# LeanCTX Final SDK-First Documentation Convergence Report

> **Classification:** Reference
>
> **Result:** Content convergence complete. Durable versioning remains blocked.
>
> **Directive:** 896 lines; SHA-256
> `20dded2545035bdf5ed97806099a26b94b7ffb8f02503563aa266350fed146b9`.

## Final product truth

- LeanCTX is a premium Context SDK for AI agents and AI-native products.
- LeanCTX Engine remains public, Apache-2.0, strong, and independently useful.
- LeanCTX Production SDK is Thinkery's primary product.
- Production SDK must live in a separate repository.
- Production SDK license family is BSL 1.1.
- Cloud is private/commercial, optional, and later.
- Customers may build on Engine; LeanCTX wins by making SDK integration the
  better engineering and business decision.
- Customer-facing lifecycle semantics must not leak into Engine.

## Scope and safety

- Reviewed every non-archive `docs/internal/**/*.md`.
- Changed documentation and documentation-governance checks only.
- No product/runtime source, package, license file, repository, deployment,
  pricing, or public website changed.
- No commit, push, package publication, repository creation, or commercial
  commitment occurred.
- Existing `docs/internal/**` ignore protection remains in place.

## Authority convergence

Authority path reduced from **13** entries to **8**:

1. canonical SDK-first product architecture;
2. Production SDK decision record;
3. Engine/SDK/Cloud plan;
4. implementation roadmap;
5. SDK positioning;
6. master execution tracker;
7. anti-roadmap;
8. proof doctrine.

The README is the navigation/status entry point; Research, Reference,
Operational, and archived documents cannot override this path.

## Inventory simplification

| Measure | Before | After |
| --- | ---: | ---: |
| Non-archive Markdown documents | 79 | 59 |
| Active product/support/tracker documents | 40 | 21 |
| Authority-path entries | 13 | 8 |
| Files archived in this pass | 0 | 21 |

The final active count uses the deterministic inventory rule: Canonical, Active
support, and Execution tracker only. Skills are now Operational guidance rather
than product authority. Research and Reference files are non-authoritative.

The previous inventory's recursive self-ingestion was removed. The new
`checks/build-docs-inventory.py` produces one stable row per non-archive file
and a self-generated marker for the inventory itself.

## Old open-SDK statements and resolution

| Source/claim | Resolution |
| --- | --- |
| `reference/FROZEN-DECISIONS.md`: local Runtime/SDK stays OSS | Archived as superseded policy. |
| `reference/OSS-PROTECTION.md`: Python/TypeScript/Rust SDKs classified OSS | Archived; Engine openness retained, Production SDK moved to BSL 1.1 truth. |
| `reference/MASTER-VISION.md`: SDK remains OSS/license pending | Archived as superseded master vision. |
| `vision/COMPOSABLE-VISION.md`: monetization centered on intelligence/operations | Archived after valid research concepts were retained as gated later directions. |
| `reference/THINKERY-COMMERCIAL.md`: Selection Intelligence/control plane is commercial product | Archived as Cloud/control-plane-first thesis. |
| `vision/14-LEANCTX-CALIBRATION-PERFORMANCE-PLATFORM-VISION.md`: platform/optimization-first moat | Archived; Calibrator/AutoTune remain later Research. |
| `vision/02-OSS-VS-PAID.md`: single developer free / organization paid and SDK terms pending | Rewritten as Apache Engine + BSL 1.1 SDK + optional Cloud boundary. |
| `vision/04-GO-TO-MARKET.md`: free SDK distribution then hosted monetization | Rewritten around SDK licensing, buy-vs-build, design partners, and LeanCTX Inside. |
| `execution/INVESTOR-NARRATIVE.md`: open SDK and Cloud/intelligence revenue ladder | Rewritten around the Production SDK as primary product. |
| `vision/06-ENGINE-SDK-CLOUD-PLAN.md`: license/commercial scope pending | Corrected: BSL 1.1 decided; only named parameters pending. |
| `vision/PRODUCT-ARCHITECTURE.md`: Production SDK licensing pending | Corrected to separate BSL 1.1 product. |
| `vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md`: future SDK license decision | Corrected; open `.ctxpkg` does not reopen BSL 1.1. |
| `reference/BRAND-NARRATIVE.md`: Production SDK licensing pending | Corrected to premium BSL 1.1 SDK and build-vs-buy story. |
| `reference/CONTRADICTIONS.md`: OSS/BSL both unapproved | Resolved explicitly in favor of BSL 1.1. |
| `DOCS-CONVERGENCE-REPORT.md`: previous pending-license conclusion | Replaced by this final report. |

Historical occurrences now live only under `_archive/` or inside explicitly
labelled contradiction history.

## Documents updated to BSL 1.1 product truth

- `README.md`
- `vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md`
- `vision/00-NORTH-STAR.md`
- `vision/02-OSS-VS-PAID.md`
- `vision/04-GO-TO-MARKET.md`
- `vision/05-CONTEXT-SDK-POSITIONING.md`
- `vision/06-ENGINE-SDK-CLOUD-PLAN.md`
- `vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md`
- `vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md`
- `vision/PRODUCT-ARCHITECTURE.md`
- `execution/ANTI-ROADMAP.md`
- `execution/COMPLETE-VISION-DELIVERY-PLAN.md`
- `execution/INVESTOR-NARRATIVE.md`
- `execution/MASTER-EXECUTION-PLAN.md`
- `execution/OSS-VISION-DELIVERY-PLAN.md`
- `execution/SDK-PRODUCTION-DECISION-RECORD.md`
- `reference/BRAND-NARRATIVE.md`
- `reference/CONTRADICTIONS.md`
- `reference/OCLA-CAPABILITY-ARCHITECTURE.md`

## BSL parameters still pending

The license family is not pending. These exact parameters are:

- repository visibility/access and administrative owner;
- package namespace and registry owner;
- BSL Change Date;
- BSL Change License;
- BSL Additional Use Grant;
- evaluation/development and production/free-use boundary;
- OEM redistribution/commercial terms;
- pricing and enterprise exceptions;
- contributor DCO/CLA process;
- security reporting and release policy.

## SDK product value added

Canonical and supporting product documents now state that the SDK owns:

- Select → Shape → Reuse → Recover lifecycle;
- `ContextSession`, `ContextSource`, `ContextView`, `ContextPlan`, and
  `ContextReceipt` as product semantics;
- budgets, source identity, freshness, trust, reuse, recovery, and degradation;
- factual evidence projection and quality integration;
- maintained host/framework lifecycle and error semantics;
- Engine×SDK compatibility, migrations, deprecation, fixtures, and provenance;
- premium DX, clean installation, documentation, support, and embedded/OEM APIs.

The canonical architecture includes Product Priority, Production SDK License,
Why the SDK Exists, Why Buy Instead of Build, Engine versus SDK Boundary, SDK
Quality Bar, LeanCTX Inside, and the SDK PMF Test.

## Engine-versus-SDK leakage risks

| Risk | Documentation rule |
| --- | --- |
| Move `ContextSession`/high-level Plan lifecycle into Engine | Keep customer lifecycle in BSL SDK. |
| Expand Rust `lean-ctx-sdk` facade into competing product truth | Treat it as Engine embedding facade only. |
| Rename Python Preview into Production SDK | Require real Runtime parity, contracts, compatibility, security, and release gates. |
| Put framework adapter lifecycle in Engine | Engine exposes mechanisms; SDK owns maintained integrations. |
| Make Workspace or Agent Bus a product shortcut | Keep them Research/local coordination until separately promoted. |
| Use OCLA selection/marketplace semantics as product layer | Keep OCLA bounded Engine mechanism; SDK owns lifecycle policy. |
| Hide or weaken Engine to create moat | Prohibited; product wins through quality and maintenance responsibility. |

## Archived files

Exact old/new paths and reasons are recorded in
[DOCS-MOVE-MAP.md](DOCS-MOVE-MAP.md). Twenty-one Historical, Superseded, stale
execution, open-SDK, Cloud-first, and platform-first documents were moved under
`_archive/sdk-first-convergence-2026-08-24/`.

## Validation

- Inventory builder: PASS, 59 non-archive documents.
- SDK-first convergence validator: PASS.
- Active relative links: PASS.
- Required canonical product assertions and dependency order: PASS.
- Decision-record DECIDED/PENDING split: PASS.
- Historical/Superseded non-archive banner check: PASS.
- Public ignore protection: PASS.
- Archive/move-map integrity and inline documentation paths: PASS.
- `git diff --check`: PASS.

## Unresolved blockers

1. `docs/internal/**` remains local-only and gitignored. No approved durable
   private versioned target exists, so durable source-of-truth status is
   incomplete.
2. The exact BSL/repository/commercial/release parameters listed above need
   responsible-owner approval.
3. Runtime phase state remains independent of documentation convergence:
   last verified P0/P1 complete, P2 active, P3 next after P2, P4 not entered.
4. This pass does not authorize creation of the Production SDK repository or
   publication of BSL artifacts.

## Fresh-agent answer

LeanCTX is a premium BSL 1.1 Production Context SDK for AI agents and AI-native
products, built on a strong Apache-2.0 Engine. The Engine executes open,
deterministic mechanisms. The SDK is Thinkery's primary product and supplies the
maintained production lifecycle, semantics, safety, adapters, compatibility,
evidence, upgrades, and embedded contract that customers would otherwise have
to build and permanently maintain. Customers can build their own layer; LeanCTX
wins when they choose not to. Cloud is optional later. The moat begins with a
superior SDK and LeanCTX Inside distribution, then may compound through
production learning and later Selection Intelligence.
