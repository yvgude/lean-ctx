# LeanCTX Internal Documentation Inventory

> **Classification:** Reference
>
> **Scope:** Every non-archive Markdown document under `docs/internal/**`.
> Generated deterministically by `checks/build-docs-inventory.py`.

## Counts

- Non-archive Markdown documents: **67**
- Active product/support/tracker documents: **21**
- Canonical authority-path entries: **8**
- Archived in final SDK-first pass: **21**

A document is active for this count only when classified Canonical, Active
support, or Execution tracker. Operational guidance, Research, and Reference
are non-authoritative. Archived files are excluded.

## Classification

| Path | Title | Class | Unique job | Evidence |
| --- | --- | --- | --- | --- |
| `DOCS-CONVERGENCE-REPORT.md` | LeanCTX Final SDK-First Documentation Convergence Report | Reference | Convergence evidence and blockers | `sha256:b114ba9b0b71` |
| `DOCS-INVENTORY.md` | LeanCTX Internal Documentation Inventory | Reference | Deterministic file classification | `self-generated` |
| `DOCS-MOVE-MAP.md` | LeanCTX Documentation Move Map | Reference | Archived-path recovery | `sha256:2b00b6860a43` |
| `ENGINE-SDK-SOURCE-AUDIT-REPORT.md` | LeanCTX Engine–SDK Source Audit Report | Research | Unpromoted direction; no product promise | `sha256:36451a31f1c0` |
| `POST-AUDIT-P2-CLOSURE-REPORT.md` | Post-Audit P2 Closure Report | Research | Unpromoted direction; no product promise | `sha256:1401c4aee1d5` |
| `README.md` | Thinkery / LeanCTX — Internal Canonical Entry Point | Canonical | Authority path | `sha256:bdbbcf632267` |
| `execution/ANTI-ROADMAP.md` | H8 — Definitive Anti-roadmap | Canonical | Authority path | `sha256:72623b24dd38` |
| `execution/CLOUD-RECEIPT-BOARD-DESIGN-V1.md` | Cloud Receipt Board — Design v1 | Research | Unpromoted direction; no product promise | `sha256:e41e7b31e3aa` |
| `execution/DEVELOPER-EXPERIENCE.md` | H18 — LeanCTX SDK Developer Experience | Reference | Background, audit, or technical evidence | `sha256:1a411a6185b2` |
| `execution/ENTERPRISE-POSITIONING.md` | Enterprise Positioning — Context systems with evidence | Reference | Background, audit, or technical evidence | `sha256:90f4270de98d` |
| `execution/FOCUS-IDENTITY.md` | Thinkery / LeanCTX — Focus and Identity | Active support | Current supporting product guidance | `sha256:2b6c41b2bbda` |
| `execution/GITLAB-ISSUES.md` | E2 — GitLab Issue Manifest | Execution tracker | Progress only; no architecture authority | `sha256:ca084d952ae9` |
| `execution/INVESTOR-NARRATIVE.md` | LeanCTX / Thinkery AG — SDK-First Investor Narrative | Active support | Current supporting product guidance | `sha256:55c7a47e94a7` |
| `execution/MASTER-EXECUTION-PLAN.md` | Master Execution Plan | Canonical | Authority path | `sha256:2e73e5d01e95` |
| `execution/ONE-PAGER.md` | LeanCTX / Thinkery AG | Reference | Background, audit, or technical evidence | `sha256:68f940fd0328` |
| `execution/OSS-PRESERVATION-CONTRACT.md` | LeanCTX OSS Preservation Contract | Reference | Background, audit, or technical evidence | `sha256:3347c29938aa` |
| `execution/OSS-VISION-DELIVERY-PLAN.md` | OSS Vision Delivery Plan | Execution tracker | Progress only; no architecture authority | `sha256:e9d9ba7cb96e` |
| `execution/PILOT-PACK.md` | Pilot Pack — Agent Tuning Sprint | Reference | Background, audit, or technical evidence | `sha256:c3b9ec1ff856` |
| `execution/PILOT-REPORT-TEMPLATE.md` | Pilot report — Agent Tuning Sprint | Reference | Background, audit, or technical evidence | `sha256:9c5259488a71` |
| `execution/POC-DESIGN.md` | H12 — Fastest credible LeanCTX POC | Reference | Background, audit, or technical evidence | `sha256:8685fb9d341b` |
| `execution/PRODUCTION-SDK-VALUE-CONTRACT.md` | LeanCTX Production SDK Value Contract | Reference | Background, audit, or technical evidence | `sha256:bae22bf00ba5` |
| `execution/PROOF-DOCTRINE.md` | LeanCTX Proof Doctrine | Canonical | Authority path | `sha256:e78ed0c1167a` |
| `execution/SDK-EXTRACTION-MIGRATION-PLAN.md` | LeanCTX SDK Extraction Migration Plan | Reference | Background, audit, or technical evidence | `sha256:f4e87ab178b5` |
| `execution/SDK-PRODUCTION-DECISION-RECORD.md` | Production SDK Decision Record | Canonical | Authority path | `sha256:d5ff44b61ad6` |
| `execution/WEBSITE-IMPLEMENTATION-PLAN.md` | E1 — Website implementation plan | Execution tracker | Progress only; no architecture authority | `sha256:32fad7a5b7de` |
| `execution/WEBSITE-REDESIGN.md` | LeanCTX Website Copy | Research | Unpromoted direction; no product promise | `sha256:410a438532f7` |
| `reference/APACHE-TO-BSL-PROVENANCE-REVIEW.md` | Apache-to-BSL Provenance Review | Reference | Background, audit, or technical evidence | `sha256:10c0a0163bb7` |
| `reference/BENCHMARK-CALIBRATOR-GAP.md` | Benchmark & Calibrator — Codebase Gap Analysis | Reference | Background, audit, or technical evidence | `sha256:93529c130cae` |
| `reference/BRAND-NARRATIVE.md` | LeanCTX / Thinkery — Brand Narrative | Active support | Current supporting product guidance | `sha256:b198d2585ff2` |
| `reference/CI-DEPS-AUDIT.md` | D5 — Dependency, CI, and Build-System Audit | Reference | Background, audit, or technical evidence | `sha256:c5c47ea7557e` |
| `reference/CODEBASE-DEEP-MAP.md` | lean-ctx definitive codebase map | Reference | Background, audit, or technical evidence | `sha256:7dcfa331af32` |
| `reference/CODEBASE-MAP.md` | H2 — Complete codebase-to-SDK-strategy map | Reference | Background, audit, or technical evidence | `sha256:66085d366711` |
| `reference/CODEBASE-TRIM-PACKAGES.md` | D2 — Non-Rust Package Audit | Reference | Background, audit, or technical evidence | `sha256:1b1277a275b4` |
| `reference/CODEBASE-TRIM-RUST.md` | D1 — Rust Codebase Audit Against the Composable Vision | Reference | Background, audit, or technical evidence | `sha256:2978fe3396bc` |
| `reference/COMPETITIVE-POSITIONING.md` | B4 — Competitive Positioning Update | Research | Unpromoted direction; no product promise | `sha256:3c89ce81da91` |
| `reference/CONTEXT-KITS.md` | H5 — Context Kit Target Architecture | Research | Unpromoted direction; no product promise | `sha256:34c839205bc1` |
| `reference/CONTEXT-SESSION.md` | H16 — ContextSession design | Reference | Background, audit, or technical evidence | `sha256:c9d680867472` |
| `reference/CONTRADICTIONS.md` | Contradictions, resolutions, and missing pieces | Research | Unpromoted direction; no product promise | `sha256:6c51bbb6d497` |
| `reference/DYNO-AUTOTUNE.md` | H3 — Dyno and AutoTune Technical Architecture | Research | Unpromoted direction; no product promise | `sha256:793afcd35ff4` |
| `reference/ENGINE-DECOMMISSION-CANDIDATES.md` | Engine Decommission Candidates | Reference | Background, audit, or technical evidence | `sha256:6e7e624f8490` |
| `reference/ENGINE-SDK-SOURCE-OWNERSHIP-MATRIX.md` | Engine–SDK Source Ownership Matrix | Research | Unpromoted direction; no product promise | `sha256:cc43fd6953e2` |
| `reference/OCLA-CAPABILITY-ARCHITECTURE.md` | OCLA Capability Architecture | Active support | Current supporting product guidance | `sha256:df2b77583774` |
| `reference/OCLA-CURRENT-STATE.md` | OCLA Current-State Audit | Reference | Background, audit, or technical evidence | `sha256:e15fdf0e104d` |
| `reference/OCLA-GAP-ANALYSIS.md` | OCLA Capability Architecture Gap Analysis | Reference | Background, audit, or technical evidence | `sha256:43f779b2cc79` |
| `reference/RECEIPT-EVIDENCE.md` | H6 — Receipt and Evidence Architecture | Reference | Background, audit, or technical evidence | `sha256:9a858eff3652` |
| `reference/TECHNICAL-CONVERGENCE.md` | C5 — Technical Convergence Plan | Reference | Background, audit, or technical evidence | `sha256:b36e516d2a40` |
| `reference/TUNING-PROFILE.md` | H4 — TuningProfile system design | Reference | Background, audit, or technical evidence | `sha256:5485d79e23c9` |
| `reference/VISUAL-BRAND-GUIDELINES.md` | LeanCTX / Thinkery — Visual Brand Guidelines | Reference | Background, audit, or technical evidence | `sha256:bafc08a29a93` |
| `reference/VZUG-ICP-VALIDATION.md` | 12 — V-ZUG ICP Feedback: Strategic Impact on LeanCTX | Reference | Background, audit, or technical evidence | `sha256:ab7a1f3527d3` |
| `skills/agent-orchestration.md` | Agent Orchestration Skill | Operational guidance | Agent/document workflow instructions | `sha256:09f5aee98418` |
| `skills/documentation.md` | Documentation Placement | Operational guidance | Agent/document workflow instructions | `sha256:5dfcd98cc7ff` |
| `skills/evidence-spine.md` | Evidence spine implementation | Operational guidance | Agent/document workflow instructions | `sha256:b62f2d48845a` |
| `skills/focus-contract.md` | Focus Contract — Thinkery / LeanCTX | Operational guidance | Agent/document workflow instructions | `sha256:508d6c767c5f` |
| `skills/master-execution.md` | Master Execution — LeanCTX Premium Delivery | Operational guidance | Agent/document workflow instructions | `sha256:0cb0fecab9fa` |
| `skills/ocla-capability.md` | OCLA capability implementation | Operational guidance | Agent/document workflow instructions | `sha256:5590ecd83ffe` |
| `skills/open-core-boundary.md` | Open-core boundary review | Operational guidance | Agent/document workflow instructions | `sha256:e0bf296273d3` |
| `skills/scheduler-phase.md` | Scheduler phase implementation | Operational guidance | Agent/document workflow instructions | `sha256:239a2f748c8a` |
| `skills/task-envelope.md` | TaskEnvelopeV1 implementation | Operational guidance | Agent/document workflow instructions | `sha256:17c0c944fa00` |
| `vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md` | LeanCTX — Canonical SDK-First Product and Repository Architecture | Canonical | Authority path | `sha256:d7652d6a4318` |
| `vision/00-NORTH-STAR.md` | LeanCTX — North Star | Active support | Current supporting product guidance | `sha256:09991251c36b` |
| `vision/02-OSS-VS-PAID.md` | LeanCTX OSS vs Paid Boundary | Active support | Current supporting product guidance | `sha256:26495897cd1c` |
| `vision/04-GO-TO-MARKET.md` | LeanCTX SDK-First Go-to-Market | Active support | Current supporting product guidance | `sha256:faa92fbd4673` |
| `vision/05-CONTEXT-SDK-POSITIONING.md` | LeanCTX — Context SDK Positioning | Canonical | Authority path | `sha256:2e0739f9a1d6` |
| `vision/06-ENGINE-SDK-CLOUD-PLAN.md` | LeanCTX Engine, SDK & Cloud — Canonical Product Plan | Canonical | Authority path | `sha256:924bee9ae403` |
| `vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md` | LeanCTX Context Workspace & `.ctxpkg` Plan | Active support | Current supporting product guidance | `sha256:c05ae81f8ce5` |
| `vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md` | LeanCTX Complete Implementation Roadmap | Canonical | Authority path | `sha256:f6ce01f7eb47` |
| `vision/PRODUCT-ARCHITECTURE.md` | LeanCTX Product Architecture | Active support | Current supporting product guidance | `sha256:1b7f9a3922f1` |

Historical and superseded material is recoverable through
[DOCS-MOVE-MAP.md](DOCS-MOVE-MAP.md). Classification never overrides the
authority order in [README.md](README.md).
