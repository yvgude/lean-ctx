# LeanCTX Documentation Move Map

> **Classification:** Reference
>
> **Purpose:** Preserve exact paths for documents archived during the final
> SDK-first convergence. Archived files are historical evidence only.

## SDK-first convergence archive

| Previous path | Archived path | Reason |
| --- | --- | --- |
| `execution/C8-final-state.md` | `_archive/sdk-first-convergence-2026-08-24/execution/C8-final-state.md` | Historical final-state snapshot. |
| `execution/CLEANUP-PLAN.md` | `_archive/sdk-first-convergence-2026-08-24/execution/CLEANUP-PLAN.md` | Completed cleanup audit/plan. |
| `execution/CONVERGENCE-PLAN.md` | `_archive/sdk-first-convergence-2026-08-24/execution/CONVERGENCE-PLAN.md` | Historical migration authority. |
| `execution/COMPLETE-VISION-DELIVERY-PLAN.md` | `_archive/sdk-first-convergence-2026-08-24/execution/COMPLETE-VISION-DELIVERY-PLAN.md` | Duplicate broad execution blueprint; current roadmap and master tracker control. |
| `execution/NEXT-STEPS.md` | `_archive/sdk-first-convergence-2026-08-24/execution/NEXT-STEPS.md` | Dated weekly tracker. |
| `execution/PRIORITY-MATRIX.md` | `_archive/sdk-first-convergence-2026-08-24/execution/PRIORITY-MATRIX.md` | Original 90-day tracker with stale source references. |
| `execution/SDK-V1-SPEC.md` | `_archive/sdk-first-convergence-2026-08-24/execution/SDK-V1-SPEC.md` | Historical Preview spec; not Production SDK contract. |
| `execution/SPRINT-ONE-PAGER.md` | `_archive/sdk-first-convergence-2026-08-24/execution/SPRINT-ONE-PAGER.md` | Dated commercial sprint artifact. |
| `execution/SPRINT-OUTREACH.md` | `_archive/sdk-first-convergence-2026-08-24/execution/SPRINT-OUTREACH.md` | Dated outreach artifact. |
| `execution/SPRINT-PROOF.md` | `_archive/sdk-first-convergence-2026-08-24/execution/SPRINT-PROOF.md` | Dated proof artifact. |
| `reference/FROZEN-DECISIONS.md` | `_archive/sdk-first-convergence-2026-08-24/reference/FROZEN-DECISIONS.md` | Old open-SDK and Cloud-monetization synthesis. |
| `reference/MASTER-VISION.md` | `_archive/sdk-first-convergence-2026-08-24/reference/MASTER-VISION.md` | Superseded master vision. |
| `reference/OSS-PROTECTION.md` | `_archive/sdk-first-convergence-2026-08-24/reference/OSS-PROTECTION.md` | Superseded open-SDK policy. |
| `reference/REPO-CONVERGENCE.md` | `_archive/sdk-first-convergence-2026-08-24/reference/REPO-CONVERGENCE.md` | Historical repository audit. |
| `reference/THINKERY-COMMERCIAL.md` | `_archive/sdk-first-convergence-2026-08-24/reference/THINKERY-COMMERCIAL.md` | Superseded Cloud/control-plane-first commercial thesis. |
| `reference/WHAT-WE-HAVE.md` | `_archive/sdk-first-convergence-2026-08-24/reference/WHAT-WE-HAVE.md` | Dated implementation audit; current source and focused maps control. |
| `vision/01-PRODUCT-ARCHITECTURE.md` | `_archive/sdk-first-convergence-2026-08-24/vision/01-PRODUCT-ARCHITECTURE.md` | Replaced by canonical SDK-first architecture. |
| `vision/03-ROADMAP.md` | `_archive/sdk-first-convergence-2026-08-24/vision/03-ROADMAP.md` | Historical roadmap. |
| `vision/COMPOSABLE-VISION.md` | `_archive/sdk-first-convergence-2026-08-24/vision/COMPOSABLE-VISION.md` | Broad research thesis retained after current conclusions were extracted. |
| `vision/CONTEXT-WORKSPACE-CTXPKG-MASTER-CONCEPT.md` | `_archive/sdk-first-convergence-2026-08-24/vision/CONTEXT-WORKSPACE-CTXPKG-MASTER-CONCEPT.md` | Superseded Workspace source concept. |
| `vision/14-LEANCTX-CALIBRATION-PERFORMANCE-PLATFORM-VISION.md` | `_archive/sdk-first-convergence-2026-08-24/vision/14-LEANCTX-CALIBRATION-PERFORMANCE-PLATFORM-VISION.md` | Superseded optimization/platform-first commercial vision. |

Active links must target current authority; this map is for historical recovery,
not an alternate authority path.
