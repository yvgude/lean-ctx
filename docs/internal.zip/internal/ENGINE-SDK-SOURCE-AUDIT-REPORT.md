# LeanCTX Engine–SDK Source Audit Report

> **Classification:** Documentation-only source ownership decision
>
> **Audited commit:** `2c7d0044302d50af8d218a041b45726ad710757c`
>
> **Integrated branch:** `github/main`
>
> **Integrated commit:** `2c7d004430 Merge pull request #1521 from
> yvgude/fix/1511-1514-user-reports`
>
> **Remote state:** **VERIFIED** by `git fetch --all --prune` and upstream
> inspection on 2026-08-24. Full candidate CI remains local until published.

## Executive conclusion

The codebase is splittable along the approved architecture, but not by moving
folders wholesale. Ownership and OSS preservation are separate decisions. It
needs a contract-first semantic extraction:

- keep deterministic mechanisms, factual evidence, security and the supported
  OSS coding-agent product in the Apache Engine;
- preserve current coding-agent Attach heuristics as OSS compatibility;
- build Product Session/Source/View/Plan/Receipt, lifecycle policy, adapters,
  compatibility and OEM responsibility cleanly in the BSL SDK;
- freeze/deprecate platform-shaped Research and move only genuinely later
  organization-scale coordination into a separate private Cloud boundary.

The current monolith already contains substantial SDK-like semantics, but they
are Apache history and tightly coupled to Attach/runtime internals. They are
migration input, not a repository ready to relocate or relicense. Unused,
redundant, experimental or unsupported implementation is not automatically a
permanent Engine obligation.

> **Preserve the OSS product contract, not the historical monolith.**

### Top five mixed-boundary risks

1. `lean-ctx-protocol/src/lib.rs` combines Engine Interface with SDK session,
   profile/Kit, control-plane, fleet, rollout and value-share contracts.
2. `core/context_kernel/types.rs` and `orchestrator.rs` define and operate
   `ContextPlanV1`/`ContextReceiptV1` inside the Engine while bridges make them
   part of current Attach behavior.
3. `context_compiler.rs` and `context_field.rs` mix a valuable deterministic
   bounded optimizer with task strategy, view meaning, presets, bandit input
   and process-global mutable weights.
4. Profiles, Kits and Python Preview mix open mechanisms/formats with product
   lifecycle, policy and adapter responsibility.
5. Root `lib.rs` and default build dependencies expose Cloud and almost the
   entire monolith as one public Engine crate, making cleanup compatibility
   sensitive.

### Top five OSS-regression risks

1. `tools/registered/ctx_read.rs:273` calls
   `server/context_gate.rs:63`; removing gate/Kernel behavior can change all
   read modes and repeat-read semantics.
2. `core/session/**` owns current hook/task/findings/decision/file continuity,
   persistence and compaction; it has external contributor signals.
3. CLI/MCP/proxy/hook changes can alter setup, Attach, native output, recovery,
   shutdown and deterministic tool schemas.
4. PathJail, secret detection/redaction, bounded IO/process execution and
   artifact integrity are distributed mechanisms and must remain open.
5. Rust `lean-ctx-sdk` embeds the real Engine and currently enables broad root
   features; careless narrowing can break power users or AST read modes.

### Top five SDK-value leakage risks

1. Treating Kernel or protocol `ContextPlan`/`ContextReceipt` as the final SDK
   product instead of historical Apache contracts.
2. Leaving candidate construction, task signal choice and lifecycle strategy
   as canonical Engine behavior.
3. Leaving freshness, invalidation, reuse, recovery and degradation semantics
   as an Engine-owned cross-product lifecycle.
4. Leaving Profile/Kit product policy, composition and activation canonical in
   the Engine.
5. Shipping adapters and compatibility as thin call-through wrappers without
   maintained host lifecycle, errors, migrations, fixtures and support.

### Legal/provenance review

Every likely migration input already carries Apache-2.0 source/package signals.
Local history shows external-author signals in `context_kernel/**` and multiple
external authors in `core/session/**`. Rights, CLA/DCO, employment assignment,
published blob mapping and dual-license authority are not established by this
audit. Direct source reuse in BSL is therefore **LEGAL/PROVENANCE REVIEW
REQUIRED**; the safe default is clean implementation behind open contracts.
This does not require the Engine to retain every implementation forever:
future inclusion and BSL source reuse are separate decisions.

## Preflight and integrated-source truth

```text
root:   /Users/yvesgugger/Documents/Privat/Projects/lean-ctx
branch: main
local:  a0585a0fbc4acf4c01c24d704f4e05146342e54d (dirty, preserved)
truth:  github/main@2c7d0044302d50af8d218a041b45726ad710757c
status: pre-existing internal-doc edits plus untracked .codex-worktrees/ and
        docs/internal.zip; preserved and excluded from source truth
```

Local `main` tracks `github/main`; the separate GitLab `origin/main` is not this
branch's upstream. Fetch verified `github/HEAD -> github/main`. A clean isolated
worktree at the integrated SHA was used for source truth. Existing P1/P2/P3 and
bus worktrees remained candidate evidence only.

## Delta revalidation from the previous audit

The delta from `a0585a0fbc4acf4c01c24d704f4e05146342e54d` to the integrated SHA
contains 22 files: 2,712 insertions and 121 deletions. Every changed file was
classified; no unchanged source family was blindly re-audited.

| Integrated change | Audit effect |
| --- | --- |
| non-v1 protocol freeze (#1518) | `auto_routing`, `control_plane`, `fleet_control`, `rollout` and `value_share` are explicitly experimental non-v1, consumer-frozen and removable no earlier than v2; this strengthens `OSS_NOT_PRESERVED`/decommission classification rather than permanent protocol preservation |
| Evidence Bundle v2 canonical signature validation (#1519) | schema and contract tests reject non-canonical Base64 pad bits; v2 stays the open canonical verifier contract and P2 must reuse it |
| lossless `ctx_read`/triage behavior (#1521) | `ctx_read` bypasses a second lossy task-triage filter and filter level zero preserves bytes; exact shaping/recovery remains `OSS_CORE_CONTRACT` |
| shell and hook security fixes (#1521) | PowerShell assignment/member wrappers and nested substitutions are admitted safely; Windows shell wrapping and hook rewrites preserve truth. These strengthen open safety obligations |
| PI shell configuration fixes (#1521) | configured shell path is honored and tested; this is OSS product compatibility, not SDK lifecycle |

No delta changed the approved Engine→SDK→Cloud dependency direction. It did
make the previous blanket preservation wording too conservative.

## Quantitative inventory

| Measure | Result |
| --- | ---: |
| Required-root files enumerated | 1,675 |
| Tracked `rust/src` paths inventoried by runtime-boundary review | 2,003 |
| Python package files | 30 |
| Rust Engine façade files | 12 |
| Protocol files | 29 |
| Root core files | 1,223 |
| Server/tools/proxy/HTTP files | 378 |
| Kits and root build/export files | 3 |
| Root public module exports reviewed | 41 |
| Protocol source modules reviewed | 28 |
| Protocol `pub mod` / `pub use` statements reviewed | 14 / 23 |
| Protocol public declarations inventoried | 131 |
| `core/mod.rs` public / crate-private module declarations | 279 / 171 |
| Registered tool source files inventoried | 95 |
| Material adjacent Node package files reviewed | 13 |
| Explicit ownership decision rows | 86 |

Decision rows by primary class:

| Class | Rows |
| --- | ---: |
| `ENGINE_CORE` | 8 |
| `ENGINE_PROTOCOL` | 5 |
| `OSS_PRODUCT_SURFACE` | 6 |
| `OSS_ATTACH_COMPAT` | 9 |
| `OPEN_FORMAT_OR_SPEC` | 5 |
| `SPLIT_REQUIRED` | 20 |
| `SDK_MIGRATION_INPUT` | 10 |
| `SDK_BSL_TARGET` | 1 |
| `CLOUD_PRIVATE_TARGET` | 4 |
| `RESEARCH_FREEZE` | 12 |
| `LEGACY_DEPRECATE` | 6 |

The independent preservation axis is:

| OSS preservation tier | Rows |
| --- | ---: |
| `OSS_CORE_CONTRACT` | 14 |
| `OSS_TRANSITION_COMPAT` | 32 |
| `OSS_NOT_PRESERVED` | 25 |
| `OPEN_INTEROP_CONTRACT` | 15 |

Rows are semantic source groups, not file totals; tests/fixtures follow their
production group. The detailed matrix is the execution authority. The
decommission authority contains **31** current candidate groups.

Largest future Engine-removal candidates are frozen non-v1 protocol/control
plane, broad A2A/workflow/autonomy, Cloud/fleet/account edges,
billing/value-share/marketplace, adaptive model-routing/learning, duplicate
SDK-like Kernel/Profile/Kit/Session semantics, accidental root exports and the
Node Research package. No deletion is authorized by this audit.

## Revalidated conclusions

1. Audit baseline equals current integrated `github/main`.
2. Future ownership and OSS preservation are separate dimensions.
3. The supported local coding-agent product, open security and explicit
   interoperability/compatibility contracts are preserved.
4. Historical Apache implementation is not automatically permanent in future
   Engine releases; historical rights remain.
5. The 31-row Engine decommission map is the cleanup candidate authority.
6. BSL source reuse is governed by rights/provenance and Legal approval, not a
   blanket conclusion from prior Apache publication.
7. Physical extraction remains blocked until the real P3 dependency proof;
   P2 completion alone does not authorize a repository split.

## Critical source findings

### Protocol is not yet an Engine-only protocol

`lean-ctx-protocol/src/lib.rs` publicly re-exports Engine facts alongside
`ContextSessionConfigurationV1`, `ContextKitPinV1`,
`ContextSdkIntegrationDepthV1`, `TuningProfilePinV1`, context candidate/bundle/
receipt models, control plane, fleet, rollout and value share. Wave C must add
a narrow Engine Protocol family and freeze historical contracts before any
physical package cleanup. Published Apache schemas remain historically
available; future Engine inclusion follows the explicit compatibility and
deprecation decision.

### Context Kernel is a prototype product boundary inside Engine

`context_kernel/types.rs:192` defines `ContextPlanV1` and line 266 defines
`ContextReceiptV1`. `orchestrator.rs:54` chooses a plan and line 74 records a
receipt. `bridge.rs` feeds this into current runtime/Attach paths. This proves
useful behavior, but also couples product semantics to Engine internals.

The seam is:

```text
Engine: explicit candidates + factual source/view/cost + bounded operation
SDK: candidate intent + policy + lifecycle plan + receipt projection
```

Existing bridges remain until OSS parity passes.

`server/context_gate.rs:454-474` currently creates a Kernel plan after a read
and records `ReceiptOutcome::Accepted` from delivery alone. Delivery is a fact;
customer/task acceptance is not. Preserve this path for OSS compatibility, but
stop treating dispatch as an accepted outcome in the future evidence boundary.
Engine emits delivery/measurement facts; the SDK or host supplies explicit
accepted-quality state.

### Compiler and context field have a viable mechanism core

`context_compiler.rs:104` deterministically selects from explicit candidates
under a token budget. That narrow operation can remain Engine. Candidate
construction, pinned meaning, strategy, signal selection and Product Plan
semantics belong SDK.

`context_field.rs` contains useful IDs, view costs and token math, but
`set_active_weights` at line 270 mutates process-global strategy state.
`context_kernel/bridge.rs:229` and `adaptive_thresholds.rs:327` write it. That
state must not remain authoritative on a deterministic Engine hot path or
become an implicit cross-session SDK planner.

### Current session is Attach state, not Product ContextSession

`core/session/types.rs` records coding-agent task/findings/decisions/files,
while `state.rs`, `persistence.rs`, and `compaction.rs` provide bounded local
continuity. Preserve it as OSS Attach compatibility. The BSL Product
`ContextSession` needs clean typed lifecycle semantics and separate identity;
renaming this module would preserve the wrong model and create provenance risk.

### Python Preview contains real public semantics but an unproven runtime path

`lean_ctx/core.py:110` creates `ContextSession`; `session.py:134`, 274 and 292
expect `/v1/sessions` create/complete/abort routes. `wrap.py` owns the current
adapter path. These public Apache semantics are migration evidence, not proof
of a Production SDK boundary. The complete route family exists in the Python
fake Runtime fixture; no matching Rust production lifecycle route was found
(only a `/v1/sessions/validate` integration-test request). Wave B must either
prove compatible real Engine routes or narrow the facade with migration tests
before repository extraction.

### Profiles and Kits need field-level separation

`profiles/types.rs` combines Engine read/compression/output configuration with
routing, budget, quality, capability and autonomy policy. Engine configuration
and safety remain open; Product performance/context policy belongs SDK; learned
or autonomous strategy remains Research.

Local Kit format/parser/integrity can remain open. SDK value is maintained
activation, composition, inheritance, policy merge and session binding, not
exclusive ownership of a portable format.

### Public root leaks Cloud and platform history

`rust/src/lib.rs` exports `cloud_client`, `cloud_sync` and conditionally
`http_server`, while also exporting nearly every internal core module through
`pub mod core`. `lean-ctx-sdk/Cargo.toml:28-33` depends on the root with
`tree-sitter`, embeddings, HTTP server and secure-update features because
internals are not cleanly separated. Narrowing this is Wave G cleanup, not a
pre-split edit.

Root Cargo metadata still describes the Apache package as a “Local Context
SDK,” while canonical architecture defines it as Engine/runtime. That naming
drift must be corrected only with a compatibility-aware packaging decision; it
does not make current source BSL-owned.

The Rust Engine façade also configures process environment once, so the first
Engine instance can determine process-wide embedding behavior. Treat this as a
documented OEM compatibility risk and fixture it before broadening the façade.

Cloud client compatibility may remain Apache, but future tenant/org/fleet,
cross-customer learning and governed operation belong a separate private
service/repository. Billing, value-share, marketplace, remote relay, broad A2A,
workflow and autonomous routing are frozen or deprecated—not SDK v1 inputs.
The adjacent MIT Node package named `lean-ctx-sdk` is likewise Research/
compatibility input; freeze and deprecate it separately rather than merging its
source into the BSL product.

## Recommended source cut

```text
PRIVATE CLOUD LATER
  tenant/org governance · fleet history · governed policy distribution
  cross-deployment learning · Continuous Optimization/Selection Intelligence
                              │
                              │ SDK contracts only
                              ▼
BSL 1.1 PRODUCTION SDK — separate repository
  ContextSession · ContextSource · ContextView · ContextPlan · ContextReceipt
  Select→Shape→Reuse→Recover · adapters · freshness/reuse/recovery policy
  compatibility · migrations · stable errors · DX · OEM/LeanCTX Inside
                              │
                              │ public versioned Engine Protocol
                              ▼
APACHE-2.0 ENGINE
  safe source/search/view/compression/cache/recovery/capability mechanisms
  invocation · observation · measurement · failure · artifact/recovery facts
  CLI · MCP · local proxy/hooks · Rust Engine embedding · OSS Attach compat
```

Open formats and offline verifiers sit at the Engine/protocol boundary.
Existing Attach journal/gate/heuristics remain compatible but are not Product
SDK semantic authority.

## Migration sequence

Follow [SDK Extraction Migration Plan](execution/SDK-EXTRACTION-MIGRATION-PLAN.md):

1. Wave A ownership truth—this audit;
2. Wave B real Python Preview→Engine vertical slice;
3. Wave C narrow additive Engine Protocol;
4. Wave D gated separate BSL repository;
5. Wave E incremental clean product-semantic migration;
6. Wave F OSS compatibility freeze/parity;
7. Wave G cleanup only after Engine and SDK proof.

The [OSS Preservation Contract](execution/OSS-PRESERVATION-CONTRACT.md),
[Production SDK Value Contract](execution/PRODUCTION-SDK-VALUE-CONTRACT.md),
[ownership matrix](reference/ENGINE-SDK-SOURCE-OWNERSHIP-MATRIX.md), and
[provenance review](reference/APACHE-TO-BSL-PROVENANCE-REVIEW.md) are mandatory
gates.

## Canonical-document changes

The approved product vision was not reopened. Only navigation links to these
new audit authorities are required in the internal entry point and execution
tracker.

## No-code confirmation

```text
No product/runtime code changed.
No repository created.
No license changed.
No source files moved.
```

## Final subsystem decision table

| Major subsystem | Decision | Execution meaning |
| --- | --- | --- |
| secure reads/search/views/compression/cache/recovery/tokens | **KEEP IN ENGINE** | Strong deterministic Apache mechanisms. |
| PathJail/secrets/bounds/artifact integrity | **KEEP IN ENGINE** | Safety remains open and may strengthen. |
| Engine Interface, capability, invocation/observation/measurement/failure | **KEEP IN ENGINE** | Freeze a narrow public versioned protocol. |
| CLI/MCP/local proxy/hooks/setup/doctor/status/uninstall | **KEEP IN ENGINE** | Preserve supported OSS product via parity suite. |
| Rust `lean-ctx-sdk` façade | **KEEP IN ENGINE** | OSS in-process Engine embedding; clarify name later. |
| current coding session, context gate and read heuristics | **KEEP AS OSS COMPAT** | Preserve Attach; do not promote as Product Session/Planner. |
| Context Kernel types/orchestrator/policy/recovery/degradation/evidence | **SPLIT** | Mechanisms/facts stay open; clean lifecycle semantics go SDK. |
| context compiler/field | **SPLIT** | Pure explicit solver/math stays Engine; strategy/state goes SDK/later intelligence. |
| Profiles and Kits/packages | **SPLIT** | Open config/format/parser/security; SDK policy/activation/composition. |
| Python Preview lifecycle/wrapper/receipt semantics | **MIGRATE TO BSL SDK** | Behavior/fixtures input; clean implementation after real vertical slice and Legal review. |
| Product Session/Source/View/Plan/Receipt, adapters, compatibility, OEM | **MIGRATE TO BSL SDK** | New canonical BSL product responsibility. |
| org/fleet governance and cross-deployment learning | **MOVE TO CLOUD LATER** | Separate private owner/service after SDK PMF. |
| model/provider routing, learned weights, AutoTune, broad shared context | **FREEZE AS RESEARCH** | No SDK v1 or public-contract growth. |
| control-plane/value-share/billing/marketplace/remote relay/workflow/platform surfaces | **DEPRECATE** | Freeze now; reachability and migration before later removal. |

> **Audit first. Split second. Preserve OSS value; extract lifecycle
> responsibility.**
