# Thinkery / LeanCTX — Internal Canonical Entry Point

> **Read this first.**
>
> **Classification:** Canonical status and navigation authority
>
> **Versioning status:** LOCAL-ONLY / UNVERSIONED. Keep `docs/internal/**`
> confidential; no approved durable private versioning target currently exists.

## Product decision

LeanCTX is a premium Context SDK for AI agents and AI-native products.

> **Give every agent a production context system.**

```text
Apache-2.0 Engine → BSL 1.1 Production SDK → customer-owned product
                                              ↓
                                      optional Cloud later
```

| Product | Fixed responsibility | Current status |
| --- | --- | --- |
| **LeanCTX Engine** | Open deterministic context mechanisms. | Public Apache-2.0 runtime; independently useful. |
| **LeanCTX Production SDK** | Maintained Select → Shape → Reuse → Recover lifecycle, DX, safety, adapters, compatibility, evidence, and upgrades. | Primary Thinkery product; BSL 1.1; separate repository required. Current Python package remains Preview/migration input. |
| **LeanCTX Cloud** | Optional organization-scale history, governance, Continuous Optimization, and Selection Intelligence. | Private/commercial Research; later and never required locally. |

The Engine makes context mechanisms possible. The SDK makes them practical to
depend on in production. Customers may build their own layer on the Engine;
LeanCTX wins when a capable team prefers the SDK over permanently owning that
infrastructure.

> **“We could build this ourselves. We chose LeanCTX instead.”**

The host owns its agent, models, tools, orchestration, business logic, UX, and
customer relationship. LeanCTX owns the context system inside that loop.

## Fixed commercial boundary

- Engine license: **Apache-2.0**.
- Production SDK license family: **BSL 1.1**.
- Production SDK: **primary product** and **separate repository**.
- Cloud: **optional/later**, private/commercial.
- BSL parameters—not the license decision—remain pending in the
  [Production SDK Decision Record](execution/SDK-PRODUCTION-DECISION-RECORD.md).

Never describe the Production SDK as OSS, Apache, license-pending, a free
distribution surface, or secondary to Cloud monetization.

## Product lifecycle and boundary

```text
Select → Shape → Reuse → Recover
```

The Engine owns low-level reads, search, transforms, compression, local cache
and recovery primitives, bounded execution, artifacts, invocation/observation,
and evidence facts.

The SDK owns `ContextSession`, `ContextSource`, `ContextView`,
`ContextPlan`, `ContextReceipt`, lifecycle policy, safe defaults, adapters,
compatibility, migrations, developer ergonomics, and embedded/OEM APIs.

Do not move customer-facing lifecycle semantics into the Apache Engine. Do not
weaken the Engine to manufacture a moat.

## Status discipline

| Status | Meaning |
| --- | --- |
| **Available** | Shipped capability with a verified real path. |
| **Preview** | Narrow implemented contract with explicit limitations. |
| **Research** | Direction only; not a product promise. |
| **DECIDED** | Approved product decision; implementation may still be pending. |
| **PENDING** | A named unresolved parameter, never a blanket reopening of decided strategy. |

Current Python SDK and OpenAI Agents wrapper work remain Preview/migration input.
Workspace, `.ctxpkg`, Calibrator, AutoTune, Shared Project Context, managed
operation, Cloud, and Selection Intelligence remain Research until promoted by
explicit evidence and gates.

Agent Bus and shared-context improvements may optimize local development, but
are not a public scheduler, hosted coordinator, or generic agent platform.

## SDK-first delivery sequence

```text
Engine contract and evidence
        ↓
Production SDK product
        ↓
real embedded/customer adoption
        ↓
SDK hardening and repeatability
        ↓
optional Cloud and optimization
```

Current phase status must come from accepted default-branch integration and the
execution tracker. Last verified state: P0/P1 complete, P2 active, P3 next after
P2, SDK repository work at its gated entry, Cloud later. Never promote isolated
worktrees.

## Evidence discipline

Receipts are factual evidence, not automatic proof of quality or savings.
External outcomes require a comparable baseline, quality threshold, named
measure, visible methodology, and limitations. SDK PMF requires a real
buy-vs-build win, retention, repeat integration, or embedded production use.

## Authority path

1. [Canonical SDK-First Product Architecture](vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md) — product, license, repository, and Engine/SDK boundary.
2. [Production SDK Decision Record](execution/SDK-PRODUCTION-DECISION-RECORD.md) — decided strategy and pending BSL/release parameters.
3. [Engine, SDK & Cloud Plan](vision/06-ENGINE-SDK-CLOUD-PLAN.md) — implementation boundary and sequence.
4. [Complete Implementation Roadmap](vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md) — dependency gates and acceptance.
5. [Context SDK Positioning](vision/05-CONTEXT-SDK-POSITIONING.md) — product story, buy-vs-build, DX, and LeanCTX Inside.
6. [Master Execution Plan](execution/MASTER-EXECUTION-PLAN.md) — accepted progress only.
7. [Anti-Roadmap](execution/ANTI-ROADMAP.md) — scope and leakage guardrails.
8. [Proof Doctrine](execution/PROOF-DOCTRINE.md) — evidence and claim rules.

This path has eight authorities, reduced from the previous thirteen-entry path.
Supporting, Research, Reference, Historical, and archived files cannot override
it.

## Supporting document map

| Need | Source |
| --- | --- |
| Commercial boundary | [OSS vs Paid](vision/02-OSS-VS-PAID.md) |
| Design partners and GTM | [Go to Market](vision/04-GO-TO-MARKET.md) |
| Investor story | [Investor Narrative](execution/INVESTOR-NARRATIVE.md) |
| Current external model | [Product Architecture](vision/PRODUCT-ARCHITECTURE.md) |
| Workspace Research | [Context Workspace Plan](vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md) |
| Evidence details | [Receipt & Evidence](reference/RECEIPT-EVIDENCE.md) |
| Engine/SDK source boundary | [Source Ownership Matrix](reference/ENGINE-SDK-SOURCE-OWNERSHIP-MATRIX.md) |
| Future Engine cleanup authority | [Engine Decommission Candidates](reference/ENGINE-DECOMMISSION-CANDIDATES.md) |
| OSS extraction guardrail | [OSS Preservation Contract](execution/OSS-PRESERVATION-CONTRACT.md) |
| Production SDK value gate | [Production SDK Value Contract](execution/PRODUCTION-SDK-VALUE-CONTRACT.md) |
| Apache/BSL provenance | [Provenance Review](reference/APACHE-TO-BSL-PROVENANCE-REVIEW.md) |
| Extraction sequence | [SDK Extraction Migration Plan](execution/SDK-EXTRACTION-MIGRATION-PLAN.md) |
| Source audit conclusion | [Engine–SDK Source Audit Report](ENGINE-SDK-SOURCE-AUDIT-REPORT.md) |
| Post-audit P2 evidence | [P2 Closure Report](POST-AUDIT-P2-CLOSURE-REPORT.md) |
| Conflict resolutions | [Contradictions](reference/CONTRADICTIONS.md) |
| Complete file classification | [Documentation Inventory](DOCS-INVENTORY.md) |
| Archived moves | [Documentation Move Map](DOCS-MOVE-MAP.md) |
| Convergence evidence | [Convergence Report](DOCS-CONVERGENCE-REPORT.md) |

## Operating rule

> **LeanCTX should own what the agent knows for the next step—not what the agent
> does next. Build less surface. Make that surface exceptional.**
