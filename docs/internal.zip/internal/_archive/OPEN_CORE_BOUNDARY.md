# Open-Core Boundary

**Status:** Binding for future development
**Date:** 2026-08-09
**Owner:** Architecture/Product Owner

This document is the classification authority for new implementation in the
lean-ctx ecosystem. It makes the forward-only decision from
`docs/adrs/ADR-014-open-runtime-invariant.md` operational and preserves the
Apache-2.0 status of code that has already been published.

The governing principle is:

> **Open the edge. Close the brain. Open trust. Close compounding intelligence.**

Deployment and license are independent dimensions. A commercial component may
run in Cloud, a customer VPC, on-premises, a sovereign region, or an
air-gapped environment. Its deployment location does not change its class.

## Formal classes

### A = Open Runtime (local execution, always free)

Class A is the Apache-2.0 Runtime that gives an individual developer a useful
local coding workflow without Control Plane, Cloud, or Enterprise services. It
executes local reads, shell, tools, context shaping, local memory, local
verification, provider calls using user-controlled credentials, and other
non-compounding Runtime primitives.

Class A code is public, inspectable, independently buildable, and free to use
for local execution. A local Runtime may consume a Class B contract and may
execute a signed instruction, but it must not require a commercial service to
perform its protected local coding path.

### B = Open Protocol (shared contracts, schemas, SDKs)

Class B is the public interoperability surface: semantic data types, versioned
wire contracts, JSON Schemas, OpenAPI descriptions, Protobuf projections,
signing and verification formats, SDKs, conformance tests, and reference
adapters that let independent implementations interoperate.

Class B exposes the shape and evidence needed to inspect or verify a decision;
it does not expose the proprietary algorithm that chooses the decision. A
protocol field may describe a selected model, policy, plan, or outcome without
publishing the scheduler, ranking weights, training data, or commercial
methodology that produced it.

### C = Grandfathered/Reference (public, intelligence-frozen)

Class C is implementation that is already public and Apache-2.0 but contains a
basic, static, experimental, or reference form of a capability whose future
compounding intelligence is private. It remains available for compatibility,
safety, education, and local use. It is not expanded into the production
learning or organization-scale decision system.

Class C may receive bug fixes, security fixes, portability work, bounded safety
improvements, and contract updates. New adaptive learning, cross-task ranking,
fleet allocation, organization governance, provider economics, or similar
compounding behavior is not added to Class C; that work is Class D or E.

### D = Private Intelligence (enterprise commercial, never public)

Class D is enterprise software that decides, ranks, learns, coordinates,
governs, or monetizes across tasks, workloads, users, teams, providers, or
organizations. It includes the Control Plane brain and its production
implementations: adaptive scheduling, outcome and capability intelligence,
organization-scale knowledge governance, fleet control, enterprise policy,
managed gateway behavior, commercial attribution, and provider economics.

Class D source code, implementation details, learned models, private
algorithms, and production decision logic are never committed to the public
lean-ctx repositories. The enterprise repository and its controlled build
artifacts are the source for D code.

### E = Strategic Data (customer/learned data, never in repos)

Class E is data whose value or sensitivity comes from customer workloads,
cross-task outcomes, learned weights, private benchmarks, organization state,
provider relationships, or commercial operation. It includes task-performance
graphs, task fingerprints, model/capability rankings, learned policy weights,
customer-derived outcome data, supplier rates, margin models, credentials,
customer rosters, and private benchmark corpora.

Class E is never stored in a source repository, public or private, as a
normal tracked artifact. It belongs in approved data stores with access,
retention, residency, and deletion controls. Repositories may contain
schemas, migration code, and deterministic synthetic fixtures that describe
the shape of E, but never customer or learned values.

## Classification rules

Use responsibility and data authority, not process location, to classify a new
component:

| Question | Class outcome |
| --- | --- |
| Does it execute a local read, shell action, tool call, provider request, or already-public deterministic primitive? | A, unless it embeds private decision logic or strategic data. |
| Is it a shared shape, schema, SDK, verifier, or reference adapter? | B. |
| Is it already public and useful, but intentionally limited to reference/basic behavior? | C. |
| Does it decide which context, capability, model, provider, budget, retry, or task should be used from learned or organization-scale evidence? | D. |
| Does its value reside in customer, learned, benchmark, supplier, or commercial operational data? | E. |

An open contract may describe a Class D decision. Publishing the description,
receipt, or verifier does not publish the decision system. A Class A Runtime
may enforce a signed policy or execute a received plan; authoring, ranking,
rolling out, and learning that policy remain D when they are enterprise
responsibilities.

## Grandfathered OSS list

The following public surfaces are already Apache-2.0 and stay public. Their
classification is a statement of existing ownership, not permission to add
future private intelligence to the same directory.

### Class A: local Runtime

- Local context and execution: `rust/src/core/`, excluding the specific
  grandfathered reference-intelligence paths listed under Class C below;
  `rust/src/engine/`; `rust/src/server/`; `rust/src/tools/`;
  `rust/src/tool_defs/`; `rust/src/cli/`; and `rust/src/mcp_stdio.rs`.
- Local reads and safety: `rust/src/tools/ctx_read/`,
  `rust/src/core/structured_read.rs`, `rust/src/core/pathjail.rs`, and the
  related path, output, and redaction modules.
- Local shell: `rust/src/tools/ctx_shell.rs`, `rust/src/shell/`,
  `rust/src/shell_hook.rs`, and `rust/src/core/shell_allowlist/`.
- Local agent, editor, and setup integration: `rust/src/hooks/`,
  `rust/src/hook_handlers/`, `rust/src/ipc/`, `rust/src/daemon.rs`,
  `rust/src/daemon_client.rs`, and `rust/src/setup/`.
- Local BYOK execution edge: `rust/src/proxy/`,
  `rust/src/proxy_setup/`, `rust/src/core/http_client.rs`, and local config
  handling under `rust/src/core/config/`.
- Local memory, graph, context packages, and evidence primitives already
  released under `rust/src/core/memory_archive.rs`,
  `rust/src/core/memory_boundary.rs`, `rust/src/core/memory_policy.rs`,
  `rust/src/core/memory_scheduler/`, `rust/src/core/knowledge/`,
  `rust/src/core/context_package/`, `rust/src/core/context_snapshot/`, and
  their public CLI and server surfaces.
- Local savings and verification: `rust/src/core/savings_ledger/`,
  `rust/src/core/ocla/unified_ledger.rs`, `rust/src/core/evidence.rs`,
  `rust/src/core/evidence_bundle.rs`, and the existing local signing and
  verification modules.

### Class B: public protocols and SDKs

- Rust contract definitions and version registry:
  `rust/crates/lean-ctx-protocol/`, `rust/src/core/contracts.rs`,
  `rust/src/core/ocla/types.rs`, `rust/src/core/ocla/wire.rs`, and
  `rust/src/core/openapi.rs`.
- Public JSON Schema and contract portal: `docs/contracts/`, including
  `ocla-wire-v1.schema.json`, `ocla-agent-envelope-v1.schema.json`,
  `ocla-bus-event-v1.schema.json`, and
  `ocla-contract-pack-v1.json`.
- Public Protobuf and gRPC projection: `contracts/ocla/v1/ocla.proto` and
  `packages/ocla-grpc/`.
- Rust, Python, TypeScript, and Go client surfaces:
  `clients/rust/lean-ctx-client/`, `clients/python/leanctx/`,
  `python-sdk/`, `ts-sdk/`, and `go-sdk/`.
- Public contract checks and conformance fixtures:
  `scripts/validate-sdk-types.sh`, `scripts/check-sdk-versions.py`,
  `scripts/verify-ocla-contract-suite.py`, and the deterministic fixtures under
  `clients/rust/lean-ctx-client/tests/fixtures/`.

### Class C: public reference intelligence

The following implementations are public and remain Apache-2.0 as
reference/basic behavior. They are intelligence-frozen with respect to new
compounding learning:

- `rust/src/core/adaptive.rs`;
- `rust/src/core/adaptive_mode_policy.rs`;
- `rust/src/core/adaptive_thresholds.rs`;
- `rust/src/proxy/routing.rs`;
- `rust/src/proxy/model_router.rs`;
- `rust/src/core/learning_sync.rs`; and
- existing bounded OCLA and routing feedback implementations under
  `rust/src/core/ocla/` and `rust/src/proxy/`.

These paths may continue to provide deterministic tiers, local fallbacks,
bounded diagnostics, and compatibility behavior. New workload-trained
selection, organization-wide learning, or cross-customer ranking does not
enter them.

## Private-from-now list

New production code for the following capabilities goes into the private
Enterprise/Control Plane repository, not into the public Runtime repository:

- **Scheduler and decision intelligence:** candidate plan generation, joint
  context/capability/model/provider/reasoning selection, budget optimization,
  outcome-aware ranking, retry/fallback/stopping decisions, and learned
  scheduler weights.
- **Adaptive routing intelligence:** workload-specific model/provider choice,
  quality-cost-latency prediction, exploration/exploitation, and task-to-model
  performance models beyond the existing reference router.
- **Outcome and capability intelligence:** task fingerprints, accepted-outcome
  prediction, cross-task calibration, capability benchmarks, global rankings,
  and learned quality/cost frontiers.
- **Counterfactual and commercial economics:** baseline reconstruction,
  causal attribution, verified savings methodology, forecasting, margin
  optimization, supplier allocation, rate cards, billing, and settlement.
- **Governed organizational knowledge:** authority ranking, source-of-record
  reconciliation, ownership, supersession propagation, approval workflows,
  organization-wide retrieval policy, retention, and audit governance.
- **Fleet and enterprise control:** organization-wide agents, projects,
  budgets, quotas, workload priority, central identity, policy inheritance,
  regional/residency enforcement, SSO/SCIM, RBAC/ABAC, and enterprise
  administration.
- **Managed gateway and execution:** multi-tenant credential custody, central
  usage stores, chargeback, high availability, provider contract enforcement,
  managed inference, and enterprise-only operational services.
- **Private data systems:** stores and pipelines for Class E performance
  graphs, learned models, customer-derived task fingerprints, private
  benchmarks, supplier data, and commercial operational history.

Open protocol additions may describe these capabilities when an interoperable
contract, receipt, capability manifest, or verifier is valuable. The
implementation that makes the decision, learns from outcomes, or stores the
strategic data remains private.

## Deployment versus license

> **D code may run locally but requires enterprise license.**

This rule applies to air-gapped, on-premises, customer-VPC, sovereign, and
managed deployments. A local process is not automatically Class A, and an
Enterprise service is not automatically Cloud-only. The license follows the
Class D capability; the Runtime's protected Class A functions remain free.

Class D may communicate with Class A over the open contracts in Class B. Class
A does not import or depend on private D implementation code in the public
repository. A local deployment may bundle the two products operationally, but
the code and entitlement boundary remains explicit.

## Strategic-data handling

Class E values never appear in source, commits, pull requests, public issue
attachments, generated documentation, test snapshots, checked-in logs, or
contract fixtures. Public tests use deterministic synthetic values and test
the contract shape, not customer history or learned output.

Class E may be referenced by opaque IDs in Class B receipts when the receiving
system is authorized to resolve them. The reference does not move the data
into a repository and does not make the underlying data public. A task ID or
receipt ID must not encode Class E content.

## Approval and change control

The **Architecture/Product Owner** is the final approver for every A-E
classification. The owner approves the classification before implementation
begins and records it in the governing ADR, feature specification, or design
review. Security, legal, privacy, and data owners provide required review for
license, customer-data, or regulated-deployment implications, but they do not
silently change the architecture classification.

The review record identifies:

1. the class and the responsibility being classified;
2. the repositories and runtime deployment locations;
3. the data inputs and whether any Class E data is created or consumed;
4. the open contract boundary, if one is needed; and
5. the license and entitlement behavior.

Changing a Class A/B/C implementation into D, or changing the meaning of the
classes, requires a new accepted ADR. Existing Apache-2.0 code cannot be
reclassified retroactively. A disagreement defaults to preserving the public
Runtime and pausing the new intelligence implementation until the
Architecture/Product Owner records the decision.

## References

- `docs/adrs/ADR-010-oss-and-proprietary-contribution-boundary.md`
- `docs/adrs/ADR-014-open-runtime-invariant.md`
- `docs/contracts/local-free-invariant-v1.md` (grandfathered historical
  contract; deprecated for new decisions)
- `docs/contracts/oss-plane-separation-v1.md`
- `docs/contracts/pillar-boundaries-v1.md`
- `docs/internal/strategy/03_LEANCTX_OPEN_CORE_AND_COMMERCIAL_STRATEGY.md`
