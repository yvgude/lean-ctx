# Competition and Cooperation Strategy — Composable AI Efficiency

## Purpose

Define how LeanCTX works with adjacent products without surrendering its
category, product direction, customer relationship, or technical independence.

## Strategic thesis

LeanCTX should compete for the **Context Performance** layer while cooperating
at carefully chosen technical seams.

The winning position is not to implement every conceivable optimizer better
than every specialist. It is to make proven optimization capabilities
composable, measurable, selectable, and deployable for a specific workload.

```text
specialized capabilities + controlled measurement + workload-aware selection
                                  = Context Performance
```

RTK, Headroom, and Caveman can be competitors in some buying decisions and
capability providers in others. Those positions are not contradictory. Mature
infrastructure ecosystems routinely combine competition with interoperability:
AWS and MongoDB, Cloudflare and other CDNs, Kubernetes and container runtimes.

LeanCTX owns the decision loop:

1. Identify candidate strategies.
2. Test them against the actual workload and a quality gate.
3. Select the winning configuration.
4. Version and deploy the resulting Performance Profile.
5. Re-evaluate when the workload, model, or provider behavior drifts.

The competitive advantage is selection intelligence backed by evidence—not a
claim that every LeanCTX-native transformation is always the best one.

## Why blind stacking fails

Combining every optimizer by default is not a strategy. It often makes the
system worse.

- One transformation can destroy the stable prompt prefix another layer needs
  for provider-cache reuse.
- Multiple lossy transformations can compound omissions, formatting damage, or
  semantic drift.
- Sequential remote calls add latency, failure modes, observability gaps, and
  operational complexity.
- An optimizer designed for one representation can degrade the quality of a
  downstream optimizer or the model's task completion.
- A token reduction without a quality or completion result is not a win.

Composition is an outcome to prove, not an architecture to assume. If a
workload is best served by one provider—or stock behavior—LeanCTX must select
that outcome rather than manufacture a multi-layer pipeline.

## The operating model: select the right optimization

For each workload, LeanCTX evaluates viable strategies under a shared
measurement protocol. The chosen strategy can be stock behavior, a LeanCTX
native capability, an external provider, or a compatible composition.

The selection decision considers:

- task quality and completion against a declared gate;
- input tokens, cached tokens, output tokens, and calculated cost;
- end-to-end latency and provider-specific latency;
- cache behavior and prompt-prefix stability;
- reliability, compatibility, policy requirements, and reversibility.

The output is a versioned Performance Profile: a reproducible specification of
the workload, quality gate, selected capability chain, measurements, and
rollout constraints. The profile is the deployable product artifact; any one
optimizer is replaceable.

## RTK partnership experiment

RTK is the first partnership experiment because a conversation already exists,
the products have both overlap and specialization, and the cooperation thesis
can be tested without a broad commercial agreement.

### Experiment design

Use one fixed workload and run four arms:

```text
same workload
same model and model configuration
same source corpus / tool fixtures
same quality gate
same measurement method

Arm A — Stock:         no context-performance optimization
Arm B — RTK:           RTK configuration only
Arm C — LeanCTX:       LeanCTX configuration only
Arm D — RTK + LeanCTX: explicitly defined composition order
```

Record provider input, cached input, output, calculated cost, latency, quality,
task completion, error rate, and configuration version. Keep the composition
order explicit; `RTK + LeanCTX` is not a meaningful result if it cannot be
reproduced.

The quality gate comes first. Token or cost improvements count only when an arm
meets the same task-quality and completion threshold as the baseline.

### What a win looks like

Arm D is a composition win when it passes the quality gate and adds material
value beyond the strongest single-arm result—for example, lower cost or latency
without a quality regression, better completion at comparable cost, or stronger
cache reuse with comparable completion.

That validates a narrow claim: this compatible combination improves this
declared workload under this protocol. It does not establish a universal
ordering, an exclusive relationship, or a platform endorsement.

### What a loss looks like

If Arm D loses to LeanCTX alone, RTK alone, or stock behavior, the experiment
still succeeds strategically. It proves that blind stacking is wrong and that
the selection layer must choose rather than merely aggregate capabilities.

- Arm C wins: select LeanCTX-native behavior for this workload.
- Arm B wins: record RTK as the strongest available strategy for this workload
  if integration and commercial terms are appropriate.
- Arm A wins: avoid unnecessary transformation and preserve the stock path.
- Arm D fails the gate: make the incompatibility observable and do not deploy
  the composition.

In every case LeanCTX's job is to produce the right evidence-backed decision.

## Suggested next conversation with RTK

Use a technical, bounded, non-promotional ask:

> We see RTK as both an adjacent product and a possible specialized capability
> in a composable Context Performance stack. We are not asking for an
> endorsement, exclusivity, or a marketplace commitment. Would you be open to
> a small, reproducible evaluation on one agreed workload?
>
> We would hold the workload, model, fixtures, quality gate, and measurement
> method constant across stock, RTK, LeanCTX, and an explicitly ordered
> RTK-plus-LeanCTX arm. The question is simple: does composition add value over
> the best individual approach without sacrificing task quality?
>
> We would share the protocol and raw result summary with you. Any external
> technical case study, integration announcement, or quote would require both
> sides' explicit approval. If the combined arm loses, that is useful too: it
> tells the selector not to stack the tools for that workload.
>
> If this narrow experiment is useful, the next step is to agree on a workload,
> a quality gate, and the minimal configuration needed to reproduce each arm.

The immediate goal is a developer-level experiment. Do not lead with a
partnership announcement, reseller framing, marketplace listing, or claims
about a joint roadmap.

## Interoperability boundary: `OptimizationProvider`

`OptimizationProvider` is a proposed adapter contract, not a marketplace or a
promise that every vendor will be integrated. It creates a narrow boundary
between LeanCTX's selection/runtime responsibility and a provider's specialized
transformation.

```text
OptimizationProvider
  identity() -> name, version, licensing, support boundary
  capabilities() -> supported workloads, representations, constraints
  eligible(workload, policy) -> eligible | reason
  optimize(request) -> payload, cache semantics, estimates, provenance
  health() -> availability, compatibility, degradation signals
  evidence() -> configuration identity and reproducibility metadata
```

Contract requirements:

- Request and response schemas declare what may change; providers do not
  silently alter model choice, policy, tool permissions, or quality gates.
- Cache semantics are explicit, including whether a transformation changes a
  reusable prefix or inserts volatile data.
- Every run is attributable to provider and configuration versions so results
  can be reproduced and a provider can be removed cleanly.
- LeanCTX retains final eligibility, ordering, selection, rollout, and rollback
  decisions.
- Provider telemetry is opt-in, minimised, and subject to customer policy;
  cross-customer learning is never assumed.
- An integration must fail safely: provider degradation can fall back to the
  profile's approved alternative rather than trapping the workload.

This boundary keeps integrations reversible and lets LeanCTX compare native and
external candidates on the same evidence model.

## Later candidates

### Headroom

If the RTK experiment demonstrates value in a compatible seam, Headroom is a
later candidate for a bounded compression-provider evaluation. Its "compress
everything" posture is a useful capability hypothesis, not a universal default.
LeanCTX would test where that compression preserves task quality, improves the
relevant cost or latency metric, and does not destroy cache value or a stronger
representation strategy.

The test is especially useful where LeanCTX's selection logic may determine
that compression is appropriate for one workload but cache-preserving reuse,
retrieval refinement, or structured representation is better for another.

### Caveman

Caveman is a later candidate only after there is evidence that the RTK
interoperability seam works. Its broader efficiency framing may offer a useful
specialized capability or evidence/benchmark seam, but LeanCTX does not absorb
its product category or make its stack a prerequisite.

Any Caveman experiment must isolate a single context-performance hypothesis,
use the same controlled-arm protocol, and preserve LeanCTX's ownership of
context strategy selection. Broader spend, routing, governance, or platform
claims are outside this strategy unless separately justified.

## Non-negotiables

We never:

- make LeanCTX dependent on a partner for a core workload or customer outcome;
- represent an exploratory adapter as an endorsed, certified, or exclusive
  relationship;
- promise a marketplace, partner program, joint roadmap, or platform before it
  exists and has the necessary technical, legal, and commercial approval;
- route customer workloads to a partner by default without a measured profile,
  clear policy, and a reversible fallback;
- share customer data, benchmark details, or cross-customer intelligence
  without explicit consent and an appropriate privacy boundary;
- let partner marketing override a failed quality gate or a better measured
  configuration.

## PR and community story: Composable AI efficiency

The community narrative is **Composable AI efficiency**:

> AI efficiency should not force teams to choose one monolithic optimizer.
> LeanCTX makes compatible capabilities testable on the same workload, selects
> the configuration that meets the quality gate, and preserves a reproducible
> Performance Profile.

Tell this story with evidence:

- publish contracts, benchmark protocol, and reproducibility expectations where
  appropriate;
- describe tested outcomes by workload and quality gate, not as universal
  leaderboards;
- welcome native, customer-built, open-source, commercial, and provider-native
  capabilities that meet the boundary;
- make clear that more capability supply improves LeanCTX only when it produces
  more trustworthy evidence and better selection.

The long-term flywheel is not "more plugins." It is more verified
capability/workload evidence, which improves selection, which improves
Performance Profiles and production outcomes.

## Decision rule

Advance from the RTK experiment to another provider only when the result,
technical compatibility, legal posture, commercial rationale, and customer
demand justify the next step. Otherwise, retain the experiment as selection
evidence and keep the product boundary unchanged.
