# LeanCTX Internal Documentation

> **Single Source of Truth** für Strategie, Architektur und Umsetzung.
>
> ⚠️ VERTRAULICH — Dieses Verzeichnis ist gitignored.
>
> 🎯 **Status: Phase 0–8 COMPLETE** (Stand 2026-08-09)

---

## Struktur

```
docs/internal/
├── README.md                         ← Du bist hier (Einstiegspunkt)
├── PROGRESS.md                       ← Sprint-Tracking + Quality Gates
├── OPEN_CORE_BOUNDARY.md             ← Bindende A-E Klassifikation
│
├── architecture/
│   ├── CODEBASE_MAP.md               ← Komplette Modul-Architektur (NEU)
│   ├── VISION_IMPLEMENTATION.md      ← Vision → Code Mapping (NEU)
│   ├── IST_ZUSTAND.md               ← Aktueller Zustand (Repos, Server, Infra)
│   ├── GAP_MATRIX.md                ← IST vs TO-BE (Phase 0–8 jetzt umgesetzt)
│   ├── SECURITY_ARCHITECTURE.md      ← Security + Trust Architecture
│   └── adrs/                         ← Architecture Decision Records (8 ADRs)
│
├── roadmap/
│   └── IMPLEMENTATION_PLAN.md        ← 14-Phasen Plan (Phase 0–8 done, 9–13 future)
│
├── strategy/
│   ├── 01_STRATEGIC_MASTERPLAN.md    ← Gesamtstrategie + North Star
│   └── 03_OPEN_CORE_STRATEGY.md      ← Open-Core A-E Klassifikation
│
├── contracts/
│   └── 07_CONTRACTS_AND_GLOSSARY.md  ← Canonical Contracts + Glossar
│
├── competitive/
│   └── 04_COMPETITIVE_RESEARCH.md    ← Wettbewerbsanalyse
│
├── positioning/
│   └── 05_README_AND_WEBSITE.md      ← GitHub/Website Positionierung
│
├── integrations/
│   └── rtk-evaluation.md            ← RTK External Capability Evaluation
│
└── source/                           ← Original Planning Pack (Referenz, nicht editieren)
```

---

## Quick Links

| Frage | Dokument |
|---|---|
| **Wo stehen wir?** | `PROGRESS.md` |
| **Wie ist der Code strukturiert?** | `architecture/CODEBASE_MAP.md` |
| **Ist die Vision umgesetzt?** | `architecture/VISION_IMPLEMENTATION.md` |
| **Was ist Open vs Closed?** | `OPEN_CORE_BOUNDARY.md` |
| **Wie ist die Sicherheitsarchitektur?** | `architecture/SECURITY_ARCHITECTURE.md` |
| **Was ist der Gesamtplan?** | `roadmap/IMPLEMENTATION_PLAN.md` |
| **Warum diese Architektur?** | `architecture/adrs/` |
| **Gegen wen konkurrieren wir?** | `competitive/04_COMPETITIVE_RESEARCH.md` |

---

## North Star

> **"Cost per Accepted Outcome"** — LeanCTX misst nicht Tokens, sondern was ein
> verifiziertes, akzeptiertes Ergebnis kostet. Der Control Plane optimiert diesen Wert.

---

## Kern-Contracts (IMPLEMENTIERT ✅)

| # | Contract | Rust Crate | Status |
|---|---|---|---|
| 1 | `TaskEnvelopeV1` | `lean-ctx-protocol::task` | ✅ |
| 2 | `ExecutionPlanV1` | `lean-ctx-protocol::execution` | ✅ |
| 3 | `ExecutionReceiptV1` | `lean-ctx-protocol::execution` | ✅ |
| 4 | `AcceptedOutcomeV1` | `lean-ctx-protocol::outcome` | ✅ |
| 5 | `CapabilityManifestV1` | `lean-ctx-protocol::capability` | ✅ |
| 6 | `DecisionRecordV1` | `lean-ctx-protocol::decision` | ✅ |
| 7 | `KnowledgeObjectV1` | `lean-ctx-protocol::knowledge` | ✅ |

---

## Quality Metrics (aktuell)

| Repo | Tests | Clippy | Check |
|---|---|---|---|
| OSS (`lean-ctx`) | 9862 ✅ | 0 warnings | 0 errors |
| Enterprise (`lean-ctx-enterprise`) | 47 ✅ | 0 warnings | 0 errors |

---

## Conventions

- IST = Was heute existiert und funktioniert
- TO-BE = Zielzustand gemäss Strategic Masterplan (Phase 0–8 = IST)
- `source/` = Unveränderte Quelldateien (nur lesen, nicht editieren)
- ADRs nummerieren: `ADR-NNN-SLUG.md`
- Bei Änderungen: Datum im Dokument aktualisieren
- Phase 9–13 = Zukunft (nicht vor Q1 2027)
