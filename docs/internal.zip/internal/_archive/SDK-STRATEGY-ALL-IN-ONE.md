# LeanCTX Context SDK Strategy — Complete Bundle

**Generated:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX  
**Thesis:** The Context SDK for AI Agents.  
**Promise:** Tune any agent. Prove every gain.


---

<!-- SOURCE FILE: 00-VISION-AND-FOCUS.md -->

# 00 — Vision and Focus

## 1. Category

> # LeanCTX  
> ## The Context SDK for AI Agents.

This is the proposed public category because it is:
- understandable to developers,
- close to what the codebase already supports,
- compatible with coding-agent adoption,
- compatible with custom-agent integration,
- broad enough for future context infrastructure,
- narrow enough to avoid generic agent-platform scope.

The SDK descriptor is the **surface**. The Runtime is the engine underneath.

---

## 2. Product promise

> **Tune any agent. Prove every gain.**

Supporting lines:
- **Don't replace your agent. Tune it.**
- **Context is performance.**
- **No savings claim without a baseline.**
- **Performance you can version.**

Do not use all of them at once.

---

## 3. Mission

Make AI agents use the **minimum sufficient context** required to produce an accepted outcome.

LeanCTX optimizes:
- what context is retrieved,
- what is selected,
- what representation is used,
- what is reused,
- what stays exact,
- what can be compressed,
- what can be referenced instead of resent,
- what can be recovered later,
- how much context the task may consume,
- and how those decisions affect cost, latency and quality.

---

## 4. Internal mental model: the agent tuner

The "chiptuner" analogy is strategically useful.

| Performance engineering | AI agent |
|---|---|
| Engine | Foundation model |
| Vehicle | Agent |
| ECU map | Context strategy |
| Fuel | Tokens / compute |
| Telemetry | Usage / latency / quality |
| Dyno | Controlled benchmark |
| Tuning profile | Versioned context configuration |
| Tuner | LeanCTX |
| Fleet operation | Thinkery organizational layer |

The analogy should guide product thinking.

It should **not** become literal automotive branding.

---

## 5. The shift from compression to context performance

A pure compressor receives context that already exists and shrinks it.

A context-performance system can decide whether that context should exist in the active context at all.

```text
NAIVE AGENT
task
 ↓
find everything
 ↓
read everything
 ↓
grep everything
 ↓
keep history
 ↓
model

LEANCTX-NATIVE
task
 ↓
understand context need
 ↓
select relevant source
 ↓
choose fidelity
 ↓
reuse existing state
 ↓
apply budget
 ↓
preserve recovery reference
 ↓
model
```

This is **Context Planning**.

Compression remains one powerful strategy inside it.

---

## 6. North-star metric

> **Verified cost per successful agent task**

Why not token reduction alone?
- cheaper tokens can still produce failed work,
- a larger model can sometimes reduce total retries,
- caching changes economics,
- context removal can damage quality,
- a task can be cheaper because it succeeds faster rather than because it uses fewer input tokens.

Supporting metrics:
- input tokens per accepted task,
- provider cost per accepted task,
- quality acceptance,
- latency,
- reuse rate,
- recovery rate,
- percentage of runs with verifiable evidence.

---

## 7. What LeanCTX owns

LeanCTX owns the context lifecycle:

```text
Task
 ↓
Context need
 ↓
Candidates
 ↓
Selection
 ↓
Representation
 ↓
Reuse
 ↓
Compression
 ↓
Recovery
 ↓
Execution
 ↓
Usage
 ↓
Outcome
 ↓
Receipt
```

LeanCTX does **not** need to own:
- generic workflow orchestration,
- CRM workflows,
- voice agents,
- browser automation,
- agent-building canvases,
- every tool integration,
- foundation models.

---

## 8. Current wedge and expansion

### NOW
Coding-agent context efficiency and verified savings.

### NEXT
Context SDK ergonomics, Dyno, receipts, Tuning Profiles, first-class Kits.

### THEN
Team history, private Profiles/Kits, shared evidence, organization economics.

### LATER
AutoTune, enterprise policy, fleet-level context performance.

### OPTIONAL LATER
Managed relay and managed execution.

The architecture may prepare for later layers before they are marketed.

---

## 9. Core product loop

```text
CONNECT → MEASURE → TUNE → PROVE → DEPLOY → REPEAT
```

### Connect
Add LeanCTX to an existing agent.

### Measure
Observe context, usage, cost and outcome.

### Tune
Change the context strategy.

### Prove
Compare against controlled baseline.

### Deploy
Version the winning profile.

### Repeat
Retune when model, workload or code changes.

This loop is the center of the company.

---

## 10. Focus rules

A feature is eligible only if it answers:

1. Which context problem does it solve?
2. Which user feels the problem?
3. Which measurable outcome changes?
4. Does it belong to Connect, Measure, Tune, Prove, Deploy or Repeat?
5. Is it required for one developer locally or an organization at scale?
6. What existing work stops if we build it?

If these cannot be answered, park it.

---

## 11. Operating principles

1. Proof before promise.
2. Outcome before category.
3. Context before breadth.
4. SDK before platform.
5. Developer trust before monetization tricks.
6. Quality beside savings.
7. Pull before expansion.
8. One canonical measurement path.
9. One canonical evidence path.
10. Open interoperability; proprietary compounding intelligence.
11. Do not let competitors write the roadmap.
12. Build the smallest product that proves the next commercial truth.

---

## 12. 2026 strategic objective

The company does not need to prove the entire long-term platform.

It needs to prove:

1. LeanCTX changes the economics of a real agent.
2. Quality remains within an accepted threshold.
3. The change is reproducible and evidenced.
4. A customer pays for it.
5. The result can be repeated on a second workflow/customer.

Everything else is secondary.


---

<!-- SOURCE FILE: 01-PRODUCT-ARCHITECTURE.md -->

# 01 — Product Architecture

## 1. Complete product stack

```text
                         THINKERY AG
                     company / commercial
                              │
                              ▼
                           LEANCTX
                 The Context SDK for AI Agents
                              │
          ┌───────────────────┼───────────────────┐
          │                   │                   │
        ATTACH               WRAP                EMBED
       MCP/Proxy          Adapters/SDK         Native SDK
          │                   │                   │
          └───────────────────┼───────────────────┘
                              ▼
                       LEANCTX RUNTIME
            ┌─────────────────┼─────────────────┐
            │                 │                 │
      CONTEXT ENGINE      CONTEXT ASSETS       EVIDENCE
            │                 │                 │
        selection          Kits/Profile       Receipt
        compression        memory             quality
        reuse              knowledge          economics
        recovery                               provenance
                              │
                              ▼
                       Agent execution
                              │
                              ▼
                        Model + tools
```

Later, Thinkery can add a `RUN` integration depth for managed execution.

---

## 2. The minimum product object model

### `LeanCTX`
Top-level developer client/configuration.

### `ContextSession`
One bounded context lifecycle for a task.

### `TuningProfile`
Versioned configuration describing how the agent consumes context.

### `ContextKit`
Versioned reusable context capability.

### `ExecutionReceipt`
Record of one run.

### `SavingsReceipt`
Controlled baseline/treatment comparison.

### `EvidenceBundle`
Portable verifiable proof.

---

## 3. `ContextSession`

This should become the central SDK primitive.

Identity:
- task_id,
- run_id,
- agent_id,
- project_id,
- optional workspace_id.

State:
- task,
- context already seen,
- active context,
- loaded Kits,
- active Tuning Profile,
- budgets,
- provider/model,
- recovery references.

Events:
- retrieve,
- select,
- compress,
- reuse,
- recover,
- tool response,
- model call,
- quality result,
- complete.

The exact schema must be validated against current Runtime architecture before freezing.

---

## 4. Context Engine

Capabilities can include:
- tree / structure,
- outlines,
- symbol search,
- targeted reads,
- semantic retrieval,
- compression,
- shell/tool output shaping,
- caching,
- change-aware reuse,
- local project knowledge,
- cross-agent reuse,
- recovery.

The product should not expose all capabilities as equal-level mental primitives.

Low-level features are the toolbox.

SDK abstractions are the product.

---

## 5. Context Planning

The highest-value native behavior is likely to be **planning context before materialization**.

A plan can choose:
- no retrieval,
- metadata only,
- tree,
- outline,
- diff,
- selected symbols,
- exact lines,
- memory,
- Kit knowledge,
- full content.

The objective is not "compress as much as possible."

The objective is:
> deliver sufficient context for the task at the best verified cost/quality point.

---

## 6. Tuning Profile

A Profile makes a context strategy:
- reproducible,
- versioned,
- deployable,
- rollbackable,
- comparable.

Example conceptual profile:

```yaml
name: payments-review
version: 1.4.2

context:
  budget_tokens: 64000
  read_strategy: outline-first
  search_limit: 12
  reuse_threshold: 0.85
  compression: balanced
  recovery: true

kits:
  - payments-security@2.1

quality:
  gates:
    - tests-pass
    - reviewer-score>=0.92
```

---

## 7. Context Kit

A Kit describes reusable context capability.

It should build on `.ctxpkg`, not introduce a parallel package system.

Potential semantic fields:
- identity/version,
- publisher/license,
- knowledge,
- procedures,
- rules,
- patterns,
- gotchas,
- activation,
- compatibility,
- evaluation,
- provenance,
- permissions.

A receipt should record the exact Kit version/hash used.

---

## 8. Receipt architecture

```text
Task
 ↓
ContextEnvelope
 ↓
Execution
 ↓
ExecutionReceipt
 ↓
Quality result
 ↓
SavingsReceipt
 ↓
EvidenceBundle
```

Dashboards render these records.

Dashboards must not invent a second calculation truth.

---

## 9. Commercial organization layer

Thinkery can add:
- accounts/workspaces,
- private Profiles,
- private Kit registry,
- hosted Dyno,
- continuous AutoTune,
- shared evidence,
- organization economics,
- policy,
- SSO/RBAC,
- audit/retention,
- self-hosted/VPC operation.

This layer is not required to make local LeanCTX useful.

---

## 10. Product progression

```text
Developer
 ↓
local LeanCTX
 ↓
Dyno
 ↓
Tuning Profile
 ↓
Pro
 ↓
Team
 ↓
private assets + shared evidence
 ↓
Enterprise
 ↓
policy / fleet economics / self-hosted
```

One funnel, not unrelated products.


---

<!-- SOURCE FILE: 02-SDK-RUNTIME-INTEGRATIONS.md -->

# 02 — SDK, Runtime and Integrations

## 1. Architectural decision

LeanCTX is publicly understood as an SDK.

Technically:

```text
Language SDK / Adapter
        │
        ▼
stable LeanCTX contracts
        │
        ▼
LeanCTX Runtime
        │
        ▼
filesystem / tools / model traffic / evidence
```

Do not reimplement the context engine in every language.

---

## 2. Runtime responsibilities

The Runtime owns:
- safe project filesystem access,
- structural code understanding,
- search,
- bounded reads,
- context selection,
- compression,
- reuse/cache,
- local memory,
- recovery,
- package/Kit loading,
- usage accounting,
- local evidence,
- local policy/safety gates,
- optional execution under explicit permission.

---

## 3. SDK responsibilities

The SDK provides ergonomics:
- Runtime connection,
- `ContextSession`,
- typed envelopes/receipts,
- Profile loading,
- Kit loading,
- adapters,
- language-native errors,
- async ergonomics.

SDKs should use stable shared contracts.

---

## 4. North-star API

This is **conceptual**, not a current API promise.

```python
from leanctx import LeanCTX

ctx = LeanCTX(project=".")

session = ctx.session(
    task="Review PR #482",
    profile="balanced"
)

context = session.prepare()

result = my_agent.run(
    task="Review PR #482",
    context=context
)

receipt = session.receipt(
    outcome=result,
    accepted=True
)
```

Wrapper mode:

```python
ctx = LeanCTX(project=".")
agent = ctx.wrap(existing_agent)

result = agent.run("Review the payments module")
print(result.leanctx.receipt)
```

Kit:

```python
ctx.load_kit("secure-code-review")
```

Profile:

```python
ctx.load_profile("payments-review@1.4.2")
```

---

## 5. Integration taxonomy

# ATTACH

Zero/near-zero code.

Mechanisms:
- MCP,
- local proxy,
- provider-compatible proxy,
- supported hooks/config.

Targets:
- Claude Code,
- Codex,
- Cursor.

Target UX:

```bash
lean-ctx connect claude
lean-ctx doctor
lean-ctx dyno
```

Equivalent for Codex/Cursor.

---

# WRAP

Framework/client adapter.

Target north-star:

```python
agent = leanctx.wrap(agent)
```

Candidate adapters, only when demanded:
1. OpenAI Agents SDK
2. Claude Agent SDK
3. LangGraph
4. Vercel AI SDK
5. LiteLLM

Adapter hooks should observe:
- task start/end,
- model calls,
- tool calls,
- tool responses,
- usage,
- memory/history,
- outcome.

---

# EMBED

Native Context SDK inside custom agent loop.

This is where LeanCTX can influence **whether and how context is fetched**, not only compress it after the fact.

Best for:
- custom enterprise agents,
- high-volume workflows,
- regulated agents,
- internal product agents.

---

# RUN — LATER

Managed execution.

```text
ExecutionProvider
├── CustomerLocal
├── CustomerKubernetes
├── PartnerRuntime
└── ThinkeryManaged
```

The customer keeps the agent logic.

Thinkery operates the tuned runtime environment.

Do not build a generic agent builder.

---

## 6. Integration Depth Benchmark

Strategic experiment:

```text
A — Stock
B — Attach
C — Embed
```

Controls:
- same task,
- same repository revision,
- same model/provider,
- same budget,
- same quality contract.

Measure:
- provider input tokens,
- cached tokens,
- output tokens,
- calculated cost,
- latency,
- tool calls,
- bytes/context read,
- recovery,
- task completion,
- tests,
- evaluator,
- human correction.

Hypothesis:
> deeper integration can produce a better cost/quality frontier because LeanCTX can plan context earlier.

This must be proven rather than assumed.

---

## 7. Coding-agent focus

First-class support:

1. Claude Code
2. Codex
3. Cursor
4. one reference custom Python/TypeScript agent

Each supported integration requires:
- connect,
- doctor,
- smoke test,
- Dyno,
- receipt,
- uninstall,
- known limitations.

Do not build twenty integrations before these are excellent.

---

## 8. Conformance

Every language SDK/adaptor should share fixture tests for:
- contract serialization,
- Runtime handshake,
- context request,
- error mapping,
- receipt retrieval,
- Profile load,
- Kit load,
- recovery,
- unsupported-version handling.

---

## 9. Success condition

A supported developer should be able to:

1. install LeanCTX,
2. connect or embed it,
3. run a real task,
4. get a receipt,
5. understand the before/after,

in a target of **under 15 minutes**.

They should not need to understand the complete internal tool inventory.


---

<!-- SOURCE FILE: 03-DYNO-EVIDENCE-AUTOTUNE.md -->

# 03 — Dyno, Evidence and AutoTune

## 1. LeanCTX Dyno

> **LeanCTX Dyno is the controlled benchmarking and tuning environment for AI agents.**

It runs the same workload under one or more context strategies and compares:
- context usage,
- provider-reported usage,
- calculated cost,
- latency,
- quality,
- task completion.

Dyno is strategically powerful because it is simultaneously:
- product,
- proof,
- playground,
- lead generator,
- enterprise business-case generator,
- foundation for AutoTune.

---

## 2. Current evidence foundation

The August 2026 `lean-ctx evidence realworld` experiment already demonstrates the basic shape:

- real OpenAI API calls,
- baseline and treatment,
- five accumulating turns,
- coding-agent-like sequence:
  1. project structure,
  2. source reads,
  3. symbol search,
  4. test output,
  5. final analysis,
- provider-reported prompt tokens,
- cached tokens,
- completion tokens,
- cache-aware cost calculation.

Observed in the founder's described runs:

| Scenario | Baseline tokens | Treatment tokens | Token reduction | Calculated cost reduction |
|---|---:|---:|---:|---:|
| Small | 99,203 | 14,857 | 85.0% | 78.9% |
| Medium | 139,115 | 14,016 | 89.9% | 84.3% |
| Large | 132,637 | 11,897 | 91.0% | 86.0% |

These are **workload-specific experimental results**, not a universal product promise.

The strongest next improvement is a canonical quality gate in the same run.

---

## 3. Dyno run

Proposed structure:

```yaml
dyno_run:
  id: dyno_...
  workload:
    id: payment_review_v1
    source_revision: ...
  agent:
    adapter: custom-python
    version: ...
  provider:
    name: openai
    model: ...
  controls:
    max_cost: ...
    timeout: ...
  arms:
    - id: stock
    - id: attach
      profile: balanced
    - id: native
      profile: balanced
  quality:
    evaluator: ...
    threshold: ...
```

---

## 4. Anti-cheating rules

A credible Dyno must enforce:
- same task,
- same model unless model is the intentional variable,
- same source revision,
- same timeout/budget,
- no hidden pre-generated findings,
- report caching,
- report retries,
- report failed arms,
- no smoothing,
- no synthetic data presented as real,
- no savings win without quality.

---

## 5. Canonical evidence pipeline

```text
Task
 ↓
ContextEnvelope
 ↓
Execution
 ↓
ExecutionReceipt
 ↓
Quality result
 ↓
SavingsReceipt
 ↓
EvidenceBundle
 ↓
Verifier
```

All dashboards and reports are views over these records.

---

## 6. `ExecutionReceiptV1`

Proposed fields:

### Identity
- run_id
- task_id
- agent_id
- project/workspace
- trace_id

### Execution
- provider
- model
- timestamps
- latency
- tool calls
- retries

### Context
- Tuning Profile id/version
- Kit id/version/hash
- provider prompt usage
- cached usage
- output usage
- recovery events
- context source digests

### Economics
- pricing-table version
- calculated provider cost
- baseline reference where applicable

### Outcome
- task completion
- quality gates
- evaluator output
- human acceptance if used

### Evidence
- methodology version
- signature
- key id

---

## 7. Provider usage vs cost

Always separate:

### Provider-reported usage
Observed from API response.

### Calculated provider cost
Usage × versioned published price table.

### Reconciled invoice cost
Only when matched to actual billing.

Never call calculated cost "provider billed cost" unless it has been reconciled.

---

## 8. Quality

A savings result counts only if treatment satisfies the declared quality contract.

Examples:

### Coding
- build/compile,
- tests,
- task completion,
- reviewer score,
- diff correctness.

### Research
- factual accuracy,
- source quality,
- citation completeness.

### Support
- resolution,
- escalation,
- acceptance.

### Regulated
- policy compliance,
- evidence completeness,
- required human approval.

There is no one universal evaluator.

---

## 9. Local Dyno

Open/local functionality:
- run,
- compare,
- report,
- profile experiment,
- signed receipt.

Target commands:

```bash
lean-ctx dyno run
lean-ctx dyno compare
lean-ctx dyno report
```

Existing benchmark/evidence paths should converge rather than permanently fork.

---

## 10. Hosted Dyno

Commercial capabilities:
- history,
- scheduled runs,
- parallel candidates,
- larger benchmark matrices,
- private workload fixtures,
- private Profile registry,
- shareable reports,
- team comparison,
- AutoTune.

---

# AutoTune

## 11. Product definition

> **AutoTune finds a better Tuning Profile automatically for a representative workload.**

Candidate variables:
- context budget,
- read strategy,
- retrieval depth,
- reuse threshold,
- compression strategy,
- recovery behavior,
- tool output shaping,
- Kit selection,
- model selection when allowed,
- retry/fallback policy when allowed.

---

## 12. Optimization objective

Example:

```text
minimize:
  expected cost
  + latency penalty

subject to:
  quality >= accepted threshold
  policy == pass
  evidence completeness >= required level
```

The objective is workload-specific.

---

## 13. AutoTune loop

```text
Representative workload
        ↓
Generate candidate Profiles
        ↓
Run Dyno
        ↓
Evaluate quality
        ↓
Evaluate economics
        ↓
Build Pareto frontier
        ↓
Recommend Profile
        ↓
Human approval
        ↓
Deploy
        ↓
Observe drift
        ↓
Retune
```

---

## 14. Why AutoTune is commercial

Open LeanCTX can expose the engine and tuning knobs.

Commercial value compounds in:
- profile search,
- workload-specific ranking,
- continuous retuning,
- drift detection,
- outcome prediction,
- organization history,
- benchmark scale.

Clean rule:

> **Manual tuning is open. Continuous tuning is commercial.**

---

## 15. Tuning Profile

A Profile makes performance reproducible.

Proposed `TuningProfileV1`:

```yaml
api_version: leanctx/v1
kind: TuningProfile

metadata:
  name: payments-review
  version: 1.4.2

context:
  budget_tokens: 64000
  read_strategy: outline-first
  search_limit: 12
  reuse_threshold: 0.85
  compression: balanced
  recovery: enabled

kits:
  - payments-security@2.1

quality:
  gates:
    - tests-pass
    - review-score>=0.92
```

The exact schema is not frozen until the reference agent and Dyno validate it.

---

## 16. Profile lifecycle

Local/open:
- create,
- validate,
- load,
- export,
- compare,
- pin,
- rollback.

Commercial:
- private registry,
- promotion dev → staging → prod,
- organization defaults,
- benchmark history,
- recommendation,
- drift monitoring,
- AutoTune.

---

## 17. Evidence as a moat

A one-off compressor is copyable.

A loop that learns:

```text
workload
→ context strategy
→ result
→ evidence
→ better profile
```

can compound.

That is the long-term tuning moat.


---

<!-- SOURCE FILE: 04-OSS-PAID-MONETIZATION.md -->

# 04 — OSS, Paid Boundary and Monetization

## 1. Strategic principle

Do not weaken LeanCTX OSS out of fear.

Existing public capability is distribution capital.

The commercial boundary should move **forward** into compounding intelligence and organization-scale operation.

> **The execution edge stays open. The tuning brain compounds commercially.**

Also:

> **Deployment location is not a licensing model.**

A proprietary enterprise capability may run in a customer VPC or on-prem without becoming open source.

---

## 2. What stays OSS

A developer should be able to build and tune a genuinely strong local agent for free.

Keep open:
- local Context Runtime,
- core SDK access/contracts,
- Claude Code/Codex/Cursor integrations required for adoption,
- MCP,
- local proxy,
- structural reads,
- local compression,
- local selection,
- reuse/cache,
- local memory primitives already public,
- recovery,
- `.ctxpkg`,
- Context Kit specification/loader/verifier,
- local Tuning Profiles,
- local Dyno,
- local receipts,
- evidence verifier,
- open capability contracts,
- local diagnostics.

The OSS experience must not feel like a crippled demo.

---

## 3. What becomes commercial

### Continuous intelligence
- AutoTune,
- profile search,
- workload-specific profile ranking,
- outcome prediction,
- drift detection,
- continuous retuning,
- cross-task performance models.

### Team/organization
- shared projects,
- private Profiles,
- private Kits,
- central evidence,
- organization economics,
- team defaults,
- shared history.

### Enterprise
- SSO/SCIM,
- RBAC,
- central policy,
- retention,
- audit workflows,
- self-hosted/VPC support,
- enterprise connectors,
- SLAs,
- approvals.

### Managed infrastructure
- hosted Dyno,
- managed relay,
- managed provider credentials,
- optional unified billing,
- later managed execution.

### Strategic data
- private benchmark corpora,
- task/profile performance graph,
- provider commercial intelligence,
- learned ranking models.

---

## 4. Customer-facing rule

> **One developer can tune locally with LeanCTX OSS.  
> Organizations pay Thinkery to continuously tune, share, control and govern agents at scale.**

---

## 5. Feature classification

Every meaningful feature gets classified before code starts.

### A — OSS Runtime
Needed for strong local developer experience.

### B — Open Contract
Interface/format whose openness creates trust and interoperability.

### C — Public reference / intelligence freeze
Already-public intelligence remains supported; compounding future sophistication goes commercial.

### D — Proprietary system
Organization-scale decisioning, learning, governance, managed economics.

### E — Strategic data
Private workload data, rankings, commercial rates, learned weights.

No classification → no implementation.

---

# Monetization

## 6. Revenue ladder

```text
OSS
 ↓
Pro
 ↓
Team
 ↓
Agent Tuning Sprint
 ↓
Business / Enterprise
 ↓
AutoTune usage
 ↓
Managed infrastructure
```

Not every customer follows every step.

---

## 7. Developer — Free

**CHF/USD 0**

Includes:
- Runtime,
- Context SDK,
- supported coding-agent integrations,
- Local Dyno,
- local Profiles,
- local receipts,
- community Kits.

Business role:
adoption and trust.

---

## 8. Pro / Tuner

Initial pricing hypothesis:
**~29/month**

Potential paid value:
- hosted Dyno history,
- private Profiles,
- multi-device sync,
- scheduled benchmarks,
- AutoTune credits,
- extended evidence history,
- private hosted package convenience.

This is a useful revenue stream, not the expected core enterprise moat.

---

## 9. Team

Initial hypothesis:
**~299–499/month**

Capabilities:
- shared projects,
- private Profiles,
- private Kits,
- central receipts,
- team economics,
- team AutoTune,
- access controls,
- support.

Team is the PLG bridge into organizations.

---

## 10. Agent Tuning Sprint

Fastest B2B revenue motion.

Offer:
> Give Thinkery one real agent or recurring agent workflow. We establish the baseline, integrate LeanCTX, tune its context strategy, validate quality and deliver the optimized Profile plus evidence.

Scope:
- one agent/workflow,
- one workload class,
- one to two weeks,
- explicit acceptance criteria.

Initial pricing hypothesis:
**CHF 7,500–15,000**

Keep free design-partner slots scarce and explicitly limited.

---

## 11. Business / Enterprise

Potential structure:

```text
base platform fee
+
AutoTune / hosted benchmark usage
+
enterprise controls
+
optional verified-savings upside
```

Value correlates more strongly with:
- agents,
- workflows,
- tuned AI spend,
- organization controls,
- deployment/support,

than seat count alone.

---

## 12. Performance fee

The current 10% verified-savings concept is useful but should not be the only revenue model.

Problems:
- baseline disputes,
- attribution,
- long cash cycle,
- changing provider prices.

Possible structure:

```text
annual minimum
credited against
verified savings share
```

Example hypothesis:
- minimum CHF 24k/year,
- verified gain-share result CHF 41k,
- total customer fee CHF 41k, not 24k + 41k.

Requires contract testing.

---

## 13. AutoTune usage

Potential commercial units:
- benchmark run,
- candidate profile evaluation,
- tuning compute hour,
- tuned workload,
- monthly agent optimization.

Avoid pricing directly on "tokens saved" until attribution is robust.

---

## 14. Managed relay — later

Potential endpoint:

```text
Agent
 ↓
LeanCTX Relay
 ↓
optimization / evidence / policy
 ↓
Provider
```

Revenue:
- subscription,
- usage,
- transparent infrastructure fee.

Do not make inference resale the initial business.

---

## 15. Unified billing — later

Thinkery can eventually offer one bill across providers.

Benefits:
- convenience,
- better economics visibility,
- possible margin.

Costs:
- working capital,
- fraud,
- provider terms,
- billing operations.

Only after meaningful traffic.

---

## 16. Managed execution — later

Customer brings agent logic/spec.

Thinkery provides tuned execution environment.

Charge:
- compute,
- tuning,
- platform.

Do **not** build a general agent builder.

---

## 17. Fastest path to money

```text
qualified company
 ↓
one production agent
 ↓
paid Tuning Sprint
 ↓
verified result
 ↓
annual contract
 ↓
second agent / team
```

Do not wait for a complete cloud platform before charging for a measurable outcome.


---

<!-- SOURCE FILE: 05-B2D-B2B-PLAYGROUND-GTM.md -->

# 05 — B2D, B2B, Playground and Go-to-Market

# Part I — B2D / prosumer

## 1. Primary "consumer"

The initial B2C market is better understood as **B2D**:

- Claude Code users,
- Codex users,
- Cursor users,
- independent AI engineers,
- developers building custom agents,
- consultants/SI engineers.

---

## 2. Acquisition loop

```text
GitHub / LinkedIn / recommendation
        ↓
leanctx.com
        ↓
Try Dyno
        ↓
Install
        ↓
Connect coding agent
        ↓
See local result
        ↓
Save Profile
        ↓
Pro
        ↓
Bring LeanCTX to work
```

This is the B2D → B2B flywheel.

---

## 3. Holy-shit moment

A user should be able to see something like:

```text
SAME TASK
SAME MODEL

STOCK
139,115 input tokens
$0.370 calculated cost
PASS

LEANCTX
14,016 input tokens
$0.058 calculated cost
PASS
```

Actual numbers depend on workload.

The experience is:
- fast,
- real,
- transparent,
- reproducible.

---

## 4. Coding agents remain first-class

Focus:
1. Claude Code
2. Codex
3. Cursor

Each gets:
- connect,
- doctor,
- Dyno,
- local receipt,
- uninstall.

Do not abandon coding-agent distribution just because custom agents have stronger enterprise monetization.

---

# Part II — Playground

## 5. Playground v0

No login.

Fixed safe workload.

Prompt:

> **Put an agent on the Dyno.**

Choices:

```text
[ Claude Code ]
[ Codex ]
[ Cursor ]
[ Custom Agent ]
```

Action:
`Run demo workload`

Show:
- stock arm,
- tuned arm,
- context transformation,
- provider usage,
- calculated cost,
- quality,
- receipt.

---

## 6. Playground v1 — BYOK

User provides provider API key for an ephemeral live run.

Requirements:
- secret not persisted by default,
- isolated job,
- clear handling statement,
- time limit,
- deletion,
- rate limits,
- abuse prevention.

Provider bills inference directly.

---

## 7. Playground v2 — local bridge

Website guides:

```bash
lean-ctx playground connect
```

Raw code remains local where possible.

Browser receives safe receipt/benchmark metadata unless user explicitly uploads content.

---

## 8. Playground v3 — hosted private workload

Pro/Team:
- private repository connection,
- ephemeral checkout,
- isolated worker,
- secret manager,
- Dyno,
- private Profile,
- retained evidence.

Requires stronger security, legal and operational maturity.

---

# Part III — B2B

## 9. Entry product

> # Agent Tuning Sprint

Do not call it:
- open-ended consulting,
- AI strategy,
- generic POC.

Pitch:

> Give us one existing AI agent. We benchmark it, integrate LeanCTX, tune the context strategy and verify the result against the same workload.

---

## 10. Ideal early customer

Good:
- agent already exists,
- recurring use,
- measurable provider usage,
- stable workload,
- clear owner,
- quality can be evaluated,
- enough volume for economics.

Bad:
- hypothetical AI plan,
- no stable workflow,
- no baseline,
- no owner,
- "just want to explore",
- no willingness to pay.

---

## 11. Sprint delivery

### Scope
Freeze:
- task/workload,
- source revision,
- model/provider,
- budget,
- quality threshold.

### Baseline
Run stock.

### Integrate
Attach / Wrap / Embed.

### Tune
Test Profiles.

### Validate
Quality gates.

### Deliver
- baseline,
- tuned result,
- Tuning Profile,
- receipt,
- human report,
- rollout recommendation.

---

## 12. B2B conversion

```text
Tuning Sprint
 ↓
Team
 ↓
multiple agents
 ↓
private Profiles/Kits
 ↓
shared evidence
 ↓
Enterprise
```

Expansion is by agent/workflow, not only seats.

---

## 13. Message by buyer

### CTO / VP Engineering
Lower cost per successful agent task.

### AI Platform Lead
One context-performance layer across different agents and providers.

### Engineering Manager
Less repeated context without rebuilding the workflow.

### CFO / FinOps
Savings tied to a real workflow and accepted outcome.

### Security
Local-first options, explicit receipts, versioned assets.

---

# Part IV — Sales focus

## 14. Evidence required before scaling

Before broad outbound:
- three external real baselines,
- two accepted tuning results,
- at least one paid Sprint,
- clear methodology,
- one reference case study,
- repeatable setup.

---

## 15. Partner model — later

Potential:
- AI consultancies,
- system integrators,
- custom-agent builders,
- platform providers.

LeanCTX can become the context-performance component they embed.

Do not build a large partner program before direct motion works.

---

## 16. Playground as funnel

The Playground is not a marketing toy.

It serves:

```text
demo
+ benchmark
+ onboarding
+ lead qualification
+ product proof
+ Pro conversion
```

A single capability creates multiple business functions.

---

## 17. Minimum cloud needed

Do not block Playground on the full future platform.

A minimal architecture:

```text
Web UI
 ↓
Job API
 ↓
Ephemeral worker
 ↓
LeanCTX Runtime
 ↓
Provider
 ↓
Receipt
```

Use canonical contracts so it can later converge with the broader cloud stack.


---

<!-- SOURCE FILE: 06-BRAND-AND-WEBSITE.md -->

# 06 — Brand and Complete Website Direction

# Part I — Brand

## 1. Brand architecture

### Company
**Thinkery AG**

### Product
**LeanCTX**

### Category
**The Context SDK for AI Agents.**

### Product promise
**Tune any agent. Prove every gain.**

### Thesis
**Context is performance.**

---

## 2. Brand idea

LeanCTX should feel like a **performance engineering laboratory**.

Not:
- generic AI SaaS,
- cyberpunk,
- robot art,
- glossy consulting,
- automotive cosplay.

The chiptuner analogy remains an internal product mental model.

The external visual language is:
- precision,
- metrology,
- calibration,
- benchmarking,
- technical evidence.

---

## 3. Visual vocabulary

Use:
- calibration marks,
- test runs,
- reference lines,
- coordinates,
- run IDs,
- hashes,
- traces,
- before/after states,
- exploded technical diagrams,
- diagnostic tables,
- verification stamps.

---

## 4. Proposed color system

### Carbon
`#0A0A0A`

### Bone
`#F2F0E9`

### Steel
`#9A9A94`

### Signal Orange
`#FF4B00`

Orange only for:
- active state,
- tuned state,
- gain,
- CTA.

Optional semantic green only for `PASS` / `VERIFIED`.

No gradient-led identity.

---

## 5. Typography

Two-family system:

### Primary
Precise neo-grotesk.

### Technical
Monospace for:
- commands,
- runs,
- metrics,
- hashes,
- receipts.

Final typefaces require license/brand review.

---

## 6. Vocabulary

Prefer:
- Tune
- Stock
- Baseline
- Tuned
- Run
- Dyno
- Profile
- Receipt
- Gain
- Context Budget
- Quality Gate
- Verified
- Deploy
- Retune

Avoid:
- revolutionary,
- magical,
- cognitive fabric,
- AI OS,
- transformative,
- next-generation intelligence layer.

---

## 7. Campaign library

Use selectively:

- **The Context SDK for AI Agents.**
- **Tune any agent. Prove every gain.**
- **Don't replace your agent. Tune it.**
- **Context is performance.**
- **No savings claim without a baseline.**
- **Performance you can version.**
- **Every agent has a context strategy. Most just don't know it yet.**
- **One agent is tuning. One hundred agents is infrastructure.**

---

# Part II — Website

## 8. Navigation

```text
LeanCTX

Product
Dyno
Integrations
Enterprise
Docs
GitHub

[ Try Dyno ]
```

---

## 9. Hero

Eyebrow:

> LEANCTX / CONTEXT PERFORMANCE

Headline:

# **The Context SDK for AI Agents.**

Body:

> Tune Codex, Claude Code, Cursor or your own AI agent to use context more efficiently — without rebuilding the agent.

Secondary:

> **Measure it. Tune it. Prove it.**

CTAs:

> **Try the Dyno**

> `Install LeanCTX →`

Footer:
> Open source. Local-first. Provider-neutral.

---

## 10. Hero visual

Real benchmark card:

```text
STOCK / RUN 001

INPUT
139,115

CACHED
87,040

COST
$0.370

QUALITY
PASS
```

transition:

```text
LEANCTX / RUN 002

INPUT
14,016

CACHED
8,192

COST
$0.058

QUALITY
PASS

GAIN
-84.3%
```

Only use actual verified data in production.

---

## 11. Section — Agent stays agent

Headline:

# **Don't replace your agent. Tune it.**

Copy:

> LeanCTX sits inside or alongside the agents you already use. It controls how context is selected, represented, reused and measured before inference.

Diagram:

```text
CODEX       CLAUDE CODE       CURSOR       CUSTOM AGENT
  │              │              │                │
  └──────────────┴──────┬───────┴────────────────┘
                        ↓
                     LeanCTX
                        ↓
                   MODEL / TOOLS
```

---

## 12. Section — Integration

Eyebrow:
> INTEGRATE

Headline:

# **One engine. Three ways in.**

### ATTACH
**No code changes.**

MCP / proxy / supported coding-agent integration.

### WRAP
**A few lines of code.**

Adapter around an existing framework/client.

### EMBED
**Full context control.**

Native SDK in a custom agent loop.

Footer:

> The deeper LeanCTX integrates, the more of the context lifecycle it may be able to optimize.

Do not state this as a guaranteed performance law until Dyno proves it.

---

## 13. Section — Dyno

Dark section.

Eyebrow:
> LEANCTX DYNO / AGENT BENCHMARKING

Headline:

# **You wouldn't tune a system without measuring it.**

Copy:

> LeanCTX Dyno runs the same workload under different context strategies and compares context, provider usage, cost and quality.

Example:

```text
WORKLOAD
payment-agent / run-042

              COST       QUALITY
STOCK         $1.00       PASS
ATTACH        $0.54       PASS
NATIVE        $0.31       PASS

RECOMMENDED
balanced-v7
```

CTA:
> **Run my agent on the Dyno →**

---

## 14. Section — Context is performance

# **Context is performance.**

### SELECT
Give the agent what matters.

### COMPRESS
Keep structure. Remove waste.

### REUSE
Stop paying repeatedly for the same information.

### RECOVER
Keep exact source available when detail is needed.

### MEASURE
Every optimization needs a baseline.

---

## 15. Section — Loop

```text
CONNECT → MEASURE → TUNE → PROVE → DEPLOY → REPEAT
```

Headline:
# **Agent tuning is a loop, not a setting.**

---

## 16. Section — AutoTune preview

Eyebrow:
> PREVIEW / LEANCTX CLOUD

Headline:
# **AutoTune**

Copy:

> Evaluate multiple context strategies against representative workloads and find a better cost/quality profile automatically.

Show a Pareto frontier.

Footer:
> Deploy the winning Profile back into your agent.

Do not label available until it is.

---

## 17. Section — Tuning Profiles

Headline:
# **Performance you can version.**

Example:

```text
LEANCTX PROFILE

payments-review
v1.4.2

CONTEXT BUDGET
64k

READ STRATEGY
outline-first

REUSE
enabled

KIT
payments-security@2.1

QUALITY
PASS
```

---

## 18. Section — Proof

Headline:
# **No savings claim without a baseline.**

Copy:

> LeanCTX receipts record the workload, provider usage, Profile, quality result and declared economics behind every tuning claim.

CTA:
`View methodology`

---

## 19. Section — controlled experiment

Eyebrow:
> REAL PROVIDER EXPERIMENT / AUG 2026

Copy:

> In three controlled five-turn coding-agent scenarios using real OpenAI API calls, the tested LeanCTX treatment produced approximately 79–86% lower calculated API cost than the baseline under the declared methodology.

Table:

```text
SMALL     85.0% fewer input tokens   78.9% lower calculated cost
MEDIUM    89.9%                      84.3%
LARGE     91.0%                      86.0%
```

Footnote:

> Workload-specific. Provider usage came from API responses; cost was calculated from the declared pricing table. This is not a universal savings promise. Canonical product claims require integrated quality gates.

---

## 20. Section — Coding agents

Headline:
# **Your coding agent stays your coding agent.**

Cards:
- Claude Code
- Codex
- Cursor

Copy:
> Keep your existing workflow. Add LeanCTX underneath it.

---

## 21. Section — Custom agents

Eyebrow:
> LEANCTX SDK

Headline:
# **Building your own agent? Go deeper.**

Conceptual code:

```python
from leanctx import LeanCTX

ctx = LeanCTX(project=".")
agent = ctx.wrap(agent)

result = agent.run("Review the payment service")
print(result.leanctx.receipt)
```

Label conceptual until exact API is stable.

---

## 22. Section — Enterprise

Headline:
# **One agent is tuning. One hundred agents is infrastructure.**

Copy:

> Thinkery extends LeanCTX from local agent performance to shared evidence, private Profiles, policy and organization-wide economics.

### CONTROL
- access
- budgets
- policy
- SSO/RBAC

### EVIDENCE
- shared receipts
- audit
- economics
- quality

### DISTRIBUTION
- private Profiles
- private Context Kits
- organization standards

CTA:
> **Tune one production agent →**

---

## 23. Section — OSS

Headline:
# **The engine stays open.**

Copy:

> Developers should be able to build and tune great agents locally without asking Thinkery for permission.

Secondary:
> Thinkery earns revenue when teams need continuous tuning, shared control and organizational infrastructure.

---

## 24. Pricing

### Developer
$0

### Pro / Tuner
~$29/month hypothesis

### Team
from ~$399/month hypothesis

### Enterprise
custom

### Agent Tuning Sprint
from CHF 7,500 hypothesis

Do not publish hypotheses as validated pricing without testing.

---

## 25. Tuning Sprint page

Headline:
# **Put one production agent on the Dyno.**

Copy:

> We baseline it, integrate LeanCTX, tune its context strategy and verify the result against the same workload.

Process:

```text
CONNECT
BASELINE
TUNE
VALIDATE
DEPLOY
```

Deliver:
- baseline,
- tuned integration,
- Profile,
- receipt,
- report,
- rollout recommendation.

---

## 26. Footer

```text
LeanCTX
The Context SDK for AI Agents.

Built by Thinkery AG
Switzerland

GitHub
Docs
Security
Privacy
Contact
```


---

<!-- SOURCE FILE: 07-COMPETITIVE-MOAT.md -->

# 07 — Competitive Moat

## 1. Core rule

> **Do not let competitors write the roadmap.**

A competitor shipping a feature creates a research item, not automatically a product task.

---

## 2. The wrong game

Do not compete primarily on:
- highest compression ratio,
- most patterns,
- most integrations,
- most tools,
- "we also have shared context",
- one isolated benchmark win.

Individual features are useful, but individually copyable.

---

## 3. The game LeanCTX should play

Own the complete tuning loop:

```text
Task
 ↓
Context strategy
 ↓
Execution
 ↓
Outcome
 ↓
Receipt
 ↓
Dyno
 ↓
Tuning Profile
 ↓
next execution
```

The interaction graph is the product.

---

## 4. Defensibility stack

### Layer 1 — Distribution
Strong OSS adoption and coding-agent compatibility.

### Layer 2 — Integration depth
Attach, Wrap and Embed.

### Layer 3 — Methodology
Credible controlled benchmarking.

### Layer 4 — Profiles
Performance becomes portable/versioned.

### Layer 5 — Evidence
Every gain tied to workload and outcome.

### Layer 6 — AutoTune
Automated workload-specific optimization.

### Layer 7 — Performance graph
Historical relationship among:
- workload,
- agent,
- model/provider,
- Profile,
- context behavior,
- quality,
- cost.

### Layer 8 — Enterprise embedding
Private assets, policy, evidence and organization workflows increase operational dependence.

---

## 5. Context Planning differentiation

Pure compression:
> shrink a payload after it exists.

Native LeanCTX:
> influence whether and how the payload is created.

This may be a structurally stronger position because unnecessary context can be prevented rather than merely compressed.

It must be proven via the Integration Depth Benchmark.

---

## 6. Competitors as capability supply

Long term, specialized optimizers can fit beneath the LeanCTX decision/tuning layer.

```text
LeanCTX
  │
  ├── native context optimizer
  ├── provider-native compaction
  ├── third-party optimizer
  └── enterprise custom optimizer
```

If another optimizer is better for a workload, integrating it can strengthen LeanCTX.

The strategic question is not:
> Can we copy this feature?

It is:
> Does this capability produce a better accepted outcome per unit of cost for this workload?

---

## 7. Provider neutrality

LeanCTX should remain valuable across:
- OpenAI,
- Anthropic,
- Google,
- open-weight models,
- local models,
- future providers.

Do not make one provider's agent runtime the product identity.

---

## 8. Local-first moat

Local-first provides:
- trust,
- low-friction enterprise pilots,
- raw-context control,
- portability,
- sovereign/on-prem options,
- independent evidence.

Do not give this away casually for cloud convenience.

---

## 9. Evidence moat

A compressor can be cloned.

A history of:
- task class,
- profile version,
- context choice,
- model/provider,
- quality result,
- accepted outcome,
- verified economics,

is more difficult to replace.

Especially if customers use it for:
- budget decisions,
- rollout,
- profile promotion,
- audit,
- regression detection.

---

## 10. Performance metadata moat

Potential compounding metadata:
- task class,
- agent type,
- model/provider,
- Profile,
- input volume,
- tool mix,
- recovery,
- cost,
- latency,
- quality,
- acceptance.

This can compound without centralizing raw source code if privacy and consent are designed correctly.

---

## 11. Open protocols as offensive strategy

Open:
- Profile format,
- receipt format,
- Kit format,
- optimizer interfaces,

can let LeanCTX become the common context-performance layer.

The implementation that decides **which Profile/capability to use** can remain commercial.

---

## 12. Brand moat

LeanCTX can attempt to own a category phrase:
> **agent context performance**

Distinctive objects:
- Dyno,
- Tuning Profile,
- Receipt,
- AutoTune,
- Context Kit.

Naming does not create a moat alone.

A real, repeatable product loop does.

---

## 13. Competitive response policy

When a competitor ships:
1. capture the fact,
2. verify what is actually available,
3. ask whether a customer needs it,
4. classify it in the LeanCTX loop,
5. integrate if commoditized and useful,
6. build only if strategically differentiated,
7. otherwise ignore.

No panic feature race.

---

## 14. Never overclaim

Do not say:
- nobody else can build this,
- other competitors only do dashboards,
- every optimization is quality-neutral,
- one benchmark applies universally,
- another company copied LeanCTX without forensic evidence,
- funding determines product quality.

Win on product evidence.


---

<!-- SOURCE FILE: 08-TECHNICAL-CONVERGENCE.md -->

# 08 — Technical Convergence

## 1. Definition

Convergence does **not** mean one repository.

It means:
- one owner per responsibility,
- one contract per concept,
- one evidence truth,
- one billing owner,
- one identity model,
- fewer duplicate implementations,
- one end-to-end customer flow.

---

## 2. Core repository ownership

### `lean-ctx`
Public OSS:
- Runtime,
- SDK core/contracts,
- local integrations,
- ctxpkg / Kit tooling,
- local Tuning Profiles,
- local Dyno,
- local evidence,
- verifier,
- open protocol/reference interfaces.

### `lean-ctx-enterprise`
Private:
- enterprise authorization,
- central policy,
- fleet,
- enterprise evidence aggregation,
- self-hosted control,
- enterprise deployment,
- proprietary organization-scale tuning/control intelligence where appropriate.

### `lean-ctx-cloud`
Private:
- user/account lifecycle,
- organizations/workspaces,
- Stripe,
- subscriptions,
- entitlements,
- hosted Dyno,
- hosted private registry,
- Pro/Team cloud services,
- cloud dashboard APIs.

### `thinkery`
Brand, website, product narrative, cases.

---

## 3. Dependency direction

```text
lean-ctx
   ↑
versioned contracts/releases
   │
enterprise
   ↑
service contracts
   │
cloud
```

Public Runtime must never depend on private code.

Cloud outage must not break local LeanCTX.

---

## 4. Canonical contracts

Freeze only after reference implementation pressure-tests them.

Candidates:
- `TaskEnvelopeV1`
- `ContextEnvelopeV1`
- `ExecutionReceiptV1`
- `SavingsReceiptV1`
- `EvidenceBundleV1`
- `TuningProfileV1`
- `ContextKitV1`
- `PolicyDecisionV1`
- `UsageObservationV1`
- `EntitlementV1`

For each contract define:
- owner,
- schema,
- producer,
- consumers,
- versioning,
- compatibility,
- test fixtures,
- deprecation.

---

## 5. Evidence convergence

Target:

```text
Runtime
 ↓
ExecutionReceipt
 ↓
SavingsReceipt
 ↓
EvidenceBundle
 ↓
Verifier / Enterprise / Cloud / dashboard
```

One arithmetic implementation.

One signature model.

One verifier.

HTML/PDF/CSV are derived views.

---

## 6. Billing convergence

Canonical commercial owner:
**Cloud.**

### Runtime
Observes:
- usage,
- model/provider,
- cost inputs.

### Enterprise
Owns:
- operational budgets,
- quotas,
- local enforcement,
- usage observations.

### Cloud
Owns:
- plans,
- Stripe,
- subscription state,
- invoices,
- commercial entitlement lifecycle.

Long-term duplicate Stripe/business billing surfaces should be removed from Enterprise.

---

## 7. Identity convergence

Separate:

### Commercial identity — Cloud
- user,
- organization,
- workspace,
- subscription,
- entitlement.

### Runtime identity — protocol/Enterprise
- agent,
- service principal,
- human operator,
- policy subject.

### Local OSS
- local process/project identity.

Do not force Thinkery identity into local OSS.

---

## 8. Kit convergence

Do not create a second package runtime.

Decision:
> `ContextKitV1` uses `.ctxpkg` as the technical distribution substrate.

Add:
- first-class semantic schema,
- SDK `load_kit`,
- activation,
- compatibility,
- receipt reference.

---

## 9. Profile convergence

Do not let tuning settings diverge across:
- CLI,
- SDK,
- Cloud,
- Enterprise.

Define one versioned `TuningProfileV1`.

Adapters translate the same Profile into runtime behavior.

---

## 10. Dyno convergence

Converge:
- `evidence realworld`,
- existing benchmark commands,
- future hosted benchmarking,

around:
- one workload schema,
- one result schema,
- one quality contract,
- one receipt path.

Do not create a separate marketing benchmark engine.

---

## 11. Worker / Enterprise seam

A known current-state integration seam is the expected MCP authorization path between the worker and Suite.

Before broad Enterprise rollout:
- define the canonical authorization contract,
- correct route/header behavior,
- add cross-repo integration test,
- use explicit runtime identity.

Do this only when it blocks current customer/product flow.

---

## 12. Cloud seam

Current Cloud code has substantial billing/registry functionality but historically depended on external account/session state and configured Postgres/Stripe.

Before Pro/Team launch:
- decide canonical account owner,
- implement complete end-to-end signup/session/billing,
- exercise live/test Stripe end to end,
- migrate schema handling to durable versioned migrations if needed,
- test cancellation/export/deletion.

Do not confuse source presence with production readiness.

---

## 13. Cross-repo strategic tests

### Test A — Local SDK
SDK → Runtime → run → receipt → verify.

### Test B — Profile
Profile load → run → receipt contains exact version.

### Test C — Kit
Kit create/sign/load → receipt contains exact hash/version.

### Test D — Evidence
Enterprise ingests canonical bundle → export still verifies.

### Test E — Entitlement
Cloud entitlement reaches commercial layer while local OSS still works without Cloud.

---

## 14. Module migration labels

Every existing module gets one status:
- KEEP
- MOVE
- ADAPT
- MERGE
- DEPRECATE
- DELETE
- DEFER

Examples:

```text
compression engine           KEEP
ctxpkg                       KEEP
SDK                          ADAPT / PRODUCTIZE
Kit semantic layer           BUILD ON TOP
signed evidence primitives   CANONICALIZE
unsigned CSV                 DERIVED VIEW
Suite Stripe ownership       MOVE / DEPRECATE
Cloud Stripe                 KEEP
generic agent scheduler      DEFER
marketplace                  DEFER
```

---

## 15. One end-to-end architecture

The first complete commercial chain should be:

```text
supported agent
 ↓
LeanCTX integration
 ↓
real workload
 ↓
baseline
 ↓
treatment
 ↓
quality gate
 ↓
canonical receipt
 ↓
signed evidence
 ↓
customer-readable report
 ↓
paid customer
```

Do not optimize architecture that does not support this chain yet.


---

<!-- SOURCE FILE: 09-ROADMAP-AND-BACKLOG.md -->

# 09 — 90-Day Roadmap and Execution Backlog

## Principle

Do not spend 90 days "building the platform."

Spend 90 days proving and selling the tuning loop.

---

# Phase 0 — Freeze

## Deliverables
- approve this strategy repository,
- approve category,
- approve OSS/commercial boundary,
- approve canonical contract candidates,
- approve anti-roadmap.

## Exit
New work can be classified quickly.

---

# Phase 1 — Dyno foundation

## Goal
Turn the current real-world evidence command into canonical product proof.

### P0 tasks
- [ ] Define `DynoWorkloadV1`.
- [ ] Refactor baseline/treatment runner.
- [ ] Preserve provider-reported usage.
- [ ] Record cached tokens.
- [ ] Version pricing.
- [ ] Add quality gate.
- [ ] Remove/clearly label synthetic fallback data.
- [ ] Emit `ExecutionReceiptV1`.
- [ ] Emit `SavingsReceiptV1`.
- [ ] Emit signed `EvidenceBundleV1`.
- [ ] Verify bundle offline.
- [ ] Generate HTML from same canonical data.
- [ ] Add tamper test.
- [ ] Publish methodology.

### Definition of done
One workload can be replayed and independently verified.

---

# Phase 2 — Reference custom agent

## Goal
Prove the Context SDK thesis.

Build the smallest useful coding agent:
- discover,
- search,
- read,
- test,
- answer.

Arms:
1. stock,
2. Attach,
3. Embed.

### P0 tasks
- [ ] Freeze real task fixture.
- [ ] Instrument tool/context reads.
- [ ] Integrate provider usage.
- [ ] Integrate quality.
- [ ] Run Integration Depth Benchmark.
- [ ] Document result honestly.

### Exit
We know empirically whether deeper integration improves the frontier.

---

# Phase 3 — SDK productization

## Goal
Small developer mental model.

### Tasks
- [ ] Define `ContextSession`.
- [ ] Define Runtime handshake.
- [ ] Define receipt API.
- [ ] Define Profile loading.
- [ ] Define Kit loading.
- [ ] Pick first priority language.
- [ ] Build one complete reference example.
- [ ] Add conformance fixtures.

### Exit
A new developer integrates a supported custom agent in under 15 minutes.

---

# Phase 4 — Coding-agent distribution

### Targets
- Claude Code
- Codex
- Cursor

For each:
- [ ] `connect`
- [ ] `doctor`
- [ ] smoke test
- [ ] Dyno path
- [ ] receipt
- [ ] clean uninstall
- [ ] docs

### Exit
All three are boringly reliable.

---

# Phase 5 — Tuning Profile

### Tasks
- [ ] Define `TuningProfileV1`.
- [ ] local create/validate.
- [ ] version/pin.
- [ ] load.
- [ ] receipt reference.
- [ ] rollback.
- [ ] compare.

### Exit
Winning Dyno configuration can be deployed deterministically.

---

# Phase 6 — Context Kit

### Tasks
- [ ] Define `ContextKitV1`.
- [ ] map to `.ctxpkg`.
- [ ] SDK load.
- [ ] compatibility.
- [ ] receipt hash.
- [ ] Code Review Kit example.

### Exit
Kit is a real runtime/evidence object, not marketing terminology.

---

# Phase 7 — Playground v0

### Tasks
- [ ] fixed safe workload.
- [ ] no-login experience.
- [ ] stock/tuned visualization.
- [ ] methodology.
- [ ] install CTA.
- [ ] no fake benchmark path.

### Exit
A stranger understands LeanCTX by trying it.

---

# Phase 8 — Revenue in parallel

Do not wait for phases to finish.

### Tuning Sprint
- [ ] one-page offer,
- [ ] scope template,
- [ ] acceptance template,
- [ ] price,
- [ ] contract path,
- [ ] 10 qualified conversations,
- [ ] 3 scoped workflows,
- [ ] 1 paid Sprint,
- [ ] 1 accepted report.

### Exit
External money for a tuning outcome.

---

# Phase 9 — Playground BYOK / Pro

Only after v0 works.

- [ ] ephemeral secrets,
- [ ] isolated jobs,
- [ ] rate limit,
- [ ] receipt storage,
- [ ] account,
- [ ] hosted history,
- [ ] private Profiles,
- [ ] billing.

---

# Phase 10 — Team

Only after shared need is observed.

- [ ] organizations,
- [ ] shared receipts,
- [ ] private Profile registry,
- [ ] private Kit registry,
- [ ] team economics,
- [ ] basic access control.

---

# Phase 11 — AutoTune alpha

Prerequisites:
- Dyno stable,
- quality stable,
- Profile schema stable,
- representative workloads.

Alpha:
- [ ] candidate generator,
- [ ] benchmark queue,
- [ ] Pareto analysis,
- [ ] recommendation,
- [ ] human approval,
- [ ] deploy,
- [ ] rollback.

No autonomous production rollout at first.

---

# P2 / P3 later

- Enterprise SSO/RBAC.
- central policy.
- self-hosted.
- audit/retention.
- Managed Relay.
- Unified Billing.
- Managed Execution.
- Marketplace.

No work without customer pull.

---

# 90-day success definition

Technically:

> A developer can install LeanCTX, tune a supported coding/custom agent, produce a verified before/after result and deploy a versioned Profile.

Commercially:

> At least one external customer has paid Thinkery for a bounded tuning outcome.

That is the milestone.


---

<!-- SOURCE FILE: 10-METRICS-CLAIMS-GOVERNANCE.md -->

# 10 — Metrics, Claims and Governance

# Part I — Metrics

## 1. North Star

> **Verified cost per successful agent task**

---

## 2. Activation

Track:
- install → first successful request,
- install → first receipt,
- install → first Dyno,
- median time to result.

Target for supported path:
**<15 minutes**.

---

## 3. Performance

Track:
- provider input tokens,
- cached tokens,
- output tokens,
- calculated cost,
- task success,
- quality delta,
- latency,
- tool calls,
- context reuse,
- recovery.

---

## 4. Trust

Track:
- receipt coverage,
- verification pass rate,
- benchmark reproducibility,
- failed/ambiguous runs,
- unsupported claims removed.

---

## 5. B2D metrics

- active installs,
- Dyno activation,
- repeat Dyno runs,
- Profile reuse,
- Pro conversion,
- paid retention.

---

## 6. B2B metrics

- qualified workflows,
- scoped Sprints,
- paid Sprints,
- accepted reports,
- annual conversions,
- second-agent expansion,
- ARR per customer,
- tuned AI spend.

---

# Part II — Gates

## 7. Proof Gate
Do not broaden savings claims until:
- provider usage is captured,
- quality gate exists,
- receipt works.

## 8. SDK Gate
Do not overmarket SDK depth until:
- reference agent works,
- external integration docs exist,
- exact supported APIs are stable enough.

## 9. Profile Gate
Do not call tuning deployable until:
- versioning,
- receipt linkage,
- rollback.

## 10. AutoTune Gate
Do not ship automatic recommendations until:
- representative workloads,
- quality gates,
- human approval,
- repeatability.

## 11. Team Gate
Do not overbuild collaboration without repeated shared-history/Profile/Evidence demand.

## 12. Enterprise Gate
Do not finish broad enterprise surfaces without buyer pull.

## 13. Managed Execution Gate
Do not build until real customers ask Thinkery to operate their agents.

## 14. Marketplace Gate
Do not build until Profiles/Kits show real repeated supply and demand.

---

# Part III — Claim governance

## 15. Claim classes

### A — Current product fact
Must be supported by current implementation/run evidence.

### B — Controlled benchmark
Must state workload and methodology.

### C — Customer observation
Must stay customer/workload-specific.

### D — Product target
Must be labeled preview/target/planned.

### E — Strategic thesis
Can be visionary but cannot sound shipped.

---

## 16. August 2026 real-provider experiment

Acceptable:

> In three controlled five-turn coding-agent scenarios using real OpenAI API calls, the tested LeanCTX treatment produced approximately 79–86% lower calculated API cost under the declared methodology.

Must also disclose:
- provider usage came from API responses,
- cost was calculated,
- provider cache was included,
- sample is workload-specific,
- canonical quality gate is required before broad generalization.

Avoid:

> LeanCTX reduces all agent costs by 79–86%.

---

## 17. Customer evidence

Wavect-style evidence must state:
- observed workflow,
- measurement owner,
- whether cost is estimated or provider-billed,
- no universal transfer.

---

## 18. "Verified"

Use only when:
- the declared artifact passed the declared verifier.

It does not mean:
- certified,
- secure,
- compliant,
- universally correct.

---

## 19. Cost vocabulary

Use separately:
- provider-reported usage,
- calculated API cost,
- estimated savings,
- reconciled invoice cost.

Never blur these.

---

## 20. Current vs future SDK copy

Until the exact public SDK surface is stable, use qualifying language in technical docs.

The product category can be adopted as strategic positioning, but examples must mark conceptual APIs as conceptual.

---

## 21. Competitive claims

Do not claim:
- competitors copied LeanCTX,
- they lack a capability,
- Thinkery is objectively superior,

without evidence.

The brand should win by showing its own benchmark and methodology.

---

# Part IV — Weekly focus

## 22. Weekly check

Every active project must fall into:
- **Proof**
- **Customer**
- **Revenue**

or be a critical blocker.

Everything else:
**Park.**

---

## 23. Stop criteria

Pause/reject work if:
- nobody external understands the value,
- it creates a new product category,
- it requires finishing many unrelated subsystems,
- it cannot be tied to context performance,
- quality cannot be evaluated,
- there is no customer pull,
- it exists only because a competitor shipped it.


---

<!-- SOURCE FILE: 11-SOURCE-MAP-AND-DECISIONS.md -->

# 11 — Source Map, Reconciliation and Frozen Decisions

## 1. Why this file exists

The new Context SDK strategy evolves earlier strategy.

It must not silently rewrite current technical reality.

---

# Part I — Source map

## 2. Current-state authority

### `21-WHAT-WE-HAVE-EXACTLY.md`

Use as authority for:
- what exists,
- what runs,
- what is tested,
- what is partial,
- what is missing.

Important retained facts:
- local compression is real,
- `.ctxpkg` is a strong package foundation,
- local agent coordination primitives exist but do not equal a full hosted scheduler,
- Enterprise Suite is substantial but not fully composed/deployed,
- evidence/signing primitives exist but the visible end-to-end product path historically had composition gaps,
- Cloud billing primitives exist but historically required account/session/DB/Stripe configuration.

Future-state language in this repository does not overwrite those facts.

---

## 3. Focus authority

### `25-FOCUS-AND-IDENTITY.md`

Retained:
- developer-first,
- local-first,
- proof before promise,
- quality beside savings,
- pull before expansion,
- no generic agent-platform scope,
- do not sell unsupported v5.

### Explicit evolution
Earlier focus described LeanCTX publicly primarily as Context Engine / Context Compression.

This repository proposes:

> Context Engine = runtime underneath  
> **Context SDK = public product abstraction**

Compression remains the current wedge.

This is an evolution of productization, not an assertion that every desired SDK ergonomic is already shipped.

---

## 4. Repo authority

### `23-REPO-CONVERGENCE.md`

Retained:
- public `lean-ctx`,
- private Enterprise,
- private Cloud,
- versioned contracts,
- no private dependency inside OSS.

If older open-core docs suggest different physical repository topologies, the newer convergence plan wins.

---

## 5. OSS authority

### `24-OSS-PROTECTION.md`

Retained:
- strong open Runtime,
- no hidden degradation,
- portability,
- open Kit/interoperability formats,
- local-first trust.

Useful older Open-Core principle retained:
> Deployment location is not a licensing model.

Commercial intelligence can run on-prem/VPC.

---

## 6. Immediate proof sources

### `22-FASTEST-POC.md`
Retained:
- real tasks,
- real provider processes,
- no invented findings,
- evidence,
- tamper rejection.

### August 2026 `evidence realworld`
New foundation for Dyno:
- real OpenAI API usage,
- cache-aware A/B,
- accumulating multi-turn context,
- workload-specific 79–86% calculated cost reduction in the three described runs.

It is not a universal benchmark.

---

## 7. Existing pilot material

The current pilot already says:
- integrate into existing workflow,
- keep business process,
- baseline first,
- quality matters,
- business case = cost per accepted process.

The new strategy adds:
- SDK framing,
- Dyno,
- Tuning Profiles,
- canonical receipts.

The business logic remains compatible.

---

# Part II — Frozen decisions

## D-001
**LeanCTX public descriptor:**  
**The Context SDK for AI Agents.**

## D-002
**Product promise:**  
**Tune any agent. Prove every gain.**

## D-003
LeanCTX owns context performance, not generic agent orchestration.

## D-004
Integration taxonomy:
1. Attach
2. Wrap
3. Embed
4. Run later

## D-005
Claude Code, Codex and Cursor remain first-class.

## D-006
The real-world evidence path converges into **LeanCTX Dyno**.

## D-007
North Star:
**Verified cost per successful agent task.**

## D-008
`TuningProfileV1` becomes a first-class product object.

## D-009
Context Kits use `.ctxpkg`; no parallel package system.

## D-010
One canonical receipt/evidence path.

## D-011
Strong local Runtime/SDK/tuning remains OSS.

## D-012
Continuous AutoTune and organization-scale intelligence are commercial.

## D-013
Thinkery AG is company/commercial operator. LeanCTX remains developer-facing brand.

## D-014
Primary near-term B2B cash product:
**Agent Tuning Sprint**.

## D-015
Ship a narrow real Playground before a broad cloud platform.

## D-016
Managed Relay is later.

## D-017
Managed Execution is later and is not a generic Agent Builder.

## D-018
Marketplace is deferred.

## D-019
Competitive strategy:
own the workload → context strategy → outcome → evidence → retuning loop.

## D-020
Any new material feature must state:
- user,
- context problem,
- measurable outcome,
- product-loop step,
- OSS/commercial classification,
- displaced current work.

No answer → no implementation.

---

# Part III — Anti-roadmap

Do not build now:
- generic Agent Builder,
- workflow canvas,
- CRM automation,
- voice platform,
- template zoo,
- generic browser-agent product,
- marketplace,
- provider marketplace,
- own model,
- large hosted execution fleet,
- unified billing,
- every framework adapter,
- complete enterprise dashboard,
- complete fleet scheduler,
- new package format,
- big-bang repo migration before product proof.

---

## Final handoff

The next company truth to earn is not:

> "Thinkery has a huge platform vision."

It is:

> **A real customer paid Thinkery because LeanCTX measurably improved a real agent while preserving the accepted outcome.**

Once that truth exists, the next layer is earned.


---

<!-- SOURCE FILE: README.md -->

# LeanCTX — Context SDK Strategy Repository

**Status:** Canonical strategy draft  
**Date:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX  
**Primary product thesis:** **The Context SDK for AI Agents.**  
**Primary product promise:** **Tune any agent. Prove every gain.**

---

## Why this repository exists

LeanCTX has accumulated substantial technical capability: context compression, structural code understanding, memory, MCP, proxying, evidence, cost accounting, package primitives, SDK surfaces, agent coordination primitives and commercial control-plane/cloud components.

The strategic problem is no longer "what could we build?"

It is:

> **How do we turn the existing substrate into one understandable product, one developer experience, one monetization model and one focused execution plan?**

This repository is the proposed answer.

The new public abstraction is:

> # LeanCTX  
> ## The Context SDK for AI Agents.

The SDK is the developer-facing surface.  
The LeanCTX Runtime is the technical engine.  
MCP, proxy integrations and wrappers connect existing agents.  
Thinkery monetizes continuous tuning and organization-scale operation.

---

## Canonical loop

```text
CONNECT
   ↓
MEASURE
   ↓
TUNE
   ↓
PROVE
   ↓
DEPLOY
   ↓
REPEAT
   ↺
```

Everything LeanCTX builds should fit this loop.

---

## Canonical product architecture

```text
AI AGENTS
Codex / Claude Code / Cursor / OpenAI Agents /
Claude Agent SDK / LangGraph / Custom Agents
                       │
                       ▼
                 LEANCTX ACCESS
          ┌────────┬────────┬────────┐
          │ ATTACH │  WRAP  │ EMBED  │
          └────────┴────────┴────────┘
                       │
                       ▼
                LEANCTX RUNTIME
        selection / compression / reuse
        memory / recovery / kits / evidence
                       │
                       ▼
                MODEL + TOOLS
                       │
                       ▼
                   RECEIPT
                       │
                       ▼
                    DYNO
                       │
                       ▼
                  AUTOTUNE
                       │
                       ▼
               TUNING PROFILE
```

A future fourth integration depth, **RUN**, may let Thinkery operate an existing agent on managed infrastructure. This is optional and later; it is not a generic agent-builder strategy.

---

## Source-of-truth hierarchy

### What exists today
`21-WHAT-WE-HAVE-EXACTLY.md`

### Product focus
`25-FOCUS-AND-IDENTITY.md`

### Repository ownership
`23-REPO-CONVERGENCE.md`

### OSS/IP boundary
`24-OSS-PROTECTION.md` plus prior Open-Core planning where compatible.

### Immediate proof
`22-FASTEST-POC.md` plus the August 2026 `lean-ctx evidence realworld` experiment.

This repository is a **new productization layer** over those sources. It intentionally distinguishes:
- audited current state,
- proposed canonical product direction,
- future product possibilities.

---

## Files

1. `00-VISION-AND-FOCUS.md`
2. `01-PRODUCT-ARCHITECTURE.md`
3. `02-SDK-RUNTIME-INTEGRATIONS.md`
4. `03-DYNO-EVIDENCE-AUTOTUNE.md`
5. `04-OSS-PAID-MONETIZATION.md`
6. `05-B2D-B2B-PLAYGROUND-GTM.md`
7. `06-BRAND-AND-WEBSITE.md`
8. `07-COMPETITIVE-MOAT.md`
9. `08-TECHNICAL-CONVERGENCE.md`
10. `09-ROADMAP-AND-BACKLOG.md`
11. `10-METRICS-CLAIMS-GOVERNANCE.md`
12. `11-SOURCE-MAP-AND-DECISIONS.md`

---

## One-page handoff

### What is LeanCTX?
**The Context SDK for AI Agents.**

### What does it do?
LeanCTX helps an existing agent select, represent, reuse, compress, recover and measure context so the agent can achieve accepted outcomes with less unnecessary compute.

### What is the current wedge?
Coding agents and custom agent workflows with measurable context/cost waste.

### What is the core proof?
Same task. Same model. Controlled baseline and treatment. Provider usage. Quality gate. Receipt.

### What is the business North Star?
**Verified cost per successful agent task.**

### What stays open?
A powerful local Runtime, SDK, integrations, local tuning, local profiles/kits and portable evidence.

### What becomes paid?
Continuous AutoTune, hosted benchmark capacity, private profiles/kits, shared evidence, organization economics, policy, access control and enterprise operation.

### What is Thinkery?
The company building and commercializing the organization-scale layer around LeanCTX.

### What do we explicitly not build now?
Generic Agent Builder, workflow canvas, CRM/voice automation, broad marketplace, massive hosted agent platform.

### Founder focus
The next existential proof is:

> **A real external customer pays for a verified tuning outcome.**
