# LeanCTX — Context SDK Strategy Repository

**Status:** Canonical strategy draft  
**Date:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX  
**Primary product thesis:** **The Context SDK for AI Agents.**  
**Primary product promise:** **Tune any agent. Prove every gain.**

---

## Why this repository exists

LeanCTX has accumulated substantial technical capability: context compression, structural code understanding, memory, MCP, proxying, evidence, cost accounting, package primitives, SDK surfaces, agent coordination primitives and commercial control-plane/cloud components.

The strategic problem is no longer "what could we build?"

It is:

> **How do we turn the existing substrate into one understandable product, one developer experience, one monetization model and one focused execution plan?**

This repository is the proposed answer.

The new public abstraction is:

> # LeanCTX  
> ## The Context SDK for AI Agents.

The SDK is the developer-facing surface.  
The LeanCTX Runtime is the technical engine.  
MCP, proxy integrations and wrappers connect existing agents.  
Thinkery monetizes continuous tuning and organization-scale operation.

---

## Canonical loop

```text
CONNECT
   ↓
MEASURE
   ↓
TUNE
   ↓
PROVE
   ↓
DEPLOY
   ↓
REPEAT
   ↺
```

Everything LeanCTX builds should fit this loop.

---

## Canonical product architecture

```text
AI AGENTS
Codex / Claude Code / Cursor / OpenAI Agents /
Claude Agent SDK / LangGraph / Custom Agents
                       │
                       ▼
                 LEANCTX ACCESS
          ┌────────┬────────┬────────┐
          │ ATTACH │  WRAP  │ EMBED  │
          └────────┴────────┴────────┘
                       │
                       ▼
                LEANCTX RUNTIME
        selection / compression / reuse
        memory / recovery / kits / evidence
                       │
                       ▼
                MODEL + TOOLS
                       │
                       ▼
                   RECEIPT
                       │
                       ▼
                    DYNO
                       │
                       ▼
                  AUTOTUNE
                       │
                       ▼
               TUNING PROFILE
```

A future fourth integration depth, **RUN**, may let Thinkery operate an existing agent on managed infrastructure. This is optional and later; it is not a generic agent-builder strategy.

---

## Source-of-truth hierarchy

### What exists today
`21-WHAT-WE-HAVE-EXACTLY.md`

### Product focus
`25-FOCUS-AND-IDENTITY.md`

### Repository ownership
`23-REPO-CONVERGENCE.md`

### OSS/IP boundary
`24-OSS-PROTECTION.md` plus prior Open-Core planning where compatible.

### Immediate proof
`22-FASTEST-POC.md` plus the August 2026 `lean-ctx evidence realworld` experiment.

This repository is a **new productization layer** over those sources. It intentionally distinguishes:
- audited current state,
- proposed canonical product direction,
- future product possibilities.

---

## Files

1. `00-VISION-AND-FOCUS.md`
2. `01-PRODUCT-ARCHITECTURE.md`
3. `02-SDK-RUNTIME-INTEGRATIONS.md`
4. `03-DYNO-EVIDENCE-AUTOTUNE.md`
5. `04-OSS-PAID-MONETIZATION.md`
6. `05-B2D-B2B-PLAYGROUND-GTM.md`
7. `06-BRAND-AND-WEBSITE.md`
8. `07-COMPETITIVE-MOAT.md`
9. `08-TECHNICAL-CONVERGENCE.md`
10. `09-ROADMAP-AND-BACKLOG.md`
11. `10-METRICS-CLAIMS-GOVERNANCE.md`
12. `11-SOURCE-MAP-AND-DECISIONS.md`

---

## One-page handoff

### What is LeanCTX?
**The Context SDK for AI Agents.**

### What does it do?
LeanCTX helps an existing agent select, represent, reuse, compress, recover and measure context so the agent can achieve accepted outcomes with less unnecessary compute.

### What is the current wedge?
Coding agents and custom agent workflows with measurable context/cost waste.

### What is the core proof?
Same task. Same model. Controlled baseline and treatment. Provider usage. Quality gate. Receipt.

### What is the business North Star?
**Verified cost per successful agent task.**

### What stays open?
A powerful local Runtime, SDK, integrations, local tuning, local profiles/kits and portable evidence.

### What becomes paid?
Continuous AutoTune, hosted benchmark capacity, private profiles/kits, shared evidence, organization economics, policy, access control and enterprise operation.

### What is Thinkery?
The company building and commercializing the organization-scale layer around LeanCTX.

### What do we explicitly not build now?
Generic Agent Builder, workflow canvas, CRM/voice automation, broad marketplace, massive hosted agent platform.

### Founder focus
The next existential proof is:

> **A real external customer pays for a verified tuning outcome.**
