# LeanCTX — executive synthesis

## Here is what LeanCTX is, what we have, what we build, and how we win

LeanCTX is a **context runtime and SDK for AI agents**. It makes an existing
agent workflow use less, better-selected context, then proves the economic and
quality outcome. It is not another agent framework and does not take over a
customer's orchestration or provider account. The buyer keeps provider
credentials (BYOK), the agent remains native, and LeanCTX supplies context
preparation, reusable kits, measurement, and a signed execution receipt.

The company is pursuing a narrow, credible wedge: Python + OpenAI Agents SDK,
one code-review reference workflow, and one paid customer pilot. The north-star
metric is **Verified Cost per Successful Agent Task (VCP-SAT)**: provider cost
divided by tasks that pass pre-agreed automated and human quality gates. Savings
count only when baseline and treatment are matched, provider prices and cache
treatment are pinned, quality passes, and a local verifier accepts the signed
evidence bundle. This converts a familiar “we reduce tokens” claim into a
financially defensible statement: lower cost with no quality regression.

### What we have

LeanCTX already has unusually strong building blocks for this position:

- A production-oriented Rust engine and accepted in-process SDK façade, with
  PathJail and explicit write/execute gates.
- A Python package with local proxy compression and LiteLLM, LangChain, and
  LlamaIndex adapters; an OCLA protocol/receipt/ledger model; and existing
  evidence, reporting, verification, and pilot-setup foundations.
- Context technology covering **27 languages**, **95+ compression patterns**,
  and **10 read modes**, protected by deterministic-output and compatibility
  discipline for Cursor, Codex, and Claude Code.
- A `kits/code-review` asset and a real five-turn reference benchmark: **78.9%
  lower billed cost**, **85.0% fewer prompt tokens**, and roughly an **80% cost
  reduction** (USD 0.26880 to USD 0.05670; 99,203 to 14,857 prompt tokens).

That benchmark is proof of potential, not a universal promise. The commercial
claim remains deliberately stricter: a customer must demonstrate at least **40%
lower VCP-SAT with no quality regression** on its own approved workload. The
gap between “about 80% in a reference workflow” and “40% verified customer
threshold” is a strength: it preserves credibility through variance, cache
effects, model changes, and hidden rework.

### What we build

The 60-day product commitment is `lean-ctx-sdk` v1.0 for one supported route:

```python
LeanCTX.wrap(agent, config)
```

It returns the unmodified native output plus a `LeanCtxRun` and a local,
offline-verifiable receipt. The promised primitives stay small: `prepare`,
`load_kit`, `receipt`, and `compare`. Every run either produces a signed,
verifiable receipt or explicitly reports `evidence_status=unavailable`; it
never invents usage, cost, or quality evidence. Default observe mode preserves
a successful native call when evidence infrastructure is unavailable; required
evidence mode fails closed before any commercial measurement.

The first product demonstration is stock versus LeanCTX-wrapped code review on
the same workload manifest, model/provider setting, budget, tests, and human
rubric. Its output is a simple proof chain: workload → baseline/treatment →
quality result → signed bundle → offline verification → executive report. Do
not spend the 90 days on a dashboard, hosted control plane, accounts,
marketplace, second framework adapter, or new agent orchestration. Open source
retains the local runtime, SDK, kits, receipts, and measurements; paid layers
come later only for shared evidence history, policies, private registry,
RBAC/SSO, fleet control, and SLA.

### How we win

We win through **verifiable economics in a tightly bounded workflow**, not a
generic “AI optimization platform” story. The initial customer is a Swiss
20–80-person B2B SaaS firm (with adjacent fintech, consultancy, and
industrial/B2B targets) that runs at least 100 coding-agent tasks each week.
The economic buyer is a CTO/VP Engineering; the operational champion is a
platform, developer-experience, or AI-engineering lead; Finance validates
provider prices and savings; Security approves a local, reversible BYOK setup.

Lead with a 15-minute evidence review, not a broad product demo. Target 30
accounts, qualify one named repetitive workflow and quality gate, then show the
reference workflow and its limitations. The customer pilot runs one workflow,
one team, and up to three matched tasks; it has a signed scope, redaction
preflight, local uninstall path, weekly one-page reports, and a Day-30
conversion meeting booked before installation. No raw prompts, source code,
credentials, or unapproved usage logs leave the agreed boundary.

**Canonical 90-day commercial offer:** CHF 7,500 prepaid for a 30-day Verified
Savings Pilot, BYOK, one workflow/team, up to three matched tasks, signed
baseline/treatment bundles, offline verifier, executive report, and conversion
recommendation. Credit 50% toward an annual agreement signed within 60 days.
This is the only pilot price to quote until Yves explicitly approves a post-pilot
price card. A free pilot is not a standard offer: it requires a written founder
exception with a named strategic return. This resolves the source-material
conflict and keeps the revenue objective real.

### Timeline, gates, and ask

| Window | Deliverable and decision |
|---|---|
| Days 1–30 | Freeze contract/evidence rules; build wrapper; prove quickstart, receipt, verification, rollback, and protected OSS smoke matrix; issue 30 targeted invitations. A Day-30 release is allowed only if every gate passes. |
| Days 31–60 | Harden the reference agent, run discovery/demos, close and onboard the paid pilot, and complete external SDK v1.0 no later than Day 60. A Day-30 v1.0 is an upside outcome, not permission to skip hardening. |
| Days 61–90 | Independently validate customer measurement, hold conversion decision, sell/onboard pilot #2 with the same repeatable process, and issue the Day-90 evidence/revenue decision memo. |

The target is **SDK v1.0 within 60 days** and **first revenue within 90 days**;
the operating plan is more ambitious, seeking prepaid CHF 7,500 around Days
45–51. Continue only if a paid customer, a reproducible customer bundle with
at least 40% lower VCP-SAT/no quality regression, an external quickstart,
healthy protected OSS paths, and under four founder-support hours per active
customer/week all hold. Otherwise keep OSS healthy, stop platform expansion,
and run one narrower paid proof cycle.

No external investment is a critical-path requirement for this experiment. The
immediate ask is founder focus: one technical owner, one commercial owner,
access to 30 qualified accounts, and one customer willing to pay for a bounded
measurement. Reassess financing only after Day 90, using actual conversion,
support, and repeatability data rather than a premature platform forecast.
