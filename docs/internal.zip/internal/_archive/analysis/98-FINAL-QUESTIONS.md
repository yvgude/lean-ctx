# Final questions for Yves

Resolve these in the stated order; each answer changes what the team can safely
build, sell, or promise.

## Immediate commercial decisions

1. **Pilot price:** Confirm CHF 7,500 prepaid as the default 30-day Founding
   Pilot, or explicitly authorize a limited free-design-partner exception.
   If an exception is allowed, what measurable strategic return makes it worth
   the lost revenue (named reference, distribution access, or annual commitment)?
2. **Post-pilot price card:** Choose one conversion model before any proposal:
   CHF 1,500/month for three months; CHF 2,500/month Foundation; CHF 5,000/month
   + 5% accepted savings Standard; or a capped 10% pure savings-share model.
   The current alternatives must not be shown together.
3. **Legal seller:** Is the counterparty Thinkery, LeanCTX, or another legal
   entity? Confirm Swiss VAT handling, invoice/payment terms, governing law,
   liability cap, privacy/DPA owner, and approved exit-clause wording.
4. **First-customer ICP:** Approve the overlap target: Swiss firm with 10–50
   developers, visible BYOK/API spend, >=100 coding-agent tasks/week, a CTO
   sponsor, finance validator, and an accessible non-production workflow.
5. **Reference-right trade:** What, if any, price concession is acceptable for a
   named case study, logo, or customer introduction after written approval?

## Product and evidence decisions

6. **v1.0 release posture:** Is Day 30 allowed to be an RC/early stable release
   with Day 60 as the hard external v1.0 deadline, or must Day 30 be the final
   GA? The recommended answer is Day-30 gate/RC, Day-60 hard v1.0.
7. **Supported SDK surface:** Confirm Python + OpenAI Agents SDK non-streaming
   `run` as v1.0. Are streaming, async parity, and a second adapter explicitly
   deferred unless the paid-demand gate is met?
8. **Evidence failure policy:** Approve `observe` mode (preserve a native agent
   call and state `evidence_status=unavailable`) and `required_evidence` mode
   (fail closed before commercial measurement). Who may override that policy?
9. **Quality authority:** What automated test and human-review method will be
   accepted, who names/calibrates reviewers, and who resolves a disputed score?
   Without this, VCP-SAT cannot be commercially decisive.
10. **Data boundary:** May pilot artifacts retain hashed/redacted prompts and
    source descriptors locally by default? Set retention duration, approved
    telemetry, installer checksum policy, proxy routing disclosure, and security
    escalation contact.

## Operating decisions

11. **Owners and capacity:** Name the single technical owner and commercial
    owner. Can each reserve the weekly capacity for build, five discovery calls,
    three demos, and pilot delivery without reducing protected OSS support?
12. **Day-70 demand gate:** Confirm that no second framework adapter is built
    until two paid/prepaid requests share it and represent >=CHF 10,000 annualized
    value. What qualifies as “paid/prepaid” evidence?
13. **Investment posture:** Is the operating plan funded through Day 90? If not,
    define the runway gap and whether customer prepayment, founder funding, or
    external capital is authorized. No fundraise should be required to begin the
    bounded pilot experiment.
