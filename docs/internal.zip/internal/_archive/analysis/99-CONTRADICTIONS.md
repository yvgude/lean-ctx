# Contradictions, missing links, and reality checks

## Canonical synthesis rule

The 90-day plan governs execution. Until Yves signs a replacement decision, the
external offer is **CHF 7,500 prepaid / 30 days / one workflow / BYOK**, with a
50% annual-contract credit. Customer savings claims require a signed,
matched, quality-passing, offline-verifiable evidence bundle. The reference
benchmark is described as roughly 80%, never guaranteed; the commercial proof
threshold is >=40% lower VCP-SAT with no quality regression.

## Direct contradictions

| Topic | 90-day plan | Customer playbook | Resolution required for consistency |
|---|---|---|---|
| Pilot price | CHF 7,500 prepaid; no zero-cost exception without written founder decision | CHF 0 30-day founding PoV for up to three partners | Canonical: paid CHF 7,500 pilot. Free PoV becomes a founder-only documented exception, never outreach default. |
| First revenue | Customer #1 pays in Week 7; Day-90 DoD requires CHF 7,500 paid | The first customer may receive a free PoV and convert later | Revenue target takes precedence. A free lighthouse cannot count as customer #1 for the Day-90 revenue objective. |
| Conversion price | CHF 1,500/month for three months is proposed only if evidence and support economics justify it | Foundation CHF 2,500/month; Standard CHF 5,000/month + 5% savings; optional pure 10% savings share | Do not quote any continuation price until a single post-pilot price card is approved. The figures cannot coexist in one proposal. |
| Customer segment | 20–80-person B2B SaaS company, >=100 coding-agent tasks/week | Swiss 50–500-person firms, 10–50 developers across three verticals | Use the overlap for first 90 days: Swiss B2B SaaS/fintech/consulting/industrial firm, 10–50 developers, visible BYOK/API spend, >=100 repeated coding-agent tasks/week. |
| SDK timing | v1.0 release decision on Day 30 | No SDK delivery date | Treat Day 30 as an early-release gate and Day 60 as the external v1.0 commitment. Do not call a Day-30 build stable if quickstart/customer hardening remains incomplete. |
| Product language | Local runtime/SDK/evidence first; no dashboard/control plane | “aggregate dashboard/ledger” appears in PoV scope | Offer a local/shared evidence artifact and ledger, not a new hosted dashboard, during the 90-day window. |
| Brand/legal party | LeanCTX throughout | Exit clause refers to “Thinkery” | Identify the contracting legal entity and use it consistently in every SOW, invoice, privacy note, and exit clause. |

## Missing links

- **Legal and tax:** no confirmed legal entity, Swiss VAT treatment, invoice terms,
  governing law, liability cap, DPA, or security annex. “CHF excluding VAT” is
  not enough to invoice safely.
- **Evidence schema bridge:** the plan directs reuse of OCLA and existing
  verifier/evidence code, but no published mapping yet links `LeanCtxRun`,
  receipt status, workload manifest, signature format, and VCP-SAT calculation.
- **Provider data feasibility:** the plan assumes provider prompt, cached-input,
  and completion usage for the selected Agents SDK path. Validate exact response
  shapes and price snapshot provenance before promising verified VCP-SAT.
- **Human-quality gate operations:** reviewer identity, calibration, turnaround,
  dispute path, and cost are unspecified. A required human decision can become
  the pilot bottleneck.
- **Customer security package:** the playbook needs a one-pager covering local
  proxy behavior, outbound connections, logs, retention, redaction, installer
  checksum, incident contact, and uninstall verification.
- **Acquisition capacity:** 30 accounts, 15 invitations, discovery calls, demos,
  build work, and a Week-7 close require named owners and calendar capacity;
  the plans state roles but no actual people or pipeline conversion assumptions.
- **Open-core boundary:** later paid capabilities are named but the entitlement,
  hosting, support, and data-residency architecture is intentionally not designed.
  That is correct for now, but sales must not imply it already exists.

## Reality checks

- The plan is aggressive but not inherently impossible: it restricts v1 to one
  adapter and reuses real engine/evidence assets. It becomes implausible if
  streaming parity, a second framework, dashboard work, or custom security
  architecture enters scope before the Day-70 demand gate.
- A signed receipt proves the captured data and comparison process, not that the
  customer will realize organization-wide savings. Constrain every claim to the
  matched workload and reporting window.
- A 40% VCP-SAT gain requires both measured cost reduction and quality passing.
  If provider cache behavior changes or reviewers reject treatment output,
  savings may be zero even when token volume falls sharply.
- A first paid pilot by Days 45–51 requires payment authority and a simple buying
  path. Treat the stated Day-90 first-revenue deadline as the commitment;
  maintain multiple qualified prospects rather than assuming the first one
  clears procurement.
- “No external investment needed” is valid only while founders can supply the
  technical and sales capacity. Do not convert it into a claim that the company
  needs no operating runway.
