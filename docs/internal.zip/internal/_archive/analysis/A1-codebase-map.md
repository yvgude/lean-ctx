# lean-ctx definitive codebase map

Source-backed reference for the repository working tree. Line counts are physical lines (`wc -l`) and test counts are static Rust `#[test]`/`#[tokio::test]` markers; generated/vendor artifacts are labelled explicitly.

## 1. Architecture at a glance

```text
CLI / hooks / editor integrations ─┬─ shell execution + compression pipeline
                                 ├─ MCP stdio server + HTTP server + tool registry
                                 ├─ Context Engine: read/search/index/cache/knowledge/session/graph
                                 ├─ Gateway proxy: request interception, compression, metering, routing
                                 └─ OCLA contracts / SDKs / adapters / provider bridges
```

| Layer | Primary paths | Responsibility |
|---|---|---|
| Binary & library | `rust/src/main.rs`, `rust/src/lib.rs` | Crash/TCC guards then CLI dispatch; library exposes all runtime subsystems. |
| Context engine | `rust/src/core/` | Compression, memory, retrieval, graph, policy, persistence, provider and session mechanics. |
| Interfaces | `rust/src/cli/`, `rust/src/tools/`, `rust/src/server/`, `rust/src/http_server.rs` | CLI, MCP tools/dispatch, stdio/HTTP serving. |
| Command interception | `rust/src/shell/`, `rust/src/hook_handlers/`, `rust/src/rewrite_registry.rs` | Wraps shell/editor actions and safely reduces output. |
| Gateway | `rust/src/proxy/`, `rust/src/proxy_setup/` | Reverse proxy for LLM traffic and per-client installation. |
| Stable contracts | `rust/crates/lean-ctx-ocla`, `rust/crates/lean-ctx-protocol`, `rust/crates/lean-ctx-sdk` | Public OCLA, wire protocol, and in-process Rust facade. |
| External clients | `clients/`, `packages/`, `cookbook/sdk/` | HTTP/OCLA/CLI clients and framework/transport adapters. |

## 2. Rust crates and public API

| Crate / path | Role | Rust files | LOC | Static test markers | Root public API |
|---|---|---:|---:|---:|---|
| `lean-ctx (workspace root)` | Main engine crate and lean-ctx binary; default workspace member. | 1977 | 613933 | 10556 | mod compound_lexer;mod core;mod daemon;mod daemon_autostart;mod daemon_client;mod dashboard;mod dropin;mod engine;mod heatmap;mod hook_handlers;mod hooks;mod instructions;mod lsp;mod marked_block;mod mcp_stdio;mod rewrite_registry;mod rules_inject;mod server;mod shell;mod shell_hook;mod terminal_ui;mod token_report;mod tool_defs;mod tools;mod tui;mod proxy;mod proxy_autostart;mod proxy_setup;mod cloud_client;mod cloud_sync;mod http_server;mod cli;mod config_io;mod doctor;mod ipc;mod kits;mod report;mod setup;mod status;mod test_env;mod uninstall;mod wrap; |
| `lean-ctx-ocla` | Stable provider-neutral OCLA token/context lifecycle contract boundary. | 6 | 1508 | 11 | mod traits;mod types;use traits::*;use types::*; |
| `lean-ctx-protocol` | Open wire contracts: events, observations, assignments, evidence gaps. | 25 | 3906 | 45 | mod savings;mod auto_routing;mod circuit_breaker;mod control_plane;mod decision;mod eligibility;mod fleet_control;mod knowledge;mod knowledge_routing;mod outcome;mod outcome_engine;mod rollout;mod triage;mod value_share;use capability::*;use common::*;use control_plane::*;use decision::*;use evidence::{EvidenceKind, EvidenceRefV1, SignatureStatus};use execution::*;use experiment::{DataClassification, ExperimentArm, ExperimentAssignmentV1, SideEffectPolicy};use fleet_control::*;use gap::{BillingPeriodStatus, EvidenceGapClosedV1, EvidenceGapOpenedV1, GapReason};use knowledge::{ClassificationLevel, KnowledgeObjectV1, ValidityWindow};use knowledge_routing::{;use money::{CurrencyCode, MoneyV1};us |
| `lean-ctx-sdk` | In-process embedding facade over engine read/search/compression/token APIs. | 11 | 969 | 12 | mod addon;mod compress;mod engine;mod error;mod hash;mod output;mod read;mod tokens;use engine::{Engine, EngineBuilder};use error::Error;use output::Output;use read::ReadMode; |
| `grammar-addon-lua` | cdylib Tree-sitter Lua grammar loaded dynamically by signatures_ts. | 1 | 16 | 0 | — |
| `rmcp (vendored)` | Vendored upstream Rust SDK for Model Context Protocol; dependency, not a workspace member. | 116 | 45156 | 572 | use error::{Error, ErrorData, RmcpError};mod model;mod service;use handler::client::ClientHandler;use handler::server::ServerHandler;use handler::server::wrapper::Json;use service::{Peer, Service, ServiceError, ServiceExt};use service::{RoleClient, serve_client};use service::{RoleServer, serve_server};mod handler;mod task_manager;mod transport;use pastey::paste;use rmcp_macros::*;use schemars;use serde;use serde_json; |
| `rmcp-macros (vendored)` | Vendored upstream proc-macro companion for rmcp; dependency, not a workspace member. | 9 | 2017 | 14 | fn tool;fn tool_router;fn tool_handler;fn prompt;fn prompt_router;fn prompt_handler;fn task_handler; |
| `grammar-dlopen-spike-host (experiment)` | Manual verification host for grammar addon dlopen design; workspace member but not release pipeline. | 1 | 55 | 0 | — |

### Crate notes

- Workspace members are declared in `rust/Cargo.toml`; `default-members = ["."]`, so normal build/test commands target the engine unless `--workspace` or `-p` is supplied.
- `lean-ctx-sdk` intentionally disables the engine jemalloc default so embedding does not impose a global allocator. Its root exports are `Engine`, `EngineBuilder`, `ReadMode`, `Output`, `Error`, compression helpers, token counting, hashing, and addon audit/scaffold types.
- `lean-ctx-ocla` is the stable contract boundary; `lean-ctx-protocol` provides the public wire-level event/observation/assignment types used across that boundary.

## 3. `rust/src/core/`: complete domain map

The core root is explicitly ordered by domain in `rust/src/core/mod.rs`: Compression; Memory; Graph; Context; Knowledge; Search & Retrieval; Session & Handoff; Attention & Placement; Neural/ML; Patterns & Shell; Agents/A2A; Adaptive & Scoring; Diagnostics & Quality; Config & Infrastructure.

| Domain from `core/mod.rs` | Direct modules |
|---|---|
| Compression | `adaptive_chunking`, `adaptive_compression`, `addons`, `attention_context`, `codebook`, `cognitive`, `compressor`, `context_prefetch`, `entropy`, `etpao`, `eval_ab`, `eval_harness`, `finops_export`, `fleet_analytics`, `html_crush`, `ib`, `information_bottleneck`, `json_crush`, `tabular_crush`, `yaml_crush`, `structural_tokenizer`, `verbosity`, `wasserstein`, and related rules/preservation modules. |
| Memory | `anti_interrupt`, `episodic_memory`, `interrupt`, `memory_archive`, `memory_guard`, `memory_lifecycle`, `memory_policy`, `memory_scheduler`, `multiscale_index`, `procedural_memory`. |
| Graph | `call_graph`, `community`, `gamma_cover`, `graph_context`, `graph_expand`, `graph_export`, `graph_features`, `graph_index`, `graph_provider`, `property_graph`. |
| Context | `context_artifacts`, `context_column`, `context_deficit`, `context_field`, `context_handles`, `context_ir`, `context_kernel`, `context_ledger`, `context_os`, `context_overhead`, `context_overlay`, `context_policies`, `context_proof_v2`, `context_radar`, cross-customer/source modules. |
| Knowledge | `claim_extractor`, `execution_ledger`, `knowledge`, `knowledge_bridge`, `knowledge_embedding`, `knowledge_provider_extract`, `knowledge_relations`, `knowledge_router`, `outcome`, `trust`. |
| Search & retrieval | `bm25_cache`, `bm25_index`, `content_cache`, `content_chunk`, `cooccurrence`, `dense_backend`, `embedding_index`, `embeddings`, `energy`, `hybrid_search`, `search_reranking`, `semantic_cache`, `semantic_chunks`, `spreading_activation`. |
| Session / attention / ML | `session`; `attention_layout_driver`, `attention_model`, `attention_placement`, `litm`; `neural`. |
| Agents & scoring | `a2a`, `autonomy_drivers`, `canonical`, `stigmergy`; `adaptive`, thresholds, bandits, decision loop, calibration, model routing, shadow, task relevance/spine. |
| Diagnostics & quality | anomaly, benchmark compare, billing, code health/load, conformance/contracts, cost-per-outcome, degradation/loop detection, output verification, quality/scorecard, setup report, surprise. |
| Infrastructure | agents, cache, config, consolidation, data/paths, evidence, editor, index/ingestion, MCP catalog/manifest, OCLA, providers, security, token/tool profile, telemetry, triage, web, workflow, and the remaining source modules catalogued below. |

### Core subdirectories (every recursive source directory)

| Directory | Purpose | Rust files | LOC | Static test markers |
|---|---|---:|---:|---:|
| `rust/src/core/a2a` | Agent-to-agent envelopes, identity/cards, budgets, compatibility, and compression. | 15 | 3312 | 60 |
| `rust/src/core/addons` | Grammar addon lifecycle, manifests, audit, package/load, and capability checks. | 29 | 8323 | 202 |
| `rust/src/core/agents` | Agent registry, leases, directives, presence, and bus coordination. | 9 | 1844 | 28 |
| `rust/src/core/anti_interrupt` | Interrupt prevention/recovery and task continuation guards. | 3 | 399 | 8 |
| `rust/src/core/benchmark_compare` | Benchmark execution, comparisons, study/task definitions, and quality scoring. | 5 | 1136 | 17 |
| `rust/src/core/benchmark_study` | Benchmark execution, comparisons, study/task definitions, and quality scoring. | 19 | 2077 | 36 |
| `rust/src/core/benchmark_study/datasets` | Focused subsystem; see its complete source-file inventory below. | 5 | 242 | 3 |
| `rust/src/core/benchmark_study/metrics` | Focused subsystem; see its complete source-file inventory below. | 4 | 135 | 10 |
| `rust/src/core/benchmark_study/stats` | Focused subsystem; see its complete source-file inventory below. | 3 | 157 | 5 |
| `rust/src/core/billing` | Usage, cost, savings, financial exports, and outcome scorecards. | 5 | 2724 | 30 |
| `rust/src/core/billing/settlement_evidence` | Focused subsystem; see its complete source-file inventory below. | 2 | 2114 | 14 |
| `rust/src/core/bm25_index` | Sparse/dense retrieval indexes, embeddings, and optional neural backends. | 5 | 2966 | 34 |
| `rust/src/core/buddy` | Pet/mascot runtime and Godot integration assets/logic. | 9 | 1888 | 22 |
| `rust/src/core/cache` | Shared cache, diagnostics, invalidation, and reuse accounting. | 7 | 2647 | 58 |
| `rust/src/core/code_health` | Code-quality signals, smells, and health reports. | 13 | 2291 | 55 |
| `rust/src/core/codesign` | macOS binary signing/verification support. | 2 | 386 | 4 |
| `rust/src/core/cognitive` | Cognitive load/context-quality modeling. | 2 | 463 | 8 |
| `rust/src/core/community` | Code/knowledge graph construction, algorithms, expansion, and graph-backed retrieval. | 6 | 1289 | 10 |
| `rust/src/core/compliance_report` | Compliance evidence, provenance, trust decisions, and value/safety gates. | 5 | 1567 | 23 |
| `rust/src/core/config` | TOML model, defaults, merge/load/set logic, validation schema, and config tests. | 48 | 14999 | 302 |
| `rust/src/core/config/schema` | Focused subsystem; see its complete source-file inventory below. | 4 | 3191 | 6 |
| `rust/src/core/context_kernel` | Context Kernel contracts, envelope/evidence wiring, health, policy, lifecycle, and E2E integration. | 85 | 19232 | 501 |
| `rust/src/core/context_ledger` | Durable context accounting/ledger operations. | 6 | 1504 | 38 |
| `rust/src/core/context_os` | Context OS orchestration and operating-model primitives. | 5 | 1678 | 12 |
| `rust/src/core/context_package` | Context package creation, import/export, and transfer. | 19 | 6773 | 115 |
| `rust/src/core/context_prefetch` | Predictive context prefetching. | 2 | 212 | 2 |
| `rust/src/core/context_snapshot` | Snapshot/restore of context state. | 8 | 1660 | 33 |
| `rust/src/core/contextops` | Context operations automation and operational workflows. | 5 | 1219 | 36 |
| `rust/src/core/deep_queries` | Deep/multi-stage codebase and knowledge queries. | 7 | 3574 | 56 |
| `rust/src/core/editor_registry` | Editor integration registry and config writers. | 26 | 5879 | 84 |
| `rust/src/core/editor_registry/writers` | Focused subsystem; see its complete source-file inventory below. | 21 | 3860 | 54 |
| `rust/src/core/editor_registry/writers/install` | Focused subsystem; see its complete source-file inventory below. | 17 | 1772 | 1 |
| `rust/src/core/embeddings` | Sparse/dense retrieval indexes, embeddings, and optional neural backends. | 5 | 2698 | 63 |
| `rust/src/core/eval_ab` | Focused subsystem; see its complete source-file inventory below. | 15 | 4913 | 74 |
| `rust/src/core/eval_ab/testbench` | Focused subsystem; see its complete source-file inventory below. | 5 | 1136 | 18 |
| `rust/src/core/execution_ledger` | Execution receipts and command/tool lifecycle accounting. | 6 | 1092 | 5 |
| `rust/src/core/extractive` | Extractive summarization and content-specific extractors. | 4 | 797 | 13 |
| `rust/src/core/extractors` | Extractive summarization and content-specific extractors. | 4 | 662 | 19 |
| `rust/src/core/finops_export` | Usage, cost, savings, financial exports, and outcome scorecards. | 5 | 1093 | 20 |
| `rust/src/core/gain` | Usage, cost, savings, financial exports, and outcome scorecards. | 8 | 2837 | 49 |
| `rust/src/core/git` | Git-aware context, metadata, and repository helpers. | 4 | 950 | 18 |
| `rust/src/core/godot` | Pet/mascot runtime and Godot integration assets/logic. | 2 | 128 | 4 |
| `rust/src/core/gotcha_tracker` | Recurring failure/gotcha detection and retrieval. | 8 | 2660 | 46 |
| `rust/src/core/graph_analysis` | Code/knowledge graph construction, algorithms, expansion, and graph-backed retrieval. | 5 | 799 | 19 |
| `rust/src/core/graph_expand` | Code/knowledge graph construction, algorithms, expansion, and graph-backed retrieval. | 3 | 315 | 8 |
| `rust/src/core/graph_index` | Code/knowledge graph construction, algorithms, expansion, and graph-backed retrieval. | 4 | 3234 | 58 |
| `rust/src/core/ib` | Information-bottleneck compression algorithms. | 3 | 394 | 8 |
| `rust/src/core/import` | Import parsing and cross-file/module resolution. | 4 | 730 | 1 |
| `rust/src/core/import_resolver` | Import parsing and cross-file/module resolution. | 3 | 2092 | 51 |
| `rust/src/core/input_filters` | Input eligibility/safety filters before processing. | 4 | 886 | 29 |
| `rust/src/core/knowledge` | Persistent knowledge objects, facts, relations, extraction, and route selection. | 17 | 5681 | 71 |
| `rust/src/core/knowledge_router` | Persistent knowledge objects, facts, relations, extraction, and route selection. | 11 | 1420 | 34 |
| `rust/src/core/locomo` | LoCoMo benchmark integration and evaluation helpers. | 4 | 477 | 3 |
| `rust/src/core/mcp_catalog` | Remote MCP catalog, adapter pool, post-processing, and routing. | 17 | 3294 | 68 |
| `rust/src/core/mcp_catalog/adapters` | Focused subsystem; see its complete source-file inventory below. | 6 | 894 | 18 |
| `rust/src/core/mcp_catalog/postprocess` | Focused subsystem; see its complete source-file inventory below. | 4 | 382 | 10 |
| `rust/src/core/mdl_mode` | Minimum-description-length mode/selector support. | 3 | 422 | 7 |
| `rust/src/core/measurement` | Measurement models and calibration. | 5 | 533 | 5 |
| `rust/src/core/memory_scheduler` | Memory lifecycle/scheduling policy. | 3 | 347 | 10 |
| `rust/src/core/neural` | Sparse/dense retrieval indexes, embeddings, and optional neural backends. | 6 | 1548 | 20 |
| `rust/src/core/ocla` | Open Context & Token Lifecycle Architecture runtime, types, bus, and bridges. | 64 | 20621 | 325 |
| `rust/src/core/ocla/adapters` | Focused subsystem; see its complete source-file inventory below. | 4 | 750 | 8 |
| `rust/src/core/ocla/builtin` | Focused subsystem; see its complete source-file inventory below. | 17 | 4475 | 112 |
| `rust/src/core/ocla/reference_adapters` | Focused subsystem; see its complete source-file inventory below. | 6 | 2569 | 9 |
| `rust/src/core/outcome` | Outcome/quality measurement and verification. | 5 | 1551 | 10 |
| `rust/src/core/patterns` | Command/output-specific compression patterns and structural transforms. | 84 | 17874 | 264 |
| `rust/src/core/patterns/git` | Focused subsystem; see its complete source-file inventory below. | 6 | 1718 | 37 |
| `rust/src/core/plugins` | Plugin discovery, manifests, runtime registration, and policy. | 6 | 1582 | 34 |
| `rust/src/core/policy` | Policy definitions, enforcement, evaluation, and safety controls. | 9 | 2572 | 39 |
| `rust/src/core/policy/org` | Focused subsystem; see its complete source-file inventory below. | 4 | 604 | 9 |
| `rust/src/core/profiles` | Context/tool profile definitions and selection. | 5 | 1474 | 16 |
| `rust/src/core/property_graph` | Code/knowledge graph construction, algorithms, expansion, and graph-backed retrieval. | 11 | 2790 | 35 |
| `rust/src/core/provenance` | Compliance evidence, provenance, trust decisions, and value/safety gates. | 5 | 875 | 9 |
| `rust/src/core/providers` | External provider registry, config, OAuth, health, and execution adapters. | 20 | 6250 | 116 |
| `rust/src/core/providers/config_provider` | Focused subsystem; see its complete source-file inventory below. | 5 | 1711 | 38 |
| `rust/src/core/quality_benchmark` | Benchmark execution, comparisons, study/task definitions, and quality scoring. | 1 | 170 | 9 |
| `rust/src/core/quality_lab` | Experimental quality analysis/lab workflows. | 5 | 1380 | 37 |
| `rust/src/core/repomap` | Repository-map generation and codebase orientation. | 4 | 696 | 14 |
| `rust/src/core/savings_ledger` | Usage, cost, savings, financial exports, and outcome scorecards. | 10 | 4849 | 75 |
| `rust/src/core/scorecard` | Usage, cost, savings, financial exports, and outcome scorecards. | 3 | 914 | 12 |
| `rust/src/core/sensitivity` | Sensitivity/impact analysis. | 2 | 597 | 19 |
| `rust/src/core/session` | Session state, persistence, lifecycle, and compact summaries. | 8 | 2957 | 48 |
| `rust/src/core/session_summary` | Session state, persistence, lifecycle, and compact summaries. | 5 | 625 | 5 |
| `rust/src/core/shadow` | Shadow-mode comparisons and counterfactual reporting. | 8 | 825 | 18 |
| `rust/src/core/shell_allowlist` | Shell command policy, allowlist matching, and tests. | 16 | 5573 | 257 |
| `rust/src/core/sidecar_transport` | Sidecar/IPC transport for context exchange. | 4 | 211 | 4 |
| `rust/src/core/signatures_ts` | Tree-sitter signatures, grammar loading, and language-specific symbol extraction. | 20 | 2964 | 37 |
| `rust/src/core/signatures_ts/handlers` | Focused subsystem; see its complete source-file inventory below. | 12 | 784 | 0 |
| `rust/src/core/skillify` | Skill discovery/generation and packaging. | 4 | 741 | 11 |
| `rust/src/core/stats` | Telemetry counters, aggregation, and reporting. | 8 | 3425 | 33 |
| `rust/src/core/stats/format` | Focused subsystem; see its complete source-file inventory below. | 5 | 1831 | 9 |
| `rust/src/core/stigmergy` | Shared indirect coordination signals for agents. | 1 | 103 | 0 |
| `rust/src/core/task_benchmark` | Benchmark execution, comparisons, study/task definitions, and quality scoring. | 5 | 2060 | 27 |
| `rust/src/core/terse` | Terse/compression formatting engine and MCP integration. | 10 | 2308 | 78 |
| `rust/src/core/triage` | Issue/error triage and prioritization. | 17 | 1915 | 35 |
| `rust/src/core/triage/distillation` | Focused subsystem; see its complete source-file inventory below. | 4 | 362 | 0 |
| `rust/src/core/trust` | Compliance evidence, provenance, trust decisions, and value/safety gates. | 6 | 1164 | 0 |
| `rust/src/core/value_gate` | Compliance evidence, provenance, trust decisions, and value/safety gates. | 6 | 785 | 20 |
| `rust/src/core/verbosity` | Adaptive output verbosity control. | 5 | 604 | 12 |
| `rust/src/core/wasserstein` | Wasserstein-distance analysis for distributions/quality. | 3 | 353 | 8 |
| `rust/src/core/web` | Web fetch/read/search helpers and web-context processing. | 10 | 3998 | 83 |
| `rust/src/core/workflow` | Workflow definitions and orchestration. | 4 | 450 | 0 |

### Context Kernel focus (`rust/src/core/context_kernel/`)

This is the densest core subpackage: envelope bridge/wiring/E2E, ETAPO live execution, evidence bundles/hooks/wiring, fail matrix, feedback, health/API, identity resolution, invalidation, kernel config, knowledge health, hot-path wiring, and integration E2E. The full file inventory gives the exact modules and LOC.

## 4. CLI: commands, subcommands, and source layout

CLI entry: `rust/src/main.rs` installs macOS TCC seatbelt and panic logging, then calls `cli::dispatch::run()`. `rust/src/cli/dispatch/mod.rs` is the authoritative top-level router.

### Code-derived top-level dispatcher arms (aliases preserved)

```text
"-c" | "exec" => handle_exec(&args, &rest), "-t" | "--track" => handle_track(&args), "badge" => { "shell" | 
"--shell" => { "gain" => { "spend" => { "savings" => { "learning" => { "conformance" | "selftest" => { "health" => 
{ "quality-lab" | "quality_lab" => { "billing" => { "finops" => { "roi" => { "output-savings" | "output_savings" 
=> { "value-report" | "value_report" => { "evidence-export" => { "evidence" => { "shadow" => { "triage" => { 
"scenario" => { "measure" => { "token-report" | "report-tokens" => { "pack" => { "policy" => { "plugin" | 
"plugins" => { "addon" | "addons" => { "embeddings" => { "model" => { "enable-gpu" | "gpu" => { "rules" => { 
"proof" => { "prove" => { "snapshot" => { "verify" => { "eval" => { "verify-cache" | "cache-selftest" => { 
"visualize" => { "audit" => { "compliance" => { "agent" => { "instructions" => { "index" => { "semantic-search" | 
"search-code" => { "explore" => { "repomap" | "repo-map" => { "cep" => { "demo" => { "dashboard" => { "team" => { 
"provider" => { "serve" => { "watch" => { "proxy" => { "daemon" => { "init" => { "setup" => { "onboard" => { 
"install" => { "bootstrap" => { "wrap" => { "unwrap" => { "status" => { "cognitive" => { "read" => { "call" => { 
"diff" => { "grep" => { "glob" => { "find" => { "ls" => { "deps" => { "discover" => { "ghost" => { "filter" => { 
"heatmap" => { "graph" => { "smells" => { "session" => { "ledger" => { "ocla" => { "control" | "context-control" 
=> { "plan" | "context-plan" => { "compile" | "context-compile" => { "import" => { "checkpoints" => { "knowledge" 
=> { "kit" | "kits" => { "skillify" => { "summary" => { "overview" => { "compress" => { "wrapped" => { "sessions" 
| "session-store" => { "benchmark" => { "compact" => { "profile" => { "tools" => { "config" => { "allow" => { 
"security" => { "yolo" => { "secure" | "lockdown" => { "trust" => { "untrust" => { "stats" => { "introspect" => { 
"cache" => { "theme" => { "enterprise" => { "tee" => { "terse" | "compression" => { "slow-log" => { "debug-log" => 
{ "editor-signal" => { "editor-session" => { "update" | "--self-update" => { "restart" => { "stop" => { 
"dev-install" => { "codesign-setup" => { "doctor" => { "harden" => { "export-rules" => { "completions" => { 
"__complete" => { ```

| Command families | Commands / delegated source |
|---|---|
| Execution & interception | `-c`/`exec`, `-t`/`--track`, `shell`, `raw`/`bypass`, `read`, `grep`, `glob`, `find`, `ls`, `diff`, `deps`, `filter`, `wrap`, `unwrap`, `hook`, `editor-signal`, `editor-session`. |
| Context & retrieval | `compose`-adjacent CLI functionality via `read`, `semantic-search`/`search-code`, `explore`, `repomap`, `context-control`/`control`, `context-plan`/`plan`, `context-compile`/`compile`, `knowledge`, `session`, `sessions`, `ledger`, `index`, `import`, `summary`, `overview`, `compress`, `snapshot`, `checkpoints`. |
| Operations | `init`, `setup`, `onboard`, `install`, `bootstrap`, `status`, `doctor`, `health`, `daemon`, `proxy`, `serve`, `watch`, `restart`, `stop`, `dev-install`, `update`, `codesign-setup`, `uninstall`. |
| Policy/admin | `config`, `allow`, `security`, `secure`/`lockdown`, `yolo`, `trust`, `untrust`, `harden`, `policy`, `compliance`, `audit`, `verify`, `verify-cache`, `proof`, `prove`, `agent`, `instructions`, `plugins`, `addon`, `pack`, `rules`, `profile`, `tools health`. |
| Measurement | `gain`, `spend`, `savings`, `roi`, `output-savings`, `value-report`, `billing`, `finops`, `stats`, `cep`, `measure`, `benchmark`, `quality-lab`, `conformance`/`selftest`, `shadow`, `triage`, `smells`, `heatmap`, `graph`, `visualize`, `token-report`. |
| Integrations | `provider`, `team`, `cloud`, `login`, `register`, `sync`, `telemetry`, `enterprise`, `embeddings`, `model`, `skillify`, `kit`, `completions`; client-specific proxy wiring lives in `rust/src/proxy_setup/`. |

Nested command parsers are intentionally distributed: `agent_cmd.rs` documents `register/list/show/heartbeat/suspend/resume`; `dispatch/lifecycle.rs` owns daemon lifecycle; `dispatch/network/{proxy,provider,team}.rs` owns gateway/provider/team; `dispatch/evidence.rs` defines `run/workflow/realworld/report/inspect`; addon and pack have their own subpackages. The full CLI inventory below maps every implementation file.

## 5. Shell compression engine (`rust/src/shell/`)

Flow: `shell::exec` classifies the command; passthrough inherits the terminal, otherwise buffered execution spawns a profile-free shell, relays piped stdin, applies bounded timeout/output limits, decodes and joins streams, records diagnostics/lifecycle data, redacts/persists tee data when needed, then compresses and emits deterministic output.

| Component | Files / behavior |
|---|---|
| Execution | `exec/execution.rs`, `process.rs`, `timeout.rs`: shell selection, process groups, stdin relay, bounded wait/output, exit-code preserving stream combination. |
| Policy | `output_policy.rs`, `compress/classification.rs`, `compress/passthrough.rs`: classify passthrough/verbatim/compressible/structural output; honor excluded commands and protected spans. |
| Compression | `compress/engine.rs`: token-floor gate; command patterns; lossless JSON/CSV/TSV/YAML/HTML crushers; optional lossy high-entropy-column drops only with content-addressed `ctx_expand` recovery. Successful test output gets structural compression; failed output retains diagnostics. |
| Safety | `redact.rs`, `tee_policy.rs`, `reentry.rs`, `agent_wrapper.rs`: secret redaction, 24h redacted tee logs, nested invocation prevention, and agent wrapper behavior. |
| Presentation | `compress/boundaries.rs`, `footer.rs`, `pipeline.rs`, `interactive.rs`, `platform.rs`: deterministic savings footer, terminal/platform normalization, TTY behavior. |

Compression is guarded by token-savings floors (normally 120 tokens; lower for tests/git/data tooling), structural/verbatim protection, and no-loss failure handling. The engine recomputes savings after protected-span splicing, preserving byte stability for provider prompt caching.

## 6. MCP tools and server

Tool registration is `rust/src/tools/registered/mod.rs`; server dispatch and access controls are in `rust/src/server/`. The tool list below uses registered module files; it is the durable source map even when a runtime tool profile hides a tool.

| Category | Tools |
|---|---|
| Orientation & reads | `ctx_compose`, `ctx_read`, `ctx_multi_read`, `ctx_smart_read`, `ctx_url_read`, `ctx_glob`, `ctx_tree`, `ctx_search`, `ctx_semantic_search`, `ctx_symbol`, `ctx_outline`, `ctx_repomap`, `ctx_explore`, `ctx_architecture`, `ctx_callgraph`, `ctx_impact`, `ctx_git_read`. |
| Execution & changes | `ctx_shell`, `ctx_execute`, `ctx_edit`, `ctx_patch`, `ctx_refactor`, `ctx_compile`, `ctx_verify`, `ctx_review`, `ctx_call`. |
| Compression & recovery | `ctx_compress`, `ctx_compress_memory`, `ctx_crush`, `ctx_dedup`, `ctx_delta`, `ctx_expand`, `ctx_fill`, `ctx_preload`, `ctx_prefetch`, `ctx_cache`, `ctx_index`, `ctx_retrieve`, `ctx_transcript_compact`. |
| Knowledge & session | `ctx_knowledge`, `ctx_ledger`, `ctx_memory`, `ctx_session`, `ctx_checkpoint`, `ctx_handoff`, `ctx_share`, `ctx_agent`, `ctx_task`, `ctx_context`, `ctx_live_zone`. |
| Analysis & planning | `ctx_analyze`, `ctx_compare`, `ctx_plan`, `ctx_optimize`, `ctx_multi_repo`, `ctx_quality`, `ctx_quality_lab`, `ctx_smells`, `ctx_benchmark`, `ctx_perf`, `ctx_proof`, `ctx_graph`, `ctx_routes`, `ctx_overview`, `ctx_summary`. |
| Operations & observability | `ctx_control`, `ctx_tools`, `ctx_discover`, `ctx_discover_tools`, `ctx_load_tools`, `ctx_plugins`, `ctx_provider`, `ctx_pack`, `ctx_package`, `ctx_workflow`, `ctx_skillify`, `ctx_rules`, `ctx_metrics`, `ctx_cost`, `ctx_gain`, `ctx_radar`, `ctx_heatmap`, `ctx_feedback`, `ctx_intent`, `ctx_response`, `ctx_artifacts`. |

Server support files include call dispatch, capability/role guards, permission inheritance, dynamic tool/profile filtering, bounded locking, response handling, and HTTP/stdio bridges. `ctx_shell` and `ctx_read` are multi-file implementations under `rust/src/tools/ctx_shell/` and `rust/src/tools/ctx_read/`; direct modules provide specialized read/edit/impact/knowledge behavior.

## 7. SDKs, clients, and adapters

| Surface | Paths | Purpose |
|---|---|---|
| In-process Rust SDK | `rust/crates/lean-ctx-sdk/src/{engine,read,compress,tokens,output,hash,addon,error}.rs` | Stable embedder facade; engine handle/session cache, read modes, compression/tokenization, deterministic hashing, addon author/audit. |
| Stable Rust HTTP client | `clients/rust/lean-ctx-client/` | Blocking `/v1` client, event SSE iterator, conformance checks, tool-text adapter, offline OCLA verification; no engine linkage. |
| Python HTTP/OCLA SDK | `clients/python/leanctx/` | Dependency-free urllib `/v1` client, OCLA verifier/types, conformance, and LangChain/OpenAI/LlamaIndex/CrewAI adapters. |
| Python CLI/framework package | `packages/python-lean-ctx/lean_ctx/` | CLI wrapper plus proxy compression and LangChain/LiteLLM/LlamaIndex adapters. |
| TypeScript HTTP SDK | `cookbook/sdk/` | `/v1` client/types, tool result text conversion, and conformance/E2E tests. |
| Node package | `packages/node-lean-ctx/` | CLI wrapper, proxy client, discovery, and Vercel AI middleware/tool adapter. |
| OCLA gRPC adapter | `packages/ocla-grpc/` | Loopback-only, bounded gRPC projection of public OCLA v1 envelopes; links the standalone client only. |
| Offline verifier | `packages/leanctx-verify/` | Independent evidence-bundle verifier (hashes, chain and signatures). |
| Other integrations | `packages/pi-lean-ctx/`, `ts-sdk/`, `python-sdk/`, `py-sdk/`, `vscode-extension/`, `integrations/hermes-lean-ctx/` | Additional editor/agent SDKs and integrations; detailed source listing is in the appendix. |

## 8. Gateway proxy and interception

`rust/src/proxy/mod.rs` defines the Gateway pillar. It intercepts Anthropic, OpenAI, Gemini/Google, and ChatGPT traffic; it also has Bedrock SigV4 handling, Azure usage accounting, and configurable provider/upstream routing. It does not terminate TLS: production deployment requires a TLS-terminating reverse proxy.

| Provider / shape | Proxy support |
|---|---|
| Anthropic | Native `/v1/messages` ingress, request compression, cache attribution, streaming and usage handling (`anthropic.rs`). |
| OpenAI | Chat Completions and Responses request/stream shapes, models API, output shaping, routing (`openai.rs`, `openai_responses*.rs`). |
| Google Gemini | Native provider route/shape support (`google.rs`). |
| ChatGPT | Web/API and WebSocket paths with shared Cloudflare cookie store (`chatgpt*.rs`). |
| Amazon Bedrock | Header handling, request construction and SigV4 signing; can carry Anthropic model invocations (`bedrock.rs`). |
| Azure / OpenAI-compatible upstreams | Azure usage accounting plus configurable upstream aliases; optional `shape-xlat` enables Claude-shaped clients to reach OpenAI-shaped Foundry/vLLM/Ollama-style backends. |

| Stage | Implementation |
|---|---|
| Ingress/provider shapes | `anthropic.rs`, `openai.rs`, `openai_responses*.rs`, `google.rs`, `chatgpt*.rs`, `bedrock.rs`, `connector.rs`, `providers.rs`, `models_api.rs`. |
| Forwarding | `forward/{prepare,headers,pipeline,transport,trace_id,xlat}.rs`: safe header/body construction, streamed transport, correlation and optional cross-shape translation. |
| Transformation | `compress*.rs`, `prose*.rs`, `image_compression.rs`, `history_prune.rs`, `response_optimizer.rs`, `response_shaper.rs`, `reasoning_budget.rs`, `effort*.rs`. |
| Routing & policy | `routing*.rs`, `auto_routing.rs`, `model_router.rs`, `sticky_tools.rs`, `eligibility.rs`, `policy_gate.rs`, `adaptive_policy.rs`, `rollout.rs`, `circuit_breaker.rs`. |
| Cache/CCR | `ccr*.rs`, `cache_*.rs`, `cold_prefix.rs`, `prefix_replay.rs`, `prefix_cache_stats.rs`, `cache_attribution.rs`, `determinism_guard.rs`. |
| Metering & evidence | `usage*.rs`, `usage_meter.rs`, `cost.rs`, `metrics.rs`, `output_savings.rs`, `counterfactual.rs`, `lineage.rs`, `usage_sink.rs`, `ocla_cache_bridge.rs`. |
| Web application | `web_app/`, `web_app_middleware.rs`, `dashboard`, conversation tracker/normalization; `introspect.rs` exposes state safely. |

Client interception setup is isolated in `rust/src/proxy_setup/`: Claude, Codex, Command Code, Grok, Pi, shell and utilities write/reverse the relevant client environment/MCP wiring. `proxy_autostart.rs` emits `com.leanctx.proxy` LaunchAgent (macOS) or systemd user service (Linux); `daemon_autostart.rs` does the same for `com.leanctx.daemon`.

## 9. Configuration, launchd, and MCP configuration

| Surface | Source / installed location | Details |
|---|---|---|
| Global + project config | `rust/src/core/config/{model,sections,loader,merge,setter,defaults,logic,render}.rs`; user `~/.config/lean-ctx/config.toml` plus project `.lean-ctx.toml` | Serde model with cached load, project override merge, provenance, typed setter and schema validation. |
| Schema | `rust/src/core/config/schema/{mod,sections_core,sections_features,sections_advanced}.rs` | Drives `lean-ctx config validate`/set key discovery; prevents CLI/schema drift. |
| Config sections | `Config` plus `Shadow`, `Ocla`, `Delivery`, `Cache`, `Agents`, `SecretDetection`, `Setup`, `Archive`, `Conversation`, `Providers`, `KnowledgeRouting`, `Autonomy`, `Updates`, `Context`, `Telemetry`, `Cloud`, `Gain`, `Cost`, `DecisionLoop`, `CodeHealth`, `Index`, `Graph`, `Skillify`, `Summaries`, `LoopDetection`, `GatewayServer`, `Embedding`, memory/risk/response-shaping/solution sections. |
| Launch services | `rust/src/{daemon_autostart,proxy_autostart}.rs`, `rust/src/core/launchd.rs`, `rust/src/core/update_scheduler.rs` | Generates plist/XML at runtime; labels are `com.leanctx.daemon` and `com.leanctx.proxy`, rather than committed plist files. macOS uses `launchctl bootstrap`; Linux uses systemd user units. |
| Repository MCP configs | `.github/mcp.json`, `.github/copilot/mcp.json`, `.vscode/mcp.json` | GitHub and VS Code run the lean-ctx stdio MCP server; the first/VS Code use the local installed binary and VS Code declares `type: stdio`. |
| MCP runtime | `rust/src/mcp_stdio.rs`, `rust/src/server/`, `rust/src/tools/`, `rust/src/setup/mcp.rs`, `core/mcp_catalog/` | rmcp stdio transport, tool serving/authorization, setup writers, remote MCP catalog/bridges. |

## 10. Test infrastructure

| Area | Evidence / intent |
|---|---|
| Engine unit/integration tests | `rust/src`: 1977 Rust files, 613933 LOC, 10556 static Rust test markers. Tests are colocated in modules and `*_tests.rs`; `rust/tests/` adds E2E/contract fixtures. |
| Public crates | OCLA 11, protocol 45, SDK 12 static Rust test markers; grammar addon is intentionally a minimal cdylib. |
| Client conformance | `clients/rust/lean-ctx-client`, `clients/python/tests`, `cookbook/sdk/src/*test.ts`, `packages/{python-lean-ctx,node-lean-ctx}/tests` validate HTTP `/v1`, tool text and OCLA boundaries. |
| Contract/security | `tests/delivery/`, `tests/security/`, `tests/ocla_contract_suite/` exercise delivery manifests/evidence/key rotation, release/branch/secret policy, and OCLA suite verification. |
| Benchmark/lifecycle | `bench/`, `benchmark/`, `benchmarks/`, `scripts/benchmark*`, and `rust/src/core/{benchmark_compare,benchmark_study,task_benchmark}` support reproducible performance/regression studies. |
| CI | `.github/workflows/` contains build/test/quality/release workflows; Rust quality gate is `cargo test --lib`, `cargo clippy --all-features -- -D warnings`, and `cargo fmt --check`. |

## 11. Scripts directory

Executable scripts are listed individually below. `scripts/benchmark/` additionally contains benchmark documentation and recorded result fixtures; those are data, not executable orchestration.

| Script | LOC | Role inferred from executable name/source header |
|---|---:|---|
| `scripts/apply-branch-protection.py` | 232 | Apply or verify GitHub branch-protection policy. |
| `scripts/benchmark/report.sh` | 24 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark/token_reduction.sh` | 71 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark_bigcode.py` | 519 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark_codex.py` | 352 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark_codex_compressed.py` | 457 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark_mbpp.py` | 447 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark_multifile.py` | 342 | Benchmark harness, reporting, or baseline collection. |
| `scripts/benchmark_shell.py` | 346 | Benchmark harness, reporting, or baseline collection. |
| `scripts/chaos-restart-test.sh` | 92 | Restart/resilience chaos check. |
| `scripts/check-addon-versions.py` | 180 | Static release/version/secret/open-core/addon guard. |
| `scripts/check-loc-limit.sh` | 62 | Static release/version/secret/open-core/addon guard. |
| `scripts/check-open-core-boundary.py` | 320 | Static release/version/secret/open-core/addon guard. |
| `scripts/check-package-versions.py` | 95 | Static release/version/secret/open-core/addon guard. |
| `scripts/check-sdk-versions.py` | 130 | Static release/version/secret/open-core/addon guard. |
| `scripts/check-secret-expiry.py` | 294 | Static release/version/secret/open-core/addon guard. |
| `scripts/demo-great-filter.sh` | 157 | Demo scenario. |
| `scripts/demo-outcome-pricing.sh` | 105 | Demo scenario. |
| `scripts/g4-metrics-evidence.py` | 140 | Generate audit, SBOM, evidence, or benchmark artifacts. |
| `scripts/gen-sdk-matrix.py` | 116 | SDK compatibility, type, or conformance validation. |
| `scripts/generate-audit-report.py` | 225 | Generate audit, SBOM, evidence, or benchmark artifacts. |
| `scripts/generate-sbom.sh` | 22 | Generate audit, SBOM, evidence, or benchmark artifacts. |
| `scripts/generate_ebench_report.py` | 239 | Generate audit, SBOM, evidence, or benchmark artifacts. |
| `scripts/generate_multifile_benchmark_tasks.py` | 1399 | Generate audit, SBOM, evidence, or benchmark artifacts. |
| `scripts/history-policy-gate.py` | 339 | History policy enforcement. |
| `scripts/loc-gate.sh` | 65 | Source line-count quality gate. |
| `scripts/monitor-agents-r2.sh` | 60 | Multi-agent run monitoring or launch. |
| `scripts/monitor-agents-r3.sh` | 56 | Multi-agent run monitoring or launch. |
| `scripts/monitor-agents-tickets.sh` | 95 | Multi-agent run monitoring or launch. |
| `scripts/monitor-agents.sh` | 56 | Multi-agent run monitoring or launch. |
| `scripts/multi-ide-benchmark.sh` | 110 | Benchmark harness, reporting, or baseline collection. |
| `scripts/pilot-baseline.sh` | 55 | Benchmark harness, reporting, or baseline collection. |
| `scripts/pilot-setup.sh` | 550 | Pilot/CI environment setup or preflight validation. |
| `scripts/preflight.sh` | 289 | Pilot/CI environment setup or preflight validation. |
| `scripts/sdk-conformance.sh` | 86 | SDK compatibility, type, or conformance validation. |
| `scripts/self-pilot-report.py` | 188 | Pilot outcome report. |
| `scripts/start-agents-r2.sh` | 68 | Multi-agent run monitoring or launch. |
| `scripts/start-agents-r3.sh` | 56 | Multi-agent run monitoring or launch. |
| `scripts/start-agents-tickets.sh` | 52 | Multi-agent run monitoring or launch. |
| `scripts/start-agents.sh` | 74 | Multi-agent run monitoring or launch. |
| `scripts/validate-sdk-types.sh` | 116 | SDK compatibility, type, or conformance validation. |
| `scripts/verify-branch-protection.py` | 152 | Apply or verify GitHub branch-protection policy. |
| `scripts/verify-ocla-contract-suite.py` | 613 | OCLA contract suite verification. |
| `scripts/verify-release-integrity.py` | 197 | Release integrity verification. |
| `scripts/verify-test-deployment-evidence.py` | 683 | Deployment evidence verification. |

### Non-executable files under `scripts/`

| File | LOC | Classification |
|---|---:|---|
| `scripts/benchmark/README.md` | 25 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/10_read_readme.compressed` | 359 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/10_read_readme.raw` | 695 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/1_read_core_mod.compressed` | 521 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/1_read_core_mod.raw` | 520 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/2_read_registry.compressed` | 45 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/2_read_registry.raw` | 298 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/3_test_triage.compressed` | 26 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/3_test_triage.raw` | 26 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/4_git_log.compressed` | 20 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/4_git_log.raw` | 20 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/5_git_diff_stat.compressed` | 58 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/5_git_diff_stat.raw` | 58 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/6_search_task_envelope.compressed` | 1 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/6_search_task_envelope.raw` | 43 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/7_read_cargo_toml.compressed` | 112 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/7_read_cargo_toml.raw` | 471 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/8_clippy_head.compressed` | 2 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/8_clippy_head.raw` | 4 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/9_tree_core.compressed` | 3 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/latest/9_tree_core.raw` | 1175 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/report.md` | 13 | Benchmark documentation or recorded fixture/output data. |
| `scripts/benchmark/results/token_reduction.tsv` | 11 | Benchmark documentation or recorded fixture/output data. |
| `scripts/gl` | 115 | Benchmark documentation or recorded fixture/output data. |
| `scripts/multifile_benchmark_tasks.json` | 180 | Benchmark documentation or recorded fixture/output data. |
| `scripts/shell_benchmark_tasks.json` | 146 | Benchmark documentation or recorded fixture/output data. |

## 12. Complete Rust implementation inventory

Every `.rs` implementation file under `rust/src/` is listed once, grouped by its containing directory. This appendix is intentionally mechanical: it is the authoritative path/line-count cross-reference for the maps above.

### `rust/src/`

| File | LOC |
|---|---:|
| `rust/src/cloud_client.rs` | 1347 |
| `rust/src/cloud_sync.rs` | 684 |
| `rust/src/compound_lexer.rs` | 263 |
| `rust/src/config_io.rs` | 730 |
| `rust/src/daemon.rs` | 294 |
| `rust/src/daemon_autostart.rs` | 382 |
| `rust/src/daemon_client.rs` | 481 |
| `rust/src/dropin.rs` | 214 |
| `rust/src/heatmap.rs` | 247 |
| `rust/src/instructions.rs` | 879 |
| `rust/src/lib.rs` | 72 |
| `rust/src/main.rs` | 24 |
| `rust/src/marked_block.rs` | 195 |
| `rust/src/mcp_stdio.rs` | 700 |
| `rust/src/proxy_autostart.rs` | 640 |
| `rust/src/report.rs` | 652 |
| `rust/src/rewrite_registry.rs` | 437 |
| `rust/src/shell_hook.rs` | 1260 |
| `rust/src/status.rs` | 202 |
| `rust/src/terminal_ui.rs` | 488 |
| `rust/src/test_env.rs` | 25 |
| `rust/src/token_report.rs` | 250 |

### `rust/src/bin/`

| File | LOC |
|---|---:|
| `rust/src/bin/bench_cross_agent_cache.rs` | 297 |
| `rust/src/bin/gen_docs.rs` | 99 |
| `rust/src/bin/gen_mcp_manifest.rs` | 85 |
| `rust/src/bin/gen_registry.rs` | 110 |
| `rust/src/bin/gen_rules.rs` | 100 |
| `rust/src/bin/gen_tdd_schema.rs` | 76 |
| `rust/src/bin/gen_testbench_recording.rs` | 103 |
| `rust/src/bin/locomo_bench.rs` | 158 |
| `rust/src/bin/seed_observatory.rs` | 491 |

### `rust/src/cli/`

| File | LOC |
|---|---:|
| `rust/src/cli/addon_deps.rs` | 150 |
| `rust/src/cli/agent_cmd.rs` | 245 |
| `rust/src/cli/allow_cmd.rs` | 189 |
| `rust/src/cli/audit_report.rs` | 118 |
| `rust/src/cli/badge_cmd.rs` | 285 |
| `rust/src/cli/benchmark_cmd.rs` | 438 |
| `rust/src/cli/benchmark_study_cmd.rs` | 95 |
| `rust/src/cli/benchmark_tasks_cmd.rs` | 159 |
| `rust/src/cli/call_cmd.rs` | 294 |
| `rust/src/cli/cheatsheet_cmd.rs` | 126 |
| `rust/src/cli/checkpoint_cmd.rs` | 126 |
| `rust/src/cli/cloud.rs` | 1094 |
| `rust/src/cli/cognitive.rs` | 60 |
| `rust/src/cli/common.rs` | 264 |
| `rust/src/cli/compliance_cmd.rs` | 215 |
| `rust/src/cli/compress_cmd.rs` | 154 |
| `rust/src/cli/config_cmd.rs` | 1502 |
| `rust/src/cli/context_cmd.rs` | 150 |
| `rust/src/cli/dashboard_cmd.rs` | 5 |
| `rust/src/cli/debug_log_cmd.rs` | 39 |
| `rust/src/cli/demo_cmd.rs` | 423 |
| `rust/src/cli/discover_cmd.rs` | 250 |
| `rust/src/cli/embeddings_cmd.rs` | 72 |
| `rust/src/cli/enterprise.rs` | 237 |
| `rust/src/cli/eval_cmd.rs` | 651 |
| `rust/src/cli/evidence_export.rs` | 192 |
| `rust/src/cli/explore_cmd.rs` | 199 |
| `rust/src/cli/export_rules.rs` | 229 |
| `rust/src/cli/harden.rs` | 267 |
| `rust/src/cli/health_cmd.rs` | 99 |
| `rust/src/cli/import_cmd.rs` | 114 |
| `rust/src/cli/index_cmd.rs` | 607 |
| `rust/src/cli/init_cmd.rs` | 198 |
| `rust/src/cli/instructions_cmd.rs` | 90 |
| `rust/src/cli/introspect_cmd.rs` | 44 |
| `rust/src/cli/kit_cmd.rs` | 100 |
| `rust/src/cli/knowledge_cmd.rs` | 807 |
| `rust/src/cli/learn_cmd.rs` | 425 |
| `rust/src/cli/ledger_cmd.rs` | 471 |
| `rust/src/cli/measurement_cmd.rs` | 67 |
| `rust/src/cli/migrate_cmd.rs` | 222 |
| `rust/src/cli/mod.rs` | 148 |
| `rust/src/cli/model_cmd.rs` | 128 |
| `rust/src/cli/ocla_cmd.rs` | 402 |
| `rust/src/cli/output_savings_cmd.rs` | 175 |
| `rust/src/cli/overview_cmd.rs` | 63 |
| `rust/src/cli/pack_remote.rs` | 276 |
| `rust/src/cli/plugin_cmd.rs` | 193 |
| `rust/src/cli/policy_cmd.rs` | 468 |
| `rust/src/cli/policy_enforce_cmd.rs` | 366 |
| `rust/src/cli/policy_org_cmd.rs` | 499 |
| `rust/src/cli/profile_cmd.rs` | 553 |
| `rust/src/cli/prompt.rs` | 70 |
| `rust/src/cli/proof_cmd.rs` | 103 |
| `rust/src/cli/prove.rs` | 119 |
| `rust/src/cli/quality_lab_cmd.rs` | 57 |
| `rust/src/cli/read_cmd.rs` | 920 |
| `rust/src/cli/repomap_cmd.rs` | 197 |
| `rust/src/cli/roi_cmd.rs` | 347 |
| `rust/src/cli/rules_cmd.rs` | 149 |
| `rust/src/cli/rules_dedup.rs` | 609 |
| `rust/src/cli/savings.rs` | 227 |
| `rust/src/cli/scenario_cmd.rs` | 481 |
| `rust/src/cli/security_cmd.rs` | 286 |
| `rust/src/cli/semantic_search_cmd.rs` | 334 |
| `rust/src/cli/session_cmd.rs` | 401 |
| `rust/src/cli/shadow_report.rs` | 71 |
| `rust/src/cli/shell_init.rs` | 1289 |
| `rust/src/cli/skillify_cmd.rs` | 42 |
| `rust/src/cli/snapshot_cmd.rs` | 390 |
| `rust/src/cli/summary_cmd.rs` | 65 |
| `rust/src/cli/tee_cmd.rs` | 182 |
| `rust/src/cli/telemetry_cmd.rs` | 164 |
| `rust/src/cli/theme_cmd.rs` | 178 |
| `rust/src/cli/tools_health_cmd.rs` | 188 |
| `rust/src/cli/triage_cmd.rs` | 59 |
| `rust/src/cli/trust_cmd.rs` | 171 |
| `rust/src/cli/upgrade_hint.rs` | 132 |
| `rust/src/cli/value_report.rs` | 157 |
| `rust/src/cli/verify_cache_cmd.rs` | 337 |
| `rust/src/cli/verify_cmd.rs` | 39 |
| `rust/src/cli/visualize_cmd.rs` | 118 |
| `rust/src/cli/wrap_cmd.rs` | 774 |
| `rust/src/cli/wrapped_publish.rs` | 952 |

### `rust/src/cli/addon_cmd/`

| File | LOC |
|---|---:|
| `rust/src/cli/addon_cmd/authoring.rs` | 227 |
| `rust/src/cli/addon_cmd/commands.rs` | 622 |
| `rust/src/cli/addon_cmd/display.rs` | 241 |
| `rust/src/cli/addon_cmd/management.rs` | 408 |
| `rust/src/cli/addon_cmd/mod.rs` | 39 |

### `rust/src/cli/completions/`

| File | LOC |
|---|---:|
| `rust/src/cli/completions/engine.rs` | 205 |
| `rust/src/cli/completions/mod.rs` | 42 |
| `rust/src/cli/completions/shells.rs` | 114 |
| `rust/src/cli/completions/spec.rs` | 1507 |

### `rust/src/cli/dispatch/`

| File | LOC |
|---|---:|
| `rust/src/cli/dispatch/evidence.rs` | 499 |
| `rust/src/cli/dispatch/evidence_cost.rs` | 184 |
| `rust/src/cli/dispatch/evidence_realworld.rs` | 613 |
| `rust/src/cli/dispatch/evidence_report.rs` | 456 |
| `rust/src/cli/dispatch/evidence_workflow.rs` | 811 |
| `rust/src/cli/dispatch/help.rs` | 395 |
| `rust/src/cli/dispatch/lifecycle.rs` | 755 |
| `rust/src/cli/dispatch/mod.rs` | 1325 |
| `rust/src/cli/dispatch/server.rs` | 552 |
| `rust/src/cli/dispatch/suggest.rs` | 168 |
| `rust/src/cli/dispatch/verify.rs` | 704 |

### `rust/src/cli/dispatch/analytics/`

| File | LOC |
|---|---:|
| `rust/src/cli/dispatch/analytics/billing.rs` | 311 |
| `rust/src/cli/dispatch/analytics/finops.rs` | 148 |
| `rust/src/cli/dispatch/analytics/gain.rs` | 976 |
| `rust/src/cli/dispatch/analytics/graph.rs` | 415 |
| `rust/src/cli/dispatch/analytics/learning.rs` | 103 |
| `rust/src/cli/dispatch/analytics/mod.rs` | 57 |
| `rust/src/cli/dispatch/analytics/provider_run.rs` | 719 |
| `rust/src/cli/dispatch/analytics/savings.rs` | 609 |
| `rust/src/cli/dispatch/analytics/spend.rs` | 159 |

### `rust/src/cli/dispatch/network/`

| File | LOC |
|---|---:|
| `rust/src/cli/dispatch/network/mod.rs` | 596 |
| `rust/src/cli/dispatch/network/provider.rs` | 136 |
| `rust/src/cli/dispatch/network/proxy.rs` | 732 |
| `rust/src/cli/dispatch/network/team.rs` | 10 |
| `rust/src/cli/dispatch/network/tests.rs` | 74 |

### `rust/src/cli/pack_cmd/`

| File | LOC |
|---|---:|
| `rust/src/cli/pack_cmd/management.rs` | 497 |
| `rust/src/cli/pack_cmd/mod.rs` | 93 |
| `rust/src/cli/pack_cmd/package.rs` | 635 |
| `rust/src/cli/pack_cmd/pr.rs` | 83 |
| `rust/src/cli/pack_cmd/transfer.rs` | 201 |

### `rust/src/core/`

| File | LOC |
|---|---:|
| `rust/src/core/a2a_transport.rs` | 262 |
| `rust/src/core/active_inference.rs` | 285 |
| `rust/src/core/adaptive.rs` | 116 |
| `rust/src/core/adaptive_chunking.rs` | 278 |
| `rust/src/core/adaptive_compression.rs` | 294 |
| `rust/src/core/adaptive_mode_policy.rs` | 232 |
| `rust/src/core/adaptive_thresholds.rs` | 565 |
| `rust/src/core/agent_attribution.rs` | 263 |
| `rust/src/core/agent_budget.rs` | 405 |
| `rust/src/core/agent_identity.rs` | 327 |
| `rust/src/core/agent_lease.rs` | 346 |
| `rust/src/core/agent_registry.rs` | 488 |
| `rust/src/core/agent_registry_tests.rs` | 167 |
| `rust/src/core/agent_runtime_env.rs` | 579 |
| `rust/src/core/aggressiveness.rs` | 116 |
| `rust/src/core/anchor.rs` | 159 |
| `rust/src/core/ann_cache.rs` | 298 |
| `rust/src/core/anomaly.rs` | 376 |
| `rust/src/core/archive.rs` | 566 |
| `rust/src/core/archive_fts.rs` | 363 |
| `rust/src/core/artifact_index.rs` | 581 |
| `rust/src/core/artifacts.rs` | 262 |
| `rust/src/core/ast_walk.rs` | 126 |
| `rust/src/core/atomic_fs.rs` | 381 |
| `rust/src/core/attention_context.rs` | 229 |
| `rust/src/core/attention_layout_driver.rs` | 91 |
| `rust/src/core/attention_model.rs` | 288 |
| `rust/src/core/attention_placement.rs` | 73 |
| `rust/src/core/attribution.rs` | 88 |
| `rust/src/core/audit_trail.rs` | 270 |
| `rust/src/core/auto_capture.rs` | 213 |
| `rust/src/core/auto_findings.rs` | 917 |
| `rust/src/core/auto_mode_resolver.rs` | 1239 |
| `rust/src/core/autonomy.rs` | 148 |
| `rust/src/core/autonomy_drivers.rs` | 265 |
| `rust/src/core/bandit.rs` | 516 |
| `rust/src/core/baseline.rs` | 133 |
| `rust/src/core/benchmark.rs` | 1091 |
| `rust/src/core/binary_detect.rs` | 345 |
| `rust/src/core/bm25_cache.rs` | 260 |
| `rust/src/core/bounce_tracker.rs` | 462 |
| `rust/src/core/budget.rs` | 167 |
| `rust/src/core/budget_tracker.rs` | 445 |
| `rust/src/core/budgets.rs` | 51 |
| `rust/src/core/cache_diagnostics.rs` | 205 |
| `rust/src/core/cache_telemetry.rs` | 137 |
| `rust/src/core/call_graph.rs` | 1322 |
| `rust/src/core/canonical.rs` | 259 |
| `rust/src/core/capabilities.rs` | 213 |
| `rust/src/core/capsule_transport.rs` | 228 |
| `rust/src/core/causal_attribution.rs` | 91 |
| `rust/src/core/ccp_session_bundle.rs` | 414 |
| `rust/src/core/chain_compression.rs` | 293 |
| `rust/src/core/chunks_ts.rs` | 450 |
| `rust/src/core/claim_extractor.rs` | 289 |
| `rust/src/core/cli_cache.rs` | 410 |
| `rust/src/core/client_capabilities.rs` | 359 |
| `rust/src/core/client_constraints.rs` | 211 |
| `rust/src/core/cloud_files.rs` | 104 |
| `rust/src/core/codebook.rs` | 355 |
| `rust/src/core/cognition_loop.rs` | 1130 |
| `rust/src/core/cognition_scheduler.rs` | 180 |
| `rust/src/core/cognitive_gate.rs` | 30 |
| `rust/src/core/cognitive_load.rs` | 229 |
| `rust/src/core/compliance.rs` | 558 |
| `rust/src/core/compress_preview.rs` | 214 |
| `rust/src/core/compression_safety.rs` | 273 |
| `rust/src/core/compressor.rs` | 579 |
| `rust/src/core/config_heal.rs` | 281 |
| `rust/src/core/conformance.rs` | 629 |
| `rust/src/core/consolidation.rs` | 467 |
| `rust/src/core/consolidation_engine.rs` | 343 |
| `rust/src/core/content_cache.rs` | 484 |
| `rust/src/core/content_chunk.rs` | 258 |
| `rust/src/core/content_handle.rs` | 163 |
| `rust/src/core/context_artifacts.rs` | 222 |
| `rust/src/core/context_capsule.rs` | 593 |
| `rust/src/core/context_column.rs` | 374 |
| `rust/src/core/context_compiler.rs` | 631 |
| `rust/src/core/context_deficit.rs` | 296 |
| `rust/src/core/context_field.rs` | 786 |
| `rust/src/core/context_gc.rs` | 54 |
| `rust/src/core/context_handles.rs` | 537 |
| `rust/src/core/context_ir.rs` | 285 |
| `rust/src/core/context_lint.rs` | 222 |
| `rust/src/core/context_overhead.rs` | 315 |
| `rust/src/core/context_overlay.rs` | 491 |
| `rust/src/core/context_packing.rs` | 162 |
| `rust/src/core/context_policies.rs` | 413 |
| `rust/src/core/context_proof.rs` | 302 |
| `rust/src/core/context_proof_v2.rs` | 394 |
| `rust/src/core/context_radar.rs` | 524 |
| `rust/src/core/contracts.rs` | 487 |
| `rust/src/core/conversation.rs` | 552 |
| `rust/src/core/cooccurrence.rs` | 464 |
| `rust/src/core/cost_per_outcome.rs` | 59 |
| `rust/src/core/crash_log.rs` | 192 |
| `rust/src/core/cross_customer_learning.rs` | 4 |
| `rust/src/core/cross_source_edges.rs` | 282 |
| `rust/src/core/cross_source_hints.rs` | 237 |
| `rust/src/core/cyclomatic.rs` | 227 |
| `rust/src/core/data_consolidate.rs` | 282 |
| `rust/src/core/data_dir.rs` | 466 |
| `rust/src/core/datadog_push.rs` | 348 |
| `rust/src/core/debug_log.rs` | 376 |
| `rust/src/core/decision_loop.rs` | 202 |
| `rust/src/core/decision_loop_integration_test.rs` | 214 |
| `rust/src/core/decision_loop_runtime.rs` | 261 |
| `rust/src/core/decision_loop_runtime_tests.rs` | 65 |
| `rust/src/core/degradation_policy.rs` | 274 |
| `rust/src/core/delivered_ranges.rs` | 241 |
| `rust/src/core/delta_response.rs` | 227 |
| `rust/src/core/dense_backend.rs` | 676 |
| `rust/src/core/deps.rs` | 517 |
| `rust/src/core/determinism.rs` | 588 |
| `rust/src/core/diagnostics_store.rs` | 570 |
| `rust/src/core/echo_ratio.rs` | 132 |
| `rust/src/core/edit_metering.rs` | 230 |
| `rust/src/core/edit_quality.rs` | 596 |
| `rust/src/core/edit_snapshot.rs` | 275 |
| `rust/src/core/editor_signal.rs` | 202 |
| `rust/src/core/efficacy.rs` | 319 |
| `rust/src/core/egress.rs` | 334 |
| `rust/src/core/embedding_index.rs` | 903 |
| `rust/src/core/embedding_quant.rs` | 221 |
| `rust/src/core/energy.rs` | 166 |
| `rust/src/core/entropy.rs` | 1191 |
| `rust/src/core/episodic_memory.rs` | 826 |
| `rust/src/core/error.rs` | 169 |
| `rust/src/core/etpao.rs` | 190 |
| `rust/src/core/eval_harness.rs` | 847 |
| `rust/src/core/events.rs` | 849 |
| `rust/src/core/eviction_orchestrator.rs` | 445 |
| `rust/src/core/evidence.rs` | 88 |
| `rust/src/core/evidence_bundle.rs` | 370 |
| `rust/src/core/evidence_classification.rs` | 111 |
| `rust/src/core/evidence_flow.rs` | 436 |
| `rust/src/core/evidence_ledger.rs` | 370 |
| `rust/src/core/evidence_report.rs` | 593 |
| `rust/src/core/extension_registry.rs` | 372 |
| `rust/src/core/feedback.rs` | 325 |
| `rust/src/core/fep_prefetch.rs` | 142 |
| `rust/src/core/filters.rs` | 276 |
| `rust/src/core/firewall.rs` | 496 |
| `rust/src/core/fleet_analytics.rs` | 4 |
| `rust/src/core/free_energy_budget.rs` | 184 |
| `rust/src/core/gamma_cover.rs` | 215 |
| `rust/src/core/git_cache.rs` | 164 |
| `rust/src/core/git_signals.rs` | 293 |
| `rust/src/core/git_util.rs` | 42 |
| `rust/src/core/grammar_usage.rs` | 249 |
| `rust/src/core/graph_cache.rs` | 134 |
| `rust/src/core/graph_context.rs` | 436 |
| `rust/src/core/graph_coordinator.rs` | 52 |
| `rust/src/core/graph_enricher.rs` | 568 |
| `rust/src/core/graph_export.rs` | 796 |
| `rust/src/core/graph_features.rs` | 316 |
| `rust/src/core/graph_parity.rs` | 302 |
| `rust/src/core/graph_provider.rs` | 1040 |
| `rust/src/core/handle.rs` | 190 |
| `rust/src/core/handoff_ledger.rs` | 610 |
| `rust/src/core/handoff_transfer_bundle.rs` | 515 |
| `rust/src/core/hasher.rs` | 48 |
| `rust/src/core/heatmap.rs` | 470 |
| `rust/src/core/hebbian_cache.rs` | 332 |
| `rust/src/core/hnsw.rs` | 521 |
| `rust/src/core/home.rs` | 263 |
| `rust/src/core/homeostasis.rs` | 217 |
| `rust/src/core/html_crush.rs` | 1320 |
| `rust/src/core/http_client.rs` | 35 |
| `rust/src/core/hybrid_search.rs` | 625 |
| `rust/src/core/ide_permissions.rs` | 445 |
| `rust/src/core/immune_detector.rs` | 194 |
| `rust/src/core/index_admission.rs` | 230 |
| `rust/src/core/index_bundle.rs` | 412 |
| `rust/src/core/index_filter.rs` | 252 |
| `rust/src/core/index_namespace.rs` | 175 |
| `rust/src/core/index_orchestrator.rs` | 1233 |
| `rust/src/core/index_paths.rs` | 53 |
| `rust/src/core/index_progress.rs` | 186 |
| `rust/src/core/information_bottleneck.rs` | 247 |
| `rust/src/core/ingestion.rs` | 312 |
| `rust/src/core/installation_id.rs` | 121 |
| `rust/src/core/instruction_compiler.rs` | 165 |
| `rust/src/core/integration_proof.rs` | 383 |
| `rust/src/core/integrity.rs` | 98 |
| `rust/src/core/intent_engine.rs` | 1163 |
| `rust/src/core/intent_lang.rs` | 337 |
| `rust/src/core/intent_protocol.rs` | 430 |
| `rust/src/core/intent_router.rs` | 436 |
| `rust/src/core/interrupt.rs` | 72 |
| `rust/src/core/introspect.rs` | 324 |
| `rust/src/core/io_boundary.rs` | 402 |
| `rust/src/core/io_health.rs` | 235 |
| `rust/src/core/journal.rs` | 131 |
| `rust/src/core/json_crush.rs` | 587 |
| `rust/src/core/json_sample.rs` | 620 |
| `rust/src/core/jsonc.rs` | 363 |
| `rust/src/core/knowledge_bootstrap.rs` | 181 |
| `rust/src/core/knowledge_bridge.rs` | 458 |
| `rust/src/core/knowledge_embedding.rs` | 1101 |
| `rust/src/core/knowledge_provider_extract.rs` | 341 |
| `rust/src/core/knowledge_relations.rs` | 488 |
| `rust/src/core/knowledge_vault.rs` | 144 |
| `rust/src/core/language_capabilities.rs` | 568 |
| `rust/src/core/launchd.rs` | 71 |
| `rust/src/core/layout_pin.rs` | 186 |
| `rust/src/core/learning_sync.rs` | 158 |
| `rust/src/core/levenshtein.rs` | 81 |
| `rust/src/core/limits.rs` | 22 |
| `rust/src/core/litm.rs` | 505 |
| `rust/src/core/litm_calibration.rs` | 344 |
| `rust/src/core/live_evidence_ledger.rs` | 148 |
| `rust/src/core/llm_enhance.rs` | 301 |
| `rust/src/core/llm_feedback.rs` | 272 |
| `rust/src/core/logging.rs` | 29 |
| `rust/src/core/loop_detection.rs` | 1011 |
| `rust/src/core/marginal_gate.rs` | 154 |
| `rust/src/core/markdown_compact.rs` | 532 |
| `rust/src/core/mcp_manifest.rs` | 101 |
| `rust/src/core/mdl_selector.rs` | 154 |
| `rust/src/core/memory_archive.rs` | 403 |
| `rust/src/core/memory_boundary.rs` | 241 |
| `rust/src/core/memory_branch.rs` | 164 |
| `rust/src/core/memory_capacity.rs` | 256 |
| `rust/src/core/memory_consolidation.rs` | 222 |
| `rust/src/core/memory_guard.rs` | 700 |
| `rust/src/core/memory_lifecycle.rs` | 1196 |
| `rust/src/core/memory_policy.rs` | 811 |
| `rust/src/core/memory_salience.rs` | 71 |
| `rust/src/core/metering.rs` | 161 |
| `rust/src/core/mod.rs` | 552 |
| `rust/src/core/mode_predictor.rs` | 571 |
| `rust/src/core/model_registry.rs` | 251 |
| `rust/src/core/model_router.rs` | 26 |
| `rust/src/core/multi_repo.rs` | 604 |
| `rust/src/core/multiscale_index.rs` | 297 |
| `rust/src/core/nc_compress.rs` | 225 |
| `rust/src/core/negative_knowledge.rs` | 140 |
| `rust/src/core/ocla_bus.rs` | 882 |
| `rust/src/core/ocp.rs` | 181 |
| `rust/src/core/openapi.rs` | 180 |
| `rust/src/core/ort_environment.rs` | 432 |
| `rust/src/core/ort_execution_providers.rs` | 331 |
| `rust/src/core/output_echo.rs` | 481 |
| `rust/src/core/output_sanitizer.rs` | 444 |
| `rust/src/core/output_verification.rs` | 669 |
| `rust/src/core/owasp_alignment.rs` | 372 |
| `rust/src/core/pagerank.rs` | 260 |
| `rust/src/core/path_locks.rs` | 133 |
| `rust/src/core/path_mode_memory.rs` | 259 |
| `rust/src/core/path_resolve.rs` | 388 |
| `rust/src/core/pathjail.rs` | 1354 |
| `rust/src/core/paths.rs` | 662 |
| `rust/src/core/pathutil.rs` | 1048 |
| `rust/src/core/persona.rs` | 560 |
| `rust/src/core/pgvector_store.rs` | 558 |
| `rust/src/core/pipeline.rs` | 739 |
| `rust/src/core/pop_pruning.rs` | 197 |
| `rust/src/core/portable_binary.rs` | 291 |
| `rust/src/core/predictive_coding.rs` | 199 |
| `rust/src/core/predictive_prefetch.rs` | 231 |
| `rust/src/core/preservation.rs` | 152 |
| `rust/src/core/pro_triggers.rs` | 120 |
| `rust/src/core/procedural_memory.rs` | 555 |
| `rust/src/core/process_guard.rs` | 142 |
| `rust/src/core/profile_suggest.rs` | 425 |
| `rust/src/core/progressive_compression.rs` | 201 |
| `rust/src/core/project_hash.rs` | 720 |
| `rust/src/core/prospective_memory.rs` | 163 |
| `rust/src/core/protect.rs` | 183 |
| `rust/src/core/protocol.rs` | 658 |
| `rust/src/core/provider_bandit.rs` | 322 |
| `rust/src/core/provider_cache.rs` | 259 |
| `rust/src/core/qdrant_store.rs` | 434 |
| `rust/src/core/quality.rs` | 282 |
| `rust/src/core/quality_benchmark.rs` | 354 |
| `rust/src/core/quality_scorecard.rs` | 361 |
| `rust/src/core/qubo_select.rs` | 342 |
| `rust/src/core/query_aware.rs` | 166 |
| `rust/src/core/rabin_karp.rs` | 225 |
| `rust/src/core/read_provenance.rs` | 184 |
| `rust/src/core/read_stub_index.rs` | 368 |
| `rust/src/core/recovery.rs` | 162 |
| `rust/src/core/redaction.rs` | 680 |
| `rust/src/core/reference_docs.rs` | 277 |
| `rust/src/core/relevance_gate.rs` | 141 |
| `rust/src/core/relevance_tracker.rs` | 592 |
| `rust/src/core/roles.rs` | 910 |
| `rust/src/core/route_extractor.rs` | 603 |
| `rust/src/core/rule_artifacts.rs` | 74 |
| `rust/src/core/rule_discovery.rs` | 526 |
| `rust/src/core/rule_scorer.rs` | 419 |
| `rust/src/core/rules_canonical.rs` | 1389 |
| `rust/src/core/rules_channel.rs` | 618 |
| `rust/src/core/rules_overhead.rs` | 365 |
| `rust/src/core/rules_sections.rs` | 327 |
| `rust/src/core/rules_validation.rs` | 163 |
| `rust/src/core/runtime_flags.rs` | 121 |
| `rust/src/core/safety_needles.rs` | 117 |
| `rust/src/core/saliency.rs` | 329 |
| `rust/src/core/sandbox.rs` | 770 |
| `rust/src/core/sandbox_landlock.rs` | 423 |
| `rust/src/core/sandbox_seatbelt.rs` | 186 |
| `rust/src/core/sanitize.rs` | 96 |
| `rust/src/core/savings_autopush.rs` | 134 |
| `rust/src/core/savings_footer.rs` | 491 |
| `rust/src/core/savings_tracker.rs` | 220 |
| `rust/src/core/scent_field.rs` | 435 |
| `rust/src/core/science_benchmark.rs` | 959 |
| `rust/src/core/science_integration.rs` | 571 |
| `rust/src/core/science_props.rs` | 554 |
| `rust/src/core/search_delta.rs` | 187 |
| `rust/src/core/search_index.rs` | 1343 |
| `rust/src/core/search_reranking.rs` | 531 |
| `rust/src/core/secret_detection.rs` | 490 |
| `rust/src/core/security_posture.rs` | 246 |
| `rust/src/core/semantic_cache.rs` | 367 |
| `rust/src/core/semantic_chunks.rs` | 419 |
| `rust/src/core/server_capabilities.rs` | 265 |
| `rust/src/core/session_budget.rs` | 121 |
| `rust/src/core/session_diff.rs` | 329 |
| `rust/src/core/session_token.rs` | 104 |
| `rust/src/core/setup_report.rs` | 61 |
| `rust/src/core/share.rs` | 103 |
| `rust/src/core/shared_context.rs` | 742 |
| `rust/src/core/signatures.rs` | 925 |
| `rust/src/core/slo.rs` | 567 |
| `rust/src/core/slow_log.rs` | 89 |
| `rust/src/core/smells.rs` | 754 |
| `rust/src/core/solution_auto_capture.rs` | 365 |
| `rust/src/core/solution_commercial.rs` | 234 |
| `rust/src/core/solution_rules.rs` | 62 |
| `rust/src/core/solution_tracker.rs` | 237 |
| `rust/src/core/solution_types.rs` | 5 |
| `rust/src/core/splade_retrieval.rs` | 335 |
| `rust/src/core/spreading_activation.rs` | 193 |
| `rust/src/core/startup_guard.rs` | 445 |
| `rust/src/core/storage_maintenance.rs` | 108 |
| `rust/src/core/structural_diff.rs` | 185 |
| `rust/src/core/structural_tokenizer.rs` | 472 |
| `rust/src/core/structured_compact.rs` | 228 |
| `rust/src/core/structured_read.rs` | 474 |
| `rust/src/core/subagent_contract.rs` | 203 |
| `rust/src/core/surprise.rs` | 329 |
| `rust/src/core/symbol_map.rs` | 294 |
| `rust/src/core/syntax_validate.rs` | 167 |
| `rust/src/core/tabular_crush.rs` | 372 |
| `rust/src/core/task_briefing.rs` | 232 |
| `rust/src/core/task_relevance.rs` | 956 |
| `rust/src/core/task_spine.rs` | 188 |
| `rust/src/core/tcc_guard_sandbox.rs` | 355 |
| `rust/src/core/tdd_schema.rs` | 80 |
| `rust/src/core/telemetry.rs` | 654 |
| `rust/src/core/telemetry_ledger.rs` | 80 |
| `rust/src/core/theme.rs` | 833 |
| `rust/src/core/threshold_learning.rs` | 379 |
| `rust/src/core/token_calibration.rs` | 255 |
| `rust/src/core/tokenizer_translation_driver.rs` | 329 |
| `rust/src/core/tokens.rs` | 478 |
| `rust/src/core/tool_health.rs` | 627 |
| `rust/src/core/tool_lifecycle.rs` | 894 |
| `rust/src/core/tool_profiles.rs` | 723 |
| `rust/src/core/transcript_compact.rs` | 266 |
| `rust/src/core/type_ref_edges.rs` | 523 |
| `rust/src/core/update_scheduler.rs` | 612 |
| `rust/src/core/updater.rs` | 1356 |
| `rust/src/core/verification_observability.rs` | 84 |
| `rust/src/core/version_check.rs` | 231 |
| `rust/src/core/visualizer.rs` | 374 |
| `rust/src/core/walk_filter.rs` | 159 |
| `rust/src/core/wasm_ext.rs` | 542 |
| `rust/src/core/wordlist.rs` | 219 |
| `rust/src/core/work_graph.rs` | 864 |
| `rust/src/core/workspace_config.rs` | 154 |
| `rust/src/core/workspace_trust.rs` | 374 |
| `rust/src/core/wrapped.rs` | 530 |
| `rust/src/core/wrapped_share.rs` | 218 |
| `rust/src/core/wrapped_svg.rs` | 269 |
| `rust/src/core/xdg_migrate.rs` | 819 |
| `rust/src/core/yaml_crush.rs` | 248 |

### `rust/src/core/a2a/`

| File | LOC |
|---|---:|
| `rust/src/core/a2a/a2a_compat.rs` | 316 |
| `rust/src/core/a2a/agent_card.rs` | 256 |
| `rust/src/core/a2a/budget_cascade.rs` | 200 |
| `rust/src/core/a2a/compress.rs` | 264 |
| `rust/src/core/a2a/cost_attribution.rs` | 386 |
| `rust/src/core/a2a/dlq.rs` | 235 |
| `rust/src/core/a2a/health.rs` | 144 |
| `rust/src/core/a2a/message.rs` | 177 |
| `rust/src/core/a2a/mod.rs` | 13 |
| `rust/src/core/a2a/rate_limiter.rs` | 247 |
| `rust/src/core/a2a/relay.rs` | 148 |
| `rust/src/core/a2a/remote_transport.rs` | 341 |
| `rust/src/core/a2a/task.rs` | 352 |
| `rust/src/core/a2a/telemetry.rs` | 138 |
| `rust/src/core/a2a/transfer.rs` | 95 |

### `rust/src/core/addons/`

| File | LOC |
|---|---:|
| `rust/src/core/addons/artifact_install.rs` | 346 |
| `rust/src/core/addons/audit.rs` | 442 |
| `rust/src/core/addons/binhash.rs` | 164 |
| `rust/src/core/addons/bootstrap.rs` | 747 |
| `rust/src/core/addons/capabilities.rs` | 417 |
| `rust/src/core/addons/commerce.rs` | 322 |
| `rust/src/core/addons/env_scrub.rs` | 173 |
| `rust/src/core/addons/grammar_install.rs` | 134 |
| `rust/src/core/addons/grammar_manifest.rs` | 179 |
| `rust/src/core/addons/grammar_registry.rs` | 142 |
| `rust/src/core/addons/health.rs` | 74 |
| `rust/src/core/addons/install.rs` | 379 |
| `rust/src/core/addons/integrity.rs` | 254 |
| `rust/src/core/addons/manifest.rs` | 670 |
| `rust/src/core/addons/meter.rs` | 160 |
| `rust/src/core/addons/mod.rs` | 102 |
| `rust/src/core/addons/ort_provision.rs` | 375 |
| `rust/src/core/addons/pack_env.rs` | 217 |
| `rust/src/core/addons/policy.rs` | 302 |
| `rust/src/core/addons/publish.rs` | 362 |
| `rust/src/core/addons/registry.rs` | 429 |
| `rust/src/core/addons/registry_snapshot.rs` | 144 |
| `rust/src/core/addons/revocation.rs` | 199 |
| `rust/src/core/addons/runtime.rs` | 54 |
| `rust/src/core/addons/sandbox.rs` | 555 |
| `rust/src/core/addons/scaffold.rs` | 227 |
| `rust/src/core/addons/signing.rs` | 193 |
| `rust/src/core/addons/store.rs` | 154 |
| `rust/src/core/addons/trust.rs` | 407 |

### `rust/src/core/agents/`

| File | LOC |
|---|---:|
| `rust/src/core/agents/bridge.rs` | 122 |
| `rust/src/core/agents/diary.rs` | 224 |
| `rust/src/core/agents/mod.rs` | 20 |
| `rust/src/core/agents/persistence.rs` | 82 |
| `rust/src/core/agents/reaper.rs` | 146 |
| `rust/src/core/agents/registry.rs` | 914 |
| `rust/src/core/agents/roles.rs` | 160 |
| `rust/src/core/agents/shared.rs` | 98 |
| `rust/src/core/agents/types.rs` | 78 |

### `rust/src/core/anti_interrupt/`

| File | LOC |
|---|---:|
| `rust/src/core/anti_interrupt/metrics.rs` | 152 |
| `rust/src/core/anti_interrupt/mod.rs` | 32 |
| `rust/src/core/anti_interrupt/tracker.rs` | 215 |

### `rust/src/core/benchmark_compare/`

| File | LOC |
|---|---:|
| `rust/src/core/benchmark_compare/competitors.rs` | 118 |
| `rust/src/core/benchmark_compare/metrics.rs` | 301 |
| `rust/src/core/benchmark_compare/mod.rs` | 58 |
| `rust/src/core/benchmark_compare/report.rs` | 505 |
| `rust/src/core/benchmark_compare/system_info.rs` | 154 |

### `rust/src/core/benchmark_study/`

| File | LOC |
|---|---:|
| `rust/src/core/benchmark_study/analysis.rs` | 398 |
| `rust/src/core/benchmark_study/experiment.rs` | 211 |
| `rust/src/core/benchmark_study/llm_client.rs` | 290 |
| `rust/src/core/benchmark_study/mod.rs` | 21 |
| `rust/src/core/benchmark_study/report.rs` | 148 |
| `rust/src/core/benchmark_study/runner.rs` | 312 |
| `rust/src/core/benchmark_study/sandbox.rs` | 163 |

### `rust/src/core/benchmark_study/datasets/`

| File | LOC |
|---|---:|
| `rust/src/core/benchmark_study/datasets/download.rs` | 80 |
| `rust/src/core/benchmark_study/datasets/humaneval.rs` | 55 |
| `rust/src/core/benchmark_study/datasets/mbpp.rs` | 57 |
| `rust/src/core/benchmark_study/datasets/mod.rs` | 7 |
| `rust/src/core/benchmark_study/datasets/swebench.rs` | 43 |

### `rust/src/core/benchmark_study/metrics/`

| File | LOC |
|---|---:|
| `rust/src/core/benchmark_study/metrics/cost.rs` | 32 |
| `rust/src/core/benchmark_study/metrics/mod.rs` | 8 |
| `rust/src/core/benchmark_study/metrics/pass_rate.rs` | 70 |
| `rust/src/core/benchmark_study/metrics/quality.rs` | 25 |

### `rust/src/core/benchmark_study/stats/`

| File | LOC |
|---|---:|
| `rust/src/core/benchmark_study/stats/bootstrap.rs` | 85 |
| `rust/src/core/benchmark_study/stats/mod.rs` | 5 |
| `rust/src/core/benchmark_study/stats/significance.rs` | 67 |

### `rust/src/core/billing/`

| File | LOC |
|---|---:|
| `rust/src/core/billing/metering.rs` | 66 |
| `rust/src/core/billing/mod.rs` | 73 |
| `rust/src/core/billing/plans.rs` | 471 |

### `rust/src/core/billing/settlement_evidence/`

| File | LOC |
|---|---:|
| `rust/src/core/billing/settlement_evidence/mod.rs` | 1420 |
| `rust/src/core/billing/settlement_evidence/tests.rs` | 694 |

### `rust/src/core/bm25_index/`

| File | LOC |
|---|---:|
| `rust/src/core/bm25_index/build.rs` | 445 |
| `rust/src/core/bm25_index/chunking.rs` | 322 |
| `rust/src/core/bm25_index/coordinator.rs` | 71 |
| `rust/src/core/bm25_index/mod.rs` | 1051 |
| `rust/src/core/bm25_index/tests.rs` | 1077 |

### `rust/src/core/buddy/`

| File | LOC |
|---|---:|
| `rust/src/core/buddy/achievements.rs` | 200 |
| `rust/src/core/buddy/ascension.rs` | 167 |
| `rust/src/core/buddy/evolution.rs` | 125 |
| `rust/src/core/buddy/format.rs` | 513 |
| `rust/src/core/buddy/mascot_art.rs` | 210 |
| `rust/src/core/buddy/mod.rs` | 105 |
| `rust/src/core/buddy/rpg.rs` | 162 |
| `rust/src/core/buddy/sprite.rs` | 18 |
| `rust/src/core/buddy/types.rs` | 388 |

### `rust/src/core/cache/`

| File | LOC |
|---|---:|
| `rust/src/core/cache/entry.rs` | 517 |
| `rust/src/core/cache/mod.rs` | 20 |
| `rust/src/core/cache/pipeline_tests.rs` | 142 |
| `rust/src/core/cache/session.rs` | 614 |
| `rust/src/core/cache/tests.rs` | 540 |
| `rust/src/core/cache/validation.rs` | 504 |
| `rust/src/core/cache/warming.rs` | 310 |

### `rust/src/core/code_health/`

| File | LOC |
|---|---:|
| `rust/src/core/code_health/annotate.rs` | 117 |
| `rust/src/core/code_health/astutil.rs` | 80 |
| `rust/src/core/code_health/cognitive.rs` | 326 |
| `rust/src/core/code_health/coupling.rs` | 112 |
| `rust/src/core/code_health/delta.rs` | 160 |
| `rust/src/core/code_health/fabric.rs` | 385 |
| `rust/src/core/code_health/gate.rs` | 98 |
| `rust/src/core/code_health/mod.rs` | 128 |
| `rust/src/core/code_health/naming.rs` | 164 |
| `rust/src/core/code_health/persist.rs` | 180 |
| `rust/src/core/code_health/report.rs` | 128 |
| `rust/src/core/code_health/scan.rs` | 229 |
| `rust/src/core/code_health/score.rs` | 184 |

### `rust/src/core/codesign/`

| File | LOC |
|---|---:|
| `rust/src/core/codesign/mod.rs` | 162 |
| `rust/src/core/codesign/setup.rs` | 224 |

### `rust/src/core/cognitive/`

| File | LOC |
|---|---:|
| `rust/src/core/cognitive/chunker.rs` | 454 |
| `rust/src/core/cognitive/mod.rs` | 9 |

### `rust/src/core/community/`

| File | LOC |
|---|---:|
| `rust/src/core/community/graph.rs` | 239 |
| `rust/src/core/community/hardening.rs` | 227 |
| `rust/src/core/community/leiden.rs` | 244 |
| `rust/src/core/community/mod.rs` | 174 |
| `rust/src/core/community/stable_ids.rs` | 166 |
| `rust/src/core/community/tests.rs` | 239 |

### `rust/src/core/compliance_report/`

| File | LOC |
|---|---:|
| `rust/src/core/compliance_report/aggregate.rs` | 306 |
| `rust/src/core/compliance_report/mod.rs` | 285 |
| `rust/src/core/compliance_report/model.rs` | 324 |
| `rust/src/core/compliance_report/pdf.rs` | 296 |
| `rust/src/core/compliance_report/render.rs` | 356 |

### `rust/src/core/config/`

| File | LOC |
|---|---:|
| `rust/src/core/config/defaults.rs` | 205 |
| `rust/src/core/config/defaults_allowlist.rs` | 371 |
| `rust/src/core/config/enterprise.rs` | 149 |
| `rust/src/core/config/enums.rs` | 519 |
| `rust/src/core/config/loader.rs` | 480 |
| `rust/src/core/config/logic.rs` | 628 |
| `rust/src/core/config/memory.rs` | 210 |
| `rust/src/core/config/merge.rs` | 330 |
| `rust/src/core/config/mod.rs` | 75 |
| `rust/src/core/config/model.rs` | 741 |
| `rust/src/core/config/provenance.rs` | 319 |
| `rust/src/core/config/proxy.rs` | 1425 |
| `rust/src/core/config/proxy_tests.rs` | 956 |
| `rust/src/core/config/read_dedup.rs` | 184 |
| `rust/src/core/config/read_redirect.rs` | 289 |
| `rust/src/core/config/render.rs` | 276 |
| `rust/src/core/config/response_shaping.rs` | 148 |
| `rust/src/core/config/risk.rs` | 106 |
| `rust/src/core/config/sections.rs` | 1527 |
| `rust/src/core/config/serde_defaults.rs` | 86 |
| `rust/src/core/config/setter.rs` | 297 |
| `rust/src/core/config/shell_activation.rs` | 145 |
| `rust/src/core/config/solution.rs` | 112 |
| `rust/src/core/config/solution_tests.rs` | 180 |
| `rust/src/core/config/tests.rs` | 77 |
| `rust/src/core/config/tests_config_load_cache.rs` | 32 |
| `rust/src/core/config/tests_config_path_visibility.rs` | 28 |
| `rust/src/core/config/tests_config_profiles.rs` | 98 |
| `rust/src/core/config/tests_context_budget.rs` | 65 |
| `rust/src/core/config/tests_cost_config.rs` | 87 |
| `rust/src/core/config/tests_default_tool_categories.rs` | 114 |
| `rust/src/core/config/tests_delta_explicit.rs` | 148 |
| `rust/src/core/config/tests_disabled_tools.rs` | 59 |
| `rust/src/core/config/tests_extra_roots.rs` | 189 |
| `rust/src/core/config/tests_loop_detection_config.rs` | 54 |
| `rust/src/core/config/tests_max_index_threads.rs` | 39 |
| `rust/src/core/config/tests_no_degrade.rs` | 98 |
| `rust/src/core/config/tests_parsing.rs` | 476 |
| `rust/src/core/config/tests_permission_inheritance.rs` | 80 |
| `rust/src/core/config/tests_persist_global.rs` | 96 |
| `rust/src/core/config/tests_prefer_native_editor.rs` | 73 |
| `rust/src/core/config/tests_rules_injection.rs` | 85 |
| `rust/src/core/config/tests_rules_scope.rs` | 48 |
| `rust/src/core/config/tests_shell_timeout_and_writes.rs` | 104 |

### `rust/src/core/config/schema/`

| File | LOC |
|---|---:|
| `rust/src/core/config/schema/mod.rs` | 303 |
| `rust/src/core/config/schema/sections_advanced.rs` | 671 |
| `rust/src/core/config/schema/sections_core.rs` | 1396 |
| `rust/src/core/config/schema/sections_features.rs` | 821 |

### `rust/src/core/context_kernel/`

| File | LOC |
|---|---:|
| `rust/src/core/context_kernel/a2a_fixes.rs` | 224 |
| `rust/src/core/context_kernel/accounting_fix.rs` | 252 |
| `rust/src/core/context_kernel/activation.rs` | 258 |
| `rust/src/core/context_kernel/activation_e2e.rs` | 204 |
| `rust/src/core/context_kernel/adaptive_bridge.rs` | 132 |
| `rust/src/core/context_kernel/adaptive_hook.rs` | 127 |
| `rust/src/core/context_kernel/airgap_e2e.rs` | 121 |
| `rust/src/core/context_kernel/attribution.rs` | 170 |
| `rust/src/core/context_kernel/bench.rs` | 238 |
| `rust/src/core/context_kernel/bounded.rs` | 290 |
| `rust/src/core/context_kernel/bridge.rs` | 380 |
| `rust/src/core/context_kernel/bridge_e2e.rs` | 146 |
| `rust/src/core/context_kernel/capsule_wire.rs` | 295 |
| `rust/src/core/context_kernel/client_e2e.rs` | 133 |
| `rust/src/core/context_kernel/client_profile.rs` | 300 |
| `rust/src/core/context_kernel/client_wiring.rs` | 203 |
| `rust/src/core/context_kernel/config_bridge.rs` | 222 |
| `rust/src/core/context_kernel/conformance.rs` | 168 |
| `rust/src/core/context_kernel/context_broker.rs` | 210 |
| `rust/src/core/context_kernel/context_dedup.rs` | 253 |
| `rust/src/core/context_kernel/coverage_class.rs` | 151 |
| `rust/src/core/context_kernel/ctx_read_dedup.rs` | 152 |
| `rust/src/core/context_kernel/dashboard_report.rs` | 191 |
| `rust/src/core/context_kernel/dedup_wiring.rs` | 252 |
| `rust/src/core/context_kernel/degradation.rs` | 245 |
| `rust/src/core/context_kernel/enforce.rs` | 185 |
| `rust/src/core/context_kernel/envelope_bridge.rs` | 186 |
| `rust/src/core/context_kernel/envelope_e2e.rs` | 213 |
| `rust/src/core/context_kernel/envelope_wiring.rs` | 234 |
| `rust/src/core/context_kernel/etpao.rs` | 294 |
| `rust/src/core/context_kernel/etpao_live.rs` | 242 |
| `rust/src/core/context_kernel/evidence_bundle.rs` | 100 |
| `rust/src/core/context_kernel/evidence_hook.rs` | 149 |
| `rust/src/core/context_kernel/evidence_wiring.rs` | 148 |
| `rust/src/core/context_kernel/fail_matrix.rs` | 282 |
| `rust/src/core/context_kernel/feedback.rs` | 211 |
| `rust/src/core/context_kernel/feedback_e2e.rs` | 117 |
| `rust/src/core/context_kernel/health.rs` | 139 |
| `rust/src/core/context_kernel/health_api.rs` | 103 |
| `rust/src/core/context_kernel/hotpath_wiring.rs` | 262 |
| `rust/src/core/context_kernel/identity.rs` | 336 |
| `rust/src/core/context_kernel/identity_resolver.rs` | 165 |
| `rust/src/core/context_kernel/integration_e2e.rs` | 171 |
| `rust/src/core/context_kernel/invalidation.rs` | 293 |
| `rust/src/core/context_kernel/kernel_config.rs` | 247 |
| `rust/src/core/context_kernel/knowledge_health.rs` | 214 |
| `rust/src/core/context_kernel/learning.rs` | 154 |
| `rust/src/core/context_kernel/list_tools_opt.rs` | 164 |
| `rust/src/core/context_kernel/live_dashboard.rs` | 235 |
| `rust/src/core/context_kernel/mcp_bridge.rs` | 352 |
| `rust/src/core/context_kernel/mcp_coverage.rs` | 123 |
| `rust/src/core/context_kernel/mcp_e2e.rs` | 185 |
| `rust/src/core/context_kernel/mcp_receipt.rs` | 200 |
| `rust/src/core/context_kernel/mcp_schema_opt.rs` | 236 |
| `rust/src/core/context_kernel/mod.rs` | 133 |
| `rust/src/core/context_kernel/multi_agent_e2e.rs` | 199 |
| `rust/src/core/context_kernel/orchestrator.rs` | 484 |
| `rust/src/core/context_kernel/outcome_signal.rs` | 225 |
| `rust/src/core/context_kernel/perf_benchmark.rs` | 151 |
| `rust/src/core/context_kernel/policy.rs` | 225 |
| `rust/src/core/context_kernel/policy_engine.rs` | 358 |
| `rust/src/core/context_kernel/production_e2e.rs` | 240 |
| `rust/src/core/context_kernel/provider_display.rs` | 169 |
| `rust/src/core/context_kernel/provider_metrics_e2e.rs` | 162 |
| `rust/src/core/context_kernel/provider_normalization.rs` | 589 |
| `rust/src/core/context_kernel/provider_parity.rs` | 205 |
| `rust/src/core/context_kernel/provider_traces.rs` | 155 |
| `rust/src/core/context_kernel/providers.rs` | 549 |
| `rust/src/core/context_kernel/proxy_bridge.rs` | 254 |
| `rust/src/core/context_kernel/quality_e2e.rs` | 87 |
| `rust/src/core/context_kernel/receipt_builder.rs` | 517 |
| `rust/src/core/context_kernel/receipt_chain.rs` | 250 |
| `rust/src/core/context_kernel/recovery.rs` | 203 |
| `rust/src/core/context_kernel/response_evidence.rs` | 109 |
| `rust/src/core/context_kernel/result_fusion.rs` | 296 |
| `rust/src/core/context_kernel/schema_wiring.rs` | 239 |
| `rust/src/core/context_kernel/shadow.rs` | 146 |
| `rust/src/core/context_kernel/smoke_test.rs` | 173 |
| `rust/src/core/context_kernel/startup.rs` | 110 |
| `rust/src/core/context_kernel/stream_controller.rs` | 280 |
| `rust/src/core/context_kernel/token_envelope.rs` | 306 |
| `rust/src/core/context_kernel/tool_surface.rs` | 344 |
| `rust/src/core/context_kernel/types.rs` | 404 |
| `rust/src/core/context_kernel/usage_normalizer.rs` | 249 |
| `rust/src/core/context_kernel/wiring_e2e.rs` | 164 |

### `rust/src/core/context_ledger/`

| File | LOC |
|---|---:|
| `rust/src/core/context_ledger/helpers.rs` | 80 |
| `rust/src/core/context_ledger/ledger.rs` | 651 |
| `rust/src/core/context_ledger/mod.rs` | 14 |
| `rust/src/core/context_ledger/reinjection.rs` | 115 |
| `rust/src/core/context_ledger/tests.rs` | 561 |
| `rust/src/core/context_ledger/types.rs` | 83 |

### `rust/src/core/context_os/`

| File | LOC |
|---|---:|
| `rust/src/core/context_os/context_bus.rs` | 929 |
| `rust/src/core/context_os/metrics.rs` | 110 |
| `rust/src/core/context_os/mod.rs` | 196 |
| `rust/src/core/context_os/redaction.rs` | 149 |
| `rust/src/core/context_os/shared_sessions.rs` | 294 |

### `rust/src/core/context_package/`

| File | LOC |
|---|---:|
| `rust/src/core/context_package/auto_load.rs` | 65 |
| `rust/src/core/context_package/builder.rs` | 702 |
| `rust/src/core/context_package/bundle.rs` | 81 |
| `rust/src/core/context_package/composition.rs` | 442 |
| `rust/src/core/context_package/content.rs` | 274 |
| `rust/src/core/context_package/deps.rs` | 432 |
| `rust/src/core/context_package/export.rs` | 92 |
| `rust/src/core/context_package/graph_model.rs` | 447 |
| `rust/src/core/context_package/import.rs` | 283 |
| `rust/src/core/context_package/keys.rs` | 102 |
| `rust/src/core/context_package/loader.rs` | 777 |
| `rust/src/core/context_package/lockfile.rs` | 125 |
| `rust/src/core/context_package/manifest.rs` | 468 |
| `rust/src/core/context_package/mod.rs` | 35 |
| `rust/src/core/context_package/registry.rs` | 741 |
| `rust/src/core/context_package/remote.rs` | 394 |
| `rust/src/core/context_package/signing.rs` | 176 |
| `rust/src/core/context_package/skills.rs` | 438 |
| `rust/src/core/context_package/verify.rs` | 699 |

### `rust/src/core/context_prefetch/`

| File | LOC |
|---|---:|
| `rust/src/core/context_prefetch/mod.rs` | 93 |
| `rust/src/core/context_prefetch/warming.rs` | 119 |

### `rust/src/core/context_snapshot/`

| File | LOC |
|---|---:|
| `rust/src/core/context_snapshot/builder.rs` | 339 |
| `rust/src/core/context_snapshot/digest.rs` | 84 |
| `rust/src/core/context_snapshot/mod.rs` | 135 |
| `rust/src/core/context_snapshot/publish.rs` | 235 |
| `rust/src/core/context_snapshot/restore.rs` | 240 |
| `rust/src/core/context_snapshot/signing.rs` | 167 |
| `rust/src/core/context_snapshot/timeline.rs` | 276 |
| `rust/src/core/context_snapshot/types.rs` | 184 |

### `rust/src/core/contextops/`

| File | LOC |
|---|---:|
| `rust/src/core/contextops/config.rs` | 263 |
| `rust/src/core/contextops/drift.rs` | 222 |
| `rust/src/core/contextops/lint.rs` | 299 |
| `rust/src/core/contextops/mod.rs` | 259 |
| `rust/src/core/contextops/sync.rs` | 176 |

### `rust/src/core/deep_queries/`

| File | LOC |
|---|---:|
| `rust/src/core/deep_queries/calls.rs` | 519 |
| `rust/src/core/deep_queries/ext_methods.rs` | 76 |
| `rust/src/core/deep_queries/imports.rs` | 922 |
| `rust/src/core/deep_queries/mod.rs` | 1206 |
| `rust/src/core/deep_queries/type_defs.rs` | 467 |
| `rust/src/core/deep_queries/type_uses.rs` | 280 |
| `rust/src/core/deep_queries/types.rs` | 104 |

### `rust/src/core/editor_registry/`

| File | LOC |
|---|---:|
| `rust/src/core/editor_registry/detect.rs` | 997 |
| `rust/src/core/editor_registry/mod.rs` | 11 |
| `rust/src/core/editor_registry/paths.rs` | 434 |
| `rust/src/core/editor_registry/plan_mode.rs` | 529 |
| `rust/src/core/editor_registry/types.rs` | 48 |

### `rust/src/core/editor_registry/writers/`

| File | LOC |
|---|---:|
| `rust/src/core/editor_registry/writers/mod.rs` | 103 |
| `rust/src/core/editor_registry/writers/shared.rs` | 367 |
| `rust/src/core/editor_registry/writers/tests.rs` | 1069 |
| `rust/src/core/editor_registry/writers/uninstall.rs` | 549 |

### `rust/src/core/editor_registry/writers/install/`

| File | LOC |
|---|---:|
| `rust/src/core/editor_registry/writers/install/amp.rs` | 64 |
| `rust/src/core/editor_registry/writers/install/claude.rs` | 191 |
| `rust/src/core/editor_registry/writers/install/cline_cli.rs` | 84 |
| `rust/src/core/editor_registry/writers/install/codex.rs` | 133 |
| `rust/src/core/editor_registry/writers/install/commandcode.rs` | 85 |
| `rust/src/core/editor_registry/writers/install/copilot.rs` | 81 |
| `rust/src/core/editor_registry/writers/install/crush.rs` | 79 |
| `rust/src/core/editor_registry/writers/install/gemini.rs` | 65 |
| `rust/src/core/editor_registry/writers/install/hermes.rs` | 106 |
| `rust/src/core/editor_registry/writers/install/jetbrains.rs` | 69 |
| `rust/src/core/editor_registry/writers/install/mod.rs` | 58 |
| `rust/src/core/editor_registry/writers/install/openclaw.rs` | 187 |
| `rust/src/core/editor_registry/writers/install/opencode.rs` | 117 |
| `rust/src/core/editor_registry/writers/install/qoder.rs` | 62 |
| `rust/src/core/editor_registry/writers/install/vibe.rs` | 113 |
| `rust/src/core/editor_registry/writers/install/vscode.rs` | 195 |
| `rust/src/core/editor_registry/writers/install/zed.rs` | 83 |

### `rust/src/core/embeddings/`

| File | LOC |
|---|---:|
| `rust/src/core/embeddings/download.rs` | 374 |
| `rust/src/core/embeddings/mod.rs` | 1090 |
| `rust/src/core/embeddings/model_registry.rs` | 567 |
| `rust/src/core/embeddings/pooling.rs` | 156 |
| `rust/src/core/embeddings/tokenizer.rs` | 511 |

### `rust/src/core/eval_ab/`

| File | LOC |
|---|---:|
| `rust/src/core/eval_ab/artifact.rs` | 328 |
| `rust/src/core/eval_ab/conditions.rs` | 421 |
| `rust/src/core/eval_ab/footprint.rs` | 626 |
| `rust/src/core/eval_ab/judge.rs` | 223 |
| `rust/src/core/eval_ab/mod.rs` | 343 |
| `rust/src/core/eval_ab/model.rs` | 442 |
| `rust/src/core/eval_ab/report.rs` | 384 |
| `rust/src/core/eval_ab/routing_eval.rs` | 454 |
| `rust/src/core/eval_ab/scorers.rs` | 340 |
| `rust/src/core/eval_ab/suite.rs` | 216 |

### `rust/src/core/eval_ab/testbench/`

| File | LOC |
|---|---:|
| `rust/src/core/eval_ab/testbench/clone.rs` | 213 |
| `rust/src/core/eval_ab/testbench/findings.rs` | 266 |
| `rust/src/core/eval_ab/testbench/lockfile.rs` | 199 |
| `rust/src/core/eval_ab/testbench/mod.rs` | 386 |
| `rust/src/core/eval_ab/testbench/recording.rs` | 72 |

### `rust/src/core/execution_ledger/`

| File | LOC |
|---|---:|
| `rust/src/core/execution_ledger/event.rs` | 233 |
| `rust/src/core/execution_ledger/migration.rs` | 79 |
| `rust/src/core/execution_ledger/mod.rs` | 344 |
| `rust/src/core/execution_ledger/projection.rs` | 243 |
| `rust/src/core/execution_ledger/store.rs` | 147 |
| `rust/src/core/execution_ledger/verify.rs` | 46 |

### `rust/src/core/extractive/`

| File | LOC |
|---|---:|
| `rust/src/core/extractive/mod.rs` | 99 |
| `rust/src/core/extractive/ranker.rs` | 249 |
| `rust/src/core/extractive/segment.rs` | 150 |
| `rust/src/core/extractive/tests.rs` | 299 |

### `rust/src/core/extractors/`

| File | LOC |
|---|---:|
| `rust/src/core/extractors/csv.rs` | 151 |
| `rust/src/core/extractors/eml.rs` | 201 |
| `rust/src/core/extractors/json.rs` | 75 |
| `rust/src/core/extractors/mod.rs` | 235 |

### `rust/src/core/finops_export/`

| File | LOC |
|---|---:|
| `rust/src/core/finops_export/aliases.rs` | 201 |
| `rust/src/core/finops_export/cbf.rs` | 184 |
| `rust/src/core/finops_export/focus.rs` | 292 |
| `rust/src/core/finops_export/mod.rs` | 243 |
| `rust/src/core/finops_export/vantage.rs` | 173 |

### `rust/src/core/gain/`

| File | LOC |
|---|---:|
| `rust/src/core/gain/bounce_cost.rs` | 126 |
| `rust/src/core/gain/bridge_status.rs` | 211 |
| `rust/src/core/gain/gain_score.rs` | 333 |
| `rust/src/core/gain/live_pricing.rs` | 713 |
| `rust/src/core/gain/mod.rs` | 292 |
| `rust/src/core/gain/model_pricing.rs` | 810 |
| `rust/src/core/gain/stream_savings.rs` | 139 |
| `rust/src/core/gain/task_classifier.rs` | 213 |

### `rust/src/core/git/`

| File | LOC |
|---|---:|
| `rust/src/core/git/clone.rs` | 217 |
| `rust/src/core/git/mod.rs` | 156 |
| `rust/src/core/git/repo_url.rs` | 219 |
| `rust/src/core/git/shadow.rs` | 358 |

### `rust/src/core/godot/`

| File | LOC |
|---|---:|
| `rust/src/core/godot/mod.rs` | 8 |
| `rust/src/core/godot/scene.rs` | 120 |

### `rust/src/core/gotcha_tracker/`

| File | LOC |
|---|---:|
| `rust/src/core/gotcha_tracker/detect.rs` | 263 |
| `rust/src/core/gotcha_tracker/learn.rs` | 245 |
| `rust/src/core/gotcha_tracker/mining.rs` | 287 |
| `rust/src/core/gotcha_tracker/mod.rs` | 898 |
| `rust/src/core/gotcha_tracker/model.rs` | 321 |
| `rust/src/core/gotcha_tracker/persist.rs` | 127 |
| `rust/src/core/gotcha_tracker/reflector.rs` | 354 |
| `rust/src/core/gotcha_tracker/runtime.rs` | 165 |

### `rust/src/core/graph_analysis/`

| File | LOC |
|---|---:|
| `rust/src/core/graph_analysis/centrality.rs` | 239 |
| `rust/src/core/graph_analysis/cycles.rs` | 199 |
| `rust/src/core/graph_analysis/god_nodes.rs` | 104 |
| `rust/src/core/graph_analysis/mod.rs` | 104 |
| `rust/src/core/graph_analysis/surprising.rs` | 153 |

### `rust/src/core/graph_expand/`

| File | LOC |
|---|---:|
| `rust/src/core/graph_expand/hops.rs` | 139 |
| `rust/src/core/graph_expand/mod.rs` | 13 |
| `rust/src/core/graph_expand/partial.rs` | 163 |

### `rust/src/core/graph_index/`

| File | LOC |
|---|---:|
| `rust/src/core/graph_index/edges.rs` | 611 |
| `rust/src/core/graph_index/file_id.rs` | 220 |
| `rust/src/core/graph_index/mod.rs` | 1288 |
| `rust/src/core/graph_index/tests.rs` | 1115 |

### `rust/src/core/ib/`

| File | LOC |
|---|---:|
| `rust/src/core/ib/intent.rs` | 153 |
| `rust/src/core/ib/mod.rs` | 11 |
| `rust/src/core/ib/relevance.rs` | 230 |

### `rust/src/core/import/`

| File | LOC |
|---|---:|
| `rust/src/core/import/claude_code.rs` | 71 |
| `rust/src/core/import/codex.rs` | 200 |
| `rust/src/core/import/cursor.rs` | 62 |
| `rust/src/core/import/mod.rs` | 397 |

### `rust/src/core/import_resolver/`

| File | LOC |
|---|---:|
| `rust/src/core/import_resolver/languages.rs` | 1152 |
| `rust/src/core/import_resolver/mod.rs` | 325 |
| `rust/src/core/import_resolver/tests.rs` | 615 |

### `rust/src/core/input_filters/`

| File | LOC |
|---|---:|
| `rust/src/core/input_filters/classification.rs` | 135 |
| `rust/src/core/input_filters/injection.rs` | 74 |
| `rust/src/core/input_filters/mod.rs` | 374 |
| `rust/src/core/input_filters/pii.rs` | 303 |

### `rust/src/core/knowledge/`

| File | LOC |
|---|---:|
| `rust/src/core/knowledge/chunking.rs` | 332 |
| `rust/src/core/knowledge/core.rs` | 403 |
| `rust/src/core/knowledge/fact.rs` | 79 |
| `rust/src/core/knowledge/format.rs` | 332 |
| `rust/src/core/knowledge/import_export.rs` | 230 |
| `rust/src/core/knowledge/local_store.rs` | 181 |
| `rust/src/core/knowledge/maintenance.rs` | 251 |
| `rust/src/core/knowledge/mod.rs` | 970 |
| `rust/src/core/knowledge/okf.rs` | 920 |
| `rust/src/core/knowledge/persist.rs` | 515 |
| `rust/src/core/knowledge/query.rs` | 344 |
| `rust/src/core/knowledge/ranking.rs` | 233 |
| `rust/src/core/knowledge/retrieval.rs` | 205 |
| `rust/src/core/knowledge/snapshot.rs` | 140 |
| `rust/src/core/knowledge/store.rs` | 71 |
| `rust/src/core/knowledge/supersession.rs` | 22 |
| `rust/src/core/knowledge/types.rs` | 453 |

### `rust/src/core/knowledge_router/`

| File | LOC |
|---|---:|
| `rust/src/core/knowledge_router/context_bundle.rs` | 82 |
| `rust/src/core/knowledge_router/gate_integration.rs` | 135 |
| `rust/src/core/knowledge_router/gate_integration_tests.rs` | 111 |
| `rust/src/core/knowledge_router/knowledge_router_tests.rs` | 212 |
| `rust/src/core/knowledge_router/manifest_builder.rs` | 92 |
| `rust/src/core/knowledge_router/mod.rs` | 255 |
| `rust/src/core/knowledge_router/planner.rs` | 116 |
| `rust/src/core/knowledge_router/provider_bridge.rs` | 150 |
| `rust/src/core/knowledge_router/receipt.rs` | 80 |
| `rust/src/core/knowledge_router/reference_resolver.rs` | 100 |
| `rust/src/core/knowledge_router/source_manifest.rs` | 87 |

### `rust/src/core/locomo/`

| File | LOC |
|---|---:|
| `rust/src/core/locomo/dataset.rs` | 146 |
| `rust/src/core/locomo/mod.rs` | 35 |
| `rust/src/core/locomo/report.rs` | 179 |
| `rust/src/core/locomo/runner.rs` | 117 |

### `rust/src/core/mcp_catalog/`

| File | LOC |
|---|---:|
| `rust/src/core/mcp_catalog/catalog.rs` | 248 |
| `rust/src/core/mcp_catalog/client.rs` | 223 |
| `rust/src/core/mcp_catalog/config.rs` | 747 |
| `rust/src/core/mcp_catalog/memento.rs` | 121 |
| `rust/src/core/mcp_catalog/mod.rs` | 237 |
| `rust/src/core/mcp_catalog/pool.rs` | 275 |
| `rust/src/core/mcp_catalog/router.rs` | 167 |

### `rust/src/core/mcp_catalog/adapters/`

| File | LOC |
|---|---:|
| `rust/src/core/mcp_catalog/adapters/code_graph.rs` | 109 |
| `rust/src/core/mcp_catalog/adapters/code_symbols.rs` | 150 |
| `rust/src/core/mcp_catalog/adapters/codebase_pack.rs` | 106 |
| `rust/src/core/mcp_catalog/adapters/compression.rs` | 172 |
| `rust/src/core/mcp_catalog/adapters/memory.rs` | 149 |
| `rust/src/core/mcp_catalog/adapters/mod.rs` | 208 |

### `rust/src/core/mcp_catalog/postprocess/`

| File | LOC |
|---|---:|
| `rust/src/core/mcp_catalog/postprocess/compress.rs` | 102 |
| `rust/src/core/mcp_catalog/postprocess/index.rs` | 80 |
| `rust/src/core/mcp_catalog/postprocess/mod.rs` | 123 |
| `rust/src/core/mcp_catalog/postprocess/spill.rs` | 77 |

### `rust/src/core/mdl_mode/`

| File | LOC |
|---|---:|
| `rust/src/core/mdl_mode/bounds.rs` | 36 |
| `rust/src/core/mdl_mode/mod.rs` | 10 |
| `rust/src/core/mdl_mode/structural.rs` | 376 |

### `rust/src/core/measurement/`

| File | LOC |
|---|---:|
| `rust/src/core/measurement/baseline_recorder.rs` | 111 |
| `rust/src/core/measurement/comparison.rs` | 138 |
| `rust/src/core/measurement/mod.rs` | 137 |
| `rust/src/core/measurement/report.rs` | 49 |
| `rust/src/core/measurement/treatment_recorder.rs` | 98 |

### `rust/src/core/memory_scheduler/`

| File | LOC |
|---|---:|
| `rust/src/core/memory_scheduler/decay.rs` | 143 |
| `rust/src/core/memory_scheduler/fsrs.rs` | 192 |
| `rust/src/core/memory_scheduler/mod.rs` | 12 |

### `rust/src/core/neural/`

| File | LOC |
|---|---:|
| `rust/src/core/neural/attention_learned.rs` | 159 |
| `rust/src/core/neural/cache_alignment.rs` | 336 |
| `rust/src/core/neural/context_reorder.rs` | 237 |
| `rust/src/core/neural/line_scorer.rs` | 410 |
| `rust/src/core/neural/mod.rs` | 99 |
| `rust/src/core/neural/token_optimizer.rs` | 307 |

### `rust/src/core/ocla/`

| File | LOC |
|---|---:|
| `rust/src/core/ocla/agent_gateway.rs` | 55 |
| `rust/src/core/ocla/budget.rs` | 230 |
| `rust/src/core/ocla/cache_coordinator.rs` | 297 |
| `rust/src/core/ocla/cache_delivery.rs` | 155 |
| `rust/src/core/ocla/cache_tiers.rs` | 465 |
| `rust/src/core/ocla/cache_types.rs` | 578 |
| `rust/src/core/ocla/capsule.rs` | 778 |
| `rust/src/core/ocla/catalogue.rs` | 83 |
| `rust/src/core/ocla/compose_cache.rs` | 119 |
| `rust/src/core/ocla/content_port.rs` | 446 |
| `rust/src/core/ocla/grpc_bridge.rs` | 218 |
| `rust/src/core/ocla/health.rs` | 477 |
| `rust/src/core/ocla/invocation.rs` | 225 |
| `rust/src/core/ocla/ledger_export.rs` | 209 |
| `rust/src/core/ocla/mod.rs` | 59 |
| `rust/src/core/ocla/openapi.rs` | 690 |
| `rust/src/core/ocla/policy_bundle.rs` | 448 |
| `rust/src/core/ocla/policy_constraints.rs` | 208 |
| `rust/src/core/ocla/reference_scheduler.rs` | 548 |
| `rust/src/core/ocla/registry.rs` | 518 |
| `rust/src/core/ocla/regression_gate.rs` | 120 |
| `rust/src/core/ocla/response_cache.rs` | 473 |
| `rust/src/core/ocla/routing_experiment.rs` | 278 |
| `rust/src/core/ocla/routing_quality.rs` | 182 |
| `rust/src/core/ocla/runtime.rs` | 107 |
| `rust/src/core/ocla/scheduler_client.rs` | 193 |
| `rust/src/core/ocla/scheduler_service.rs` | 99 |
| `rust/src/core/ocla/shell_cache_allowlist.rs` | 123 |
| `rust/src/core/ocla/sidecar.rs` | 193 |
| `rust/src/core/ocla/tracing.rs` | 344 |
| `rust/src/core/ocla/traits.rs` | 124 |
| `rust/src/core/ocla/types.rs` | 903 |
| `rust/src/core/ocla/unified_ledger.rs` | 682 |
| `rust/src/core/ocla/wire.rs` | 358 |
| `rust/src/core/ocla/wire_api.rs` | 1342 |
| `rust/src/core/ocla/wire_middleware.rs` | 304 |
| `rust/src/core/ocla/wire_stream.rs` | 196 |

### `rust/src/core/ocla/adapters/`

| File | LOC |
|---|---:|
| `rust/src/core/ocla/adapters/mod.rs` | 184 |
| `rust/src/core/ocla/adapters/native_context.rs` | 233 |
| `rust/src/core/ocla/adapters/passthrough.rs` | 122 |
| `rust/src/core/ocla/adapters/registry.rs` | 211 |

### `rust/src/core/ocla/builtin/`

| File | LOC |
|---|---:|
| `rust/src/core/ocla/builtin/agent_gateway.rs` | 449 |
| `rust/src/core/ocla/builtin/compression_provider.rs` | 434 |
| `rust/src/core/ocla/builtin/config_tuner.rs` | 181 |
| `rust/src/core/ocla/builtin/connector_scheduler.rs` | 131 |
| `rust/src/core/ocla/builtin/delivery_registry.rs` | 710 |
| `rust/src/core/ocla/builtin/efficiency_analyzer.rs` | 222 |
| `rust/src/core/ocla/builtin/experiment_executor.rs` | 392 |
| `rust/src/core/ocla/builtin/experiment_runner.rs` | 2 |
| `rust/src/core/ocla/builtin/intent_classifier.rs` | 143 |
| `rust/src/core/ocla/builtin/metrics_exporter.rs` | 185 |
| `rust/src/core/ocla/builtin/mod.rs` | 22 |
| `rust/src/core/ocla/builtin/model_router.rs` | 561 |
| `rust/src/core/ocla/builtin/observation_hook.rs` | 364 |
| `rust/src/core/ocla/builtin/outcome_tracker.rs` | 152 |
| `rust/src/core/ocla/builtin/response_optimizer.rs` | 170 |
| `rust/src/core/ocla/builtin/savings_ledger.rs` | 232 |
| `rust/src/core/ocla/builtin/usage_sink.rs` | 125 |

### `rust/src/core/ocla/reference_adapters/`

| File | LOC |
|---|---:|
| `rust/src/core/ocla/reference_adapters/comparison_receipt.rs` | 199 |
| `rust/src/core/ocla/reference_adapters/kill_switch.rs` | 78 |
| `rust/src/core/ocla/reference_adapters/mod.rs` | 27 |
| `rust/src/core/ocla/reference_adapters/report.rs` | 660 |
| `rust/src/core/ocla/reference_adapters/rtk_shell.rs` | 1100 |
| `rust/src/core/ocla/reference_adapters/shadow_runner.rs` | 505 |

### `rust/src/core/outcome/`

| File | LOC |
|---|---:|
| `rust/src/core/outcome/contracts.rs` | 273 |
| `rust/src/core/outcome/evaluator.rs` | 937 |
| `rust/src/core/outcome/fingerprint.rs` | 65 |
| `rust/src/core/outcome/mod.rs` | 23 |
| `rust/src/core/outcome/signals.rs` | 253 |

### `rust/src/core/patterns/`

| File | LOC |
|---|---:|
| `rust/src/core/patterns/alembic.rs` | 143 |
| `rust/src/core/patterns/ansible.rs` | 85 |
| `rust/src/core/patterns/argocd.rs` | 141 |
| `rust/src/core/patterns/artisan.rs` | 320 |
| `rust/src/core/patterns/aws.rs` | 241 |
| `rust/src/core/patterns/bazel.rs` | 117 |
| `rust/src/core/patterns/buf.rs` | 77 |
| `rust/src/core/patterns/bun.rs` | 149 |
| `rust/src/core/patterns/cargo.rs` | 951 |
| `rust/src/core/patterns/cargo_diagnostics.rs` | 407 |
| `rust/src/core/patterns/clang.rs` | 203 |
| `rust/src/core/patterns/cmake.rs` | 166 |
| `rust/src/core/patterns/composer.rs` | 101 |
| `rust/src/core/patterns/cosign.rs` | 64 |
| `rust/src/core/patterns/curl.rs` | 299 |
| `rust/src/core/patterns/dbt.rs` | 168 |
| `rust/src/core/patterns/deno.rs` | 145 |
| `rust/src/core/patterns/deploy.rs` | 183 |
| `rust/src/core/patterns/deps_cmd.rs` | 275 |
| `rust/src/core/patterns/docker.rs` | 536 |
| `rust/src/core/patterns/dotnet.rs` | 302 |
| `rust/src/core/patterns/env_filter.rs` | 89 |
| `rust/src/core/patterns/eslint.rs` | 145 |
| `rust/src/core/patterns/fd.rs` | 107 |
| `rust/src/core/patterns/find.rs` | 82 |
| `rust/src/core/patterns/flutter.rs` | 196 |
| `rust/src/core/patterns/flyway.rs` | 158 |
| `rust/src/core/patterns/gem.rs` | 117 |
| `rust/src/core/patterns/gh.rs` | 343 |
| `rust/src/core/patterns/glab.rs` | 103 |
| `rust/src/core/patterns/golang.rs` | 216 |
| `rust/src/core/patterns/grep.rs` | 240 |
| `rust/src/core/patterns/grype.rs` | 106 |
| `rust/src/core/patterns/helm.rs` | 155 |
| `rust/src/core/patterns/jj.rs` | 141 |
| `rust/src/core/patterns/json_schema.rs` | 192 |
| `rust/src/core/patterns/just.rs` | 165 |
| `rust/src/core/patterns/kubectl.rs` | 428 |
| `rust/src/core/patterns/linkerd.rs` | 95 |
| `rust/src/core/patterns/log_dedup.rs` | 395 |
| `rust/src/core/patterns/ls.rs` | 267 |
| `rust/src/core/patterns/make.rs` | 127 |
| `rust/src/core/patterns/maven.rs` | 183 |
| `rust/src/core/patterns/mise.rs` | 97 |
| `rust/src/core/patterns/mix.rs` | 147 |
| `rust/src/core/patterns/mlflow.rs` | 127 |
| `rust/src/core/patterns/mod.rs` | 948 |
| `rust/src/core/patterns/mypy.rs` | 153 |
| `rust/src/core/patterns/mysql.rs` | 92 |
| `rust/src/core/patterns/next_build.rs` | 159 |
| `rust/src/core/patterns/ninja.rs` | 160 |
| `rust/src/core/patterns/npm.rs` | 317 |
| `rust/src/core/patterns/ollama.rs` | 146 |
| `rust/src/core/patterns/php.rs` | 524 |
| `rust/src/core/patterns/pip.rs` | 178 |
| `rust/src/core/patterns/playwright.rs` | 141 |
| `rust/src/core/patterns/pnpm.rs` | 169 |
| `rust/src/core/patterns/poetry.rs` | 353 |
| `rust/src/core/patterns/prettier.rs` | 49 |
| `rust/src/core/patterns/prisma.rs` | 124 |
| `rust/src/core/patterns/psql.rs` | 94 |
| `rust/src/core/patterns/pulumi.rs` | 152 |
| `rust/src/core/patterns/pytest.rs` | 474 |
| `rust/src/core/patterns/ruby.rs` | 195 |
| `rust/src/core/patterns/ruff.rs` | 116 |
| `rust/src/core/patterns/semgrep.rs` | 74 |
| `rust/src/core/patterns/spark.rs` | 168 |
| `rust/src/core/patterns/swift.rs` | 133 |
| `rust/src/core/patterns/swiftlint.rs` | 110 |
| `rust/src/core/patterns/syft.rs` | 77 |
| `rust/src/core/patterns/sysinfo.rs` | 229 |
| `rust/src/core/patterns/systemd.rs` | 132 |
| `rust/src/core/patterns/terraform.rs` | 238 |
| `rust/src/core/patterns/test.rs` | 558 |
| `rust/src/core/patterns/trivy.rs` | 201 |
| `rust/src/core/patterns/typescript.rs` | 50 |
| `rust/src/core/patterns/wget.rs` | 57 |
| `rust/src/core/patterns/zig.rs` | 91 |

### `rust/src/core/patterns/git/`

| File | LOC |
|---|---:|
| `rust/src/core/patterns/git/commit.rs` | 592 |
| `rust/src/core/patterns/git/diff.rs` | 103 |
| `rust/src/core/patterns/git/log.rs` | 298 |
| `rust/src/core/patterns/git/mod.rs` | 603 |
| `rust/src/core/patterns/git/parser.rs` | 25 |
| `rust/src/core/patterns/git/status.rs` | 97 |

### `rust/src/core/plugins/`

| File | LOC |
|---|---:|
| `rust/src/core/plugins/executor.rs` | 388 |
| `rust/src/core/plugins/manifest.rs` | 276 |
| `rust/src/core/plugins/mod.rs` | 261 |
| `rust/src/core/plugins/registry.rs` | 294 |
| `rust/src/core/plugins/sandbox.rs` | 269 |
| `rust/src/core/plugins/tools.rs` | 94 |

### `rust/src/core/policy/`

| File | LOC |
|---|---:|
| `rust/src/core/policy/builtin.rs` | 115 |
| `rust/src/core/policy/coverage.rs` | 376 |
| `rust/src/core/policy/floor.rs` | 384 |
| `rust/src/core/policy/mod.rs` | 797 |
| `rust/src/core/policy/runtime.rs` | 296 |

### `rust/src/core/policy/org/`

| File | LOC |
|---|---:|
| `rust/src/core/policy/org/mod.rs` | 116 |
| `rust/src/core/policy/org/model.rs` | 267 |
| `rust/src/core/policy/org/store.rs` | 135 |
| `rust/src/core/policy/org/trust.rs` | 86 |

### `rust/src/core/profiles/`

| File | LOC |
|---|---:|
| `rust/src/core/profiles/builtins.rs` | 333 |
| `rust/src/core/profiles/loading.rs` | 535 |
| `rust/src/core/profiles/mod.rs` | 20 |
| `rust/src/core/profiles/tests.rs` | 244 |
| `rust/src/core/profiles/types.rs` | 342 |

### `rust/src/core/property_graph/`

| File | LOC |
|---|---:|
| `rust/src/core/property_graph/cross_source.rs` | 133 |
| `rust/src/core/property_graph/edge.rs` | 151 |
| `rust/src/core/property_graph/file_catalog.rs` | 79 |
| `rust/src/core/property_graph/meta.rs` | 79 |
| `rust/src/core/property_graph/mod.rs` | 708 |
| `rust/src/core/property_graph/node.rs` | 400 |
| `rust/src/core/property_graph/path_id.rs` | 66 |
| `rust/src/core/property_graph/queries.rs` | 352 |
| `rust/src/core/property_graph/schema.rs` | 171 |
| `rust/src/core/property_graph/snapshot.rs` | 328 |
| `rust/src/core/property_graph/sync.rs` | 323 |

### `rust/src/core/provenance/`

| File | LOC |
|---|---:|
| `rust/src/core/provenance/mod.rs` | 23 |
| `rust/src/core/provenance/store.rs` | 291 |
| `rust/src/core/provenance/tests.rs` | 198 |
| `rust/src/core/provenance/tracker.rs` | 223 |
| `rust/src/core/provenance/types.rs` | 140 |

### `rust/src/core/providers/`

| File | LOC |
|---|---:|
| `rust/src/core/providers/cache.rs` | 501 |
| `rust/src/core/providers/config.rs` | 58 |
| `rust/src/core/providers/github.rs` | 427 |
| `rust/src/core/providers/gitlab.rs` | 298 |
| `rust/src/core/providers/hardened_http.rs` | 382 |
| `rust/src/core/providers/health.rs` | 372 |
| `rust/src/core/providers/init.rs` | 127 |
| `rust/src/core/providers/jira.rs` | 635 |
| `rust/src/core/providers/jira_oauth.rs` | 675 |
| `rust/src/core/providers/mcp_bridge.rs` | 296 |
| `rust/src/core/providers/mod.rs` | 98 |
| `rust/src/core/providers/postgres.rs` | 237 |
| `rust/src/core/providers/provider_trait.rs` | 58 |
| `rust/src/core/providers/registry.rs` | 292 |
| `rust/src/core/providers/scaffold.rs` | 83 |

### `rust/src/core/providers/config_provider/`

| File | LOC |
|---|---:|
| `rust/src/core/providers/config_provider/discovery.rs` | 438 |
| `rust/src/core/providers/config_provider/extract.rs` | 327 |
| `rust/src/core/providers/config_provider/http.rs` | 357 |
| `rust/src/core/providers/config_provider/mod.rs` | 258 |
| `rust/src/core/providers/config_provider/schema.rs` | 331 |

### `rust/src/core/quality_benchmark/`

| File | LOC |
|---|---:|
| `rust/src/core/quality_benchmark/tests.rs` | 170 |

### `rust/src/core/quality_lab/`

| File | LOC |
|---|---:|
| `rust/src/core/quality_lab/calibration.rs` | 269 |
| `rust/src/core/quality_lab/fidelity.rs` | 265 |
| `rust/src/core/quality_lab/golden_corpus.rs` | 421 |
| `rust/src/core/quality_lab/mod.rs` | 10 |
| `rust/src/core/quality_lab/orchestrator.rs` | 415 |

### `rust/src/core/repomap/`

| File | LOC |
|---|---:|
| `rust/src/core/repomap/budget.rs` | 191 |
| `rust/src/core/repomap/graph.rs` | 278 |
| `rust/src/core/repomap/mod.rs` | 13 |
| `rust/src/core/repomap/ranking.rs` | 214 |

### `rust/src/core/savings_ledger/`

| File | LOC |
|---|---:|
| `rust/src/core/savings_ledger/combined.rs` | 161 |
| `rust/src/core/savings_ledger/event.rs` | 769 |
| `rust/src/core/savings_ledger/evidence_projection.rs` | 895 |
| `rust/src/core/savings_ledger/migration_tests.rs` | 241 |
| `rust/src/core/savings_ledger/mod.rs` | 694 |
| `rust/src/core/savings_ledger/observation.rs` | 124 |
| `rust/src/core/savings_ledger/push.rs` | 135 |
| `rust/src/core/savings_ledger/roi.rs` | 251 |
| `rust/src/core/savings_ledger/signed_batch.rs` | 421 |
| `rust/src/core/savings_ledger/store.rs` | 1158 |

### `rust/src/core/scorecard/`

| File | LOC |
|---|---:|
| `rust/src/core/scorecard/dual_arm.rs` | 503 |
| `rust/src/core/scorecard/mod.rs` | 293 |
| `rust/src/core/scorecard/scenarios.rs` | 118 |

### `rust/src/core/sensitivity/`

| File | LOC |
|---|---:|
| `rust/src/core/sensitivity/classify.rs` | 249 |
| `rust/src/core/sensitivity/mod.rs` | 348 |

### `rust/src/core/session/`

| File | LOC |
|---|---:|
| `rust/src/core/session/compaction.rs` | 577 |
| `rust/src/core/session/heuristics.rs` | 96 |
| `rust/src/core/session/mod.rs` | 385 |
| `rust/src/core/session/paths.rs` | 239 |
| `rust/src/core/session/persistence.rs` | 400 |
| `rust/src/core/session/playbook.rs` | 307 |
| `rust/src/core/session/state.rs` | 725 |
| `rust/src/core/session/types.rs` | 228 |

### `rust/src/core/session_summary/`

| File | LOC |
|---|---:|
| `rust/src/core/session_summary/generate.rs` | 154 |
| `rust/src/core/session_summary/mod.rs` | 136 |
| `rust/src/core/session_summary/recall.rs` | 91 |
| `rust/src/core/session_summary/record.rs` | 72 |
| `rust/src/core/session_summary/store.rs` | 172 |

### `rust/src/core/shadow/`

| File | LOC |
|---|---:|
| `rust/src/core/shadow/baseline.rs` | 60 |
| `rust/src/core/shadow/comparison.rs` | 319 |
| `rust/src/core/shadow/mod.rs` | 46 |
| `rust/src/core/shadow/persistence.rs` | 50 |
| `rust/src/core/shadow/recommendation.rs` | 55 |
| `rust/src/core/shadow/runtime.rs` | 87 |
| `rust/src/core/shadow/runtime_tests.rs` | 73 |
| `rust/src/core/shadow/tests.rs` | 135 |

### `rust/src/core/shell_allowlist/`

| File | LOC |
|---|---:|
| `rust/src/core/shell_allowlist/case_construct.rs` | 380 |
| `rust/src/core/shell_allowlist/comment_strip_tests.rs` | 64 |
| `rust/src/core/shell_allowlist/compound.rs` | 390 |
| `rust/src/core/shell_allowlist/config.rs` | 188 |
| `rust/src/core/shell_allowlist/enforcement.rs` | 638 |
| `rust/src/core/shell_allowlist/heredoc.rs` | 276 |
| `rust/src/core/shell_allowlist/mod.rs` | 55 |
| `rust/src/core/shell_allowlist/mode.rs` | 136 |
| `rust/src/core/shell_allowlist/powershell.rs` | 514 |
| `rust/src/core/shell_allowlist/substitution.rs` | 192 |
| `rust/src/core/shell_allowlist/substitution_tests.rs` | 86 |
| `rust/src/core/shell_allowlist/tests.rs` | 1500 |
| `rust/src/core/shell_allowlist/tests_multiword.rs` | 62 |
| `rust/src/core/shell_allowlist/tests_powershell.rs` | 268 |
| `rust/src/core/shell_allowlist/tests_tokenizer.rs` | 495 |
| `rust/src/core/shell_allowlist/tokenizer.rs` | 329 |

### `rust/src/core/sidecar_transport/`

| File | LOC |
|---|---:|
| `rust/src/core/sidecar_transport/mod.rs` | 7 |
| `rust/src/core/sidecar_transport/noop.rs` | 132 |
| `rust/src/core/sidecar_transport/transport_trait.rs` | 38 |
| `rust/src/core/sidecar_transport/types.rs` | 34 |

### `rust/src/core/signatures_ts/`

| File | LOC |
|---|---:|
| `rust/src/core/signatures_ts/ast_prune.rs` | 131 |
| `rust/src/core/signatures_ts/extract.rs` | 249 |
| `rust/src/core/signatures_ts/grammar_loader.rs` | 187 |
| `rust/src/core/signatures_ts/helpers.rs` | 90 |
| `rust/src/core/signatures_ts/mod.rs` | 1075 |
| `rust/src/core/signatures_ts/queries.rs` | 386 |
| `rust/src/core/signatures_ts/query_cache.rs` | 28 |
| `rust/src/core/signatures_ts/sfc.rs` | 34 |

### `rust/src/core/signatures_ts/handlers/`

| File | LOC |
|---|---:|
| `rust/src/core/signatures_ts/handlers/elixir.rs` | 43 |
| `rust/src/core/signatures_ts/handlers/gdscript.rs` | 82 |
| `rust/src/core/signatures_ts/handlers/go_java.rs` | 112 |
| `rust/src/core/signatures_ts/handlers/kotlin_swift.rs` | 139 |
| `rust/src/core/signatures_ts/handlers/lua.rs` | 128 |
| `rust/src/core/signatures_ts/handlers/mod.rs` | 23 |
| `rust/src/core/signatures_ts/handlers/python.rs` | 50 |
| `rust/src/core/signatures_ts/handlers/ruby.rs` | 19 |
| `rust/src/core/signatures_ts/handlers/rust.rs` | 75 |
| `rust/src/core/signatures_ts/handlers/scala.rs` | 21 |
| `rust/src/core/signatures_ts/handlers/typescript.rs` | 71 |
| `rust/src/core/signatures_ts/handlers/zig.rs` | 21 |

### `rust/src/core/skillify/`

| File | LOC |
|---|---:|
| `rust/src/core/skillify/candidate.rs` | 234 |
| `rust/src/core/skillify/gate.rs` | 122 |
| `rust/src/core/skillify/mod.rs` | 145 |
| `rust/src/core/skillify/rule_file.rs` | 240 |

### `rust/src/core/stats/`

| File | LOC |
|---|---:|
| `rust/src/core/stats/io.rs` | 331 |
| `rust/src/core/stats/mod.rs` | 766 |
| `rust/src/core/stats/model.rs` | 497 |

### `rust/src/core/stats/format/`

| File | LOC |
|---|---:|
| `rust/src/core/stats/format/cep.rs` | 393 |
| `rust/src/core/stats/format/dashboard.rs` | 1020 |
| `rust/src/core/stats/format/mod.rs` | 15 |
| `rust/src/core/stats/format/util.rs` | 181 |
| `rust/src/core/stats/format/views.rs` | 222 |

### `rust/src/core/stigmergy/`

| File | LOC |
|---|---:|
| `rust/src/core/stigmergy/mod.rs` | 103 |

### `rust/src/core/task_benchmark/`

| File | LOC |
|---|---:|
| `rust/src/core/task_benchmark/config.rs` | 152 |
| `rust/src/core/task_benchmark/fixtures.rs` | 1077 |
| `rust/src/core/task_benchmark/mod.rs` | 13 |
| `rust/src/core/task_benchmark/report.rs` | 380 |
| `rust/src/core/task_benchmark/runner.rs` | 438 |

### `rust/src/core/terse/`

| File | LOC |
|---|---:|
| `rust/src/core/terse/auto_dict.rs` | 197 |
| `rust/src/core/terse/counter.rs` | 61 |
| `rust/src/core/terse/dictionaries.rs` | 429 |
| `rust/src/core/terse/engine.rs` | 345 |
| `rust/src/core/terse/mcp_compress.rs` | 190 |
| `rust/src/core/terse/mod.rs` | 128 |
| `rust/src/core/terse/pipeline.rs` | 348 |
| `rust/src/core/terse/quality.rs` | 206 |
| `rust/src/core/terse/residual.rs` | 103 |
| `rust/src/core/terse/scoring.rs` | 301 |

### `rust/src/core/triage/`

| File | LOC |
|---|---:|
| `rust/src/core/triage/accuracy_tracker.rs` | 234 |
| `rust/src/core/triage/calibration.rs` | 134 |
| `rust/src/core/triage/calibration_tests.rs` | 42 |
| `rust/src/core/triage/confidence.rs` | 30 |
| `rust/src/core/triage/distillation_tests.rs` | 110 |
| `rust/src/core/triage/fusion.rs` | 78 |
| `rust/src/core/triage/mod.rs` | 236 |
| `rust/src/core/triage/model_loader.rs` | 275 |
| `rust/src/core/triage/profile.rs` | 52 |
| `rust/src/core/triage/rules.rs` | 140 |
| `rust/src/core/triage/semantic_analyzer.rs` | 95 |
| `rust/src/core/triage/validation.rs` | 76 |
| `rust/src/core/triage/validation_tests.rs` | 51 |

### `rust/src/core/triage/distillation/`

| File | LOC |
|---|---:|
| `rust/src/core/triage/distillation/data_pipeline.rs` | 162 |
| `rust/src/core/triage/distillation/mod.rs` | 15 |
| `rust/src/core/triage/distillation/model_config.rs` | 53 |
| `rust/src/core/triage/distillation/teacher_labeling.rs` | 132 |

### `rust/src/core/trust/`

| File | LOC |
|---|---:|
| `rust/src/core/trust/classification.rs` | 308 |
| `rust/src/core/trust/evidence_chain.rs` | 333 |
| `rust/src/core/trust/identity.rs` | 181 |
| `rust/src/core/trust/mod.rs` | 26 |
| `rust/src/core/trust/policy.rs` | 215 |
| `rust/src/core/trust/tenant_isolation.rs` | 101 |

### `rust/src/core/value_gate/`

| File | LOC |
|---|---:|
| `rust/src/core/value_gate/cost_tracker.rs` | 58 |
| `rust/src/core/value_gate/cpao.rs` | 47 |
| `rust/src/core/value_gate/mod.rs` | 278 |
| `rust/src/core/value_gate/outcome_evaluator.rs` | 74 |
| `rust/src/core/value_gate/report.rs` | 116 |
| `rust/src/core/value_gate/store.rs` | 212 |

### `rust/src/core/verbosity/`

| File | LOC |
|---|---:|
| `rust/src/core/verbosity/mod.rs` | 20 |
| `rust/src/core/verbosity/recommender.rs` | 132 |
| `rust/src/core/verbosity/runtime.rs` | 168 |
| `rust/src/core/verbosity/signals.rs` | 148 |
| `rust/src/core/verbosity/transcript.rs` | 136 |

### `rust/src/core/wasserstein/`

| File | LOC |
|---|---:|
| `rust/src/core/wasserstein/allocator.rs` | 144 |
| `rust/src/core/wasserstein/mod.rs` | 10 |
| `rust/src/core/wasserstein/transport.rs` | 199 |

### `rust/src/core/web/`

| File | LOC |
|---|---:|
| `rust/src/core/web/citation.rs` | 69 |
| `rust/src/core/web/distill.rs` | 662 |
| `rust/src/core/web/feed.rs` | 504 |
| `rust/src/core/web/fetch.rs` | 262 |
| `rust/src/core/web/html_to_text.rs` | 971 |
| `rust/src/core/web/mod.rs` | 559 |
| `rust/src/core/web/pdf.rs` | 77 |
| `rust/src/core/web/rewrite.rs` | 90 |
| `rust/src/core/web/url_guard.rs` | 350 |
| `rust/src/core/web/youtube.rs` | 454 |

### `rust/src/core/workflow/`

| File | LOC |
|---|---:|
| `rust/src/core/workflow/engine.rs` | 114 |
| `rust/src/core/workflow/mod.rs` | 7 |
| `rust/src/core/workflow/store.rs` | 148 |
| `rust/src/core/workflow/types.rs` | 181 |

### `rust/src/dashboard/`

| File | LOC |
|---|---:|
| `rust/src/dashboard/base_path.rs` | 170 |
| `rust/src/dashboard/mod.rs` | 1034 |
| `rust/src/dashboard/tests.rs` | 663 |
| `rust/src/dashboard/vscode_open.rs` | 330 |

### `rust/src/dashboard/api/`

| File | LOC |
|---|---:|
| `rust/src/dashboard/api/mod.rs` | 1 |
| `rust/src/dashboard/api/value_gate.rs` | 25 |

### `rust/src/dashboard/routes/`

| File | LOC |
|---|---:|
| `rust/src/dashboard/routes/agents.rs` | 422 |
| `rust/src/dashboard/routes/doctor.rs` | 130 |
| `rust/src/dashboard/routes/health.rs` | 150 |
| `rust/src/dashboard/routes/helpers.rs` | 260 |
| `rust/src/dashboard/routes/kernel.rs` | 79 |
| `rust/src/dashboard/routes/knowledge.rs` | 511 |
| `rust/src/dashboard/routes/leaderboard.rs` | 403 |
| `rust/src/dashboard/routes/learning.rs` | 98 |
| `rust/src/dashboard/routes/memory.rs` | 559 |
| `rust/src/dashboard/routes/mod.rs` | 213 |
| `rust/src/dashboard/routes/provenance.rs` | 64 |
| `rust/src/dashboard/routes/response_cache.rs` | 127 |
| `rust/src/dashboard/routes/risk.rs` | 109 |
| `rust/src/dashboard/routes/roi.rs` | 99 |
| `rust/src/dashboard/routes/settings.rs` | 408 |
| `rust/src/dashboard/routes/signals.rs` | 120 |
| `rust/src/dashboard/routes/snapshots.rs` | 94 |
| `rust/src/dashboard/routes/solution.rs` | 151 |
| `rust/src/dashboard/routes/stats.rs` | 203 |
| `rust/src/dashboard/routes/system.rs` | 136 |
| `rust/src/dashboard/routes/telemetry.rs` | 101 |
| `rust/src/dashboard/routes/tools.rs` | 339 |
| `rust/src/dashboard/routes/usage_breakdown.rs` | 201 |

### `rust/src/dashboard/routes/context/`

| File | LOC |
|---|---:|
| `rust/src/dashboard/routes/context/aggregated.rs` | 246 |
| `rust/src/dashboard/routes/context/core.rs` | 88 |
| `rust/src/dashboard/routes/context/diagnostics.rs` | 672 |
| `rust/src/dashboard/routes/context/mod.rs` | 22 |
| `rust/src/dashboard/routes/context/overlay.rs` | 357 |

### `rust/src/dashboard/routes/graph/`

| File | LOC |
|---|---:|
| `rust/src/dashboard/routes/graph/analysis.rs` | 53 |
| `rust/src/dashboard/routes/graph/analysis_cache.rs` | 147 |
| `rust/src/dashboard/routes/graph/architecture.rs` | 310 |
| `rust/src/dashboard/routes/graph/callgraph.rs` | 169 |
| `rust/src/dashboard/routes/graph/capability_matrix.rs` | 49 |
| `rust/src/dashboard/routes/graph/deps.rs` | 378 |
| `rust/src/dashboard/routes/graph/mod.rs` | 38 |
| `rust/src/dashboard/routes/graph/tree.rs` | 139 |

### `rust/src/doctor/`

| File | LOC |
|---|---:|
| `rust/src/doctor/common.rs` | 895 |
| `rust/src/doctor/deprecations.rs` | 107 |
| `rust/src/doctor/fix.rs` | 647 |
| `rust/src/doctor/lint_context.rs` | 64 |
| `rust/src/doctor/migrate.rs` | 360 |
| `rust/src/doctor/mod.rs` | 1039 |
| `rust/src/doctor/overhead.rs` | 273 |
| `rust/src/doctor/report.rs` | 257 |
| `rust/src/doctor/workspace_scope.rs` | 366 |

### `rust/src/doctor/checks/`

| File | LOC |
|---|---:|
| `rust/src/doctor/checks/clients.rs` | 130 |
| `rust/src/doctor/checks/environment.rs` | 916 |
| `rust/src/doctor/checks/mod.rs` | 25 |
| `rust/src/doctor/checks/providers.rs` | 82 |
| `rust/src/doctor/checks/proxy.rs` | 358 |
| `rust/src/doctor/checks/security.rs` | 346 |
| `rust/src/doctor/checks/storage.rs` | 643 |
| `rust/src/doctor/checks/tests.rs` | 248 |

### `rust/src/doctor/integrations/`

| File | LOC |
|---|---:|
| `rust/src/doctor/integrations/codex.rs` | 287 |
| `rust/src/doctor/integrations/configs.rs` | 486 |
| `rust/src/doctor/integrations/editors.rs` | 334 |
| `rust/src/doctor/integrations/hooks.rs` | 365 |
| `rust/src/doctor/integrations/mod.rs` | 134 |
| `rust/src/doctor/integrations/tests.rs` | 351 |
| `rust/src/doctor/integrations/wiring.rs` | 335 |

### `rust/src/engine/`

| File | LOC |
|---|---:|
| `rust/src/engine/mod.rs` | 134 |

### `rust/src/hook_handlers/`

| File | LOC |
|---|---:|
| `rust/src/hook_handlers/codex.rs` | 428 |
| `rust/src/hook_handlers/dedup.rs` | 301 |
| `rust/src/hook_handlers/deny.rs` | 771 |
| `rust/src/hook_handlers/edit_health.rs` | 462 |
| `rust/src/hook_handlers/file_rewrite.rs` | 794 |
| `rust/src/hook_handlers/mod.rs` | 403 |
| `rust/src/hook_handlers/observe.rs` | 849 |
| `rust/src/hook_handlers/payload.rs` | 228 |
| `rust/src/hook_handlers/read_dedup.rs` | 726 |
| `rust/src/hook_handlers/redirect.rs` | 784 |
| `rust/src/hook_handlers/search_rewrite.rs` | 407 |
| `rust/src/hook_handlers/solution_capture.rs` | 515 |
| `rust/src/hook_handlers/tests.rs` | 51 |
| `rust/src/hook_handlers/tests_command_rewrites.rs` | 344 |
| `rust/src/hook_handlers/tests_file_rewrites.rs` | 360 |
| `rust/src/hook_handlers/tests_parsing_platform.rs` | 329 |
| `rust/src/hook_handlers/tests_redirects.rs` | 333 |
| `rust/src/hook_handlers/tests_rewrite_extras.rs` | 76 |
| `rust/src/hook_handlers/tests_search_rewrites.rs` | 198 |
| `rust/src/hook_handlers/vibe.rs` | 287 |

### `rust/src/hooks/`

| File | LOC |
|---|---:|
| `rust/src/hooks/mod.rs` | 1228 |
| `rust/src/hooks/support.rs` | 565 |
| `rust/src/hooks/tests.rs` | 833 |

### `rust/src/hooks/agents/`

| File | LOC |
|---|---:|
| `rust/src/hooks/agents/amp.rs` | 18 |
| `rust/src/hooks/agents/antigravity.rs` | 578 |
| `rust/src/hooks/agents/claude.rs` | 1255 |
| `rust/src/hooks/agents/cline.rs` | 118 |
| `rust/src/hooks/agents/codebuddy.rs` | 806 |
| `rust/src/hooks/agents/codex.rs` | 935 |
| `rust/src/hooks/agents/copilot.rs` | 505 |
| `rust/src/hooks/agents/crush.rs` | 96 |
| `rust/src/hooks/agents/cursor.rs` | 570 |
| `rust/src/hooks/agents/gemini.rs` | 390 |
| `rust/src/hooks/agents/grok.rs` | 114 |
| `rust/src/hooks/agents/hermes.rs` | 164 |
| `rust/src/hooks/agents/jetbrains.rs` | 122 |
| `rust/src/hooks/agents/kiro.rs` | 29 |
| `rust/src/hooks/agents/mod.rs` | 65 |
| `rust/src/hooks/agents/openclaw.rs` | 53 |
| `rust/src/hooks/agents/opencode.rs` | 640 |
| `rust/src/hooks/agents/pi.rs` | 289 |
| `rust/src/hooks/agents/qoder.rs` | 289 |
| `rust/src/hooks/agents/shared.rs` | 97 |
| `rust/src/hooks/agents/vibe.rs` | 234 |
| `rust/src/hooks/agents/windsurf.rs` | 194 |

### `rust/src/http_server/`

| File | LOC |
|---|---:|
| `rust/src/http_server/handlers.rs` | 256 |
| `rust/src/http_server/kernel_api.rs` | 177 |
| `rust/src/http_server/mod.rs` | 1493 |

### `rust/src/instructions/`

| File | LOC |
|---|---:|
| `rust/src/instructions/solution.rs` | 56 |

### `rust/src/ipc/`

| File | LOC |
|---|---:|
| `rust/src/ipc/mod.rs` | 127 |
| `rust/src/ipc/process.rs` | 623 |
| `rust/src/ipc/unix.rs` | 81 |
| `rust/src/ipc/windows.rs` | 171 |

### `rust/src/kits/`

| File | LOC |
|---|---:|
| `rust/src/kits/mod.rs` | 414 |

### `rust/src/lsp/`

| File | LOC |
|---|---:|
| `rust/src/lsp/backend.rs` | 766 |
| `rust/src/lsp/client.rs` | 459 |
| `rust/src/lsp/config.rs` | 152 |
| `rust/src/lsp/edit_apply.rs` | 358 |
| `rust/src/lsp/jetbrains_backend.rs` | 1304 |
| `rust/src/lsp/mod.rs` | 8 |
| `rust/src/lsp/port_discovery.rs` | 118 |
| `rust/src/lsp/router.rs` | 254 |

### `rust/src/lsp/format/`

| File | LOC |
|---|---:|
| `rust/src/lsp/format/mod.rs` | 254 |

### `rust/src/proxy/`

| File | LOC |
|---|---:|
| `rust/src/proxy/adaptive_policy.rs` | 54 |
| `rust/src/proxy/anthropic.rs` | 516 |
| `rust/src/proxy/anthropic_tests.rs` | 1031 |
| `rust/src/proxy/auth_tests.rs` | 544 |
| `rust/src/proxy/auto_routing.rs` | 100 |
| `rust/src/proxy/bedrock.rs` | 1026 |
| `rust/src/proxy/break_even.rs` | 166 |
| `rust/src/proxy/cache_aligner.rs` | 774 |
| `rust/src/proxy/cache_attribution.rs` | 306 |
| `rust/src/proxy/cache_breakpoint.rs` | 170 |
| `rust/src/proxy/cache_policy.rs` | 286 |
| `rust/src/proxy/cache_safety.rs` | 175 |
| `rust/src/proxy/ccr.rs` | 801 |
| `rust/src/proxy/ccr_robustness_tests.rs` | 256 |
| `rust/src/proxy/chatgpt.rs` | 298 |
| `rust/src/proxy/chatgpt_cookies.rs` | 167 |
| `rust/src/proxy/chatgpt_ws.rs` | 434 |
| `rust/src/proxy/circuit_breaker.rs` | 35 |
| `rust/src/proxy/codec.rs` | 123 |
| `rust/src/proxy/cold_prefix.rs` | 597 |
| `rust/src/proxy/compress.rs` | 721 |
| `rust/src/proxy/compress_api.rs` | 523 |
| `rust/src/proxy/compress_shared.rs` | 36 |
| `rust/src/proxy/connector.rs` | 35 |
| `rust/src/proxy/conversation.rs` | 425 |
| `rust/src/proxy/cost.rs` | 145 |
| `rust/src/proxy/counterfactual.rs` | 252 |
| `rust/src/proxy/dedup.rs` | 1057 |
| `rust/src/proxy/determinism_guard.rs` | 487 |
| `rust/src/proxy/effort.rs` | 666 |
| `rust/src/proxy/effort_routing.rs` | 650 |
| `rust/src/proxy/eligibility.rs` | 160 |
| `rust/src/proxy/gateway_identity.rs` | 283 |
| `rust/src/proxy/google.rs` | 520 |
| `rust/src/proxy/history_prune.rs` | 645 |
| `rust/src/proxy/holdout.rs` | 253 |
| `rust/src/proxy/image_compression.rs` | 548 |
| `rust/src/proxy/integration_tests.rs` | 415 |
| `rust/src/proxy/intent.rs` | 104 |
| `rust/src/proxy/introspect.rs` | 908 |
| `rust/src/proxy/latency_guard.rs` | 363 |
| `rust/src/proxy/leaderboard.rs` | 26 |
| `rust/src/proxy/lineage.rs` | 217 |
| `rust/src/proxy/live_zone.rs` | 419 |
| `rust/src/proxy/metrics.rs` | 72 |
| `rust/src/proxy/mod.rs` | 1413 |
| `rust/src/proxy/model_router.rs` | 467 |
| `rust/src/proxy/models_api.rs` | 207 |
| `rust/src/proxy/ocla_cache_bridge.rs` | 125 |
| `rust/src/proxy/openai.rs` | 396 |
| `rust/src/proxy/openai_responses.rs` | 790 |
| `rust/src/proxy/openai_responses_ws.rs` | 386 |
| `rust/src/proxy/output_savings.rs` | 306 |
| `rust/src/proxy/pii.rs` | 195 |
| `rust/src/proxy/pipeline_bench.rs` | 421 |
| `rust/src/proxy/policy_gate.rs` | 810 |
| `rust/src/proxy/pre_optimize.rs` | 337 |
| `rust/src/proxy/prefix_cache_stats.rs` | 146 |
| `rust/src/proxy/prefix_replay.rs` | 223 |
| `rust/src/proxy/prose.rs` | 284 |
| `rust/src/proxy/prose_compress.rs` | 453 |
| `rust/src/proxy/prose_patterns.rs` | 394 |
| `rust/src/proxy/prose_ranker.rs` | 123 |
| `rust/src/proxy/providers.rs` | 453 |
| `rust/src/proxy/quality_lab_api.rs` | 37 |
| `rust/src/proxy/reasoning_budget.rs` | 16 |
| `rust/src/proxy/response_optimizer.rs` | 753 |
| `rust/src/proxy/response_shaper.rs` | 561 |
| `rust/src/proxy/rollout.rs` | 29 |
| `rust/src/proxy/routing.rs` | 702 |
| `rust/src/proxy/routing_feedback.rs` | 230 |
| `rust/src/proxy/shape_xlat.rs` | 905 |
| `rust/src/proxy/shaping_hook.rs` | 127 |
| `rust/src/proxy/sse_keepalive.rs` | 110 |
| `rust/src/proxy/stats_tests.rs` | 113 |
| `rust/src/proxy/sticky_tools.rs` | 161 |
| `rust/src/proxy/tool_kind.rs` | 540 |
| `rust/src/proxy/tool_output.rs` | 224 |
| `rust/src/proxy/upstream_tests.rs` | 132 |
| `rust/src/proxy/usage.rs` | 911 |
| `rust/src/proxy/usage_accounting.rs` | 180 |
| `rust/src/proxy/usage_azure.rs` | 128 |
| `rust/src/proxy/usage_meter.rs` | 892 |
| `rust/src/proxy/usage_parity.rs` | 113 |
| `rust/src/proxy/usage_sink.rs` | 73 |
| `rust/src/proxy/value_gate_proxy.rs` | 152 |
| `rust/src/proxy/verbosity.rs` | 327 |
| `rust/src/proxy/web_app_middleware.rs` | 22 |

### `rust/src/proxy/forward/`

| File | LOC |
|---|---:|
| `rust/src/proxy/forward/enterprise_headers.rs` | 156 |
| `rust/src/proxy/forward/headers.rs` | 126 |
| `rust/src/proxy/forward/mod.rs` | 765 |
| `rust/src/proxy/forward/pipeline.rs` | 416 |
| `rust/src/proxy/forward/prepare.rs` | 437 |
| `rust/src/proxy/forward/tests.rs` | 788 |
| `rust/src/proxy/forward/trace_id.rs` | 58 |
| `rust/src/proxy/forward/transport.rs` | 231 |
| `rust/src/proxy/forward/xlat.rs` | 38 |

### `rust/src/proxy/web_app/`

| File | LOC |
|---|---:|
| `rust/src/proxy/web_app/conversation_tracker.rs` | 364 |
| `rust/src/proxy/web_app/dashboard.rs` | 96 |
| `rust/src/proxy/web_app/mod.rs` | 49 |
| `rust/src/proxy/web_app/normalize.rs` | 314 |
| `rust/src/proxy/web_app/proof_tests.rs` | 242 |

### `rust/src/proxy_setup/`

| File | LOC |
|---|---:|
| `rust/src/proxy_setup/claude.rs` | 225 |
| `rust/src/proxy_setup/codex.rs` | 429 |
| `rust/src/proxy_setup/commandcode.rs` | 231 |
| `rust/src/proxy_setup/grok.rs` | 454 |
| `rust/src/proxy_setup/mod.rs` | 237 |
| `rust/src/proxy_setup/pi.rs` | 181 |
| `rust/src/proxy_setup/shell.rs` | 136 |
| `rust/src/proxy_setup/tests.rs` | 1296 |
| `rust/src/proxy_setup/util.rs` | 72 |

### `rust/src/rules_inject/`

| File | LOC |
|---|---:|
| `rust/src/rules_inject/content.rs` | 77 |
| `rust/src/rules_inject/detect.rs` | 190 |
| `rust/src/rules_inject/mod.rs` | 400 |
| `rust/src/rules_inject/skills.rs` | 164 |
| `rust/src/rules_inject/targets.rs` | 220 |
| `rust/src/rules_inject/tests.rs` | 561 |
| `rust/src/rules_inject/write.rs` | 71 |

### `rust/src/server/`

| File | LOC |
|---|---:|
| `rust/src/server/background_shell.rs` | 513 |
| `rust/src/server/bounded_lock.rs` | 245 |
| `rust/src/server/bypass_hint.rs` | 466 |
| `rust/src/server/call_tool.rs` | 17 |
| `rust/src/server/compaction_sync.rs` | 308 |
| `rust/src/server/context_gate.rs` | 1196 |
| `rust/src/server/dynamic_tools.rs` | 655 |
| `rust/src/server/elicitation.rs` | 139 |
| `rust/src/server/execute.rs` | 743 |
| `rust/src/server/file_resource.rs` | 230 |
| `rust/src/server/helpers.rs` | 119 |
| `rust/src/server/mod.rs` | 447 |
| `rust/src/server/multi_path.rs` | 264 |
| `rust/src/server/notifications.rs` | 52 |
| `rust/src/server/permission_inheritance.rs` | 400 |
| `rust/src/server/policy_guard.rs` | 276 |
| `rust/src/server/post_dispatch.rs` | 306 |
| `rust/src/server/post_process.rs` | 359 |
| `rust/src/server/predictive_preload.rs` | 383 |
| `rust/src/server/progress.rs` | 35 |
| `rust/src/server/prompts.rs` | 166 |
| `rust/src/server/reference_store.rs` | 80 |
| `rust/src/server/registry.rs` | 305 |
| `rust/src/server/resources.rs` | 227 |
| `rust/src/server/role_guard.rs` | 173 |
| `rust/src/server/roots.rs` | 523 |
| `rust/src/server/schema_hook.rs` | 98 |
| `rust/src/server/server_handler.rs` | 710 |
| `rust/src/server/tool_trait.rs` | 440 |
| `rust/src/server/tool_visibility.rs` | 724 |
| `rust/src/server/tools_config_watch.rs` | 137 |

### `rust/src/server/call_tool/`

| File | LOC |
|---|---:|
| `rust/src/server/call_tool/guarded.rs` | 470 |
| `rust/src/server/call_tool/outcome.rs` | 64 |
| `rust/src/server/call_tool/pipeline.rs` | 1151 |
| `rust/src/server/call_tool/policy.rs` | 198 |
| `rust/src/server/call_tool/tests.rs` | 242 |

### `rust/src/server/dispatch/`

| File | LOC |
|---|---:|
| `rust/src/server/dispatch/mod.rs` | 835 |

### `rust/src/setup/`

| File | LOC |
|---|---:|
| `rust/src/setup/env_guard.rs` | 31 |
| `rust/src/setup/first_run.rs` | 55 |
| `rust/src/setup/helpers.rs` | 482 |
| `rust/src/setup/index_build.rs` | 116 |
| `rust/src/setup/interactive.rs` | 600 |
| `rust/src/setup/mcp.rs` | 727 |
| `rust/src/setup/mod.rs` | 26 |
| `rust/src/setup/onboard.rs` | 93 |
| `rust/src/setup/options.rs` | 12 |
| `rust/src/setup/paths.rs` | 9 |
| `rust/src/setup/with_options.rs` | 583 |

### `rust/src/shell/`

| File | LOC |
|---|---:|
| `rust/src/shell/agent_wrapper.rs` | 708 |
| `rust/src/shell/interactive.rs` | 46 |
| `rust/src/shell/mod.rs` | 23 |
| `rust/src/shell/output_policy.rs` | 334 |
| `rust/src/shell/pipeline.rs` | 178 |
| `rust/src/shell/platform.rs` | 1045 |
| `rust/src/shell/redact.rs` | 176 |
| `rust/src/shell/reentry.rs` | 148 |
| `rust/src/shell/tee_policy.rs` | 136 |

### `rust/src/shell/compress/`

| File | LOC |
|---|---:|
| `rust/src/shell/compress/boundaries.rs` | 344 |
| `rust/src/shell/compress/classification.rs` | 1026 |
| `rust/src/shell/compress/engine.rs` | 1197 |
| `rust/src/shell/compress/footer.rs` | 5 |
| `rust/src/shell/compress/mod.rs` | 19 |
| `rust/src/shell/compress/passthrough.rs` | 308 |
| `rust/src/shell/compress/tests.rs` | 24 |
| `rust/src/shell/compress/tests_cli_api_data.rs` | 66 |
| `rust/src/shell/compress/tests_engine.rs` | 258 |
| `rust/src/shell/compress/tests_passthrough.rs` | 369 |
| `rust/src/shell/compress/tests_structural_output.rs` | 184 |
| `rust/src/shell/compress/tests_test_runner_output.rs` | 114 |
| `rust/src/shell/compress/tests_verbatim_output.rs` | 715 |

### `rust/src/shell/exec/`

| File | LOC |
|---|---:|
| `rust/src/shell/exec/execution.rs` | 694 |
| `rust/src/shell/exec/mod.rs` | 7 |
| `rust/src/shell/exec/process.rs` | 383 |
| `rust/src/shell/exec/timeout.rs` | 499 |

### `rust/src/shell/exec/execution/`

| File | LOC |
|---|---:|
| `rust/src/shell/exec/execution/nested_lean_ctx_exec_tests.rs` | 56 |

### `rust/src/tool_defs/`

| File | LOC |
|---|---:|
| `rust/src/tool_defs/granular.rs` | 259 |
| `rust/src/tool_defs/mod.rs` | 313 |

### `rust/src/tools/`

| File | LOC |
|---|---:|
| `rust/src/tools/autonomy.rs` | 747 |
| `rust/src/tools/ctx_agent.rs` | 926 |
| `rust/src/tools/ctx_analyze.rs` | 142 |
| `rust/src/tools/ctx_architecture.rs` | 1383 |
| `rust/src/tools/ctx_artifacts.rs` | 309 |
| `rust/src/tools/ctx_benchmark.rs` | 236 |
| `rust/src/tools/ctx_callgraph.rs` | 336 |
| `rust/src/tools/ctx_compile.rs` | 83 |
| `rust/src/tools/ctx_compose.rs` | 708 |
| `rust/src/tools/ctx_compress.rs` | 211 |
| `rust/src/tools/ctx_compress_memory.rs` | 329 |
| `rust/src/tools/ctx_context.rs` | 88 |
| `rust/src/tools/ctx_control.rs` | 301 |
| `rust/src/tools/ctx_cost.rs` | 86 |
| `rust/src/tools/ctx_dedup.rs` | 240 |
| `rust/src/tools/ctx_delta.rs` | 7 |
| `rust/src/tools/ctx_discover.rs` | 536 |
| `rust/src/tools/ctx_execute.rs` | 411 |
| `rust/src/tools/ctx_expand.rs` | 523 |
| `rust/src/tools/ctx_explore.rs` | 729 |
| `rust/src/tools/ctx_feedback.rs` | 83 |
| `rust/src/tools/ctx_fill.rs` | 256 |
| `rust/src/tools/ctx_gain.rs` | 1012 |
| `rust/src/tools/ctx_glob.rs` | 340 |
| `rust/src/tools/ctx_graph.rs` | 837 |
| `rust/src/tools/ctx_graph_diagram.rs` | 267 |
| `rust/src/tools/ctx_graph_diff.rs` | 366 |
| `rust/src/tools/ctx_graph_primitives.rs` | 768 |
| `rust/src/tools/ctx_handoff.rs` | 78 |
| `rust/src/tools/ctx_heatmap.rs` | 79 |
| `rust/src/tools/ctx_impact_tests.rs` | 1030 |
| `rust/src/tools/ctx_index.rs` | 61 |
| `rust/src/tools/ctx_intent.rs` | 113 |
| `rust/src/tools/ctx_knowledge_relations.rs` | 429 |
| `rust/src/tools/ctx_metrics.rs` | 564 |
| `rust/src/tools/ctx_multi_read.rs` | 239 |
| `rust/src/tools/ctx_optimize.rs` | 744 |
| `rust/src/tools/ctx_overview.rs` | 702 |
| `rust/src/tools/ctx_pack.rs` | 822 |
| `rust/src/tools/ctx_package.rs` | 129 |
| `rust/src/tools/ctx_plan.rs` | 323 |
| `rust/src/tools/ctx_plugins.rs` | 139 |
| `rust/src/tools/ctx_prefetch.rs` | 200 |
| `rust/src/tools/ctx_preload.rs` | 555 |
| `rust/src/tools/ctx_proof.rs` | 258 |
| `rust/src/tools/ctx_provider.rs` | 694 |
| `rust/src/tools/ctx_quality.rs` | 199 |
| `rust/src/tools/ctx_repomap.rs` | 50 |
| `rust/src/tools/ctx_response.rs` | 490 |
| `rust/src/tools/ctx_review.rs` | 271 |
| `rust/src/tools/ctx_routes.rs` | 122 |
| `rust/src/tools/ctx_rules.rs` | 98 |
| `rust/src/tools/ctx_session.rs` | 1050 |
| `rust/src/tools/ctx_share.rs` | 602 |
| `rust/src/tools/ctx_shell.rs` | 1134 |
| `rust/src/tools/ctx_skillify.rs` | 77 |
| `rust/src/tools/ctx_smart_read.rs` | 88 |
| `rust/src/tools/ctx_smells.rs` | 253 |
| `rust/src/tools/ctx_summary.rs` | 76 |
| `rust/src/tools/ctx_symbol.rs` | 430 |
| `rust/src/tools/ctx_task.rs` | 245 |
| `rust/src/tools/ctx_tools.rs` | 151 |
| `rust/src/tools/ctx_transcript_compact.rs` | 505 |
| `rust/src/tools/ctx_tree.rs` | 388 |
| `rust/src/tools/ctx_verify.rs` | 81 |
| `rust/src/tools/ctx_workflow.rs` | 291 |
| `rust/src/tools/edit_io.rs` | 279 |
| `rust/src/tools/edit_recovery.rs` | 349 |
| `rust/src/tools/graph_meta.rs` | 59 |
| `rust/src/tools/knowledge_shared.rs` | 21 |
| `rust/src/tools/mod.rs` | 600 |
| `rust/src/tools/output_format.rs` | 45 |
| `rust/src/tools/search_hook.rs` | 102 |
| `rust/src/tools/search_kernel.rs` | 126 |
| `rust/src/tools/server.rs` | 112 |
| `rust/src/tools/server_lifecycle.rs` | 370 |
| `rust/src/tools/server_metrics.rs` | 947 |
| `rust/src/tools/server_paths.rs` | 191 |
| `rust/src/tools/startup.rs` | 138 |
| `rust/src/tools/walk_guard.rs` | 65 |

### `rust/src/tools/ctx_cognitive/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_cognitive/mod.rs` | 187 |

### `rust/src/tools/ctx_edit/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_edit/implementation.rs` | 758 |
| `rust/src/tools/ctx_edit/mod.rs` | 13 |
| `rust/src/tools/ctx_edit/tests.rs` | 733 |

### `rust/src/tools/ctx_impact/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_impact/analyze.rs` | 673 |
| `rust/src/tools/ctx_impact/build.rs` | 772 |
| `rust/src/tools/ctx_impact/mod.rs` | 25 |

### `rust/src/tools/ctx_knowledge/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_knowledge/consolidate.rs` | 495 |
| `rust/src/tools/ctx_knowledge/embeddings.rs` | 238 |
| `rust/src/tools/ctx_knowledge/mod.rs` | 1032 |
| `rust/src/tools/ctx_knowledge/remember.rs` | 848 |
| `rust/src/tools/ctx_knowledge/restore.rs` | 608 |
| `rust/src/tools/ctx_knowledge/search.rs` | 372 |
| `rust/src/tools/ctx_knowledge/tests.rs` | 321 |

### `rust/src/tools/ctx_multi_repo/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_multi_repo/mod.rs` | 190 |
| `rust/src/tools/ctx_multi_repo/search.rs` | 358 |

### `rust/src/tools/ctx_outline/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_outline/dir.rs` | 124 |
| `rust/src/tools/ctx_outline/json.rs` | 88 |
| `rust/src/tools/ctx_outline/mod.rs` | 144 |
| `rust/src/tools/ctx_outline/tests.rs` | 278 |

### `rust/src/tools/ctx_patch/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_patch/anchors.rs` | 448 |
| `rust/src/tools/ctx_patch/apply.rs` | 808 |
| `rust/src/tools/ctx_patch/metering.rs` | 148 |
| `rust/src/tools/ctx_patch/mod.rs` | 423 |
| `rust/src/tools/ctx_patch/output.rs` | 160 |
| `rust/src/tools/ctx_patch/symbol.rs` | 136 |
| `rust/src/tools/ctx_patch/tests.rs` | 619 |

### `rust/src/tools/ctx_read/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_read/core_logic.rs` | 683 |
| `rust/src/tools/ctx_read/dedup_hook.rs` | 72 |
| `rust/src/tools/ctx_read/dispatch.rs` | 1029 |
| `rust/src/tools/ctx_read/file_io.rs` | 205 |
| `rust/src/tools/ctx_read/helpers.rs` | 129 |
| `rust/src/tools/ctx_read/kernel.rs` | 70 |
| `rust/src/tools/ctx_read/mod.rs` | 42 |
| `rust/src/tools/ctx_read/mode.rs` | 625 |
| `rust/src/tools/ctx_read/render.rs` | 1255 |
| `rust/src/tools/ctx_read/terminal_compress.rs` | 472 |
| `rust/src/tools/ctx_read/tests.rs` | 23 |
| `rust/src/tools/ctx_read/tests_compression.rs` | 320 |
| `rust/src/tools/ctx_read/tests_delta.rs` | 674 |
| `rust/src/tools/ctx_read/tests_e26_benchmark.rs` | 354 |
| `rust/src/tools/ctx_read/tests_inflation.rs` | 252 |
| `rust/src/tools/ctx_read/tests_modes.rs` | 415 |
| `rust/src/tools/ctx_read/tests_ranges.rs` | 200 |
| `rust/src/tools/ctx_read/tests_verbatim.rs` | 273 |
| `rust/src/tools/ctx_read/tests_windowed.rs` | 144 |
| `rust/src/tools/ctx_read/types.rs` | 146 |

### `rust/src/tools/ctx_refactor/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_refactor/mod.rs` | 867 |
| `rust/src/tools/ctx_refactor/ops.rs` | 978 |
| `rust/src/tools/ctx_refactor/tests.rs` | 869 |
| `rust/src/tools/ctx_refactor/tests_ops.rs` | 1027 |

### `rust/src/tools/ctx_search/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_search/implementation.rs` | 784 |
| `rust/src/tools/ctx_search/mod.rs` | 3 |
| `rust/src/tools/ctx_search/tests.rs` | 635 |

### `rust/src/tools/ctx_semantic_search/`

| File | LOC |
|---|---:|
| `rust/src/tools/ctx_semantic_search/bm25_store.rs` | 110 |
| `rust/src/tools/ctx_semantic_search/dense.rs` | 449 |
| `rust/src/tools/ctx_semantic_search/mod.rs` | 408 |
| `rust/src/tools/ctx_semantic_search/multi_root.rs` | 634 |
| `rust/src/tools/ctx_semantic_search/scope.rs` | 180 |
| `rust/src/tools/ctx_semantic_search/tests.rs` | 306 |

### `rust/src/tools/registered/`

| File | LOC |
|---|---:|
| `rust/src/tools/registered/ctx_agent.rs` | 166 |
| `rust/src/tools/registered/ctx_analyze.rs` | 51 |
| `rust/src/tools/registered/ctx_architecture.rs` | 83 |
| `rust/src/tools/registered/ctx_artifacts.rs` | 91 |
| `rust/src/tools/registered/ctx_benchmark.rs` | 56 |
| `rust/src/tools/registered/ctx_cache.rs` | 165 |
| `rust/src/tools/registered/ctx_call.rs` | 55 |
| `rust/src/tools/registered/ctx_callgraph.rs` | 128 |
| `rust/src/tools/registered/ctx_checkpoint.rs` | 191 |
| `rust/src/tools/registered/ctx_compare.rs` | 133 |
| `rust/src/tools/registered/ctx_compile.rs` | 52 |
| `rust/src/tools/registered/ctx_compose.rs` | 791 |
| `rust/src/tools/registered/ctx_compress.rs` | 47 |
| `rust/src/tools/registered/ctx_compress_memory.rs` | 40 |
| `rust/src/tools/registered/ctx_context.rs` | 49 |
| `rust/src/tools/registered/ctx_control.rs` | 78 |
| `rust/src/tools/registered/ctx_cost.rs` | 64 |
| `rust/src/tools/registered/ctx_crush.rs` | 1418 |
| `rust/src/tools/registered/ctx_dedup.rs` | 61 |
| `rust/src/tools/registered/ctx_delta.rs` | 77 |
| `rust/src/tools/registered/ctx_discover.rs` | 42 |
| `rust/src/tools/registered/ctx_discover_tools.rs` | 39 |
| `rust/src/tools/registered/ctx_edit.rs` | 249 |
| `rust/src/tools/registered/ctx_execute.rs` | 129 |
| `rust/src/tools/registered/ctx_expand.rs` | 54 |
| `rust/src/tools/registered/ctx_explore.rs` | 81 |
| `rust/src/tools/registered/ctx_feedback.rs` | 139 |
| `rust/src/tools/registered/ctx_fill.rs` | 110 |
| `rust/src/tools/registered/ctx_gain.rs` | 67 |
| `rust/src/tools/registered/ctx_git_read.rs` | 386 |
| `rust/src/tools/registered/ctx_glob.rs` | 324 |
| `rust/src/tools/registered/ctx_graph.rs` | 131 |
| `rust/src/tools/registered/ctx_handoff.rs` | 675 |
| `rust/src/tools/registered/ctx_heatmap.rs` | 50 |
| `rust/src/tools/registered/ctx_impact.rs` | 100 |
| `rust/src/tools/registered/ctx_index.rs` | 79 |
| `rust/src/tools/registered/ctx_intent.rs` | 89 |
| `rust/src/tools/registered/ctx_knowledge.rs` | 254 |
| `rust/src/tools/registered/ctx_ledger.rs` | 234 |
| `rust/src/tools/registered/ctx_live_zone.rs` | 213 |
| `rust/src/tools/registered/ctx_load_tools.rs` | 167 |
| `rust/src/tools/registered/ctx_memory.rs` | 125 |
| `rust/src/tools/registered/ctx_metrics.rs` | 99 |
| `rust/src/tools/registered/ctx_multi_read.rs` | 352 |
| `rust/src/tools/registered/ctx_multi_repo.rs` | 126 |
| `rust/src/tools/registered/ctx_optimize.rs` | 587 |
| `rust/src/tools/registered/ctx_outline.rs` | 77 |
| `rust/src/tools/registered/ctx_overview.rs` | 87 |
| `rust/src/tools/registered/ctx_pack.rs` | 242 |
| `rust/src/tools/registered/ctx_package.rs` | 85 |
| `rust/src/tools/registered/ctx_patch.rs` | 817 |
| `rust/src/tools/registered/ctx_perf.rs` | 135 |
| `rust/src/tools/registered/ctx_plan.rs` | 58 |
| `rust/src/tools/registered/ctx_plugins.rs` | 66 |
| `rust/src/tools/registered/ctx_prefetch.rs` | 104 |
| `rust/src/tools/registered/ctx_preload.rs` | 274 |
| `rust/src/tools/registered/ctx_proof.rs` | 111 |
| `rust/src/tools/registered/ctx_provider.rs` | 58 |
| `rust/src/tools/registered/ctx_quality.rs` | 93 |
| `rust/src/tools/registered/ctx_quality_lab.rs` | 67 |
| `rust/src/tools/registered/ctx_radar.rs` | 71 |
| `rust/src/tools/registered/ctx_read.rs` | 1490 |
| `rust/src/tools/registered/ctx_read_inline_tests.rs` | 849 |
| `rust/src/tools/registered/ctx_read_repo_param_tests.rs` | 141 |
| `rust/src/tools/registered/ctx_read_window.rs` | 157 |
| `rust/src/tools/registered/ctx_refactor.rs` | 226 |
| `rust/src/tools/registered/ctx_repomap.rs` | 99 |
| `rust/src/tools/registered/ctx_response.rs` | 42 |
| `rust/src/tools/registered/ctx_retrieve.rs` | 216 |
| `rust/src/tools/registered/ctx_review.rs` | 95 |
| `rust/src/tools/registered/ctx_routes.rs` | 50 |
| `rust/src/tools/registered/ctx_rules.rs` | 50 |
| `rust/src/tools/registered/ctx_search.rs` | 1063 |
| `rust/src/tools/registered/ctx_semantic_search.rs` | 181 |
| `rust/src/tools/registered/ctx_session.rs` | 96 |
| `rust/src/tools/registered/ctx_share.rs` | 102 |
| `rust/src/tools/registered/ctx_shell.rs` | 1381 |
| `rust/src/tools/registered/ctx_skillify.rs` | 56 |
| `rust/src/tools/registered/ctx_smart_read.rs` | 88 |
| `rust/src/tools/registered/ctx_smells.rs` | 81 |
| `rust/src/tools/registered/ctx_summary.rs` | 68 |
| `rust/src/tools/registered/ctx_symbol.rs` | 63 |
| `rust/src/tools/registered/ctx_task.rs` | 102 |
| `rust/src/tools/registered/ctx_tools.rs` | 61 |
| `rust/src/tools/registered/ctx_transcript_compact.rs` | 113 |
| `rust/src/tools/registered/ctx_tree.rs` | 188 |
| `rust/src/tools/registered/ctx_url_read.rs` | 106 |
| `rust/src/tools/registered/ctx_verify.rs` | 82 |
| `rust/src/tools/registered/ctx_workflow.rs` | 91 |
| `rust/src/tools/registered/mod.rs` | 108 |
| `rust/src/tools/registered/plugin_tool.rs` | 106 |
| `rust/src/tools/registered/schema_qa_tests.rs` | 169 |
| `rust/src/tools/registered/shell_alias.rs` | 92 |

### `rust/src/tui/`

| File | LOC |
|---|---:|
| `rust/src/tui/app.rs` | 1103 |
| `rust/src/tui/event_reader.rs` | 173 |
| `rust/src/tui/mod.rs` | 4 |

### `rust/src/uninstall/`

| File | LOC |
|---|---:|
| `rust/src/uninstall/agents.rs` | 1180 |
| `rust/src/uninstall/binary.rs` | 340 |
| `rust/src/uninstall/mod.rs` | 701 |
| `rust/src/uninstall/parsers.rs` | 1228 |

### `rust/src/wrap/`

| File | LOC |
|---|---:|
| `rust/src/wrap/launch.rs` | 104 |
| `rust/src/wrap/mod.rs` | 297 |
| `rust/src/wrap/snapshot.rs` | 98 |
| `rust/src/wrap/unwrap.rs` | 115 |
| `rust/src/wrap/verify.rs` | 92 |

## 13. Complete non-engine SDK/client and crate file inventories

### `rust/crates/lean-ctx-ocla/`

| File | LOC |
|---|---:|
| `rust/crates/lean-ctx-ocla/Cargo.toml` | 24 |
| `rust/crates/lean-ctx-ocla/src/failure.rs` | 25 |
| `rust/crates/lean-ctx-ocla/src/lib.rs` | 15 |
| `rust/crates/lean-ctx-ocla/src/manifest.rs` | 210 |
| `rust/crates/lean-ctx-ocla/src/observation.rs` | 22 |
| `rust/crates/lean-ctx-ocla/src/traits.rs` | 128 |
| `rust/crates/lean-ctx-ocla/src/types.rs` | 1108 |

### `rust/crates/lean-ctx-protocol/`

| File | LOC |
|---|---:|
| `rust/crates/lean-ctx-protocol/Cargo.toml` | 13 |
| `rust/crates/lean-ctx-protocol/src/auto_routing.rs` | 258 |
| `rust/crates/lean-ctx-protocol/src/capability.rs` | 166 |
| `rust/crates/lean-ctx-protocol/src/circuit_breaker.rs` | 420 |
| `rust/crates/lean-ctx-protocol/src/common.rs` | 191 |
| `rust/crates/lean-ctx-protocol/src/control_plane.rs` | 129 |
| `rust/crates/lean-ctx-protocol/src/decision.rs` | 101 |
| `rust/crates/lean-ctx-protocol/src/eligibility.rs` | 191 |
| `rust/crates/lean-ctx-protocol/src/evidence.rs` | 44 |
| `rust/crates/lean-ctx-protocol/src/execution.rs` | 233 |
| `rust/crates/lean-ctx-protocol/src/experiment.rs` | 74 |
| `rust/crates/lean-ctx-protocol/src/fleet_control.rs` | 66 |
| `rust/crates/lean-ctx-protocol/src/gap.rs` | 88 |
| `rust/crates/lean-ctx-protocol/src/knowledge.rs` | 299 |
| `rust/crates/lean-ctx-protocol/src/knowledge_routing.rs` | 261 |
| `rust/crates/lean-ctx-protocol/src/lib.rs` | 49 |
| `rust/crates/lean-ctx-protocol/src/money.rs` | 41 |
| `rust/crates/lean-ctx-protocol/src/outcome.rs` | 120 |
| `rust/crates/lean-ctx-protocol/src/outcome_engine.rs` | 133 |
| `rust/crates/lean-ctx-protocol/src/policy.rs` | 47 |
| `rust/crates/lean-ctx-protocol/src/rollout.rs` | 191 |
| `rust/crates/lean-ctx-protocol/src/savings.rs` | 292 |
| `rust/crates/lean-ctx-protocol/src/task.rs` | 166 |
| `rust/crates/lean-ctx-protocol/src/triage.rs` | 197 |
| `rust/crates/lean-ctx-protocol/src/usage.rs` | 42 |
| `rust/crates/lean-ctx-protocol/src/value_share.rs` | 107 |

### `rust/crates/lean-ctx-sdk/`

| File | LOC |
|---|---:|
| `rust/crates/lean-ctx-sdk/Cargo.toml` | 42 |
| `rust/crates/lean-ctx-sdk/examples/embed.rs` | 45 |
| `rust/crates/lean-ctx-sdk/src/addon.rs` | 165 |
| `rust/crates/lean-ctx-sdk/src/compress.rs` | 29 |
| `rust/crates/lean-ctx-sdk/src/engine.rs` | 358 |
| `rust/crates/lean-ctx-sdk/src/error.rs` | 49 |
| `rust/crates/lean-ctx-sdk/src/hash.rs` | 26 |
| `rust/crates/lean-ctx-sdk/src/lib.rs` | 67 |
| `rust/crates/lean-ctx-sdk/src/output.rs` | 42 |
| `rust/crates/lean-ctx-sdk/src/read.rs` | 49 |
| `rust/crates/lean-ctx-sdk/src/tokens.rs` | 19 |
| `rust/crates/lean-ctx-sdk/tests/engine_read.rs` | 120 |

### `rust/crates/grammar-addons/lua/`

| File | LOC |
|---|---:|
| `rust/crates/grammar-addons/lua/Cargo.toml` | 16 |
| `rust/crates/grammar-addons/lua/src/lib.rs` | 16 |

### `clients/rust/lean-ctx-client/`

| File | LOC |
|---|---:|
| `clients/rust/lean-ctx-client/Cargo.toml` | 49 |
| `clients/rust/lean-ctx-client/src/bin/lean-ctx-ocla-verify.rs` | 121 |
| `clients/rust/lean-ctx-client/src/client.rs` | 572 |
| `clients/rust/lean-ctx-client/src/conformance.rs` | 284 |
| `clients/rust/lean-ctx-client/src/error.rs` | 92 |
| `clients/rust/lean-ctx-client/src/events.rs` | 123 |
| `clients/rust/lean-ctx-client/src/lib.rs` | 110 |
| `clients/rust/lean-ctx-client/src/ocla.rs` | 338 |
| `clients/rust/lean-ctx-client/src/tool_text.rs` | 92 |
| `clients/rust/lean-ctx-client/src/types.rs` | 169 |
| `clients/rust/lean-ctx-client/tests/conformance_live.rs` | 59 |
| `clients/rust/lean-ctx-client/tests/dependency_boundary.rs` | 147 |
| `clients/rust/lean-ctx-client/tests/external_consumer.rs` | 187 |
| `clients/rust/lean-ctx-client/tests/http.rs` | 224 |
| `clients/rust/lean-ctx-client/tests/ocla_cli.rs` | 114 |
| `clients/rust/lean-ctx-client/tests/ocla_wire.rs` | 452 |

### `clients/python/leanctx/`

| File | LOC |
|---|---:|
| `clients/python/leanctx/__init__.py` | 68 |
| `clients/python/leanctx/adapters/__init__.py` | 32 |
| `clients/python/leanctx/adapters/_common.py` | 83 |
| `clients/python/leanctx/adapters/crewai.py` | 53 |
| `clients/python/leanctx/adapters/langchain.py` | 36 |
| `clients/python/leanctx/adapters/llamaindex.py` | 36 |
| `clients/python/leanctx/adapters/openai.py` | 46 |
| `clients/python/leanctx/client.py` | 355 |
| `clients/python/leanctx/conformance.py` | 218 |
| `clients/python/leanctx/errors.py` | 47 |
| `clients/python/leanctx/ocla.py` | 528 |
| `clients/python/leanctx/ocla_verify.py` | 96 |
| `clients/python/leanctx/tool_text.py` | 31 |

### `packages/python-lean-ctx/lean_ctx/`

| File | LOC |
|---|---:|
| `packages/python-lean-ctx/lean_ctx/__init__.py` | 30 |
| `packages/python-lean-ctx/lean_ctx/client.py` | 63 |
| `packages/python-lean-ctx/lean_ctx/discovery.py` | 113 |
| `packages/python-lean-ctx/lean_ctx/errors.py` | 21 |
| `packages/python-lean-ctx/lean_ctx/langchain.py` | 92 |
| `packages/python-lean-ctx/lean_ctx/litellm.py` | 105 |
| `packages/python-lean-ctx/lean_ctx/llamaindex.py` | 47 |
| `packages/python-lean-ctx/lean_ctx/proxy.py` | 164 |

### `cookbook/sdk/src/`

| File | LOC |
|---|---:|
| `cookbook/sdk/src/client.e2e.test.ts` | 162 |
| `cookbook/sdk/src/client.test.ts` | 105 |
| `cookbook/sdk/src/client.ts` | 386 |
| `cookbook/sdk/src/conformance.e2e.test.ts` | 50 |
| `cookbook/sdk/src/conformance.test.ts` | 142 |
| `cookbook/sdk/src/conformance.ts` | 216 |
| `cookbook/sdk/src/errors.ts` | 26 |
| `cookbook/sdk/src/index.ts` | 22 |
| `cookbook/sdk/src/toolText.test.ts` | 26 |
| `cookbook/sdk/src/toolText.ts` | 44 |
| `cookbook/sdk/src/types.ts` | 57 |

### `packages/node-lean-ctx/src/`

| File | LOC |
|---|---:|
| `packages/node-lean-ctx/src/client.ts` | 87 |
| `packages/node-lean-ctx/src/discovery.ts` | 143 |
| `packages/node-lean-ctx/src/errors.ts` | 24 |
| `packages/node-lean-ctx/src/index.ts` | 12 |
| `packages/node-lean-ctx/src/proxy.ts` | 171 |
| `packages/node-lean-ctx/src/vercel-ai.ts` | 116 |

### `packages/ocla-grpc/`

| File | LOC |
|---|---:|
| `packages/ocla-grpc/Cargo.toml` | 29 |
| `packages/ocla-grpc/build.rs` | 10 |
| `packages/ocla-grpc/src/lib.rs` | 337 |
| `packages/ocla-grpc/src/main.rs` | 36 |
| `packages/ocla-grpc/tests/grpc_e2e.rs` | 217 |

### `packages/leanctx-verify/`

| File | LOC |
|---|---:|
| `packages/leanctx-verify/Cargo.toml` | 23 |
| `packages/leanctx-verify/src/main.rs` | 93 |
| `packages/leanctx-verify/src/verify.rs` | 460 |
| `packages/leanctx-verify/tests/verify_bundle.rs` | 212 |

### `examples/ocla_consumer/`

| File | LOC |
|---|---:|
| `examples/ocla_consumer/Cargo.toml` | 12 |
| `examples/ocla_consumer/src/main.rs` | 200 |

## 14. Reading guide and limits

- This map inventories source tracked in the working tree; generated benchmark results, build outputs, and vendored rmcp internals are not duplicated in the 1,900-file engine appendix beyond their crate-level row.
- Runtime capability is feature/profile/config dependent. A compiled module may be hidden by a tool profile, disabled feature, or provider configuration; the source path is still definitive for ownership.
- For call-site impact after this map, use `ctx_callgraph`; for targeted source orientation, use `ctx_compose` then the relevant file path from this appendix.
