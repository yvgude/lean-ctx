# LeanCTX competitive deep research

**Investor positioning | Research snapshot: 19 August 2026**

## One-page positioning

### Category definition

LeanCTX is the **Context SDK for AI agents**: a local-first MCP layer that improves the information an agent receives from files, search, shell output, providers, and handoffs. It measures the resulting token and outcome economics, then makes the result independently verifiable.

**Core claim:** **Only LeanCTX measures + reduces + proves context efficiency with signed evidence.**

This is a distinct category from observability, LLM gateways, prompt CMSs, eval platforms, governance systems, and coding agents. Those products usually answer one of: *What happened? Can I route it? Is the answer good? Is usage allowed?* LeanCTX answers the missing operational question: **Did this agent receive a smaller, better context, did useful work hold up, and can a third party verify the claimed saving without seeing proprietary prompts or code?**

| Layer | Incumbents | What they optimize | LeanCTX wedge |
|---|---|---|---|
| Context reduction | Headroom | Request payload compression and cache locality | Tool-aware, codebase-aware context operations plus baseline comparison and proof |
| Observability / gateway | Langfuse, Helicone | Trace, cost, latency, routing | Reduces the upstream context before it becomes spend; local per-event savings ledger |
| Prompt / eval | PromptLayer, Braintrust | Prompt versioning and output quality | Optimizes the *working set* for every agent task and ties savings to accepted outcomes |
| Governance | Portal26 | Policy, discovery, risk, enterprise ROI | Developer-native evidence of actual context efficiency; complementary audit feed |
| Agent frameworks / hosts | Agents SDK, MCP, Cursor, Windsurf, Codex | Build, connect, or run agents | Drop-in context intelligence for the agents users already chose |

### Why now

Agentic workloads amplify context waste: every tool call, file read, log, search result, and inter-agent handoff can be replayed into the model. Even when a host has retrieval, memory, caching, rules, or native compaction, it normally treats context management as an opaque feature rather than a measurable control plane. The buyer is shifting from “can the agent act?” to “can we run it reliably, economically, and accountably at scale?”

### Durable differentiation

1. **Act before inference.** LeanCTX compresses and selects context at the tool boundary—where coding agents create most redundant payload—not merely after the provider records a request.
2. **Measure useful efficiency.** It records token and cost savings, supports shadow-baseline comparison, and tracks CPAO (cost per accepted outcome), rather than claiming compression alone equals value.
3. **Prove it offline.** An append-only SHA-256 savings ledger can produce an Ed25519-signed aggregate receipt. A customer, finance team, or auditor can verify integrity and origin offline without receiving code, prompts, paths, or raw events.
4. **Ride the standard.** MCP makes LeanCTX portable across Claude Code, Codex, Cursor, Windsurf, and custom agent stacks; it complements, rather than replaces, their workflows.

### Go-to-market and buying message

Land with developers who hit context limits, noisy tool output, expensive agent sessions, or cross-agent handoff bloat. Expand into engineering leaders with a weekly savings and accepted-outcome view. Close enterprise security, finance, and procurement with privacy-preserving, signed savings artifacts. Position LeanCTX beside Langfuse/Helicone/Braintrust—not as a rip-and-replace: **“Keep your trace, gateway, and eval stack. LeanCTX makes the context they process materially more efficient and gives you evidence that it worked.”**

## Competitive profiles

### 1. Headroom Labs — closest direct competitor

**What it does.** Headroom is an open-source, local-first context-compression library, proxy, CLI wrapper, and MCP option for agent tool outputs, logs, files, RAG chunks, and recent conversation content. Its pipeline routes JSON, code, logs, and text through content-aware compressors; it also preserves provider cache prefixes and supports reversible retrieval of originals. Headroom says it works with Claude Code, Codex, Cursor, Aider, LangChain, CrewAI, MCP, and others. Its public claim is 60–95% fewer tokens for JSON and 15–20% fewer for coding agents; the commercial macOS companion app currently starts at $3.75/month annual ($5.63 monthly) for Pro, $15/$22.50 for Max x5, $30/$45 for Max x20, with team pricing by quote. The creator is Tejas Chopra; public primary materials identify the product as self-hosted Apache-2.0 software, but do **not** disclose a company financing round or institutional funding amount—report this as **undisclosed**, not $0M. [Product](https://headroomlabs.ai/) · [architecture](https://docs.headroomlabs.ai/docs/architecture) · [OSS repository](https://github.com/headroomlabs-ai/headroom) · [commercial pricing](https://extraheadroom.com/) · [trust model](https://headroomlabs.ai/trust)

**Weakness LeanCTX exploits.** Headroom is primarily an inline request compressor. Its own metrics and savings counters help an operator inspect its effect, but its core value proposition is not an independently verifiable before/after evidence chain, shadow-baselined outcome economics, codebase intelligence, or a broad context-engineering operating layer.

**Differentiation.** **Headroom compresses LLM traffic. LeanCTX engineers the full agent context supply chain—reads, search, shell, provider data, handoffs, and memory—and produces signed evidence of the net saving and quality hold. LeanCTX is better for teams that must prove, not simply assert, savings.**

### 2. Langfuse — observability plus prompt/eval suite

**What it does.** Langfuse is an open-source, self-hostable AI engineering platform for production tracing, token/cost and latency analytics, prompt versioning/deployment, datasets, experiments, LLM-as-judge and code evaluation, annotations, and APIs/exports. It records LLM and non-LLM calls such as retrieval, embeddings, and agent graphs through SDKs, OpenTelemetry, integrations, or a gateway. Cloud pricing is currently Free (50k units), Core $29/month, Pro $199/month, and Enterprise $2,499/month, with usage beyond included units. [Platform](https://langfuse.com/docs) · [pricing](https://langfuse.com/pricing)

**Weakness LeanCTX exploits.** Langfuse makes a request observable after instrumentation/ingestion; it does not principally shrink the tool payload an agent reads before the model sees it, nor issue a cryptographically signed savings receipt. Its unit economics are usage analytics, not independently auditable context-reduction proof.

**Differentiation.** **Langfuse traces what the agent spent. LeanCTX reduces what the agent must spend before inference, then supplies a tamper-evident ledger and signed batch. LeanCTX is better when savings itself is a production KPI, while Langfuse remains an excellent downstream trace destination.**

### 3. Helicone — proxy-based LLM gateway and observability

**What it does.** Helicone combines an AI gateway with observability. It provides a single OpenAI-compatible entry point to 100+ models, provider routing/fallbacks, caching, rate limits, monitoring, request/session debugging, prompt management, and cost/latency/error analysis; customers can use Helicone credits or bring their own keys. Current public plans are Hobby free, Pro $79/month, Team $799/month, and Enterprise custom, plus usage. [Platform overview](https://docs.helicone.ai/getting-started/platform-overview) · [pricing](https://www.helicone.ai/pricing)

**Weakness LeanCTX exploits.** Helicone sits on the LLM API path, so it is strongest at provider choice, reliability, request logs, and response caching. It does not understand or optimize a coding agent’s local file reads, shell output, code topology, or MCP-provider context before the request is assembled.

**Differentiation.** **Helicone routes and observes model calls. LeanCTX reduces and verifies the context inside those calls—especially local tool output that a gateway never understands semantically. LeanCTX is better for code agents and multi-tool workflows; Helicone is a complementary transport/control layer.**

### 4. Portal26 — enterprise AI governance and value realization

**What it does.** Portal26 is an AI Adoption Management / AI TRiSM platform aimed at CISOs and enterprise AI programs. It discovers shadow AI and agents, surfaces prompts/tool calls and usage, enforces security, privacy, token and MCP policies, provides forensics, and frames adoption value/ROI. Its free Claude offering includes discovery, agent graphs, tool-call visibility, token usage/cost, and conversation threads; full platform pricing is sales-led. The company announced a $9M Series A in November 2025 after a $6M seed, or $15M disclosed total. CEO Arti Raman and Chief Product & AI Officer Pakshi Rajan lead the published team. [Platform](https://portal26.ai/generative-ai-trism-platform/) · [free offering/pricing](https://portal26.ai/free-security-and-governance-for-claude/) · [team](https://portal26.ai/team/) · [funding](https://www.prnewswire.com/news-releases/portal26-boosts-momentum-with-9mm-series-a-302601733.html)

**Weakness LeanCTX exploits.** Portal26 governs consumption from the enterprise perimeter and translates usage into risk/ROI; it does not operate as a developer’s context-selection and compression engine for local code, search, or shell work. Token control is policy enforcement, not a per-event, reproducible measurement of context efficiency.

**Differentiation.** **Portal26 governs who may use AI and under what policy. LeanCTX optimizes the work context that authorized agents consume and emits privacy-preserving proof an enterprise system can ingest. LeanCTX is better at developer-level efficiency; Portal26 is a natural governance channel for LeanCTX evidence.**

### 5. PromptLayer — prompt registry and AI-engineering collaboration

**What it does.** PromptLayer is a prompt CMS/registry coupled with agent tracing, evaluations, datasets, regression backtests, human/AI graders, workflow versioning, and production cost/latency analytics. Its center of gravity is enabling domain experts and engineering teams to edit, test, release, roll back, and monitor prompts and agent workflows without an application redeploy. Current prices are Free, Pro $49/month, Team $500/month, and Enterprise custom; PromptLayer announced a $4.8M funding round in 2024. [Product](https://www.promptlayer.com/) · [pricing](https://www.promptlayer.com/pricing/) · [funding](https://blog.promptlayer.com/promptlayer-announces-our-4-8m-fundraise/)

**Weakness LeanCTX exploits.** PromptLayer optimizes authored instructions and evaluates resulting behavior. It does not address the dynamic tool-output, terminal, file, search, and provider-data payload that can overwhelm an otherwise well-versioned prompt while an agent works.

**Differentiation.** **PromptLayer versions what you tell the model. LeanCTX optimizes what the model discovers while doing the job, then proves the economics of doing so. LeanCTX is better for keeping live agent context lean; PromptLayer is complementary for prompt-release discipline.**

### 6. Braintrust — evaluation and observability platform

**What it does.** Braintrust provides datasets, experiments, scorers, production tracing, online evaluation, prompt/playground workflows, and CI/CD evaluation gates. Its immutable experiment snapshots let teams compare models, prompts, and code versions, while production logs seed test data. Pricing is Free for Starter, Pro $249/month with included credits/data/scores, and Enterprise custom. Braintrust announced a $36M Series A in 2024, bringing total disclosed funding then to $45M. [Evals](https://www.braintrust.dev/docs/evaluate) · [pricing](https://www.braintrust.dev/pricing) · [funding](https://www.braintrust.dev/blog/announcing-series-a)

**Weakness LeanCTX exploits.** Braintrust evaluates whether an agent’s output is good; it does not directly prevent repeated, irrelevant context from being sent to the agent, nor provide a cryptographically attributable proof of token savings. An eval can reveal quality held, but it is not a savings ledger.

**Differentiation.** **Braintrust proves output quality across experiments. LeanCTX proves context efficiency in live agent work—then can feed outcome and baseline signals into an eval stack. LeanCTX is better when the concern is the cost and information density of the trajectory, not solely final-answer quality.**

### 7. OpenAI Agents SDK — framework/runtime

**What it does.** OpenAI’s Agents SDK is a lightweight runtime for building agentic applications with agents, tools, guardrails, sessions, handoffs/agents-as-tools, MCP server integration, and tracing. It manages turns and tool execution; its traces capture generations, tools, handoffs, guardrails, and custom events. [Official SDK overview](https://openai.github.io/openai-agents-python/) · [tracing](https://openai.github.io/openai-agents-python/tracing/)

**Weakness LeanCTX exploits.** A framework orchestrates the agent loop but is not a portable context-efficiency operating layer across hosts, providers, local developer environments, and non-OpenAI stacks. Its tracing describes execution; it does not certify that local tool context was reduced against a comparable baseline.

**Differentiation.** **The Agents SDK builds and runs agents. LeanCTX makes those agents context-efficient, provider-neutral, and auditable through MCP or HTTP. LeanCTX is better as the cross-runtime control plane; the SDK is an integration surface, not a replacement.**

### 8. Anthropic / Model Context Protocol — open interoperability standard

**What it does.** MCP is the open client-host-server protocol introduced by Anthropic to connect AI applications to external tools, resources, prompts, and data. Servers expose focused capabilities; hosts retain orchestration and security boundaries. Anthropic products and APIs support MCP, and the protocol is now governed through the Linux Foundation’s Agentic AI Foundation. [Anthropic overview](https://docs.anthropic.com/en/docs/mcp) · [protocol architecture](https://modelcontextprotocol.io/specification/2025-06-18/architecture) · [governance update](https://www.anthropic.com/news/donating-the-model-context-protocol-and-establishing-of-the-agentic-ai-foundation)

**Weakness LeanCTX exploits.** MCP standardizes *how* tools and context connect; it deliberately does not dictate which context to select, compress, cache, measure, or prove. Every host can connect to many MCP servers, multiplying the risk of noisy context without an efficiency layer.

**Differentiation.** **MCP is the USB-C port for agent context. LeanCTX is the intelligent, metered device attached to that port: an MCP server that returns relevant, compressed, provenance-aware context and records signed savings evidence. LeanCTX wins by adopting the standard rather than competing with it.**

### 9. Cursor — AI coding-agent host

**What it does.** Cursor combines a coding agent with codebase search/indexing, terminal/file-edit tools, model-specific orchestration, project/user/team rules, AGENTS.md support, memories, MCP integrations, and manual “surgical context” attachments. Its docs explicitly advise precise context selection because both too little and too much context impair results; semantic indexing is a core performance investment. [Agent overview](https://prod.cursor.com/docs/agent/overview) · [working with context](https://docs.cursor.com/en/guides/working-with-context) · [rules](https://prod.cursor.com/docs/rules)

**Weakness LeanCTX exploits.** Cursor is responsible for the whole UX and has native retrieval heuristics, but those heuristics are host-specific and do not make context costs, compression effects, or savings claims independently auditable across terminal outputs, MCP providers, and other agents.

**Differentiation.** **Cursor gathers and packages context for Cursor. LeanCTX makes context operations explicit, efficient, and provable across Cursor and the rest of the stack. LeanCTX is better for teams that want durable context controls and evidence instead of accepting an editor-specific black box.**

### 10. Windsurf / Cascade — AI coding-agent host

**What it does.** Windsurf’s Cascade uses RAG-backed codebase awareness, context pinning, auto-generated workspace-local Memories, rules, AGENTS.md, workflows, skills, and MCP. Its rules expose useful activation modes—always-on, glob, model-decision, and manual—so a team can decide how much persistent context enters the prompt. Memories are local to a workspace; its own documentation advises committing durable knowledge as Rules or AGENTS.md rather than relying on automatically generated Memories. [Memories and rules](https://docs.windsurf.com/es/windsurf/cascade/memories) · [context awareness](https://docs.windsurf.com/pt-BR/context-awareness/overview)

**Weakness LeanCTX exploits.** Windsurf’s memory/retrieval settings help its own host decide what to include, but they do not reduce and account for all external tool output or quantify a cross-agent before/after efficiency baseline with portable proof.

**Differentiation.** **Windsurf manages Cascade’s remembered context. LeanCTX optimizes the broader context stream Cascade reads and produces a verifiable record of the gain. LeanCTX is better for organizations that need to govern efficiency across editors, CLI agents, and provider data—not only within one workspace.**

### 11. Codex — AI coding-agent host

**What it does.** Codex uses layered `AGENTS.md` project instructions, tools, skills, local/cloud execution, worktrees, and MCP. Official documentation says Codex builds a per-run instruction chain from global and nested project guidance (32 KiB default cap), while its shared MCP configuration lets the desktop app, CLI, and IDE extension connect to local STDIO or remote HTTP servers. [AGENTS.md guidance](https://learn.chatgpt.com/docs/agent-configuration/agents-md) · [official MCP integration](https://learn.chatgpt.com/docs/extend/mcp)

**Weakness LeanCTX exploits.** Codex offers powerful native context discovery, instruction layering, compaction, and tool use, but it needs a systematic way to make reads/search/shell/provider results compact and precise across large codebases—and to attribute savings in a vendor-neutral, cryptographically verifiable artifact.

**Differentiation.** **Codex is the agent that performs software work. LeanCTX is the context SDK beneath it: it supplies compact context through MCP, retains provenance and session knowledge, measures the delta, and signs the evidence. LeanCTX is better for making Codex work longer and cheaper with proof the engineering leader can verify.**

## Evidence behind the LeanCTX claim

LeanCTX’s documented savings model is specifically designed to support the positioning above:

- **Measurement:** local per-event accounting records original/compressed tokens, cost signals, and cache/savings state; `savings`, `gain`, and Shadow Mode expose savings, baseline comparisons, quality-hold reporting, and CPAO.
- **Reduction:** the context layer optimizes files, searches, shell output, provider results, and agent handoffs with task-aware read/search modes and context packages; it works as an MCP and Streamable HTTP service.
- **Proof:** each savings event appends to a SHA-256 hash chain. `lean-ctx savings sign` produces an aggregate, Ed25519-signed receipt; `verify-batch` validates it offline. Raw events, code, file paths, prompts, and per-event timestamps are not serialized in the signed artifact.

Internal product references: [README](../../Users/yvesgugger/Documents/Privat/Projects/lean-ctx/README.md) · [signed savings ledger](../../Users/yvesgugger/Documents/Privat/Projects/lean-ctx/docs/reference/16-signed-savings-ledger.md)

## Positioning guardrails

- Do **not** claim LeanCTX replaces observability, evals, governance, or agent hosts. The stronger claim is that it occupies the missing, pre-inference context-efficiency layer and improves each adjacent tool’s economics.
- Treat vendor performance numbers as vendor claims; use LeanCTX Shadow Mode and signed receipts for customer-specific proof.
- For Headroom, state funding as **not publicly disclosed in reviewed primary materials**. Absence of a disclosed round is not evidence of no funding.
- “Only” is defensible in the combined sense: among the reviewed landscape, LeanCTX uniquely combines runtime reduction, local measurement/baselines, and offline-verifiable signed savings evidence. Maintain a current competitive evidence log before using an absolute claim in regulated marketing.
