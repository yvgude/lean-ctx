# A11 — Agent Bus, A2A, and orchestration assessment

## Executive conclusion

**Yes — the right product boundary is “lean-ctx is the local Agent Runtime and
open protocol; Thinkery is the Enterprise Agent Control Plane.”**  The repo has
valuable primitives for that story: agent identities, a local collaboration
registry, task/message state, handoff capsules, leases/claims, signed transfer
bundles, OCLA contracts, policy-aware scheduling, and durable local session
state.

It is **not yet an enterprise control plane implementation**.  The current
system is a capable single-host/local-runtime foundation with several parallel
agent registries.  It lacks a unified identity, centrally durable coordination,
first-class directives, tenant policy enforcement, and a working end-to-end
remote A2A route.  Those gaps are exactly where Thinkery can create durable,
paid value without closing the local runtime or wire contracts.

This is a code-inspection assessment; unit tests visible next to the components
were not run as part of this report.

## Architecture as implemented

```text
CLI `lean-ctx agent` ──> core/agent_registry       identity / attestation
MCP `ctx_agent`      ──> core/agents               local presence + scratchpad
MCP `ctx_task`       ──> core/a2a/task             local durable task store
                              │
                              ├── OCLA AgentGateway ──> local scratchpad
                              │                         or RemoteTransport
                              └── OCLA capsule store     fork / delta / rollback

SessionState + Context Kits are local configuration/state.  They are not
attached to AgentEnvelope or distributed through the agent bus.
```

The important distinction is that `ocla_bus` is a bounded, in-memory
observability event bus; it is not the durable collaboration bus.  Collaboration
is instead the file-backed `core/agents::AgentRegistry` plus the task store.

## Feature-by-feature findings

| Feature | Status | Code locations | Finding and Thinkery boundary |
|---|---|---|---|
| Identity-agent CLI | **Partial, functional local identity lifecycle** | `rust/src/cli/agent_cmd.rs`, `rust/src/core/agent_registry.rs` | The requested `rust/src/cli/dispatch/agent.rs` no longer exists; implementation moved to `cli/agent_cmd.rs`. It supports `register`, `list`, `gc`, `show`, `heartbeat`, `suspend`, `resume`, `decommission`, `offboard-owner`, and `check`. Registration records public key, owner, role, PID, attestation hashes, status and heartbeats; transitions audit. There is **no `agent send` command**. OSS: local identity and inspectable lifecycle. Thinkery: organization identity, SSO/SCIM, trust-domain enrollment, key rotation, policy admission and authoritative audit retention. |
| Local Agent Bus | **Partial, strong local prototype** | `rust/src/tools/ctx_agent.rs`, `rust/src/core/agents/{types,registry,persistence,bridge,reaper,shared}.rs` | `ctx_agent` provides registration, scoped lists, post/read scratchpad messages, presence/status, handoff, diary, shared facts, event polling, and local lease actions. `AgentRegistry::mutate_locked` persists a shared registry under a file lock; messages have privacy/priority/TTL and agent status has PID/last-active metadata. It is host/project-oriented, not tenant/fleet oriented. OSS: local collaboration and inspectable file format. Thinkery: durable multi-region message service, tenant namespaces, ACLs, delivery receipts/replay, quotas, audit and operations. |
| A2A task protocol | **Partial; local task state is real, network interoperability is incomplete** | `rust/src/core/a2a/{task,a2a_compat,agent_card,message,transfer}.rs`, `rust/src/tools/ctx_task.rs`, `rust/src/http_server/mod.rs` | `TaskStore` persists tasks and transitions; `ctx_task` offers create/update/list/get/cancel/message. `a2a_compat` implements JSON-RPC-style `tasks/send`, `tasks/get`, and `tasks/cancel`; agent-card generation also exists. However `a2a_jsonrpc` and `v1_a2a_agent_card` are defined in `http_server/mod.rs` but have no other source references, so the compatibility handlers are not mounted in the server router. OSS: task/agent-card schemas and local reference implementation. Thinkery: interoperable hosted A2A gateway, partner federation, authentication, conformance, streaming, and operational SLA. |
| A2A transport and handoff | **Partial, with a blocking route mismatch** | `rust/src/core/a2a_transport.rs`, `rust/src/core/a2a/remote_transport.rs`, `rust/src/core/ocla/builtin/agent_gateway.rs`, `rust/src/http_server/handlers.rs`, `rust/src/cli/pack_cmd/transfer.rs` | Signed/HMAC transport envelopes, bounded payloads, retries, a DLQ, signed handoff bundles and local/remote gateway routing exist. The remote transport posts to `.../a2a/deliver`, while the server mounts inbound handoff at `/v1/a2a/handoff`; repository search finds no `/a2a/deliver` route. The CLI pack-transfer client uses the mounted `/v1/a2a/handoff` path. Thus remote relay is not end-to-end against this server as written. OSS: envelope/bundle formats, local handler and client. Thinkery: managed relay, regional routing, reliable queues/DLQ workflow, delivery proofs and external federation. |
| Agent directives | **Absent as a first-class subsystem** | No agent-directive type, command, route, persistence model, acknowledgement or policy evaluator found. Closest substitutes: `ctx_agent` scratchpad `post/read`, `ctx_task`, and role/config policy. | Do not describe current messages as directives. A Thinkery directive needs issuer identity, tenant scope, target selector, priority, expiry, policy version, required acknowledgement, execution evidence, cancellation and immutable audit. Keep an open directive schema/client in OSS; monetize hosted issuance, enforcement and audit. |
| OCLA implementation | **Partial but substantial local extensibility plane** | `rust/crates/lean-ctx-ocla/src/{traits,types}.rs`, `rust/src/core/ocla/{registry,runtime,wire_api,capsule,health,reference_scheduler}.rs`, `rust/src/core/ocla_bus.rs` | OCLA defines 15 capability traits including `AgentGateway`, typed request lineage, canonical token envelopes, deterministic `AgentEnvelope` relay IDs and capsules with fork/delta/snapshot/rollback. The global registry has built-ins; REST is loopback-only and exposes health, capabilities, budgets, envelopes, agents, metrics, DLQ, delivery cache and capsules. `ocla_bus` is bounded in-memory telemetry with overflow policy and no durable subscription. The gRPC bridge binds/accepts a loopback listener but is not a generated/served gRPC API. OSS: traits, schemas, local built-ins and loopback runtime. Thinkery: hosted registry/runner, durable events, policy enforcement, multi-tenant ledger, managed capability catalogue and data residency. |
| Orchestration crates | **Scaffold/reference contracts, not a deployed orchestration product** | `rust/crates/lean-ctx-protocol`, `rust/crates/lean-ctx-ocla`, `rust/crates/lean-ctx-sdk` | There is no separate orchestration crate. `lean-ctx-protocol` provides task, execution-plan, capability, control-plane and fleet-control contracts. `LocalControlPlane` is deterministic and `LocalFleetControl` always authorizes; searches find no runtime consumers beyond their definitions. `ReferenceScheduler` is more complete (candidate generation, policy filtering, deterministic fallback/selection) but also has no caller outside its module/tests. OSS: Apache-licensed protocol types and deterministic reference scheduler. Thinkery: real scheduler, capacity market, organization budgets, policy hierarchy, routing experiments and fleet optimization. |
| Context Kits | **Complete for local loading; not distributable** | `rust/src/kits/mod.rs`, `rust/src/cli/kit_cmd.rs`, `rust/src/core/auto_mode_resolver.rs` | Strict TOML kits define read rules/modes, priority, shell, quality criteria and prompt template; project paths take precedence over user kits and the selected kit is written to global config. The only runtime use found is `active_mode_for_path` in auto-mode resolution. No kit reference/hash occurs in `AgentEnvelope`, task state, handoff transfer or registry records. OSS: kit schema, validation, local loading and an open signed-package format. Thinkery: signed kit registry, approval workflow, version pinning/rollback, policy distribution, targeting and evidence of agent adoption. |
| Session persistence | **Mature local persistence and portable handoff** | `rust/src/core/session/{types,persistence,paths}.rs`, `rust/src/tools/ctx_session.rs`, `rust/src/core/ccp_session_bundle.rs`, `rust/src/core/context_os/shared_sessions.rs` | `SessionState` persists task/findings/decisions/files/tests/progress/evidence/intents/playbook and compression settings. Saves use temp-file replacement and a latest pointer; compaction snapshots, list/delete/cleanup and project-root safety checks exist. CCP bundles export/import a redacted or admin-gated full session and mark stale files. Shared sessions key memory by project/workspace/channel and write best-effort local files. OSS: local session store/bundles and redaction semantics. Thinkery: encrypted shared memory, tenant retention/legal hold, conflict control, cross-device sync and auditable state sharing. |
| Duplicate-work prevention | **Partial, best-effort; not safe across a fleet** | `rust/src/core/scent_field.rs`, `rust/src/core/agent_lease.rs`, `rust/src/tools/ctx_agent.rs`, `rust/src/core/subagent_contract.rs` | Scent claims create decaying file/symbol claims; `ctx_agent claim` rejects a live foreign claim and claims decay in about ten minutes. Local leases have schema validation and idempotency, but `agent_lease` uses a process-global `OnceLock<Mutex<...>>`, so it is not cross-process durable coordination. Briefing packs are deterministic and budgeted, but do not reserve work. OSS: transparent local claims, leases and briefing pack. Thinkery: tenant-scoped durable lease service with fencing tokens, transactional task assignment, expiry/recovery, ownership dashboard and conflict arbitration. |
| Agent health and heartbeat | **Partial/manual; background wiring is incomplete** | `rust/src/core/agent_registry.rs`, `rust/src/core/agents/{registry,reaper}.rs`, `rust/src/cli/agent_cmd.rs`, `rust/src/http_server/mod.rs`, `rust/src/core/ocla/health.rs` | Identity heartbeat is invoked by `lean-ctx agent heartbeat`; it refreshes attestation and reports binary/config drift. The collaboration registry has persistent heartbeat and logical-session methods, and the HTTP endpoint updates collaboration presence. But source search finds `spawn_reaper` only in its definition/tests and `heartbeat_persistent` only in its definition; neither is wired into normal runtime. Likewise `check_a2a_bus` exists in OCLA health but has no caller. Health is therefore component-local, not an authoritative fleet liveness system. OSS: local diagnostics/attestation drift. Thinkery: signed liveness, adaptive timeouts, SLOs, capability readiness, incident actions and fleet-wide health history. |

## Important implementation seams

1. **Two registries need one identity bridge.** `core/agent_registry` is the
   CLI identity/attestation registry; `core/agents::AgentRegistry` is the
   collaboration/presence registry. `core/agents/bridge.rs` only unifies them
   for listing. The same agent can be represented differently, with separate
   lifecycle and heartbeat semantics.

2. **The current “bus” is not a single bus.** Scratchpad messages and task
   state are durable local coordination; OCLA events are ephemeral local
   observability; identity lifecycle is another persisted record. Thinkery
   should explicitly make these one logical control-plane event model while
   retaining local fallbacks.

3. **A2A must be hardened before it is a product promise.** Mount the
   JSON-RPC/card endpoints or remove the dead compatibility surface; resolve
   `/a2a/deliver` vs `/v1/a2a/handoff`; authenticate sender identity; emit and
   persist delivery receipts; make the DLQ operationally replayable.

4. **Current health claims overstate readiness.** Presence reaping and A2A
   health checks are implemented but not invoked by normal runtime paths.
   The cloud telemetry heartbeat in `cloud_sync.rs` is installation telemetry,
   not agent liveness.

## Recommended OSS / Thinkery split

Keep these open in lean-ctx to maximize adoption and interoperability:

- Agent/task/envelope/capsule/kit/session schemas and reference implementations.
- Local single-user agent bus, file-backed persistence, claims and diagnostics.
- OCLA traits, capability manifests, policy interfaces and reference scheduler.
- Import/export, local redaction, signed handoff bundles and conformance tests.

Make these Thinkery-only (or Thinkery-hosted), because they require operations,
trust and organization data rather than just code:

- Tenant/organization control plane, SSO/SCIM, key lifecycle and trusted agent
  admission.
- Central directive and policy service with acknowledgement, enforcement and
  immutable audit.
- Durable fleet message/task/lease system, delivery guarantees, replay and
  multi-region failover.
- Central context-kit registry, signatures, approvals, targeting, version
  pinning and evidence of policy adoption.
- Organization budget allocation, scheduling, model/provider governance,
  compliance/data residency, cost attribution, observability and chargeback.
- Fleet health/SLOs, incident remediation and governance dashboards.

The monetization is not “a closed message format.” It is operating the
authoritative coordination, trust, policy, evidence and optimization layers
that an enterprise cannot safely reconstruct from local JSON files.

## Product path to a credible Enterprise Agent Control Plane

1. Define `AgentIdentityV2` as the shared key for CLI, MCP, task, lease,
   session and OCLA envelopes; retain adapters for existing files.
2. Ship `DirectiveV1` in the open protocol with signed issuer/target/expiry/
   acknowledgement/evidence fields; implement a local no-op or file-backed
   reference server and host the authoritative version in Thinkery.
3. Repair and test the A2A route contract end-to-end, then publish conformance
   fixtures for agent cards, tasks, handoffs and delivery receipts.
4. Replace process-local lease authority with a pluggable lease provider;
   Thinkery supplies durable, fenced, tenant-scoped leases.
5. Add a signed, content-addressed Context Kit reference to task/handoff/
   session context, then layer Thinkery approval/distribution on top.
6. Wire reaping and A2A health into runtime; export a stable local health
   contract that Thinkery aggregates into fleet SLOs.

## Positioning sentence

**lean-ctx gives every agent a portable local context runtime; Thinkery gives
the enterprise one trusted control plane to govern, coordinate, prove and
optimize all of those agents.**
