# A12 — Enterprise / Cloud Feature Audit

**Repository audited:** `lean-ctx` worktree, 2026-08-19.  
**Status legend:** **Working-local** = executable in this checkout; **Foundation** =
typed/enforced building block but not an end-to-end service; **Contract/docs** =
specified or advertised but no corresponding implementation here; **Absent** = no
implementation found.

## Executive assessment

LeanCTX has credible local security and governance primitives: role enforcement,
policy enforcement, tamper-evident audit records, signed evidence, compliance
report generation, a local web dashboard, and a personal-cloud client. The
enterprise product itself is not yet demonstrably deployable from this repository:
the team command is explicitly an OSS stub; fleet and control-plane implementations
are local contracts; SSO/SCIM are plan flags and documentation; and the cloud/gateway
server sources referenced by docs/inventory are not checked in.

For a 50-developer pilot, prioritize a customer-hosted gateway plus central identity,
usage, audit retention, and tenant boundaries before promising SSO, centralized
dashboard, fleet controls, or hosted proxy service.

## Feature matrix

| Feature | Status | Evidence / location | Production-ready gap | Pilot priority |
|---|---|---|---|---|
| Enterprise gateway integration | **Foundation** | `rust/src/cli/enterprise.rs`; `rust/src/core/config/enterprise.rs`; `rust/src/proxy/forward/enterprise_headers.rs`; wired by `rust/src/proxy/forward/mod.rs:607` | Client config, connection health check, bearer token, instance ID and usage metadata headers exist. No gateway server/deployment/authz implementation in worktree. | **P0** |
| Multi-tenancy | **Foundation** | `rust/src/core/trust/{identity.rs,tenant_isolation.rs,evidence_chain.rs,classification.rs}`; protocol schemas in `clients/rust/lean-ctx-client/contracts/` | Strong checks exist for evidence-chain tenant consistency; no demonstrated request-to-storage tenant enforcement, tenant auth binding, RLS/database model, or cross-service test suite. | **P0** |
| Cloud account auth | **Working client / external dependency** | `rust/src/cloud_client.rs` | Email/password register/login, password reset, API-key storage, OAuth client registration and bearer-token calls are implemented client-side. Cloud API implementation and operational controls are absent here. | **P0** |
| SSO / SCIM | **Contract/docs + entitlement only** | `docs/guides/org-sso-setup.md`; `rust/src/core/billing/plans.rs`; `rust/src/cli/dispatch/analytics/billing.rs` | Guide describes OIDC callback/JWKS validation and advertises Enterprise SAML+SCIM. Source search found no SAML, SCIM, or OIDC handler in `rust/src`; plan flags do not enforce SSO. | **P0** |
| Team management / RBAC | **Working-local RBAC; team service absent** | RBAC: `rust/src/core/roles.rs`, `rust/src/server/role_guard.rs`, `rust/src/server/policy_guard.rs`; team: `rust/src/cli/dispatch/network/team.rs`; contract: `docs/contracts/team-invite-links-v1.md` | Local roles and capability/tool gates work and denials are audited. `lean-ctx team` explicitly exits with “requires Enterprise edition”; invite/team APIs are documented, not present. Need org/member persistence, admin lifecycle, invitations, SCIM, server-side authorization. | **P0** |
| Audit logging / evidence | **Working-local** | `rust/src/core/audit_trail.rs`; call sites in `rust/src/server/{policy_guard.rs,role_guard.rs,dispatch/mod.rs}`, `rust/src/core/agent_registry.rs`; signed tenant evidence in `rust/src/core/trust/evidence_chain.rs` | Append-only JSONL with SHA-256 chain and chain verification; evidence chain adds Ed25519 signatures and rejects cross-tenant entries. Need central collection, immutable/WORM storage, retention/deletion controls, access/search, key custody, alerting and disaster recovery. | **P0** |
| EU AI Act / compliance | **Working report tooling; limited scoped readiness** | `rust/src/core/compliance.rs`; `rust/src/core/compliance_report/`; `rust/src/cli/compliance_cmd.rs`; `rust/data/compliance/mappings/eu-ai-act.toml`; `rust/tests/compliance_frameworks.rs` | Mapping is deliberately scoped to deployer context-flow duties; generated reports can be signed and verified offline. It explicitly excludes provider obligations (e.g. conformity assessment, CE marking, registration), leaves legal sign-off open, and at least the six-month retention control is tested as not enforced. | **P1** (P0 only if regulated pilot) |
| Web dashboard | **Working-local** | `rust/src/dashboard/mod.rs`, `rust/src/dashboard/routes/`, `rust/src/dashboard/static/`; CLI dispatch | A real HTTP dashboard defaults to loopback, supports token auth when exposed, CSP/host/CSRF checks, and Cockpit views. It is not a multi-user hosted admin console. Central usage route is feature-gated and relies on an external admin API. | **P1** |
| Usage tracking / billing | **Foundation** | `rust/src/core/billing/{plans.rs,metering.rs,settlement_evidence/}`; `rust/src/cli/dispatch/analytics/billing.rs`; `rust/src/cloud_client.rs` | Plans/entitlements, checkout API client, local ROI metering, signed settlement-evidence verification exist. Metering labels itself **“OSS — metering stub”**; no payment, invoice, webhook, seat or server-side reconciliation implementation is present. | **P1** |
| Fleet management (50 developers) | **Contract only** | `rust/crates/lean-ctx-protocol/src/fleet_control.rs` | `AgentPolicy` and `FleetState` schema exist, but only `LocalFleetControl`, whose authorization always returns true. No enrollment, policy distribution, inventory, enforcement, aggregation, orchestration, or admin UI. | **P0** for 50-dev pilot |
| Hosted cloud proxy | **Partial client integration; server absent** | `rust/src/cloud_client.rs`; `rust/src/cloud_sync.rs`; local proxy header bridge above | Client calls cloud endpoints for auth, sync, telemetry, checkout, models and index upload. No cloud proxy/API source, IaC, deployment or SLO evidence is in this worktree. The local proxy can forward to a configured enterprise gateway but does not make it hosted. | **P0** |
| `lean-ctx-cloud` references | **External/missing source reference** | `docs/contracts/runtime-reality-inventory-v1.json` references `cloud-infra/Dockerfile.cloud-api` and `lean-ctx-cloud`; personal-cloud contract and client above | `cloud-infra/` and the referenced cloud binary/server source are not present in tracked source here. Treat claims as external dependency until source, build, deployment, security review and tests are supplied. | **P0** |
| Control Plane | **Protocol contract + local demo** | `rust/crates/lean-ctx-protocol/src/control_plane.rs`; `docs/adrs/ADR-013-control-plane-contract-ownership.md`; `rust/src/cli/demo_cmd.rs`; team-invite contract | Protocol request/decision types and deterministic `LocalControlPlane` exist; CLI has a Control Plane task-lifecycle demo. No remotely deployed control plane, scheduler, policy store, HA, tenant authorization or telemetry collector was found. | **P0** |

## Detailed findings

### Enterprise and gateway modules

`lean-ctx enterprise init|status` persists `EnterpriseConfig` (gateway URL,
instance token, instance ID and header-injection setting) and validates a `/health`
request. During proxy forwarding, it injects a bearer token plus instance, token
savings, agent, session, and task-class headers. This is a useful agent-side
integration, not a full enterprise offering: referenced `lean-ctx-enterprise`
gateway/cloud server sources appear only in the runtime reality inventory, while
`cloud-infra/` is not present in this checkout.

### Tenancy, identity, and authorization

`IdentityContext` models tenant/project/agent/human/service/session identity.
`TenantBoundary`, `assert_same_tenant`, and `EvidenceChain::append_scoped/verify`
prevent a mixed-tenant signed evidence chain; classified tenant-bound data carries
the same boundary. This is good security-domain design, but no evidence connects an
authenticated cloud/gateway request to the identity, nor applies it to every cache,
index, cloud object, audit entry, or billing record. There is also no data-store
isolation implementation in scope.

RBAC is separate from organizational RBAC. `roles.rs` supports built-in and
filesystem-defined local roles with inheritance, tool allow/deny lists, shell policy,
I/O boundaries, and limits. `role_guard` and `policy_guard` enforce calls and write
audit records. It has no organization membership or identity-provider mapping.

### SSO, teams, and fleet

The SSO guide is unusually specific—OIDC discovery/JWKS and an
`https://api.leanctx.com/api/auth/sso/callback` callback—and advertises SAML plus
SCIM for Enterprise. The client source has neither endpoint handler nor protocol
implementation. `sso_oidc`/`sso_scim` occur only as billing entitlement output in
the Rust product source. Do not represent SSO or SCIM as built without the separate
backend.

Team invites are a well-described API contract, but the open-source command is
explicitly a stub. Similarly, fleet protocol types describe agents, spend, budgets
and allowed models/providers, but the only implementation permits every action.
Neither can operate or govern a 50-developer pilot today.

### Audit and compliance

Audit coverage is the strongest enterprise-ready component. Policy, role, dispatch,
agent registry and handoff paths record events in a locked append-only JSONL trail
with predecessor hashes; verification detects tampering. The separate evidence
chain adds Ed25519 signatures, ordered timestamps, identity attribution and tenant
checking. These are local-host controls, not centralized compliance operations.

EU AI Act mapping uses honest status semantics: “full” claims require a mechanism
and test; policy-pack controls are live-evaluated; report artifacts are signed and
offline-verifiable. `rust/tests/compliance_frameworks.rs` verifies at least ten
enforced full EU AI Act controls, while retention is explicitly not enforced.
This supports a technical readiness discussion, not a legal compliance certification.

### Dashboard, usage, cloud

The Cockpit dashboard is a substantive local web application, with static
components and dynamic routes. It has careful local/network exposure behavior, but
is owned by one local install. Under the `enterprise` feature,
`/api/usage-breakdown` optionally asks `gateway_server.admin_url` for central usage;
otherwise it returns a local snapshot. That is an integration seam, not a centralized
console.

Personal cloud features are more developed client-side: credentials are permission
restricted, token refresh is supported, and opt-in background tasks sync telemetry,
stats, knowledge/gotchas (documented as end-to-end encrypted), commands and index
bundles. These calls require a remote service that is outside the worktree. The
cloud plan/check-out flows and billing catalog must not be confused with reliable
usage billing: local `Usage::headline()` calls metering an OSS stub.

## Pilot recommendation

1. **Gate a 50-developer pilot on P0:** deliver/review the gateway/cloud backend,
   tenant/auth data model, central audit retention, org lifecycle and fleet policy
   enforcement; perform an end-to-end isolation and recovery test.
2. **Offer a narrowly scoped pilot before that only if customer-hosted:** use the
   local proxy, local RBAC/policy guards, local dashboard, and signed audit/evidence
   exports. State that user management, SSO, fleet and centralized monitoring are
   not included.
3. **Do not sell as complete:** SAML/SCIM SSO, hosted proxy, team management,
   centralized control plane, fleet management, production billing, or legal EU AI
   Act compliance until the missing server implementation and operations evidence
   are audited.

