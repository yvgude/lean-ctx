# LeanCTX SDK v1.0 + first paying customer — definitive 90-day execution plan

**Execution window:** Day 1 = 19 August 2026; Day 90 = 16 November 2026.  
**Single objective:** ship a supportable `lean-ctx-sdk` v1.0 for one Python/OpenAI Agents SDK path, prove lower **Verified Cost per Successful Agent Task** (VCP-SAT), and collect payment from customer #1.

## Decisions frozen on Day 1

| Decision | Rule for this plan |
|---|---|
| Product boundary | LeanCTX is a **Context Runtime + SDK**, not an agent framework. It improves context selection/compression, kits, evidence, and cost measurement; it does not own orchestration, handoffs, or the customer's provider account. |
| First supported path | Python + OpenAI Agents SDK only. Do not add a second paid adapter before the Day-70 demand gate. |
| v1 public surface | `LeanCTX.wrap(agent, config)`; `run()` returns a `LeanCtxRun` with the unmodified native output and an execution receipt; `prepare`, `load_kit`, `receipt`, and `compare` are the only promised primitives. |
| Evidence promise | Every wrapped execution gets one local, signed receipt or an explicit `evidence_status=unavailable`; never fabricate a receipt or silently claim a cost/quality result. |
| Commercial offer | **Verified Savings Pilot — CHF 7,500 prepaid, BYOK, 30 days, one agent/workflow, up to three matched tasks.** Deliver signed baseline/treatment bundles, quality comparison, offline verifier, executive report, and next-step recommendation. Credit 50% toward an annual contract signed within 60 days. No zero-cost exception without a written founder decision. |
| North-star metric | `VCP-SAT = provider-reported net LLM cost / tasks passing the predeclared automated and human quality gates`. A customer claim requires a matched baseline, versioned pricing, provider cache treatment, and a signed bundle. |
| Commercial proof threshold | At least **40% lower VCP-SAT with no quality regression** on a customer-approved workload. The present 79–86% internal result is evidence of potential, not a promise. |
| OSS boundary | Local runtime, SDK, wrappers, local kits, local receipts, and local measurements stay open. Shared evidence, hosted history/continuous tuning, private registry, organization policies, RBAC/SSO, fleet control, and SLA are later paid layers. |

## Starting assets and constraints

The plan extends, rather than replaces, the current codebase:

- `rust/crates/lean-ctx-sdk` is the accepted in-process Rust façade; it already exposes the real engine via `EngineBuilder` with PathJail and explicit write/exec gates.
- `packages/python-lean-ctx` is the Python package (`lean_ctx`, v0.3.0) with local proxy compression plus LiteLLM, LangChain, and LlamaIndex adapters; it does **not** yet provide the OpenAI Agents wrapper.
- `py-sdk` already models OCLA `ContextPlanV1`, `ContextReceiptV1`, policies, and ledger access. Reuse its versioned concepts rather than inventing parallel receipt names.
- `rust/src/cli/dispatch/evidence_realworld.rs` already runs five-turn matched provider calls and accounts for `cached_tokens`; `evidence_workflow`, `evidence_report`, evidence bundles, verification, and `scripts/pilot-setup.sh` are usable foundations.
- `kits/code-review` already supplies a review-oriented context kit; `ctx_review` and `ctx_verify` are available for the reference agent.
- Cursor, Codex, and Claude Code are protected OSS paths. Every release in this plan must pass their smoke matrix; a critical regression pauses commercial work after one business day.

## Definition of done on Day 90

1. `lean-ctx-sdk` Python v1.0 is installable, documented, semver-versioned, and supports `LeanCTX.wrap()` for the OpenAI Agents SDK with deterministic tests, rollback/uninstall, and a 15-minute external-developer quickstart.
2. Every successful wrapped execution emits a local, offline-verifiable receipt; failures state why evidence is unavailable and retain the native agent outcome/error semantics.
3. The repository contains a demonstrable stock-versus-LeanCTX-native code-review reference agent using `kits/code-review`, with matched workload manifests and quality gates.
4. Customer #1 has paid CHF 7,500, received a signed matched evidence bundle, and has a written conversion/renewal decision. A pilot only counts if the predeclared quality bar passes.
5. A customer-specific bundle independently demonstrates >=40% VCP-SAT reduction with no quality regression, **or** the decision memo records an honest failed hypothesis and a narrower next experiment.
6. Customer #2 has begun a paid pilot or has a paid kickoff date and signed scope; no critical Cursor/Codex/Claude Code regression remains open.

## Operating system

- **Daily:** 20-minute evidence/deal stand-up: current constraint, yesterday's artifact, today's testable output, buyer next action, and blocker owner.
- **Monday:** choose one proof-or-revenue bottleneck; freeze all unrelated feature requests.
- **Thursday:** customer calls, live demos, results reviews, and proposals. Every conversation ends with a named owner and dated next decision.
- **Friday:** release/compatibility review, Evidence Ledger update, deal-board hygiene, and a published internal decision log.
- **Scope control:** use the real engine/protocol/evidence code; do not create a control plane, dashboard, user accounts, hosted secrets, a marketplace, or a second framework integration during these 90 days.

## Days 1–30 — day-by-day plan

### Day 1 — Wed 19 Aug: establish the baseline

- **Tasks:** appoint the single technical owner and commercial owner; create one Evidence Ledger and one deal board; capture current test/compatibility status; record the existing real-world result as an internal baseline, not a customer claim.
- **Deliverable:** `sdk-v1` decision log, ledger template, deal-board template, and repository health snapshot.
- **Dependencies:** access to current CI/test status and the existing evidence outputs.
- **Success:** one owner per decision; no ambiguous target metric; all current blockers are named and dated.

### Day 2 — Thu 20 Aug: audit the actual surfaces

- **Tasks:** map `rust/crates/lean-ctx-sdk`, `lean-ctx-protocol`, `packages/python-lean-ctx`, `py-sdk`, evidence commands, verifier, and `kits/code-review`; list every existing public Python symbol and evidence schema used by tests.
- **Deliverable:** API/evidence inventory with “reuse”, “adapt”, and “do not expose” columns.
- **Dependencies:** Day-1 health snapshot.
- **Success:** each proposed v1 method maps to an existing runtime/protocol capability or a named implementation task; no duplicate receipt model is proposed.

### Day 3 — Fri 21 Aug: freeze product and buyer scope

- **Tasks:** approve the Python/OpenAI Agents SDK wedge; publish v1 non-goals; define the ICP: Head of Engineering or staff platform engineer at a 20–80-person B2B SaaS company running >=100 coding-agent tasks/week; approve the CHF 7,500 pilot and BYOK terms.
- **Deliverable:** one-page product/buyer/offer brief and 30-account target list rubric.
- **Dependencies:** Day-2 inventory.
- **Success:** one integration, one buyer, one price, one metric; all platform work is explicitly parked.

### Day 4 — Sat 22 Aug: write the contract skeleton

- **Tasks:** draft `SDK Contract v1`: lifecycle, configuration, result/receipt ownership, failure modes, privacy, semantic-versioning policy, and adapter boundary; define `LeanCtxRun[T]` with `output`, `receipt`, `evidence_status`, and `run_id`.
- **Deliverable:** contract outline plus typed pseudocode and open-question list.
- **Dependencies:** Day-3 scope.
- **Success:** native agent output is preserved as `LeanCtxRun.output`; receipt attachment is concurrency-safe and does not depend on a mutable global “last receipt”.

### Day 5 — Sun 23 Aug: specify evidence invariants

- **Tasks:** define receipt minimum fields: SDK/runtime versions, adapter version, manifest hash, prompt/task hash, provider/model, cache usage, versioned prices, context/kit decisions, quality evidence, redaction/consent, timestamps, signer, and limitations; specify `unavailable`, `partial`, and `verified` states.
- **Deliverable:** receipt schema delta and canonical JSON/signature rules.
- **Dependencies:** Day-4 contract skeleton and existing protocol/evidence schemas.
- **Success:** a receipt cannot state `verified` without matched arms, provider usage, both quality gates, and a verifier-passing signature.

### Day 6 — Mon 24 Aug: agree quality and comparison rules

- **Tasks:** write the workload manifest contract: repository commit, task/prompt, agent/framework versions, provider/model settings, seeded/repeated-run rule, test command, human-review rubric, redaction policy, and acceptance threshold; define VCP-SAT calculation including cached-token pricing.
- **Deliverable:** `PilotWorkloadManifestV1` schema/example and quality scorecard.
- **Dependencies:** Day-5 evidence invariants.
- **Success:** an unmatched baseline/treatment run is rejected before it can enter a report.

### Day 7 — Tue 25 Aug: contract review gate

- **Tasks:** run a 60-minute design review; resolve all v1 open questions; write migration compatibility notes for current `lean_ctx` and `py-sdk` users; publish the approved contract internally.
- **Deliverable:** signed-off SDK Contract v1, ADR/decision log, and implementation backlog sequenced by dependency.
- **Dependencies:** Days 4–6.
- **Success:** no P0 contract ambiguity remains; changing the public surface now requires a recorded exception.

### Day 8 — Wed 26 Aug: scaffold the Python wrapper

- **Tasks:** add the wrapper module, typed `LeanCTX`, `WrapConfig`, `LeanCtxRun`, and error taxonomy in `packages/python-lean-ctx`; pin the compatible OpenAI Agents SDK range; wire local daemon/proxy discovery without changing existing `compress()` behavior.
- **Deliverable:** importable wrapper skeleton, package metadata change, and constructor/config unit tests.
- **Dependencies:** approved Day-7 contract and a tested OpenAI Agents SDK version.
- **Success:** `from lean_ctx import LeanCTX` works; invalid configuration fails before the agent runs; existing package tests remain green.

### Day 9 — Thu 27 Aug: implement transparent run interception

- **Tasks:** implement the smallest supported wrapped execution path; preserve agent input/output and cancellation semantics; introduce explicit context preparation before provider dispatch; make evidence opt-in in `WrapConfig` while the API stabilizes.
- **Deliverable:** first runnable `LeanCTX.wrap(agent)` sample against a fixture agent.
- **Dependencies:** Day-8 scaffold and a stable test fixture.
- **Success:** stock and wrapped fixture produce equivalent functional output when compression/evidence are disabled.

### Day 10 — Fri 28 Aug: test the compatibility seam

- **Tasks:** add tests for sync/async invocation as supported by the selected Agents SDK version, exceptions, cancellation, streaming decision, re-entrancy, proxy unavailable, and no-op/rollback mode; document any v1 exclusion rather than silently half-supporting it.
- **Deliverable:** adapter compatibility test matrix and explicit v1 limitations.
- **Dependencies:** Day-9 runnable wrapper.
- **Success:** every listed failure path returns the documented typed error or the original agent error; no native output mutation is hidden.

### Day 11 — Sat 29 Aug: build the quickstart fixture

- **Tasks:** create a minimal code-review task fixture with fixed source, task, expected tests, and human-review rubric; add a clean-environment bootstrap and exact install commands.
- **Deliverable:** runnable `examples/python-openai-agents-code-review` quickstart fixture.
- **Dependencies:** Days 8–10.
- **Success:** a fresh environment reaches first wrapped task without repository-specific configuration.

### Day 12 — Sun 30 Aug: prove 15-minute onboarding

- **Tasks:** have an uninvolved developer or clean machine follow the quickstart; record time, commands, errors, and manual interventions; fix only first-run blockers.
- **Deliverable:** measured onboarding transcript and revised quickstart.
- **Dependencies:** Day-11 fixture.
- **Success:** first wrapped task runs in <=15 minutes with zero undocumented intervention.

### Day 13 — Mon 31 Aug: make the wrapper releasable

- **Tasks:** add changelog entry, semantic-version gate, API docs, typed examples, uninstall/disable instructions, and a compatibility smoke job for Cursor, Codex, and Claude Code.
- **Deliverable:** Python wrapper release candidate checklist and CI job definition.
- **Dependencies:** passing Days 10–12 tests.
- **Success:** SDK changes are isolated from existing CLI/MCP paths and each protected path has a smoke command.

### Day 14 — Tue 1 Sep: wrapper acceptance review

- **Tasks:** run the complete Python package suite, targeted Rust/protocol/evidence tests, and protected-path smoke matrix; fix P0/P1 defects; tag the contract/wrapper candidate.
- **Deliverable:** Wrapper RC report with passing commands and known limitations.
- **Dependencies:** Day-13 CI.
- **Success:** all release gates pass; contract, package version, docs, and examples agree.

### Day 15 — Wed 2 Sep: begin automatic evidence lifecycle

- **Tasks:** implement creation of a run context at `wrap()` time and deterministic run ID/manifest linkage at each wrapped execution; record adapter/runtime/package versions and configuration fingerprint.
- **Deliverable:** run-lifecycle data model and unit tests.
- **Dependencies:** Day-14 RC and Day-5 receipt rules.
- **Success:** every wrapped execution has a traceable run record before context is modified.

### Day 16 — Thu 3 Sep: capture provider usage honestly

- **Tasks:** connect the wrapper to provider-reported prompt, cached-input, and completion usage for the supported path; distinguish missing provider fields from zero; attach the selected pricing-version identifier, not a mutable current price.
- **Deliverable:** provider-usage adapter and pricing/usage fixtures.
- **Dependencies:** Day-15 run lifecycle and access to usage response shapes.
- **Success:** receipt arithmetic reproduces fixture costs exactly; unavailable fields produce `partial`, never invented values.

### Day 17 — Fri 4 Sep: attach context decisions and kits

- **Tasks:** capture selected/compressed context descriptors and `kits/code-review` version/hash without retaining raw sensitive prompt content by default; define opt-in local artifact retention and redaction behavior.
- **Deliverable:** context-decision and kit-provenance receipt section with privacy tests.
- **Dependencies:** Days 15–16 and kit metadata.
- **Success:** receipt proves what mechanism ran while the default artifact contains no raw source/prompt payload.

### Day 18 — Sat 5 Sep: automate quality evidence

- **Tasks:** add a declared automated test-command result and required human-review decision to the run manifest/receipt; reject a commercial “success” if either is absent; define the reviewer identity/approval record.
- **Deliverable:** quality scorecard implementation and failing-fixture tests.
- **Dependencies:** Day-6 quality contract.
- **Success:** a cheaper treatment that fails tests or review cannot improve VCP-SAT or appear as a customer success.

### Day 19 — Sun 6 Sep: sign and verify locally

- **Tasks:** assemble the execution receipt/bundle from the wrapper path; use existing evidence verification primitives; add tamper, missing-file, and signature-format compatibility tests.
- **Deliverable:** `verify` command/example that validates a wrapper-produced bundle offline.
- **Dependencies:** Days 15–18 and current evidence bundle/verifier code.
- **Success:** clean verification passes; byte or manifest tampering fails deterministically.

### Day 20 — Mon 7 Sep: define evidence failure behavior

- **Tasks:** test daemon down, provider usage absent, signer unavailable, unsupported stream, quality timeout, and disk write failure; finalize whether native task continues or fails for each mode (`observe`, `required_evidence`).
- **Deliverable:** evidence failure-mode table, typed errors, and recovery guidance.
- **Dependencies:** Day-19 bundle path.
- **Success:** default `observe` never breaks a successful native agent call; `required_evidence` fails closed before any commercial claim.

### Day 21 — Tue 8 Sep: first complete receipt demo

- **Tasks:** run the quickstart stock and treatment variants on the fixed fixture; generate two receipts, a comparison, a signed bundle, and an HTML/Markdown report using existing reporting code.
- **Deliverable:** reproducible internal “wrapper → receipt → verify → report” demonstration.
- **Dependencies:** Days 15–20.
- **Success:** an observer can verify the bundle from a clean checkout and see VCP-SAT inputs, cache treatment, quality outcomes, and limitations.

### Day 22 — Wed 9 Sep: harden reproducibility

- **Tasks:** add canonical manifest sorting/hash tests, fixed-clock test injection where necessary, exact pricing snapshot fixture, and repeat-run comparisons; remove synthetic fallback from commercial evidence paths.
- **Deliverable:** determinism/reproducibility test suite and “real data unavailable” error path.
- **Dependencies:** Day-21 complete demo.
- **Success:** rerunning a fixed fixture produces identical signed inputs apart from allowed run identity/time metadata; failed test collection is reported as failed, not simulated.

### Day 23 — Thu 10 Sep: pilot privacy and setup readiness

- **Tasks:** extend `scripts/pilot-setup.sh` or adjacent wrapper setup with prerequisite checks, local output directory, redaction preflight, uninstall/rollback, and verifier installation; write a short data-handling note.
- **Deliverable:** pilot setup RC and redaction/preflight report.
- **Dependencies:** Days 19–22 and existing setup script.
- **Success:** preflight lists data boundaries, blocks known secret patterns by default, and uninstall removes only pilot configuration.

### Day 24 — Fri 11 Sep: rehearsal #1

- **Tasks:** conduct an internal pilot on a non-production repository: intake, manifest approval, baseline, treatment, test/review, sign, verify, and executive report; measure founder time and every manual step.
- **Deliverable:** first rehearsal bundle, report, and gap list.
- **Dependencies:** Day-23 setup RC.
- **Success:** bundle verifies offline; all deviations from the runbook are recorded; founder effort is <=6 hours for the rehearsal.

### Day 25 — Sat 12 Sep: repair only evidence blockers

- **Tasks:** fix rehearsal P0/P1 defects; encode every repeated manual step in the setup/runbook; add regression fixtures for the failures found.
- **Deliverable:** Pilot-in-a-Box v0.1 and updated tests.
- **Dependencies:** Day-24 gap list.
- **Success:** no unresolved defect can falsify cost, quality, consent, or signature evidence.

### Day 26 — Sun 13 Sep: rehearsal #2 and rollback drill

- **Tasks:** repeat the entire flow with a different representative task; intentionally test proxy/signing/quality failure and rollback/uninstall; compare outputs with rehearsal #1.
- **Deliverable:** second rehearsal bundle, rollback evidence, and revised operator runbook.
- **Dependencies:** Day-25 fixes.
- **Success:** both bundles verify; rollback is documented and leaves the host usable; the operator completes the run without product-author intervention.

### Day 27 — Mon 14 Sep: publish SDK v1.0 release candidate

- **Tasks:** cut the Python SDK RC, publish release notes, generate API reference, pin dependencies, and run all quality gates plus protected OSS smoke tests; prepare package publication but do not release if any evidence blocker remains.
- **Deliverable:** `lean-ctx-sdk` v1.0.0-rc candidate and release checklist.
- **Dependencies:** Days 24–26.
- **Success:** all automated gates pass and the external quickstart still completes in <=15 minutes.

### Day 28 — Tue 15 Sep: customer-facing proof package

- **Tasks:** finish the concise methodology, executive report template, pilot SOW/order form, data-handling note, objection sheet, 20-minute demo script, and 30 named target accounts with buyer/reason/task-volume hypothesis.
- **Deliverable:** sales-ready Pilot-in-a-Box package.
- **Dependencies:** Day-27 release candidate and verified rehearsals.
- **Success:** every value claim has a method/limitation statement; offer, price, acceptance criteria, and invoice trigger are unambiguous.

### Day 29 — Wed 16 Sep: outreach and technical validation

- **Tasks:** send 15 personalized invitations; run at least two demos using the reference fixture; qualify each response on workload frequency, current OpenAI Agents usage, spend, buyer authority, quality gate, security path, and decision date.
- **Deliverable:** updated deal board, call notes, and at least two technical-validation slots.
- **Dependencies:** Day-28 proof package.
- **Success:** no unqualified lead enters delivery; each qualified lead has a concrete next action/date.

### Day 30 — Thu 17 Sep: SDK v1.0 go/no-go

- **Tasks:** hold release and commercial readiness review; publish v1.0 if all gates pass, otherwise remain RC and execute the smallest corrective patch; select one pilot candidate and request a written validation scope.
- **Deliverable:** `lean-ctx-sdk` v1.0 release decision, readiness scorecard, and named pilot-candidate action plan.
- **Dependencies:** Days 27–29.
- **Success:** v1.0 has a verified wrapper receipt path, docs, rollback, tests, and a known support boundary; one candidate is at written-scope or procurement stage.

## Days 31–90 — week-by-week plan

### Week 5 — Days 31–37 (Fri 18–Thu 24 Sep): make the reference agent demonstrable

- **Tasks:** build the smallest reference code-review agent twice: stock OpenAI Agents SDK and LeanCTX-wrapped/native-context version; load `kits/code-review`; use the same repository/task manifest, provider/model, budget, test command, and human rubric. Add a one-command demo, baseline/treatment receipts, and a short architecture diagram.
- **Deliverable:** `examples/python-openai-agents-code-review` with stock/treatment modes, workload manifest, verified evidence bundle, and five-minute demo script.
- **Dependencies:** v1.0 wrapper, evidence lifecycle, `kits/code-review`, and fixture repository.
- **Success:** both versions complete the same review task; treatment is independently verifiable; quality meets or exceeds baseline; no unsupported agent-framework behavior is implied.

### Week 6 — Days 38–44 (Fri 25 Sep–Thu 1 Oct): turn the demo into a buyer proof

- **Tasks:** run the reference agent across three representative fixtures; document variance and cache behavior; finish offline verifier UX; run five discovery calls and three live demos; issue proposals only to buyers with a named workflow, sponsor, access path, quality gate, and decision date.
- **Deliverable:** reference-agent benchmark report, comparison matrix, refreshed Pilot-in-a-Box v1.0, and 3–5 qualified pilot proposals.
- **Dependencies:** Week-5 demo and Day-28 commercial materials.
- **Success:** a prospect sees stock → wrapped agent → receipt → verifier in <=20 minutes; at least one CHF 7,500 proposal is in approval; no claim generalizes beyond measured workloads.

### Week 7 — Days 45–51 (Fri 2–Thu 8 Oct): close and onboard pilot customer #1

- **Tasks:** close one fixed-scope pilot: signed SOW/order form, CHF 7,500 payment collected, named executive sponsor and technical owner, predeclared quality bar, redaction/consent choice, and kickoff date; run pilot setup and approve the customer workload manifest before collecting any comparison result.
- **Deliverable:** paid-customer ledger entry, kickoff record, signed manifest, consent/preflight result, and delivery calendar.
- **Dependencies:** qualified proposal, purchaser authority, customer BYOK/provider access, and security approval for a non-production or representative workload.
- **Success:** cash is received; first matched baseline is scheduled within five business days; customer can run the verifier locally; protected OSS smoke matrix remains green.

### Week 8 — Days 52–58 (Fri 9–Thu 15 Oct): execute pilot #1 safely and repeatedly

- **Tasks:** run up to three agreed matched workloads; conduct weekly quality and VCP-SAT review; add only customer-discovered SDK hardening (documented error code, receipt migration guidance, redacted regression fixture); convert repeated delivery steps into Pilot-in-a-Box v1.1; prepare a customer-approved/anonymized case-study outline.
- **Deliverable:** signed customer baseline/treatment bundles, weekly results page, SDK patch/release notes, repeatable runbook, and case-study outline.
- **Dependencies:** Week-7 kickoff, stable customer workload, completed test/reviewer decisions.
- **Success:** each customer run has a pinned manifest and passes offline verification; founder support trends to <4 hours/week after onboarding; quality or evidence failures stop the claim and trigger the blocked-runbook.

### Week 9 — Days 59–65 (Fri 16–Thu 22 Oct): validate measurement, not optimism

- **Tasks:** independently re-run or customer-re-run one representative workload; reconcile provider usage and price-version arithmetic; compare quality results; calculate VCP-SAT with confidence/variance notes; publish no case study yet; start conversion discussion using the measured report.
- **Deliverable:** measurement-validation memo, independently verified bundle, customer executive report, and conversion proposal (CHF 1,500/month for three months only if value/support economics justify it).
- **Dependencies:** valid Week-8 bundles and customer reviewer availability.
- **Success:** a second operator verifies the evidence without founder access; commercial threshold is either met or honestly failed; customer has a written conversion decision date.

### Week 10 — Days 66–72 (Fri 23–Thu 29 Oct): use evidence to choose—not expand

- **Tasks:** audit all receipts, workflow manifests, sales stages, cash, support hours, quickstart completion, and compatibility status; publish an integration decision memo. Add another adapter only if two paid/prepaid requests share it and total >=CHF 10,000 annualized value; otherwise retain Python/OpenAI as the sole paid path. Execute second-wave outreach using approved evidence only.
- **Deliverable:** Day-70 evidence/revenue decision memo, updated support matrix, SDK hardening release if warranted, and 2–3 second-pilot proposals.
- **Dependencies:** Week-9 validation and real buyer demand.
- **Success:** roadmap changes have a payment/proof link; one of customer #1 conversion or second paid pilot is contracted; OSS release matrix is green.

### Week 11 — Days 73–79 (Fri 30 Oct–Thu 5 Nov): write an approved case study and sell pilot #2

- **Tasks:** write the case study from the signed receipt and customer approval: starting workflow, methodology, cache treatment, quality gates, VCP-SAT result/range, limitations, and verification instructions; obtain written approval or publish only anonymized/no-number version. Run four targeted demos and close the second pilot scope on the unchanged offer.
- **Deliverable:** approved/anonymized case study, reproducibility appendix, customer-reference request, and pilot #2 SOW/invoice.
- **Dependencies:** Week-9 validation, customer #1 approval, and Week-10 demand memo.
- **Success:** the case study makes no unverified claim; at least one qualified buyer has signed pilot #2 scope and a payment/kickoff path.

### Week 12 — Days 80–84 (Fri 6–Tue 10 Nov): start pilot #2 and preserve the core

- **Tasks:** collect payment or signed payment date for pilot #2; run preflight, setup, manifest approval, and first baseline; repeat v1.0 onboarding without bespoke architecture changes; run OSS release smoke/triage and record all commercial-only changes separately.
- **Deliverable:** pilot #2 kickoff bundle (scope, preflight, manifest, baseline plan), v1.0 support record, and case-study distribution log.
- **Dependencies:** Week-11 signed scope and customer #2 environment/access.
- **Success:** customer #2 has begun the measured flow; no critical compatibility regression is open; delivery uses the standard kit with <=2 founder setup hours.

### Week 13 — Days 85–90 (Wed 11–Mon 16 Nov): close the learning loop

- **Tasks:** complete the Day-90 Evidence Ledger; verify archives from a clean machine; hold renewal/expansion/stop meetings with both customers; publish an internal 90-day decision memo; communicate OSS status and commercial boundary to the community; create only the first two weeks of the next plan.
- **Deliverable:** signed/archive-tested delivery folder, SDK Thesis Scorecard, cash/support ledger, customer decision records, and next-quarter go/no-go memo.
- **Dependencies:** all prior evidence, deal board, support-time log, and customer decisions.
- **Success:** the Day-90 definition of done is measured item by item; a failed gate changes the next action to a narrower paid-proof cycle, not a platform build.

## Blocked-work playbook

| Blocker | Immediate action (same day) | Decision gate / fallback |
|---|---|---|
| Contract dispute or API ambiguity | Stop implementation at the public boundary; write two concrete alternatives with compatibility, evidence, and support impact. | Technical owner decides within 24 hours; default to the smaller explicit API. Do not ship a compatibility guess. |
| OpenAI Agents SDK lifecycle/streaming mismatch | Reduce v1 to the documented non-streaming `run` path, preserve native behavior, and mark streaming unsupported in code/docs. | Extend only after a paid customer requires it and a fixture proves it. |
| Daemon/proxy unavailable | In `observe` mode continue the native agent call and record `evidence_status=unavailable`; in `required_evidence` fail before commercial measurement. | Never backfill guessed receipt data; fix reliability before customer claims resume. |
| Provider usage/cache data missing | Mark receipt `partial`; retain raw provider response metadata permitted by policy; do not calculate verified VCP-SAT. | Switch to a provider/model response shape that exposes usage or call the run non-verifiable. |
| Quality regresses | Stop treatment rollout, preserve baseline, attach failed quality evidence, and perform recovery/expansion drill. | Diagnosis may change context policy/kit; it may not be reported as savings or billed as performance proof. |
| Secret/privacy/security review blocks source access | Use the customer's non-production repo or sealed representative fixture; run entirely locally with BYOK and redaction preflight. | If that cannot meet the quality bar, do not start a pilot; replace prospect rather than request unrestricted production access. |
| Pilot prospect requests free PoC | Offer the public demo/reference bundle free, not bespoke setup or customer measurement. | Hold the CHF 7,500 boundary; reserve a zero-price exception for a written founder decision with an explicit strategic return. |
| Procurement stalls | Ask for card/simple-invoice path and a dated decision; keep another qualified buyer active. | After 10 business days without a payment route, move the account out of the active pilot slot. |
| Cursor/Codex/Claude Code regression | Same-day triage and rollback/release fix; pause commercial feature work after one business day if unresolved. | Customer work proceeds only when it does not rely on the broken OSS path; otherwise defer delivery honestly. |
| Customer asks for another framework | Record framework, workflow volume, buyer, and prepaid value on the deal board. | Build only after two paid/prepaid requests total >=CHF 10,000 annualized value and share the same framework. |

## Minimum viable target vs ambitious target

| Area | Minimum viable by Day 90 | Ambitious, only after minimum is safe |
|---|---|---|
| SDK v1.0 | One documented Python/OpenAI wrapper path; 15-minute quickstart; stable config/errors; local rollback. | Async/streaming parity, richer typed helpers, and a second adapter after the demand gate. |
| Evidence | One receipt per wrapped execution; local signing/offline verification; provider usage/cache data; required automated + human quality gates. | Independently repeated customer runs, confidence intervals/variance dashboard, and scheduled local CI evidence runs. |
| Reference agent | One stock-versus-treatment code-review demonstration with three fixtures and an honest comparison report. | Raw vs proxy vs native integration-depth benchmark on several repositories. |
| Customer #1 | CHF 7,500 collected; one verified customer bundle; written conversion decision. | Three completed workflows, a CHF 1,500/month conversion, and an approved named case study. |
| Customer #2 | Paid/SOW-signed kickoff and first baseline under the unchanged Pilot-in-a-Box process. | Payment collected and first verified treatment bundle before Day 90. |
| OSS health | No critical unresolved Cursor/Codex/Claude Code regression; clear open-core boundary. | A compatibility-checked maintenance release and a public methodology update. |

## Communication checkpoints

| When | Audience | Required message / artifact |
|---|---|---|
| Day 1 | Core team | Freeze metric, buyer, first integration, offer, owners, and parked work. |
| Day 7 | Engineering/product | SDK Contract v1 approval or named unresolved decision; no implementation ambiguity carried forward. |
| Day 14 | Engineering | Wrapper RC status, support matrix, tests, limitations, and release risk. |
| Day 21 | Engineering + founder | Live receipt/verifier demo; evidence failure modes; go/no-go for pilot rehearsal. |
| Day 27 | Engineering + OSS maintainer | v1.0 RC/release evidence and protected-path compatibility result. |
| Day 30 | Founder/sales | Release decision, qualified-pipeline count, chosen pilot candidate, and next decision dates. |
| Every Thursday, Days 29–72 | Each prospect/customer | 20-minute demo or results review: same agent, wrapped path, receipt, verifier, scope, next decision. |
| Week 7 kickoff | Customer #1 sponsor + technical owner | Signed scope, data boundary, quality gate, workload manifest, delivery calendar, escalation route. |
| Weekly during each pilot | Customer sponsor + technical owner | VCP-SAT/quality status, evidence state, variance/limitations, risks, and approve/stop decision. |
| Week 9 | Customer #1 executive | Independently verified measurement report and conversion recommendation—whether or not threshold is met. |
| Week 11 | Customer #1 | Case-study approval request with exact text/numbers; publication only after written approval. |
| Week 12 | Customer #2 | Standardized onboarding/manifest approval and first-baseline schedule. |
| Day 90 | Team, customers, OSS community | Evidence Ledger result, what remains OSS, what the paid pilot proved, honest misses, and the single next-quarter decision. |

## Day-90 decision rule

Continue the SDK/verified-savings wedge only when all of the following are true: payment from at least one customer; one independently verified customer bundle with >=40% lower VCP-SAT and no quality regression; external quickstart completion without agent-architecture changes; protected OSS paths green; and post-onboarding support below four founder hours per active customer/week. Otherwise maintain OSS, stop platform expansion, state the failed assumption plainly, and run one narrower paid proof cycle.
