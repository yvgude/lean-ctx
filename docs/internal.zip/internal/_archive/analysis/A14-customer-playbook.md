# First paying customer playbook — Founding Pilot

**Commercial objective:** convert one Swiss design partner from a 30-day proof-of-value (PoV) into a paid annual LeanCTX agreement. Start with a CHF 0 PoV only for a named sponsor with an accessible baseline; do not run an open-ended trial.

**Evidence used in every conversation:** the current independently reproducible HTML evidence report measured **78.9% lower billed cost** and **85.0% fewer prompt tokens** on the same five-turn code-review workflow (99,203 → 14,857 prompt tokens; USD 0.26880 → USD 0.05670). This is a benchmark result, not a promise for the prospect. The customer’s matched baseline/treatment report is the only basis for a savings claim or invoice.

All prices below are **CHF, excluding VAT and provider inference charges**. Provider usage remains BYOK/pass-through.

## 1. Target profile and buying committee

### Ideal customer profile

Prioritise companies that meet all five criteria:

| Dimension | Target | Why it closes first |
|---|---|---|
| Company | Swiss-headquartered or Swiss business unit; roughly 50–500 employees | Shorter buying path than a large multinational, but sufficient recurring AI spend |
| Engineering | 10–50 software developers in one or more product squads | Enough repeated agent work for a measured result; one executive can sponsor a rollout |
| AI usage | Cursor, Claude Code, Codex, Copilot, internal coding agents, or RAG/automation agents used weekly; API/BYOK spend is visible | A baseline and an economic owner already exist |
| Pain | Rising token invoices, context-window failures, slow agent loops, or a mandate to control GenAI cost without reducing output quality | LeanCTX solves a live, funded problem rather than a speculative experiment |
| Access | A CTO/VP Engineering can name one workflow and permit a 30-day shadow measurement | Keeps the PoV bounded and conversion-able |

### First three verticals in Switzerland

1. **Fintech and regulated financial-services technology** — high API usage, governance pressure, and clear FinOps ownership. Start with a non-production or de-identified code-review workflow; engage security/procurement early.
2. **Digital/product consulting and engineering consultancies** — many developers and direct margin sensitivity. Position the result as lower delivery cost per successful task and a reusable client-delivery capability.
3. **Industrial, manufacturing, and B2B technology companies** — internal engineering teams adopting AI assistants, often with CIO/CTO cost-control mandates. Lead with local operation, a loopback proxy, and a single contained workflow.

Do not start with organisations that cannot identify a workflow, baseline, sponsor, or budget owner. A team with fewer than ten developers can be a reference user, but it is not the first paid-account target.

### Buyer map

| Role | Job in the deal | What they need to hear | Required action |
|---|---|---|---|
| CTO or VP Engineering | Economic buyer and executive sponsor | “Lower cost per successful agent task, with no quality regression.” | Approves the PoV and signs the recurring service agreement |
| Head of Platform, Developer Experience, AI Engineering, or Engineering Manager | Champion and operational owner | “One-command install, one workflow, weekly evidence; no migration.” | Chooses workflow, coordinates developers, validates quality |
| FinOps / Finance business partner | Economic validator | “Provider-priced baseline, realised savings, and a transparent formula.” | Confirms pricing inputs and accepts the savings statement |
| Security, CISO, data protection, procurement | Gatekeeper | “Local/loopback deployment, least data needed, BYOK, reversible exit.” | Clears the architecture and contract controls |
| CFO / COO | Final approver when the commitment is material | “A bounded operating cost tied to an accepted evidence report.” | Approves annual commitment, savings-share terms, or enterprise scope |

### Budget authority: ask, do not assume

On the discovery call ask: **“Which cost centre owns AI-provider spend, and who can approve up to CHF 5,000/month without a full procurement cycle?”** Record a named person before the PoV starts.

Use this operating assumption until the customer states its delegation of authority:

| Commercial level | Typical approval route | Do not proceed without |
|---|---|---|
| Up to CHF 5,000/month or a CHF 15,000 bounded engagement | CTO/VP Engineering from engineering software or AI-operations budget | Written confirmation from the CTO/VP Engineering that the budget exists |
| CHF 5,000–10,000/month or annual spend above CHF 60,000 | CTO/VP Engineering + finance owner/CFO delegate | Finance validation of model-pricing and savings-share calculation |
| More than CHF 10,000/month, regulated/self-hosted, or multi-business-unit rollout | CTO/CIO + CFO + procurement/security | A procurement plan, information-security review, and named signer |

## 2. Outreach

### Account selection and first contact

Build a list of 30 accounts: 10 fintech, 10 consulting, and 10 industrial/B2B technology firms. For each, identify a CTO/VP Engineering and a potential champion. Personalise one observation: public AI hiring, agent tooling, developer-platform investment, or a known engineering scale. Never imply access to private usage data.

Offer a **15-minute evidence review**, not a product demo. The call outcome is either “not a fit” or agreement to define one workflow and its baseline.

### LinkedIn connection/request message (German)

> Hallo {{Vorname}}, wir helfen Engineering-Teams, die Kosten von KI-Agenten messbar zu senken, ohne bei der Qualität Abstriche zu machen. In einem reproduzierbaren Workflow lagen wir bei 78,9 % weniger API-Kosten und 85,0 % weniger Prompt-Tokens. Wir suchen gerade einen Schweizer Design-Partner für einen klar begrenzten 30-Tage-PoV. Wären 15 Minuten sinnvoll, um zu prüfen, ob {{Firma}} dafür passt?

After acceptance, send:

> Danke fürs Vernetzen. Entscheidend ist nicht unser Benchmark, sondern Ihr eigener Vergleich: ein Workflow, Baseline und Qualitätskriterium vorab festlegen, dann wöchentlich transparent berichten. Wenn keine Einsparung bei mindestens gleicher Qualität sichtbar wird, beenden wir ohne Bindung. Passt {{zwei konkrete Zeitfenster}} für einen kurzen Evidenz-Check?

### Three-email sequence (German)

**Email 1 — day 0: relevance + low-friction ask**

Subject: `{{Firma}}: KI-Agentenkosten mit einem 30-Tage-Nachweis prüfen`

> Guten Tag {{Vorname}},
>
> Ihre Teams nutzen bereits {{konkretes Signal: z. B. Cursor/AI Engineering/API-Modelle}}. Genau dort entstehen oft steigende Tokenkosten und schwer nachvollziehbare Qualitätsrisiken.
>
> LeanCTX läuft unter dem bestehenden Agenten-Workflow. Wir vergleichen vorab einen vereinbarten Baseline-Workflow mit der Behandlung und liefern wöchentlich Tokens, Kosten und Qualitätsresultat. Unser reproduzierbarer Referenzlauf zeigte 78,9 % weniger Kosten und 85,0 % weniger Prompt-Tokens; Ihr Resultat wird separat gemessen.
>
> Für drei Schweizer Design-Partner bieten wir einen 30-Tage-PoV ohne Implementierungsgebühr an. Hätten Sie nächste Woche 15 Minuten für die Frage, ob ein einzelner Workflow bei {{Firma}} geeignet ist?
>
> Freundliche Grüsse  
> {{Absender}}

Attach the one-pager; link to the evidence report rather than attaching a large HTML file on first contact.

**Email 2 — day 4: proof + qualification**

Subject: `Re: {{Firma}}: messbare Kostenreduktion bei KI-Agenten`

> Guten Tag {{Vorname}},
>
> Zwei Details, damit die Aussage prüfbar bleibt: Der Referenzlauf nutzte denselben 5-Turn-Code-Review-Workflow; der HTML-Bericht enthält Modell, Vorher/Nachher-Werte, Reproduktionsschritte und einen SHA-256-Fingerprint.
>
> Für einen PoV brauchen wir nur (1) einen Sponsor, (2) einen wiederkehrenden Workflow, (3) das Qualitätskriterium und (4) Zugriff auf aggregierte Nutzungsmetriken. Installation und Rückbau erfolgen per Skript; der Proxy bindet lokal.
>
> Wer verantwortet bei Ihnen die Kombination aus Engineering-Produktivität und AI-/Provider-Budget — Sie oder jemand aus Ihrem Team?
>
> Freundliche Grüsse  
> {{Absender}}

Attach the HTML evidence report only after interest or an NDA; include the hash and a one-line limitations note.

**Email 3 — day 10: close the loop**

Subject: `Soll ich den 30-Tage-PoV für {{Firma}} schliessen?`

> Guten Tag {{Vorname}},
>
> Ich schliesse die Anfrage diese Woche, damit die drei Design-Partner-Plätze klar bleiben. Falls KI-Agentenkosten und Kontextqualität bei {{Firma}} derzeit kein Thema sind, genügt ein kurzes “nicht relevant”.
>
> Falls es relevant ist, sende ich gern eine einseitige PoV-Vereinbarung: ein Workflow, 30 Tage, wöchentlicher Evidenzbericht, keine Bindung bei ausbleibendem Qualitäts- oder Wirtschaftlichkeitsnachweis.
>
> Freundliche Grüsse  
> {{Absender}}

### Evidence package

Send a deliberate two-asset package:

1. **One-pager (first touch):** customer problem, one-workflow 30-day design, local/loopback + BYOK operating model, exactly what is measured, no-lock-in exit, and the meeting CTA. State the benchmark result as “78.9% measured cost reduction / 85.0% prompt-token reduction in a defined reference workflow,” with a “results vary” footnote.
2. **HTML evidence report (after interest/NDA):** full per-turn baseline/treatment values, methodology, model, date, reproducibility instructions, and source-data SHA-256 fingerprint. It is evidence of the reference workflow, not a customer ROI forecast.

Never attach raw prompts, source code, credentials, or customer usage logs. The customer approves the data fields in its weekly report before reporting begins.

### Warm-introduction play

Ask **Kevin at SAP**, **Francois**, and each relevant network contact for one specific introduction at a time—not for “any leads.” Give them an easy forwardable text and a named target profile.

Forwardable request (English, adapt to the relationship):

> Hi {{Connector}}, I’m looking for one Swiss CTO/VP Engineering with a 10–50 developer team already using AI coding agents and accountable for API spend. We have a bounded 30-day proof-of-value: one workflow, local setup, weekly evidence, and no lock-in. A reproducible reference run showed 78.9% lower billed cost and 85.0% fewer prompt tokens; we will measure the prospect’s result independently. Would you be comfortable introducing me to {{Name/Company}} for a 15-minute fit check? I can send a one-page brief.

Follow-up mechanics:

- Ask Kevin specifically for a Swiss SAP ecosystem customer or partner running developer AI tooling; do not ask him to sponsor the pilot without a target team.
- Ask Francois for one CTO/VP Engineering introduction in fintech, consulting, or industrial tech, plus the context that makes the approach relevant.
- Send the one-pager within one hour of the introduction; thank the connector, BCC them only if they ask, and report back once after the first meeting.

## 3. 30-day proof-of-value structure

### Entry conditions — sign before installing

The one-page PoV agreement names:

- Executive sponsor (CTO/VP Engineering), operational owner, finance validator, and conversion signer.
- One representative workflow, the participating team, providers/models, and the comparison window.
- Baseline definition; quality metric and scoring method; success threshold; exclusions such as workload/model changes.
- Approved aggregated telemetry fields, report recipients, data location/retention, and security contact.
- Day-30 conversion meeting, scheduled on day 0.

The PoV is free for 30 days for a named founding partner only. It is limited to one workflow and one team. If any entry condition is missing, run a 15-minute design session—not an installation.

### What is installed

Install LeanCTX and the local proxy with the supplied one-command installer:

```bash
curl -fsSL https://raw.githubusercontent.com/yvgude/lean-ctx/main/scripts/pilot-setup.sh | bash
```

Current installer scope is macOS. It installs LeanCTX, configures supported local tooling, and starts a loopback proxy (default `127.0.0.1:4444`); it supports removal with `scripts/pilot-setup.sh --uninstall`. Confirm the exact release version, checksum policy, model-provider routing, and customer security requirements before execution. Do not install a proxy in a production path before security approval.

The PoV includes:

- LeanCTX runtime and approved agent/tool integrations.
- Local loopback proxy only when the customer wants provider-level measurement; otherwise use LeanCTX’s MCP/tool measurements.
- A baseline/treatment profile for the single workflow.
- Access to the aggregate dashboard/ledger and a named support channel.

### What is measured

Measure matched work, not headline averages:

| Metric | Definition | Guardrail |
|---|---|---|
| Baseline prompt tokens and provider cost | Same workflow, model/provider price version, and observation window before treatment | Record model, cache treatment, and price assumptions |
| Treatment prompt tokens and provider cost | Equivalent workflow after LeanCTX configuration | Separate gross, bounce-adjusted/net, and any provider cache effect |
| Savings | `baseline − treatment`, in tokens and currency | Only quality-passing, matched work may be counted |
| Context quality score | Pre-agreed task success, test-pass rate, reviewer acceptance, or calibrated human score | Score must be **at least the agreed baseline**; otherwise tune, roll back, and exclude savings |
| Operational quality | Latency, errors, re-reads/bounces, developer feedback, and adoption | Do not trade hidden rework for apparent savings |

Use the signed/tamper-evident savings ledger and keep the report inputs: workload, model, provider pricing, cache treatment, quality method, run ID, and limitations. A forecast or an unaccepted dashboard is not invoiceable savings.

### Calendar and reporting cadence

| Timing | Action | Customer output |
|---|---|---|
| Days 0–2 | Kick-off, security confirmation, install, smoke test, baseline lock | Pilot charter + baseline snapshot |
| Days 3–7 | Observe baseline and validate the quality score | Week 1 report: coverage, baseline quality, configuration status |
| Days 8–14 | Enable/tune treatment on the same workflow | Week 2 report: before/after tokens, costs, quality, bounces, issues |
| Days 15–21 | Stabilise and expand only within the agreed team | Week 3 report: cumulative net savings, quality trend, recommendation |
| Days 22–30 | Final matched comparison and conversion preparation | Final signed evidence report + commercial recommendation |

Send the weekly report to the sponsor, operational owner, and finance validator on the same weekday. Keep it to one page plus an attached CSV/HTML evidence artifact. Every report states: scope, measurement period, baseline/treatment values, net savings, quality result, anomalies, next-week action, and whether the result is eligible for commercial calculation.

### Day-30 conversion meeting

The meeting is a 30-minute evidence review, booked before installation:

1. Confirm the agreed workflow, baseline, quality gate, and limitations.
2. Review the final report and have the sponsor/finance validator accept or dispute the savings statement.
3. Decide: **convert**, **one bounded remediation week**, or **exit**. No unbounded extension.
4. For conversion, choose Foundation, Standard, or Enterprise; name the signer, procurement owner, start date, and 90-day expansion hypothesis.

Use this line: **“The benchmark opened the conversation. This report is your evidence. It shows {{net savings}} with a quality score of {{score}} against the agreed {{baseline}}; should we lock in the 12-month rollout now?”**

## 4. Pricing and negotiation

### Value anchor

Open with the customer’s money, not token counts:

> “You spend CHF {{monthly provider spend}} per month on the agreed AI-agent workload. In the PoV, the matched, quality-passing work saved CHF {{monthly net savings}}. Our reference economic model is 10% of verified savings: we earn when the evidence shows value.”

`Verified savings` requires the pre-agreed baseline/treatment, matched workflow, declared provider prices, quality pass, customer acceptance, and an immutable/signed statement. Exclude hypothetical hiring savings, opportunity costs, model changes, unaccepted dashboards, and work outside scope.

### Quote card

| Offer | Price and term | Scope | When to use |
|---|---|---|---|
| **Founding Design Pilot** | CHF 0 implementation fee; 30 days; at most three named partners | One workflow, evidence report, tuning profile, weekly reports | Only to win the first lighthouse customer; sponsor and accessible baseline are mandatory |
| **Foundation (minimum)** | **CHF 2,500/month**, 12-month term | One team/workflow, shared evidence dashboard, monthly evidence review, business-hours support | Customer wants the smallest paid continuation or the savings-share calculation is below the floor |
| **Standard** | **CHF 5,000/month + 5% of accepted, measured net savings**, 12-month term | Up to 25 managed agents, ongoing tuning, priority support, monthly finance review | Default first paid customer package where the PoV proves recurring value |
| **Enterprise** | **From CHF 10,000/month**, annual agreement; implementation and savings-share custom | Multi-team scope, SSO/SCIM, retention/data-residency, self-hosted/dedicated option, named support/SLA | Regulated, multi-unit, or large-fleet rollout |

For the founding partner, a pure 10% verified-savings share for the first agreed measurement year is an acceptable alternative **only if** a savings cap, quarterly acceptance cadence, workload-change rule, and signer are written into the agreement. Do not stack a 10% share with Standard’s 5% share; select one commercial model.

### Negotiation rules

- Lead with **10% of verified savings** to establish a value-based reference point; then present Standard as predictable operating capacity plus a smaller 5% performance share.
- Hold the CHF 2,500/month floor. Trade only for a 12-month term, a named reference/case-study right subject to approval, multi-team expansion, or annual prepayment—not for vague future potential.
- Calculate the share quarterly from customer-accepted net savings; attach the evidence statement and pricing version to every invoice.
- Cap savings-share exposure before signature. If the customer needs a cap, lower the percentage only in exchange for a higher platform fee or term commitment.
- Never guarantee an 80% outcome. Promise the measurement method, quality gate, weekly transparency, and exit right.
- If savings are lower than expected but quality passes, propose Foundation rather than extending the free PoV. If quality fails, remediate once or exit.

## 5. Delivery, service commitments, and exit

### What the customer receives

- `scripts/pilot-setup.sh` (referred to commercially as `pilot-setup.sh`) and a documented uninstall path.
- Pilot charter, baseline definition, security/configuration record, and named technical owner.
- Weekly one-page stakeholder reports and underlying aggregate evidence artifacts.
- Final HTML evidence report, source-data fingerprint, methodology, limitations, and conversion recommendation.
- Named Slack/Teams shared channel with business-hours support; severity route for pilot-blocking issues.
- On conversion: the agreed LeanCTX deployment/profile, monthly evidence review, and support scope for the chosen tier.

### Pilot service commitments

| Commitment | Standard | Remedy if missed |
|---|---|---|
| Context quality | At least the pre-agreed baseline on the agreed scoring method | Pause treatment, restore safe profile/baseline, investigate; affected savings are not claimed |
| Evidence integrity | Matched baseline/treatment, declared assumptions, net/bounce-adjusted savings, and reproducible final artifact | Correct report before commercial discussion; do not invoice disputed numbers |
| Weekly reporting | Delivered on the agreed weekday to named stakeholders | Send within one business day with a written explanation |
| Support | Business-hours response in the shared channel; acknowledge a pilot-blocking incident within one business day | Prioritise rollback or safe configuration; extend only the affected measurement window if both parties agree |
| Security posture | Local/loopback proxy by default, approved integrations only, customer-controlled provider credentials | Disable/revert the component and follow the customer incident process |

### Exit clause — put this verbatim in the PoV agreement

> Either party may end the proof-of-value on written notice. On expiry or termination, Thinkery will disable/remove its pilot configuration on request and provide the final aggregate evidence package. The customer retains its reports, accepted evidence data, and exported aggregate metrics. No production commitment, automatic renewal, exclusivity, or minimum spend arises from the proof-of-value. Thinkery may not use customer-identifying results as a reference without written approval. Customer prompts, source code, credentials, and raw usage data are not retained beyond the agreed purpose and retention period.

### Pre-send checklist

- [ ] Named CTO/VP Engineering sponsor and finance validator
- [ ] Single workflow, baseline, quality score, and success rule written down
- [ ] Day-30 evidence/conversion meeting booked
- [ ] One-pager attached; benchmark worded as a defined reference result, not a guarantee
- [ ] Security/proxy/BYOK design approved for the customer’s environment
- [ ] Minimum price, savings-share method, cap, currency, VAT treatment, and signer identified
- [ ] Exit, uninstall, evidence-data ownership, retention, and case-study rights accepted
