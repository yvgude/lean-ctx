# A2 — Repository and Infrastructure Landscape

**Scope.** Local repository state inspected 2026-08-19. This report distinguishes evidence in the checked-out Git data from inference about external systems. No remotes were fetched, so a remote branch absent from the local ref cache is reported as *not locally observed*, not as proof it does not exist.

## 1. System topology

```text
                   public OSS distribution
GitHub yvgude/lean-ctx ── main ── GitHub Actions ── releases / crates.io / npm / Homebrew / VS Code
         │                         │
         │                         └── AUR submodule points at aur.archlinux.org/lean-ctx-bin
         │
         └── source-level guard prevents private deployment and commercial code entering public tree

GitLab origin (private) ── deploy worktree/branch ── GitLab CI ── Docker/Coolify/Traefik
                                                          ├── leanctx.com static Astro site
                                                          └── api.leanctx.com cloud API + PostgreSQL

Private implementation boundary ── lean-ctx-cloud / lean-ctx-enterprise
```

The code and policies deliberately separate a public local engine from private deployment/commercial planes. `.github-ignore` and the GitHub security workflow block cloud infrastructure, website, host runbooks, billing, license issuance, and other proprietary paths from the public repository.

## 2. Git remotes and worktrees

| Remote / worktree | Local URL and observed state | Purpose supported by repository evidence |
|---|---|---|
| `github` | `git@github.com:yvgude/lean-ctx.git`; `main` tracks `github/main`, currently at `324e9ad9`. | Canonical public OSS repository and release source. All GitHub Actions, GitHub Releases, public package publishing, and public-tree guards target this plane. |
| `origin` | Self-hosted GitLab: `gitlab.pounce.ch/root/lean-ctx.git`; locally cached `origin/main` is `93f89d97`, behind the current GitHub main. | Private GitLab mirror/operations plane. The deploy branch's `.gitlab-ci.yml` deploys the private website/cloud stack. `origin/deploy` is **not** present in local remote refs and the local `deploy` branch has no configured upstream, so the exact current GitLab branch state cannot be proven from this clone. |
| `cedric013` | `https://github.com/cedric013/lean-ctx.git`; no configured local branch upstream. Cached contributor branches include fixes for MCP secret mementos, agent episodes, adaptive indexing, flaky tests, and pack setup. | Contributor/fork remote used to inspect or integrate Cedric's proposed work; not a release or deployment remote. |
| Other cached forks | `andig` and `ousatov-ua` refs are cached, but no corresponding configured remote URL is present in `.git/config`. | Historical/review refs only in this clone. |
| main worktree | `/Users/yvesgugger/Documents/Privat/Projects/lean-ctx`, `main`. | Public-engine working tree. |
| deploy worktree | `/Users/yvesgugger/Documents/Privat/Projects/lean-ctx-deploy`, `deploy` at `4839369c`. | Separate deployment/product worktree; prevents the deployed web/cloud files from polluting the public OSS checkout. |

## 3. Branch landscape

| Branch | Tracking / relation | Purpose |
|---|---|---|
| `main` | Tracks `github/main`; current public head `324e9ad9`. | Public OSS engine, SDKs, package sources, GitHub CI and tagged-release pipeline. |
| `deploy` | Checked out in its own worktree; no configured upstream. Its head is `deploy: v3.9.19`. Diverged substantially from `main`. | Private deployment branch. It contains the Astro website, GitLab CI, cloud API deployment scripts, Dockerfiles, account/billing/cloud UI, and operational files excluded from the GitHub tree. GitLab CI runs its deploy jobs only for a branch named `deploy`. |
| `enterprise/intelligence-layer` | Local only; no upstream. It is exactly the same commit as local `feat/intelligence-layer` (`faebc0cb`). | Private/commercial intelligence-layer development line. OSS stubs explicitly direct full implementations to `lean-ctx-enterprise/crates/intelligence/` and identify `enterprise/intelligence-layer` as the implementation branch. |
| `feat/intelligence-layer`, `feat/oss-intelligence-layer`, `feat/solution-intelligence` | Local feature branches; only `feat/intelligence-layer` and `feat/oss-intelligence-layer` have GitHub upstream configuration. | Development branches around the intelligence/control-plane split. They are not deployment or release branches. |

The documented branch-hygiene rule matches this architecture: GitHub should retain only `main`, `cla-signatures`, and at most one active PR branch per agent. The currently cached GitHub refs also include open fix/feature/dependabot branches.

## 4. GitHub Actions: complete workflow inventory

All 17 workflows live under `.github/workflows/` on `main`.

| Workflow | Trigger | What it validates or does |
|---|---|---|
| `ci.yml` — **CI** | Push/PR to `main`; manual | Full quality gate; detailed below. |
| `security-check.yml` — **Security Check** | Push/PR to `main` | Audited-history delta evidence, unsafe/dependency/shell-risk scans, public/proprietary and commercial-plane boundary enforcement, critical-file notice, and `cargo audit`. |
| `codeql.yml` — **CodeQL** | Push/PR to `main`; Mondays 05:30 UTC | GitHub CodeQL analysis, including a dedicated Rust build/analysis leg. |
| `secret-rotation-check.yml` | First of each month, 05:00 UTC; manual | Checks secret-expiry policy, uploads a rotation report, and writes a job summary. |
| `history-audit.yml` | Mondays 04:00 UTC; manual | Runs a full repository-history audit, uploads its report, and fails on new findings. |
| `addon-versions.yml` | Mondays 06:00 UTC; manual; limited PR paths | Resolves grammar-addon registry pins against upstream versions. |
| `grammar-addons.yml` | Manual | Discovers grammar crates, cross-builds their dynamic libraries, hashes them, derives ABI versions, uploads them to a rolling release, regenerates the registry, and opens/updates a PR. |
| `go-conformance.yml` | Changes to `go-sdk/**` or the OCLA wire schema; push/PR | Runs Go SDK protocol-conformance tests. |
| `benchmark-study.yml` | Manual, with suite/arm/model/repeat inputs | Builds the engine, executes requested HumanEval/MBPP/SWE-bench study arms, uploads a report, and applies a quality gate. |
| `dep-update.yml` | Manual | Performs compatible patch/minor Rust dependency updates, smoke-verifies default features, and creates or updates a PR. |
| `cla.yml` | New issue comments; PR-target events | Runs the CLA assistant. `pull_request_target` means this workflow is security-sensitive. |
| `issue-reopen.yml` | New issue comments | Implements the issue-reopen command. |
| `jetbrains-plugin.yml` | Push/PR to `main` when JetBrains plugin files change | Runs actionlint, Gradle wrapper validation, Java/Gradle build, tests, and test-result collection. |
| `publish-vscode.yml` | `vscode-v*` tags; manual | Installs/compiles/packages the VSIX, publishes to VS Code Marketplace and Open VSX, uploads the VSIX, and attaches it to the GitHub release. |
| `publish-sdk.yml` | `sdk-v[0-9]*` tags; manual target selection | Builds/tests/publishes the SDK to npm and/or PyPI. |
| `publish-clients.yml` | `client-v[0-9]*` tags; manual target selection | Builds/tests/publishes `/v1` clients to npm, PyPI, and/or crates.io. |
| `release.yml` — **Release** | `v[0-9]*` tags | Produces and signs the engine release; publishes core packages; updates Homebrew; announces release. Detailed below. |

### `ci.yml`: required build and test matrix

`ci.yml` has concurrency cancellation for superseded non-`main` runs, read-only contents permission, and disables automatic embedding-model downloads to keep tests hermetic. PR test matrices run Ubuntu and Windows; pushes to `main`, manual runs, and release coverage include macOS.

| Job | Coverage |
|---|---|
| `test` | `cargo test --all-features` on Ubuntu/macOS/Windows; Windows uses MSYS2 + GNU target + jemalloc workaround, Linux uses `mold`; Linux additionally runs serialized wall-clock regression gates for incremental rebuild, context-kernel, and performance stress. |
| `clippy` | `cargo clippy --all-features -D warnings` plus the Rust file-size/LOC budget gate. |
| `build-minimal` | Two reduced-feature builds: no ORT/embeddings and no Tree-sitter, protecting community/slim builds. |
| `fmt` | `cargo fmt --check`. |
| `cookbook` | Node 20 `npm ci`, lint, typecheck, test, and build. |
| `pi-extension` | Checks package-to-engine version coupling, then Node 22 typecheck/tests for `pi-lean-ctx`. |
| `rust-sdk` | Formats, lints, tests, and documents `clients/rust/lean-ctx-client`. |
| `embed-sdk` | Formats, pedantic-lints, tests/doctests, builds example, and docs `lean-ctx-sdk`; it is deliberately excluded from the default Rust workspace members. |
| `python-sdk` | Installs and pytest-tests `clients/python` (`lean-ctx-client`). |
| `hermes-plugin` | Python plugin tests plus an offline benchmark smoke using an unreachable daemon endpoint to exercise local fallback. |
| `sdk-conformance` | Runs all first-party SDKs against a real engine and uploads the generated conformance matrix. |
| `coverage` | LLVM `cargo-tarpaulin` all-feature coverage and Codecov upload. |
| `deny` | Runs `cargo-deny`. |
| `adversarial` | Runs adversarial compression/safety tests. |
| `bench` | Compiles benchmarks, creates a reproducible scorecard, and uploads it. |
| `quality-gate` | Builds the tool, checks self-footprint/doctor overhead, runs deterministic A/B output-quality and testbench gates, verifies signature/determinism, and uploads reports. |
| `doc` | Rust docs with warnings denied; checks generated reference docs, registry snapshots, and recorded testbench fixtures are current. |
| `ci-green` | `always()` aggregate: fails if any required job failed. |

## 5. GitLab CI and the deploy branch

`main` does not contain a tracked `.gitlab-ci.yml`; the public-tree policy forbids it. The file exists in `deploy` and contains two stages:

1. `website_build` (`test`, Node 22.12): `npm ci`, `npm run validate`, and `npm run build` in `website/`; it caches the npm cache by branch slug.
2. `deploy_website` (`deploy`, Docker 24, `only: [deploy]`): builds the website image from source, asserts generated site/dependency directories are not tracked, replaces `leanctx-web` on Docker network `coolify`, and prints its container status.
3. `deploy_cloud_api` (`deploy`, Docker 24, `only: [deploy]`): invokes `cloud-infra/deploy-cloud-api.sh`.

The GitLab website job does a replacement plus `docker ps` check; it does **not** use the more robust `website/deploy-web.sh` health-gated rollback helper. The cloud API helper does preserve an environment allowlist from the prior container or first-deploy env file, builds a new image, probes `/health` for up to 15 seconds, and restores the backup image on failure.

## 6. Website and cloud hosting

### Domains and content

- The canonical configured site is **`https://leanctx.com`**. No tracked `leanctx.dev` deployment reference was found.
- The API endpoint is **`https://api.leanctx.com`**; account, team, billing, cloud, leaderboard, and join flows call it from the website.
- The `deploy` website is an Astro 6 static site with Tailwind, sitemap generation, Pagefind search, validation scripts, generated tool docs, AI/MCP discovery files (`.well-known/mcp.json`, `ai.txt`, `llms.txt`), and 18 locales (English plus 17 translations).
- Content includes product/architecture/docs, integrations, pricing, enterprise/security, customer stories, benchmarks, and logged-in account/billing/cloud/team pages. This makes it both marketing/documentation site and frontend for the private cloud control plane.

### Runtime topology

```text
Internet
  └─ Traefik (shared `coolify` Docker network)
       ├─ leanctx.com      → leanctx-web:80        (Astro static files served by nginx)
       └─ api.leanctx.com  → lean-ctx-cloud-api:8088 (Rust cloud API)
                                      └─ PostgreSQL cloud database
```

The deployment runbook identifies a separate server-side checkout named `lean-ctx-cloud`; this clone does not configure a remote for that repository, so its canonical Git URL and current branch cannot be established here.

## 7. Docker/container strategy

No Dockerfile or compose file is tracked on public `main`. `deploy` tracks four Dockerfiles; a `docker-compose.yml` is explicitly private/ignored.

| Image | Build/runtime | Role and deployment state |
|---|---|---|
| `website/Dockerfile` | Multi-stage: Node 22.12 Alpine runs `npm ci` and Astro build; nginx Alpine serves `/app/dist`. | CI deploys it as `leanctx-web` on `coolify`; Traefik is the external proxy. `deploy-web.sh` offers image backup plus HTTP health-gated rollback. |
| `cloud-infra/Dockerfile.cloud-api` | Rust 1 Bookworm build of `lean-ctx-cloud-api` with `cloud-server`; Debian Bookworm Slim runtime, port 8088. | Deployed as `lean-ctx-cloud-api`; runtime configuration is inherited via `LEANCTX_CLOUD_*`, `DATABASE_URL`, and `JWT_SECRET` allowlist, avoiding credentials in the script. |
| `stats-api/Dockerfile` | Node 22 Alpine, production `npm install`, port 3099. | Statistics/leaderboard-oriented API service. No active GitLab deployment job was found for it. |
| `discord-bot/Dockerfile` | Python 3.13 Slim plus `requirements.txt`. | Discord bot container. No active GitLab deployment job was found for it. |

## 8. Private related repositories and boundaries

### `lean-ctx-cloud`

Evidence describes this as the private commercial/control-plane repository:

- `.github-ignore` says billing and license issuance belong there; public OSS only emits the signed savings ledger.
- The GitHub security workflow fails if success-fee invoicing, Stripe, license issuance, cloud directories, or private operational files enter the OSS tree.
- Tests and demonstration scripts state that this control plane consumes verified savings totals to create Stripe success-fee invoices.
- The deploy worktree contains a Rust `lean-ctx-cloud-api` binary with cloud-server feature, Docker deploy script, private site account/billing/cloud pages, PostgreSQL-dependent services, and a server checkout called `lean-ctx-cloud`.

The relationship is therefore strong, but this clone has no `lean-ctx-cloud` remote configured; code/release state of that separate repository is unknown.

### `lean-ctx-enterprise`

Evidence describes a separate private GitLab-only enterprise implementation:

- The pre-push proprietary guard tells contributors that private team-auth logic belongs in `lean-ctx-enterprise`.
- `rust/src/core/solution_commercial.rs` is intentionally an OSS stub and says full implementations live under `lean-ctx-enterprise/crates/intelligence/`.
- Commercial APIs in the OSS tree return an enterprise-license error for adaptive intensity, fingerprints, team policy, cross-project patterns, verified attribution, and audit trail features.
- The default enterprise gateway is `https://api.leanctx.com/v1`; the local `enterprise/intelligence-layer` branch is the matching implementation line but has no remote tracking configuration here.

Neither private repo should be inferred to be public merely because its names appear in the OSS repository; the public build policy also rejects private GitLab URLs/imports.

## 9. Package and client distribution

| Channel | Packages / mechanism | Release path |
|---|---|---|
| GitHub Releases | Native binary archives for Linux GNU, Linux musl, Linux CUDA, macOS x86_64/aarch64, Windows MSVC/GNU; source tarball. | Engine `v[0-9]*` tags. |
| crates.io | `lean-ctx` 3.9.19; release workflow publishes workspace dependencies `lean-ctx-ocla` 1.0.0 and `lean-ctx-protocol` 0.1.0 first, then the engine. `lean-ctx-sdk` Rust crate is explicitly `publish = false`; Rust `lean-ctx-client` 0.2.0 has its own `client-v*` workflow route. | `release.yml` / `publish-clients.yml`. |
| npm | `lean-ctx-bin` 3.9.19 (launcher/downloader for the native binary), `pi-lean-ctx` 3.9.19, plus independent `lean-ctx-sdk` 0.3.0 and `lean-ctx-client` 0.1.0. The OCLA TypeScript package is `@lean-ctx/ocla-sdk` 0.1.0. | Engine release publishes the first two; `sdk-v*` and `client-v*` workflows publish the latter SDK/client packages. |
| PyPI | `lean-ctx-sdk` 0.3.0 and `lean-ctx-client` 0.1.0 are wired to SDK/client publish workflows. `leanctx` 0.1.0 and `lean-ctx-ocla` 0.1.0 also have package manifests, but no corresponding active publishing workflow was found. | `sdk-v*` / `client-v*` for the first two. |
| Homebrew | External `yvgude/homebrew-lean-ctx` tap receives a generated binary formula from release checksums. Formula depends on `onnxruntime`. | Engine release, non-RC only. |
| VS Code / Open VSX | `vscode-v*` publishes the VSIX to both registries and attaches it to the GitHub Release. | Dedicated workflow. |
| JetBrains | Gradle plugin is tested on source changes and its ZIP is attached to non-RC engine GitHub releases. | Engine release, non-RC only. |
| AUR | `lean-ctx-bin` package pulls trusted prebuilt x86_64/aarch64 GNU/Linux archives from GitHub Releases and depends on `onnxruntime`. | Manual/versioned submodule update; not an observed job in `release.yml`. |

Current local tags include engine `v3.9.19` down through earlier versions and `vscode-v0.1.0`/`vscode-v0.2.0`. No `client-v*` or `sdk-v*` tags are present locally, although their workflows are configured.

## 10. Engine release process

1. Create and push a `v[0-9]*` tag with versions already aligned (the `sdk-gate` checks SDK and npm package/engine coupling).
2. Build/test locked production binaries for nine targets: Linux GNU x86_64, CUDA x86_64, GNU aarch64, musl x86_64/aarch64, macOS x86_64/aarch64, and Windows MSVC/GNU. Cross/musl/zig and Windows jemalloc specifics are handled in the matrix.
3. Package archives, create a source tarball, generate `SHA256SUMS`, cosign-sign the checksum file using GitHub OIDC, generate an SBOM and a release manifest, extract notes from `CHANGELOG.md`, and create the GitHub Release.
4. For non-RC tags: attach the JetBrains plugin, publish crates.io and npm packages idempotently, generate/push the Homebrew formula, then announce through Twitter and an n8n-backed Discord webhook.

Release artifacts include checksums, `SHA256SUMS.sig`, the cosign certificate, `SBOM.txt`, and `release-manifest.json` in addition to binaries/source/plugin. The engine release notes advertise `lean-ctx update`, `cargo install lean-ctx`, `npm update -g lean-ctx-bin`, and `brew upgrade lean-ctx` as upgrade routes.

## 11. AUR submodule

`aur/lean-ctx-bin` is a real Git submodule, not a copied packaging directory:

- Parent gitlink: `12993b161b6a75963df380d5bc31d52555e46a0d`; checked out on `master` at `12993b1` (`fix: sync pkgver and checksums to 3.9.19`).
- Source remote: `ssh://aur@aur.archlinux.org/lean-ctx-bin.git`.
- Its `PKGBUILD` defines Arch package `lean-ctx-bin` 3.9.19, provides/conflicts with `lean-ctx`, pulls the two GitHub Release Linux binaries, verifies their SHA-256 values, and installs `lean-ctx` to `/usr/bin`.
- It depends on `gcc-libs` and `onnxruntime`; semantic search dynamically loads ONNX Runtime. Updating it is a separate AUR Git commit, followed by an updated gitlink in the parent repository.

## 12. Security and operational findings

1. **Plaintext production credentials were found in the private deploy worktree's `server.md`.** They include database, SMTP, and JWT material. Values are intentionally omitted from this report. Treat them as exposed: rotate/revoke them, remove the file from reachable history where feasible, and replace it with a redacted runbook plus a secret-manager reference. `.github-ignore` correctly blocks this file from public GitHub, but that does not make plaintext secrets in a private checkout safe.
2. The OSS/private boundary is unusually well defended in automation: local pre-push guard, GitHub path checks, a commercial-plane check, history-delta evidence, and a clean-room public-build policy. Keep GitLab CI, cloud scripts, site source, and host docs out of `main`.
3. `deploy` and `enterprise/intelligence-layer` are important local branches with no configured upstream. Before relying on CI/CD or collaboration, explicitly verify their intended remote/upstream and protection settings; local Git state alone cannot establish them.
4. Website deployment in GitLab has weaker rollback verification than the checked-in `deploy-web.sh`; consider invoking the health-gated helper or adding an equivalent HTTP probe/rollback to `.gitlab-ci.yml`.

## Evidence files

- Public-source boundaries: `.github-ignore`, `.github/workflows/security-check.yml`, `.github/hooks/pre-push-proprietary-guard.sh`.
- Release/publishing: `.github/workflows/release.yml`, `publish-sdk.yml`, `publish-clients.yml`, `publish-vscode.yml`.
- Private deployment: `deploy:.gitlab-ci.yml`, `deploy:website/{Dockerfile,deploy-web.sh,package.json}`, `deploy:cloud-infra/{Dockerfile.cloud-api,deploy-cloud-api.sh}`.
- Packaging: `rust/Cargo.toml`, `packages/*/package.json`, `clients/python/pyproject.toml`, `.gitmodules`, and `aur/lean-ctx-bin/PKGBUILD`.
