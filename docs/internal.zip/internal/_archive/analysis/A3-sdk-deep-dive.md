# A3 — SDK deep dive

## Bottom line

The repository has three different SDK families:

1. Rust lean-ctx-sdk: an in-process façade over the real engine and registry.
2. Python/Node lean-ctx-sdk: daemon HTTP clients for POST /v1/compress plus CLI/framework adapters.
3. OCLA and general HTTP /v1 clients: control-plane, event, and tool-protocol SDKs.

They are implemented in substantial part but are not one ctx.wrap(agent) product. The provider proxy is the closest existing transparent agent wrapper.

## Rust embedding SDK: rust/crates/lean-ctx-sdk

### State, runtime relationship, and validation

- Real implementation, not a scaffold. Cargo package is 0.1.0 but publish=false, so it is currently a workspace/path-dependency artifact.
- Build creates the production ToolRegistry with build_registry(), shared Arc<RwLock<SessionCache>>, shared Arc<RwLock<SessionState>>, and a multithread Tokio runtime. Calls construct the normal ToolContext and execute real handlers on spawn_blocking.
- The shared cache gives the intended read -> unchanged re-read delta.
- Safe defaults: canonical PathJail root, temp-scoped state (unless data_dir is set), update checks disabled, no engine jemalloc feature. Writes and commands require an explicit builder opt-in.
- Synchronous API only. Calling it within a Tokio runtime worker is unsupported; async hosts must use tokio::task::spawn_blocking.
- I ran cargo test -p lean-ctx-sdk. It is not green: integration test search_finds_symbol fails. read_then_reread_is_cheaper passes. The crate is implemented but currently has a known failing acceptance surface.

### Public API, complete

src/lib.rs exposes public modules addon, compress, engine, error, hash, output, read, tokens; re-exports Engine, EngineBuilder, Error, Output, ReadMode; and provides VERSION.

EngineBuilder is created with Engine::builder(project_root); its constructor is private.

| API | Public behavior |
|---|---|
| data_dir(dir) -> Self | Use explicit data/config/state/cache directory; can share memory with CLI/MCP. |
| allow_write(bool) -> Self | Enables ctx_edit and ctx_fill through Engine::call. |
| allow_exec(bool) -> Self | Enables ctx_shell, ctx_execute, and shell through Engine::call. |
| worker_threads(usize) -> Self | Tokio worker count, min one, default two. |
| build() -> Result<Engine, Error> | Canonicalizes/validates root; configures process state once; creates cache/session/runtime/registry. |

| Engine API | Runtime route |
|---|---|
| builder(project_root) -> EngineBuilder | Start safe engine configuration. |
| project_root() -> &str | Canonical jail root. |
| read(path, ReadMode) -> Result<Output, Error> | ctx_read, with jailed resolved path. |
| search(pattern, subdir) -> Result<String, Error> | ctx_search, optional jailed scope. |
| symbol(name) -> Result<String, Error> | ctx_symbol. |
| outline(path) -> Result<String, Error> | ctx_outline, jailed. |
| tree(subdir) -> Result<String, Error> | ctx_tree, optional jailed scope. |
| call(tool, serde_json::Map<String, Value>) -> Result<Output, Error> | Escape hatch for every registered tool; string path is jailed; write/exec gates applied. |

The RFC maps all other Lean-md requirements to call(): ctx_glob/repomap, cost, graph/callgraph/impact, architecture, smells, refactor, review, knowledge, semantic search, compose/overview, tool inspection, routes, and the gated mutating/command tools.

ReadMode is non_exhaustive, default Auto, and has Auto, Full, Raw, Signatures, Map, Diff, Reference, Task, and Lines { start: u32, end: u32 }; Lines is a one-based inclusive window.

Output is cloneable and has public text, original_tokens, saved_tokens, mode: Option<String>, plus saved_pct() clamped to 0..100.

Error is non_exhaustive: UnknownTool(String), Path(String), Init(String), Tool { tool, message }, NotPermitted(String), and Incomplete(String).

### Stateless public helpers

| Module | Public API | Real backing implementation |
|---|---|---|
| compress | shell_output(command, output) -> Option<String>; shell_output_or_passthrough(...) -> String | Proxy/ctx_shell pattern compressor. None means protected/no beneficial compression. |
| tokens | count(text) -> usize | Engine tokenizer. |
| hash | blake3_hex(&[u8]); blake3_str(&str) | Engine canonical BLAKE3. |

### Addon public API

Enums: Transport { Stdio, Http }, Severity { Info, Warn, Danger }, Verdict { Pass, Review, Fail }.

Structs: Finding { severity, code, message }; Audit { verdict, findings, capability_coherent, binary_pinned, paid_eligible }.

Functions:

- scaffold(slug, Transport) -> String: ready-to-edit addon manifest TOML.
- slugify(name) -> Option<String>: normalizes to [a-z0-9-].
- audit(manifest_toml) -> Result<Audit, String>: production manifest/schema/capability/malware audit.

Tests prove successful scaffold audit, malicious curl-pipe-shell rejection, invalid-manifest failure, and slug normalization.

### Every SDK crate file read

| File | Role |
|---|---|
| Cargo.toml | Workspace-only façade package; engine path dependency with tree-sitter, embeddings, HTTP-server, secure-update; default jemalloc omitted. |
| README.md | Embedding surface, safety, build and async caveat. |
| src/lib.rs | Stable public contract/exports. |
| src/engine.rs | Builder, shared state, registry dispatch, PathJail and permission gate. |
| src/read.rs | Stable engine mode mirror. |
| src/output.rs | Stable tool result/token accounting type. |
| src/error.rs | Stable public errors over internal rmcp errors. |
| src/compress.rs, hash.rs, tokens.rs | Thin wrappers over real production utilities. |
| src/addon.rs | Stable addon type mappings plus scaffold/audit. |
| examples/embed.rs | Shared-cache read/re-read, helpers, addon audit demo. |
| tests/engine_read.rs | Read cache, jail, search, permission, unknown-tool acceptance tests. |

## Embedding RFC and docs

- docs/rfcs/sdk-embedding-v1.md: accepted; increment 1 implemented. Its goals are a small stable façade, shared session cache, safety-by-default, and registry parity. Explicit non-goals: async API, global configuration mutations, minimal-feature engine build. External Lean-md port is the real acceptance test.
- docs/guides/embed-sdk.md: operative embedding guide. It clearly distinguishes in-process embedding, distributable Addons, and HTTP compression clients.
- docs/guides/extensions.md supports that mechanism split.

## Python SDK surfaces

### packages/python-lean-ctx: compression client and adapters

State: implemented, dependency-free HTTP transport documented as pip install lean-ctx-sdk (Python >=3.9, MIT). Tests use a loopback stand-in, not a live daemon.

Public proxy API:

- compress(messages, model=None, *, base_url=None, token=None, timeout=30) -> rewritten messages.
- ProxyClient(base_url=None, token=None, timeout=30):
  - compress(messages, model=None) -> CompressResult
  - resolve_reference(reference_id) -> str via GET /v1/references/{id}
- CompressResult: messages, stats; properties original_tokens, compressed_tokens, saved_tokens, saved_pct.
- discovery: resolve_port(), resolve_base_url(), resolve_token().
- errors: LeanCtxError, LeanCtxConnectionError, LeanCtxAuthError.

It POSTs message arrays to /v1/compress. Discovery precedence is explicit value, environment, config/data directories, then UID-derived loopback port. Unlike the Node client, this Python discovery code does not reject use of a disk session token for a non-loopback base URL; that policy mismatch is a security and behavior inconsistency.

CLI surface: LeanCtxClient(binary='lean-ctx', project_root=None) invokes the binary and offers read, search, shell, gain, benchmark. It is a CLI wrapper, not embedded runtime access.

Framework surfaces:

- LiteLLM: compress_request_data(...) mutates an OpenAI request's messages; default failure behavior preserves original messages. LeanCtxLiteLLMHandler uses the optional CustomLogger async_pre_call_hook and ImportErrors when LiteLLM is unavailable.
- LangChain: compress_messages(messages, model, **proxy_options) converts to OpenAI form, compresses, then Pydantic-copies only content back. It returns originals on cardinality/copy ambiguity. Optional LeanCtxRetriever parses CLI search output.
- LlamaIndex: optional LeanCtxNodeParser calls CLI read(mode) for file-backed documents.

### Other Python trees: overlapping protocol clients

| Directory | Package and API | State |
|---|---|---|
| py-sdk | leanctx 0.1 synchronous httpx OCLA client. Tests show LeanCtxClient.health, envelope, ledger_summary. | Early/minimal OCLA duplicate. |
| python-sdk | lean-ctx-ocla 0.1 async Pydantic/httpx OclaClient: health, capabilities, validate_envelope, register/resolve/fork capsule, ledger_summary, SSE envelopes. | Implemented typed OCLA client. |
| clients/python | lean-ctx-client, dependency-free general /v1 client. | Most mature general Python client. |

clients/python exposes health, manifest, capabilities, openapi, list_tools, call_tool, call_tool_text, subscribe_events, context_summary, search_events, event_lineage, metrics, cache_stats; it has LeanCtxConfigError, LeanCtxTransportError, structured LeanCtxHTTPError, and run_conformance(). Its route-coverage gate compares server OpenAPI against client methods and supports HTTP-MCP contract version 1.

The conformance matrix claims Python 14/14 pass but assigns Level 1 schema-valid certification, not verifier-grade. Four Python package identities (leanctx, lean-ctx-ocla, lean-ctx-client, lean-ctx-sdk) make selection unclear.

## TypeScript SDK surfaces

### packages/node-lean-ctx: npm lean-ctx-sdk 0.3.0

State: implemented daemon client/adapters, MIT. ai >=3 is optional peer dependency; tests cover discovery, proxy transport and Vercel behavior against a loopback server.

Public exports:

- LeanCtxClient and LeanCtxOptions: safe execFileSync CLI wrapper; read, search, shell, gain, benchmark.
- ProxyClient and compress; types Message, CompressStats, CompressResult, ProxyClientOptions, CompressOptions.
- LeanCtxError, LeanCtxConnectionError, LeanCtxAuthError.
- createLeanCtxTool, leanCtxMiddleware, withLeanCtx, LeanCtxLanguageModelMiddleware.

ProxyClient calls POST /v1/compress and GET /v1/references/{id}. It validates port values, aborts via AbortController, and never sends an on-disk session token to a non-loopback URL.

Vercel integration:

- createLeanCtxTool() returns AI SDK JSON-schema search tool with query and optional path.
- leanCtxMiddleware() implements transformParams, compresses only array params.prompt, and fails open for known LeanCtx failures.
- withLeanCtx(model) dynamically requires ai then calls wrapLanguageModel. In this ESM package the CommonJS require is a deployment fragility; manual wrapLanguageModel plus leanCtxMiddleware is safer.

### ts-sdk: @lean-ctx/ocla-sdk 0.1.0

State: standalone Apache-2.0 OCLA wire client, separate from compress() despite the same repository.

OclaClient(baseUrl, apiKey='') has health, capabilities, validateEnvelope, registerCapsule, resolveCapsule, forkCapsule, ledgerSummary and async streamEnvelopes. It uses fetch, optional bearer auth, normalized base URL, structured non-2xx error text and multiline SSE parsing.

Its exported types cover capability discovery, request context, four-stage token balance, canonical and agent envelopes, messages/stream/tool/usage payloads, context plans/receipts/policies and attribution. Tests cover all endpoints and SSE.

cookbook/sdk is a client/types/tool-text/conformance mirror, not a separately publishable SDK. VSCode and Pi TypeScript trees are consumers/integrations rather than standalone SDKs. Having npm lean-ctx-sdk for compression and @lean-ctx/ocla-sdk for OCLA is functionally understandable but hard to discover.

## Requested wrappers

### Vercel AI SDK

Implemented in packages/node-lean-ctx/src/vercel-ai.ts. Tests prove prompt replacement, non-array passthrough and proxy-down fail-open handling.

### LiteLLM

Two working paths:

1. Python LeanCtxLiteLLMHandler / compress_request_data.
2. Sidecar configuration using LiteLLM's headroom prompt-compression guardrail.

The daemon's /v1/compress returns messages plus tokens_before, tokens_after and compression_ratio (LiteLLM aliases). Lossy output contains hash=<24 hex>; LiteLLM CCR can GET /v1/retrieve/{hash} and receives original_content.

### LangChain

Only a Python helper and optional retriever exist; there is no automatic callback/middleware package that wraps every model call. The helper is intentionally metadata-safe and fail-open.

## Proxy: the implicit SDK

The proxy is the strongest existing transparent wrapping surface. It routes OpenAI chat/responses, Anthropic messages, ChatGPT/Codex, Gemini/universal providers and MCP reverse proxies. Provider handlers use forward::forward_request with provider-specific compress_request_body functions.

Those handlers can preserve cached prefixes/live zones, prune old history cache-safely, compress tool-result text with task-aware policy, leave ctx_* output/images/tool blocks untouched, apply optional prose/effort/verbosity controls, support in-band CCR recovery, measure provider use, and live-reload upstream settings.

POST /v1/compress is a separate pure message transformation:

- accepts OpenAI string content and Anthropic text/tool_result blocks;
- only transforms text; preserves images/tool_use/IDs/non-text fields;
- uses model-aware token counting and structured stats;
- is deterministic and footer-free, preserving provider-cache eligibility;
- supports /v1/references/{id} and LiteLLM CCR /v1/retrieve/{hash};
- runs behind standard proxy bearer auth. The proxy never starts unauthenticated; non-loopback gateway mode mandates bearer auth.

Therefore provider-base-URL configuration is currently the closest real ctx.wrap(agent): point an agent at the proxy and normal provider calls are intercepted without client-by-client changes.

## lean-ctx-protocol contracts

State: 0.1.0 Apache-2.0 serde wire-contract crate with only serde, serde_json and sha2; it is schema/domain logic, not an engine embedder or network client. cargo test -p lean-ctx-protocol exits successfully.

Shared constraints:

- V1 schema validation.
- Bounded opaque IDs: TaskId, TraceId, ProjectId, SessionId, AgentId, TenantId, PlanId, ReceiptId, OutcomeId, CapabilityId, DecisionId; 256 bytes max, nonempty, no controls.
- Milliunits constrained to 0..=1000; many records deny unknown fields, documented extension records retain extras.

| Family | Contracts |
|---|---|
| Capability discovery | CapabilityManifestV1, CapabilityKind, SurfaceSupportV1, measurement/determinism/reversibility/data-movement metadata. |
| Task and triage | TaskEnvelopeV1 with lineage validation; TaskProfileV1, TriageResultV1, complexity/risk/scope/backend. |
| Context routing | KnowledgeSourceManifestV1, SourceCapabilities, ContextCandidateV1, ContextBundleV1, ContextReceiptV1. |
| Planning/execution | ExecutionPlanV1, ContextBalanceV1, ExecutionReceiptV1, context strategy and stop conditions; monotonic accounting validation. |
| Evidence/decision/outcome | EvidenceRefV1, DecisionRecordV1, AcceptedOutcomeV1, signals; OutcomeEngineContract/LocalOutcomeEngine. |
| Knowledge provenance | KnowledgeObjectV1, source/authority/classification/validity metadata; supports legacy scalar metadata decoding. |
| Money/usage/savings | MoneyV1 exact coefficient/scale; UsageBreakdownV1; SavingsObservationV1 and SavingsReceiptV1::compute_from_arms. |
| Routing governance | AutoRoutingConfig/Request/Decision/Receipt, SchedulerGate, EligibilityPolicy, deterministic CircuitBreaker and SHA-256 RolloutConfig. |
| Control/fleet/value share | ControlPlaneContract, FleetControlContract, ValueShareContract and intentionally minimal local implementations. |
| Experiments/policy/gaps | ExperimentAssignmentV1, data/side-effect policy, PolicyClassification, append-only EvidenceGapOpenedV1/EvidenceGapClosedV1. |

The deliberate boundary: proprietary learning, candidate ranking, calibration, billing and rollout intelligence stay outside. This crate transports and validates inputs/results rather than implementing that intelligence.

## What is missing for ctx.wrap(agent)

1. No one public wrapper owns provider transport, engine session/cache, tools, streaming, lifecycle, policy and receipt output. Rust wraps tools; proxy wraps provider HTTP; Python/Node rewrite messages.
2. No cross-language embedded-engine parity. Only Rust gets shared SessionCache and typed engine invocation.
3. Adapter coverage is uneven: Vercel middleware, LiteLLM callback/sidecar, LangChain helper/retriever. No common middleware interface.
4. No universal provider/tool streaming loop that preserves provider-specific tool calls, cache controls, trace IDs and CCR references.
5. Public models are fragmented: Engine Output, /v1/compress messages, generic /v1 tool results and OCLA envelopes have no stable shared AgentContext/receipt mapping.
6. Distribution/versioning is ambiguous: unpublished Rust crate; four Python packages; two differently named TypeScript SDKs.
7. Release readiness needs real-daemon cross-SDK tests; the Rust embedded SDK's symbol-search acceptance test is currently failing.

## Recommended target

Keep the proxy as the zero-code route, and add a shared contract shaped like:

    ctx.wrap(agent, { mode: proxy | embedded | sidecar, policy, session })
      -> provider/tool streaming preserved
      -> shared cache/context policy and reversible references
      -> normalized output, tokens/cost receipt and trace IDs

Rust can use Engine directly. Other languages need a versioned sidecar/HTTP transport with the same session and receipt semantics; framework adapters should bind this shared contract rather than maintain independent message rewrites.

