# LeanCTX Website and Public-Documentation Analysis

**Scope:** `main` public docs and messaging; `deploy` website branch; live
`leanctx.com`; GitHub releases and hosting configuration.  
**Snapshot:** 2026-08-19. `deploy` is commit `4839369` (`deploy: v3.9.19`,
2026-08-18); `main` is one day newer at `324e9ad`.

## Executive conclusion

LeanCTX has far more product substance than its current position communicates.
The site leads with a painful coding-agent symptom—"Your agents re-read
everything. Every single time."—and presents a context-engineering utility.
The public materials also call it an **AI Value Gate** and a **Cognitive Context
Layer**. Those are credible capability descriptions, but together they make the
product feel broad, operational, and difficult to adopt.

`LeanCTX — The Context SDK for AI Agents` is the better top-level position. It
states the category, identifies the buyer/user (agent builders as well as coding
agent users), and gives the existing `/v1`, Python, TypeScript, Rust, MCP, and
embedded-engine surfaces a coherent reason to exist. Compression, memory,
policy, and proof then become the differentiated capabilities of that SDK—not
four competing product identities.

The site should lead with a runnable integration, then progressively disclose
integration depth and evidence. Keep the existing coding-agent workflow as an
important "zero-code" integration, not the whole product story.

## What is deployed today

### Technical and hosting facts

| Area | Finding |
|---|---|
| Website implementation | `website/` is Astro 6 + Tailwind 4, with Pagefind search, an Astro sitemap, and a translation-driven component system. The home route renders `IndexPageV2` → `Home.astro`. |
| Scale | 464 Astro route files, 73 page-template files, and 18 configured locales. The large route count is mostly localized variants plus marketing, account, docs, and product pages. |
| Main navigation | Product; Use Cases; Docs; Pricing; Enterprise. Product links include How It Works, Architecture, Benchmark, Compatibility, Compare, Add-ons, Metrics, and Customer Stories. |
| Deployment | The `website/Dockerfile` builds static Astro output and serves it from nginx. No GitHub Pages site is configured: `GET /repos/yvgude/lean-ctx/pages` returns 404. |
| Custom domain | nginx explicitly redirects `leanctx.tech`, `www.leanctx.tech`, `www.leanctx.com`, and `lean-ctx.pounce.ch` to `https://leanctx.com`. Live `leanctx.com` resolves to `185.142.213.170` and responds as nginx, so this is a self-hosted/custom-domain deployment, not GitHub Pages. |
| Runtime additions | nginx proxies `/api/stats`, `/leaderboard`, and selected wrapped-card paths; it redirects `/install.sh` to GitHub `main`. |

The live home page matches the deploy branch: the hero, Cold-Start Tax,
capabilities, token-accounting, memory, traction, FAQ, and one-command install
sections are all visible.

### Current homepage message

The homepage says:

> **Your agents re-read everything. Every single time.**

Its supporting copy says 90% of prompts are wasted context and LeanCTX
compresses file reads, shell output, and search results. The story then flows as:

1. **Problem:** wasted tokens, blind spend, and lost session knowledge.
2. **Capabilities:** Read Compression, Shell Intelligence, Persistent Memory,
   Agent Coordination.
3. **Proof:** a signed savings ledger, installs, GitHub stars, and saved energy.
4. **Conversion:** GitHub/Discord CTA and an install CTA.

This is polished and concrete for someone already using Cursor/Claude/Codex as a
coding agent. It does not, however, immediately tell an application or agent
builder that LeanCTX can be imported, wrapped around a model, served over `/v1`,
or embedded into an agent runtime.

### Pricing that is already on the site

The deploy source defines Free, Pro ($9/month or $90/year), Team ($18/seat/month
or $180/year), and custom Enterprise. It also has a voluntary $5/month Supporter
offer and a 14-day Pro trial. The pricing page has tier cards, comparison,
assurances, a savings/ROI calculator, enterprise, and proof/pilot sections.

That ladder can remain. The page should first make the Local-Free Invariant
unmistakable: the local core/SDK is free forever; paid plans are for hosted sync,
team operation, support, and enterprise control—not for withholding essential
agent capability.

## Public-message audit

### README on `main`

The README opens with **"Control what your AI can see."** and labels LeanCTX an
**"AI Value Gate for AI Coding Agents."** It promises a local binary that
understands tasks, routes context, compresses it, and tracks cost/outcome. It
then explains five capabilities: Context Compression, Intelligent Triage,
Knowledge Routing, AI Value Gate, and Shadow Recommendations.

It has strong SDK material, but too late in the page: Python/TypeScript
`compress()` clients, Vercel AI SDK middleware/`withLeanCtx`, LiteLLM, LangChain,
and thin `/v1` clients appear after the CLI installation narrative. In other
words, the raw ingredients for "Context SDK" already exist but are subordinate
to the coding-agent product.

### VISION.md

The vision calls LeanCTX the **Cognitive Context Layer** and defines four
dimensions: compression, semantic routing, memory architecture, and quality
guardrails. Its strongest durable ideas are:

- context requires both compression of what fits and retrieval of what does not;
- code structure, not generic chunks, is the moat;
- local-first, portable knowledge, signed evidence, and model neutrality matter;
- the long-term product decides, remembers, guards, proves, and replays context.

This is excellent architecture/manifesto material. It is too conceptual for a
first-screen category label; use it as the source for the "How it works" and
"Evidence" narratives.

### ECOSYSTEM.md

ECOSYSTEM describes one product in three pillars:

| Pillar | Role |
|---|---|
| Engine | Open-source local context engine for individual developers. |
| Gateway | Organization-wide LLM proxy, budgets, FinOps, and compliance. |
| Cloud | Hosted account, sync, team, billing, and registry services. |

This maps cleanly to product packaging and integration depth. Its language—
"efficient, verifiable, portable, organizational context infrastructure"—also
supports the SDK position. It should be simplified on the website into a
builder-to-enterprise progression rather than introduced as three products.

One maintenance issue: both ECOSYSTEM and VISION link to
`docs/business/adr-023-open-core-split.md`; no `docs/business/` files exist on
`main`, so that public reference is currently broken.

## Public documentation audit

There are **206 tracked documents under `docs/` outside `docs/internal/`**.
They are valuable, but they mix several audiences and stability levels:

| Group | Count | What it conveys |
|---|---:|---|
| Reference | 39 | Journey-based CLI/MCP product manual, operational playbooks, generated tool/config reference, API/conformance evidence. |
| Contracts | 77 | Versioned schemas/contracts for tools, HTTP, policy, evidence, packages, provider, release, and governance behavior. |
| Guides | 24 | Agent setup plus compression SDK, embedded Rust SDK, extensions, addons, data sources, policy, SSO, monorepo, and package publishing. |
| Comparisons | 9 | Positioning against Headroom, Repomix, naive RAG, memory products, Claude context, and related alternatives. |
| ADRs | 8 | Protocol, sidecar, open-runtime, task identity, and control-plane decisions. |
| GA/runbooks/releases/research/specs/integrations/etc. | 49 | Operations, deployment, standards, research, and release material. |

The repository docs index explicitly calls this **developer-facing** material and
sends end users to `leanctx.com/docs`. The website docs are a separate,
hand-authored documentation system, organized as:

`Get Started → Journeys → Core Concepts → Tools → Workflows → Context Engine → Operations → Reference`.

That navigation is much better than the repository tree, but it still makes the
SDK hard to discover. The API page does describe the local and Team Server `/v1`
contract, but no top-level "Build with LeanCTX" path connects it to:

- TypeScript/Python `lean-ctx-sdk` prompt compression;
- Vercel AI SDK `withLeanCtx`/middleware;
- LiteLLM and LangChain adapters;
- `/v1` clients and generated OpenAPI;
- the safe, in-process Rust `Engine` façade.

The embedded Rust guide is particularly strong: it documents a shared cache,
typed `Engine` methods, PathJail, scoped state, and explicit write/exec opt-in.
The SDK RFC gives a credible surface map. This is the proof that the SDK claim
is substantive, not a marketing rename.

### Documentation changes for the new position

1. Add a first-class **Build with LeanCTX** track beside **Use LeanCTX with my
   coding agent**. Start with an integration chooser: zero-code/MCP, drop-in
   prompt wrapper, `/v1` API/client, or embedded Rust engine.
2. Add `/docs/sdk/quickstart`, `/docs/sdk/typescript`, `/docs/sdk/python`,
   `/docs/sdk/api`, and `/docs/sdk/rust-engine`. Link this track in the main nav,
   docs landing page, README near the top, and every SDK package README.
3. Present the `/v1` contract, OpenAPI, capability discovery, version support,
   authentication, and live conformance in one developer portal. Clearly mark
   availability: the in-process Rust crate is currently a workspace/path
   dependency; do not market it as a published crates.io install.
4. Keep contracts, ADRs, runbooks, research plans, and superpowers documents
   public if desired, but separate **stable public interface** from **repository
   governance/design material** so product documentation does not feel like an
   internal archive.
5. Make one cross-repository facts source feed README, website, docs, package
   READMEs, and release snippets. Current public numbers conflict: README and
   homepage metadata say 27 languages while website `facts.ts` and VISION say
   26; README says 84 MCP tools while reference guides say 79; website facts
   still identify version 3.9.3 even though deploy is 3.9.19. Explain different
   denominators or remove unstable headline counts.

## GitHub releases

`gh release list`/the releases API shows an active release train. The latest
release is **v3.9.19**, published 2026-08-18, non-draft/non-prerelease, with 16
assets. The immediately previous release is v3.9.18 (2026-08-08), followed by
v3.9.17 through v3.9.14 over 2026-08-03/04; recent releases have 12–16 assets.

The v3.9.19 notes lead with OSS intelligence/control-plane work, cross-agent
memory sync, workspace health, analytics, and solution-intelligence tracking.
This supports an SDK/runtime narrative: LeanCTX is maintained infrastructure
with installable artifacts, not a static demo. On the site, show the current
release/version and link to release notes; do not turn the hero into a changelog.

## Positioning comparison

| Dimension | Current website | "The Context SDK for AI Agents" |
|---|---|---|
| Category | Context engineering / AI Value Gate / Cognitive Context Layer. | Context SDK. Familiar, concise developer category. |
| Primary user implied | Individual using a coding agent. | Anyone building, extending, or operating an agent; coding-agent users remain included. |
| First value | Fewer tokens and no cold starts. | Add deterministic context I/O, memory, policy, and proof to an agent in minutes. |
| Primary action | Install/wrap a supported editor or visit GitHub. | Import/wrap/run; then choose MCP, `/v1`, or embedded depth. |
| Differentiation | Read/shell compression, memory, agent coordination, ledger. | Local-first context runtime: structure-aware compression/retrieval, durable memory, safe controls, and verifiable evidence. |
| Enterprise story | Separate product/enterprise navigation. | Natural extension from a local SDK to Gateway and Cloud. |

Do not discard the present language entirely. Use **context engineering** as the
discipline and **AI Value Gate/Cognitive Context Layer** as architectural or
enterprise language. The public category and hero should have one consistent
answer: **The Context SDK for AI Agents**.

## Proposed website structure

### Global navigation

`Product` · `Integrations` · `Developers` · `Docs` · `Pricing` · `GitHub`

The **Developers** menu should expose SDK Quickstart, TypeScript, Python, `/v1`
API, Rust Engine, OpenAPI, and examples. Keep coding-agent integrations as a
peer route rather than burying custom-agent builders under Use Cases.

### 1. Hero

**Eyebrow:** Open source · local first · provider agnostic  
**H1:** `LeanCTX — The Context SDK for AI Agents`  
**Body:** `Give every agent focused context, durable memory, safe controls, and
verifiable evidence—without giving up your model, data, or prompt cache.`

Primary CTA: **Get the SDK**  
Secondary CTA: **Read the API**  
Tertiary/text CTA: **Use with Cursor, Claude Code, Codex, and 30+ agents**

Show a real Vercel AI SDK integration immediately. It follows the documented
`withLeanCtx` shortcut and meets the requested import → wrap → run shape:

```ts
import { withLeanCtx } from "lean-ctx-sdk";
const model = withLeanCtx(openai("gpt-4o"));
await generateText({ model, prompt });
```

Label it **"Drop-in prompt compression; original prompt used on failure."**
Offer tabs for Python `compress()`, LiteLLM, `/v1`, and Rust `Engine`; do not
invent a universal wrapper API that the shipped SDKs do not expose.

### 2. How it works

Use one simple, left-to-right system visual:

`Your agent → LeanCTX local runtime → model, repository, tools, and sources`

Under it, four short stages:

1. **Shape context** — structure-aware reads, search, shell output, and
   compression choose signal over raw volume.
2. **Carry context forward** — session continuity, knowledge, and code graph
   preserve relevant learning.
3. **Apply controls** — PathJail, budgets, policy, permissions, and reversible
   references keep context safe and recoverable.
4. **Prove the result** — deterministic output, receipts, signed ledger,
   benchmarks, and snapshots make savings/audits inspectable.

The copy should distinguish the two real data paths: read-side MCP/shell and
optional wire-side prompt compression. That distinction is a technical strength
and prevents an overbroad "we compress everything" claim.

### 3. Integration depths

Present four cards in increasing depth, with an explicit choice rather than a
one-size-fits-all installation flow:

| Depth | Best for | Entry point |
|---|---|---|
| 0 — Connect | Existing coding agents | `lean-ctx wrap <agent>` / MCP + shell hooks. |
| 1 — Wrap | Existing LLM applications | TypeScript/Python `compress()` or Vercel AI SDK middleware. |
| 2 — Build | Custom agent loops and services | Local `lean-ctx serve`, versioned `/v1`, OpenAPI, and client SDKs. |
| 3 — Embed | Native developer tools and runtimes | Rust `Engine` façade with shared cache and explicit capability gates. |

Every card should state what remains local, what process/network boundary it
uses, required prerequisites, and whether the surface is stable/preview. This
turns product breadth into an understandable adoption ladder.

### 4. Evidence and proof

Replace generic traction-first proof with four inspectable evidence cards:

- **Reproducible efficiency:** benchmark methodology, before/after tokens, and
  cache behavior; link to benchmark scripts/results.
- **Deterministic context:** byte-stable compression and content-addressed
  recovery references preserve prompt-cache behavior and reversibility.
- **Verifiable operations:** signed savings ledger, `ctx_proof`/`ctx_verify`,
  signed snapshots, and offline verification.
- **Interface confidence:** versioned `/v1`, OpenAPI, public contracts, SDK
  conformance matrix, GitHub releases, and live compatibility status.

Use installs/stars/release velocity as secondary social proof, with a date and
source. Avoid an unsupported universal percentage. Tie every performance claim
to workload, mode, and benchmark link.

### 5. Pricing

Lead the section with: **"Build locally for free. Pay when operating context
needs a team."** Then retain the existing Free, Pro, Team, Enterprise, and
Supporter structure. Organize comparison rows around operating needs:

- Local engine/SDK and core `/v1`: Free forever.
- Hosted identity/sync/registry: Pro.
- Shared workspace, audit retention, team controls: Team.
- Central Gateway, SSO/SCIM, compliance, dedicated support: Enterprise.

Keep the ROI calculator below—not above—proof and plan fit. It is useful for a
platform buyer, but it should not be the first definition of an SDK.

### Footer and continuity

Include SDK/API links, agent integrations, security/privacy, benchmark/evidence,
status, releases, and source. Ensure product claims remain scoped: the home FAQ
says code stays local, while the shared `SiteV2` layout initializes PostHog with
`cookieless_mode: 'on_reject'`. Clarify that distinction in the privacy/consent
copy and only make a "nothing leaves" claim about LeanCTX runtime data.

## Recommended implementation order

1. **Message system:** approve canonical hero, one-sentence definition, and
   controlled vocabulary; update README, homepage, docs intro, Open Graph/meta,
   and comparison/architecture pages together.
2. **Homepage:** replace the hero and insert code + integration-depth section;
   retain the strongest existing problem/evidence sections lower on the page.
3. **Developer path:** create SDK Quickstart and language/API pages; add
   Developers navigation and cross-links from package READMEs.
4. **Evidence hygiene:** establish shared product facts and repair the missing
   ADR link; reconcile counts, package names, versions, and availability states.
5. **Pricing:** recast tiers around local-to-team operating depth while preserving
   the Local-Free Invariant and existing checkout paths.

This sequence gives the new category a concrete proof point on day one, without
requiring an engine rewrite or discarding the strong context-engineering work
already present.
