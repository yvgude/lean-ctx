# A5 — Evidence-system audit

Audit date: 2026-08-19

Scope: the 12 files named in the task. Two requested paths are rooted at rust/
in this checkout: rust/crates/lean-ctx-protocol/src/savings.rs and
rust/tests/evidence_tamper_tests.rs.

## Executive verdict

The repository contains a credible prototype of signed, tamper-evident
evidence, but its customer-facing evidence commands are a separate system.
The protocol-backed flow is not called by production code. Today it can prove
that a generated ZIP has not changed after it was signed; it cannot
automatically prove every SDK call occurred, that usage/cost is complete and
accurate, or that the claimed savings use a matched workload.

System split:

    evidence workflow
      -> scenario JSON + unsigned ZIP (manifest evidence-workflow-strict, v2.0)
      -> verify rejects it (requires signed evidence-bundle, v1)

    analytics provider-run ArmResult
      -> core::evidence_flow::build_evidence_from_run
      -> signed execution/savings receipts + signed ZIP
      -> offline verifier accepts the outer ZIP
         ^ no non-test caller

## Verification performed

- Source line counts below are current checkout counts.
- Passed cargo test --test evidence_tamper_tests: 7/7.
- Passed filtered library suites: evidence flow 2/2, canonical signing 6/6,
  quality scorecard 6/6.
- The test linker emitted a non-fatal compact-unwind performance warning.

## File-by-file audit

### 1. rust/src/cli/dispatch/evidence.rs — 499 lines

Purpose: Clap dispatcher for evidence {run, workflow, realworld, report,
inspect}; writes workflow/real-world artefacts and makes an unsigned workflow
ZIP.

Public API: pub(crate) fn run(&[String]) -> i32. Command/argument types are
private.

Coverage: two unit tests cover inspect listing a manifest and rejecting a ZIP
without one. Dispatch, arguments, workflow output, and interoperability are
untested.

Known issues:

- evidence run says the provider comparison is unavailable yet returns exit
  code 0, so automation can report success with no evidence.
- create_workflow_bundle emits an unsigned string-versioned v2 manifest with
  no file hashes or signing; it is incompatible with verify's signed v1
  evidence-bundle contract.
- Realworld writes mutable JSON and workflow writes the incompatible ZIP;
  neither invokes build_evidence_from_run.
- inspect lists files but does not verify them.
- An invalid scenario silently becomes all.

### 2. rust/src/cli/dispatch/evidence_realworld.rs — 613 lines

Purpose: runs two synthetic five-turn code-review conversations against an
OpenAI-compatible endpoint. Baseline receives raw project data, treatment
locally compressed data; provider usage plus local pricing is used for costs.

Public API: crate-visible TurnResult, ArmResult, RealWorldResult, Methodology,
RealWorldArgs, and execute_realworld_evidence.

Coverage: no direct tests; evidence_report only uses result types as fixtures.

Known issues:

- It is a hand-built benchmark, not SDK/agent-call instrumentation. It has no
  receipt, signature, task identity, or tool-call provenance.
- run_cmd returns stdout even if find, rg, cargo test, or cargo check exits
  unsuccessfully. Failed test runs are not distinguished from passing runs.
- If the commands cannot launch it inserts fabricated passing test output into
  the claimed evidence.
- Cost is only as real as the mutable local ModelPricing quote; the result
  records neither price key/rates/match kind nor an invoice/price snapshot.
- Independent conversations and nondeterministic model output have no outcome
  quality gate before a savings claim is emitted.

### 3. rust/src/cli/dispatch/evidence_workflow.rs — 811 lines

Purpose: simulates bugfix/review/refactor workflows, measures raw versus
compressed context locally, optionally requests LLM reviews, applies a
heuristic quality comparison, and produces multi-model cost projections.

Public API: crate-visible TurnMeasurement, QualityScore, ScenarioResult,
WorkflowResult, WorkflowArgs, ScenarioType, and execute_workflow_evidence.

Coverage: no tests in this file or direct external tests.

Known issues:

- Measurements are local simulation, not provider billing or SDK telemetry.
  Costs use a fixed 500 output-token estimate and 100 tasks/day.
- Missing API key or LLM failure yields successful output with no quality
  result; there is no fail-closed quality-preserved condition.
- Quality is keyword/list-marker overlap, response length, and code-fence
  heuristics, not rubric evaluation against ground truth.
- It duplicates the failed-command/fabricated-test-output behaviour.
- Its callgraph is two rg searches, not dependency analysis.
- Selected model is ignored by the fixed five-model projection set.

### 4. rust/src/cli/dispatch/evidence_cost.rs — 184 lines

Purpose: calculates per-task/monthly USD projections for five fixed models and
renders an ASCII table.

Public API: crate-visible CostEstimate, MonthlyProjection, CostReport,
CostSummary, calculate_cost_report, format_cost_table, get_model_cost.

Coverage: no direct tests.

Known issues:

- Assumes equal output tokens and zero cache reads/writes; it is a projection,
  not receipt-backed cost.
- Drops ModelQuote.match_kind, presenting heuristic/fallback values with exact
  precision.
- cheapest_model/most_expensive_model select min/max savings, not actual
  model price.
- Table text hard-codes 100 tasks/day despite a tasks_per_day argument.

### 5. rust/src/cli/dispatch/evidence_report.rs — 456 lines

Purpose: converts RealWorldResult JSON into escaped, printable, self-contained
Thinkery HTML.

Public API: crate-visible render_file; renderer/helpers private.

Coverage: two unit tests cover metric rendering/escaping and number grouping.
File I/O, malformed input, and signed-bundle linkage are untested.

Known issues:

- Verification hash is only SHA-256 of arbitrary input JSON, not a signature,
  certificate, bundle verification, or protected origin.
- Stored totals and percentages are trusted; no turn-total/cost recomputation
  or provider-usage verification occurs.
- It calls these actual API costs and independently verifiable although the
  source realworld JSON is unsigned.
- Narrative hard-codes five turns even if supplied data disagree.

### 6. rust/src/core/evidence_flow.rs — 436 lines

Purpose: converts matched provider-run arms and a quality comparison into
signed execution receipts, a signed SavingsReceiptV1, a signed hashed ZIP,
then self-verifies the ZIP.

Public API: EvidenceFlowConfig, EvidenceFlowResult,
build_evidence_from_run, arm_to_receipt.

Coverage: two passing unit tests: a synthetic self-verified bundle and
tampered receipt rejection. Direct source search found no production caller of
build_evidence_from_run.

Known issues:

- Not wired to the normal evidence CLI or SDK/proxy interception; it receives
  pre-aggregated ArmResults, not every observed call.
- arm_to_receipt assigns original/materialized/delivered/provider-billed all
  to input_tokens, losing actual context-compression balances and references.
- It hard-codes one call, zero retries, and zero reasoning tokens.
- Public arm_to_receipt uses expect for identifiers; invalid direct input can
  panic.
- QualityComparison permits a 50-milli regression; signed savings sets
  quality_preserved only at exact parity or better, producing conflicting
  quality fields in one bundle.
- Validation does not check scorecard arm labels or workload/prompt/input hash.

### 7. rust/src/core/canonical.rs — 259 lines

Purpose: compact recursively sorted JSON canonicalisation and Ed25519 signing
for execution receipts and manifests.

Public API: Error, AgentIdentity, canonical_serialize, sign_receipt,
verify_receipt_signature, sign_manifest, verify_manifest_signature.

Coverage: six passing tests cover determinism, canonical round-trip, receipt
sign/verify, receipt tampering, wrong key, and manifest round-trip.

Known issues:

- Public canonical_serialize panics on a Serialize failure rather than
  returning a Result.
- cli::dispatch::verify does not verify individual receipt signatures.
- Signatures prove integrity from a supplied key, not signer trust or data
  truth; there is no trust policy, key lifecycle/revocation, or attestation.
- Tests omit malformed/missing signatures and signature-placement boundaries.

### 8. rust/src/core/quality_scorecard.rs — 361 lines

Purpose: defines five equal-weight quality dimensions, scorecards, and
baseline/treatment comparisons with milli-score tolerance.

Public API: QualityDimension, ScoreConfidence, DimensionScore, QualityScorecard
(new, add_score, compute_overall), QualityComparison
(DEFAULT_TOLERANCE_MILLI, compare).

Coverage: six passing tests cover serialization, average, regression,
tolerance, unavailable dimensions, and per-dimension bounds.

Known issues:

- QualityScorecard.overall_score_milli deserializes as unconstrained u16 and
  is not checked against compute_overall; inconsistent scorecards are accepted.
- Duplicate dimensions can deserialize; comparisons do not validate run
  equality or baseline/treatment arm labels.
- Scores are self-reported mutable assertions with no rubric version,
  evaluator prompt/model/version, source evidence, or independent review.
- Unavailable dimensions are removed from the denominator, potentially raising
  a score while an important dimension is unmeasured.

### 9. rust/src/cli/dispatch/verify.rs — 704 lines

Purpose: offline ZIP verifier for manifest shape, listed file SHA-256 hashes,
and manifest Ed25519 signature using embedded or supplied key.

Public API: VerifyCommand, VerifyResult, FileVerification, execute_verify;
crate-visible looks_like_bundle_command and run.

Coverage: five local tests plus the seven passing integration tamper tests:
valid/tampered/missing/extra files, manifest tampering, wrong key, empty ZIP.

Known issues:

- Verifies only the outer manifest/hashes, not ExecutionReceiptV1 or
  SavingsReceiptV1 schema, signatures, references, arithmetic, or quality
  semantics.
- Reads every ZIP entry fully with no count/compressed/expanded-size limits;
  a hostile bundle can exhaust resources.
- Unlisted content retains bundle_valid=true with a warning. It is unsigned,
  but a commercial verifier needs an explicit strict mode/trust classification.
- Several historical signature payload encodings are accepted without a clear
  versioned contract.

### 10. rust/crates/lean-ctx-protocol/src/savings.rs — 292 lines

Purpose: protocol types for OSS SavingsObservationV1, measurement provenance,
and signed-style SavingsReceiptV1 derived from baseline/treatment receipts.

Public API: SavingsObservationV1, MeasurementMethod, SavingsReceiptV1,
SavingsReceiptV1::validate, SavingsReceiptV1::compute_from_arms.

Coverage: four unit tests cover observation/receipt serialization, excessive
avoided-cost rejection, and ordinary delta calculation.

Known issues:

- validate requires avoided cost no greater than baseline but does not require
  equality to baseline minus treatment or token-ratio consistency.
- It cannot establish the two receipt IDs refer to the same workload; compute
  copies baseline task fields without enforcing that relationship.
- Signature is an unchecked string in the protocol validator and current CLI
  verification does not verify receipt signatures.
- SavingsObservationV1 is not signed evidence and is not automatically emitted
  by SDK integrations.

### 11. rust/tests/evidence_tamper_tests.rs — 271 lines

Purpose: end-to-end mutation tests for verify using a generated audit-trail
bundle.

Public API: none; test-only helpers and seven tests.

Coverage: passed 7/7: valid bundle, changed listed file, removed file, added
unlisted file, changed manifest, wrong public key, empty ZIP.

Known issues:

- Tests a generic audit-trail bundle, not protocol receipts made by
  evidence_flow.
- Does not test receipt signatures, internally signed but false claims,
  savings/quality arithmetic, malformed paths, duplicate entries, or ZIP
  resource limits.
- Locks in warning-only handling for added data without strict mode.

### 12. rust/src/core/gain/model_pricing.rs — 810 lines

Purpose: embedded/live/config/environment price resolution, name
normalisation/heuristics, and USD estimation.

Public API: ModelCost (estimate_usd), PricingMatchKind (is_estimated),
ModelQuote, ModelPricing (load, embedded, quote, quote_for_client,
quote_from_env_or_agent_type), resolve_model_for_client.

Coverage: ten unit tests cover fallback, precedence, overrides, dashed IDs,
Claude/Foundry heuristics, and model selection. Default evidence pricing and
quote provenance are untested.

Known issues:

- evidence realworld defaults to gpt-4o-mini, absent from the embedded exact
  table. The gpt-4o heuristic selects fallback-blended (2.50 USD/M input,
  10 USD/M output) without exposing match kind, so an estimate can be reported
  as real cost.
- Config/env/live prices can change, but artefacts do not record selected key,
  rates, match kind, snapshot time, or configuration provenance.
- Unknown/new models are family-priced heuristically; suitable operationally,
  not for unqualified commercial claims.
- f64 arithmetic and no ledger rounding/rate-validation policy make it
  unsuitable as authoritative financial evidence.

## Gap to “every SDK call automatically produces a receipt”

| Required capability | Current state | Gap |
| --- | --- | --- |
| Trigger | Manual evidence commands; signed flow has no production caller | No SDK/proxy middleware that observes every call and emits before return |
| Per-call provenance | Aggregate ArmResult after a benchmark | No immutable usage, provider request ID, request/task hash, tool/context refs, retries, outcome, or sequence |
| Billing truth | Provider counters plus mutable local quote | Need provider usage/invoice IDs or estimate label, price snapshot/region/tier, integer money, reconciliation |
| Matched savings | Hand-built arms; optional/weak quality | Need signed workload hash, matching policy, quality-evaluator provenance, fail-closed gate |
| Cryptographic trust | Self-embedded Ed25519 key | Need issuer trust policy, key lifecycle/revocation, signed sequence/timestamp, audit-log anchoring |
| Verification | Outer ZIP only | Need receipt schema/signatures/cross-refs/arithmetic/scorecards and strict ZIP limits |
| Customer report | Hashes unsigned JSON | Must render only a verified signed bundle and display signer, method, rates, and limitations |

## Minimum viable commercial path

1. Add one shared SDK/proxy observation boundary recording immutable request
   metadata, returned provider usage/request ID, selected model, exact context
   balance, price provenance, retries, latency, and a monotonic sequence.
2. Sign one ExecutionReceiptV1 per observed call immediately and append it to a
   durable local ledger; spool/fail visibly if receipt persistence fails.
3. Build SavingsReceiptV1 only from linked matched receipt sets with a signed
   workload/prompt hash, matching policy, evaluator evidence, and fail-closed
   quality result.
4. Route all evidence CLI output through this protocol flow; retire or label
   the current workflow simulation as a benchmark. Generate only the signed
   ZIP format accepted by verify.
5. Make verify validate the complete receipt graph and arithmetic with safe ZIP
   limits; generate HTML only after verification succeeds.
6. Embed exact price quote/snapshot and signer trust material. Unknown or
   heuristic price must say estimate, never actual cost.

Until then, the accurate positioning is: manual benchmark and tamper-evident
bundle prototype, not automatic SDK-call evidence or commercial-grade verified
savings.
