# A6 — Compression Engine and Context Selection Moat Audit

## Executive assessment

lean-ctx's technical moat is an integrated, deterministic context-control system:
it decides whether to compress, selects the cheapest recoverable view that remains
useful for the task, enforces budgets, and records measured—not estimated—savings.

The ingredients are individually reproducible: Tree-sitter, BPE tokenizers,
command parsers, and summarizers are commodity. The hard-to-copy asset is their
coupling: a broad compatibility corpus, conservative gates, recovery paths,
cache coherence, task-aware selection, and evidence-grade accounting.

The moat is credible when positioned as a context control plane for coding agents,
not merely as shell-output summarization.

## Source-of-truth corrections

Two shorthand descriptions understate the current code.

- core/extension_registry.rs is a plug-in registry, not the owner of every user
  read mode. It defines extension points for ReadMode, Compressor, Chunker, and
  RenderTransform. Its built-in read handler is only full; the application modes
  are implemented in tools/ctx_read.
- The source has more than "10 modes." tools/ctx_read/mode.rs accepts 14 named
  modes: full, full-compact, anchored, raw, signatures, map, aggressive,
  entropy, cognitive, mdl, task, reference, auto, and diff. It additionally
  supports lines:N-M (including comma multi-select), anchored:N-M, and
  density:0.NN.

## End-to-end design

    tool or file output
      -> classify content, command semantics, safety, and policy
      -> count model-family tokens
      -> choose a view under task/cache/pressure/budget constraints
      -> run structural, command, AST, entropy, or task-aware reduction
      -> reject a non-winning or unsafe candidate
      -> attach stable recovery reference and account for realized savings
      -> update cache, context ledger, and optional feedback policy

Compression is always a candidate. Multiple layers can decline it and return raw,
a precise slice, a diff, or a recoverable structured representation instead.

## 1. Shell compression engine

### What it does

rust/src/shell/compress/engine.rs is the final policy gate. It combines stdout and
stderr, handles failed commands and test/build output specially, strips an old
footer before recounting, and only accepts an output that has fewer measured
tokens than its input. It delegates command-specific reduction to
core/patterns/mod.rs and only then considers generic cleanup.

The flow is deliberately layered.

1. classification.rs identifies excluded commands, source-search output,
   structural output, and output that must remain verbatim. It protects file
   viewers, CLI/API data, database queries, crypto output, infrastructure
   inspection, logs, archives, clipboard reads, version/help, config inspection,
   network/DNS output, container listings, cloud/package queries, and
   write/development scripts.
2. engine.rs gives errors and test/build diagnostics priority, deduplicates
   repeated diagnostics, folds repetitive progress, preserves protected spans,
   and routes only eligible output to command-specific patterns.
3. boundaries.rs finds repeated record delimiters (at least three matching
   boundaries) and compresses each record independently. This prevents one
   record's formatting from damaging its neighbours.
4. Verbatim data has a separate recoverable path. JSON, CSV/TSV, YAML, and HTML
   can be compacted losslessly; optional lossy variants explicitly identify
   dropped high-entropy columns and return a ctx_expand handle to the complete
   data.
5. footer.rs delegates savings formatting to the protocol layer for a consistent
   display contract.

passthrough.rs centralizes built-in exclusions and developer-script keywords.
The engine also has a 4,000-token verbatim fallback which keeps test and
diagnostic lines, rather than blindly retaining a head or tail.

### Pattern surface: what "95+ patterns" means

core/patterns/mod.rs exposes 78 compressor modules and an ordered PATTERNS table
with 89 routing predicates. Predicate entries include aliases and subcommands,
so the command surface exceeds 95 forms. The first matching handler wins, and a
token-aware shorter_only guard rejects any handler result that inflates output.

Complete module register:

alembic, ansible, argocd, artisan, aws, bazel, buf, bun, cargo,
cargo_diagnostics, clang, cmake, composer, cosign, curl, dbt, deno, deploy,
deps_cmd, docker, dotnet, env_filter, eslint, fd, find, flutter, flyway, gem,
gh, git, glab, golang, grep, grype, helm, jj, json_schema, just, kubectl,
linkerd, log_dedup, ls, make, maven, mise, mix, mlflow, mypy, mysql,
next_build, ninja, npm, ollama, php, pip, playwright, pnpm, poetry, prettier,
prisma, psql, pulumi, pytest, ruby, ruff, semgrep, spark, swift, swiftlint,
syft, sysinfo, systemd, terraform, test, trivy, typescript, wget, and zig.

The router also normalizes tool aliases: Git/GitHub/GitLab, Docker/Compose,
Kubernetes/k, npm/yarn/pnpm/bun/bunx/deno, pip/Poetry/uv/conda, Terraform/
OpenTofu/Pulumi, C/C++ toolchains, test runners, linters, cloud CLIs, data
migrations, AI/ML tools, security/SBOM scanners, and edge deployment tools.

### How effective it is

The code makes effectiveness a safe realized-saving property rather than a
headline average.

- Every accepted candidate is token-counted and must be smaller than source.
- Boundary-aware compression needs at least 10% aggregate token reduction.
- Terse compression must pass quality checks and save at least 3% globally or
  5% per preserved record segment.
- Small output stays raw when framing overhead would erase benefit.
- Search output is structural, preserving locations and source lines.
- Existing lean-ctx markers are spliced around rather than corrupted.
- Already compact TOON-like output and structured payloads have re-entry guards.
- Lossy structured reduction is opt-in, visibly labeled, and expandable.

The inspected source does not prove one universal saving percentage across every
tool. It does prove per-output measurement and rejection of non-wins, which is
the stronger operational claim.

### Why competitors cannot easily copy it

A competitor can imitate the top ten command handlers. Parity requires the
long-tail compatibility corpus: command precedence, aliases, exclusions,
diagnostic preservation, output-shape parsers, data safety, and a regression
suite grown from real developer failures. Separating classification, structured
data handling, command patterns, and final token gates also makes the whole
system robust when one heuristic is wrong.

## 2. Read modes and extension registry

### Extension registry

core/extension_registry.rs provides a thread-safe BTreeMap-backed registry behind
a global RwLock. It registers and resolves four plug-in interfaces:

- ReadMode: source plus path to rendered text.
- Compressor: text plus an optional budget.
- Chunker: text to chunks.
- RenderTransform: text plus an integer hint.

Its built-ins are intentionally simple: full source, identity and whitespace
compressors, and line/paragraph chunkers. truncate_to_budget is UTF-8 safe, and
a feature-gated Wasm path can extend the registry. This is a clean extensibility
boundary, but it is not the differentiated read-mode router.

### Application read modes

| Mode | What it does | Effectiveness | Hard-to-copy part |
| --- | --- | --- | --- |
| raw | Minimal-intervention source escape hatch. | Guarantees a no-transform route. | Low alone; necessary for trust. |
| full | Complete source plus stable metadata/dependency context. | Fidelity default with cache/delta avoidance. | Cache and stable file-reference integration. |
| full-compact | Headerless, trailing-whitespace-stripped full source. | Removes formatting tax without semantic loss. | Low in isolation. |
| reference | Metadata-only source pointer. | Avoids reinjecting known content. | Session delivery tracking. |
| lines:N-M | Exact numbered span or comma multi-select. | Precise retrieval without full reread. | Pinned recovery contract. |
| anchored | Stable source anchors, optionally windowed. | Supports safe edit targeting and expansion. | Coupling to ctx_patch/cache/edit safety. |
| diff | Delta against cached prior source. | Sends changed information only. | Correct cache coherence and stale detection. |
| signatures | Imports, API surface, declaration spans, compact/TDD notation. | High signal per token for orientation. | AST/regex fallback, spans, dependency extraction. |
| map | Structural outline of key declarations/imports/exports. | Topology before body detail. | AST, graph hints, and progressive-disclosure integration. |
| aggressive | AST/structural prune plus generic compression. | Lossy candidate guarded by token monotonicity. | Quality gates and recovery discipline. |
| entropy | BPE entropy, repetition, blank-line, and task-aware pruning. | Drops low-information lines while protecting syntax/task lines. | Token-aware score plus invariants. |
| density:0.NN | Highest-value lines within a requested density. | Fits a strict BPE budget and reports actual density. | Deterministic ranking with delimiter balance. |
| cognitive | Semantic chunks, budget-selected then source-ordered. | Controls working-set size without random reorder. | Chunking, relevance, and selection logic. |
| mdl | Minimum-description-length structural fingerprint. | Delivers architecture rather than prose. | Live signatures/spans and structural heuristics. |
| task | Information-bottleneck view conditioned on task/intent. | Preserves task-relevant chunks. | Reliable session/task state plus retrieval hooks. |
| auto | Resolver-selected view. | Combines all available signals. | The system-level policy moat. |

mode.rs separately defines cacheability, lossiness, raw-cap eligibility,
compression accounting, and pinned-read protection. map, signatures, and mdl
have compressed-cache variants; precise lines, anchored windows, and diffs are
not casually substituted with a different view.

## 3. Tree-sitter integration

### Languages

The embedded grammar set covers Rust, TypeScript, TSX, JavaScript, Python, Go,
Java, C, C++, Ruby, C#, Kotlin, Swift, PHP, Bash, Scala, Elixir, Zig, Dart,
GDScript, Lua, Luau, OCaml, Haskell, Julia, Solidity, Nix, and PowerShell.
Svelte and Vue use script-block extraction then the TypeScript path. This comes
from Cargo.toml and core/signatures_ts/queries.rs.

The long tail can be supplied as grammar add-ons. grammar_loader.rs refuses a
world-writable grammar directory/library, verifies manifest SHA-256, checks the
grammar ABI, and caches the loaded language. This makes extensibility a
supply-chain-controlled feature rather than an arbitrary dynamic-library load.

### How AST data is used

- Signature extraction: core/signatures_ts uses per-language queries, a
  thread-local parser, cached compiled queries, and declaration/name captures to
  create typed signatures with exact start/end spans. Svelte/Vue route through
  script extraction. A panic or empty AST result falls back to specific or
  generic regex extraction and can block the faulty grammar for the process.
- AST pruning: ast_prune.rs retains declaration headers, imports, and exports
  while dropping body detail using body/block nodes, not indentation guesses.
- Semantic/BM25 chunks: chunks_ts.rs produces named CodeChunks with complete
  body spans for retrieval, map/task rendering, and indexing.
- Deep analysis: deep_queries/mod.rs extracts imports, definitions, calls, type
  uses, visibility, namespaces, and selected language constructs for graph
  context.
- Edit safety: syntax_validate.rs rejects an edit that takes clean source to an
  AST with syntax errors and reports the first error line.
- Observability: grammar_usage.rs records Tree-sitter versus regex fallback per
  extension and ranks use deterministically.

### Effectiveness and competitor barrier

Tree-sitter gives structural views a decisive advantage over line heuristics:
multiline signatures, nesting, language syntax, and component wrappers retain
their identity and source spans. Tree-sitter itself is commodity. The difficult
asset is the 27-language query/fallback/test matrix, SFC handling, grammar
integrity checks, and reuse of one AST investment across rendering, search,
graph construction, and edit validation.

## 4. Compression and context-selection decisions

core/auto_mode_resolver.rs resolves auto by precedence, not a single opaque
score.

1. Honor explicit caller modes; exact/pinned views resist substitution.
2. Honor instruction files, binary detection, kit/path overrides, and
   edit-quality escalations.
3. Use cache state: unchanged/full-delivered files can become stable stubs or
   deltas rather than duplicate source.
4. Apply small-file, code/prose/config/data, diagnostic, task-target, and
   token-size rules. Explicit branches include <=200 tokens, <=400 for small
   code, and large-file thresholds beyond 2,000, 6,000, and 8,000 tokens.
5. Apply progressive disclosure: eligible code becomes signatures or map at
   configured line thresholds; structure-first favors map for medium code.
6. Optionally consult a mode predictor, adaptive penalty policy, bandit, and
   OCLA tuner. Learning is off by default for deterministic behavior; the bandit
   uses deterministic argmax-of-mean unless exploration is explicitly enabled.

The resolver returns both the mode and its source, making decisions inspectable.
Conservative projection prevents learned policy from bypassing the safety
hierarchy.

### Triage

Triage is separate from file-mode selection. TaskProfileLocal captures task
class, intent, complexity, scope, context need, reasoning need, risk, and
confidence. server/context_gate.rs derives an output filter level from profile
confidence/context need, skips short output and JSON/machine payloads, and at
higher levels retains structural lines, task keywords, and actionable comments
while removing boilerplate.

The task classifier can run rules with a semantic model in shadow mode; accuracy
and calibration track the semantic candidate. Low-confidence triage fails open.
That separation prevents an uncertain classifier from silently deleting
developer data.

## 5. Token counting

core/tokens.rs uses tiktoken-rs CoreBPE, lazily loading o200k_base and
cl100k_base.

- OpenAI/default uses o200k_base.
- Claude/Anthropic uses the documented cl100k_base approximation; the source
  notes approximately 3% accuracy to Claude's actual tokenizer.
- Gemini applies an explicit 1.1x correction to its BPE estimate.
- Llama and unknown clients select the defined fallback family.

Counts sit in a synchronous Moka cache keyed by a stable hash of text plus
tokenizer family, preventing cross-model reuse. UTF-8 floor/ceiling helpers
protect truncation. The fixed internal COUNTING_FAMILY supports comparable local
decisions; gateway and ledger paths can use the resolved model family.

This is more than billing polish: the same measurement controls candidate
acceptance, cache keys, density targets, budget checks, savings evidence, and
footer statistics. Character counts or one tokenizer create systematic wrong
accept/reject decisions on real model traffic.

## 6. Context budgeting and allocation

### Hard delivery and agent limits

- core/budget.rs applies a final per-call cap, truncates at complete
  line/UTF-8 boundaries, and adds a recovery hint.
- core/agent_budget.rs tracks per-agent and per-turn consumption, warns at 80%,
  and blocks projected overage; zero configured limit means unlimited.
- server/context_gate.rs estimates a read before dispatch and can warn, block,
  or safely downgrade under pressure without improperly overriding explicit full
  or pinned reads.

### Value per token

core/context_field.rs gives each item a potential phi from normalized relevance,
surprise, graph proximity, access history, token cost, and redundancy. ViewCosts
holds alternative-view estimates for the same item. Under high budget
utilization, temperature-based selection favors dense views; with space, it can
select richer ones. It exposes phi/token efficiency and MMR (lambda 0.7) so
redundant sources do not displace complementary context.

### Ledger, packing, and reinjection

core/context_ledger maintains an agent-scoped window (default 128k), source and
sent tokens, mode, stable id, hash, active view, provenance, salience, and access
count. It signals pressure at 50%, 75%, and 90%, ranks evictions by salience/
value, protects pinned entries, plans dense replacement views, and only
"ignites" statistically exceptional high-salience context.

context_packing.rs greedily maximizes weighted term coverage under a token
budget. attention_context.rs gives more budget to diverse/definition chunks and
penalizes redundancy. The cognitive chunker detects imports, declaration spans,
and gaps; ranks them by kind, complexity, and relevance; and renders winners in
source order. Context-kernel supplements are independently capped at 150 tokens.

A competitor can copy a maximum context-window number. The harder capability is
knowing multiple recoverable representations of a source and trading among them
without losing the user's place.

## 7. Gains and savings evidence

### Gain engine

core/gain/mod.rs aggregates command statistics, tool costs, per-file heatmaps,
model pricing, session state, and events into GainSummary. It reports gross and
effective input/output savings, injection overhead, first-inject versus reread
stream savings, bounce waste, net tokens, USD avoided, energy/CO2, tool spend,
ROI, task breakdown, and a multi-factor gain score.

stream_savings.rs distinguishes first injection, rereads, cache write/read
pricing, and measured bounce waste. context_overhead.rs does not charge lean-ctx
for native baseline tool overhead, so value is a net calculation rather than a
flattering gross ratio.

### Auditable ledger

core/savings_ledger records only measured positive savings; zero or inverted
events are skipped. SavingsEvent contains baseline/actual/saved tokens,
tokenizer, model, price, mechanism (compression, routing, caching), bounce
adjustment, attribution, optional response evidence, quality signal, and
measurement/evidence class.

The JSONL store appends under a file lock and maintains a hash chain. Its
canonical event representation uses integer micro-USD rather than unstable float
formatting, supports legacy verification where required, detects tampering, can
re-chain old entries, aggregates by day/model/tool/mechanism, and creates signed
batches for third-party verification.

Accounting does not make compression better by itself. It makes savings claims
falsifiable. A dashboard counter is easy to copy; BPE baselines, cache economics,
bounce debit, canonical evidence, hash chaining, and signed export are a
stronger enterprise evidence moat.

## 8. Determinism contract (#498)

The cache-facing contract is that output is a stable function of source content,
mode, CRP mode, and task when a view is task-dependent. The implementation has
concrete controls.

- Stable instructions: instructions.rs keeps the default coding persona empty
  so it does not perturb the static prompt skeleton. Dynamic session additions
  are controlled rather than mixed into the cacheable core.
- Stable render/selection: modes round-trip canonically; renderers use source
  order and fixed formatting. ctx_explore uses BTreeMap/BTreeSet, sorted
  tie-breaks, bounded frontier expansion, and deterministic greedy coverage.
- Stable auto mode: learning is disabled by default and Thompson-style
  exploration is opt-in; tests verify identical inputs resolve identically.
- Stable artifacts: shell/redact.rs::save_tee names output as
  command-slug plus the first eight hex digits of BLAKE3(command), rather than a
  timestamp. Cleanup may use time internally, but time does not change a returned
  body or artifact identity.
- Stable compression: JSON, tabular, YAML, HTML, entropy, protected-span, and
  dictionary paths have deterministic/non-inflation tests and re-entry guards.
- Stable accounting: canonical serialization and BTreeMaps preserve ordering;
  footer formatting is tested for byte stability and quantization reduces useless
  cache variants; ledger hashes commit a fixed field sequence.
- Regression coverage: core/determinism.rs replays byte-for-byte, tests footer
  stability and auto-mode purity, and tracks provider cache evidence.
  proxy/compress_api.rs has a full-conversation #498 regression; ctx_explore
  has repeat-run byte-equality coverage.

Determinism is strategically valuable because prompt caches reward stable bytes.
A product that saves tokens but changes harmless ordering, timestamps, whitespace,
or footers can lose cache reuse and cost more overall.

## Moat map

| Component | Easy to copy | Difficult to reproduce |
| --- | --- | --- |
| Shell patterns | A few popular command parsers. | 78-module compatibility corpus, precedence, exclusions, diagnostics preservation, regression fixtures. |
| Read modes | Full, diff, outline, signatures individually. | Correct cache/stub/anchor/recovery/edit-safety state transitions. |
| Tree-sitter | The library and common grammars. | Query/fallback matrix, SFC handling, add-on integrity, spans, and multi-purpose reuse. |
| Auto selection | Size thresholds or an LLM router. | Safe precedence with pressure, task, cache, overlays, diagnostics, learning, deterministic defaults. |
| Token counts | A tiktoken counter. | Family-aware use at every acceptance, cache, budget, and ledger boundary. |
| Budgeting | One global cap. | Alternative-view economics, MMR, reinjection, provenance, and recovery. |
| Gains | A savings dashboard. | Net economics, bounce accounting, immutable evidence, hash chain, signed batches. |
| Determinism | Sorting a response. | Instructions, selectors, bodies, artifacts, footers, serialization, and cache regression control together. |

## Positioning guidance

Lead with:

> lean-ctx is the deterministic context control plane for coding agents: it
> converts raw developer-tool output into the cheapest recoverable view sufficient
> for the current task, and proves the result.

Avoid claiming Tree-sitter or tiktoken are proprietary, and avoid one universal
compression percentage. The defensible claim is measured, non-inflating savings
with structural preservation, recovery, cache stability, and evidence.

## Primary implementation map

- Shell: rust/src/shell/compress/{classification,engine,boundaries,passthrough,footer}.rs
- Command corpus: rust/src/core/patterns/mod.rs and 78 modules
- Read system: rust/src/tools/ctx_read/{mode,dispatch,core_logic,render,types,terminal_compress}.rs
- Extension boundary: rust/src/core/extension_registry.rs
- AST: rust/src/core/{signatures.rs,signatures_ts,chunks_ts.rs,deep_queries,syntax_validate.rs,grammar_usage.rs}
- Selection/budgets: rust/src/core/{auto_mode_resolver.rs,context_field.rs,context_ledger,context_packing.rs,attention_context.rs,agent_budget.rs,budget.rs}
- Measurement/evidence: rust/src/core/{tokens.rs,gain,savings_ledger,determinism.rs}

