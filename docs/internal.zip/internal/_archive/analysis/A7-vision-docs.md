# A7 — Final Vision Documents Delivery Report

## Result

The final LeanCTX vision set is present in `docs/internal/vision/`.

| Document | Purpose | Status |
|---|---|---|
| `00-NORTH-STAR.md` | Category, Chiptuner model, boundaries, Attach/Wrap/Embed, evidence principles | Complete |
| `01-PRODUCT-ARCHITECTURE.md` | Five SDK primitives, integration contracts, Rust runtime, shared surfaces | Complete |
| `02-OSS-VS-PAID.md` | OSS/Thinkery module boundary, permanent free commitments, packaging | Complete |
| `03-ROADMAP.md` | v1.0–v4.0 delivery gates, metrics, timelines, and parked work | Complete |
| `04-GO-TO-MARKET.md` | Developer wedge, pilot motion, pricing, and first-three-customers playbook | Complete |

`the_plan.md` remains in place as the archive/source input.

The obsolete numbered documents `05` through `24` are absent from the final
directory tree.

## Source decisions carried forward

- LeanCTX category: **The Context SDK for AI Agents**.
- Positioning: tune an existing agent; do not replace the agent, LLM, provider,
  or application control flow.
- Operating metaphor: LeanCTX is the context-performance chiptuner; Thinkery
  is the organization-scale operating layer.
- Core public primitives: `LeanCTX()`, `session()`, `wrap()`, `load_kit()`,
  and `receipt()`.
- Integration depths: Attach, Wrap, Embed on one shared Rust runtime and
  canonical protocol/evidence contract.
- Commercial boundary: **single developer = free, organization = paid**;
  manual/local tuning remains open, continuous/shared/governed operation is
  Thinkery.
- Proof metric: VCP-SAT with a matched baseline, declared quality gate,
  provider/cache/pricing facts, and a verifiable Receipt.
- GTM: OSS → evidence → wow → tell team → bounded paid pilot → shared
  organizational operation.

## Pricing reflected

- Developer: CHF 0.
- Pro Tuner: CHF 29/month or CHF 290/year.
- Team: CHF 499/month, annual preferred.
- Business: CHF 2,499/month, annual.
- Enterprise: from CHF 10,000/month on annual contract.
- Agent Tuning Sprint: CHF 7,500–15,000.
- Founding Design Pilot: maximum three named partners, with the strict
  evidence and acceptance boundary documented in the GTM and OSS documents.

## Validation performed

- Confirmed the five final filenames exist.
- Confirmed every final vision document has at least 200 lines.
- Confirmed `the_plan.md` is retained.
- Confirmed no obsolete `05-*` through `24-*` document remains.

## Notes

The documents intentionally make product claims conditional on measurable
quality and evidence. They do not treat observed benchmark gains as universal
savings promises, and they retain the local-first OSS commitments for Codex,
Cursor, and Claude Code.
