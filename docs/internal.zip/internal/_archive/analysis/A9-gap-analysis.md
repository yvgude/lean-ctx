# A9 — SDK v1.0 gap analysis

## Bottom line

The repository has most of the *engine* needed for v1.0, but not the product
integration. `lean-ctx-sdk` is currently a manual message compressor and
framework-adapter package; it is not an OpenAI Agents SDK wrapper. The proxy
can accept OpenAI Responses traffic and already has selection, compression,
usage, cost, and evidence primitives, but none is exposed as one correlated
Python agent run with a durable receipt and a one-command inspection flow.

**Recommended v1 target:** make `packages/python-lean-ctx` (PyPI
`lean-ctx-sdk`, import `lean_ctx`) the sole public home for `ctx.wrap(agent)`.
The similarly shaped `clients/python`, `py-sdk`, and `python-sdk` trees must
be explicitly retired, internalized, or made compatibility-only before release.

## What exists now

| v1 concern | Existing implementation | What it proves / limitation |
|---|---|---|
| Python compression API | `packages/python-lean-ctx/lean_ctx/proxy.py` has `ProxyClient.compress(messages, model)` and `CompressResult` helpers for original, compressed, and saved tokens. | Manual, chat-message-level call; no agent/runner lifecycle. |
| Python convenience integrations | `lean_ctx/litellm.py`, `langchain.py`, `llamaindex.py`; `clients/python/leanctx/adapters/openai.py` converts lean-ctx tools to OpenAI function-call specs. | LiteLLM and retrieval adapters are not OpenAI Agents SDK integration; the OpenAI adapter is tool-schema conversion, not agent wrapping. |
| OpenAI request interception | `rust/src/proxy/openai_responses.rs` accepts Responses API traffic (including Agents SDK conversation shapes); `openai.rs` handles chat traffic; routes live in `rust/src/proxy/mod.rs`. | Transport-level support exists, but Python does not configure or own it per wrapped agent/run. |
| Context choice and compression | `rust/src/proxy/forward/mod.rs` invokes `KnowledgeRouter`; `PipelineConfig.enable_knowledge_routing` defaults to true in `rust/src/core/config/proxy.rs`; `forward/pipeline.rs`, `compress_api.rs`, `conversation.rs`, and provider handlers perform compression. | Strong reusable engine, but no public typed `ContextPlan` or per-run policy/result exposed to Python. |
| Metering/cost | `rust/src/proxy/usage.rs`, `usage_meter.rs`, `cost.rs`, `metrics.rs`, and forwarding response headers. | Proxy/session aggregates and usage records exist; not one receipt returned to a Python agent result. |
| Evidence/receipts | `rust/src/core/context_kernel/receipt_builder.rs` builds/signed `ExecutionReceiptV1`; `proxy_bridge.rs` carries tokens/model; `envelope_wiring.rs` invokes evidence processing when `usage_tracking` and `receipt_chain` are enabled. | Internal and feature-gated; no `/v1/receipt(s)` contract, query store, Python model, or run correlation. |
| Quality evaluation | `rust/src/core/quality_lab/` and `lean-ctx quality-lab`; `ContextReceiptV1` has `quality_signals`. | Quality Lab evaluates artifacts/offline comparisons; no defined online quality value for an Agents SDK execution. |
| CLI reporting | `lean-ctx gain`, `benchmark`, `quality-lab`, and `token-report` already render aggregate or benchmark reports. | No command resolves one wrapped run and renders its before/after context plus cost and quality. |

## Exact gaps

| Gap | Files/modules to change | Estimated effort | Dependencies | Risk |
|---|---|---:|---|---|
| 1. No stable v1 Python SDK boundary | Select `packages/python-lean-ctx`; change its `pyproject.toml`, `lean_ctx/__init__.py`, README, tests. Mark `clients/python`, `py-sdk`, and `python-sdk` compatibility/internal or migrate their useful protocol types. | 8 h | Release/package-owner decision | Medium |
| 2. `ctx.wrap(agent)` does not exist | Add `packages/python-lean-ctx/lean_ctx/agents.py` (or `wrap.py`), export from `__init__.py`, and add Agent SDK integration tests. | 14 h | Pinned `openai-agents` compatibility range | High |
| 3. Wrapped runs do not control the OpenAI transport | Adapter must create/configure the Agent SDK model/provider against the authenticated local proxy and preserve agent tools, handoffs, guardrails, output types, clone semantics, and `Runner.run`, `run_sync`, and `run_streamed`. Touch new Python adapter plus `proxy.py`/`discovery.py`; verify `rust/src/proxy/openai_responses.rs`, `openai_responses_ws.rs`, and `forward/mod.rs`. | 18 h | Gap 2; proxy lifecycle/auth | High |
| 4. Automatic selection is engine-only, not SDK policy | Define a versioned `ContextPolicy`/`ContextPlan` contract. Carry policy, correlation ID, selection decision, source references, exclusions, and compression deltas through `forward/mod.rs`, `forward/pipeline.rs`, `compress_api.rs`, and proxy routes; surface Python options and plan metadata. | 16 h | Gaps 2–3; privacy/redaction policy | High |
| 5. No full agent-loop semantics | Current compression operates on request payloads. The wrapper must handle multi-turn tool output, handoffs, retries, streaming, cancellations, and failures without breaking prompt caching or tool-result recovery. Main Rust reuse points: `openai_responses.rs`, `tool_output.rs`, `history_prune.rs`, `sticky_tools.rs`, `prefix_replay.rs`. | 16 h | Gaps 3–4; golden Agents SDK fixtures | High |
| 6. No per-run execution receipt | Add a correlated receipt accumulator/store and authenticated proxy API such as `GET /v1/receipts/{run_id}`. Wire it from `usage.rs`, `usage_meter.rs`, `cost.rs`, `metrics.rs`, `context_kernel/proxy_bridge.rs`, `envelope_wiring.rs`, and `receipt_builder.rs`; add Python `ExecutionReceipt`. | 20 h | Gaps 3–5; persistence/retention decision | High |
| 7. “Quality” has no v1 runtime definition | Specify a quality contract: required deterministic invariants plus optional guardrail/structured-output/result-evaluator signals. Adapt `quality_lab`/`QualitySignal` into receipt data rather than claiming a synthetic score; add Python callback/configuration API. | 16 h | Product definition; Gap 6 | High |
| 8. Receipt evidence is feature-gated and not SDK-safe | Make receipt generation explicitly enabled by `wrap` policy, fail closed on malformed receipt data, redact/hide raw context by default, use content hashes/reference IDs for persisted snapshots, and bound storage. Touch kernel config, receipt store/API, Python policy, and tests. | 12 h | Gaps 4, 6, 7; security review | High |
| 9. No one-command run comparison | Add a receipt CLI subcommand in `rust/src/cli/dispatch/` (new `receipt_cmd.rs`) and dispatch/help wiring. It must show before/after summaries, selected/dropped context, token and dollar deltas, quality signals, receipt ID, and a JSON mode. | 10 h | Durable receipt/query API (Gap 6) | Medium |
| 10. v1 contract, integration, and release coverage are absent | Add Python tests for async/sync/streaming/cancel/error paths, Rust route and persistence tests, golden CLI tests, compatibility matrix CI, examples, migration notes, and package publishing checks. | 20 h | All prior gaps | Medium |

**Total:** ~150 engineering hours for one engineer; quality definition, security review,
and release qualification are the critical-path uncertainty, not compression code.

## Prioritized shipping plan — build these 10 things in order

1. **Choose the package and freeze the public v1 names (8 h, medium).**
   Ship only one `ctx.wrap` surface. The four Python trees currently expose
   overlapping package names and 0.x protocol models; duplicating the wrapper
   would make support and receipt serialization ambiguous.

2. **Pin the OpenAI Agents SDK compatibility contract (6 h, medium).**
   Add an optional dependency and a tested support range in
   `packages/python-lean-ctx/pyproject.toml`. Test the actual public run
   surfaces: `Runner.run`, `Runner.run_sync`, and `Runner.run_streamed`.

3. **Build `ctx.wrap(agent)` as an Agent SDK-native adapter (14 h, high).**
   Add `lean_ctx/agents.py`; return an Agent-compatible wrapper/clone that
   retains instructions, tools, handoffs, guardrails, model settings, and
   output type. Do not monkey-patch global Runner state.

4. **Route only the wrapped agent’s model calls through lean-ctx (18 h, high).**
   Configure a per-wrapper model/provider/client to use proxy discovery and
   auth from `discovery.py`. Preserve sync, async, SSE, websocket, failure,
   and cancellation behavior against `openai_responses.rs`.

5. **Create the versioned context-policy and context-plan contract (16 h, high).**
   `wrap(..., policy=...)` needs documented defaults/budgets, opt-out,
   exclusions, and redaction. The proxy must return the actual plan,
   selection rationale, source IDs, and compression delta—not only mutate a
   request invisibly.

6. **Complete agent-loop-aware automatic compression (16 h, high).**
   Use existing conversation/tool-output/prefix-cache components, but add
   end-to-end fixtures for tool calls, handoffs, multi-turn input,
   `previous_response_id`, retries, and streaming. This is the difference
   between “proxy can compress JSON” and “an agent is automatically managed.”

7. **Implement correlated metering and the execution receipt (20 h, high).**
   Give every wrapped run a `run_id`, propagate it as a proxy correlation ID,
   finalize after the final response/stream close, calculate actual-or-labeled
   estimated cost from normalized usage, and persist a signed receipt.

8. **Define and implement quality signals (16 h, high).**
   Record only defensible signals: compression invariants, guardrail results,
   structured-output validation, tool/error outcomes, and an opt-in evaluator.
   Provide `quality: unknown` when no trustworthy evaluator applies; never
   silently present a compression ratio as quality.

9. **Expose receipt lookup and the one-command comparison (10 h, medium).**
   Add an authenticated receipt API and `lean-ctx receipt show <run-id>`.
   Render side-by-side safe summaries by default, exact payloads only with an
   explicit local opt-in, plus JSON for automation.

10. **Finish v1 release hardening (20 h, medium).**
    Lock API/receipt schemas, test the Agent SDK version matrix and all run
    modes, add deterministic golden receipts/CLI output, document migration,
    and publish one package with a complete quickstart.

## Reuse map

| Reuse candidate | Reuse it for | Do not mistake it for |
|---|---|---|
| `proxy/openai_responses.rs`, `openai.rs`, `forward/mod.rs` | OpenAI transport routing, response header plumbing, provider forwarding, correlation propagation. | A Python Agents SDK integration. |
| `proxy/forward/pipeline.rs`, `conversation.rs`, `compress_api.rs`, `compress_shared.rs`, `tool_output.rs`, `history_prune.rs` | Selection-aware request transformation, deterministic compression, tool-result protection/recovery. | A typed per-run context plan or a receipt. |
| `core/knowledge_router`, `PipelineConfig.enable_knowledge_routing` | Relevant-context preservation/selection; it is already enabled by default in pipeline config. | A product-level policy with explanation, privacy controls, and Python visibility. |
| `proxy/usage.rs`, `usage_meter.rs`, `cost.rs`, `metrics.rs` | Usage normalization, model/accounting primitives, estimated savings. | Actual execution-level dollar cost tied to a returned run result. |
| `core/context_kernel/receipt_builder.rs`, `proxy_bridge.rs`, `envelope_wiring.rs`, protocol receipt models | Signed receipt schema/building, evidence chain, quality-signal representation. | A queryable proxy receipt service; current wiring is feature-gated and not returned to Python. |
| `core/quality_lab/`, `lean-ctx quality-lab`, benchmark commands | Offline/evaluation tooling and report rendering. | A real-time quality score for an arbitrary agent outcome. |
| `lean-ctx gain`, `benchmark`, `token-report` | CLI formatting, JSON conventions, aggregate savings and benchmark reports. | A per-run before/after viewer. |
| `packages/python-lean-ctx/lean_ctx/proxy.py` and `discovery.py` | Dependency-free proxy discovery, authentication, `/v1/compress`, reference resolution, error messages. | Agent orchestration, streaming, or receipt retrieval. |
| `clients/python/leanctx/adapters/openai.py` | OpenAI function-tool schema conversion if the v1 wrapper needs lean-ctx tools. | An OpenAI Agents SDK `Agent` wrapper. |

## Design constraints to lock before implementation

- **Wrapper semantics:** `ctx.wrap(agent)` cannot transparently alter a caller
  that still passes the original `agent` to `Runner.run`. v1 must document the
  returned value (`Runner.run(ctx.wrap(agent), ...)`) or offer an explicit
  wrapped-runner facade. Global monkey-patching is a compatibility and
  concurrency risk.
- **Receipt timing:** stream receipts need a `pending` state and become final
  only after stream completion/cancellation; they cannot be fully known when
  the request is sent.
- **Cost provenance:** label each field actual (provider usage/pricing),
  estimated (tokenizer/model price table), or unavailable. Do not merge them
  into one unqualified dollar value.
- **Quality provenance:** expose component signals and provenance, not a single
  magic number. An evaluator should be opt-in because it can add cost, latency,
  and sensitive-data exposure.
- **Before/after safety:** store hashes and compact snapshots by default; raw
  prompts/tool output are sensitive and require retention, encryption, and
  display controls.

## External integration fact used in this assessment

The official OpenAI Agents SDK runs agents through `Runner.run`,
`Runner.run_sync`, or `Runner.run_streamed`, and supports additive custom trace
processors. That makes a per-wrapper provider/transport plus a trace processor
the least invasive receipt-correlation design, rather than a global patch.
Sources: [running agents](https://openai.github.io/openai-agents-python/running_agents/)
and [tracing](https://openai.github.io/openai-agents-python/tracing/).

