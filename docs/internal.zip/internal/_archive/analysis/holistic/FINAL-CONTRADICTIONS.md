# Final contradictions, resolutions, and missing pieces

## Resolution rule

H1’s frozen product direction and H8’s anti-roadmap control scope. Technical reports describe implementation choices only after they pass that scope test. Anything not necessary for the first local, verifiable proof loop is deferred.

## Contradictions requiring a decision

| Topic | Tension | Resolution recommendation |
|---|---|---|
| Canonical receipts | H1/H2/H7 name ExecutionReceiptV1, SavingsReceiptV1, and EvidenceBundleV1. H3 adds Dyno-specific receipts; H6 proposes ReceiptDocumentV1 and evidence-bundle-v2; H16 proposes SessionReceiptV1. | Keep current ExecutionReceiptV1 immutable as a compatibility projection. Define a layered public model: SessionReceiptV1 for one task, Dyno arm/quality/comparison receipts for controlled proof, and SavingsReceiptV1 as a compatible comparison projection. Publish one logical EvidenceBundleV1; if its archive format must be v2, name that field separately and document migration. Do not ship competing top-level receipt families. |
| Integration taxonomy | H1/H7 require Attach → Wrap → Embed → Run later. H13 uses three depths, while H18 maps CLI wrap codex to Attach and message compression to Wrap. | Make the four terms normative. Attach is external integration; Wrap is lifecycle control around an existing runtime; Embed is native SDK integration; Run is later managed execution. Rename installer commands to connect where useful, or document them as installers—not taxonomy definitions. |
| First POC scope | H12 proposes one Python/OpenAI Agents SDK code-review agent and one Kit. H5 proposes four built-in Kits and packaging commands. H19 starts a future control-plane foundation. | This quarter: one reference agent, one pinned workload, one code-review Kit, two arms, local bundle/verifier. The other three Kits, remote publication, registry, tenancy, and cloud work require proof/re-entry gates. |
| Metric language | H1/H7 define VCP-SAT; H14 also promotes CPAO; older surfaces center token savings. | Use VCP-SAT everywhere as the North Star. Cost per accepted outcome is explanatory prose only. A token reduction is a diagnostic, never the headline business result. |
| Profile format and CLI | H4 specifies TOML authoring, canonical JSON digest, and a new tuning-profile namespace. H18 shows YAML and reuses profile. | Freeze TOML authoring plus canonical JSON export. Use tuning-profile for TuningProfileV1; retain profile solely for legacy runtime presets during migration. A profile is not a free-form config overlay. |
| Profile timing | H4 provides a full Profile design now, while H15 makes Profile deployment conditional on a demonstrated reference/customer configuration. | Freeze the contract and local import path now, but do not make Profile lifecycle a P0 release blocker. Promote only controls shown to matter in the first controlled proof. |
| Python SDK ownership | H10/H15 choose packages/python-lean-ctx and lean_ctx. H17/H18 show leanctx or target package names, while three other Python trees have colliding namespaces and APIs. | Name packages/python-lean-ctx as the only v1 Python distribution root and lean_ctx as its primary import. Freeze py-sdk and python-sdk feature work; inventory and migrate tested public behaviour from clients/python before deleting anything. A leanctx compatibility shim is temporary and only inside the canonical distribution if evidence requires it. |
| Kit distribution | H1 requires .ctxpkg only. H5 correctly uses .ctxpkg but also includes remote publish/marketplace-like flows. H7/H8 explicitly defer marketplace. | Keep local source Kits and deterministic local .ctxpkg packing/verification. Defer remote discovery, public publishing, marketplace ranking, commerce, and registry UX. |
| Commercial price | H1 calls price points hypotheses; H13 forbids public numerical pricing; H12 says do not quote before scope; H17 states CHF 7,500 and CHF 7,500–15,000. | Do not publish monthly or enterprise numbers now. Internally use CHF 7,500 as a starting pilot hypothesis; quote a fixed Sprint only after qualified scope, data boundary, quality contract, and acceptance decision are agreed. Do not advertise credit or savings-share terms before contractual testing. |
| Product-truth copy | H13/H17/H18 show target SDK snippets such as LeanCTX.wrap, sessions, and profiles before those contracts ship. H18 labels some examples, but public pages can still mislead. | Every unreleased API is labelled Preview / Target Contract, never used as an installation instruction. Current CTAs lead to actual CLI/MCP/hook integrations. Build validation should fail public copy that marks a planned capability as available. |
| Thinkery timing | H19 is a credible future control-plane blueprint. H8 bans control plane, central evidence, fleet management, SSO, and hosted scheduling before paid demand. | Treat H19 as a conditional post-proof architecture, not an approved roadmap. This week permits only a data-classification ADR and customer discovery—not control-plane implementation or sales claims. |
| Thinkery versus Cloud ownership | H19 calls Thinkery the future control plane; H10 assigns private cloud/control-plane code to lean-ctx-cloud and keeps Thinkery as brand/product narrative. | Thinkery AG is the company and commercial operator. LeanCTX is the product. Any future control-plane service is owned technically by lean-ctx-cloud, downstream of open contracts; never market Thinkery itself as a shipped cloud control plane. |
| Customer evidence | H17 contains exact reference-benchmark figures; H13 uses rounded 79–86%; H12 insists reference results are not customer proof. | Externally use either the exact verified benchmark artifact or the qualified rounded range, never both in the same asset. Always say controlled reference benchmark, calculated API cost, methodology, and not a customer guarantee. |

## Tensions that are compatible once wording is precise

- H6’s receipt timestamps concern per-execution factual timing. H14’s privacy guardrail should prohibit raw event timelines in shareable aggregates by default, not erase required execution timing.
- H12’s Python/OpenAI Agents SDK POC and H1’s first-class Codex/Claude Code/Cursor support can coexist: the former is the first Wrap proof; the latter remain Attach compatibility/release gates.
- H5’s technical package substrate can remain in the repository. It must not be marketed as a marketplace or become a v1 adoption dependency.

## Missing pieces

### Missing reports

H9 and H11 were absent at finalization. Re-run this synthesis after they arrive if either proposes a material change to product scope, evidence contract, commercial packaging, or the first POC.

### Missing decisions or artifacts

1. A signed, versioned contract registry naming the one accepted Session/Dyno/receipt/bundle schema stack.
2. A minimal DynoRun workload manifest, quality-contract format, and run-plan test vectors.
3. An explicit capability matrix for Codex, Claude Code, and Cursor: supported version, integration depth, observability coverage, install/doctor/uninstall behavior.
4. A customer pilot pack: qualification checklist, data boundary, statement of work, acceptance criteria, report template, and no-go outcome.
5. A public claim ledger linked to source artifacts, methodology, qualifiers, owner, and release status.
6. A feature-admission template enforcing D-020: user, context problem, measurable result, loop step, OSS/commercial class, and displaced work.
7. A real packaging decision for Kit/Profile compatibility—not just proposed commands—and a migration path from legacy profiles/Kits.

## Highest-risk unrealistic assumptions

1. Treating existing engine breadth as proof that the end-to-end customer product is shipped.
2. Building a marketplace, control plane, or dashboard before a second paid, repeatable evidence result.
3. Promising LeanCTX.wrap, Dyno, Profile deployment, or signed evidence in public before the first supported vertical slice works.
4. Selling raw token reduction as economic value without accepted-task quality.
5. Expanding to multiple frameworks before the reference Python Wrap path has passed an external 15-minute quickstart and tamper test.
