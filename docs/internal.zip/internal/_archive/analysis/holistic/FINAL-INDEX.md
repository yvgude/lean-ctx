# LeanCTX / Thinkery — Final index

## Executive conclusion

LeanCTX should spend the next 90 days proving one narrow, paid, local-first context-performance loop—not building an agent platform. The first proof is a controlled comparison on an existing coding agent that produces a quality-gated, offline-verifiable evidence bundle and a deployable, versioned Tuning Profile.

The governing product identity is:

> LeanCTX — The Context SDK for AI Agents.  
> Tune any agent. Prove every gain.

Every claim must remain workload-specific, baseline-backed, quality-gated, and explicit about whether cost is provider-reported, calculated, or invoice-reconciled.

## Recommended reading order

1. [FINAL-ONE-PAGER.md](FINAL-ONE-PAGER.md) — external explanation in German.
2. [H1 — Master vision](H1-master-vision.md) — product identity, frozen decisions, business model, 90-day direction.
3. [H8 — Anti-roadmap](H8-anti-roadmap.md) — the scope boundary that protects the strategy.
4. [H7 — Frozen-decisions analysis](H7-frozen-decisions.md) — current gaps and visible strategy violations.
5. [H12 — Fastest credible POC](H12-fastest-poc.md) — the specific proof to build and sell first.
6. [H2 — Codebase-to-strategy map](H2-codebase-strategy-map.md) — what can be reused versus what is missing.
7. [H15 — Priority matrix](H15-priority-matrix.md), [H10 — Repository convergence](H10-repo-convergence.md), [H3 — Dyno and AutoTune](H3-dyno-autotune.md), [H4 — TuningProfile](H4-tuning-profile.md), [H5 — Context Kits](H5-context-kits.md), [H16 — ContextSession](H16-context-session.md), [H6 — Receipt and evidence](H6-receipt-evidence.md) — technical contract sequence.
8. [H14 — Focus and identity](H14-focus-identity.md), [H18 — Developer experience](H18-developer-experience.md), [H13 — Website redesign](H13-website-redesign.md) — messaging and adoption once product truth is settled.
9. [H17 — Investor narrative](H17-investor-narrative.md), [H19 — Thinkery commercial layer](H19-thinkery-commercial.md) — fundraising and later commercialization, not this week’s build scope.
10. [FINAL-CONTRADICTIONS.md](FINAL-CONTRADICTIONS.md) and [FINAL-NEXT-STEPS.md](FINAL-NEXT-STEPS.md) — resolutions and action.

## Key decisions

| Decision | Final position |
|---|---|
| Category | Context performance; never generic agent orchestration. |
| Customer promise | Tune an existing agent’s context and prove a declared gain. |
| Product loop | Connect → Measure → Tune → Prove → Deploy → Repeat. |
| Near-term wedge | Coding-agent workflows; first proof is one Python/OpenAI Agents SDK code-review agent. |
| Success metric | VCP-SAT: verified cost per successful agent task, never raw token reduction alone. |
| Proof rule | No savings claim without matched baseline, declared quality contract, method, and signed evidence. |
| Evidence architecture | One canonical logical evidence path; dashboards and reports are views, never alternative calculators. |
| Product objects | ContextSession, TuningProfileV1, ContextKit on .ctxpkg, receipts, EvidenceBundle. |
| SDK ownership | One public Python root: packages/python-lean-ctx with primary import lean_ctx; migrate duplicates only with contract and compatibility tests. |
| Sequencing | First prove one wrapper and evidence loop; make TuningProfileV1 deployable only after the reference/pilot shows which controls matter. |
| Open/paid boundary | Local runtime, tuning, Dyno/manual comparison, profiles, Kits, and offline verification stay open; continuous organization-scale intelligence is later commercial value. |
| Immediate offer | A tightly scoped Agent Tuning Sprint / Verified Savings Pilot, followed by deploy, iterate, or stop. |
| Explicitly deferred | Marketplace, generic agent builder/orchestration, hosted execution, managed relay, broad cloud/control plane, scheduled AutoTune, and enterprise dashboard. |

## Source document index

| Report | Focus | Status |
|---|---|---|
| [H1](H1-master-vision.md) | Canonical vision, positioning, business model | Read |
| [H2](H2-codebase-strategy-map.md) | Existing implementation and gaps | Read |
| [H3](H3-dyno-autotune.md) | Dyno and AutoTune architecture | Read |
| [H4](H4-tuning-profile.md) | TuningProfileV1 design | Read |
| [H5](H5-context-kits.md) | Context Kit design | Read |
| [H6](H6-receipt-evidence.md) | Receipt and evidence architecture | Read |
| [H7](H7-frozen-decisions.md) | Decision audit | Read |
| [H8](H8-anti-roadmap.md) | Binding anti-roadmap | Read |
| H9 | Not available at finalization | Missing |
| [H10](H10-repo-convergence.md) | Repository and Python-SDK convergence | Read |
| H11 | Not available at finalization | Missing |
| [H12](H12-fastest-poc.md) | Fastest credible POC | Read |
| [H13](H13-website-redesign.md) | Website and copy system | Read |
| [H14](H14-focus-identity.md) | 90-day identity and narrative | Read |
| [H15](H15-priority-matrix.md) | 90-day implementation sequencing | Read |
| [H16](H16-context-session.md) | ContextSession design | Read |
| [H17](H17-investor-narrative.md) | Investor narrative | Read |
| [H18](H18-developer-experience.md) | SDK developer experience | Read |
| [H19](H19-thinkery-commercial.md) | Future organization-scale commercial layer | Read |
| [H20](H20-final-synthesis.md) | Synthesis working notes | Created |

## Final documents

- [Contradictions and resolutions](FINAL-CONTRADICTIONS.md)
- [This week’s ten actions](FINAL-NEXT-STEPS.md)
- [German one-pager](FINAL-ONE-PAGER.md)
