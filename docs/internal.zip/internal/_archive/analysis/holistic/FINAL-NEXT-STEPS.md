# Die nächsten zehn Schritte für diese Woche

## Wochenziel

Am Ende der Woche existiert ein überprüfbarer, lokaler Plan für einen einzigen Stock-versus-LeanCTX-Pilotlauf sowie ein qualifizierter Vertriebsprozess für einen bezahlten Kunden-Pilot. Nicht das Ziel: Cloud, Marketplace, mehrere Frameworks oder ein breites Redesign.

| # | Was Yves tut | Warum jetzt | Erwartetes Ergebnis | Zeit |
|---:|---|---|---|---:|
| 1 | Einen einseitigen Decision und Ownership Record freigeben: Produktidentität, VCP-SAT, vier Integrationstiefen, OSS/Geld-Grenze, Anti-Roadmap sowie packages/python-lean-ctx und lean_ctx als einzige v1-Python-Heimat; py-sdk und python-sdk werden bis zur Migration eingefroren. | Alle nachfolgenden Code-, Website- und Vertriebsentscheidungen brauchen dieselbe Autorität; vier kollidierende Python-Oberflächen dürfen keinen zweiten Wrap- oder Receipt-Vertrag erzeugen. | Ein datierter Entscheidungsanker mit benanntem Python-, Vertrags-, Release- und Deploy-Owner; keine Löschung oder neue Features in Legacy-Paketen. | 2 Std. |
| 2 | Den ersten POC exakt festlegen: Python/OpenAI-Agents-Code-Review-Agent, ein unveränderlicher Fixture-Commit, ein Code-Review-Kit und ein Stock/Treatment-Vergleich. | Ein konkreter vertikaler Schnitt verhindert Plattformarbeit. | Ein kleines POC-README mit Owner, Agent-/Model-Version, Task-Hash, Qualitätsgrenze, Datenklasse und Stop-Regel. | 3 Std. |
| 3 | Einen gemeinsamen Schema-ADR für ContextSession, Dyno-Arme, ExecutionReceipt, SavingsReceipt und EvidenceBundle entscheiden. | H3, H6 und H16 schlagen derzeit inkompatible oberste Belegobjekte vor. | Ein Namens- und Versionsdiagramm mit Kompatibilität zu ExecutionReceiptV1 sowie einer einzigen Bundle-Definition. | 3 Std. |
| 4 | Einen Dyno-Manifest-Validator und eine minimale Beispiel-Manifestdatei erstellen, bevor ein Provider-Aufruf möglich ist. | Der POC darf bei abweichendem Commit, Modell, Cache-Policy oder Qualitätsvertrag nicht stillschweigend vergleichen. | Ein lokaler Validate-Schritt, der unvollständige oder gemischte Arme ablehnt. | 5 Std. |
| 5 | Den dünnen lokalen Runner bauen oder zuschneiden: Stock-Lauf, gewrappter Lauf, strukturierte Outputs und reale Provider-Usage. | Dies ist die erste funktionale Schleife von Connect bis Measure; keine Dashboard-Arbeit ist erforderlich. | Zwei Run-Verzeichnisse mit gleichem Agent-/Task-Hash und klarer Kennzeichnung von beobachteten versus fehlenden Feldern. | 8 Std. |
| 6 | Qualität und Integrität als harte Gates implementieren: Fixture-basierter Evaluator, Vergleichsablehnung bei Qualitätsfehler und Manipulationstest für die Bundle-Kopie. | Ein günstiger Lauf ohne akzeptiertes Resultat ist kein Kundennutzen und kein Claim. | Ein Demonstrationslauf, bei dem ein verändertes Artefakt die Offline-Verifikation sicher fehlschlagen lässt. | 5 Std. |
| 7 | Eine ehrliche Demo-Rehearsal durchführen und die 15-Minuten-Run-of-Show dokumentieren. | H12 ist nur glaubwürdig, wenn Preflight, Fehlerpfade und Grenzen vor einem Kundentermin sichtbar sind. | Checkliste mit gemessener Dauer, bekannten Blockern und einem klaren Satz: Referenz-POC ist kein Kunden-Sparversprechen. | 2 Std. |
| 8 | Das Pilotpaket vorbereiten: Qualifizierung, Daten-/Redaktionsgrenze, Qualitätsvertrag, Abnahme, Rollback und Berichtsvorlage. | Die Tuning Sprint verkauft eine überprüfbare Entscheidung, nicht offene Beratung oder unklare Telemetrie. | Eine freigabefähige einseitige Pilot-Checkliste; Preis wird erst nach gültigem Scope besprochen. | 3 Std. |
| 9 | 30 passende Schweizer Engineering-Accounts recherchieren und 10 mit konkretem Agent-Workload priorisieren. | Die technische Schleife braucht früh echte Wiederholungsaufgaben und einen wirtschaftlichen Käufer. | Eine Liste mit Firma, CTO/AI-Owner, vermutetem wiederholtem Workflow, sichtbarem Spend-Signal und Einführungsweg. | 4 Std. |
| 10 | Fünf persönliche Einführungsanfragen senden und einen Wochenreview mit Entscheidung “weiter, enger testen oder stoppen” terminieren. | Vertrieb muss denselben Belegstandard wie das Produkt erfüllen; ungeprüfte Plattformarbeit darf nicht wieder einziehen. | Fünf konkrete Gesprächstermine oder Antworten sowie ein priorisierter Backlog, aus dem alles Nicht-POC-relevante entfernt ist. | 2 Std. |

**Gesamtaufwand: etwa 36 Stunden.**

## Nicht diese Woche

- Keine Thinkery-Control-Plane, SSO, zentrale Evidenz, Team-Dashboard oder geplantes AutoTune.
- Kein Marketplace, keine öffentliche Registry, kein Publisher-Programm und keine vier zusätzlichen Kits.
- Keine öffentliche Preis- oder API-Veröffentlichung, die nicht dem tatsächlich lieferbaren POC entspricht.
