# LeanCTX / Thinkery AG

## Kontext-Performance für KI-Agenten

**LeanCTX ist das Context SDK für KI-Agenten.** Es hilft Teams, den Kontext eines bestehenden Agenten gezielt auszuwählen, zu komprimieren, wiederzuverwenden und bei Bedarf präzise wiederherzustellen. Der Agent, das Modell, der Provider und der bestehende Workflow bleiben beim Kunden. LeanCTX ersetzt keine Agent-Plattform, kein Gateway, keine Observability- oder Evaluation-Lösung.

### Das Problem

Bei produktiven Agenten entsteht ein grosser Teil von Kosten, Latenz und Unzuverlässigkeit vor dem Modellaufruf: wiederholte Datei-Reads, breite Suchresultate, lange Shell-Ausgaben, veralteter Verlauf und doppelte Hand-offs. Weniger Tokens allein sind jedoch kein Geschäftsnutzen, wenn das Ergebnis schlechter wird.

### Die Lösung

LeanCTX macht Kontext zu einer messbaren Performance-Oberfläche:

**Verbinden → Messen → Optimieren → Belegen → Deployen → Wiederholen**

Ein Team verbindet einen bestehenden Coding- oder Custom-Agenten, definiert einen echten Workload und misst zunächst die Baseline. LeanCTX testet anschliessend eine transparente Kontextstrategie. Nur wenn der optimierte Lauf dieselbe vorab definierte Qualitätsgrenze erfüllt, wird das Ergebnis als Kandidat für ein Deployment akzeptiert.

Das wiederverwendbare Ergebnis ist ein versioniertes Tuning Profile. Es enthält die geprüfte Kontextstrategie samt Budget, Auswahl-, Kompressions- und Recovery-Regeln. Ein Context Kit ergänzt dafür einen konkreten Workflow, zum Beispiel Code Review.

### Beleg statt Marketing

LeanCTX trennt drei Dinge sauber:

- Provider-gemeldete Nutzung
- Berechnete Provider-Kosten anhand einer versionierten Preistabelle
- Später optional abgeglichene Rechnungs-Kosten

Eine Savings-Aussage benötigt eine vergleichbare Baseline, denselben Workload, eine deklarierte Qualitätsprüfung, eine dokumentierte Methode und einen signierten Evidence Bundle. Dieser kann lokal und offline geprüft werden, ohne Quellcode, Prompts oder Credentials standardmässig offenzulegen.

Ein kontrollierter fünfteiliger Code-Review-Referenzbenchmark zeigte ungefähr 79–86 % niedrigere berechnete API-Kosten. Das ist ein methodisch eingegrenztes Referenzergebnis — keine Zusage für jeden Kunden. Der kommerzielle Prüfwert ist strenger: mindestens 40 % niedrigere Verified Cost per Successful Agent Task, ohne Qualitätsverlust, auf einem vom Kunden freigegebenen Workload.

### Warum jetzt

Agenten nutzen mehr Tools, Code, Retrieval, Logs und Hand-offs. Damit wachsen Kosten und Risiko nicht nur mit dem Modell, sondern mit dem Kontext, den der Agent vor jeder Inferenz erhält. LeanCTX adressiert genau diese vorgelagerte Schicht und ergänzt die vorhandene Agent-, Gateway-, Eval- und Observability-Landschaft.

### Geschäftsmodell und nächste Etappe

Die lokale Runtime, SDK-Grundlagen, lokale Messung, manuelles Tuning und Offline-Verifikation bleiben offen und lokal nutzbar. Bezahlt wird später für kontinuierliches Tuning, gemeinsame Profile und Evidenz, Organisations-Governance sowie operierte Infrastruktur.

Der nächste Schritt ist bewusst klein: ein begrenzter Agent Tuning Sprint für einen Kunden-Workflow. Geliefert werden Baseline, Qualitätsvertrag, Tuning Profile, signierter Beleg und eine klare Entscheidung: ausrollen, enger testen oder stoppen. Zuerst muss dieser Loop für einen echten Kunden wiederholbar funktionieren; Marketplace, breite Cloud-Plattform, Managed Execution und autonomes AutoTune sind danach mögliche, nicht heutige Versprechen.

**Kernfrage für einen Kunden oder Partner:**  
Welcher bestehende Agenten-Workflow läuft häufig genug, dass eine qualitätsgesicherte Senkung der Kosten pro erfolgreicher Aufgabe in diesem Quartal relevant wäre?
