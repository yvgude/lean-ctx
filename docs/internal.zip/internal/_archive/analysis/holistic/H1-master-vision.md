# LeanCTX — Definitive Holistic Vision

> **Status:** Canonical product and company vision.
>
> **Authority:** This document synthesizes the strategy repository.
>
> **Precedence:** `SDK-STRATEGY-ALL-IN-ONE.md` governs when sources disagree.
>
> **Date convention:** Statements labelled `now` describe the current wedge.
>
> **Rule:** Product targets are not claims; claims require declared evidence.

---

# 1. One-page Executive Summary

LeanCTX is the **Context SDK for AI Agents**.

It tunes the context path of an existing agent.

It does not replace the agent.

It does not try to become a generic agent-builder.

Its promise is simple:

> **Tune any agent. Prove every gain.**

The product category is context performance.

Context performance is the measurable relationship between:

- context selection;
- context transformation;
- context reuse;
- context recovery;
- cost;
- latency;
- reliability; and
- successful task outcomes.

LeanCTX starts where real value is already visible.

That wedge is coding agents and custom agent workflows with measurable context
and cost waste.

Claude Code, Codex, and Cursor remain first-class integration targets.

The product does not demand that a developer abandon a preferred agent.

Instead, it attaches to, wraps, or embeds inside that agent.

The canonical customer journey is a loop:

> **Connect → Measure → Tune → Prove → Deploy → Repeat.**

The loop begins with a real workload rather than a synthetic dashboard.

It produces a baseline before any performance claim.

It applies a versioned tuning strategy.

It validates quality against a predeclared bar.

It records the result in an inspectable receipt and evidence bundle.

It deploys a portable profile or kit back into the customer’s workflow.

It repeats when workload, model, policy, or economics change.

The company’s business North Star is **Verified Cost per Successful Agent Task**
(`VCP-SAT`).

The metric is intentionally quality-conditioned.

Lower token or API spend is not a gain if task quality regresses.

The initial commercial proof threshold is at least 40% lower VCP-SAT with no
quality regression on a declared workload and baseline.

The existing controlled result of approximately 79–86% lower calculated API
cost is evidence of potential under its declared methodology.

It is not a universal product promise.

The technology strategy is open-core without a crippled core.

The local Runtime, SDK, local tuning, coding-agent integrations, open
contracts, local profiles, kits, and inspectable receipts remain OSS.

Paid value begins where the product becomes continuous, shared, managed, or
organization-scale:

- continuous AutoTune;
- cross-run intelligence;
- team policy and governance;
- private fleet operations;
- enterprise controls and accountability; and
- managed infrastructure when the evidence gates justify it.

Thinkery AG is the company and commercial operator.

LeanCTX is the developer-facing product and brand.

The immediate cash product is the **Agent Tuning Sprint**.

It puts one production agent on the Dyno, creates a baseline, tunes the context
path, validates quality, and leaves behind a deployable profile plus evidence.

The early design partner is a Swiss B2B SaaS, fintech, consulting, or industrial
team with 10–50 developers, visible BYOK/API spend, and at least 100 repeated
coding-agent tasks per week.

The strategic moat is not a single compression algorithm.

It is ownership of the full performance loop:

> **workload → context strategy → outcome → evidence → retuning.**

This master vision resolves legacy ambiguity as follows:

- LeanCTX owns context performance, not generic orchestration.
- Coding-agent distribution remains first-class, even as custom agents deepen
  enterprise value.
- Local-first OSS remains the adoption engine, not a free trial disguised as
  open source.
- Dyno is the canonical evidence path; no parallel proof systems emerge.
- Context Kits use `.ctxpkg`; no competing package format is introduced.
- Managed Relay, Managed Execution, and a marketplace are deliberately later.
- A narrow real Playground precedes any broad cloud platform.

The outcome sought by the first 90 days is concrete:

> A developer can install LeanCTX, tune a supported coding or custom agent,
> produce a verified before/after result, and deploy a versioned profile.

---

# 2. Product Identity

## 2.1 The public descriptor

LeanCTX is **The Context SDK for AI Agents**.

That descriptor is frozen.

It says what LeanCTX is without promising an entire agent stack.

## 2.2 The product promise

LeanCTX helps a team tune an agent’s context path and prove the resulting gain.

The promise is:

> **Tune any agent. Prove every gain.**

The promise has two equal halves.

`Tune` means LeanCTX can select, compress, reuse, recover, and measure context.

`Prove` means LeanCTX can compare a declared treatment with a declared baseline.

Neither half is optional.

Optimization without proof is marketing.

Measurement without a deployable tuning action is observability alone.

## 2.3 The mental model

LeanCTX is the tuner for AI agents.

The useful analogy is a performance tuner, not an autopilot.

The agent remains the vehicle.

The model provider remains the engine supplier.

The application remains the customer’s product.

LeanCTX improves how the agent sees, carries, reuses, and validates context.

This positioning keeps the product focused on a technically durable layer.

It also prevents accidental drift into an agent framework or a chatbot suite.

## 2.4 The mission

Make agent context a measurable, tunable, and deployable performance surface.

Make proof native to the workflow.

Make the best local optimization capabilities available without account gating.

Make organization-scale learning and control worth paying for.

## 2.5 What LeanCTX is not

LeanCTX is not a foundation-model provider.

LeanCTX is not a generic agent builder.

LeanCTX is not a generic agent orchestrator.

LeanCTX is not a replacement IDE.

LeanCTX is not a prompt library with a billing page.

LeanCTX is not a cloud-first wrapper around a local open-source product.

LeanCTX is not an unqualified “save 80%” claim.

LeanCTX is not a marketplace before it has a repeatable proof loop.

## 2.6 The current wedge

Now, LeanCTX focuses on coding-agent context efficiency and verified savings.

The next expansion is custom agent workflows that expose the same loop.

Later expansion is organization-scale context performance infrastructure.

The product expands by integration depth and evidence maturity.

It does not expand by collecting unrelated AI features.

## 2.7 Brand architecture

**Thinkery AG** is the company.

Thinkery owns commercial contracting, services, enterprise operations, and the
paid product surface.

**LeanCTX** is the product and developer-facing brand.

LeanCTX is the name developers install, integrate, evaluate, and recommend.

**Context performance** is the category that explains the value.

## 2.8 Language discipline

Use “context performance” when describing the category.

Use “tune” when describing a product action.

Use “receipt” and “evidence” when describing proof.

Use “verified” only for a result with a declared baseline, workload, quality bar,
method, and receipt status.

Do not use “guaranteed savings.”

Do not use “universal optimization.”

Do not imply provider neutrality means identical results across providers.

---

# 3. Product Architecture

## 3.1 Architectural thesis

One Rust context engine underlies every LeanCTX surface.

One runtime serves local tools, coding-agent adapters, SDK integrations, and
future commercial control planes.

One object model crosses local use, team use, and enterprise use.

One receipt and evidence path prevents incompatible measurement stories.

One profile and one kit format carry optimized behavior across surfaces.

## 3.2 Complete stack diagram

```text
┌──────────────────────────────────────────────────────────────────────────┐
│ Customer agent surfaces                                                   │
│                                                                          │
│  Claude Code   Codex   Cursor   Custom agent   CI / worker   Playground │
└────────────┬───────────┬───────────┬─────────────┬────────────┬─────────┘
             │           │           │             │            │
             └───────────┴───────────┴─────────────┴────────────┘
                                      │
                    Integration depth: Attach | Wrap | Embed | Run later
                                      │
┌─────────────────────────────────────▼────────────────────────────────────┐
│ LeanCTX SDK and adapter layer                                             │
│                                                                          │
│ LeanCTX() | session() | wrap() | load_kit() | receipt()                  │
│ Adapters | conformance | policy boundaries | provider-neutral interfaces │
└─────────────────────────────────────┬────────────────────────────────────┘
                                      │
┌─────────────────────────────────────▼────────────────────────────────────┐
│ LeanCTX Runtime                                                          │
│                                                                          │
│ Session lifecycle | execution hooks | local cache | profiles | receipts │
│ local identity | safe policy enforcement | cost and outcome observation  │
└───────────────┬───────────────────────────┬──────────────────────────────┘
                │                           │
┌───────────────▼───────────────┐ ┌─────────▼──────────────────────────────┐
│ Context Engine                │ │ Context Planning                       │
│                               │ │                                      │
│ Select | Compress | Reuse     │ │ Workload → strategy → profile         │
│ Recover | Measure             │ │ constraint-aware action selection      │
└───────────────┬───────────────┘ └─────────┬──────────────────────────────┘
                │                           │
                └──────────────┬────────────┘
                               │
┌──────────────────────────────▼───────────────────────────────────────────┐
│ Portable product objects                                                   │
│                                                                          │
│ ContextSession | TuningProfile | ContextKit (.ctxpkg) | Receipt | Bundle │
└───────────────┬──────────────────────────────┬────────────────────────────┘
                │                              │
┌───────────────▼───────────────┐ ┌────────────▼───────────────────────────┐
│ LeanCTX Dyno                  │ │ Commercial organization layer          │
│                               │ │                                      │
│ Baseline | treatment | quality │ │ AutoTune | team governance | enterprise│
│ anti-cheating | evidence       │ │ private operations | managed services  │
└───────────────────────────────┘ └────────────────────────────────────────┘
```

## 3.3 Surface-to-runtime guarantee

CLI use is a local coding-agent workflow surface.

MCP use makes context tools available inside existing coding agents.

The SDK is the explicit application integration surface.

Adapters make provider and agent-specific conventions conform to one runtime.

All surfaces use the same session, profile, kit, receipt, and evidence concepts.

No surface receives a separate “lite” evidence story.

## 3.4 Context Engine responsibilities

The Context Engine is responsible for selecting relevant context.

It is responsible for compressing context when policy permits.

It is responsible for reusing valid context rather than recreating it.

It is responsible for recovering context when a task needs previously omitted
detail.

It is responsible for measuring the context path and its effects.

It must preserve declared policy boundaries.

It must not obscure transformations from receipts or evidence.

## 3.5 Context Planning responsibilities

Context Planning decides how the engine should act for a workload.

It takes the workload, constraints, policy, and historical evidence as inputs.

It proposes or applies a tuning strategy through a TuningProfile.

It selects a ContextKit when reusable assets are appropriate.

It does not claim an outcome before Dyno or an equivalent declared validation.

## 3.6 Runtime responsibilities

The Runtime owns local execution lifecycle and integration behavior.

The Runtime creates and manages a ContextSession.

The Runtime applies policy-approved transformations.

The Runtime observes cost, context, execution, and outcome signals.

The Runtime materializes local profiles, kits, and receipts.

The Runtime remains useful without a cloud account.

## 3.7 SDK responsibilities

The SDK gives builders a stable, explicit way to use the Runtime.

The SDK exposes the product primitives rather than internal engine details.

The SDK makes integration depth intentional.

The SDK makes evidence collection possible from day one.

The SDK remains provider-neutral at the contract layer.

The SDK does not become a universal agent orchestration framework.

## 3.8 Canonical public SDK primitives

`LeanCTX()` initializes LeanCTX for a project and chosen integration.

`session()` creates or accesses a ContextSession.

`wrap()` applies LeanCTX around an existing agent or callable boundary.

`load_kit()` loads a versioned ContextKit.

`receipt()` retrieves or emits the execution proof artifact.

These five primitives are the public conceptual minimum.

Additional APIs must reinforce, not fragment, this model.

## 3.9 Repository and dependency direction

`lean-ctx` owns the open Runtime, SDK, engine, local integrations, and public
contracts.

`lean-ctx-enterprise` owns enterprise-grade controls that depend on the core.

`lean-ctx-cloud` owns commercial cloud services that depend on the core.

`thinkery` owns company-facing product, commercial, and web concerns.

Dependencies flow from commercial layers toward the OSS core.

The OSS core must not depend on a proprietary control plane to function.

Commercial features may enrich, coordinate, or operate the core.

They may not hollow it out.

## 3.10 Architecture invariants

The same profile means the same declared strategy across supported surfaces.

The same kit means the same package format across supported surfaces.

The same evidence rule means cost claims remain comparable.

The same receipt contract means local and hosted proof can be reconciled.

Every adapter must preserve session identity and evidence semantics.

Every adapter must apply only policy-approved transformations.

Every adapter must observe success, failure, and relevant cost signals.

---

# 4. The Canonical Loop

## 4.1 Loop definition

The LeanCTX product is a loop, not a setting.

```text
Connect → Measure → Tune → Prove → Deploy → Repeat
```

Each stage has a distinct customer outcome.

Each stage produces an artifact for the next stage.

Each stage has a stop condition that prevents dishonest optimization.

## 4.2 Connect

Connect means bring a real agent and workload into LeanCTX.

Connection can happen through Attach, Wrap, or Embed.

The agent preserves its identity and normal user experience.

The connection declares the integration, provider, model, and workload boundary.

The output is an addressable ContextSession with a declared scope.

Do not begin by asking the user to rebuild their agent.

## 4.3 Measure

Measure establishes the baseline before a tuning claim exists.

The baseline records provider-reported usage where available.

It records calculated provider cost using declared price provenance when needed.

It distinguishes calculated cost from invoice-reconciled cost.

It records latency, context behavior, task outcome, and quality result.

It uses a predeclared quality bar.

The output is a baseline receipt and workload manifest.

## 4.4 Tune

Tune applies a declared context strategy.

The strategy may select, compress, reuse, recover, or change context policy.

The strategy is represented by a versioned TuningProfile.

Reusable resources are captured in a ContextKit where appropriate.

Tuning cannot silently modify the workload or quality criterion.

The output is a treatment configuration that can be reproduced.

## 4.5 Prove

Prove compares treatment against baseline on declared evidence.

The comparison rejects a cost win that fails quality.

The comparison rejects a result whose baseline is absent or incompatible.

The comparison exposes provider-reported, calculated, and reconciled economics.

The comparison produces an ExecutionReceipt and an EvidenceBundle.

The Dyno is the canonical pathway for this proof.

## 4.6 Deploy

Deploy makes a validated strategy operational.

It deploys a versioned TuningProfile to the relevant agent surface.

It installs or references ContextKits through `.ctxpkg`.

It preserves the profile version, policy context, and evidence lineage.

It does not turn a one-off experiment into an undocumented production change.

The output is a repeatable performance configuration.

## 4.7 Repeat

Repeat monitors for workload, model, provider, policy, or cost change.

It invokes new measurement before declaring the previous gain still holds.

It creates the data needed for future AutoTune.

It is the bridge between local OSS tuning and paid continuous intelligence.

It turns evidence from a report into a performance operating system.

## 4.8 Loop gates

No “prove” step without a declared baseline.

No “deploy” step without a versioned profile or equivalent explicit strategy.

No “verified” label without a receipt and quality result.

No AutoTune claim before the loop works manually and repeatedly.

No managed product before the local and team seams are evidence-backed.

---

# 5. Integration Depths

## 5.1 The integration ladder

Integration depth is a product choice, not a maturity contest.

Each depth gives LeanCTX more control and responsibility.

Each depth must preserve the canonical object model and evidence semantics.

```text
Attach  →  Wrap  →  Embed  →  Run later
lowest intrusion                       highest responsibility
```

## 5.2 Attach

Attach is the lowest-friction entry point.

It connects through MCP, proxy, CLI, or a supported coding-agent integration.

It works with the agent a developer already prefers.

It prioritizes adoption, observation, local context improvement, and evidence.

Attach is the primary coding-agent distribution path.

Attach does not require LeanCTX to own the agent loop.

Attach must keep Claude Code, Codex, and Cursor first-class.

## 5.3 Wrap

Wrap places LeanCTX around an existing custom agent or callable boundary.

It can create an implicit or explicit ContextSession.

It observes the execution more completely than Attach.

It applies only policy-approved transformations.

It is appropriate when a team owns a repeatable agent workflow but not every
internal context operation.

Wrap must leave the customer’s agent identity intact.

## 5.4 Embed

Embed uses the SDK directly within a customer-owned agent or application.

It gives the builder deliberate access to sessions, profiles, kits, and receipts.

It is the deepest current product integration.

It supports the strongest proof and the most deployable tuning strategy.

Embed is not a requirement for initial adoption.

Embed is the strategic seam for serious custom-agent and enterprise workflows.

## 5.5 Run — later

Run means LeanCTX participates in operating a managed execution surface.

Run is deliberately later.

It is not permission to build a generic Agent Builder.

It requires demonstrated demand, operational controls, private-workload safety,
clear margins, and a validated evidence contract.

Until those gates pass, LeanCTX helps customers run their own agents better.

## 5.6 Integration-depth benchmark

Choose Attach when adoption friction is the primary constraint.

Choose Wrap when existing workflows need consistent policy and observation.

Choose Embed when builders need programmatic performance control.

Consider Run only when managed execution creates additional, evidenced value.

Never force a deeper integration merely to increase account control.

## 5.7 Conformance requirements

Every integration declares its depth.

Every integration maps executions to a ContextSession.

Every integration can produce a receipt appropriate to the available signals.

Every integration preserves provider-usage provenance when available.

Every integration marks missing signals rather than fabricating precision.

Every integration respects local policy and privacy boundaries.

---

# 6. Key Objects

## 6.1 Object model principle

LeanCTX becomes a platform by making performance artifacts portable.

The key objects are small enough to understand locally.

They become more valuable when they connect evidence across time and teams.

## 6.2 `LeanCTX`

`LeanCTX` is the SDK entry point and product boundary.

It binds a project or application to a selected integration mode.

It resolves local configuration and policy.

It makes the Runtime available to the host agent or application.

It is not itself an agent.

It does not own generic planning or tool orchestration.

## 6.3 `ContextSession`

`ContextSession` is the addressable unit of context-aware execution.

It binds a workload to an integration, runtime policy, and observation stream.

It records the relevant execution lifecycle.

It gives receipts and profiles a stable reference point.

It may be explicit in Embed integrations.

It may be implicit in compatible Wrap integrations.

It must never be invisible to evidence semantics.

## 6.4 `TuningProfile`

`TuningProfile` is the versioned strategy for context performance.

It declares how LeanCTX should act for a workload class.

It can include selection, compression, reuse, recovery, and measurement policy.

It records compatibility, constraints, and version lineage.

It is a first-class product object, not an internal configuration blob.

It is deployable after proof.

It is comparable across versions.

It is the object AutoTune will eventually propose and improve.

## 6.5 `ContextKit`

`ContextKit` is a portable package of reusable context assets and instructions.

It is distributed through the `.ctxpkg` format.

There is no parallel package system.

A kit makes repeated context assembly more reliable and more inspectable.

A kit is not an opaque prompt bundle that hides its operational purpose.

A kit declares version and compatibility.

A kit may be open, private, or organization-governed according to its contents.

## 6.6 `ExecutionReceipt`

An `ExecutionReceipt` is the atomic proof record for an execution or comparison.

It contains identity information.

It contains execution information.

It contains context information.

It contains economics information.

It contains outcome and quality information.

It contains evidence status and provenance.

It distinguishes measured facts from calculated values.

It makes verification possible without exposing private payloads unnecessarily.

## 6.7 `SavingsReceipt`

A `SavingsReceipt` is a comparison-oriented view of baseline and treatment.

It is valid only when the comparison contract is declared.

It names the workload and quality bar.

It records the cost vocabulary used.

It makes claim scope visible.

It is a useful form of receipt, not a second evidence architecture.

## 6.8 `EvidenceBundle`

An `EvidenceBundle` collects the materials needed to inspect a performance claim.

It includes the workload manifest.

It includes baseline and treatment receipts.

It includes profile and kit versions where relevant.

It includes quality method and result.

It includes price provenance and provider usage provenance where relevant.

It includes signatures or verification status when supported.

It is the unit that supports internal review, customer proof, and future learning.

## 6.9 Object relationships

```text
LeanCTX
  └── starts or joins ContextSession
        ├── applies TuningProfile
        ├── loads ContextKit (.ctxpkg)
        ├── emits ExecutionReceipt
        └── contributes to EvidenceBundle

Baseline ContextSession + Treatment ContextSession
  └── produce a comparison / SavingsReceipt
        └── establishes or rejects a verified VCP-SAT claim
```

## 6.10 Versioning rule

Profiles, kits, receipt contracts, and evidence schemas require explicit
versions.

Version changes must preserve a migration or compatibility story.

An evidence bundle always identifies the object versions it evaluates.

No invisible prompt or policy mutation may be presented as a stable profile.

---

# 7. North-Star Metric: VCP-SAT

## 7.1 Definition

VCP-SAT means **Verified Cost per Successful Agent Task**.

```text
VCP-SAT = provider-reported net LLM cost
          ─────────────────────────────────────────
          tasks passing the predeclared quality bar
```

Where provider-reported net LLM cost is unavailable, a calculation may be used.

The calculation must identify the model, pricing snapshot, and methodology.

Invoice reconciliation is a stronger but distinct cost evidence level.

## 7.2 Why this is the North Star

It joins economics and useful outcomes.

It resists optimization theater based on token count alone.

It gives engineering, AI platform, FinOps, and leadership a common language.

It makes quality loss visible rather than hidden in an average-cost chart.

It anchors product, sales, and AutoTune around the same objective.

## 7.3 Verification conditions

A VCP-SAT comparison requires a declared baseline.

It requires a declared workload manifest.

It requires a predeclared quality bar.

It requires a compatible treatment configuration.

It requires a receipt and evidence status.

It requires transparent cost vocabulary.

It requires no quality regression for a claimed performance gain.

## 7.4 Cost vocabulary

**Provider-reported usage** is usage reported by the provider.

**Calculated provider cost** applies a declared provider price snapshot to usage.

**Reconciled invoice cost** reconciles records against invoice or billing data.

These values are not interchangeable.

All reports must say which one they use.

## 7.5 Quality vocabulary

Coding quality must be defined before the run.

Research quality must be defined before the run.

Support quality must be defined before the run.

Regulated-workflow quality must be defined before the run.

LeanCTX reports the declared quality method; it does not invent a universal one.

## 7.6 Commercial threshold

The near-term commercial threshold is at least 40% lower VCP-SAT.

The result must have no quality regression.

The result must be tied to a declared workload and baseline.

The threshold is a decision gate, not an automatic customer guarantee.

## 7.7 Claim governance

Class A: current product facts may state what exists now.

Class B: controlled benchmarks may state method, workload, and measured result.

Class C: customer observations require customer and scope permission.

Class D: product targets must be named as targets.

Class E: strategic theses must be named as theses.

No class may be upgraded by marketing language alone.

## 7.8 The controlled benchmark

The current controlled evidence uses three five-turn coding-agent scenarios.

It uses real OpenAI API calls under the declared methodology.

The tested treatment produced approximately 79–86% lower calculated API cost
than the baseline in those scenarios.

The valid claim includes the conditions above.

The invalid claim is “LeanCTX always saves 79–86%.”

---

# 8. What We Own vs. What We Do Not Own

## 8.1 LeanCTX owns

LeanCTX owns context performance as a product category.

LeanCTX owns the context engine.

LeanCTX owns context planning and tuning profiles.

LeanCTX owns the portable `.ctxpkg` ContextKit contract.

LeanCTX owns the canonical receipt and evidence path.

LeanCTX owns Dyno as the evidence and validation product.

LeanCTX owns integration conformance for supported surfaces.

LeanCTX owns the performance loop and its commercial extension.

## 8.2 The customer owns

The customer owns its agent identity.

The customer owns its application and business workflow.

The customer owns its provider account, data, policies, and deployment choices.

The customer owns its task-level quality definition.

The customer decides when a validated profile becomes production policy.

LeanCTX improves and evidences the context path without usurping this ownership.

## 8.3 Providers own

Model providers own model capability, API behavior, pricing, and usage reporting.

LeanCTX is provider-neutral at the product contract layer.

Provider neutrality does not require equal fidelity or identical economics across
every provider.

LeanCTX records provider-specific provenance rather than hiding it.

## 8.4 We explicitly do not own

We do not own generic model routing as a standalone category.

We do not own generic multi-agent orchestration.

We do not own the customer’s prompt authoring culture.

We do not own a universal quality metric.

We do not own an opaque benchmark monopoly.

We do not own a cloud account as a prerequisite for local value.

## 8.5 Why the boundary matters

The boundary keeps LeanCTX composable.

The boundary keeps the open core credible.

The boundary keeps customer adoption low-friction.

The boundary keeps the commercial layer focused on continuous, shared value.

The boundary prevents the roadmap from following every AI platform trend.

---

# 9. OSS vs. Paid: Final Boundary

## 9.1 Strategic principle

The engine stays open.

The OSS offering must be strong enough to create real developer success.

The paid offering must sell a higher-order operating capability, not an
artificially withheld local feature.

## 9.2 OSS Runtime

The local Runtime remains OSS.

The SDK remains OSS.

The context engine remains OSS.

Local context selection, compression, reuse, recovery, and measurement remain
OSS.

Supported coding-agent integrations remain OSS.

Local profiles remain OSS.

Local ContextKits remain OSS.

Local receipts and the public evidence contract remain OSS.

Local-first use remains available without account gating.

## 9.3 Open contracts

The profile contract is open.

The `.ctxpkg` kit contract is open.

The receipt and evidence schemas are open.

The conformance rules for integrations are open.

Open contracts make LeanCTX a credible substrate rather than a lock-in trap.

## 9.4 Paid: continuous intelligence

Continuous AutoTune is paid.

Cross-run learning is paid when it operates beyond a local developer workflow.

Historical performance intelligence at organization scale is paid.

Recommendation, experimentation, and continuous retuning infrastructure are
paid when they consume proprietary operational intelligence.

## 9.5 Paid: team and organization value

Shared governance is paid.

Policy distribution and approval workflows are paid.

Team-wide evidence dashboards are paid.

Private asset operations are paid.

Organization-level profile and kit lifecycle management is paid.

## 9.6 Paid: enterprise and managed value

Enterprise controls and accountability are paid.

Private deployment support and managed infrastructure are paid.

Audit-oriented operational features are paid.

Managed Relay is paid only when it is later justified and shipped.

Managed Execution is paid only when it is later justified and shipped.

Neither is a near-term assumption.

## 9.7 Feature classification

Class A — OSS Runtime:

- local engine;
- SDK;
- local integrations;
- local tuning; and
- local evidence.

Class B — Open Contract:

- profile;
- kit;
- receipt;
- bundle; and
- conformance schemas.

Class C — Public reference or intelligence freeze:

- reference implementations;
- public methodology; and
- static, publishable examples.

Class D — Proprietary system:

- continuous AutoTune;
- shared governance;
- organization control; and
- managed operations.

Class E — Strategic data:

- anonymized or permissioned performance intelligence;
- cross-run learning artifacts; and
- organization-private operational data.

## 9.8 Customer-facing rule

Use LeanCTX locally and openly to tune your agent.

Pay Thinkery when you want LeanCTX to learn continuously, operate across your
organization, govern shared assets, or run managed infrastructure for you.

## 9.9 Privacy and margin commitments

No hosted feature silently exfiltrates private task payloads.

Evidence should preserve enough provenance to verify a claim without requiring
unnecessary payload retention.

Managed infrastructure must have a clear value and margin model before launch.

Service work is priced separately from recurring product subscriptions.

---

# 10. Frozen Decisions

## D-001 — Public descriptor

LeanCTX public descriptor: **The Context SDK for AI Agents.**

## D-002 — Product promise

LeanCTX product promise: **Tune any agent. Prove every gain.**

## D-003 — Category boundary

LeanCTX owns context performance, not generic agent orchestration.

## D-004 — Integration taxonomy

The integration taxonomy is Attach, Wrap, Embed, and Run later.

## D-005 — Coding-agent priority

Claude Code, Codex, and Cursor remain first-class.

## D-006 — Canonical evidence product

The real-world evidence path converges into **LeanCTX Dyno**.

## D-007 — Business North Star

The North Star is **Verified Cost per Successful Agent Task**.

## D-008 — Profile object

`TuningProfileV1` becomes a first-class product object.

## D-009 — Kit format

Context Kits use `.ctxpkg`; no parallel package system is created.

## D-010 — Evidence path

There is one canonical receipt and evidence path.

## D-011 — OSS core

Strong local Runtime, SDK, and tuning remain OSS.

## D-012 — Commercial layer

Continuous AutoTune and organization-scale intelligence are commercial.

## D-013 — Company and product brands

Thinkery AG is the company and commercial operator.

LeanCTX remains the developer-facing brand.

## D-014 — Near-term B2B cash product

The primary near-term B2B cash product is the **Agent Tuning Sprint**.

## D-015 — Playground sequencing

Ship a narrow real Playground before a broad cloud platform.

## D-016 — Managed Relay

Managed Relay is later.

## D-017 — Managed Execution

Managed Execution is later and is not a generic Agent Builder.

## D-018 — Marketplace

Marketplace is deferred.

## D-019 — Competitive strategy

Own the workload → context strategy → outcome → evidence → retuning loop.

## D-020 — New-feature discipline

Every material feature must state:

- its user;
- the context problem;
- the measurable outcome;
- the product-loop step;
- the OSS or commercial classification; and
- the current work it displaces.

---

# 11. Anti-Roadmap

## 11.1 Product categories we do not build now

Do not build a generic Agent Builder.

Do not build generic multi-agent orchestration.

Do not build a broad cloud platform before a narrow Playground proves demand.

Do not build Managed Relay now.

Do not build Managed Execution now.

Do not build a marketplace now.

Do not build a universal benchmark product disconnected from real customer work.

Do not build a separate receipt system for each integration.

Do not build a parallel kit format.

Do not build account-gated local coding-agent integrations.

## 11.2 Commercial traps we avoid

Do not withhold the local engine merely to force conversion.

Do not sell token reduction without successful-task evidence.

Do not promise the controlled 79–86% result as a customer outcome.

Do not lead enterprise sales before the proof loop works repeatedly.

Do not create managed infrastructure with unclear privacy, unit economics, or
operational accountability.

Do not package bespoke consulting as a product subscription.

## 11.3 Technical traps we avoid

Do not fork the product object model by surface.

Do not let proprietary services become a dependency of local OSS use.

Do not hide policy changes inside unversioned prompt files.

Do not emit unverifiable savings claims.

Do not collapse provider-reported, calculated, and reconciled costs into one
ambiguous number.

Do not collect private data beyond what a declared feature requires.

## 11.4 Focus test

If a proposal does not improve Connect, Measure, Tune, Prove, Deploy, or Repeat,
it is presumed out of scope.

If it has no measurable VCP-SAT, quality, adoption, or proof impact, it is
presumed out of scope.

If it cannot state its OSS or commercial classification, it is not ready.

If it does not displace current work, it is not a priority.

---

# 12. Timeline: v1.0 → v4.0

## 12.1 Roadmap operating rule

Versions are evidence gates, not date promises.

Advance only when the previous loop is working on real workloads.

Build local proof before hosted control.

Build repeatability before scale.

Build managed execution last.

## 12.2 v1.0 — Prove the Context SDK

**Objective:** prove the loop for a real coding-agent workload.

Ship supported Attach integrations for first-class coding agents.

Ship the local Runtime and usable SDK primitives.

Ship Dyno foundation and the canonical receipt path.

Ship baseline and treatment methodology with anti-cheating rules.

Ship `TuningProfileV1` as a deployable object.

Ship the first `.ctxpkg` ContextKit path.

Run one real reference custom agent, narrowly scoped.

Offer the Agent Tuning Sprint in parallel with product work.

The first buyer is a 20–80-person B2B SaaS team with 100+ coding-agent tasks per
week; the practical first-90-day overlap is the Swiss target described below.

**Exit condition:** a developer can install, tune, prove, and deploy.

**Commercial gate:** a declared workload shows at least 40% lower VCP-SAT with
no quality regression, or the team learns why it does not.

**Park:** broad cloud, marketplace, generic orchestration, managed execution.

## 12.3 v2.0 — Repeat the proof loop

**Objective:** make v1 proof repeatable across more real agent contexts.

Harden Wrap and Embed integration paths.

Strengthen adapter conformance and coding-agent smoke coverage.

Make profiles and kits practical for versioned team use.

Ship a narrow Playground v0 that demonstrates real value.

Add BYOK-oriented Playground capability only after the local path is sound.

Introduce the Pro / Tuner commercial layer where continuous value is real.

Convert Sprint proof into repeatable team adoption.

**Exit condition:** repeatable evidence and deployment across more than one
customer or comparable workload class.

**Commercial gate:** recurrent product economics are margin-positive.

**Park:** broad hosted agent execution, broad marketplace, generic platform.

## 12.4 v3.0 — Operate context performance

**Objective:** turn repeated proof into an operating practice.

Introduce Team-level governance and shared asset lifecycle capabilities.

Introduce organization-scale evidence views where privacy permits.

Introduce AutoTune alpha only after manual tuning is demonstrably repeatable.

Operate private workload or local bridge capabilities only as needed by real
customers.

Make policy, approval, and evidence workflows valuable for AI platform teams.

**Exit condition:** customers use profiles, kits, and receipts as operational
artifacts rather than one-off evaluation outputs.

**Commercial gate:** AutoTune improves a declared objective without degrading
quality or violating governance constraints.

**Park:** generic agent hosting and unbounded managed operations.

## 12.5 v4.0 — Scale the performance operating system

**Objective:** scale proven performance operations responsibly.

Expand enterprise controls, accountability, and private operations.

Scale continuous intelligence with transparent data and governance boundaries.

Add managed relay only if customer demand, privacy controls, and margins pass.

Add managed execution only if it remains a context-performance extension rather
than a generic Agent Builder.

Evaluate a marketplace only after portable profiles and kits have durable demand,
clear trust rules, and a functioning developer ecosystem.

**Exit condition:** LeanCTX is a trusted operating layer for context performance
across many agents without sacrificing its open local core.

**Commercial gate:** scale is supported by durable retention, repeatable proof,
and healthy managed-service economics.

## 12.6 The first 90-day execution sequence

Phase 0: freeze vocabulary, contracts, decisions, and claim rules.

Phase 1: establish Dyno foundation.

Phase 2: build the smallest useful reference custom agent.

Phase 3: productize the SDK.

Phase 4: make coding-agent distribution excellent.

Phase 5: make Tuning Profiles deployable.

Phase 6: make Context Kits portable.

Phase 7: ship Playground v0.

Phase 8: sell Agent Tuning Sprints in parallel.

Later phases: BYOK / Pro, Team, then AutoTune alpha.

---

# 13. Commercial Model

## 13.1 Go-to-market thesis

Developers adopt LeanCTX because the open local engine removes the adoption tax.

They see a measurable before/after because Dyno makes the gain inspectable.

They bring evidence to their team because a receipt makes the result credible.

Teams pay when the loop becomes shared, continuous, governed, or operational.

## 13.2 Acquisition loop

Connect a coding agent.

Run a real workload.

See the context path and baseline.

Tune and prove a result.

Deploy the profile.

Share the receipt with the team.

Convert recurring performance work into a paid operating need.

## 13.3 Developer — Free

Developer remains free for the strong local OSS Runtime.

It includes supported coding-agent integrations.

It includes local tuning and local receipts.

It includes the open SDK, profile, kit, and evidence contracts.

It is a real product, not a time-limited funnel.

## 13.4 Pro / Tuner

Pro / Tuner serves the individual or small team with recurring tuning needs.

It may include paid continuous intelligence and richer repeated-evaluation value.

It must not simply repackage functionality deliberately removed from OSS.

The current go-to-market price reference is CHF 29 per month.

That price is a packaging hypothesis, not a frozen product decision.

## 13.5 Team

Team serves groups that share profiles, kits, receipts, and governance.

It creates value through coordination, visibility, and policy distribution.

The current go-to-market price reference is CHF 499 per month.

The tier earns its price through organization value, not seat-count cosmetics.

## 13.6 Business

Business serves teams with meaningful recurring agent workload and a need for
operational evidence.

It includes richer governance, organization intelligence, and support posture.

The current go-to-market price reference is CHF 2,499 per month.

Business is validated by repeatable proof and retention, not an aspirational
feature matrix.

## 13.7 Enterprise

Enterprise serves customers needing private operations, controls, accountability,
and contractual support.

The current go-to-market floor reference is from CHF 10,000 per month.

Enterprise scope is priced according to real operational obligations.

It follows evidence, security, and deployment gates.

## 13.8 Agent Tuning Sprint

The Agent Tuning Sprint is the primary near-term B2B cash product.

Its scope is one production agent or a narrow repeated agent workload.

The Sprint begins with baseline definition.

The Sprint integrates LeanCTX at the correct depth.

The Sprint develops a tuning strategy.

The Sprint validates quality and VCP-SAT.

The Sprint delivers a profile, receipts, evidence bundle, and recommended next
operating model.

The Sprint is paid professional delivery.

It is not misrepresented as recurring product revenue.

## 13.9 Design partner profile

The first 90-day target combines the best overlap from the source set.

Target a Swiss B2B SaaS, fintech, consulting, or industrial firm.

Prefer 10–50 developers inside a 20–80-person fast-moving company.

Require visible BYOK/API spend.

Require at least 100 repeated coding-agent tasks per week.

Prefer a CTO or AI-platform owner who can authorize a real pilot.

Avoid “exploration only” prospects with no measurable workload.

## 13.10 First three customers

Customer one is the proof customer.

Its job is to establish a credible real-world evidence narrative.

Customer two is the repeatability customer.

Its job is to prove the method travels beyond a single friendly environment.

Customer three is the expansion customer.

Its job is to prove team or organization value after the initial Sprint.

## 13.11 Buyer messages

For CTOs and VP Engineering: reduce waste without replacing the agent stack.

For AI Platform leads: version and govern context performance across agents.

For Engineering Managers: keep coding agents productive while making improvements
inspectable.

For CFOs and FinOps: connect API spend to successful work, not raw token charts.

For Security: retain customer control and make managed boundaries explicit.

## 13.12 Commercial sequencing

Sell the Sprint before selling a broad platform vision.

Use the Sprint to create a deployable profile and objective evidence.

Use repeat evidence to justify Pro or Team conversion.

Use organization-scale operational needs to justify Business or Enterprise.

Do not sell Managed Relay or Managed Execution before the relevant roadmap gates.

---

# 14. Success Conditions

## 14.1 Product success

A developer can install LeanCTX without a cloud account.

A developer can attach it to a supported coding agent.

A builder can wrap or embed it in a custom agent.

A real workload creates a baseline ContextSession.

A tuning strategy is captured in a versioned TuningProfile.

A reusable context asset is packaged as `.ctxpkg` when appropriate.

A treatment result produces a canonical receipt.

A verified claim produces an inspectable EvidenceBundle.

A validated profile can be deployed and repeated.

## 14.2 Evidence success

Every savings claim names its cost vocabulary.

Every verified claim has a baseline and quality bar.

Every controlled benchmark identifies its method and scope.

No quality regression is hidden by cost reporting.

The Dyno methodology resists changing the workload to manufacture a win.

Receipt schemas are stable enough for trust and evolution.

## 14.3 Distribution success

Claude Code, Codex, and Cursor integrations are excellent rather than nominal.

The OSS local path is useful enough to earn developer advocacy.

The first “holy-shit” moment is a visible, credible before/after result.

Developers can share a receipt without needing a sales call.

The Playground demonstrates real capability without pretending to be a full cloud.

## 14.4 Commercial success

The first Sprint generates paid proof.

At least one real workload meets the commercial evidence threshold or produces a
clear, high-value falsification of the hypothesis.

The second customer confirms repeatability.

The third customer confirms expansion potential.

Recurring paid tiers are based on continuous, shared, or managed value.

Service revenue and subscription revenue are measured separately.

## 14.5 Strategic success

LeanCTX is known for context performance, not generic AI sprawl.

The open core attracts developers without destroying commercial differentiation.

The evidence path earns trust without exposing unnecessary customer data.

The product object model survives every supported surface.

The moat deepens through profiles, evidence, performance metadata, integration
depth, and continuous retuning.

The company can say “no” to features outside the canonical loop.

## 14.6 Weekly operating questions

What real workload did we connect this week?

What baseline did we measure this week?

What profile did we improve or falsify this week?

What evidence became more credible this week?

What profile or kit became deployable this week?

What repeated customer behavior justifies a paid capability?

What did we stop so the loop could become stronger?

## 14.7 Final decision rule

LeanCTX wins by making agent context performance measurable and operational.

The product remains coherent when every investment strengthens the loop:

> **Connect → Measure → Tune → Prove → Deploy → Repeat.**

When in doubt, protect the open local engine.

When in doubt, require evidence before a claim.

When in doubt, preserve the customer’s agent.

When in doubt, build the next smallest thing that makes the loop more real.

---

# Appendix A — Reconciliation Record

## A.1 Authority hierarchy

The newest complete strategy is the canonical authority for decisions.

The strategy README is a navigation and structure aid.

The original plan contributes rationale and historical exploration.

The numbered vision documents contribute focused design detail.

The analysis documents identify contradictions, gaps, and final operating
questions.

Where an older source offers broader scope than the canonical strategy, the
canonical strategy limits scope.

## A.2 Resolved contradictions

**Identity:** “coding tool” language is resolved to Context SDK for AI Agents.

**Scope:** generic orchestration proposals are rejected in favor of context
performance ownership.

**Audience:** coding agents remain first-class; custom agents are the deeper
integration and enterprise path, not a replacement for developer distribution.

**Customer segment:** the first target is the overlap of the former segment
definitions: Swiss, fast-moving, 10–50 developers, visible spend, and 100+
repeated coding-agent tasks per week.

**Proof:** distinct benchmark ideas converge into Dyno, the one canonical
receipt and evidence path.

**Metric:** raw cost savings resolves to VCP-SAT, which requires quality.

**OSS:** local capability remains open; continuous, shared, and organization
value is paid.

**Cloud:** Playground is narrow and sequenced before any platform ambition.

**Managed products:** Relay and Execution are later, gated extensions.

**Packaging:** profiles and `.ctxpkg` kits are the only portable core objects.

**Commercial entry:** Agent Tuning Sprint is the immediate paid offer.

## A.3 Open questions are not product contradictions

Exact price points can change with evidence and packaging research.

Customer-specific quality bars must be declared per workload.

Managed infrastructure timing depends on security, demand, and margin gates.

Provider-specific coverage depends on maintained adapter conformance.

These are implementation and operating decisions inside this vision.

They do not reopen the frozen product identity or strategic boundary.

## A.4 Document completion standard

This document is definitive when used as a decision filter.

It should be updated only when a frozen decision is explicitly superseded.

Any superseding proposal must present evidence, displaced work, and a migration
story for the affected product objects and customer claims.
