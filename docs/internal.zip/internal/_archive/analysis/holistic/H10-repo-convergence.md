# H10 — Repository Convergence Plan

## Status

This is the definitive convergence plan for the LeanCTX repositories.

It is an implementation plan, not permission to delete code immediately.

Its governing rule is to converge responsibility, contracts, and releases.

It does not require merging every repository into one Git repository.

The strategy says exactly that convergence is not “one repository.”

The target is one owner per responsibility and one implementation per API.

This plan uses the current checkout as evidence.

Evidence date: 2026-08-20.

Checkout inspected: lean-ctx on branch main.

Current public GitHub head: 0f86871aa60aeccab03a6a7e3217e39ff1cb5c55.

## Scope

This plan covers the four Python SDK attempts.

It also covers cookbook/sdk because it is a related client implementation.

It covers the existing Rust workspace as the native runtime authority.

It records the GitHub, GitLab, deploy, Enterprise, Cloud, and Thinkery seams.

It does not authorize a Cloud deployment or a production database migration.

It does not assume a private repository’s unobserved implementation details.

## Important documentation finding

The requested all-in-one strategy file exists.

The checked-in file has a Technical Convergence chapter numbered 08.

Its source map identifies 23-REPO-CONVERGENCE.md as repo authority.

No standalone docs/internal/vision/23-REPO-CONVERGENCE.md exists in this checkout.

The current vision directory contains 00 through 04, the all-in-one bundle,

the strategy README, and the_plan.md.

Therefore this plan treats chapter 08 as the available convergence authority.

The missing standalone 23 document is itself a documentation-convergence defect.

Create it as a short extracted decision record after this plan is accepted.

Do not create a divergent second strategy document.

It should point back to the all-in-one chapter and this execution plan.

## Strategy constraints that govern every migration

LeanCTX owns public runtime, SDK core/contracts, local integrations,

ctxpkg/Kit tooling, local Tuning Profiles, local Dyno, and local evidence.

lean-ctx-enterprise owns private organization-scale authorization,

policy, evidence aggregation, self-hosted control, and enterprise deployment.

lean-ctx-cloud owns account lifecycle, organizations/workspaces,

hosted private registry, Pro/Team services, and cloud dashboard APIs.

Thinkery owns brand, website, product narrative, and cases.

The dependency direction is public lean-ctx, then Enterprise, then Cloud.

Public runtime must never depend on private code.

A Cloud outage must not break local LeanCTX.

Cloud is the canonical commercial billing owner.

Runtime observes usage, provider/model, and cost inputs.

Enterprise enforces operational budgets and local policy.

Cloud owns plans, Stripe, subscription state, and commercial entitlement lifecycle.

The canonical contract list includes TaskEnvelopeV1 and ContextEnvelopeV1.

It includes ExecutionReceiptV1, SavingsReceiptV1, and EvidenceBundleV1.

It includes TuningProfileV1 and ContextKitV1.

It includes PolicyDecisionV1, UsageObservationV1, and EntitlementV1.

Every contract requires one owner, schema, producer, consumer, version rule,

compatibility rule, fixture set, and deprecation rule.

These rules prohibit a “quick merge” that silently chooses incompatible APIs.

## Current state — repository topology

The repository root is not a Rust workspace root.

The Rust workspace root is rust/Cargo.toml.

That workspace already contains an engine crate and opt-in SDK crate.

Its comments explicitly keep default cargo build/test/clippy/publish scoped

to the engine unless lean-ctx-sdk or --workspace is selected.

The workspace includes rust/crates/lean-ctx-sdk.

It also includes lean-ctx-ocla and lean-ctx-protocol.

It contains grammar add-on crates and vendored dependencies.

This means the one-Rust-workspace target largely already exists.

The immediate Rust work is ownership cleanup and release discipline,

not a new workspace migration.

The public repository also contains clients/rust/lean-ctx-client.

That client is a separate language client package, not a second Rust workspace.

The public repository contains packages/node-lean-ctx.

It contains cookbook/sdk, a TypeScript HTTP client and conformance kit.

It contains four candidate Python SDK locations.

Those Python locations do not form one release surface today.

They use two distribution namespace families and two import namespace families.

## Current state — packages/python-lean-ctx

Location: packages/python-lean-ctx.

This is the intended canonical Python package per task direction.

Its distribution name is lean-ctx-sdk.

Its current version is 0.3.0.

Its declared Python floor is 3.9.

Its import namespace is lean_ctx.

Its stated purpose is SDK support for LeanCTX context compression for AI agents.

It has a README, conftest.py, package source, and dedicated tests.

It has 28 passing tests and one skipped test in this checkout’s Python 3.9 run.

That is the only Python candidate verified passing in this environment.

Its public surface exports LeanCtxClient.

It exports proxy compression support through ProxyClient and compress.

It exports CompressResult and typed LeanCtx errors.

It exports local discovery functions internally for daemon configuration.

It contains LiteLLM integration support.

It contains LangChain integration support.

It contains LlamaIndex integration support.

Its LeanCtxClient is a local CLI wrapper around the lean-ctx binary.

Its methods include read, search, shell, gain, and benchmark.

Its ProxyClient uses local HTTP endpoints for message compression.

Its discovery layer resolves the per-user local daemon port and session token.

It intentionally has no mandatory HTTP client dependency in the inspected manifest.

This package is product-shaped around local-first compression.

It is not yet the full public HTTP/OCLA client surface.

## Current state — clients/python

Location: clients/python.

Its distribution name is lean-ctx-client.

Its current version is 0.1.0.

Its declared Python floor is 3.9.

Its declared runtime dependency set is empty.

Its import namespace is leanctx.

This collides with py-sdk’s import namespace.

It is a thin dependency-free Python client for the HTTP /v1 contract.

It includes LeanCtxClient, HTTP/config/transport errors, and tool-result text.

It includes SSE/event support.

It includes a conformance scorecard and runner.

It includes OCLA types, wire helpers, verification, and an OCLA CLI.

It includes adapters for OpenAI, LangChain, LlamaIndex, and CrewAI.

Its README documents /v1 tools, events, context summary, event search,

and event-lineage operations.

Its test tree includes unit, live-adapter, conformance, OCLA CLI,

package, and wire tests.

The test command exits with code 2 in this local invocation.

The failure must be triaged under its supported interpreter/environment

before the code is judged unusable or removed.

This package is not disposable duplicated code.

It is named as a public contract path in security/public-build-policy-v1.json.

That policy currently treats clients/python/pyproject.toml as a public contract input.

Moving it changes the public clean-room policy and CI contract.

## Current state — py-sdk

Location: py-sdk.

Its distribution name is leanctx.

Its current version is 0.1.0.

Its declared Python floor is 3.10.

It requires httpx version 0.27 or later.

It has pytest and pytest-httpx development dependencies.

Its import namespace is leanctx.

That namespace is identical to clients/python’s namespace.

It is an OCLA wire API client attempt.

It exports a synchronous LeanCtxClient.

Its client exposes health, capabilities, envelope, and ledger_summary.

It defines OCLA-oriented dataclasses and enums.

Those include ContextPlanV1 and ContextReceiptV1.

They include PlanEntry, PlanBudget, QualitySignal, TokenBalance,

ContextPolicy, HealthResponse, ReceiptOutcome, and SensitivityLevel.

Its test command exits with code 2 in the current Python 3.9 invocation.

Python 3.9 is below this package’s stated support floor.

That result is an environment incompatibility signal, not a feature verdict.

The package has one direct repository build dependency.

scripts/validate-sdk-types.sh reads py-sdk/leanctx/types.py.

The script compares those Python types against OpenAPI and Go,

TypeScript, and Rust SDK type declarations.

Deleting py-sdk without moving or retargeting this source breaks that validator.

## Current state — python-sdk

Location: python-sdk.

Its distribution name is lean-ctx-ocla.

Its current version is 0.1.0.

Its declared Python floor is 3.10.

It requires httpx version 0.27 or later and pydantic version 2 or later.

Its import namespace is lean_ctx.

That namespace collides with packages/python-lean-ctx.

It is an asynchronous OCLA client attempt.

It exports OclaClient plus pydantic models and an SSE streaming helper.

Its client targets /ocla/v1 routes.

Its observed operations include capsule retrieval and capsule fork.

It supports streamed event handling.

Its test command exits with code 2 in the current Python 3.9 invocation.

Python 3.9 is below its declared support floor.

The failure must be re-run in a clean Python 3.10+ environment.

This source must not be installed beside packages/python-lean-ctx today.

Both distributions claim the same top-level lean_ctx package.

The installer can overwrite files depending on installation order.

That is a correctness and supportability defect, not only a naming preference.

## Current state — cookbook/sdk

Location: cookbook/sdk.

This is a TypeScript package, not a Python SDK attempt.

Its package name is lean-ctx-client.

Its current version is 0.1.0.

It is dependency-free at runtime.

It targets the HTTP /v1 contract.

It contains client, conformance, text conversion, errors, and type modules.

It has unit and end-to-end tests for client and conformance behavior.

Cookbook examples import it as lean-ctx-client.

The cookbook root has scripts that build this workspace package for examples.

It overlaps clients/python at the protocol and conformance level.

It must remain a TypeScript client after Python convergence.

Its types, conformance vectors, and endpoint behavior should be shared by contract,

not copied manually into another language.

Do not move TypeScript source into the Python package.

## Current state — overlap map

packages/python-lean-ctx owns local compression and framework integration behavior.

clients/python owns general public HTTP /v1 and conformance behavior.

py-sdk owns one synchronous HTTPX OCLA/client-type experiment.

python-sdk owns one async HTTPX/Pydantic OCLA experiment.

cookbook/sdk owns corresponding TypeScript /v1 and conformance behavior.

The immediate overlap is larger than file paths suggest.

There are two LeanCtxClient names with different behavior.

There is one OclaClient name in a conflicting package namespace.

There are two source trees named leanctx.

There are two source trees named lean_ctx.

There are separate HTTP stacks: urllib, standard library support,

and HTTPX-based clients.

There are separate data-model strategies: dataclasses and Pydantic.

There are separate sync and async call models.

There are separate test and release mechanisms.

There is no single public Python compatibility promise.

## Current state — external references and consumers

The benchmark compression README imports from packages/python-lean-ctx.

The benchmark Python harness recommends pip install lean-ctx-sdk.

The package’s own tests and conftest import lean_ctx.

The documentation cookbook imports leanctx and leanctx.adapters.

The Hermes integration installation script checks whether import leanctx works.

The validator script reads py-sdk/leanctx/types.py directly.

The public build policy lists clients/python/pyproject.toml as a contract path.

The release workflow directory contains publish-clients.yml and publish-sdk.yml.

Both workflows must be examined and changed as part of the release migration.

External PyPI consumers cannot be fully inventoried from this checkout.

Assume external imports of leanctx, leanctx.types, leanctx.client,

lean_ctx, lean_ctx.client, and lean_ctx.proxy exist until telemetry disproves it.

## Current state — source control and deployment

The canonical public remote in this checkout is github:

git@github.com:yvgude/lean-ctx.git.

GitHub HEAD and this checkout’s main are at commit 0f86871aa60.

The GitHub remote currently advertises main and cla-signatures.

There is also a GitHub fork remote named cedric013.

The remote named origin points at GitLab:

https://root@gitlab.pounce.ch/root/lean-ctx.git.

GitLab origin HEAD points to its main branch at 93f89d976514.

GitLab also advertises a deploy branch at 0dd4a8022b07.

It advertises enterprise/intelligence-layer and feat/oss-intelligence-layer.

GitHub and GitLab main are therefore divergent repositories/branch histories.

GitLab deploy is the only directly observed deploy-named branch.

This checkout does not prove what environment that branch deploys to.

It does not prove whether GitLab deploy is the Cloud production branch.

Treat it as a deployment candidate requiring ownership verification.

Never fast-forward GitHub main from GitLab deploy as a convergence shortcut.

Never assume GitLab is a harmless mirror.

## Current state — what is lean-ctx-cloud

The strategy defines lean-ctx-cloud as the private commercial cloud owner.

Its responsibilities are accounts, organizations, hosted registry,

Pro/Team services, and dashboard APIs.

The strategy says current Cloud code has substantial billing and registry function.

It also says that code historically relied on external account/session state,

configured Postgres, and configured Stripe.

The strategy explicitly warns not to confuse source presence with production readiness.

There is no cloud-infra directory in this public checkout.

The public build policy forbids cloud/ paths and private Cloud dependencies.

It also forbids GitLab/private URLs in public source.

Therefore Cloud must remain a separately controlled private repository or service.

It must consume versioned public contracts rather than public code consuming Cloud.

The correct next action is to identify its actual repository URL, owner,

default branch, deploy branch, CI pipeline, database migration system,

and production environment in an access-controlled inventory.

This plan names that work a dependency rather than inventing the answers.

## Target state — repository ownership

Public GitHub lean-ctx is the source of truth for the OSS runtime.

Public GitHub lean-ctx is the source of truth for public contracts and fixtures.

Public GitHub lean-ctx is the source of truth for all public language clients.

Rust runtime and Rust client code remain in the existing rust workspace/layout.

One public Python distribution exists under packages/python-lean-ctx.

One public TypeScript client remains under cookbook/sdk or a later public clients/typescript home.

One public Rust client remains at clients/rust/lean-ctx-client.

Private Enterprise remains downstream of public versioned releases.

Private Cloud remains downstream of public versioned releases and Enterprise service contracts.

Thinkery remains content/brand only and carries no runtime ownership.

GitHub main is the public release source for LeanCTX OSS.

GitLab must be explicitly classified as private integration, deploy mirror,

or legacy repository before it receives any further changes.

## Target state — one Python distribution

The sole supported Python distribution is located at packages/python-lean-ctx.

The primary public import namespace is lean_ctx.

The final distribution name should remain lean-ctx-sdk for the first convergence release

unless packaging research confirms a safe rename and existing PyPI availability.

Changing distribution name and import namespace in the same release is unnecessary risk.

The package supports Python 3.10 and later after convergence.

Raising the floor from 3.9 is justified only by an accepted version policy.

If Python 3.9 remains a product requirement, HTTPX/Pydantic features are optional extras

or implemented with the existing standard-library transport.

The package exposes one documented LeanCtxClient facade.

The facade has explicitly named local, HTTP, and OCLA capability modules.

It must not hide a networked constructor behind a formerly local-only call.

The package has these internal ownership areas.

lean_ctx.local owns CLI wrapper, discovery, and local daemon interaction.

lean_ctx.compress owns ProxyClient, compression result, and message helpers.

lean_ctx.integrations owns LiteLLM, LangChain, LlamaIndex, and future adapters.

lean_ctx.http owns /v1 transport, errors, SSE events, and tool-result conversion.

lean_ctx.conformance owns public contract probes and scorecards.

lean_ctx.ocla owns OCLA models, wire operations, verification, and streaming.

lean_ctx.models owns only public shared model types when they are protocol neutral.

lean_ctx.errors owns one stable hierarchy with compatibility aliases where needed.

Tests mirror this ownership instead of each legacy directory retaining a test suite.

## Target state — compatibility policy

There is one distribution but may be a temporary compatibility import shim.

The temporary leanctx shim exists inside the canonical distribution only.

It re-exports documented compatibility symbols from lean_ctx.

It emits a deprecation warning with the removal release/date.

The shim contains no independent behavior or separate transport stack.

The shim is not a second published distribution.

The package keeps lean_ctx as the permanent primary namespace.

The legacy leanctx name is removed only after a documented deprecation window.

Package versioning follows SemVer-style compatibility commitments.

Namespace removal requires a major release or a separately approved exception.

No compatibility shim is released until import-order tests prove it cannot clobber files.

## Target state — protocol and model policy

The /v1 HTTP client and /ocla/v1 client are separate protocol modules.

They share only verified common transport, errors, auth, and contract types.

They do not become one vague generic client merely to reduce file count.

OCLA types have one canonical Python definition.

The canonical definition replaces py-sdk/leanctx/types.py after parity approval.

The OpenAPI type validator points to the canonical definition.

Pydantic is used only where validation/serialization earns its dependency cost.

Dataclasses remain appropriate for lightweight public immutable value types.

The sync client is the base supported API unless product requirements choose otherwise.

Async APIs are exposed as a clear AsyncOclaClient or async submodule.

Do not overload one object with incompatible sync and async methods.

SSE parsing has one implementation and test corpus.

Conformance fixtures are language-neutral and live outside a language package where practical.

## Target state — one Rust workspace

rust/Cargo.toml remains the only Rust workspace root.

lean-ctx engine remains the default workspace member for existing commands.

lean-ctx-sdk remains an explicit opt-in public SDK crate.

lean-ctx-ocla and lean-ctx-protocol remain contract-oriented crates.

Rust client packaging remains under clients/rust only if its release model requires it.

No duplicate Cargo workspace is created for Python or Cloud concerns.

Public contracts are emitted from schemas/fixtures, not copied by hand across crates.

Cloud and Enterprise consume released contract artifacts.

## Migration plan — phase 0: freeze and assign owners

1. Name an accountable owner for the canonical Python API.

2. Name an accountable owner for OCLA contract/model compatibility.

3. Name an accountable owner for client publishing and PyPI credentials.

4. Name an accountable owner for GitLab deploy branch and Cloud repository inventory.

5. Freeze new features in py-sdk and python-sdk immediately.

6. Permit only defect fixes and migration tests in clients/python during convergence.

7. Continue normal correctness fixes in packages/python-lean-ctx.

8. Record a short architecture decision for primary import lean_ctx.

9. Record a short architecture decision for supported Python-version floor.

10. Record a short architecture decision for sync versus async primary API.

11. Capture current package artifacts, versions, and SHA256 hashes.

12. Capture current PyPI package ownership and release history.

13. Capture current installed-client/import telemetry if available.

14. Do not delete any legacy directory in phase 0.

## Migration plan — phase 1: create a contract inventory

15. Generate API inventories for all four Python trees.

16. Include modules, symbols, constructors, errors, model fields, and CLI entry points.

17. Generate an endpoint inventory for /v1 and /ocla/v1.

18. Generate a model-field inventory from py-sdk types and python-sdk models.

19. Compare that inventory with OpenAPI and OCLA contract fixtures.

20. Classify every public item as retain, rename, merge, deprecate, or reject.

21. Add an owner and a removal release for every deprecated item.

22. Add import-collision tests that install all current distributions in both orders.

23. Add an explicit test that only the canonical distribution is installable at phase completion.

24. Add a generated compatibility matrix to the repository.

25. Include Python 3.10, 3.11, and current supported maximum in that matrix.

26. Run Python 3.9 only if it remains supported by the accepted policy.

27. Establish a clean virtual environment for each legacy test suite.

28. Diagnose the present exit-code-2 legacy test collections there.

29. Record environmental failures separately from behavioral failures.

## Migration plan — phase 2: establish canonical package skeleton

30. Keep packages/python-lean-ctx as the only Python distribution root.

31. Preserve its existing lean_ctx namespace as primary.

32. Add internal subpackages without breaking its current top-level exports.

33. Move local CLI client code to lean_ctx.local if the move is source-compatible.

34. Move proxy compression code to lean_ctx.compress if the move is source-compatible.

35. Preserve re-exports during the first convergence release.

36. Move current discovery logic with the local client, not with Cloud code.

37. Move framework adapters to lean_ctx.integrations.

38. Retain their optional dependency boundaries.

39. Keep standard-library transport available for local compression paths.

40. Create one shared error taxonomy before adding a second HTTP implementation.

41. Document local-only versus networked construction in the README.

42. Add installation extras for HTTP, OCLA, and framework integrations only as justified.

## Migration plan — phase 3: merge clients/python deliberately

43. Treat clients/python as a source migration, not an immediate deletion.

44. Move the dependency-free /v1 transport into lean_ctx.http.

45. Move HTTP/config/transport errors into the shared error hierarchy.

46. Preserve exact status-code/error mapping with regression tests.

47. Move tool_result_to_text into lean_ctx.http or a shared protocol utility.

48. Move SSE/event support into lean_ctx.http.events.

49. Move the conformance scorecard into lean_ctx.conformance.

50. Move OpenAI, LangChain, LlamaIndex, and CrewAI adapters into integrations.

51. Deduplicate the existing LangChain and LlamaIndex adapters by behavior, not filename.

52. Keep one canonical adaptation test per framework behavior.

53. Retain advanced /v1 features from clients/python that packages/python lacks.

54. Preserve the OCLA CLI and verifier only after contract parity tests pass.

55. Change security/public-build-policy-v1.json only with the matching source move.

56. Replace clients/python/pyproject.toml in public contract paths with the canonical manifest.

57. Update public-build-gate fixtures and tests in the same change.

58. Update publish-clients.yml and publish-sdk.yml so one workflow publishes Python.

59. Do not leave two workflows capable of publishing incompatible Python clients.

## Migration plan — phase 4: merge py-sdk types and synchronous OCLA surface

60. Move py-sdk OCLA types to lean_ctx.ocla.types.

61. Preserve fields and enum wire values before any model redesign.

62. Write JSON serialization and deserialization fixtures for every public type.

63. Move py-sdk HealthResponse semantics into the canonical health model if still supported.

64. Move synchronous health, capabilities, envelope, and ledger APIs behind lean_ctx.ocla.

65. Do not add those methods to the existing local CLI client without explicit routing.

66. Prefer a dedicated OclaClient facade below the canonical namespace.

67. Retarget scripts/validate-sdk-types.sh to lean_ctx/ocla/types.py.

68. Run OpenAPI, Go, TypeScript, Python, and Rust type parity checks after the retarget.

69. Update any documentation importing leanctx.types or leanctx.client.

70. Add a compatibility leanctx.types re-export only if external compatibility data requires it.

71. Mark py-sdk as deprecated only after canonical type parity passes.

## Migration plan — phase 5: merge python-sdk asynchronous OCLA surface

72. Re-run python-sdk tests under Python 3.10+ in an isolated environment.

73. Identify which pydantic models are wire-authoritative versus convenience models.

74. Compare their field names and validation behavior with moved py-sdk dataclasses.

75. Choose one canonical wire model representation per contract.

76. Keep Pydantic optional if only async/OCLA users need it.

77. Move streaming.py to lean_ctx.ocla.streaming.

78. Move OclaClient to lean_ctx.ocla.async_client or AsyncOclaClient.

79. Preserve capsule get/fork and event stream behavior with end-to-end contract tests.

80. Do not retain a second top-level lean_ctx distribution.

81. Move tests to the canonical package before deleting python-sdk.

82. Add installation-order tests proving the original file collision no longer exists.

83. Update any release or documentation reference to lean-ctx-ocla.

## Migration plan — phase 6: compatibility, publishing, and cutover

84. Release a convergence preview from packages/python-lean-ctx.

85. Version it as a minor release unless its primary API contains breaking changes.

86. Publish release notes with import and distribution migration tables.

87. Provide old-to-new examples for leanctx and lean_ctx imports.

88. Publish an explicit replacement table for old client constructors.

89. Keep legacy distributions available but deprecated for at least one documented window.

90. Pin their project descriptions to the canonical package during the window.

91. If PyPI transfer or yanking is needed, create a separate release-operation runbook.

92. Do not silently republish a legacy package with a different API.

93. Update Hermes installation logic to install/check the canonical package.

94. Update context-os cookbook snippets to use primary lean_ctx imports.

95. Update benchmark installation instructions and package links.

96. Update all CI paths, package tests, and release evidence.

97. Measure package adoption/errors during the deprecation window if telemetry permits.

## Migration plan — phase 7: delete legacy source only when exit gates pass

98. Delete py-sdk only after all py-sdk types, tests, references, and docs have migrated.

99. Delete python-sdk only after all async OCLA behavior and tests have migrated.

100. Delete clients/python only after its HTTP/conformance implementation and policy path migrate.

101. Delete legacy directories in separate reviewable commits.

102. Each deletion commit includes a repository-wide reference search result.

103. Each deletion commit includes package-install and import compatibility evidence.

104. Each deletion commit includes supported Python-version test evidence.

105. Each deletion commit updates public-build policy and release workflows when applicable.

106. Retain repository history; do not rewrite Git history to hide old attempts.

107. Add tombstone READMEs only if needed for source users during one release cycle.

108. Remove tombstones after the deprecation window closes.

## Dependencies and breakage if py-sdk is deleted today

Deleting py-sdk immediately breaks scripts/validate-sdk-types.sh.

The script currently reads py-sdk/leanctx/types.py by direct path.

That breaks the Python leg of OpenAPI SDK type divergence validation.

It may leave Go, TypeScript, and Rust validation green while Python is absent.

Deleting py-sdk removes its synchronous OCLA HealthResponse and ledger API surface.

It removes exported leanctx types and LeanCtxClient symbols.

It can break external imports of leanctx, leanctx.client, and leanctx.types.

It risks breaking local documentation that imports leanctx unless those examples

are first assigned to clients/python or a canonical compatibility shim.

It does not remove the leanctx name from the repository because clients/python also uses it.

That shared namespace makes deletion deceptively incomplete.

Deleting py-sdk does not solve the lean_ctx collision caused by python-sdk.

Deleting py-sdk without a canonical type model creates contract governance drift.

Therefore py-sdk is deleted last among the type-validation prerequisites,

but first among the physical legacy directories after its contents have migrated.

## Dependencies and breakage if python-sdk is deleted today

Deleting python-sdk removes asynchronous OCLA operations.

It removes Pydantic validation behavior and SSE stream helper behavior.

It can break external installation/import users of lean-ctx-ocla.

It may remove undocumented capsule APIs that require contract decisions.

It eliminates one half of the top-level lean_ctx file-clobbering risk.

It must happen only after the canonical package has an explicit async story.

## Dependencies and breakage if clients/python is deleted today

Deleting clients/python removes the public dependency-free /v1 client.

It removes conformance runner and scorecard implementation.

It removes OCLA verifier/CLI and framework adapters unless migrated.

It breaks the public-build policy’s declared contract path.

It can break cookbook and integration documentation that expects leanctx.

It can leave Python without parity with cookbook/sdk’s public /v1 surface.

This directory has the broadest public-contract responsibility despite its 0.1.0 version.

It should be migrated after an API inventory, not discarded as an experiment.

## GitHub, GitLab, and deploy migration plan

109. Declare GitHub main the public OSS source of truth in repository documentation.

110. Create a remote-ownership table listing github, origin/GitLab, and cedric013.

111. Classify GitLab origin as Cloud, Enterprise, deployment, mirror, or legacy.

112. Record the owner, deploy environment, CI pipeline, and rollback owner for GitLab deploy.

113. Record whether deploy is built from GitLab main, a tag, or another artifact.

114. Record the database migration and secret-management mechanisms associated with deploy.

115. Do not merge divergent GitLab and GitHub histories wholesale.

116. Port selected changes through reviewed commits against versioned public contracts.

117. Establish a release artifact promotion record from GitHub main to any private deployment.

118. Require a commit SHA, artifact digest, contract version, and rollback reference.

119. Make Cloud consume public release artifacts rather than a public workspace checkout.

120. Keep Cloud environment configuration and Stripe/Postgres credentials private.

121. Add an explicit Cloud readiness checklist for account, session, billing,

cancellation, export, deletion, migrations, and Stripe test-mode exercise.

## Week 1 — decisions, inventory, and safety

Week 1 goal: make unsafe deletions impossible and choose the canonical API.

Day 1: appoint Python, contract, publish, and deploy owners.

Day 1: freeze feature work in py-sdk and python-sdk.

Day 1: snapshot manifests, exports, tests, workflows, and current package artifacts.

Day 2: run all legacy suites in clean Python 3.10+ environments.

Day 2: diagnose each current exit-code-2 collection failure.

Day 2: build the API and endpoint inventory.

Day 3: decide primary namespace, Python support floor, sync/async policy,

and distribution-name policy.

Day 3: create the compatibility matrix and namespace collision tests.

Day 4: trace every in-repo py-sdk, python-sdk, clients/python, and leanctx reference.

Day 4: inventory PyPI names, current releases, and available ownership credentials.

Day 5: document GitLab origin/deploy ownership and lean-ctx-cloud repository facts.

Week 1 exit: no one can delete a directory without a typed dependency checklist.

## Week 2 — canonical implementation and test migration

Week 2 goal: move behavior into packages/python-lean-ctx without publishing two APIs.

Day 6: create canonical submodule boundaries and shared error hierarchy.

Day 6: preserve current packages/python-lean-ctx exports.

Day 7: migrate clients/python /v1 client, error mapping, and tool text tests.

Day 7: migrate conformance runner and neutral fixtures.

Day 8: migrate py-sdk OCLA types and retarget validate-sdk-types.sh.

Day 8: run cross-language OpenAPI type parity.

Day 9: migrate python-sdk async client/streaming behavior after model reconciliation.

Day 9: add sync/async and streaming conformance tests.

Day 10: migrate framework adapters and deduplicate equivalents.

Week 2 exit: canonical package passes old behavioral tests plus new collision tests.

## Week 3 — release cutover, policy change, and deletion readiness

Week 3 goal: publish a safe canonical preview and prepare deletion commits.

Day 11: update docs, Hermes installer, benchmarks, examples, and package metadata.

Day 11: publish an import/distribution migration guide.

Day 12: update publish workflows so exactly one Python distribution is releaseable.

Day 12: migrate public-build policy from clients/python to canonical paths.

Day 13: add temporary leanctx compatibility shim if adoption evidence requires it.

Day 13: perform clean installs and import-order tests across supported interpreters.

Day 14: publish or stage the convergence preview and validate generated wheels.

Day 14: verify that Cloud/Enterprise still consume contracts, not Python internals.

Day 15: prepare separate deletion pull requests for py-sdk, python-sdk,

and clients/python with all exit evidence attached.

Week 3 exit: legacy directories are deletion-ready, not necessarily already deleted.

Actual deletion waits for the announced compatibility window and release adoption evidence.

## Required acceptance gates

One canonical Python manifest exists at packages/python-lean-ctx/pyproject.toml.

One canonical primary import namespace is documented as lean_ctx.

No two published distributions install the same primary package files.

All public HTTP and OCLA surface areas have named owners.

All old package exports have retain/deprecate/remove decisions.

The OpenAPI SDK type validator reads canonical Python types.

The public-build policy points at canonical public Python sources.

Exactly one CI workflow can publish the canonical Python distribution.

All migrated tests pass on the declared supported Python versions.

Clean install tests pass in both ordinary and formerly-conflicting install orders.

Cookbook/sdk conformance vectors remain compatible with the same server contract.

Rust workspace tests remain scoped and pass under existing default-member semantics.

Cloud remains optional for all local runtime and SDK paths.

GitLab deploy ownership and production promotion evidence are recorded.

No private Cloud, billing, Stripe, Postgres, or account code enters public GitHub.

## Risk register

Risk: treating directory count as the only duplication metric.

Control: preserve protocol behaviors and migration tests before deletion.

Risk: overwriting a top-level Python package during pip installation.

Control: prohibit co-installation and test clean environments in both orders.

Risk: losing Python/OpenAPI type verification.

Control: retarget the validator before deleting py-sdk.

Risk: breaking public /v1 conformance and adapters.

Control: migrate clients/python behavior and policy references before deletion.

Risk: changing package and import names simultaneously.

Control: retain distribution name and add a time-bounded compatibility shim.

Risk: an untested async OCLA migration.

Control: validate python-sdk on its supported Python version and preserve streaming tests.

Risk: accidental Cloud coupling in OSS.

Control: preserve the public-build gate and enforce released contracts as the seam.

Risk: treating GitLab deploy as a public source branch.

Control: classify its owner and artifact promotion path before changes.

Risk: duplicate publish workflows reintroduce divergent packages.

Control: create one release owner and one Python publishing workflow.

## Final recommendation

Adopt packages/python-lean-ctx as the only Python distribution root.

Adopt lean_ctx as the only permanent primary Python import namespace.

Merge, test, and release clients/python capability rather than deleting it wholesale.

Move py-sdk types before deleting py-sdk because the OpenAPI validator depends on them.

Move python-sdk async/OCLA behavior before deleting it because it resolves a real package collision.

Keep cookbook/sdk as the TypeScript conformance sibling, not Python migration input.

Keep rust/Cargo.toml as the one Rust workspace root.

Keep lean-ctx-cloud private and downstream of public versioned contracts.

Treat GitLab deploy as an unverified deployment candidate pending owner confirmation.

Make physical directory deletion the final, evidence-gated act of convergence.
