# H11 OSS Protection and Open-Core Audit

Date: 2026-08-20

Repository inspected: lean-ctx

Audit head: 0f86871aa60aeccab03a6a7e3217e39ff1cb5c55

Scope: licensing, source topology, Cargo feature gates, ignored private material,

commercial/cloud code, contributor IP controls, and required agent compatibility.

Assessment type: architecture and repository-policy audit, not legal advice.

## Executive conclusion

The intended open-core boundary is coherent and unusually well stated.

The implemented repository boundary is not yet coherent enough to enforce it.

The public license is Apache-2.0.

Apache-2.0 is appropriate for a genuinely open local runtime and interoperable SDK.

Apache-2.0 cannot stop another party from selling a competing commercial layer.

That is a feature of OSI open source, not a defect in the license text.

The strategy correctly chooses operated organizational value as the paid boundary.

The repository currently mixes parts of that paid plane into the OSS crate.

The single Rust package exposes cloud accounts, sync, plans, checkout, billing,

add-on pricing, and commercial configuration as ordinary public-source modules.

An enterprise Cargo feature exists, but it is empty and is not an IP boundary.

Some code is conditionally compiled with the enterprise feature.

The source for that code is nevertheless public and Apache-licensed.

No separate enterprise binary or private enterprise crate exists in the public

workspace topology.

The actual private cloud source is not tracked in the public repository.

Only ignored cloud build artifacts are present locally in the inspected worktree.

The policy should be implemented as separate OSS and private deliverables.

Feature gates should remain for optional OSS build capabilities only.

They should not be represented as protection for commercial source code.

## Direct answers

### 1. Current OSS license and open-core suitability

Current license: Apache License, Version 2.0.

Evidence: LICENSE opens with Apache License Version 2.0, January 2004.

Evidence: LICENSE attributes Copyright 2026 Yves Gugger.

Apache-2.0 is OSI-approved permissive open source.

It permits commercial use, modification, distribution, sublicensing, and forks.

It includes a patent grant subject to its conditions and termination provision.

It is suitable for the stated local-first OSS layer.

It is suitable for SDKs, adapters, protocols, schemas, verifiers, and the CLI.

It is suitable for an open-core model if paid value stays outside that source.

It is not suitable if the objective is to prohibit a competing paid offering.

An Apache licensee can create a paid fork or hosted competitor.

An Apache licensee can sell support, hosting, managed deployment, or extensions.

An Apache licensee must preserve required notices and license terms.

That does not give Thinkery exclusive commercial rights to equivalent functionality.

Conclusion: keep Apache-2.0 for the actual OSS product.

Conclusion: do not rely on Apache-2.0 to prevent commercial competition.

### 2. Are enterprise features behind Cargo feature gates?

Answer: partially, but not in a way that protects enterprise implementation.

rust/Cargo.toml has a features section at line 98.

rust/Cargo.toml defines enterprise = [] at line 99.

The enterprise feature has no dependencies and no private crate attachment.

The default feature list does not include enterprise.

The default list does include tree-sitter, embeddings, http-server, shape-xlat,

secure-update, jemalloc, qdrant, pgvector, and context_kernel.

The default comments explicitly say the shipped binary must support the pilot path.

The comments call this a Local-Free Invariant with compile gating only.

That is consistent with leaving useful local capabilities available by default.

The public source contains enterprise cfg branches in at least these locations:

- rust/src/proxy/mod.rs

- rust/src/proxy/pre_optimize.rs

- rust/src/dashboard/routes/mod.rs

- rust/src/proxy/forward/mod.rs

- rust/src/proxy/forward/prepare.rs

- rust/src/proxy/lineage.rs

- rust/src/proxy/usage_meter.rs

- rust/src/core/value_gate/mod.rs

Several other occurrences are tests for those paths.

Examples include context-prefetch planning after triage.

Examples include gateway identity and trusted-request forwarding fields.

Examples include usage-meter wire identity fields.

These cfg blocks exclude code from a default build.

They do not make the source unavailable to a competitor.

They do not change Apache-2.0 rights to source already present in the repository.

The feature gate is therefore a build-selection mechanism, not an IP boundary.

### 3. Is public code present that should be private?

Answer: no private cloud-server source was found in tracked files.

Answer: several commercial-plane client and domain modules are public and should

be deliberately classified or moved behind a real service/private-binary boundary.

The following are publicly compiled from rust/src/lib.rs without an enterprise cfg:

- pub mod cloud_client

- pub mod cloud_sync

The adjacent source comment identifies that area as Cloud: hosted API, accounts,

sync, billing edge.

cloud_client contains public code for credentials, registration, login, checkout,

plan resolution, account lookup, model synchronization, knowledge push/pull,

index-bundle upload, community leaderboard, and related API calls.

cloud_sync contains background synchronization and collection for local data.

The public CLI exposes a cloud module without an enterprise cfg.

The public CLI also always compiles an enterprise command module.

The command dispatcher has an enterprise command route.

The enterprise command is currently configuration and connection setup code.

The public core module exposes solution_commercial without an enterprise cfg.

The public core exposes addons without an enterprise cfg.

The public core exposes billing without an enterprise cfg.

The billing source labels itself commercial-plane billing substrate.

The billing comment says it never gates local use.

That is directionally compatible with the strategy.

It is not clean separation between an OSS crate and a private commercial binary.

solution_commercial contains OSS-visible commercial contracts and error stubs.

Its comments state implementation belongs exclusively in a private

enterprise/intelligence-layer branch.

The stubs themselves do not reveal an apparent proprietary algorithm.

Keeping a stable public contract or an explicit unavailable error can be sensible.

Keeping pricing, checkout, cloud synchronization, and commercial domain logic in

the OSS crate needs a written decision rather than historical accretion.

Recommended classification: public only if each item is a thin, documented,

provider-neutral client or portable local primitive.

Recommended classification: private if it implements hosted orchestration,

organization state, entitlement decisioning, experimentation selection, managed

deployment, fleet optimization, or commercial operations.

The checked worktree has an ignored cloud directory.

That directory contained cloud/target build artifacts, including lean-ctx-cloud.

No cloud source files were found beneath it in this inspection.

No enterprise directory exists in the worktree.

No tracked path begins with cloud/.

This indicates the private backend source is not presently public.

It does not make the public client-side commercial plane cleanly separated.

### 4. How can the community be prevented from building a competing paid layer?

Answer: it cannot be prevented while retaining Apache-2.0 for the same code.

Do not make an unattainable anti-competition promise part of the OSS strategy.

Do not replace a real operating advantage with artificial degradation of OSS.

The strategy explicitly rejects that approach.

The defensible approach is differentiation, not a legal lock on OSS functionality.

Protect the LeanCTX and Thinkery names, logos, and endorsement claims by trademark.

Publish a trademark policy that permits factual compatibility claims.

Require a different name and branding for forks and hosted derivatives.

Operate durable services competitors cannot obtain from a source checkout alone.

Examples are hosted history, shared governance, reliability operations, support,

private registries, connectors, identity integrations, compliance delivery, and SLA.

Keep private data, service operation runbooks, customer relationships, acceptance

methods, and hosting implementations out of the public tree.

Use product execution, trust, interoperability, and distribution as moats.

Use contributor governance and a CLA to preserve relicensing flexibility.

Use contractual terms for hosted service use, not for the OSS local runtime.

Use service-side authorization only for service resources.

Never use service authorization to disable an installed local runtime.

A dual-license commercial license can help for proprietary embedding cases.

It does not prevent a party from using the Apache version to offer a competing SaaS.

Changing to BSL, SSPL, Elastic-style, or other source-available terms may deter

some hosted competition.

Such a change would no longer satisfy the stated credible-OSS objective.

It would conflict with the strategy's no-paywall and portability commitments.

### 5. Patents and trade secrets

No patent portfolio, patent-pending claim, patent assignment, or patent inventory

was identified in the tracked repository material reviewed for this audit.

No PATENTS file was found.

No trademark policy file was found.

The Apache-2.0 license includes the standard outbound patent license.

The project CLA includes a contributor patent license.

The CLA grants a perpetual, worldwide, non-exclusive, royalty-free, irrevocable

patent license for necessarily infringed contributor claims.

The CLA includes patent-litigation termination.

The CLA also gives the maintainer the right to relicense contributions, including

under proprietary and dual-license terms.

These are inbound-rights controls, not evidence that Thinkery owns a patent.

The CLA itself says commercial reliance should be reviewed by legal counsel.

The strongest plausible trade secrets are not the OSS local algorithms.

Apache-licensed public source cannot remain a trade secret after publication.

Potential trade secrets should instead include private cloud implementations,

service-side selection methods, operating runbooks, non-public benchmark workloads,

customer-specific data, private connectors, pricing/discount rules, and account

or fleet operational data.

The ignored docs/internal material is locally present and is not tracked publicly.

That material should continue to be treated as confidential strategy material.

The ignored cloud directory is also a private-material risk surface.

The audit cannot confirm trade-secret status, ownership, or reasonable secrecy

measures from source inspection alone.

Create an IP register reviewed by counsel before making patent or trade-secret claims.

The register should state invention, inventor, owner, filing status, disclosure

status, and whether the item is intentionally public under Apache-2.0.

### 6. Is the architecture separated as OSS crate versus enterprise binary?

Answer: not yet.

The Rust workspace has a single main package at rust/Cargo.toml.

That package has a public library named lean_ctx.

That package has one shipped binary named lean-ctx at rust/src/main.rs.

The only observed required-features binary is a dev-tools example.

There is no public lean-ctx-enterprise binary target.

There is no public enterprise Cargo package or enterprise workspace member.

There is no private crate dependency referenced by the enterprise feature.

There is no architectural seam that forces commercial code to stay out of the OSS

binary.

Public modules named cloud_client, cloud_sync, billing, addons, and

solution_commercial cross the intended logical boundary.

The strategy calls for public lean-ctx, private Enterprise, private Cloud,

versioned contracts, and no private dependency inside OSS.

That target is valid.

The current public source is compatible with the no-private-dependency half.

It is not yet compatible with a clean private Enterprise/Cloud implementation half.

The strategy also says deployment location is not a licensing model.

That means an on-prem or VPC enterprise deployment may be commercial.

It must still be delivered from private commercial code or service artifacts.

It cannot be kept proprietary merely by compiling Apache public source differently.

### 7. Changes needed for proper open-core distribution

Create explicit product boundaries rather than relying on folder names and cfg flags.

Keep the following public, versioned, Apache-2.0 deliverables:

- lean-ctx-core or lean-ctx-runtime

- lean-ctx-protocol

- language SDKs

- CLI and MCP local tools

- local proxy/attach gateway

- local compression, planning, recovery, and policy enforcement

- local Dyno, profiles, Receipts, schemas, and offline verifier

- Context Kit format, loader, and integrity verifier

- adapter contract and publicly buildable adapters

- Codex, Cursor, and Claude Code local integrations

Move commercial implementation to a separate private repository or package source:

- lean-ctx-enterprise binary or deployable service

- private cloud service

- hosted scheduler and experiment runner

- AutoTune orchestration and candidate-selection services

- shared workspace state, retention, and audit workflow

- SSO, SCIM, RBAC, and organization policy control plane

- private registry and premium asset delivery

- commercial entitlement, checkout, invoicing, and pricing operations

- dedicated connector implementations that encode proprietary service behavior

Expose only versioned protocols, schemas, traits, and client interfaces from OSS.

Make the private binary depend on published OSS artifacts, never the reverse.

Do not use a path dependency from OSS to a private repository.

Do not include private source through git submodules in the public checkout.

Do not include private source behind a Cargo feature in a public repository.

Use separate CI pipelines, SBOMs, release signing, and access controls for each plane.

## Strategy evidence

### SDK strategy section 24-OSS-PROTECTION

The strategy identifies Context SDK as the public product abstraction.

It says compression remains the current wedge.

The repository-convergence section retains public lean-ctx.

The same section retains private Enterprise.

The same section retains private Cloud.

The same section retains versioned contracts.

The same section requires no private dependency inside OSS.

The OSS-protection section retains a strong open Runtime.

It retains no hidden degradation.

It retains portability.

It retains open Kit and interoperability formats.

It retains local-first trust.

It explicitly says deployment location is not a licensing model.

It permits commercial intelligence to run on-prem or in a VPC.

This is a service and operational boundary, not a geographic deployment boundary.

### Coding-agent compatibility obligations

The SDK strategy says coding agents remain first-class.

Its listed focus order is Claude Code, Codex, then Cursor.

It requires each to receive connect.

It requires each to receive doctor.

It requires each to receive Dyno.

It requires each to receive a local receipt.

It requires each to receive uninstall.

It says not to abandon coding-agent distribution for stronger enterprise monetization.

The OSS-vs-paid policy explicitly classifies Codex integration as OSS.

The OSS-vs-paid policy explicitly classifies Cursor integration as OSS.

The OSS-vs-paid policy explicitly classifies Claude Code integration as OSS.

For each of those integrations, connect, tune, doctor, and uninstall must remain local.

The policy says they must never be degraded to sell Thinkery.

### OSS-vs-paid policy obligations

The policy defines the boundary as organizational, not an artificial feature limit.

It states that LeanCTX makes one agent context-efficient.

It states that Thinkery makes an organization operate context-efficient agents.

The individual developer must experience full local LeanCTX value.

Paid value begins with continuous operation, shared control, and accountability.

Manual tuning is open.

Continuous tuning is commercial.

The local runtime, SDK, and adapter path must not be paywalled.

Local selection, compression, memory, and recovery must not be paywalled.

Context Kit format and verifier must not be paywalled.

Local receipts, benchmarking, and manual profiles must not be paywalled.

Customers must be able to use their own models, agents, and tools.

The policy rejects a free tier that saves little while paid saves a lot.

The protected local loop is connect, measure, manually tune, run Dyno, inspect

a Receipt, and deploy locally.

The policy says a single developer must not pay to use the core runtime.

The policy says a single developer must not pay to produce a local Receipt.

The policy says a single developer must not pay to verify evidence.

The policy says a single developer must not pay to load a community Kit.

The policy says a single developer must not pay to retain a working local integration.

Commercial triggers are cross-device continuity, shared policy or ownership,

private distribution, scheduled experiments, organization economics, retention,

identity, delivery, support, and contractual operations.

The policy says a Pro plan cannot lock core developer capability behind payment.

### Normative module classification

The policy classifies the Rust Context Runtime as OSS.

The policy classifies the Python SDK as OSS.

The policy classifies the TypeScript SDK as OSS.

The policy classifies the Rust SDK as OSS.

The policy classifies lean-ctx-protocol as OSS and never proprietary.

The policy classifies CLI as OSS and never account-gated.

The policy classifies MCP integration as OSS and never account-gated.

The policy classifies Proxy / Attach gateway as OSS.

The policy classifies core compression as OSS and never paywalled.

The policy classifies context planner as OSS.

The policy classifies local Dyno as OSS.

The policy classifies local profiles as OSS.

The policy classifies local Receipts as OSS.

The policy classifies offline verifier as OSS and never paywalled.

The policy classifies evidence schema as OSS and never proprietary.

The policy classifies local metrics as OSS.

The policy classifies Community Kits as OSS.

The policy classifies Kit verifier as OSS and never paywalled.

The policy classifies adapter contract as OSS and never proprietary.

The policy classifies the reference agent as OSS.

The policy allows an optional managed relay only when direct BYOK access remains valid.

The policy reserves hosted history, scheduled runs, hosted jobs, AutoTune, private

profile synchronization, private Kit registry, shared Receipts, dashboards, RBAC,

SSO/SCIM, fleet recommendation, and private deployment operations for Thinkery.

## Compatibility verification

### Public source and package evidence

The Rust runtime is a tracked public package at rust/Cargo.toml.

The package exports a public library named lean_ctx.

The package ships a public lean-ctx binary.

The Python SDK is present under python-sdk.

python-sdk contains pyproject.toml and lean_ctx client, models, and streaming code.

The Node/TypeScript package is present under packages/node-lean-ctx.

The Rust SDK is a tracked public crate at rust/crates/lean-ctx-sdk.

The protocol crate is a tracked public crate at rust/crates/lean-ctx-protocol.

The Rust client is present under clients/rust/lean-ctx-client.

The verifier package is present under packages/leanctx-verify.

These locations support the intended public SDK and verifier surface.

### Codex compatibility

Tracked public Codex integration paths include:

- rust/src/core/editor_registry/writers/install/codex.rs

- rust/src/core/import/codex.rs

- rust/src/doctor/integrations/codex.rs

- rust/src/hook_handlers/codex.rs

- rust/src/hooks/agents/codex.rs

- rust/src/proxy_setup/codex.rs

- docs/guides/codex-cli.md

The hook_handlers module includes codex without an enterprise cfg.

The agents module includes codex without an enterprise cfg.

The public source therefore keeps the observed Codex integration source available.

### Claude Code compatibility

Tracked public Claude-related paths include:

- rust/src/core/editor_registry/writers/install/claude.rs

- rust/src/core/import/claude_code.rs

- rust/src/hooks/agents/claude.rs

- rust/src/proxy_setup/claude.rs

- docs/guides/claude-code.md

The agents module includes claude without an enterprise cfg.

The proxy setup facade includes claude without an enterprise cfg.

The public source therefore keeps the observed Claude Code integration source available.

### Cursor compatibility

Tracked public Cursor-related paths include:

- rust/src/core/import/cursor.rs

- rust/src/hooks/agents/cursor.rs

- docs/guides/cursor.md

The agents module includes cursor without an enterprise cfg.

The import module publicly exports cursor without an enterprise cfg.

Cursor has less dedicated source coverage than Codex and Claude Code.

No dedicated Cursor doctor module was found in rust/src/doctor/integrations.

No dedicated Cursor proxy-setup module was found in rust/src/proxy_setup.

That does not prove these functions fail; generic code may provide them.

It does mean the required Cursor connect, doctor, Dyno, receipt, and uninstall

contract lacks an obvious dedicated conformance surface.

Create an integration conformance test for all three named agents.

### Protected-module verdict

The required agent integration source is public and not enterprise-gated.

That satisfies the source-availability part of the strategy today.

The current enterprise feature does not hide Codex, Cursor, or Claude Code modules.

The Runtime, SDK crates, protocol crate, CLI, MCP implementation, and verifier

are also present in public tracked paths.

The stronger requirement is behavioral, not only source placement.

There is no single audited conformance test proving all required local operations

for all three agents remain available with no account, telemetry, or entitlement.

Verdict: source placement passes; policy-enforcement and behavioral proof are missing.

## Public/private inventory

| Area | Current location | Intended classification | Verdict |
|---|---|---|---|
| Runtime | rust package | OSS | Correctly public |
| CLI and MCP | rust package | OSS | Correctly public |
| Protocol | rust/crates/lean-ctx-protocol | OSS | Correctly public |
| SDKs | python-sdk, node package, Rust SDK | OSS | Correctly public |
| Verifier | packages/leanctx-verify | OSS | Correctly public |
| Agent adapters | rust source and guides | OSS | Correctly public |
| Cloud client | rust/src/cloud_client.rs | Thin public client only | Boundary decision required |
| Cloud sync | rust/src/cloud_sync.rs | Local opt-in client only | Boundary decision required |
| Billing | rust/src/core/billing | Private service/domain preferred | Public mixing risk |
| Add-on commerce | rust/src/core/addons/commerce.rs | Private service/domain preferred | Public mixing risk |
| Commercial contracts | rust/src/core/solution_commercial.rs | Public API/stubs only | Clarify and minimize |
| Enterprise config command | rust CLI/config | OSS connection shell only | Keep thin or move |
| Cloud server | no tracked source found | Private | Appears absent from public tree |
| Enterprise implementation | no public package found | Private | No clean deployment artifact yet |
| Internal vision docs | ignored docs/internal | Private | Not tracked, but guard is weak |
| Private cloud artifacts | ignored cloud/target | Private | Keep outside public worktree |

## Git ignore and publication-control findings

.gitignore ignores .env at line 5.

.gitignore ignores discord-bot/ at line 25.

.gitignore ignores n8n-workflows/ at line 28.

.gitignore ignores lab/ at line 32.

.gitignore ignores rust/models/ at line 33.

.gitignore ignores /cloud/ at line 38.

.gitignore ignores docs/business/ at line 48.

.gitignore ignores docs/internal/ at line 95.

docs/internal/vision/SDK-STRATEGY-ALL-IN-ONE.md is not tracked.

docs/internal/vision/02-OSS-VS-PAID.md is not tracked.

LICENSE and .gitignore are tracked.

The ignore rules correctly reduce accidental publication of current internal strategy.

Ignore rules are not access control.

git add -f can override an ignore rule.

An existing tracked file is not protected by a later ignore rule.

The gitignore does not ignore enterprise/.

The gitignore does not ignore enterprise-crate/.

The gitignore does not ignore rust/crates/lean-ctx-enterprise/.

The gitignore does not ignore docs/enterprise/.

The gitignore does not ignore the protected contract prefixes used by the hook.

Therefore a future private Enterprise tree can be accidentally staged.

The checked pre-push proprietary guard is tracked at

.github/hooks/pre-push-proprietary-guard.sh.

It blocks selected docs/enterprise, docs/contracts, docs/business, and inventory paths.

It does not block enterprise source directories.

It does not block cloud client/server source directories by content classification.

It can be bypassed with SKIP_PROPRIETARY_GUARD=1.

It is a local hook, not a GitHub-enforced merge control.

No workflow was identified that makes proprietary-content scanning a required CI gate.

Conclusion: current prevention is helpful hygiene, not release-grade protection.

## Contributor-rights findings

CLA.md exists and is tracked.

The repository has a CLA GitHub workflow.

The CLA grants broad copyright rights to the maintainer and recipients.

The CLA explicitly permits maintainer relicensing, including proprietary and

dual-license terms.

The CLA has a broad contributor patent grant and litigation termination.

The CLA asks contributors to disclose known third-party license, patent, and

trademark restrictions.

This supports dual-product evolution and inbound-rights management.

The CLA does not create a trademark policy.

The CLA does not establish a patent portfolio.

The CLA workflow should be checked as a required merge check, not merely a comment bot.

Corporate contributors need a clear corporate CLA acceptance path.

Retain signed acceptance records independently of a third-party workflow.

## Risks ranked by priority

### Critical

No critical public leakage of a tracked cloud-server implementation was observed.

The absence of a separate private enterprise artifact is nevertheless a strategic

blocker before claiming a mature open-core architecture.

### High

The enterprise Cargo feature may create a false sense of IP protection.

Public commercial-plane modules make the OSS/private boundary ambiguous.

The public crate is the only shipped binary rather than an OSS dependency of an

independent commercial binary.

The local proprietary guard does not cover enterprise source paths.

The guard is bypassable and not enforced in CI.

Cursor's full required local lifecycle has weaker dedicated source evidence than

Codex and Claude Code.

### Medium

The public client contains account, plan, checkout, and sync behavior that can

unnecessarily reveal commercial service semantics and complicate OSS governance.

Internal strategy documents rely on ignore rules rather than repository separation.

The cloud build artifact exists inside the public worktree namespace.

It should be produced in a separate private build workspace or CI environment.

No patent/trademark inventory is available for governance decisions.

### Low

Commercial stubs in solution_commercial are not apparent secret leakage.

They still make the intended boundary harder to understand for contributors.

## Recommended target architecture

### OSS repository and release

Publish an Apache-2.0 lean-ctx OSS repository.

Publish the runtime, CLI, MCP server, local adapters, SDKs, protocol, schemas,

verifier, Kit format, local metrics, local policies, and local Dyno there.

Make all OSS releases independently buildable and useful offline.

Make the OSS release pass agent lifecycle conformance tests with no account.

Document an uninstall and rollback path for every supported agent.

Document direct BYOK use and provider-neutral adapter behavior.

### Public contracts

Version wire contracts in lean-ctx-protocol or a dedicated contract package.

Use semver and compatibility tests for records, Receipts, Kit formats, digests,

adapter interfaces, and error semantics.

Publish a client trait for optional managed services.

Make the default implementation a no-op or direct local operation.

Require explicit user configuration before any managed-service client activates.

Ensure the client can be removed without affecting local core operations.

### Private Enterprise product

Create a private lean-ctx-enterprise repository or securely controlled monorepo.

Make it depend on released OSS crates and versioned contracts.

Ship it as a distinct binary, container, or managed deployment artifact.

Put fleet recommendation, organization policy, SSO/SCIM, RBAC, shared audit,

private registry, and corporate delivery there.

Use commercial terms and enterprise support contracts for that artifact.

Do not compile its implementation from Apache source in the OSS repository.

### Private Cloud product

Create a private cloud-service repository and deployment pipeline.

Keep server routes, databases, queue workers, scheduler, service-side AutoTune,

customer records, entitlement authority, billing operations, and runbooks there.

Publish only stable client schemas and documented API behavior when interoperability

requires it.

Treat local cloud_client as an optional, auditable OSS connector.

Move implementation-heavy commercial workflow logic from the public client to

the service or private binary.

## Recommended migration sequence

### Phase 0: declare and freeze the boundary

Adopt a short OSS Boundary specification in the public repository.

Make it normatively reference the no-hidden-degradation and local-first rules.

List public deliverables and prohibited private-source paths.

List public contract packages and their versioning owner.

List private deliverables by capability, not only by repository name.

### Phase 1: split code ownership

Inventory cloud_client, cloud_sync, billing, addons commerce, enterprise config,

and solution_commercial APIs.

For each symbol, label it Local OSS, Public Contract, Thin Optional Client, or Private.

Move private implementation to a private repository before further development.

Leave minimal traits, protocol records, and no-op/local behavior in OSS.

Delete stale public commercial implementation rather than only cfg-gating it.

Replace enterprise = [] with an explicit documented policy.

Either remove it or reserve it for entirely public optional build integrations.

### Phase 2: establish the commercial artifact

Create a private enterprise binary with a separate package name and release process.

Create a private cloud service with a separate deployment and secrets boundary.

Make both consume released OSS crates through normal versioned dependencies.

Forbid OSS source dependencies on private crates in CI.

Forbid private path dependencies in the public lockfile and manifests.

### Phase 3: prove no degradation

Add a no-account integration test matrix for Codex, Cursor, and Claude Code.

Test connect, doctor, Dyno, local Receipt, uninstall, and rollback for each.

Run the matrix in the public CI release gate.

Assert that no cloud URL, token, account, or telemetry setting is required.

Assert that all local Receipt and verifier flows work offline.

Assert that community Kit loading and adapter-building work without entitlement.

### Phase 4: strengthen outbound controls

Add an OSS publication policy checker to mandatory CI.

Check changed files against explicit prohibited private paths.

Check for private-domain imports and path dependencies in public manifests.

Check for service credentials, cloud deployment manifests, and internal documents.

Check SPDX/license headers and third-party notices.

Run the check on pull requests, release tags, and GitHub push targets.

Keep a local pre-push hook as convenience only.

Do not treat an environment-variable-bypassable hook as a security boundary.

### Phase 5: establish IP governance

Publish a LeanCTX and Thinkery trademark policy.

Maintain a private IP register and invention disclosure process.

Review employee and contractor invention-assignment agreements.

Confirm CLA workflow enforcement and corporate CLA handling.

Document third-party dependency license review for the commercial distribution.

Obtain counsel review before changing outbound license or asserting patents.

## Acceptance criteria

The public repository contains no private Enterprise or Cloud implementation source.

The public repository contains no private deployment manifests or production secrets.

The OSS runtime builds and works without enterprise features or service credentials.

The OSS runtime has no private-crate dependency.

The private binary depends on OSS artifacts rather than embedding unreviewed copies.

The public protocol and SDK contracts remain buildable and versioned.

The no-account agent lifecycle matrix passes for Codex, Cursor, and Claude Code.

Local tuning, Dyno, Receipt, verification, export, and uninstall remain available.

Cloud and enterprise clients are optional and cannot disable local capabilities.

Every commercial-only capability maps to operated organization value.

Every OSS capability maps to one-agent local value, inspection, or portability.

CI rejects protected paths and private dependencies before publication.

Release SBOMs distinguish OSS runtime from commercial service/binary components.

Trademark and CLA policies have named owners and enforcement records.

## Final audit verdict

License: PASS for an honest Apache-2.0 open-core model.

License as anti-competition mechanism: FAIL by design; no OSS license provides it.

Strategy quality: PASS; the boundary is precise, local-first, and credible.

Required public compatibility source placement: PASS for Runtime, SDK/protocol,

CLI/MCP, and observed Codex/Cursor/Claude integrations.

Required compatibility behavioral proof: PARTIAL; add a public lifecycle matrix.

Cargo feature protection: PARTIAL/FAIL; cfg exists but cannot protect public IP.

Public/private architecture separation: FAIL; one OSS package currently mixes

commercial-plane modules and no separate enterprise binary exists.

Private source leakage observed: no tracked cloud-server or enterprise source found.

Publication controls: PARTIAL; ignore rules and a local docs-only guard are insufficient.

Open-core distribution readiness: NOT READY until the real private artifact,

public contract boundary, CI policy gate, and agent conformance tests exist.

