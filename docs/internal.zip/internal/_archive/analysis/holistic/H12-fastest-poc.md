# H12 — Fastest credible LeanCTX POC

## Decision in one sentence

Demo one pre-existing, open reference code-review agent on one pinned review
workload; run it once stock and once through LeanCTX with `kits/code-review`,
then show a locally signed, offline-verifiable comparison bundle.

This is the fastest route that demonstrates the canonical loop without
pretending that the current generic proxy or aggregate evidence commands are
already a production `ctx.wrap()` product.

## The promise the CTO should hear

> “Keep your agent, model, provider account, and workflow.  LeanCTX changes
> only the context path, measures the resulting task, and gives you evidence
> you can verify without trusting our dashboard.”

The on-screen proof is not a compression percentage alone.

It is:

1. the same agent;
2. the same pinned task and quality gate;
3. a smaller provider-reported input/cost result;
4. a signed evidence bundle; and
5. a proposed next experiment that remains approval-gated.

## Non-negotiable integrity rules

- Never insert a made-up finding, cost, cache result, or quality result.
- Do not call the reference-fixture result a customer result or a universal
  benchmark.
- Do not call a treatment successful unless both arms meet the declared
  automated quality gate and the facilitator accepts the review rubric.
- Label dollar data as `provider-reported`, `estimated`, or `unavailable`.
- Preserve the original agent output; LeanCTX attaches a result and receipt,
  it does not rewrite the review to make it look better.
- A missing signer, missing provider usage, or missing quality result yields
  `evidence_status=unavailable` or `partial`, never a fabricated receipt.
- AutoTune is a dry-run proposal in this demo, not a claim that continuous
  managed tuning already exists.

## What we use

### The agent: our own existing reference agent

Use a repository-owned `examples/python-openai-agents-code-review/agent.py`.

It is a deliberately small, already-working Python OpenAI Agents SDK agent:

- fixed code-review instructions;
- the same model, temperature, and completion cap in both arms;
- no LeanCTX import in its stock path;
- a structured `ReviewResult` containing finding IDs, severities, locations,
  rationales, and remediations;
- one normal `Runner.run()` call in the baseline;
- one `Runner.run(LeanCTX.wrap(agent, config), ...)` call in treatment.

This is an *existing agent* at the point of connection.  It matters because
the demonstrator can truthfully say “we did not rebuild an agent to suit the
demo.”

Do **not** use the customer’s production agent in the first 15 minutes.

Why:

- a first call should not require access to customer repositories or secrets;
- an unfamiliar agent makes quality, cache state, model configuration, and
  tool permissions impossible to normalize inside the time box;
- a deterministic reference workload establishes that LeanCTX is measurable;
- the immediate next step is to point the exact same harness at one customer
  agent and its pre-approved manifest in a 30-minute technical session.

The reference agent must remain public/reviewable so a CTO can inspect what is
being compared.  It is a demonstration of mechanism, not a substitute for the
customer pilot.

### The workload: one pinned code-review fixture

Use `examples/python-openai-agents-code-review/fixture` at an immutable Git
commit, not the LeanCTX repository head and not a live pull request.

The fixture contains:

- a compact service change with enough Rust/Python/source/test material to
  require orientation, reading, search, and test-output interpretation;
- a declared review request: “find actionable correctness, security, and
  performance issues introduced by this change”;
- a `workload-manifest.json` with the commit, agent version, task hash, model,
  pricing snapshot, cache treatment, quality policy, and redaction policy;
- `expected-findings.json`, whose IDs map to real locations and test evidence;
- an automated evaluator that only checks predeclared finding IDs and
  locations; it never asks an LLM to grade itself;
- a one-page human scorecard for relevance, correctness, and actionable
  remediation.

The fixture should contain 3–5 independently verifiable review conditions,
not an artificial 30-file corpus.  Its code and tests are the source of truth.
If the issue set changes, the fixture commit and manifest hash change too.

### The kit: `kits/code-review` v1.0.0

The treatment uses the repository’s existing code-review kit.

The kit demonstrates a concrete policy rather than magic:

- changed files first;
- Rust: structural map then signatures before expanding bodies;
- TOML: full read;
- tests: signatures first;
- `cargo test` and `cargo clippy`: compressed evidence focused on failures;
- quality criteria that require actionable, located, evidenced findings.

The presenter shows the kit before running treatment.  A CTO sees precisely
what changed, and a staff engineer can question or replace it.

## The narrow POC build target

Build only the following thin vertical slice before rehearsing.

| Capability | Narrow POC implementation | Explicitly out of scope |
|---|---|---|
| Attach | `LeanCTX.wrap(agent, config)` for one supported Python/OpenAI Agents SDK version and `Runner.run()` | Global monkey patching, arbitrary agent frameworks |
| Measure | Per-run baseline/treatment usage capture with one pinned model pricing snapshot | Organization analytics or live billing |
| Tune | Load exactly `code-review@1.0.0`, record hash and selected modes | Marketplace, private registry, multiple kits |
| Prove | Two execution receipts, quality comparison, signed ZIP, offline verifier | Hosted receipt history or dashboards |
| Deploy | Terminal comparison plus self-contained HTML report | Customer rollout automation |
| Repeat | One approval-required next-experiment proposal | Scheduled/hosted AutoTune |

The POC command surface is intentionally small:

```text
leanctx-poc doctor
leanctx-poc run --arm stock --manifest <manifest> --out <run-dir>
leanctx-poc run --arm leanctx --kit code-review --manifest <manifest> --out <run-dir>
leanctx-poc compare --baseline <receipt> --treatment <receipt> --out <run-dir>
leanctx-poc autotune propose --from <comparison> --dry-run
lean-ctx verify <bundle.zip> --json
```

`leanctx-poc` may be a small entry point in `packages/python-lean-ctx` or an
example-local module.  Do not add a control plane, account system, hosted
runner, or a broad CLI before this demo works.

## Required output contract

Every run writes this local layout:

```text
.leanctx-poc/runs/<run-id>/
  workload-manifest.json
  stock-output.json | treatment-output.json
  execution-receipt.json
  quality-result.json
  provider-usage.json
  context-plan.json                 # treatment only
  comparison.json                   # after both arms
  savings-receipt.json              # after both arms
  evidence-bundle.zip               # signed after both arms
  report.html                       # self-contained
  autotune-proposal.json            # proposal only
```

Default artifacts contain hashes, identifiers, summaries, and redacted
descriptors; they do not retain raw prompt text or full source content.

The baseline receipt records that no kit/context transform was applied.

The treatment receipt records:

- `kit_name=code-review`;
- kit version and content hash;
- context-policy/configuration fingerprint;
- selected context descriptors and exclusions;
- original and treatment token counts;
- provider usage, including cached-input usage when available;
- quality-gate results and human-review state;
- pricing snapshot identifier;
- signer public-key fingerprint;
- evidence status and declared limitations.

## The 15-minute run of show

The presenter shares one terminal.  A second terminal pane is optional but no
dashboard, slideware, or manual JSON editing is permitted.

| Clock | Canonical-loop step | Presenter action | CTO sees |
|---:|---|---|---|
| 00:00–00:45 | Frame | State the promise and the comparison rules. | “Same agent, same task, proof you can keep.” |
| 00:45–02:00 | CONNECT | Run preflight and identify the unwrapped reference agent. | Agent/model/fixture ready; no hidden hosted service. |
| 02:00–04:30 | MEASURE | Run the stock arm. | Native output, provider usage, baseline receipt status. |
| 04:30–05:30 | TUNE | Load/show `code-review` kit. | Human-readable context policy and hash. |
| 05:30–08:00 | PROVE | Run the same wrapped agent against same manifest. | Native-shaped review plus context plan and treatment receipt. |
| 08:00–10:00 | DEPLOY | Compare, build bundle, verify offline, render report. | Exact deltas, quality gate, Ed25519 verification. |
| 10:00–11:00 | Tamper | Alter a copied artifact and rerun verifier. | Verifier rejects the changed evidence. |
| 11:00–12:30 | REPEAT | Produce AutoTune proposal in dry-run mode. | Bounded next experiment; nothing runs without approval. |
| 12:30–15:00 | Pilot ask | Map this harness to one customer agent/workload. | A 30-day, one-workflow Verified Savings Pilot. |

If a network call takes longer than expected, do not fill time with claims.
Show the manifest, kit provenance, and already-produced receipts only if they
are clearly labelled as a prior rehearsal.  Resume the live task result when
it returns.

## Pre-demo setup: done before the CTO joins

The demo operator prepares a clean, local directory and never types an API key
in the shared terminal.

```bash
git clone https://github.com/<org>/lean-ctx.git leanctx-poc
cd leanctx-poc
git checkout <signed-demo-commit>
python3 -m venv .venv
source .venv/bin/activate
pip install "lean-ctx-sdk[openai-agents]==1.0.0rc1" "openai-agents==<pinned-version>"
export OPENAI_API_KEY='<set privately before screen share>'
export POC_DIR="$PWD/.leanctx-poc"
```

The environment must also have a locally running LeanCTX runtime and a local
signing identity.  These are preflight checks, not assumptions:

```bash
leanctx-poc doctor --manifest examples/python-openai-agents-code-review/workload-manifest.json
```

Expected output shape:

```text
LeanCTX POC preflight
  SDK:                 1.0.0rc1
  Runtime:             <version> reachable on loopback
  Agent adapter:       OpenAI Agents SDK <pinned-version> supported
  Provider:            OpenAI-compatible endpoint reachable
  Fixture commit:      <40-char commit> pinned
  Manifest hash:       sha256:<hash>
  Pricing snapshot:    <model-price-version>
  Signing identity:    ed25519:<public-key-fingerprint>
  Evidence directory:  .leanctx-poc/runs
READY: one stock and one treatment run can be compared.
```

A red `BLOCKED` preflight is a good outcome: it proves the demo does not hide
missing evidence prerequisites.  Fix it before the live session; never fall
back to synthetic usage, test output, or receipts.

## Live script, word for word

### 1. CONNECT — 00:45–02:00

Say:

> “This is a normal OpenAI Agents SDK code-review agent.  Its stock path has
> no LeanCTX wrapper.  We will retain its instructions, model, task, and output
> contract, then attach LeanCTX only for the second run.”

Run:

```bash
python examples/python-openai-agents-code-review/agent.py describe
```

Expected output shape:

```text
Agent:              ReferenceCodeReviewAgent v1
Framework:          OpenAI Agents SDK <pinned-version>
Model:              <pinned-model>
Temperature:        0
Output schema:      ReviewResult v1
Tools:              fixture_reader, fixture_search, fixture_tests
LeanCTX attached:   no
```

Then bind the demo to the immutable workload, not the working tree:

```bash
leanctx-poc manifest show examples/python-openai-agents-code-review/workload-manifest.json
```

Expected output shape:

```text
Workload:            code-review-reference-v1
Fixture commit:      <commit>
Task hash:           sha256:<hash>
Quality evaluator:   expected-findings-v1
Human review:        required
Cache treatment:     recorded; not normalized away
Comparison rule:     reject if manifest/model/agent hashes differ
```

The connection is complete only when the agent and manifest hashes are shown.
Do not show source code yet; it wastes the first two minutes.

### 2. MEASURE — 02:00–04:30

Say:

> “First, this agent runs normally.  This gives us a baseline from the
> provider, not an estimate from a marketing calculator.”

Run:

```bash
leanctx-poc run \
  --arm stock \
  --agent examples/python-openai-agents-code-review/agent.py \
  --manifest examples/python-openai-agents-code-review/workload-manifest.json \
  --out "$POC_DIR"
```

Expected output shape:

```text
RUN stock/<run-id>
  Agent hash:              sha256:<same-agent-hash>
  Workload manifest:       sha256:<manifest-hash>
  Context policy:          stock/no-transform
  Provider usage:          prompt=<actual> cached=<actual-or-unavailable> completion=<actual>
  Provider cost:           $<actual> [provider-reported usage; <pricing-version>]
  Quality evaluator:       PASS (<matched>/<required> declared findings)
  Human review:            PENDING
  Receipt:                 <path>/execution-receipt.json
  Evidence status:         PARTIAL (comparison arm not yet complete)
```

Open the native review, not an edited summary:

```bash
leanctx-poc output show "$POC_DIR/runs/<stock-run-id>/stock-output.json" --summary
```

Expected output shape:

```text
ReviewResult v1
  Finding <declared-ID-1>  <severity>  <real fixture location>
  Finding <declared-ID-2>  <severity>  <real fixture location>
  Finding <declared-ID-3>  <severity>  <real fixture location>
No LeanCTX transformation was applied to this result.
```

The operator records the displayed run ID rather than retyping it:

```bash
export BASELINE_RUN_ID='<printed-stock-run-id>'
```

### 3. TUNE — 04:30–05:30

Say:

> “Tuning is an inspectable profile, not a black box.  Here is exactly what
> LeanCTX is allowed to prioritize and compress for this review.”

Run:

```bash
lean-ctx kit load code-review
lean-ctx kit show code-review
leanctx-poc kit fingerprint code-review
```

Expected output shape:

```text
Context Kit: code-review (1.0.0)
Priority: git_changed
Rust reads: map -> signatures
Test reads: signatures
TOML reads: full
Shell evidence: cargo test, cargo clippy compressed around failures
Quality rule: actionable, located, evidenced findings only
Kit digest: sha256:<kit-content-hash>
```

Point out that the stock run is untouched.  The treatment will wrap the same
agent with this versioned kit, and the receipt will capture the digest.

### 4. PROVE — 05:30–08:00

Say:

> “Now we execute the same agent on the same manifest.  The difference is the
> context policy and its observed plan—not the task, model, or acceptance bar.”

Run:

```bash
leanctx-poc run \
  --arm leanctx \
  --agent examples/python-openai-agents-code-review/agent.py \
  --kit code-review \
  --manifest examples/python-openai-agents-code-review/workload-manifest.json \
  --out "$POC_DIR"
```

Expected output shape:

```text
RUN leanctx/<run-id>
  Agent hash:              sha256:<same-agent-hash> MATCH
  Workload manifest:       sha256:<same-manifest-hash> MATCH
  Context kit:             code-review@1.0.0 sha256:<kit-hash>
  Context plan:            changed files first; <n> descriptors selected; <n> exclusions
  Provider usage:          prompt=<actual> cached=<actual-or-unavailable> completion=<actual>
  Provider cost:           $<actual> [provider-reported usage; <pricing-version>]
  Quality evaluator:       PASS (<matched>/<required> declared findings)
  Human review:            PENDING
  Receipt:                 <path>/execution-receipt.json
  Evidence status:         PARTIAL (awaiting comparison/signature)
```

Then show the review produced by the wrapped agent:

```bash
leanctx-poc output show "$POC_DIR/runs/<treatment-run-id>/treatment-output.json" --summary
```

Expected output shape:

```text
ReviewResult v1
  Finding <declared-ID-1>  <severity>  <real fixture location>
  Finding <declared-ID-2>  <severity>  <real fixture location>
  Finding <declared-ID-3>  <severity>  <real fixture location>
Output schema valid: yes
```

Record the ID:

```bash
export TREATMENT_RUN_ID='<printed-leanctx-run-id>'
```

If either quality evaluator fails, stop and say:

> “The treatment is cheaper only if it remains correct.  This run did not
> clear the agreed bar, so it cannot become a savings claim.”

That failure path is more credible than a forced success.

### 5. DEPLOY — 08:00–10:00

Say:

> “The two runs become a claim only now: matching inputs, explicit quality,
> provider usage, fixed pricing, and a signed bundle.”

Run:

```bash
leanctx-poc compare \
  --baseline "$POC_DIR/runs/$BASELINE_RUN_ID/execution-receipt.json" \
  --treatment "$POC_DIR/runs/$TREATMENT_RUN_ID/execution-receipt.json" \
  --require-quality-pass \
  --out "$POC_DIR/comparisons/$TREATMENT_RUN_ID"
```

Expected output shape:

```text
MATCHED COMPARISON
  Agent / task / fixture:      MATCH
  Model / parameters:          MATCH
  Pricing snapshot:            <version> MATCH
  Cache treatment:             recorded separately for each arm
  Baseline input tokens:       <actual>
  Treatment input tokens:      <actual>
  Input-token delta:           <actual> (<actual>%)
  Baseline provider cost:      $<actual>
  Treatment provider cost:     $<actual>
  Cost delta:                  $<actual> (<actual>%)
  Automated quality:           PASS / PASS
  Human review:                PENDING — not a commercial VCP-SAT result
  Claim status:                MEASURED; customer claim withheld pending human review
  Signed bundle:               <path>/evidence-bundle.zip
  HTML report:                 <path>/report.html
```

The presentation should call out two outcomes with equal confidence:

- If treatment is lower cost and quality passes, the result is a valid
  reference-fixture measurement, not a promised customer saving.
- If treatment is not lower cost, show that honestly.  The mechanism is still
  valuable because the customer can decide from evidence rather than belief.

Verify the freshly generated evidence in the same terminal:

```bash
lean-ctx verify "$POC_DIR/comparisons/$TREATMENT_RUN_ID/evidence-bundle.zip" --json
```

Expected output shape:

```json
{
  "bundle_valid": true,
  "manifest_intact": true,
  "signature_valid": true,
  "files_verified": [
    {"path": "execution-receipt-baseline.json", "valid": true},
    {"path": "execution-receipt-treatment.json", "valid": true},
    {"path": "quality-comparison.json", "valid": true},
    {"path": "savings-receipt.json", "valid": true}
  ],
  "warnings": []
}
```

The exact verified file list can vary, but validity, manifest integrity, and
signature validity must all be `true` before the presenter says “signed.”

Optionally open the self-contained report locally after verification:

```bash
leanctx-poc report summary "$POC_DIR/comparisons/$TREATMENT_RUN_ID/report.html"
```

Expected output shape:

```text
Report ready for local sharing
  Contains: matched-arm summary, token/cost provenance, cache notes,
            quality evidence, limitations, receipt ID, signer fingerprint
  Contains no raw prompt or source by default
```

### 6. Tamper proof — 10:00–11:00

Do not tamper with the original bundle.  Copy it and alter one included JSON
field using a dedicated demo command, then verify the copy.

```bash
leanctx-poc tamper-demo \
  --input "$POC_DIR/comparisons/$TREATMENT_RUN_ID/evidence-bundle.zip" \
  --output "$POC_DIR/comparisons/$TREATMENT_RUN_ID/tampered-bundle.zip" \
  --file savings-receipt.json \
  --field treatment_cost_usd
lean-ctx verify "$POC_DIR/comparisons/$TREATMENT_RUN_ID/tampered-bundle.zip" --json
```

Expected output shape:

```json
{
  "bundle_valid": false,
  "manifest_intact": false,
  "signature_valid": false,
  "errors": ["hash mismatch: savings-receipt.json", "signature verification failed"]
}
```

Say:

> “This is why the receipt is useful in procurement and internal rollout.  It
> is not a screenshot and it does not need our cloud service to be checked.”

### 7. REPEAT — 11:00–12:30

Say:

> “AutoTune is deliberately not a black-box daemon in the POC.  It proposes
> the next bounded A/B test and waits for a human to approve it.”

Run:

```bash
leanctx-poc autotune propose \
  --from "$POC_DIR/comparisons/$TREATMENT_RUN_ID/comparison.json" \
  --candidate-kit code-review \
  --budget-usd 1.00 \
  --max-runs 2 \
  --dry-run
```

Expected output shape:

```text
AUTOTUNE PROPOSAL — NO RUNS EXECUTED
  Evidence source:       <comparison receipt ID>
  Hypothesis:            test one narrower context budget while retaining code-review quality gate
  Candidate policy:      code-review@1.0.0 + <explicit budget delta>
  Fixed controls:        fixture/model/task/quality evaluator/pricing snapshot
  Run budget:            <= 2 matched runs; <= $1.00 provider spend
  Stop rule:             stop on any automated-quality failure or budget breach
  Approval required:     yes
  Proposal artifact:     <path>/autotune-proposal.json
```

Do not run `autotune execute` in this meeting, even if it is later added.
The point is to make the feedback loop tangible while showing that budgets,
quality rules, and approvals are first-class.

## The final 150-second CTO close

Say:

> “In twelve minutes, we attached to an existing agent, measured a stock run,
> applied a visible context kit, reran the same task, and created evidence you
> can independently verify.  The next step is not a platform project: it is a
> 30-day pilot on one of your agents and up to three matched tasks.”

Then ask one concrete question:

> “Which existing coding or support agent runs often enough that a 40% lower
> verified cost per successful task would matter this quarter?”

Offer the bounded pilot:

```text
Verified Savings Pilot
  Scope:       one customer-owned agent, one workflow, up to three matched tasks
  Customer:    keeps provider, framework, code, and business process (BYOK)
  LeanCTX:     baseline, wrap/tune, quality gate, signed evidence, report
  Decision:    rollout, narrower experiment, or honest no-go
  Threshold:   >=40% lower VCP-SAT with no quality regression
  Evidence:    offline-verifiable signed bundle
```

Do not quote the price until the buyer agrees that one workflow and the stated
decision outcome are in scope.  The frozen plan’s commercial offer is CHF
7,500 prepaid for 30 days; that is the follow-up proposal, not a surprise
during the technical proof.

## Customer-agent follow-up: the next 30 minutes, not part of the POC clock

Once the CTO wants a pilot, use the POC harness with their agent in a scoped
technical session.

```bash
leanctx-poc scaffold-manifest \
  --agent '<customer agent entry point>' \
  --out customer-workload-manifest.draft.json
leanctx-poc preflight customer-workload-manifest.draft.json
```

Together, freeze:

- repository commit or sanitized fixture;
- one task prompt and acceptance condition;
- model, temperature, max tokens, and provider endpoint;
- a provider-cache policy and repeated-run rule;
- test command plus required human reviewer;
- permitted context, redaction, retention, and signer identity;
- success threshold and stop condition.

The customer path begins only after this manifest is approved.  It never uses
the reference-fixture result as proof of their savings.

## Explicit exclusions that keep this fast

- No dashboard, login, team workspace, or central receipt store.
- No agent builder, scheduler, generic orchestration, or managed execution.
- No second framework adapter before the OpenAI Agents SDK slice is sound.
- No automatic customer-code upload or default raw prompt retention.
- No claim that a cache discount is a LeanCTX saving; cache is captured by arm.
- No synthetic test output fallback in a commercial/demo evidence path.
- No opaque overall “quality score”; only declared tests, structured output,
  and recorded human review.
- No AutoTune execution without a proposed manifest, provider budget, and
  explicit approval.

## Minimum acceptance checklist before a live demo

- [ ] A clean machine completes `doctor` and first treatment in under 15 minutes.
- [ ] Stock and treatment invoke the same agent source hash.
- [ ] The manifest rejects a changed fixture, prompt, model, or parameter.
- [ ] Both arms report real provider usage or fail as `unavailable`.
- [ ] The code-review kit version/hash appears in treatment evidence.
- [ ] The quality evaluator uses fixture-backed expected findings.
- [ ] The original native-shaped output is retained for both arms.
- [ ] `compare --require-quality-pass` refuses an unmatched or failed arm.
- [ ] The comparison bundle self-verifies and offline verification passes.
- [ ] The tampered-copy verifier exits non-zero and names a failed integrity check.
- [ ] The dry-run AutoTune output contains budget, stop rule, and approval state.
- [ ] The presenter can state the limitation: reference evidence is not customer proof.

## Abort and recovery script

If the provider call fails:

> “The system has no usage evidence, so it refuses to generate a savings
> claim.  We can inspect the local workflow and schedule the measured run.”

If signing fails:

> “The native agent result remains available, but this run is not signed
> evidence.  We do not present it as verified.”

If quality fails:

> “The comparison rejects the treatment.  That is the intended guardrail; the
> next experiment changes the policy, not the reported result.”

If the two arms are more expensive/less efficient than expected:

> “This workload does not support a savings claim under the chosen policy.
> LeanCTX has made the decision visible early; we either test a constrained
> policy or stop.”

If the CTO asks for their production agent immediately:

> “We will not attach to production blind.  In the follow-up we create the
> workload manifest, redaction boundary, quality gate, and rollback plan; then
> we run the same short evidence loop against one approved workflow.”

## Why this is the absolute fastest credible path

The current repository already has strong local compression, a code-review
kit, provider-usage evidence building blocks, signing/verification primitives,
and an existing real-world evidence runner.  The missing product integration is
the correlated Python wrapped-run plus durable receipt path.

Therefore the fastest POC is not to finish a cloud platform or adapt every
agent framework.  It is to implement and rehearse one thin OpenAI Agents SDK
vertical slice:

```text
existing reference agent
  -> stock receipt
  -> versioned code-review kit
  -> wrapped run + context plan
  -> matched quality/cost comparison
  -> signed local bundle + offline verifier
  -> approval-gated AutoTune proposal
```

This sequence maps exactly to the canonical loop, exposes the product’s
defensible edge (verifiable cost per successful task), and leaves a CTO with a
small, safe next decision: nominate one agent for a measured pilot.

## Source constraints carried into this design

- The strategy’s retained fastest-POC principles are real tasks, real provider
  processes, evidence, and tamper rejection.
- A9 says the engine exists but `ctx.wrap(agent)`, run correlation, durable
  receipt lookup, and one-command comparison are product-integration gaps.
- A9 also requires no global runner monkey patch, explicit cost provenance,
  and quality component signals rather than a synthetic magic score.
- A13 freezes the first supported path as Python + OpenAI Agents SDK and the
  public surface as `LeanCTX.wrap`, `prepare`, `load_kit`, `receipt`, and
  `compare`.
- A13 specifies the code-review reference agent/kit, local signed receipts,
  a 15-minute external-developer quickstart, and an honest 40% VCP-SAT pilot
  threshold with no quality regression.
- A13 explicitly parks hosted history, dashboards, control planes, second
  framework adapters, marketplaces, and continuous hosted AutoTune.
