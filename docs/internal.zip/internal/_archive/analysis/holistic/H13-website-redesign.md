# H13 — LeanCTX Website Redesign

## Deliverable status

- Scope: complete homepage redesign and bilingual copy system.
- Product name: LeanCTX.
- Primary positioning: **The Context SDK for AI Agents.**
- Product promise: **Tune any agent. Prove every gain.**
- Primary audience: agent builders, AI platform teams, and coding-agent users.
- Secondary audience: engineering leaders, FinOps, security, and OSS adopters.
- Homepage job: turn an interested developer into an activated evaluator.
- Conversion path: connect an agent → measure a baseline → tune → prove → deploy.

## Source basis and claim discipline

- Strategy basis: `docs/internal/vision/SDK-STRATEGY-ALL-IN-ONE.md`.
- Strategy summary: `docs/internal/vision/SDK-STRATEGY-README.md`.
- Website audit: `docs/internal/analysis/A4-website-analysis.md`.
- Deployed implementation inspected: `deploy:website/src/pages/index.astro`.
- The deployed index delegates to `page-templates/IndexPageV2.astro`.
- Current web stack: Astro 6, Tailwind CSS 4, Instrument Sans, IBM Plex Mono.
- Current site supports localization and sitemap generation.
- Do not publish invented package availability, pricing, customer logos, or testimonials.
- Do not phrase the benchmark as a universal customer outcome.
- Use “calculated API cost” unless reconciled invoice cost is being discussed.
- Link evidence claims to methodology, receipts, scenarios, and limitations.
- Label planned features as preview, early access, or roadmap where appropriate.

## One-sentence position

### English

LeanCTX is the Context SDK for AI Agents: connect to any agent, tune what it sees, and prove every performance gain with evidence.

### Deutsch

LeanCTX ist das Context SDK für KI-Agenten: Verbinde jeden Agenten, optimiere seinen Kontext und belege jeden Performancegewinn mit Evidenz.

## Homepage information architecture

| Order | Section | Visitor question answered | Primary action |
| --- | --- | --- | --- |
| 01 | Header | What is this and where can I go? | Start free |
| 02 | Hero | Why should I care now? | Connect an agent |
| 03 | Problem | What is context waste costing me? | See how it works |
| 04 | How it works | What does LeanCTX actually do? | Run a baseline |
| 05 | Integration depths | Can this fit my agent architecture? | Choose a depth |
| 06 | Evidence | Can I trust the gain claim? | Read methodology |
| 07 | Context performance | What gets tuned? | Explore the engine |
| 08 | Profiles and deployment | Can I make this repeatable? | View profiles |
| 09 | Pricing | Which path fits my stage? | Start free / talk to us |
| 10 | Open source | What remains mine and open? | View GitHub |
| 11 | Final CTA | What should I do next? | Connect LeanCTX |
| 12 | Footer | Where are docs and contact routes? | Docs / GitHub / contact |

## Global navigation

### English labels

- Product
- Integrations
- Evidence
- Pricing
- Docs
- GitHub
- Start free

### Deutsche Labels

- Produkt
- Integrationen
- Evidenz
- Preise
- Docs
- GitHub
- Kostenlos starten

### Navigation behavior

- Keep Product, Integrations, Evidence, and Pricing as on-page anchors.
- Open Docs and GitHub as normal navigation destinations.
- Use one high-contrast “Start free” button.
- On mobile, retain the CTA outside the collapsed menu.
- Do not add a marketing mega-menu in the first release.
- Make the current locale switcher visible but visually quiet.

## 01 — Hero

### Purpose

- Establish the category in one glance.
- Reassure visitors that LeanCTX improves their agent rather than replacing it.
- Show a concrete SDK-shaped interaction without a product-tour detour.
- Provide one primary and one proof-oriented secondary action.

### English copy

**Eyebrow**

Context performance for AI agents

**Headline**

The Context SDK for AI Agents.

**Promise line**

Tune any agent. Prove every gain.

**Body**

LeanCTX connects to the agent you already use, removes context waste, and produces evidence you can inspect before you deploy.

**Primary CTA**

Connect your agent

**Secondary CTA**

See the evidence

**Microcopy below CTA**

Start local. Keep control. Measure before you change production.

### Deutsche Copy

**Eyebrow**

Context Performance für KI-Agenten

**Headline**

Das Context SDK für KI-Agenten.

**Promise line**

Optimiere jeden Agenten. Belege jeden Gewinn.

**Body**

LeanCTX verbindet sich mit dem Agenten, den du bereits nutzt, reduziert Kontextverschwendung und liefert überprüfbare Evidenz vor dem Deployment.

**Primary CTA**

Agenten verbinden

**Secondary CTA**

Evidenz ansehen

**Microcopy below CTA**

Lokal starten. Kontrolle behalten. Vor Produktion messen.

### Required three-line hero code example

```ts
import { withLeanCtx } from "lean-ctx-sdk";
const agent = withLeanCtx({ model, profile: "coding-v1" });
await agent.run({ prompt });
```

### Code-example rules

- Label it `SDK preview` until the exact public package and API are released.
- If the SDK signature changes, update all three lines atomically with the docs.
- Never show a non-existent package as an installable production instruction.
- For current coding-agent conversion, the adjacent link should lead to the supported MCP/CLI integration.
- Render the code in IBM Plex Mono with copy control and no faux terminal chrome.

### Hero visual direction

- Use a living context-flow diagram, not a generic robot or gradient orb.
- Show source inputs entering a compact “Context Plan” node.
- Show selected, compressed, reused, and measured context leaving the node.
- End with a signed “Execution Receipt” chip.
- Animate only the flow on hover or reduced-motion-safe scroll entry.
- Keep the visual understandable when reduced motion is enabled.
- On narrow screens, place the code before the diagram.

## 02 — The problem

### Purpose

- Name the failure mode plainly: agents repeatedly read, carry, and pay for context they do not need.
- Make the cost both technical and organizational: latency, spend, variance, and unprovable changes.
- Avoid asserting that every agent loses the same percentage.

### English copy

**Eyebrow**

Context is performance.

**Headline**

Your agent is doing more work than the task requires.

**Lead**

Most context waste is invisible: repeated file reads, oversized tool output, stale history, and the same facts sent again on every turn.

**Metric statement**

In a poorly tuned workflow, 80%+ of available context can be spent on repeated or low-value material. Measure your own baseline before treating that number as yours.

**Three problem cards**

1. **It re-reads.** Every unnecessary read consumes budget and attention.
2. **It carries stale state.** Old conversation and tool output crowd out the next decision.
3. **You cannot prove the fix.** A smaller prompt is not automatically a better outcome.

**Section CTA**

Find your baseline

### Deutsche Copy

**Eyebrow**

Kontext ist Performance.

**Headline**

Dein Agent erledigt mehr Arbeit, als die Aufgabe verlangt.

**Lead**

Die meiste Kontextverschwendung bleibt unsichtbar: wiederholte Datei-Reads, zu große Tool-Ausgaben, veralteter Verlauf und dieselben Fakten in jedem Turn.

**Metric statement**

In einem schlecht abgestimmten Workflow können 80 %+ des verfügbaren Kontexts für wiederholtes oder wenig wertvolles Material verbraucht werden. Miss zuerst deine eigene Baseline.

**Three problem cards**

1. **Er liest erneut.** Jeder unnötige Read verbraucht Budget und Aufmerksamkeit.
2. **Er trägt alten Zustand weiter.** Alter Verlauf und Tool-Output verdrängen die nächste Entscheidung.
3. **Du kannst den Fix nicht belegen.** Ein kleinerer Prompt ist nicht automatisch ein besseres Ergebnis.

**Section CTA**

Baseline ermitteln

### Problem-section design notes

- Present “80%+” as an illustrative, workflow-specific threshold, not a dashboard stat.
- Use a before/after context strip: grey repeated tokens versus selected signal tokens.
- Include an accessible textual equivalent for the visual.
- Avoid red error states; use warm orange for waste and steel/green for recovered signal.
- Keep this section sparse: one headline, three cards, one diagram, one link.

## 03 — How it works

### Purpose

- Explain the core product loop without introducing product jargon first.
- Make LeanCTX feel operational, not merely analytical.
- Carry the visitor from initial install through a safe production change.

### English copy

**Eyebrow**

One loop. Any agent.

**Headline**

Connect. Measure. Tune. Prove. Deploy.

**Lead**

LeanCTX turns context optimization into a repeatable performance loop.

**Step 1 — Connect**

Attach to the coding agent you use, wrap an existing agent, or embed the SDK in your own runtime.

**Step 2 — Measure**

Capture a baseline for context, cost, latency, and outcome quality.

**Step 3 — Tune**

Select, compress, reuse, and recover the context that actually helps the next action.

**Step 4 — Prove**

Compare treatment with baseline and keep an inspectable execution receipt.

**Step 5 — Deploy**

Version the winning Tuning Profile and ship it with confidence.

**CTA**

See the integration guide

### Deutsche Copy

**Eyebrow**

Ein Loop. Jeder Agent.

**Headline**

Verbinden. Messen. Optimieren. Belegen. Deployen.

**Lead**

LeanCTX macht Kontextoptimierung zu einem wiederholbaren Performance-Loop.

**Step 1 — Verbinden**

Docke an deinen Coding-Agenten an, kapsle einen bestehenden Agenten oder integriere das SDK in deine eigene Runtime.

**Step 2 — Messen**

Erfasse eine Baseline für Kontext, Kosten, Latenz und Ergebnisqualität.

**Step 3 — Optimieren**

Wähle Kontext aus, komprimiere ihn, nutze ihn wieder und stelle genau den Kontext wieder her, der die nächste Aktion unterstützt.

**Step 4 — Belegen**

Vergleiche Treatment und Baseline und behalte einen prüfbaren Execution Receipt.

**Step 5 — Deployen**

Versioniere das erfolgreiche Tuning Profile und bringe es sicher in Produktion.

**CTA**

Integrationsguide ansehen

### Interaction model

- Use a horizontal five-step rail on desktop and a numbered vertical sequence on mobile.
- Expand only one step at a time, with the first open by default.
- Give each step a real product artifact: integration, baseline, tuning plan, receipt, profile.
- The “Prove” step must link to the evidence methodology section, not only documentation.
- Do not depict this as a one-click autonomous optimizer.

## 04 — Integration depths

### Purpose

- Let every visitor self-select an integration path.
- Preserve the existing coding-agent wedge while showing the SDK is broader.
- Distinguish adoption depth from plan tier.

### English copy

**Eyebrow**

One engine. Three ways in.

**Headline**

Start where your agent is. Go deeper when you need control.

**Attach — For existing agents**

Connect through MCP, a proxy, or a supported coding-agent integration. Keep your agent and workflow; expose its context performance.

**Attach CTA**

Attach LeanCTX

**Wrap — For existing runtimes**

Put LeanCTX around an agent you operate. Add measurement, policy, and receipts without rewriting its core behavior.

**Wrap CTA**

Wrap an agent

**Embed — For agent builders**

Build LeanCTX into your runtime for direct context planning, profiles, and evidence at the application layer.

**Embed CTA**

Explore the SDK

**Bottom line**

Your agent stays your agent. LeanCTX makes its context measurable and tunable.

### Deutsche Copy

**Eyebrow**

Eine Engine. Drei Wege hinein.

**Headline**

Starte dort, wo dein Agent heute ist. Gehe tiefer, wenn du mehr Kontrolle brauchst.

**Attach — Für bestehende Agenten**

Verbinde über MCP, einen Proxy oder eine unterstützte Coding-Agent-Integration. Behalte Agent und Workflow; mache seine Context Performance sichtbar.

**Attach CTA**

LeanCTX andocken

**Wrap — Für bestehende Runtimes**

Lege LeanCTX um einen Agenten, den du betreibst. Ergänze Messung, Policy und Receipts, ohne sein Kernverhalten neu zu schreiben.

**Wrap CTA**

Agenten wrappen

**Embed — Für Agent Builder**

Baue LeanCTX in deine Runtime ein: für direkte Context Planning, Profiles und Evidenz auf Applikationsebene.

**Embed CTA**

SDK erkunden

**Bottom line**

Dein Agent bleibt dein Agent. LeanCTX macht seinen Kontext messbar und optimierbar.

### Integration comparison table

| Depth | Best for | Surface | Commitment | Proof artifact |
| --- | --- | --- | --- | --- |
| Attach | Supported coding agents | MCP, proxy, shell integration | Lowest | Local baseline and receipt |
| Wrap | Teams operating an agent runtime | Runtime wrapper | Medium | Policy and receipt stream |
| Embed | Product teams building agents | Context SDK | Deepest | Versioned profile and application evidence |

### Design notes

- Make all three cards equal in visual status; “Embed” must not imply Attach is inferior.
- Give Attach the first position because it is the fastest path to the first proof.
- Show availability badges only when their status is verified: Available, Preview, or Planned.
- Never use “no-code” if configuration or approval is actually required.

## 05 — Evidence

### Purpose

- Put proof at the center of the brand promise.
- Show the strongest available benchmark without stripping its methodology.
- Teach visitors the difference between a claim, a baseline, and evidence.

### English copy

**Eyebrow**

Evidence, not anecdotes.

**Headline**

No savings claim without a baseline.

**Lead**

LeanCTX compares a declared treatment with a declared baseline and keeps the result inspectable.

**Primary benchmark number**

79–86% lower calculated API cost

**Benchmark statement**

In three controlled five-turn coding-agent scenarios using real OpenAI API calls, the tested LeanCTX treatment produced approximately 79–86% lower calculated API cost than the baseline under the declared methodology.

**Evidence labels**

- Controlled scenarios
- Five turns each
- Real provider API calls
- Calculated API cost
- Declared methodology

**Evidence CTA**

Read the benchmark methodology

**Trust note**

This is a controlled benchmark result, not a promise of identical savings for every workload.

### Deutsche Copy

**Eyebrow**

Evidenz statt Anekdoten.

**Headline**

Keine Einsparbehauptung ohne Baseline.

**Lead**

LeanCTX vergleicht ein klar definiertes Treatment mit einer klar definierten Baseline und hält das Ergebnis prüfbar.

**Primary benchmark number**

79–86 % niedrigere berechnete API-Kosten

**Benchmark statement**

In drei kontrollierten Coding-Agent-Szenarien mit jeweils fünf Turns und realen OpenAI-API-Calls erzielte das getestete LeanCTX-Treatment unter der deklarierten Methodik ungefähr 79–86 % niedrigere berechnete API-Kosten als die Baseline.

**Evidence labels**

- Kontrollierte Szenarien
- Je fünf Turns
- Reale Provider-API-Calls
- Berechnete API-Kosten
- Deklarierte Methodik

**Evidence CTA**

Benchmark-Methodik lesen

**Trust note**

Das ist ein kontrolliertes Benchmark-Ergebnis, keine Zusage identischer Einsparungen für jeden Workload.

### Evidence-module specification

- Use the benchmark number as the largest element, with the qualifier always visible.
- Show a slim paired bar chart: Baseline versus LeanCTX treatment for three scenarios.
- Do not invent scenario names, exact dollar values, quality scores, or provider invoice totals.
- Source chart values from the benchmark artifact during implementation.
- Place the methodology link directly beside the metric, not below the fold.
- Add links for receipt schema and anti-cheating rules when public.
- Offer a text table alternative for screen readers and print.
- Avoid count-up animation; a stable number is more credible and more accessible.

## 06 — What LeanCTX tunes

### English copy

**Eyebrow**

The engine beneath the loop.

**Headline**

Make context earn its place.

**Lead**

LeanCTX plans the context for the next action instead of passing through everything the agent has ever seen.

**Select**

Bring forward the facts, files, and history that matter now.

**Compress**

Reduce tool output and source material without losing the decision-critical signal.

**Reuse**

Keep verified context available instead of fetching and paying for it again.

**Recover**

Restore precise detail when the next action requires it.

**Measure**

Record what changed, what it cost, and whether the outcome held up.

### Deutsche Copy

**Eyebrow**

Die Engine unter dem Loop.

**Headline**

Kontext muss seinen Platz verdienen.

**Lead**

LeanCTX plant den Kontext für die nächste Aktion, statt alles weiterzugeben, was ein Agent jemals gesehen hat.

**Select**

Bringe die Fakten, Dateien und den Verlauf nach vorn, die jetzt relevant sind.

**Compress**

Reduziere Tool-Output und Quellmaterial, ohne entscheidungskritisches Signal zu verlieren.

**Reuse**

Halte geprüften Kontext bereit, statt ihn erneut abzurufen und erneut zu bezahlen.

**Recover**

Stelle präzise Details wieder her, wenn die nächste Aktion sie braucht.

**Measure**

Halte fest, was sich verändert hat, was es gekostet hat und ob das Ergebnis standhält.

### Design direction

- Use five compact verbs around a central Context Plan rather than five feature cards.
- Let each verb reveal a single sentence and a small technical illustration.
- Keep each illustration abstract enough to be provider-neutral.
- Use a receipt icon only for Measure; do not decorate every feature with badges.

## 07 — Profiles and deployment

### English copy

**Eyebrow**

Performance you can version.

**Headline**

Turn a measured improvement into a deployable profile.

**Body**

When a treatment wins, capture its context policy as a Tuning Profile. Review it, version it, and deploy the exact change you measured.

**CTA**

Explore Tuning Profiles

### Deutsche Copy

**Eyebrow**

Performance, die du versionieren kannst.

**Headline**

Mache aus einer gemessenen Verbesserung ein deploybares Profile.

**Body**

Wenn ein Treatment gewinnt, halte seine Context Policy als Tuning Profile fest. Prüfe, versioniere und deploye genau die Änderung, die du gemessen hast.

**CTA**

Tuning Profiles erkunden

### Product-truth guardrail

- Mark this area Preview until Profile lifecycle and deploy interfaces are publicly available.
- If the visitor cannot create a profile today, use “See the architecture” instead of “Create a profile.”
- Link to an example receipt, never a fabricated product screenshot.

## 08 — Pricing

### Pricing principle

- The strategy defines tiers but does not establish public numeric prices.
- Do not fabricate monthly amounts, usage limits, or enterprise commitments.
- Launch the pricing area with truthful availability states, clear inclusions, and a sales/contact route.
- Replace “Early access” with prices only after commercial terms are approved.

### English section copy

**Eyebrow**

Start open. Scale with proof.

**Headline**

Pricing that follows integration depth and operational need.

**Lead**

Use the open runtime locally. Add continuous tuning, team controls, and enterprise deployment when your agents need them.

### Deutsche Section Copy

**Eyebrow**

Offen starten. Mit Evidenz skalieren.

**Headline**

Preise, die Integrationsgrad und operativen Bedarf folgen.

**Lead**

Nutze die offene Runtime lokal. Ergänze kontinuierliches Tuning, Team Controls und Enterprise Deployment, wenn deine Agenten es brauchen.

### Pricing cards

#### Developer — Free / Developer — Kostenlos

**English name and price**

Developer — Free forever

**German name and price**

Developer — Dauerhaft kostenlos

**English body**

For developers who want to connect a supported agent, run locally, and understand context performance.

**German body**

Für Entwickler:innen, die einen unterstützten Agenten verbinden, lokal arbeiten und Context Performance verstehen möchten.

**Included, English**

- Open-source runtime
- Local-first operation
- Supported coding-agent integrations
- Core context engine
- Local measurement and receipts

**Enthalten, Deutsch**

- Open-Source-Runtime
- Local-first Betrieb
- Unterstützte Coding-Agent-Integrationen
- Core Context Engine
- Lokale Messung und Receipts

**CTA, English**

Start free

**CTA, Deutsch**

Kostenlos starten

#### Pro — Early access / Pro — Early Access

**English status**

Pro — Early access

**German status**

Pro — Early Access

**English body**

For builders who need continuous measurement, reusable Tuning Profiles, and deeper optimization workflows.

**German body**

Für Builder, die kontinuierliche Messung, wiederverwendbare Tuning Profiles und tiefere Optimierungs-Workflows benötigen.

**Pro value bullets, English**

- Continuous performance intelligence
- Advanced tuning workflows
- Profile lifecycle features when released
- Priority product access

**Pro value bullets, Deutsch**

- Kontinuierliche Performance Intelligence
- Erweiterte Tuning Workflows
- Profile-Lifecycle-Features bei Verfügbarkeit
- Priorisierter Produktzugang

**CTA, English**

Join Pro early access

**CTA, Deutsch**

Pro Early Access anfragen

#### Team — Talk to us / Team — Sprich mit uns

**English status**

Team — Contact us

**German status**

Team — Kontakt aufnehmen

**English body**

For teams standardizing how multiple agents are measured, tuned, reviewed, and deployed.

**German body**

Für Teams, die messen, optimieren, prüfen und deployen über mehrere Agenten hinweg standardisieren.

**Team value bullets, English**

- Shared profiles and evidence
- Team-level controls
- Reviewable rollout workflow
- Organization-level visibility

**Team value bullets, Deutsch**

- Geteilte Profiles und Evidenz
- Controls auf Teamebene
- Prüfbahrer Rollout-Workflow
- Transparenz auf Organisationsebene

**CTA, English**

Talk about Team

**CTA, Deutsch**

Über Team sprechen

#### Enterprise — Designed together / Enterprise — Gemeinsam konzipiert

**English status**

Enterprise — Talk to us

**German status**

Enterprise — Kontakt aufnehmen

**English body**

For organizations operating agent infrastructure with governance, deployment, security, and evidence requirements.

**German body**

Für Organisationen, die Agent-Infrastruktur mit Anforderungen an Governance, Deployment, Sicherheit und Evidenz betreiben.

**Enterprise value bullets, English**

- Enterprise integration design
- Governance and policy controls
- Deployment and evidence architecture
- Security and procurement collaboration

**Enterprise value bullets, Deutsch**

- Enterprise-Integrationsdesign
- Governance- und Policy-Controls
- Deployment- und Evidenzarchitektur
- Zusammenarbeit zu Security und Procurement

**CTA, English**

Design an Enterprise rollout

**CTA, Deutsch**

Enterprise-Rollout planen

### Pricing UX rules

- Highlight Developer as the default path, not a bait tier.
- Use visible status chips: Free forever, Early access, Contact us.
- Keep every plan comparable on the same baseline: runtime, measurement, profiles, controls, support.
- Add a plain-language “What stays open?” link immediately below the cards.
- No annual-discount switch until numeric pricing exists.
- Do not gate the benchmark methodology behind a pricing form.

## 09 — Open source

### Purpose

- State the OSS boundary as a product promise, not a footnote.
- Separate the free local engine from paid continuous intelligence and organization-scale capabilities.
- Make developer trust an explicit conversion mechanism.

### English copy

**Eyebrow**

Open engine. Inspectable evidence.

**Headline**

The engine stays open.

**Body**

LeanCTX keeps the local runtime, core context engine, open contracts, and supported local integrations available to developers. You can inspect the engine, run it locally, and keep control of your agent workflow.

**Paid-boundary sentence**

What becomes commercial is continuous intelligence, organization-scale controls, managed infrastructure, and advanced tuning workflows—not your right to understand the engine.

**Primary CTA**

View on GitHub

**Secondary CTA**

Read the open-source boundary

### Deutsche Copy

**Eyebrow**

Offene Engine. Prüfbare Evidenz.

**Headline**

Die Engine bleibt offen.

**Body**

LeanCTX hält die lokale Runtime, die Core Context Engine, offene Contracts und unterstützte lokale Integrationen für Entwickler:innen verfügbar. Du kannst die Engine prüfen, lokal betreiben und die Kontrolle über deinen Agenten-Workflow behalten.

**Paid-boundary sentence**

Kommerziell werden kontinuierliche Intelligence, Controls für Organisationen, Managed Infrastructure und erweiterte Tuning Workflows — nicht dein Recht, die Engine zu verstehen.

**Primary CTA**

Auf GitHub ansehen

**Secondary CTA**

Open-Source-Grenze lesen

### Open-source content checklist

- Link to the repository.
- Link to the applicable license.
- Link to public contracts and receipt schema when available.
- State local-first behavior precisely.
- Explain commercial boundaries in the same section as the free offer.
- Do not use “open core” without explaining what remains open.

## 10 — Final conversion section

### English copy

**Headline**

Put one agent on the Dyno.

**Body**

Connect a real workflow, establish the baseline, and decide with evidence whether a tuning change is worth deploying.

**Primary CTA**

Connect LeanCTX

**Secondary CTA**

Talk to an expert

**Reassurance**

Start with one agent. Keep the control plane local.

### Deutsche Copy

**Headline**

Setze einen Agenten auf den Dyno.

**Body**

Verbinde einen echten Workflow, erstelle die Baseline und entscheide anhand von Evidenz, ob ein Tuning-Change das Deployment wert ist.

**Primary CTA**

LeanCTX verbinden

**Secondary CTA**

Mit Expert:in sprechen

**Reassurance**

Starte mit einem Agenten. Behalte die Control Plane lokal.

## 11 — Footer

### Footer structure

| Column | English heading | Deutsche Überschrift | Links |
| --- | --- | --- | --- |
| Product | Product | Produkt | How it works, Integrations, Evidence, Pricing |
| Build | Build | Entwickeln | Docs, SDK reference, Examples, Changelog |
| Open | Open source | Open Source | GitHub, License, Security, Status |
| Company | Company | Unternehmen | Contact, Enterprise, Privacy, Legal |

### English footer lockup

LeanCTX — The Context SDK for AI Agents.

Tune any agent. Prove every gain.

### Deutsche footer lockup

LeanCTX — Das Context SDK für KI-Agenten.

Optimiere jeden Agenten. Belege jeden Gewinn.

### Required footer links

- Docs: link to the canonical documentation URL.
- GitHub: link to the canonical public repository.
- Contact: mailto or contact form with a visible response expectation only if verified.
- Security: link to the security policy.
- Privacy and legal: link to the canonical legal pages.
- Language selector: English and Deutsch at minimum.

### Footer social policy

- Do not add social icons without an active, maintained destination.
- GitHub is required because the OSS boundary is a core trust claim.
- Use text links with accessible labels; icons are supplementary.

## Visual system

### Brand character

- Serious engineering instrument, not AI spectacle.
- Precise, inspectable, local-first, and performance-oriented.
- The visual metaphor is a calibrated instrument or performance trace.
- Prefer diagrams, receipts, diff-like comparisons, and evidence cards.
- Avoid robot art, brains, starscapes, and vague “intelligence” blobs.

### Color application

- Carbon: main background and text foundation.
- Bone: high-legibility content surfaces and inverse blocks.
- Steel: borders, secondary UI, topology lines, and quiet data.
- Signal orange: singular focus color for CTAs, measured change, and active flow.
- Reserve green or blue success colors for actual verified state, not marketing decoration.
- Meet WCAG contrast requirements in both themes if a light theme is retained.

### Typography

- Use Instrument Sans for headlines, body, navigation, and buttons.
- Use IBM Plex Mono for code, labels, metrics metadata, and receipts.
- Keep headings short; the typography should feel editorial, not enterprise SaaS generic.
- Set metric qualifiers in the same reading order and at legible size.
- Avoid all-caps body text and dense technical paragraphs.

### Layout

- Desktop content rail: approximately 1200–1280px maximum.
- Hero: two balanced columns, copy first, code/flow visual second.
- Section rhythm: alternate calm textual blocks with technical evidence modules.
- Use 12-column desktop grid and four-column mobile grid.
- Give proof modules full-width breathing room.
- Keep CTA placement consistent at section ends.

### Motion

- Motion explains flow; it must never be purely decorative.
- Respect `prefers-reduced-motion` with a static sequence diagram.
- Use short opacity and position transitions, not looping animations.
- Do not animate benchmark values or cost reductions.
- Ensure keyboard navigation does not trigger disorienting scroll effects.

## Accessibility requirements

- One `h1` only: “The Context SDK for AI Agents.”
- Preserve a logical heading order throughout the page.
- Provide text equivalents for context-flow diagrams and benchmark charts.
- Give all CTA links specific accessible names.
- Use a visible keyboard focus state with sufficient contrast.
- Allow code block copy without requiring a pointer device.
- Verify English and German line wraps at 320px, 768px, 1024px, and 1440px.
- Do not rely on color alone to distinguish baseline and treatment.
- Honor reduced motion and user font-size preferences.
- Keep benchmark caveats in the accessible name/reading flow, not a hover-only tooltip.

## Search, social, and metadata copy

### English title

LeanCTX — The Context SDK for AI Agents

### English meta description

Tune any AI agent’s context, measure the baseline, and prove every performance gain with inspectable evidence.

### German title

LeanCTX — Das Context SDK für KI-Agenten

### German meta description

Optimiere den Kontext jedes KI-Agenten, miss die Baseline und belege jeden Performancegewinn mit prüfbarer Evidenz.

### Open Graph title

LeanCTX — Tune any agent. Prove every gain.

### Open Graph description

The Context SDK for AI Agents. Connect, measure, tune, prove, and deploy context performance.

### Schema direction

- Use `SoftwareApplication` or `Product` only for capabilities available at launch.
- Add `Organization` metadata with canonical public links.
- Avoid `AggregateRating`, fabricated reviews, and price schema until verified.
- Localize metadata rather than translating only body copy.

## Technical recommendation

### Recommendation

Continue with the deployed Astro implementation; do not replace the framework for this redesign.

### Evidence from deployed branch

- `deploy:website/src/pages/index.astro` is an Astro page delegating to `IndexPageV2.astro`.
- `deploy:website/package.json` declares Astro `^6.0.8`.
- The deployed package uses Tailwind CSS `^4.2.2` through `@tailwindcss/vite`.
- The deployed package includes Instrument Sans and IBM Plex Mono font packages.
- The deployed Astro configuration includes localization and sitemap support.
- Build command is `astro build`, followed by Pagefind indexing.

### Implementation approach

- Replace or create a dedicated Astro homepage template rather than re-platforming.
- Keep static-first rendering for fast, crawlable marketing pages.
- Use Astro components for sections, cards, charts, and CTA patterns.
- Keep rich interaction in progressive-enhancement islands only where needed.
- Use CSS/SVG for the context-flow visual and benchmark chart before reaching for a canvas dependency.
- Put copy in locale data files so English and German share one component structure.
- Reuse the existing validation, localization, and Pagefind build pipeline.
- Add image assets only when they carry product information; the first version can be diagram-led.

### Suggested component map

| Component | Responsibility | Data source |
| --- | --- | --- |
| `SiteHeader.astro` | Nav, locale, global CTA | locale navigation data |
| `HeroContextSdk.astro` | Position, code, visual, CTAs | homepage locale copy |
| `ProblemContextWaste.astro` | Problem statement and diagram | homepage locale copy |
| `ProductLoop.astro` | Five-step Connect-to-Deploy rail | loop data |
| `IntegrationDepths.astro` | Attach, Wrap, Embed chooser | integration data |
| `EvidenceBenchmark.astro` | Qualified metric and methodology link | verified benchmark JSON/data |
| `ContextEngine.astro` | Select/Compress/Reuse/Recover/Measure | engine data |
| `ProfilesPreview.astro` | Profile/deployment narrative | feature-status data |
| `PricingGrid.astro` | Tier cards and availability state | commercial config |
| `OpenSourceBoundary.astro` | OSS promise and repository links | OSS boundary data |
| `FinalCta.astro` | Conversion close | locale CTA data |
| `SiteFooter.astro` | Docs, GitHub, contact, legal | global link data |

### Content-model recommendation

- Keep `en` and `de` homepage copy in structured locale modules, not duplicated templates.
- Store benchmark values and qualifiers separately from display prose.
- Make evidence source URLs mandatory fields when a benchmark card is enabled.
- Make feature availability an enum: `available`, `preview`, `planned`.
- Make pricing availability an enum: `free`, `early_access`, `contact`.
- Fail build validation if a public claim has no evidence source or qualifier.

## Conversion paths

### Developer path

Hero CTA → Attach → Docs → local install → baseline → receipt → GitHub/star/share.

### Agent-builder path

Hero code → Embed → SDK/reference → profile architecture → Pro early access.

### Team path

Evidence → Wrap → team controls → contact → scoped tuning engagement.

### Enterprise path

Evidence → Enterprise → governance/security materials → conversation → rollout design.

## Claim review checklist before launch

- Is every current-product claim documented and available today?
- Is every benchmark number tied to its declared methodology?
- Does every evidence card state “calculated API cost” where appropriate?
- Does the 79–86% result retain its three-scenario and five-turn qualifiers?
- Is “80%+ context waste” framed as a problem pattern, not a universal result?
- Are preview or planned SDK/Profile surfaces visibly labeled?
- Do pricing cards avoid invented prices and limits?
- Does the OSS section state both what remains open and what becomes paid?
- Are Docs, GitHub, contact, privacy, and security links live?
- Does German copy preserve the qualifier and not overstate the English source?

## Build order

1. Establish structured English and German page-copy data.
2. Build header, hero, and five-step loop with mobile layouts.
3. Implement integration-depth cards and global CTA routes.
4. Implement evidence module from verified benchmark data and methodology link.
5. Add pricing and OSS modules with status-driven UI.
6. Build footer, legal links, metadata, and localized routes.
7. Add the context-flow diagram, then benchmark SVG/table alternative.
8. Run existing localization, positioning, fact, accessibility, and production-build checks.
9. Review every claim with product/evidence owners before deployment.

## Acceptance criteria

- The first viewport communicates “Context SDK,” “AI Agents,” and “Tune any agent. Prove every gain.”
- The hero contains the exact three-line SDK-preview example or a verified replacement.
- English and German versions include complete equivalent copy for every primary section.
- The Problem section introduces 80%+ context waste without making it a universal benchmark claim.
- The loop visibly includes Connect, Measure, Tune, Prove, and Deploy.
- Attach, Wrap, and Embed each have a distinct audience, explanation, and CTA.
- The evidence card states 79–86% lower calculated API cost and its controlled-scenario qualifier.
- Pricing contains Developer, Pro, Team, and Enterprise without invented numerical prices.
- Open source clearly states what is free forever and what becomes commercial.
- Footer exposes Docs, GitHub, and contact routes.
- The implementation remains Astro-first and works with the deployed localization/build pipeline.
- The page meets keyboard, contrast, reduced-motion, and mobile requirements.

## Final copy lockup

### English

LeanCTX — The Context SDK for AI Agents.

Tune any agent. Prove every gain.

### Deutsch

LeanCTX — Das Context SDK für KI-Agenten.

Optimiere jeden Agenten. Belege jeden Gewinn.
