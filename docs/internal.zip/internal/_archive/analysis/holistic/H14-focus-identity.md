# Thinkery / LeanCTX — Focus & Identity

## Status

This is the definitive positioning document for the next 90 days.

It is the decision rule for product, sales, partnerships, and messaging.

If a claim, feature, or conversation does not reinforce this document, it is secondary.

---

## 1. Identity

> **Thinkery is the context-performance engineering company; LeanCTX is its Context SDK for AI agents that reduces, tunes, measures, and independently proves the cost/quality of an agent’s pre-inference context.**

This is one identity, not a list of adjacent categories.

We are not an agent host.

We are not an LLM gateway.

We are not an observability suite.

We are not a prompt-management product.

We are not a generic AI consultancy.

We are the layer that makes an existing agent’s working context efficient, repeatable, and provable.

### Product hierarchy

Thinkery AG is the company and commercial operator.

LeanCTX is the product and technical runtime.

The Context SDK for AI Agents is the public category name.

The Context Runtime is the technical engine behind the SDK.

The Dyno is the controlled benchmarking and tuning environment.

A Tuning Profile is the versioned, deployable context strategy for a workload.

A Receipt is the signed, privacy-preserving evidence of a measured result.

### The category in one line

LeanCTX is the pre-inference context-efficiency layer for AI agents.

### The category boundary

Observability tells a team what happened.

Gateways route and record model calls.

Evals judge output quality.

Governance controls permitted usage.

Agent hosts build or operate agents.

LeanCTX improves the information supplied before inference, then measures and proves the result.

---

## 2. Focus: one objective for the next 90 days

> **Turn the Dyno / Tuning Sprint loop into a repeatable paid engagement that demonstrably improves one real production coding-agent workflow and produces a signed, quality-gated receipt the customer can verify offline.**

This is the only top-level objective.

The point is not to prove every future platform capability.

The point is to prove one commercial truth repeatedly.

The proof must show all five conditions.

1. LeanCTX changes the economics of a real agent.

2. The workflow stays within an agreed quality threshold.

3. The experiment is reproducible under a stated methodology.

4. A customer pays for the work.

5. The result can be repeated on a second workflow or customer.

### The operating loop

Connect the existing agent.

Baseline the representative workload.

Tune the context strategy.

Validate cost, latency, and quality on the same workload.

Deploy the accepted Tuning Profile.

Repeat as the workload changes.

### The 90-day deliverable

One production coding-agent workflow on the Dyno.

One customer-approved quality contract.

One transparent baseline-versus-treatment comparison.

One versioned Tuning Profile that can be deployed or rolled back.

One signed Receipt and Evidence Bundle.

One customer-facing report and rollout recommendation.

One paid referenceable Tuning Sprint, subject to customer permission.

### What success looks like

The customer can explain the result without trusting a sales slide.

The engineering team can rerun the workload under the same controls.

The finance or security team can verify the signed aggregate offline.

The account team can sell the next workload from proof, not promise.

### What is deliberately out of focus

Building a new general-purpose agent platform.

Competing feature-for-feature with agent IDEs.

Replacing Langfuse, Helicone, Braintrust, or governance systems.

Claiming universal token-reduction percentages.

Commercializing AutoTune before the Dyno proof loop is credible and repeatable.

Adding a hosted service where a local product path proves the same commercial truth.

### The decision filter

Prioritize work that makes Connect → Baseline → Tune → Validate → Deploy more credible, faster, or easier to buy.

Deprioritize work that does not improve that loop within 90 days.

---

## 3. Explanation by audience

## A developer — 30 seconds

### The talk track

Your agent wastes context long before the model request is sent.

It rereads files, receives noisy search results, ingests huge shell output, and repeats provider data across turns.

LeanCTX sits at those tool boundaries and gives the agent a smaller, task-relevant working set.

You connect it through MCP, the proxy, wrappers, or the SDK; you keep your existing agent and model.

Then we compare the same workload with and without the context strategy, keep the result only if task quality holds, and save the winning strategy as a versioned Tuning Profile.

It is performance engineering for the agent context, not a new chatbot.

### The developer close

Bring us one slow, expensive, or brittle agent workflow; we will put it on the Dyno and show the before/after under the same conditions.

### Developer proof points

Tool-aware context operations cover files, search, shell output, provider results, handoffs, and memory.

The strategy is versioned, comparable, deployable, and rollbackable.

The quality contract is workload-specific: build correctness, task completion, evaluator score, or human acceptance.

No savings result counts if the declared quality contract fails.

### Do not lead with

Cryptography before the developer understands the workflow.

Generic “AI optimization” language.

Unqualified percentage savings.

## A CTO — 2 minutes

### The talk track

Your organization has chosen agents, models, and observability tools.

The next production problem is not merely whether an agent can act; it is whether you can operate it reliably, economically, and accountably as tool use expands.

Most context cost is created before the model call: files, code search, terminal output, RAG results, MCP providers, and handoffs repeatedly inflate the agent’s working set.

LeanCTX is the pre-inference context-efficiency layer for the agent stack you already run.

It selects, compresses, reuses, and recovers the working context at those boundaries.

It does not ask you to replace your agent host, model provider, gateway, or observability platform.

It makes their economics better by reducing unnecessary upstream context.

We establish a representative workload and a quality contract first.

The Dyno then compares baseline and treatment on the same model, source revision, timeout, budget, and task controls unless a variable is intentionally under test.

The result reports context usage, provider-reported usage, calculated cost, latency, task completion, and quality.

The output is a versioned Tuning Profile, a deployment recommendation, and a signed Receipt that can be verified offline without exposing raw prompts, code, paths, or event data.

Start with one production coding-agent workflow where spend, reliability, or auditability is material.

If quality does not hold, there is no claimed saving.

### CTO close

Approve one bounded Tuning Sprint and one owner for a representative workflow; the decision after the sprint is evidence-based rollout, iteration, or stop.

### CTO proof points

The customer retains its existing agent and model choices.

The method makes baseline, treatment, and quality gates explicit.

The Tuning Profile supports reproducibility, comparison, deployment, and rollback.

The Receipt supports independent integrity and origin checks offline.

Calculated provider cost is never presented as reconciled invoice cost unless it has been reconciled.

### CTO risk answer in one sentence

LeanCTX limits change to the context-control plane, validates against the customer’s own quality threshold, and leaves the existing agent stack in place.

## An investor — 5 minutes

### The opening

AI agents are becoming production systems, but their economics degrade as they consume files, logs, search results, RAG chunks, tool outputs, and inter-agent handoffs.

The industry has invested heavily in model hosting, agent frameworks, observability, evaluation, and governance.

Those products mostly inspect, route, judge, or control what happened around a model call.

The missing operational layer is the working context before inference.

### The category

LeanCTX defines the Context SDK for AI Agents.

It is a local-first, agent-native layer that improves the information supplied from files, search, shell output, providers, and handoffs.

It measures the resulting token and outcome economics.

It then makes the result independently verifiable without revealing proprietary prompts or code.

The category is context-performance engineering.

### Why now

Agentic workloads amplify context waste with every tool call and handoff.

Native retrieval, memory, caches, rules, and compaction features are useful, but they are usually opaque host features rather than a measurable control plane.

As teams move from demos to fleets, the buying question shifts from “can the agent act?” to “can we run it reliably, economically, and accountably at scale?”

LeanCTX answers that question at the point the cost is created.

### The product loop

Connect an existing agent.

Measure a representative workload.

Tune the context strategy.

Prove cost and quality on matched controls.

Deploy the winning Tuning Profile.

Repeat as workloads drift.

The local developer product provides the integration surface.

The Dyno turns it into a controlled business case.

Tuning Profiles turn a result into a reusable operational asset.

Receipts turn a claim into a verifiable artifact.

### Why it can be durable

First, LeanCTX acts before inference at the tool boundary, where redundant agent payload accumulates.

Second, it optimizes useful efficiency rather than compression alone: cost and latency are evaluated subject to an accepted quality threshold.

Third, the evidence chain compounds trust: per-event accounting, shadow baselines, quality-hold reporting, hash-chained records, and Ed25519-signed aggregates enable offline verification.

Fourth, MCP and SDK/proxy access make the layer portable across the agent hosts customers have already selected.

Fifth, the compounding commercial assets are workload-specific Tuning Profiles, benchmark history, private Kits, organizational evidence, and continuous retuning—not lock-in to a new agent host.

### What is monetized

The immediate offer is a paid Tuning Sprint on one production workflow.

The engagement delivers a baseline, tuned integration, Tuning Profile, Receipt, report, and rollout recommendation.

The follow-on opportunity is continuous tuning, private profile and kit registries, team comparison, larger benchmark matrices, shared evidence, policy, and organization-scale operations.

The commercial sequence is developer utility → Dyno proof → private operational assets → continuous optimization.

### What we will prove in 90 days

We will not attempt to prove a complete future platform.

We will prove that LeanCTX improves one real production coding-agent workflow economically while quality holds, that the method is reproducible, that a customer pays, and that the proof can be repeated.

This creates a credible wedge before platform expansion.

### Investor close

The investment thesis is not “another wrapper around cheaper inference.”

It is the emergence of context efficiency as an independent operational control plane for agents, with evidence that is strong enough for engineering, finance, security, and procurement to share.

## A partner / SI — 10 minutes

### The opening

You already help customers select models, build agents, integrate data, secure deployments, and deliver outcomes.

LeanCTX gives you a measurable optimization engagement to attach to those projects.

It does not displace the customer’s chosen agent host or your existing delivery scope.

It makes the agent workstream easier to justify and govern by turning context cost and quality into a controlled improvement loop.

### Where LeanCTX fits in an engagement

The customer has an existing agent with a real workflow.

The SI identifies a representative production task and the business owner.

The SI and customer agree on quality gates and controls.

LeanCTX connects at the agent’s tool/context boundaries.

The Dyno establishes a baseline and tests a limited number of candidate context strategies.

The winning strategy becomes a Tuning Profile.

The SI helps deploy, monitor, and expand that profile across adjacent workflows.

### The partner value

The partner can sell a bounded assessment with concrete artifacts.

The partner can avoid unsupported ROI claims by using measured baseline-versus-treatment evidence.

The partner can differentiate an agent implementation with ongoing performance engineering.

The partner can extend the engagement into rollout, governance feeds, operating-model design, and continuous optimization.

The partner keeps ownership of business-process change, integration, and customer success.

LeanCTX supplies the context-efficiency layer and evidence method.

### The standard engagement

Step 1: Choose one workflow with meaningful tool-context volume.

Step 2: Freeze the source revision, agent version, model, timeout, budget, and task definition.

Step 3: Define quality: build/test success, factual accuracy, acceptance, policy pass, or required human approval.

Step 4: Run the baseline.

Step 5: Apply LeanCTX context strategies and candidate Tuning Profiles.

Step 6: Run treatment under the same controls.

Step 7: Report all arms, retries, caching, failures, cost method, and quality outcome.

Step 8: Recommend deploy, iterate, or stop.

Step 9: Deliver the Tuning Profile and signed Receipt.

Step 10: Expand only after a demonstrated result.

### The proof package

The customer receives a transparent methodology version.

The customer receives provider-reported usage separately from calculated provider cost.

The customer receives the source digests and profile versions necessary to understand reproducibility.

The customer receives the stated quality contract and its outcome.

The customer receives a privacy-preserving signed aggregate to verify integrity and origin offline.

The signed artifact does not serialize raw prompts, code, file paths, raw events, or per-event timestamps.

### The partner positioning

Say: “We help you turn an existing agent into a measurable, cost/quality-controlled production system.”

Say: “We will prove the gain on your workload before recommending rollout.”

Say: “This complements your observability, evaluation, and governance investments.”

Do not say: “We guarantee a fixed percentage saving.”

Do not say: “LeanCTX replaces your agent platform.”

Do not say: “The Receipt proves business value without a quality contract.”

### Partner close

Bring one customer workflow where agent spend, latency, reliability, or auditability matters; co-sell a bounded Tuning Sprint and let the evidence determine the expansion.

---

## 4. Vocabulary guide

### Preferred vocabulary

Say **Context SDK for AI Agents**.

Say **pre-inference context-efficiency layer**.

Say **context-performance engineering**.

Say **working context** or **working set**.

Say **tool boundary** when describing where LeanCTX acts.

Say **context strategy** for the choices that shape the working set.

Say **Tuning Profile** for the versioned, deployable strategy.

Say **Dyno** for controlled benchmark and tuning environment.

Say **baseline versus treatment** for the comparison.

Say **quality contract** or **accepted quality threshold**.

Say **cost per accepted outcome (CPAO)** when outcome quality is in scope.

Say **measured saving** for an observed run.

Say **calculated provider cost** for usage multiplied by a versioned price table.

Say **reconciled invoice cost** only after actual billing is matched.

Say **Receipt** or **signed aggregate receipt** for verification evidence.

Say **tamper-evident ledger** for the hash-chained event record.

Say **offline-verifiable** when the verifier can check integrity and origin without a service call.

Say **privacy-preserving evidence** when raw prompts and code are not disclosed.

Say **complements** when discussing observability, gateways, evals, governance, and agent hosts.

Say **workload-specific result** whenever discussing performance data.

### Vocabulary to avoid

Never say **prompt optimization** as the category.

Never say **prompt compressor** as the product identity.

Never say **AI cost killer**.

Never say **universal token savings**.

Never say **guaranteed 80% savings** or any fixed outcome without a scoped contractual basis.

Never say **cost** when the number is only a calculated estimate; say calculated provider cost.

Never say **proof of ROI** when only token reduction was measured.

Never say **quality preserved** without naming the quality contract and evaluator.

Never say **independent audit** unless an independent audit actually occurred.

Never say **cryptographically proven business value**.

Never say **replaces Langfuse**, **replaces Helicone**, or **replaces your agent host**.

Never say **the only product** without current competitive evidence and the qualified combined meaning.

Never say **Headroom has raised $M** unless the financing amount is verified in current primary material.

### Phrase substitutions

Instead of “we optimize prompts,” say “we engineer the agent’s working context before inference.”

Instead of “we save tokens,” say “we measure a workload-specific cost/quality improvement against a baseline.”

Instead of “we reduce spend,” say “we reduce unnecessary upstream context and report the resulting provider usage and calculated cost.”

Instead of “trust our dashboard,” say “verify the signed Receipt and inspect the stated method.”

Instead of “we beat your model,” say “we improve the context supplied to the model you selected.”

Instead of “we replace your stack,” say “we make the stack you selected more efficient and accountable.”

---

## 5. Analogies that work

### The chiptuner

An AI agent is like an engine already installed in a vehicle.

The model is the engine; the agent host is the vehicle platform.

The context strategy is the engine calibration.

LeanCTX does not sell a different car or claim to replace the engine.

It tunes how the system runs under a real workload so it uses less fuel without losing the required performance.

Use this analogy to explain why a cheaper model is not the entire answer.

Do not extend it into claims of guaranteed horsepower or fuel economy.

### The Dyno

A dyno is a controlled environment that compares engine performance under stated conditions.

LeanCTX Dyno compares the same agent workload under stated context strategies.

It reports context usage, provider-reported usage, calculated cost, latency, quality, and task completion.

The same model, source revision, timeout, budget, and task controls remain fixed unless a variable is intentionally tested.

Use this analogy to explain why a dashboard alone is not sufficient evidence.

The Dyno is the controlled test; a production dashboard is only an observation surface.

### The ECU map

An ECU map is a versioned calibration that can be installed, compared, and reverted.

A LeanCTX Tuning Profile is the agent equivalent.

It records the chosen context budget, retrieval depth, compression strategy, recovery behavior, tool-output shaping, and permitted fallback choices.

The Profile makes a successful context strategy reproducible, deployable, comparable, and rollbackable.

Use this analogy to explain why the commercial asset is more than a one-time consulting report.

### The fuel receipt

Token numbers are not the business value by themselves.

The Receipt is closer to a signed service record: it attests to the stated measurement aggregate and origin without revealing the proprietary internals.

It validates integrity of the evidence artifact, not that every possible business interpretation is true.

Use this analogy to keep the proof claim honest.

### The pit crew

The developer and agent host keep driving the race.

LeanCTX is the specialist crew that measures the run, changes the context setup, checks that lap performance holds, and documents the adjustment.

Use this analogy with SIs to reinforce complementarity rather than replacement.

---

## 6. Objections and decisive answers

### “Isn’t this just prompt optimization?”

No.

Prompt optimization changes instructions supplied to a model.

LeanCTX engineers the full agent context supply chain: file reads, code search, shell output, provider data, RAG results, memory, and inter-agent handoffs.

It acts at tool boundaries before inference and treats the assembled working set as an operational system.

It also measures baseline versus treatment, applies a quality contract, and produces evidence of the result.

Prompt work may be one input to an agent strategy; it is not the LeanCTX category.

### “Why not just use a cheaper model?”

Use the cheapest model that meets the task’s quality requirement; that is a legitimate variable to test.

But a cheaper model still receives wasteful files, logs, searches, and handoffs.

Context waste compounds across every selected model and can impair quality as well as cost and latency.

LeanCTX improves the information supplied to the model you choose.

The Dyno can evaluate model choice when allowed, but it keeps the model fixed when the purpose is to isolate context-strategy impact.

The right question is not model versus LeanCTX; it is the best verified cost/quality point for the workload.

### “How is this different from Langfuse?”

Langfuse is strong at observing traces, costs, prompts, and evaluations after instrumentation and ingestion.

LeanCTX reduces the upstream context an agent consumes before the model sees it.

Langfuse tells you what the agent spent.

LeanCTX changes what the agent needs to spend, then records a tamper-evident, signed savings aggregate.

They are complementary.

Send LeanCTX evidence and runtime metrics to Langfuse if it is the customer’s trace destination.

Do not position LeanCTX as a Langfuse replacement.

### “Why would I trust your evidence?”

You should not trust a claim merely because we make it.

Start with a representative workload, an explicit quality contract, and fixed comparison controls.

The Dyno reports baseline and treatment, failures, retries, caching, methodology, and quality outcome rather than only the best result.

Per-event savings data is recorded in a SHA-256 hash chain.

An aggregate Receipt is signed with Ed25519 and can be verified offline.

The verifier checks integrity and origin of the evidence artifact without receiving raw prompts, code, paths, or raw event data.

That proves the stated artifact has not been silently altered; it does not eliminate the need to inspect methodology and quality gates.

### “We already have internal tooling.”

Good: LeanCTX is designed to improve the agent stack you already own.

Internal tooling may provide retrieval, memory, prompting, dashboards, caches, rules, or agent orchestration.

The gap is often a common, measurable, portable control plane for the full pre-inference context supply chain and an evidence method that engineering, finance, and procurement can all verify.

Start by connecting one workflow rather than replacing an internal platform.

If the Dyno does not show a quality-gated improvement, keep the internal solution and stop.

If it does, retain the integration and turn the winning strategy into a versioned Profile.

### “Do we have to send you our prompts and code?”

No as a default product claim.

LeanCTX is local-first and the signed aggregate is designed not to serialize raw prompts, code, file paths, raw events, or per-event timestamps.

The exact deployment and support boundary must still be agreed for the customer environment.

### “Can you promise a percentage saving?”

No universal percentage is credible.

Savings depend on the workload, agent, context sources, cache behavior, model, quality threshold, and comparison controls.

We promise a transparent method and a measured decision: deploy, iterate, or stop.

---

## 7. Positioning against Headroom Labs

### The respectful, specific position

Headroom is the closest direct competitor because it is an open-source, local-first context-compression product with proxy, CLI-wrapper, and MCP options.

It addresses real request-payload compression and cache-locality problems.

That validates the importance of context efficiency.

LeanCTX must not dismiss Headroom as “just compression” in a way that ignores its useful product capabilities.

### The decisive difference

> **Headroom compresses LLM traffic; LeanCTX engineers the full agent context supply chain and proves a quality-gated, workload-specific result.**

Headroom’s core wedge is inline request compression.

LeanCTX’s wedge is tool-aware, codebase-aware context operations across reads, search, shell, provider data, handoffs, and memory.

Headroom can expose product metrics and savings counters.

LeanCTX is differentiated by the combined method: shadow baselines, outcome economics, Tuning Profiles, controlled Dyno runs, hash-chained savings records, and offline-verifiable signed aggregate Receipts.

The target buyer is a team that must prove—not simply assert—that savings held while useful work remained acceptable.

### In a competitive conversation

Say: “Headroom is a credible compression option; evaluate it when request-payload reduction is the whole job.”

Say: “LeanCTX is the better fit when the customer needs to tune the entire agent context supply chain and produce a reproducible, quality-gated evidence package.”

Say: “Run both against the same workload if the customer is deciding; our position is strongest when the comparison is controlled.”

Say: “We complement existing model, agent-host, and observability choices rather than requiring a replacement.”

Do not say: “They do not measure anything.”

Do not say: “Their compression cannot work.”

Do not say: “We are the only context product.”

### Funding claim discipline

Do not repeat the claim that Headroom “raised M” without a verified amount and primary source.

The reviewed competitive research found no publicly disclosed financing round or institutional funding amount in Headroom’s primary materials.

The correct current wording is: **“Funding amount not publicly disclosed in the reviewed primary materials.”**

Absence of a disclosed round is not evidence that no funding exists.

Funding is not the product comparison anyway.

The relevant comparison is scope of optimization, quality controls, reproducibility, and verifiable evidence.

### The Headroom battlecard

| Buyer question | LeanCTX answer |
| --- | --- |
| Can it reduce payloads? | Yes, but the product scope is the entire agent context supply chain, not only inline request compression. |
| Can it work locally? | Yes; LeanCTX is local-first and connects through MCP, proxy, wrappers, and SDK access. |
| Can we compare strategies? | Yes; Dyno runs baseline and candidate context strategies under stated controls. |
| How do we preserve quality? | A saving counts only when the declared workload-specific quality contract holds. |
| Can we deploy the result? | Yes; the accepted strategy is captured as a versioned Tuning Profile. |
| Can security or finance verify it? | Yes; signed aggregate Receipts are offline-verifiable and privacy-preserving. |
| Must we rip out our current stack? | No; LeanCTX is a complementary context-efficiency layer. |

---

## 8. Evidence standard for every external claim

State the workload.

State the agent and model version.

State the source revision or fixture version.

State what was held constant.

State what was changed.

State the quality contract.

Report provider-reported usage separately from calculated cost.

Report caching, retries, failed arms, and material control differences.

State whether results are experimental, customer-specific, or reconciled to actual billing.

Make the methodology version inspectable.

Offer the signed Receipt for integrity and origin verification.

Never convert a workload-specific experiment into a universal promise.

---

## 9. The short version to memorize

LeanCTX is the Context SDK for AI agents.

It makes the context an existing agent receives smaller, better, and measurable before inference.

We put one real workflow on the Dyno, compare the same task under controlled context strategies, keep savings only when quality holds, and deploy the winning strategy as a Tuning Profile.

The result is a privacy-preserving, signed Receipt a customer can verify offline.

That is how Thinkery turns agent context from an opaque cost into an engineered, provable operating advantage.

---

## 10. Source basis and claim limits

This document follows the canonical loop: Connect → Measure → Tune → Prove → Deploy → Repeat.

It adopts the documented product architecture: SDK surface, LeanCTX Runtime, adapters, Dyno, Tuning Profiles, Receipts, and AutoTune as a later extension.

It treats a savings result as valid only when the declared quality contract holds.

It uses the documented evidence model: local per-event accounting, SHA-256 hash chain, and Ed25519-signed aggregate receipt verifiable offline.

It positions LeanCTX as complementary to observability, gateways, prompt/eval tools, governance, and agent hosts.

It treats vendor benchmarks as vendor claims and makes no universal performance promise.

It treats Headroom funding as undisclosed in reviewed primary materials, not as zero and not as a verified “raised M” claim.

