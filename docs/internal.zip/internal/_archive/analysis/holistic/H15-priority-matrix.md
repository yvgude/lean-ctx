# LeanCTX implementation-priority matrix

Status: implementation sequencing for the first 90 days.

Primary outcome: a developer can wrap one supported Python/OpenAI Agents SDK
agent, measure it against a matched baseline, verify a signed local receipt,
and deploy a versioned winning context configuration.

## Source basis and planning rules

- Read completely: `docs/internal/vision/SDK-STRATEGY-ALL-IN-ONE.md`.
- Read completely: `docs/internal/analysis/A9-gap-analysis.md`.
- Read completely: `docs/internal/analysis/A13-90-day-plan.md`.
- Timebox: Day 1 is 19 August 2026; Day 90 is 16 November 2026.
- Primary path: Python plus the OpenAI Agents SDK only.
- Product boundary: Context Runtime + SDK; do not build an agent framework.
- Integration mode: WRAP first; ATTACH paths remain protected compatibility paths.
- Evidence rule: no baseline, quality gate, provider usage, and verifier means no
  verified savings claim.
- Scope rule: no hosted control plane, accounts, dashboard, second paid adapter,
  marketplace, or generic scheduler during this window.
- Demand rule: consider another adapter only after two paid/prepaid requests
  sharing it total at least CHF 10,000 annualized value.
- Quality rule: failure, absence, or timeout of a required quality gate blocks a
  commercial performance claim.
- Privacy rule: receipt defaults to hashes, compact snapshots, and source IDs;
  raw prompts and tool output require explicit local opt-in.

## Decision summary

Build the vertical slice before the surrounding platform.

1. Freeze one public package and contract.
2. Make one OpenAI Agents SDK agent work through a scoped wrapper.
3. Make the wrapper agent-loop-safe and observable.
4. Emit a signed, local, queryable receipt with honest cost and quality fields.
5. Prove stock versus treatment on a fixed code-review workload.
6. Package the proof for a paid, bounded pilot.
7. Harden only from measured customer and compatibility evidence.
8. Add Profiles only after the reference workload proves which settings matter.

## Priority classes

| Class | Meaning | Scheduling rule |
|---|---|---|
| P0 | Required to establish a credible v1 proof loop. | Must precede release or paid measurement. |
| P1 | Required to make the proof repeatable, supportable, or saleable. | Build after P0 dependencies are green. |
| P2 | Valuable compounding capability. | Build only when the Day-70 evidence gate supports it. |
| Parked | Platform breadth without current proof pull. | Do not schedule in this matrix. |

## Strategy concept to module map

| Strategy concept | Product-loop stage | Primary codebase modules | First delivery | Priority |
|---|---|---|---|---|
| One SDK, one Runtime | Connect | `packages/python-lean-ctx`, `rust/crates/lean-ctx-sdk` | Week 1 contract | P0 |
| WRAP, not a global patch | Connect | `lean_ctx/agents.py`, `proxy.py`, `discovery.py` | Week 2 | P0 |
| ContextSession / run identity | Connect + Measure | Python wrapper, proxy correlation plumbing | Week 3 | P0 |
| Context Planning | Tune | `proxy/forward/mod.rs`, `pipeline.rs`, compression routes | Week 3 | P0 |
| Agent-loop-safe context handling | Tune | Responses proxy, tool output, history/pruning, prefix replay | Week 2–3 | P0 |
| Dyno workload and matched arms | Measure + Prove | `evidence_realworld.rs`, workflow/report code, example fixture | Week 4–Month 2 | P0 |
| ExecutionReceiptV1 | Measure + Prove | usage, cost, metrics, context kernel receipt builder | Week 3 | P0 |
| SavingsReceiptV1 / evidence bundle | Prove | evidence workflow, verifier, reports | Week 3–4 | P0 |
| Quality beside savings | Prove | Quality Lab types, Python callbacks, workload manifest | Week 3 | P0 |
| Coding-agent reliability | Connect | Cursor/Codex/Claude smoke jobs and connect paths | Week 2 and every release | P0 |
| ContextKitV1 on `.ctxpkg` | Tune + Deploy | `kits/code-review`, SDK kit loading, receipt provenance | Month 2 | P1 |
| TuningProfileV1 | Deploy + Repeat | protocol concepts, SDK load/compare, runtime translation | Month 3 gate | P1 |
| Reference code-review agent | Measure + Prove | `examples/python-openai-agents-code-review` | Month 2 | P1 |
| Pilot-in-a-Box | Prove + commercial | setup script, runbook, report templates, verifier UX | Week 4–Month 2 | P1 |
| AutoTune, hosted Dyno, Team | Repeat at scale | candidate search, cloud/enterprise services | Post-Day-90 | Parked |

## Canonical module ownership

| Concern | Owner module | Reuse before adding code | Explicit non-owner |
|---|---|---|---|
| Python public surface | `packages/python-lean-ctx` | current `proxy.py` and `discovery.py` | `clients/python`, `py-sdk`, `python-sdk` public duplicates |
| Agent transport | `rust/src/proxy/openai_responses.rs` | Responses forwarding and response headers | a Python reimplementation of the proxy |
| Context transforms | `rust/src/proxy/forward/` | routing, pipeline, conversation, compression, tool recovery | ad-hoc wrapper compression |
| Usage and cost | `rust/src/proxy/usage.rs`, `usage_meter.rs`, `cost.rs`, `metrics.rs` | normalized usage and prices | one-off Python dollar math |
| Receipt construction | `rust/src/core/context_kernel/receipt_builder.rs` | signing and receipt schema primitives | a second receipt format |
| Receipt correlation | new proxy receipt store/API | existing proxy bridge and envelope wiring | mutable global “last receipt” |
| Quality evidence | `rust/src/core/quality_lab/` plus manifest callbacks | quality-signal types and CLI | a synthetic aggregate score |
| Evidence bundle | existing evidence workflow/report/verifier | canonical bundle/signature/verifier | a dashboard-only calculation |
| Local kit substrate | `kits/` and `.ctxpkg` tooling | `kits/code-review` | a parallel package format |
| CLI inspection | `rust/src/cli/dispatch/` | gain, benchmark, token-report conventions | a separate reporting stack |

## Release gates applied to every phase

- Native agent output and errors remain observable without silent mutation.
- `observe` mode may continue without evidence; `required_evidence` fails closed.
- Costs label provenance as provider-reported, calculated, reconciled, or unavailable.
- `quality: unknown` is valid; a guessed quality score is not.
- Streaming receipt state is pending until completion, failure, or cancellation.
- Contract JSON, receipt JSON, and CLI golden output are deterministic.
- Cursor, Codex, and Claude Code smoke paths remain green before release.
- A clean external developer completes the quickstart in 15 minutes or less.

## Critical path

```mermaid
flowchart TD
  A[W1: freeze package, API, evidence and workload contracts]
  B[W2: typed Python wrapper and scoped Agents SDK transport]
  C[W2: compatibility and quickstart fixture]
  D[W3: run identity, context plan and agent-loop semantics]
  E[W3: provider usage, quality evidence and signed receipt]
  F[W4: receipt API, CLI, verifier, deterministic bundle]
  G[W4: rehearsals, rollback and SDK v1.0 RC]
  H[M2: stock vs treatment reference agent and Dyno proof]
  I[M2: paid pilot #1 using standard runbook]
  J[M3: independently validated customer evidence]
  K[M3: gated Profile v1 and repeatable deployment]
  A --> B
  B --> C
  B --> D
  D --> E
  E --> F
  C --> G
  F --> G
  G --> H
  H --> I
  I --> J
  J --> K
```

```text
Contract freeze
  -> Wrapper boundary
     -> Scoped proxy transport
        -> Context plan + agent-loop fixtures
           -> Correlated usage + quality + signed receipt
              -> Receipt lookup / CLI / offline verifier
                 -> Rehearsal / rollback / v1.0 release
                    -> Reference Dyno comparison
                       -> Paid pilot and independent validation
                          -> Profile v1 only if evidence validates settings
```

The critical path is A → B → D → E → F → G → H → I → J.

`ContextKitV1` can progress alongside H after provenance fields are stable.

`TuningProfileV1` must not block the first receipt or pilot; it is a deployment
object for a configuration that the reference workload has actually shown to win.

## Week 1 — freeze contracts and remove ambiguity

Week-1 objective: make it impossible for two teams to build incompatible wrappers,
receipt models, or commercial claims.

### W1.1 — Select the sole public Python package

- Strategy concept: one SDK, one Runtime; SDK before platform.
- Priority: P0.
- Create: `docs/contracts/python-sdk-v1-boundary.md`.
- Modify: `packages/python-lean-ctx/pyproject.toml`.
- Modify: `packages/python-lean-ctx/lean_ctx/__init__.py`.
- Modify: `clients/python/README.md`.
- Modify: `py-sdk/README.md`.
- Effort: 8 hours.
- Dependencies: package-owner decision; current Python API inventory.
- Build: declare `packages/python-lean-ctx` as the only public `lean_ctx` v1 home.
- Build: mark overlapping Python trees compatibility-only, internal, or deprecated.
- Success: one import path and one package version own `LeanCTX.wrap`.
- Success: no second public receipt or wrapper type remains plausible.

### W1.2 — Inventory reusable API, protocol, and evidence surfaces

- Strategy concept: technical convergence; one contract per concept.
- Priority: P0.
- Create: `docs/internal/analysis/sdk-v1-api-evidence-inventory.md`.
- Modify: `docs/internal/decisions/sdk-v1-decision-log.md`.
- Inspect and link: `rust/crates/lean-ctx-sdk`.
- Inspect and link: `packages/python-lean-ctx/lean_ctx/proxy.py`.
- Inspect and link: `packages/python-lean-ctx/lean_ctx/discovery.py`.
- Inspect and link: `rust/src/core/context_kernel/receipt_builder.rs`.
- Inspect and link: `rust/src/cli/dispatch/evidence_realworld.rs`.
- Effort: 6 hours.
- Dependencies: W1.1 package decision.
- Build: classify every candidate as reuse, adapt, do-not-expose, or retire.
- Success: every promised v1 method maps to a current capability or named task.
- Success: existing `ContextPlanV1` and `ContextReceiptV1` concepts are reused.

### W1.3 — Freeze the public SDK lifecycle contract

- Strategy concept: ContextSession; WRAP ergonomics; native output preservation.
- Priority: P0.
- Create: `docs/contracts/sdk-contract-v1.md`.
- Create: `docs/contracts/sdk-contract-v1.schema.json`.
- Modify: `docs/internal/decisions/sdk-v1-decision-log.md`.
- Modify: `packages/python-lean-ctx/README.md`.
- Effort: 8 hours.
- Dependencies: W1.1 and W1.2.
- Build: specify `LeanCTX.wrap(agent, config) -> wrapped agent` semantics.
- Build: specify `LeanCtxRun[T]` as output, receipt, evidence status, and run ID.
- Build: specify no mutable global last-receipt state and no global Runner patch.
- Success: contract covers configuration, lifecycle, errors, concurrency, and rollback.
- Success: callers know whether to invoke `Runner.run(wrapped_agent, input)`.

### W1.4 — Pin the OpenAI Agents SDK compatibility seam

- Strategy concept: one supported WRAP integration; proof before breadth.
- Priority: P0.
- Create: `docs/compatibility/openai-agents-sdk-v1.md`.
- Modify: `packages/python-lean-ctx/pyproject.toml`.
- Create: `packages/python-lean-ctx/tests/test_agents_sdk_compatibility.py`.
- Modify: `packages/python-lean-ctx/README.md`.
- Effort: 6 hours.
- Dependencies: W1.3 contract.
- Build: pin an optional supported `openai-agents` range and public lifecycle set.
- Build: record support for `Runner.run`, `Runner.run_sync`, and `Runner.run_streamed`.
- Build: explicitly document any v1 streaming exclusion instead of half-supporting it.
- Success: CI executes supported APIs against the pinned range.
- Success: unsupported versions produce a typed, actionable compatibility error.

### W1.5 — Define receipt, evidence-state, and cost-provenance invariants

- Strategy concept: no savings claim without a baseline; canonical evidence path.
- Priority: P0.
- Create: `docs/contracts/execution-receipt-v1.md`.
- Create: `docs/contracts/execution-receipt-v1.schema.json`.
- Create: `docs/contracts/evidence-state-v1.md`.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Modify: `rust/src/core/context_kernel/envelope_wiring.rs`.
- Effort: 10 hours.
- Dependencies: W1.2 and W1.3.
- Build: define `unavailable`, `partial`, `pending`, and `verified` evidence states.
- Build: require model, usage, pricing version, context/kit decisions, quality, signer.
- Build: label every cost field provider-reported, calculated, reconciled, or unavailable.
- Success: receipt cannot become verified without required evidence and valid signature.
- Success: a missing provider field is never serialized as a zero value.

### W1.6 — Define matched-workload and quality contract

- Strategy concept: Dyno; verified cost per successful agent task.
- Priority: P0.
- Create: `docs/contracts/pilot-workload-manifest-v1.md`.
- Create: `docs/contracts/pilot-workload-manifest-v1.schema.json`.
- Create: `docs/templates/quality-scorecard-v1.md`.
- Modify: `rust/src/cli/dispatch/evidence_realworld.rs`.
- Effort: 8 hours.
- Dependencies: W1.5.
- Build: bind repository revision, task, agent version, provider/model, prices, cache rule,
  test command, reviewer rubric, consent, and acceptance threshold to a workload manifest.
- Build: define VCP-SAT using provider-reported net LLM cost and declared quality gates.
- Success: unmatched baseline/treatment arms cannot enter a customer report.
- Success: a cheaper arm failing tests or human acceptance cannot claim a win.

### W1.7 — Run the contract review gate

- Strategy concept: proof before promise; one canonical measurement path.
- Priority: P0.
- Create: `docs/internal/reviews/sdk-v1-contract-review.md`.
- Modify: `docs/internal/decisions/sdk-v1-decision-log.md`.
- Modify: `docs/contracts/sdk-contract-v1.md`.
- Modify: `docs/contracts/execution-receipt-v1.md`.
- Effort: 4 hours.
- Dependencies: W1.3 through W1.6.
- Build: resolve wrapper semantics, stream timing, privacy defaults, and ownership.
- Build: record public migration notes and every approved v1 non-goal.
- Success: no P0 API or evidence ambiguity remains before implementation starts.
- Success: an exception requires a dated decision-log entry and compatibility impact.

Week-1 planned effort: 50 hours.

Week-1 exit: one package, one integration, one metric, one evidence vocabulary,
and one contract-backed backlog.

## Week 2 — make the wrapper real and safely narrow

Week-2 objective: a fixture agent executes through LeanCTX without breaking native
agent semantics, even if compression and evidence are disabled.

### W2.1 — Scaffold typed SDK and wrapper configuration

- Strategy concept: LeanCTX top-level client; ContextSession identity.
- Priority: P0.
- Create: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Create: `packages/python-lean-ctx/lean_ctx/types.py`.
- Create: `packages/python-lean-ctx/lean_ctx/errors.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/__init__.py`.
- Modify: `packages/python-lean-ctx/pyproject.toml`.
- Create: `packages/python-lean-ctx/tests/test_agents_wrapper.py`.
- Effort: 10 hours.
- Dependencies: W1.3, W1.4, and W1.7.
- Build: add `LeanCTX`, `WrapConfig`, `LeanCtxRun`, `EvidenceStatus`, and typed errors.
- Build: validate configuration before agent execution and preserve existing `compress()` API.
- Success: `from lean_ctx import LeanCTX` imports without optional runtime surprises.
- Success: invalid project, proxy, or evidence configuration fails deterministically.

### W2.2 — Implement agent-compatible wrapping without global mutation

- Strategy concept: WRAP integration; do not replace the customer agent.
- Priority: P0.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/types.py`.
- Create: `packages/python-lean-ctx/tests/test_agents_clone_semantics.py`.
- Create: `packages/python-lean-ctx/tests/fixtures/openai_agents/basic_agent.py`.
- Effort: 14 hours.
- Dependencies: W2.1.
- Build: clone or adapt the supplied Agent while retaining instructions, tools, handoffs,
  guardrails, model settings, output type, and caller-visible identity semantics.
- Build: keep wrapping scoped to the returned agent, never to global `Runner` state.
- Success: stock and wrapped fixture return equivalent functional output in no-op mode.
- Success: original unwrapped agent retains untouched stock behavior.

### W2.3 — Route only wrapped calls through authenticated proxy discovery

- Strategy concept: Runtime owns engine; SDK supplies ergonomic connection.
- Priority: P0.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/proxy.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/discovery.py`.
- Modify: `rust/src/proxy/openai_responses.rs`.
- Modify: `rust/src/proxy/forward/mod.rs`.
- Create: `packages/python-lean-ctx/tests/test_agents_transport.py`.
- Effort: 18 hours.
- Dependencies: W2.2; local daemon/proxy authentication decision.
- Build: configure only the wrapped model/provider/client against discovered proxy/auth data.
- Build: carry an initial wrapper correlation ID without changing unrelated application calls.
- Success: request uses the Responses proxy and preserves response/body/error semantics.
- Success: proxy unavailable produces documented observe/required-evidence behavior.

### W2.4 — Prove supported lifecycle and failure seams

- Strategy concept: developer trust; under-15-minute supported experience.
- Priority: P0.
- Create: `packages/python-lean-ctx/tests/test_agents_run_modes.py`.
- Create: `packages/python-lean-ctx/tests/test_agents_failures.py`.
- Create: `packages/python-lean-ctx/tests/test_agents_streaming.py`.
- Modify: `docs/compatibility/openai-agents-sdk-v1.md`.
- Effort: 12 hours.
- Dependencies: W2.3.
- Build: test async, sync, stream decision, cancellation, exception, re-entrancy,
  proxy outage, no-op, and rollback paths.
- Build: use golden Agent SDK fixtures for tool calls and output types.
- Success: every failure retains the original native error or a documented LeanCTX error.
- Success: unsupported lifecycle behavior is rejected explicitly before a customer can rely on it.

### W2.5 — Add agent-loop-aware context transform fixtures

- Strategy concept: Context Planning before materialization, not JSON compression alone.
- Priority: P0.
- Modify: `rust/src/proxy/forward/pipeline.rs`.
- Modify: `rust/src/proxy/conversation.rs`.
- Modify: `rust/src/proxy/tool_output.rs`.
- Modify: `rust/src/proxy/history_prune.rs`.
- Modify: `rust/src/proxy/prefix_replay.rs`.
- Create: `rust/src/proxy/tests/openai_agents_loop.rs`.
- Effort: 16 hours.
- Dependencies: W2.3 and Agent SDK fixtures.
- Build: cover multi-turn input, tool output, handoffs, retries, `previous_response_id`,
  prompt cache preservation, recovery references, streaming, cancellation, and failure.
- Success: the agent loop remains functionally equivalent at the declared quality gate.
- Success: transformed context has a recoverable provenance reference, not silent loss.

### W2.6 — Publish and test the first quickstart fixture

- Strategy concept: Connect; reference custom/coding agent proof.
- Priority: P1.
- Create: `examples/python-openai-agents-code-review/README.md`.
- Create: `examples/python-openai-agents-code-review/main.py`.
- Create: `examples/python-openai-agents-code-review/requirements.txt`.
- Create: `examples/python-openai-agents-code-review/fixture/`.
- Create: `examples/python-openai-agents-code-review/workload.manifest.json`.
- Modify: `packages/python-lean-ctx/README.md`.
- Effort: 10 hours.
- Dependencies: W2.4 and W2.5.
- Build: give a fixed source/task/test/rubric fixture and exact clean-environment commands.
- Build: expose an explicit disable/rollback path and all required local prerequisites.
- Success: an uninvolved developer runs stock and wrapped paths in 15 minutes or less.
- Success: every manual intervention becomes documentation, test coverage, or a blocker.

### W2.7 — Protect existing coding-agent distribution paths

- Strategy concept: ATTACH reliability for Codex, Cursor, and Claude Code.
- Priority: P0.
- Create: `.github/workflows/sdk-protected-path-smoke.yml`.
- Create: `scripts/smoke-coding-agent-integrations.sh`.
- Modify: `docs/compatibility/openai-agents-sdk-v1.md`.
- Modify: `packages/python-lean-ctx/pyproject.toml`.
- Effort: 8 hours.
- Dependencies: W2.1.
- Build: run isolated smoke commands for Codex, Cursor, and Claude Code in release CI.
- Build: prevent Python packaging changes from accidentally altering MCP/proxy installations.
- Success: any critical protected-path regression blocks an SDK release within one business day.
- Success: generated smoke evidence identifies exact command, version, and failure mode.

Week-2 planned effort: 88 hours.

Week-2 exit: the smallest supported wrapped run works, fails predictably, and has a
clean quickstart plus compatibility evidence.

## Week 3 — correlate one execution into trustworthy evidence

Week-3 objective: turn the working wrapper into an observable local execution with
honest usage, context decisions, quality signals, and a signed receipt.

### W3.1 — Create per-run lifecycle and correlation model

- Strategy concept: ContextSession; ExecutionReceipt identity.
- Priority: P0.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/types.py`.
- Create: `packages/python-lean-ctx/lean_ctx/run_lifecycle.py`.
- Create: `packages/python-lean-ctx/tests/test_run_lifecycle.py`.
- Modify: `rust/src/proxy/openai_responses.rs`.
- Modify: `rust/src/proxy/forward/mod.rs`.
- Effort: 12 hours.
- Dependencies: W2.2 and W1.5.
- Build: create a run context before context modification and propagate stable `run_id`.
- Build: record SDK/runtime/adapter versions, configuration fingerprint, and manifest hash.
- Success: every wrapped run can be joined to proxy records without timing races.
- Success: concurrent runs cannot attach another run’s receipt.

### W3.2 — Carry versioned context policy and context-plan results

- Strategy concept: Context Planning; sufficient context at best verified frontier.
- Priority: P0.
- Create: `docs/contracts/context-policy-v1.md`.
- Create: `docs/contracts/context-plan-v1.schema.json`.
- Create: `packages/python-lean-ctx/lean_ctx/policy.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `rust/src/proxy/forward/mod.rs`.
- Modify: `rust/src/proxy/forward/pipeline.rs`.
- Modify: `rust/src/proxy/compress_api.rs`.
- Effort: 16 hours.
- Dependencies: W3.1; privacy/redaction decision in W1.5.
- Build: expose defaults, budgets, opt-out, exclusions, redaction, and policy version.
- Build: return selection rationale, source references, exclusions, and compression deltas.
- Success: the receipt explains actual context treatment rather than merely a token delta.
- Success: Python API can prove whether a plan selected, compressed, reused, or recovered context.

### W3.3 — Capture provider usage and versioned calculated cost

- Strategy concept: Measure; VCP-SAT; cost provenance.
- Priority: P0.
- Modify: `rust/src/proxy/usage.rs`.
- Modify: `rust/src/proxy/usage_meter.rs`.
- Modify: `rust/src/proxy/cost.rs`.
- Modify: `rust/src/proxy/metrics.rs`.
- Modify: `packages/python-lean-ctx/lean_ctx/run_lifecycle.py`.
- Create: `rust/src/proxy/tests/usage_receipt.rs`.
- Effort: 14 hours.
- Dependencies: W3.1; selected provider response shape.
- Build: record prompt, cached-input, and completion usage, distinguishing absent from zero.
- Build: attach immutable pricing version and calculate fixture costs with cache-aware math.
- Success: receipt arithmetic exactly reproduces usage/cost fixture expectations.
- Success: missing usage yields `partial`, never invented cost or verified VCP-SAT.

### W3.4 — Capture safe context and Kit provenance

- Strategy concept: ContextKit; evidence without raw secret retention.
- Priority: P0.
- Modify: `rust/src/proxy/forward/pipeline.rs`.
- Modify: `rust/src/core/context_kernel/proxy_bridge.rs`.
- Modify: `packages/python-lean-ctx/lean_ctx/policy.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/run_lifecycle.py`.
- Create: `rust/src/proxy/tests/context_provenance.rs`.
- Effort: 10 hours.
- Dependencies: W3.2 and W3.3.
- Build: store source IDs/digests, selected/dropped descriptions, delta, and kit hash/version.
- Build: default to no raw source, prompt, or tool-output persistence.
- Success: receipt proves which mechanism and kit ran without exposing raw customer content.
- Success: explicit local retention is consented, bounded, and covered by redaction tests.

### W3.5 — Implement quality signals, not a magic quality score

- Strategy concept: quality beside savings; verified cost per successful task.
- Priority: P0.
- Modify: `rust/src/core/quality_lab/`.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Create: `packages/python-lean-ctx/lean_ctx/quality.py`.
- Create: `packages/python-lean-ctx/tests/test_quality_evidence.py`.
- Create: `rust/src/core/quality_lab/tests/runtime_quality_signals.rs`.
- Effort: 16 hours.
- Dependencies: W1.6 and W3.1.
- Build: record invariants, guardrails, structured-output validation, tool/error outcomes,
  declared test result, human approval, and optional evaluator provenance.
- Build: serialize unknown quality explicitly when no trustworthy evaluator applies.
- Success: failed test, failed review, or missing required gate prevents commercial success.
- Success: compression ratio cannot be rendered as a quality result.

### W3.6 — Build correlated receipt accumulator and authenticated lookup API

- Strategy concept: ExecutionReceiptV1; canonical evidence pipeline.
- Priority: P0.
- Create: `rust/src/proxy/receipt_store.rs`.
- Create: `rust/src/proxy/receipts.rs`.
- Modify: `rust/src/proxy/mod.rs`.
- Modify: `rust/src/proxy/openai_responses.rs`.
- Modify: `rust/src/core/context_kernel/proxy_bridge.rs`.
- Modify: `rust/src/core/context_kernel/envelope_wiring.rs`.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Create: `rust/src/proxy/tests/receipt_api.rs`.
- Effort: 20 hours.
- Dependencies: W3.1 through W3.5; retention/storage decision.
- Build: accumulate by run ID, finalize only at response/stream terminal state, sign receipt.
- Build: expose authenticated `GET /v1/receipts/{run_id}` with safe summary defaults.
- Success: receipt retrieval returns only the corresponding run and valid evidence state.
- Success: malformed receipt data fails closed; no cross-run or unbounded-storage leak occurs.

### W3.7 — Assemble, verify, and fail safely

- Strategy concept: EvidenceBundleV1; proof before promise.
- Priority: P0.
- Modify: `rust/src/core/context_kernel/envelope_wiring.rs`.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Modify: `rust/src/cli/dispatch/evidence_realworld.rs`.
- Create: `packages/python-lean-ctx/tests/test_evidence_failures.py`.
- Create: `rust/src/core/context_kernel/tests/wrapper_bundle_verification.rs`.
- Effort: 14 hours.
- Dependencies: W3.6 and existing bundle/verifier primitives.
- Build: emit wrapper receipt/bundle and exercise tamper, missing-file, signer, timeout,
  provider-usage, daemon-down, unsupported-stream, and disk-failure cases.
- Build: formalize `observe` versus `required_evidence` behavior.
- Success: clean wrapper bundle verifies offline; any byte/manifest tamper fails deterministically.
- Success: observe does not break a successful native run; required evidence blocks false claims.

Week-3 planned effort: 102 hours.

Week-3 exit: a run has a unique identity, defensible plan/usage/quality provenance,
and a signed local receipt that can be fetched safely.

## Week 4 — make proof inspectable, reproducible, and releasable

Week-4 objective: complete the first vertical proof loop and make it safe to put in
front of a prospect without improvising product behavior.

### W4.1 — Add receipt inspection and comparison CLI

- Strategy concept: Prove; developer understands before/after.
- Priority: P0.
- Create: `rust/src/cli/dispatch/receipt_cmd.rs`.
- Modify: `rust/src/cli/dispatch/mod.rs`.
- Modify: `rust/src/cli/dispatch/help.rs`.
- Modify: `rust/src/cli/dispatch/evidence_realworld.rs`.
- Create: `rust/src/cli/dispatch/tests/receipt_cmd.rs`.
- Effort: 10 hours.
- Dependencies: W3.6.
- Build: add `lean-ctx receipt show <run-id>` and comparison output with JSON mode.
- Build: render selected/dropped context, token/dollar deltas, quality, IDs, limitations.
- Success: default output never reveals raw payload; explicit local opt-in is required.
- Success: JSON and human output use the same canonical receipt arithmetic.

### W4.2 — Make receipts and reports deterministic

- Strategy concept: independent verification; one canonical evidence truth.
- Priority: P0.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Modify: `rust/src/cli/dispatch/evidence_realworld.rs`.
- Modify: `rust/src/cli/dispatch/receipt_cmd.rs`.
- Create: `rust/src/core/context_kernel/tests/receipt_determinism.rs`.
- Create: `rust/src/cli/dispatch/tests/receipt_golden.rs`.
- Effort: 10 hours.
- Dependencies: W3.7 and W4.1.
- Build: canonicalize manifest sorting, inject a test clock, pin pricing fixtures, and add goldens.
- Build: remove synthetic fallback from commercial-evidence execution paths.
- Success: fixed fixture emits identical signed inputs except permitted identity/time metadata.
- Success: unavailable real data is visible as an error/partial state, never a simulation.

### W4.3 — Converge Dyno evidence output on the wrapper path

- Strategy concept: Dyno; stock versus treatment controlled benchmark.
- Priority: P0.
- Modify: `rust/src/cli/dispatch/evidence_realworld.rs`.
- Modify: `rust/src/cli/dispatch/evidence_workflow.rs`.
- Modify: `rust/src/cli/dispatch/evidence_report.rs`.
- Modify: `examples/python-openai-agents-code-review/main.py`.
- Create: `examples/python-openai-agents-code-review/run_comparison.py`.
- Effort: 14 hours.
- Dependencies: W4.1 and W4.2.
- Build: have stock/treatment runs produce the canonical workload, receipt, bundle, verifier,
  and Markdown/HTML report instead of a parallel marketing benchmark format.
- Success: one command yields a reproducible wrapper → receipt → verify → report demo.
- Success: report shows cache treatment, VCP-SAT inputs, quality outcomes, and limitations.

### W4.4 — Build pilot setup, privacy preflight, and rollback path

- Strategy concept: local-first trust; Pilot-in-a-Box.
- Priority: P1.
- Modify: `scripts/pilot-setup.sh`.
- Create: `scripts/pilot-preflight.sh`.
- Create: `docs/pilot/data-handling.md`.
- Create: `docs/pilot/operator-runbook.md`.
- Create: `docs/pilot/rollback.md`.
- Effort: 12 hours.
- Dependencies: W3.7 and W4.2.
- Build: check prerequisites, output location, verifier install, redaction, uninstall, and rollback.
- Build: block known secret patterns by default and print the data boundary before execution.
- Success: uninstall removes only pilot configuration and the host remains usable.
- Success: operator can explain stored data, consent, recovery, and evidence limitations.

### W4.5 — Rehearse the delivery flow twice and repair only evidence blockers

- Strategy concept: proof before promise; standard delivery before revenue scale.
- Priority: P0.
- Create: `docs/pilot/rehearsals/rehearsal-1.md`.
- Create: `docs/pilot/rehearsals/rehearsal-2.md`.
- Modify: `docs/pilot/operator-runbook.md`.
- Modify: `scripts/pilot-preflight.sh`.
- Modify: `examples/python-openai-agents-code-review/workload.manifest.json`.
- Effort: 16 hours.
- Dependencies: W4.3 and W4.4.
- Build: run intake, manifest approval, baseline, treatment, test/review, sign, verify, report.
- Build: exercise proxy, signing, quality, and uninstall failure drills on two representative tasks.
- Success: both bundles verify offline; all manual work becomes code or runbook.
- Success: no open defect can falsify consent, cost, quality, or signature evidence.

### W4.6 — Cut SDK v1.0 release candidate and proof package

- Strategy concept: SDK productization; revenue in parallel.
- Priority: P0.
- Modify: `packages/python-lean-ctx/pyproject.toml`.
- Modify: `packages/python-lean-ctx/CHANGELOG.md`.
- Modify: `packages/python-lean-ctx/README.md`.
- Create: `docs/releases/sdk-v1.0.0-rc.md`.
- Create: `docs/pilot/methodology.md`.
- Create: `docs/pilot/executive-report-template.md`.
- Effort: 14 hours.
- Dependencies: W4.5 and protected-path smoke gate.
- Build: pin dependencies, publish API reference, release notes, limitations, and rollback guidance.
- Build: package an evidence-backed 20-minute demo and standard offer materials.
- Success: RC passes package, Rust/protocol/evidence, verifier, and protected-path gates.
- Success: every external claim links to method, measurement boundary, and limitation.

Week-4 planned effort: 76 hours.

Week-4 exit: `lean-ctx-sdk` RC can demonstrate a verified local vertical slice;
rehearsal and rollback make the first paid measurement operationally safe.

## Month 2 — prove reference value and deliver a standard pilot

Month-2 objective: use the released vertical slice on real, bounded workloads;
build only what turns a customer observation into reproducible evidence.

### M2.1 — Make the reference code-review agent a true stock/treatment comparison

- Strategy concept: reference custom agent; Integration Depth Benchmark; Dyno.
- Priority: P1.
- Modify: `examples/python-openai-agents-code-review/main.py`.
- Modify: `examples/python-openai-agents-code-review/run_comparison.py`.
- Create: `examples/python-openai-agents-code-review/stock.py`.
- Create: `examples/python-openai-agents-code-review/treatment.py`.
- Create: `examples/python-openai-agents-code-review/quality.py`.
- Create: `examples/python-openai-agents-code-review/demo.sh`.
- Effort: 20 hours.
- Dependencies: W4 RC, `kits/code-review`, and fixed workload manifest.
- Build: execute identical repository/task/model/budget/test/rubric in stock and wrapped arms.
- Build: show both a five-minute demo and machine-verifiable outputs.
- Success: treatment quality meets or exceeds baseline and no unsupported framework behavior is implied.
- Success: comparison can be reproduced by another operator from a clean checkout.

### M2.2 — Add three representative fixture workloads and variance reporting

- Strategy concept: Dyno; claims governance.
- Priority: P1.
- Create: `examples/python-openai-agents-code-review/fixtures/small/`.
- Create: `examples/python-openai-agents-code-review/fixtures/medium/`.
- Create: `examples/python-openai-agents-code-review/fixtures/large/`.
- Create: `examples/python-openai-agents-code-review/manifests/`.
- Modify: `examples/python-openai-agents-code-review/run_comparison.py`.
- Modify: `rust/src/cli/dispatch/evidence_report.rs`.
- Effort: 18 hours.
- Dependencies: M2.1 and W1.6 workload contract.
- Build: record variance, cache behavior, failed arms, retries, and limitations for three fixtures.
- Build: report workload-specific results rather than average/smoothed or universal savings.
- Success: report identifies each revision, pricing version, quality gate, and cache treatment.
- Success: a failed arm stays in output and cannot be silently excluded from interpretation.

### M2.3 — Turn `kits/code-review` into a provenance-bearing runtime input

- Strategy concept: ContextKitV1; tune with reusable context capability.
- Priority: P1.
- Create: `docs/contracts/context-kit-v1.md`.
- Create: `docs/contracts/context-kit-v1.schema.json`.
- Modify: `kits/code-review/`.
- Create: `packages/python-lean-ctx/lean_ctx/kits.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Effort: 18 hours.
- Dependencies: W3.4 provenance fields; M2.1 reference agent.
- Build: use existing `.ctxpkg` substrate, load only compatible kit versions, and record hash.
- Build: define activation, compatibility, permissions, evaluation, and provenance metadata.
- Success: a receipt identifies exact `kits/code-review` version/hash used for the run.
- Success: no parallel kit package system or hidden kit activation is introduced.

### M2.4 — Improve verifier and report UX for a buyer demonstration

- Strategy concept: Prove; evidence as product and moat.
- Priority: P1.
- Modify: `rust/src/cli/dispatch/receipt_cmd.rs`.
- Modify: `rust/src/cli/dispatch/evidence_report.rs`.
- Modify: `docs/pilot/methodology.md`.
- Create: `docs/pilot/verifier-guide.md`.
- Create: `docs/pilot/objection-handling.md`.
- Effort: 12 hours.
- Dependencies: M2.2 and W4.6.
- Build: make stock → wrapped → receipt → verifier understandable in 20 minutes or less.
- Build: present methodology, quality gates, cache, unavailable fields, and limitations first.
- Success: prospect can reproduce verification without founder access.
- Success: no report implies calculated cost equals provider invoice cost.

### M2.5 — Harden only from pilot-discovered defects

- Strategy concept: pull before expansion; local SDK reliability.
- Priority: P1.
- Modify: `packages/python-lean-ctx/lean_ctx/errors.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `rust/src/proxy/receipt_store.rs`.
- Modify: `docs/pilot/operator-runbook.md`.
- Create: `packages/python-lean-ctx/tests/regression/`.
- Create: `rust/src/proxy/tests/regression/`.
- Effort: 20 hours.
- Dependencies: paid-pilot execution feedback and a reproducible defect.
- Build: add documented error codes, migration guidance, redacted regression fixtures, and tests.
- Build: reject unrelated UI, control-plane, or adapter feature requests.
- Success: each patch links to a customer runbook failure or support event.
- Success: post-onboarding founder support trends below four hours per active customer/week.

### M2.6 — Standardize the paid pilot evidence archive

- Strategy concept: commercial proof; portable EvidenceBundleV1.
- Priority: P1.
- Create: `docs/pilot/archive-layout.md`.
- Create: `scripts/archive-pilot-evidence.sh`.
- Modify: `scripts/pilot-preflight.sh`.
- Modify: `docs/pilot/operator-runbook.md`.
- Modify: `docs/pilot/executive-report-template.md`.
- Effort: 10 hours.
- Dependencies: W4.5 and a first customer manifest.
- Build: archive signed baseline/treatment bundles, manifest, verifier, report, and decisions.
- Build: keep sensitive data local and retain only consented redacted artifacts by default.
- Success: a second operator validates the archive from a clean machine.
- Success: archive reveals all assumptions required to calculate VCP-SAT.

### M2.7 — Run Day-70 decision gate before any integration expansion

- Strategy concept: focus rules; pull before expansion.
- Priority: P0.
- Create: `docs/internal/decisions/day-70-evidence-revenue-gate.md`.
- Modify: `docs/compatibility/openai-agents-sdk-v1.md`.
- Modify: `docs/internal/decisions/sdk-v1-decision-log.md`.
- Effort: 6 hours.
- Dependencies: M2.1–M2.6 and real customer/support evidence.
- Build: audit receipts, manifests, sales stages, cash, support hours, quickstart, and OSS smoke.
- Build: approve another adapter only when the stated two-request/CHF 10,000 gate is met.
- Success: every roadmap change has a payment, proof, or compatibility evidence link.
- Success: otherwise Python/OpenAI remains the sole paid integration.

Month-2 planned effort: 104 hours plus customer delivery time.

Month-2 exit: the reference agent proves a bounded stock/treatment result, customer #1
has a standard verified flow, and changes are driven by observed defects rather than breadth.

## Month 3 — validate, deploy learned configuration, and decide the next narrow loop

Month-3 objective: independently validate evidence, productize only the configuration
shown to matter, and decide whether the wedge earns another focused quarter.

### M3.1 — Independently validate a representative customer workload

- Strategy concept: Proof; verified cost per successful agent task.
- Priority: P0.
- Create: `docs/pilot/measurement-validation-template.md`.
- Create: `docs/pilot/customer-1-validation-memo.md`.
- Modify: `scripts/archive-pilot-evidence.sh`.
- Modify: `rust/src/cli/dispatch/evidence_report.rs`.
- Effort: 14 hours.
- Dependencies: valid Month-2 baseline/treatment bundles and customer reviewer availability.
- Build: re-run or customer-re-run one manifest with an independent operator.
- Build: reconcile provider usage, cached tokens, pricing arithmetic, quality, and variance.
- Success: the operator verifies bundle without founder access.
- Success: commercial threshold is recorded as met or honestly failed with no spin.

### M3.2 — Gate and define `TuningProfileV1` from demonstrated controls

- Strategy concept: Deploy; performance users can version.
- Priority: P1, conditional on M3.1 evidence.
- Create: `docs/contracts/tuning-profile-v1.md`.
- Create: `docs/contracts/tuning-profile-v1.schema.json`.
- Create: `packages/python-lean-ctx/lean_ctx/profiles.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Modify: `rust/src/proxy/forward/pipeline.rs`.
- Modify: `rust/src/core/context_kernel/receipt_builder.rs`.
- Effort: 20 hours.
- Dependencies: M3.1; stable policy fields from W3.2; a measured winning configuration.
- Build: define budget, read strategy, search limit, reuse threshold, compression, recovery,
  kit references, quality gates, semantic version, and compatibility range.
- Build: carry exact profile ID/version into every receipt.
- Success: Profile schema encodes only controls the reference agent can apply and verify.
- Success: no speculative provider/model orchestration or cloud registry is required.

### M3.3 — Implement local Profile lifecycle: validate, pin, compare, rollback

- Strategy concept: Deploy + Repeat; reproducible manual tuning stays open.
- Priority: P1, conditional on M3.2.
- Modify: `packages/python-lean-ctx/lean_ctx/profiles.py`.
- Modify: `packages/python-lean-ctx/lean_ctx/agents.py`.
- Create: `packages/python-lean-ctx/tests/test_profiles.py`.
- Create: `rust/src/cli/dispatch/profile_cmd.rs`.
- Modify: `rust/src/cli/dispatch/mod.rs`.
- Modify: `rust/src/cli/dispatch/receipt_cmd.rs`.
- Effort: 18 hours.
- Dependencies: M3.2 and receipt provenance.
- Build: create, validate, load, export, pin, compare, and rollback a local profile.
- Build: make comparison use existing receipt/Dyno facts, not a second calculation path.
- Success: winning configuration deploys deterministically and receipt contains exact version.
- Success: rollback returns the previous compatible profile with a documented command.

### M3.4 — Add cross-contract conformance fixtures

- Strategy concept: stable shared contracts; SDK portability.
- Priority: P1.
- Create: `tests/conformance/sdk-runtime-receipt/`.
- Create: `tests/conformance/profile/`.
- Create: `tests/conformance/kit/`.
- Modify: `packages/python-lean-ctx/tests/test_agents_sdk_compatibility.py`.
- Modify: `rust/src/core/context_kernel/tests/`.
- Effort: 16 hours.
- Dependencies: M3.2, M3.3, and M2.3.
- Build: cover runtime handshake, error mapping, receipt retrieval, profile load, kit load,
  recovery, contract serialization, and unsupported version behavior.
- Success: local SDK → Runtime → run → receipt → verify passes as one integration test.
- Success: profile/kit versions in receipts match the loaded artifact byte-for-byte.

### M3.5 — Preserve OSS distribution reliability during commercial hardening

- Strategy concept: coding agents remain first class; open interoperability.
- Priority: P0.
- Modify: `.github/workflows/sdk-protected-path-smoke.yml`.
- Modify: `scripts/smoke-coding-agent-integrations.sh`.
- Create: `docs/releases/oss-compatibility-status.md`.
- Modify: `docs/internal/decisions/sdk-v1-decision-log.md`.
- Effort: 10 hours.
- Dependencies: every Month-3 release candidate.
- Build: publish versioned smoke outcomes, known limits, triage owner, and rollback action.
- Build: pause commercial expansion after one business day of unresolved critical regression.
- Success: no critical Cursor/Codex/Claude Code regression remains open at Day 90.
- Success: commercial wrapper work does not silently change public OSS behavior.

### M3.6 — Package validated evidence into a bounded case-study path

- Strategy concept: revenue in parallel; claims governance.
- Priority: P1.
- Create: `docs/pilot/case-study-template.md`.
- Create: `docs/pilot/reproducibility-appendix-template.md`.
- Modify: `docs/pilot/executive-report-template.md`.
- Modify: `docs/pilot/methodology.md`.
- Effort: 8 hours.
- Dependencies: M3.1 and written customer approval or anonymization decision.
- Build: present workflow, controls, cache, quality, VCP-SAT range, limitations, and verifier.
- Build: prohibit publication of a name, number, or claim without written approval.
- Success: evidence is exact, independently reproducible, and scoped to measured workload.
- Success: an honest failure produces a decision memo, not a success narrative.

### M3.7 — Close the 90-day learning loop and choose one next action

- Strategy concept: Repeat; smallest product proving next commercial truth.
- Priority: P0.
- Create: `docs/internal/decisions/day-90-sdk-thesis-scorecard.md`.
- Create: `docs/internal/decisions/next-quarter-go-no-go.md`.
- Modify: `docs/internal/decisions/sdk-v1-decision-log.md`.
- Modify: `docs/releases/oss-compatibility-status.md`.
- Effort: 8 hours.
- Dependencies: M3.1–M3.6, cash/support ledger, and customer decisions.
- Build: score payment, independent bundle, >=40% VCP-SAT/no regression, quickstart,
  protected paths, and support burden against the Day-90 rule.
- Build: choose continue, narrow paid proof cycle, or maintain OSS without platform expansion.
- Success: decision has a measured rationale and only the next two weeks are planned.
- Success: AutoTune, hosted Dyno, Team, cloud registry, and second adapter stay parked
  unless their specific prerequisite and customer-pull gates are documented as passed.

Month-3 planned effort: 94 hours plus customer validation time.

Month-3 exit: measured customer evidence determines whether local Profiles become a
stable deployment primitive and whether the verified-savings wedge earns continuation.

## Effort roll-up and dependency gates

| Window | Planned engineering hours | Non-negotiable gate | Output |
|---|---:|---|---|
| Week 1 | 50 | Contract review passes | One public surface and evidence vocabulary |
| Week 2 | 88 | Native semantics plus smoke matrix | Scoped working wrapper and quickstart |
| Week 3 | 102 | Receipt verifies and failure modes are safe | Correlated plan/usage/quality receipt |
| Week 4 | 76 | Two rehearsal bundles verify | SDK RC and Pilot-in-a-Box |
| Month 2 | 104 | Customer/fixture evidence, not feature demand | Reference proof and standard pilot |
| Month 3 | 94 | Independent validation and Day-70/90 decisions | Profile lifecycle only if justified |
| Total | 514 | Customer access and review time excluded | Evidence-led SDK wedge |

The 514-hour roll-up is intentionally larger than A9’s 150-hour core gap estimate.

The 150 hours covers the ten core implementation gaps.

The remaining planned work is contract freezing, fixture design, release qualification,
protected-path compatibility, reproducibility, operator safety, customer proof, and
conditional Profile productization.

## Explicitly not in the first 90 days

- No generic agent builder or orchestration framework.
- No second public Python wrapper package.
- No global monkey patch of the OpenAI Agents SDK Runner.
- No second paid framework adapter before the demand gate.
- No hosted dashboard, user accounts, organization control plane, or cloud secrets.
- No private Profile/Kit registry, billing, Stripe, SSO, RBAC, or fleet policy.
- No managed relay or managed execution.
- No AutoTune candidate queue, autonomous deployment, or production rollout.
- No marketplace.
- No unqualified savings, universal benchmark, or cost claim.

## Final build order

1. Contract and package boundary.
2. Scoped Python/OpenAI wrapper.
3. Agent-loop fixtures and protected-path compatibility.
4. Run identity, context policy/plan, usage, quality, and signed receipt.
5. Receipt API, CLI, verifier, determinism, and rehearsed operator path.
6. Stock/treatment reference agent and controlled Dyno evidence.
7. Standard paid pilot and independent measurement validation.
8. Local TuningProfile lifecycle only for evidence-proven controls.
9. Decide the next narrow commercial proof loop.

This order implements the strategy’s core loop:

`CONNECT → MEASURE → TUNE → PROVE → DEPLOY → REPEAT`.
