# H19 — Thinkery Commercial and Organizational Layer

**Status:** product plan; Thinkery is not an existing product.

**Scope:** commercialization and operation of the organization-scale layer around
LeanCTX.

**Audience:** product, engineering, security, customer success, and prospective
design partners.

**Decision in one sentence:** Keep LeanCTX a portable, useful local runtime and
open protocol; sell Thinkery as the trusted control plane that continuously tunes,
governs, proves, and operates that runtime across an organization.

---

## 1. Ground truth and planning rules

This document deliberately separates current repository capability from the
product that must be built.

It does not authorize marketing an unbuilt service as available.

It also does not make LeanCTX’s local features contingent on a Thinkery account.

### 1.1 What exists in LeanCTX today

- A local context runtime with agent integrations, proxying, local tuning,
  profiles/kits, portable evidence, and a local dashboard.
- Working-local policy and role enforcement, including audited denials.
- Local append-only audit records with hash chaining and signed evidence-chain
  primitives that reject cross-tenant entries.
- Local agent identity/attestation lifecycle and a capable host/project-scoped
  Agent Bus with scratchpad messages, claims, handoffs, leases, and persistence.
- Local task and handoff formats, context-kit loading/validation, session bundles,
  and protocol/reference scheduler primitives.
- Client-side cloud and enterprise-gateway configuration, bearer-token handling,
  usage metadata headers, account flows, plan entitlements, and billing stubs.
- Contract types for fleet control and a deterministic local control-plane demo.

### 1.2 What does not exist as a demonstrated product today

- A deployed Thinkery cloud control plane, gateway, admin console, or supported
  self-hosted control-plane package.
- Tenant-to-storage enforcement, organization/member persistence, server-side
  authorization, enrollment, or fleet inventory.
- Production SSO, SAML, OIDC callback handling, SCIM, organization RBAC, or
  identity-provider mapping.
- A central immutable audit service, WORM retention, legal hold, alerting,
  disaster recovery, or evidence search service.
- Policy distribution with acknowledgements, actual fleet enforcement, durable
  tenant-scoped leases, remote scheduler, or multi-region message delivery.
- A private kit registry, approval workflow, signed distribution, version pinning,
  adoption evidence, or cross-device shared memory.
- Production billing reconciliation, invoicing, payment/webhook integration,
  customer-visible usage reconciliation, or an operational SLA.
- A complete hosted proxy or working end-to-end remote A2A service.

### 1.3 Source constraints behind this plan

The strategy defines paid value as continuous AutoTune, hosted benchmark capacity,
private profiles/kits, shared evidence, organization economics, policy, access
control, and enterprise operation.

The A11 assessment sets the product boundary: LeanCTX is the local Agent Runtime
and open protocol; Thinkery is the Enterprise Agent Control Plane.

The A12 assessment requires central identity, tenant boundaries, usage, audit
retention, organization lifecycle, and fleet policy before a 50-developer pilot
can be represented as enterprise-ready.

The product must preserve open envelope, task, capsule, kit, session, and evidence
formats rather than monetizing a closed wire format.

### 1.4 Product promise

Thinkery sells a repeatable organizational outcome:

> Every participating local runtime receives approved improvements, follows the
> organization’s policy, and produces evidence that the organization can inspect.

The value is continuous tuning at scale, not remote ownership of a developer’s
machine.

---

## 2. What Thinkery is

### 2.1 Product definition

Thinkery is a multi-tenant organizational control plane for LeanCTX deployments.

It stores the organization’s approved tuning assets, policy intent, scoped
identity, adoption evidence, economic measures, and fleet-level operational state.

It does not replace LeanCTX’s local runtime, local control, or interoperability.

It is not a generic agent builder, workflow-canvas product, CRM/voice automation
suite, broad marketplace, or massive hosted-agent platform.

Thinkery may eventually offer a carefully bounded `RUN` integration depth for
operating an existing agent on managed infrastructure.

`RUN` is optional and later; it is not a prerequisite for Team, Business, or
Enterprise control-plane value.

### 2.2 Delivery model decision

Thinkery is both SaaS and self-hostable, with a common protocol and product
contract.

| Mode | Customer fit | Where control plane runs | Commercial intent |
|---|---|---|---|
| Thinkery Cloud | teams wanting the fastest adoption | Thinkery-operated regional SaaS | default Team and Business offer |
| Thinkery Dedicated | enterprises needing isolation or regional commitments | isolated Thinkery-operated tenant | Enterprise option |
| Thinkery Customer-Managed | regulated, sovereign, or air-gapped enterprises | customer cloud or data center | Enterprise option after product maturity |
| LeanCTX-only | individual/local use and offline environments | nowhere beyond local runtime | free/open local product |

Self-hosted means the control plane, its data stores, and its operator boundary run
inside the customer’s environment.

It must not mean an unsupported collection of source files or a customer-operated
copy of a SaaS database without lifecycle tooling.

Every self-hosted deployment needs versioned Helm or equivalent installation,
upgrade/rollback, backup/restore, observability, vulnerability updates, and a
supportability matrix.

### 2.3 Ownership model

LeanCTX owns local execution and user-local data.

Thinkery owns organization-scoped configuration and the trusted service needed to
coordinate it.

The customer owns its content, provider accounts, runtime enrollment decisions,
and organization policy.

Thinkery AG operates the SaaS according to the contracted data-processing and
support terms; it does not own customer prompts, code, or agent output.

### 2.4 The commercial wedge

The first sale is not “more dashboards.”

The first sale is a verified tuning outcome for a real customer workload.

That proof combines a baseline, an approved change, an isolated benchmark,
measured economic/quality result, and evidence that the approved profile reached
the intended runtimes.

---

## 3. Architecture and runtime relationship

### 3.1 Architectural principle

Local runtime remains authoritative for local execution.

Thinkery becomes authoritative only for organization-scoped identity, approved
artifacts, centrally issued policy, fleet coordination, and centrally retained
evidence where the customer elects to use those services.

No cloud command can silently bypass LeanCTX’s local safety guards.

### 3.2 Logical architecture

```text
Developer / existing coding agent
          |
          v
LeanCTX Runtime on the customer machine or CI worker
  - local proxy, context engine, kit resolver, policy guard
  - local audit/evidence, local session and local Agent Bus
  - Thinkery connector: outbound authenticated control channel
          |
          | signed policy/artifact updates, minimal telemetry, evidence manifests
          v
Thinkery Control Plane
  Identity | Organizations | Policy | Kit Registry | Tuning/Benchmark
  Fleet    | Evidence      | Economics | Admin API | Audit | Operations
          |
          +--> SaaS shared regional service
          +--> dedicated tenant deployment
          +--> customer-managed deployment
```

The connector is an additive integration, not a replacement for local MCP, CLI,
local proxy, files, or open protocol operations.

### 3.3 Trust boundary

The runtime verifies every remotely supplied, executable-relevant artifact before
use.

Those artifacts include policy bundles, kit manifests/packages, revocations,
directives, and enrollment certificates.

The runtime applies a locally cached last-known-valid policy when the control plane
is temporarily unreachable.

Policies must specify their offline behavior explicitly: fail-open, fail-closed,
or allow-only-existing-work.

Emergency stop/revocation must be signed, narrow in scope, auditable, and designed
to propagate with priority over normal tuning updates.

### 3.4 Control plane domains

| Domain | Thinkery responsibility | LeanCTX responsibility |
|---|---|---|
| Identity | org, member, service identity, enrollment, key lifecycle | device/runtime key storage, proof, local role enforcement |
| Policy | authoring, hierarchy, distribution, approval, acknowledgement | signature verification, cache, local guard enforcement, local audit |
| Kits/profiles | private registry, signatures, release channels, targeting | schema validation, resolution, local loading, rollback |
| Tuning | experiment design, benchmark queue, result comparison, promotion | capture approved measurements, run local adapters, emit evidence |
| Fleet | inventory, desired state, scoped commands, health history | health report, local decision, execution acknowledgement |
| Evidence | immutable central record, search, retention and export | local receipt generation, redaction, signing and upload choice |
| Economics | allocation, budgets, attribution and organization reports | local metering and signed settlement evidence |

### 3.5 Organization operating loop

1. An administrator establishes the organization, data region, and identity source.
2. A runtime is enrolled to a project/environment with an attested public key.
3. A platform owner publishes a signed kit/profile through a reviewable change.
4. Thinkery targets a release channel to an approved subset of runtimes.
5. LeanCTX verifies, applies, and records adoption or a precise rejection reason.
6. Tuning evidence and permitted aggregate measurements return to Thinkery.
7. The organization compares baseline versus outcome and promotes, rolls back, or
   iterates.
8. Audit, cost, health, and policy status remain available for operators.

This loop is the product; a dashboard is merely one view of it.

### 3.6 Policy hierarchy

Policy precedence is deterministic:

```text
Legal/regional guardrail
  > organization policy
  > business unit/project policy
  > environment/release channel policy
  > signed kit/profile constraints
  > local user preference
```

Lower layers may narrow permissions and choose safer settings.

Lower layers may not broaden a higher-layer restriction.

The effective policy must be inspectable locally, including the version, signer,
scope, expiry, and the reason a requested action was allowed or denied.

### 3.7 Agent coordination boundary

Local Agent Bus, task/envelope/capsule/session schemas, handoffs, claims, and
reference scheduling remain open LeanCTX capabilities.

Thinkery adds durable tenant-scoped coordination where the local primitives are
insufficient: fenced leases, assignment/recovery, message delivery receipts,
replay, quotas, federation, health/SLO history, and organization audit.

The protocol schemas and conformance fixtures stay public enough for independent
clients to interoperate.

Thinkery differentiates through operated reliability, identity, governance, and
evidence—not through obscuring the message format.

---

## 4. Product packaging and tier entitlements

### 4.1 Packaging principles

All paid tiers retain the LeanCTX local runtime and export/import portability.

Tiers differ by organization scope, operational guarantees, governance depth, and
managed capacity—not by withholding basic local safety or evidence capabilities.

An entitlement must map to an actually enforced server and runtime capability;
a billing plan flag alone is not a shipped feature.

### 4.2 Team

**Target customer:** a small engineering team proving repeatable local tuning.

**Commercial job:** turn individual successful profiles into a shared, observable
team practice.

Included capabilities:

- Organization, projects, members, invitations, and simple administrator/member
  roles.
- Shared signed profiles and kits with a basic private workspace registry.
- Team evidence ledger: baseline/result links, adoption status, redacted receipts,
  and export.
- Basic policy bundles for allowed providers/models, kit release channels, and
  high-level data-sharing defaults.
- Per-project economic views using approved aggregate runtime measures.
- Cloud-hosted benchmark jobs with bounded included capacity.
- Runtime enrollment, a lightweight fleet inventory, and last-seen health.
- Standard cloud support and documented shared-responsibility boundaries.

Explicit Team limits:

- No SCIM, SAML, enterprise identity mapping, or complex delegated RBAC.
- No customer-managed control-plane deployment or dedicated environment.
- No legal-hold, WORM retention commitment, enterprise SLA, or 24/7 response.
- No claim of centrally enforced device management beyond enrolled LeanCTX runtime
  policies.

### 4.3 Business

**Target customer:** a platform/engineering organization operating many local
runtimes across teams, repositories, and environments.

**Commercial job:** safely operate continuous tuning across a fleet.

Includes everything in Team, plus:

- Fleet control: enrollment groups, inventory, desired state, scoped rollout,
  acknowledgement, drift detection, rollback, and health history.
- Policy service with approval workflow, inheritance, targeting, expiry, offline
  behavior, exception workflow, and adoption evidence.
- Private organization kit registry with package signatures, channels, version
  pinning, promotion, rollback, targeting, approvals, and retention policy.
- Durable tenant-scoped leases and task coordination for managed agent workflows.
- Organization budgets, cost allocation, chargeback exports, provider/model
  governance, and tuning portfolio comparisons.
- Shared evidence search, longer retention options, controlled exports, and
  customer-defined redaction rules.
- Central directives with issuer, scope, expiry, acknowledgement, cancellation,
  and execution evidence.
- Standard business support, service health reporting, and named operating owner.

Business must not promise SSO/SCIM, certified compliance, dedicated isolation, or
an enterprise SLA until those capabilities and operations are independently ready.

### 4.4 Enterprise

**Target customer:** security-conscious, regulated, or large organizations with
identity, residency, compliance, and procurement requirements.

**Commercial job:** make LeanCTX fleet operation governable under the customer’s
security and operating model.

Includes everything in Business, plus:

- SSO through implemented OIDC/SAML integrations and verified callback/JWKS flows.
- SCIM lifecycle synchronization, deprovisioning, group mapping, and audit trail.
- Organization RBAC with least privilege, separation of duties, delegated admin,
  service accounts, break-glass procedure, and reviewable role assignments.
- Dedicated SaaS tenant or supported customer-managed control plane, as contracted.
- Regional residency selection, data-processing agreement, subprocessors
  disclosure, and configurable retention/deletion controls.
- BYOK for model-provider credentials and enterprise key-management integration for
  stored organization artifacts and evidence, where selected.
- Immutable central audit retention, legal hold, controlled e-discovery/export,
  evidence integrity verification, and SIEM integration.
- Compliance control mappings and evidence packs with clear scope; not an
  automatic certification or legal determination.
- Enterprise support, named technical owner, incident communications, contracted
  availability target, recovery objectives, and escalation path.
- Optional private networking, audit event streaming, dedicated capacity, and
  professional services for migration and policy design.

### 4.5 Entitlement enforcement

Every tier feature has three checks:

1. Server authorization verifies organization, role, plan, and resource scope.
2. Runtime capability negotiation verifies whether an enrolled version can honor
   the requested policy or artifact.
3. Audit evidence records the decision and version without relying on a UI state.

An unavailable capability is shown as unavailable—not visually enabled with a
future promise.

---

## 5. Data flow and privacy contract

### 5.1 Default data residency rule

Raw work stays local by default.

That includes source code, prompt bodies, model completions, shell commands and
output, local files, raw session memory, credentials, API responses, embeddings,
and unredacted evidence payloads.

Thinkery must not require these contents merely to enroll a runtime or enforce a
policy.

### 5.2 Data classes

| Data class | Default location | May go to Thinkery? | Conditions |
|---|---|---|---|
| Code, prompts, completions, shell I/O | local runtime | no | only a separately enabled, redacted artifact upload |
| Provider API keys and tokens | local secret store/customer vault | no | never sent to Thinkery control plane |
| Session bundles and context files | local runtime | optional | customer-selected encrypted sync/export with redaction policy |
| Policy, kit manifest, signatures | Thinkery + local cache | yes | organization content; signed and versioned |
| Private kit content | Thinkery registry or customer-managed registry | optional | encrypted; explicit organization upload/publish action |
| Runtime identity and posture | Thinkery metadata store | yes | minimum required enrollment claims and public keys |
| Operational telemetry | local by default | opt-in/contracted | aggregate counters and health only by default |
| Evidence receipt | local first | optional/contracted | redaction, classification, approval, encryption, retention apply |
| Benchmark input/output | selected benchmark boundary | optional | purpose-specific consent and isolation; do not silently reuse production data |
| Billing/usage record | Thinkery | yes for paid service | minimized, pseudonymous where feasible, retained per contract |

### 5.3 Permitted default cloud payload

The initial connector should send only information necessary to operate the
selected control-plane features:

- organization/project/runtime opaque identifiers;
- runtime version, protocol capabilities, signed attestation status, and health;
- policy/kit identifiers, versions, signatures, application result, and rejection
  reason code;
- aggregate timing/token/cost/quality measurements selected by the organization;
- evidence manifest hashes, signer, classification, and upload state;
- fleet command acknowledgement, error category, and safety state.

No raw prompt, repository path, file content, command string, completion, secret,
or full session is part of this default payload.

### 5.4 Optional data paths

An organization may deliberately enable additional paths:

- Upload an encrypted private kit package to the private registry.
- Upload redacted evidence needed to defend a tuning or compliance outcome.
- Submit a sanitized benchmark corpus to hosted benchmark capacity.
- Synchronize an encrypted shared-memory bundle across approved devices.
- Stream selected central audit events to Thinkery or a customer SIEM.

Each optional path needs a visible setting, documented purpose, classification,
retention period, recipient, and a way to disable future transfers.

### 5.5 BYOK principle

BYOK has two independent meanings and Thinkery must support both without
ambiguity.

**Model-provider BYOK:** LLM/provider keys remain in the local runtime, CI secret
store, or customer secret manager.

Thinkery receives neither the provider key nor the provider’s raw request body.

It can distribute an approved provider policy and record an aggregate attribution
label, but it must not become an undeclared credential proxy.

**Encryption-key control:** Enterprise customers can choose a customer-controlled
KMS/HSM key for organization artifacts and evidence stored in Thinkery.

Thinkery uses envelope encryption, records key version metadata, supports rotation,
and fails safely when a required customer key is unavailable.

The precise availability and recovery trade-off of customer-managed keys must be
contracted before enabling the feature.

### 5.6 Security requirements

- Mutual authenticated enrollment using organization-bound runtime identity.
- Short-lived access tokens with scoped refresh and revocation.
- Signature verification for policy, kit, directive, and evidence artifacts.
- Tenant boundary enforced in every API, queue, cache, object, index, and billing
  query—not merely in a type definition.
- Row/object-level isolation tests, adversarial cross-tenant tests, and audit of
  every privileged support access.
- Encryption in transit and at rest, secret-manager storage, rotation, and no
  production secrets in runtime configuration or diagnostics.
- Immutable central audit design with retention/deletion/legal-hold semantics that
  are actually enforced and tested.
- Data-export, deletion, incident notification, and backup/restore procedures.

### 5.7 Privacy-safe telemetry design

Use schema-versioned event envelopes with an allowlist, not arbitrary client logs.

Fields must be categorized as required operational metadata, optional aggregate
measurement, or prohibited content.

Runtime-side redaction happens before network serialization.

Debug capture that could contain content must be separately enabled, time-bounded,
encrypted, access-controlled, and visible in the audit trail.

### 5.8 Customer control points

Administrators control:

- region and deployment mode;
- enabled telemetry categories and sampling;
- which evidence classifications may upload;
- benchmark data boundary and retention;
- kit sharing scope and release channels;
- model/provider allowlists and budget rules;
- data retention, legal hold, exports, and deletion;
- support-access workflow and break-glass approval.

Developers can always inspect the local effective policy and the exact outbound
event schema, while not being able to weaken an organization restriction.

---

## 6. Technical implementation plan

### 6.1 Delivery shape

Build a new Thinkery control-plane repository or a clearly separated deployable
service subtree with independent CI, threat model, IaC, migrations, and operations
runbooks.

Do not pretend the current LeanCTX client-side cloud code is the server.

The server should expose versioned public APIs and a protocol compatibility matrix.

The initial implementation may use a modular monolith with isolated domain
modules; it must not distribute a prematurely complex microservice estate.

### 6.2 New control-plane services

| Service/module | Minimum responsibility | Earliest tier |
|---|---|---|
| Identity and tenancy | org/project/member/runtime identity, enrollment, scopes, tenant boundary | Team pilot |
| Artifact registry | kit/profile blobs, manifests, signatures, channels, promotion, rollback | Team |
| Policy service | policy versioning, inheritance, targeting, approval, signed distribution | Team, expanded Business |
| Evidence service | manifest registry, immutable objects, verification, search, export, retention | Team, hardened Enterprise |
| Tuning service | baseline, experiment, benchmark orchestration, result comparison, promotion evidence | Team |
| Fleet service | inventory, desired state, health, acknowledgements, rollout, drift | Business |
| Coordination service | fenced leases, durable tasks/messages, delivery receipts, replay | Business |
| Economics service | usage ingestion, allocation, budgets, chargeback, reconciliation | Team, expanded Business |
| Admin/identity bridge | SSO, SCIM, RBAC, audit, API/service accounts | Enterprise |
| Operations plane | deployment, observability, backup/restore, incident, residency, support tooling | from pilot onward |

### 6.3 LeanCTX changes required

1. Add a versioned `thinkery` connector module with explicit enablement and a
   minimized outbound event schema.
2. Add organization/runtime enrollment, certificate/token lifecycle, local
   capability advertisement, revocation, and certificate/key rotation.
3. Unify or bridge the existing local CLI identity registry and collaboration
   registry before treating an agent identity as fleet-authoritative.
4. Implement a policy-bundle verifier, deterministic precedence resolver, local
   cache, acknowledgement protocol, offline semantics, and effective-policy view.
5. Add signed kit manifest/package references to runtime selection and agent/task
   handoff evidence; preserve local kit loading for offline use.
6. Implement registry client operations: publish, fetch, verify, pin, promote,
   roll back, and report adoption without sending work content.
7. Introduce an open directive schema/client with issuer, target, policy version,
   priority, expiry, acknowledgement, cancellation, and execution-evidence fields.
8. Replace process-local lease authority with a pluggable provider interface;
   retain transparent local leases and add a Thinkery tenant-scoped fenced provider.
9. Repair the remote A2A route mismatch, add end-to-end conformance fixtures, and
   make remote transport opt-in rather than assumed.
10. Wire persistent heartbeat/reaping and A2A health into normal runtime, then
    publish a stable local health contract for fleet aggregation.
11. Add runtime-side telemetry allowlists, redaction, consent/config reporting,
    queue back-pressure, retry, and local inspection/export tools.
12. Extend evidence uploads from local signed JSONL/evidence chains to redacted,
    classified, resumable, encrypted, tenant-scoped central ingestion.
13. Make plan entitlements server-verified and capability-aware; remove reliance
    on local billing flags for security or feature claims.

### 6.4 Protocol and API requirements

All organization-scoped objects must carry:

- protocol version;
- tenant/organization and project scope;
- immutable resource ID and revision;
- actor/issuer identity;
- classification and retention policy where relevant;
- signature and signing key identifier where relevant;
- idempotency key for mutations;
- audit correlation ID;
- explicit expiry and offline semantics for executable policy.

Control-plane commands must be desired-state records, not arbitrary remote shell
commands.

Runtime acknowledgement must distinguish received, verified, applied, rejected,
deferred, expired, and rolled-back states.

Every mutation needs an idempotent API contract and durable audit event.

### 6.5 Data stores and isolation

Use a relational system for tenancy, identity, RBAC, policy metadata, audit index,
and billing facts with enforced tenant scoping.

Use object storage for encrypted kit/evidence blobs, with tenant-scoped prefixes,
per-object metadata, retention controls, and integrity checks.

Use durable queues for benchmark jobs, policy rollout, coordination, and outbound
notifications; each queue item must include tenant scope and dead-letter behavior.

Use a search/index service only for customer-approved metadata and central evidence
content that is eligible for search.

No shared cache or analytics warehouse query may bypass the tenant authorization
layer.

### 6.6 Self-hosting implementation

Customer-Managed Enterprise ships only after SaaS has exercised the same deployable
artifacts and operational runbooks.

Required deliverables:

- signed container images and SBOMs;
- declarative installation and upgrade charts/manifests;
- external database/object-storage/KMS integration guides;
- offline or restricted-egress licensing and update behavior;
- backup/restore and disaster-recovery validation;
- logging/metrics/tracing with content-safe defaults;
- compatibility checks between control-plane and LeanCTX runtime versions;
- documented customer/Thinkery shared operational responsibilities.

### 6.7 Security and quality gates

Before any paid pilot:

- End-to-end tenant isolation tests across APIs, queues, objects, caches, indexes,
  evidence, and billing.
- External security review of enrollment, access control, upload, and artifact
  verification paths.
- Load and recovery tests for policy rollout and audit ingestion.
- Restore exercise for backups and evidence integrity verification.
- Evidence that retention/deletion claims are enforced, not merely documented.
- Publicly reviewable protocol conformance tests for runtime-to-control-plane flows.
- Accurate product capability matrix marked by deployment status, not plan flags.

---

## 7. Timeline and release gates

Dates below are relative to an approved start, not promises to customers.

### Phase 0 — Foundation and design partners (0–3 months)

Goal: prove a customer will pay for a verified tuning outcome.

- Confirm two to three design partners and their data/residency constraints.
- Define product contracts, data classification, DPA/security questionnaire input,
  threat model, and customer language for “local by default.”
- Deliver thin identity/tenant model, runtime enrollment, private artifact upload,
  signed artifact verification, and one evidence manifest path.
- Build a narrow hosted benchmark workflow on sanitized or customer-approved data.
- Demonstrate baseline, change, measured result, and local adoption evidence for a
  real customer workload.

**Commercial availability:** paid design-partner engagement or professional
services; no general Team SKU promise yet.

**Exit gate:** audited end-to-end proof and explicit customer value, not a demo.

### Phase 1 — Team beta (3–6 months)

Goal: make shared tuning safely repeatable for a small team.

- Ship organization/member persistence, invitation lifecycle, basic roles, runtime
  enrollment, signed profile/kit registry, and basic policy distribution.
- Ship evidence ledger, redacted export, aggregate economics, bounded benchmark
  capacity, local effective-policy inspection, and transparent outbound telemetry.
- Operate one production region with backups, monitoring, incident process, and
  support boundaries.
- Validate the Team experience with a limited beta cohort and a documented data
  processing model.

**Commercial availability:** Team private beta, sold only with feature limits
stated in the order form and product UI.

**Exit gate:** tenant isolation, artifact verification, audit integrity, and
recovery exercise pass; no unqualified fleet or SSO claims.

### Phase 2 — Team general availability and Business pilot (6–10 months)

Goal: introduce accountable fleet operation.

- Make Team generally available after reliability, onboarding, and support gates.
- Add policy approvals/inheritance, release channels, targeting, pin/rollback, and
  adoption evidence.
- Add fleet inventory, durable desired state, scoped rollout, drift/health history,
  organization budgets, and provider/model governance.
- Replace local-only lease authority for opted-in workflows with tenant-scoped
  fenced leases and durable coordination.
- Fix and certify remote A2A compatibility before offering managed relay features.

**Commercial availability:** Business paid pilot with explicit scale and service
limits; Team GA if its own gates have passed.

**Exit gate:** a 50-developer pilot can show organization lifecycle, tenant
authorization, central audit retention, fleet policy, and recoverable rollout.

### Phase 3 — Business general availability and Enterprise beta (10–15 months)

Goal: make control-plane governance useful to a platform organization.

- Generalize fleet rollout, durable coordination, private registry approvals,
  shared evidence search, chargeback exports, and operational dashboard.
- Add OIDC/SAML integrations, SCIM lifecycle, organization RBAC, service accounts,
  SIEM events, and defined support-access controls.
- Establish dedicated deployment pattern, regional residency controls, encryption
  key integration, WORM/retention implementation, legal hold where offered, and
  formal incident/recovery operations.

**Commercial availability:** Business GA; Enterprise limited beta with contract
review per customer.

**Exit gate:** identity and compliance claims independently tested; support and
operations evidence meets the proposed contract.

### Phase 4 — Enterprise general availability (15–24 months)

Goal: offer a supportable enterprise operating model.

- Deliver contracted SLA operations, dedicated SaaS, and customer-managed package
  where the same deployment artifacts have proven reliable.
- Complete SSO/SCIM/RBAC lifecycle, data-region and KMS options, central audit and
  retention, e-discovery/export controls, and compliance evidence packs.
- Offer optional managed relay, advanced federation, and capacity only after their
  protocol, security, and operational controls reach the same standard.

**Commercial availability:** Enterprise GA by deployment mode and region, not a
single blanket claim.

### Timeline rule

Move a tier only when the associated service, enforcement point, runbook, and
support posture all exist.

Do not accelerate an Enterprise label by counting local LeanCTX primitives as an
operated multi-tenant service.

---

## 8. Revenue model

### 8.1 Model

Use a hybrid of predictable subscription and transparent consumption.

Subscription pays for organization controls, retained state, support level, and
the right to operate the relevant tier.

Usage pays for variable managed capacity that creates cost for Thinkery.

Do not tax raw customer code, prompt text, or every local token merely because the
runtime exists.

### 8.2 Subscription dimensions

| Tier | Base subscription includes | Primary pricing metric |
|---|---|---|
| Team | organization, member bundle, private workspace, baseline evidence, support | active named members or active runtimes |
| Business | Team plus fleet/policy/registry/coordination/operations | active managed runtimes with organization platform minimum |
| Enterprise | Business plus identity, compliance, deployment, SLA, dedicated support | annual platform commitment plus managed runtime/users and deployment scope |

An “active managed runtime” should be narrowly defined, deduplicated, observable,
and shown to the customer before invoice generation.

### 8.3 Usage dimensions

Meter only services that Thinkery actually operates:

- hosted benchmark compute/time and retained benchmark datasets;
- managed relay/coordination message volume where used;
- encrypted artifact/evidence storage beyond included retention;
- premium data-export/e-discovery volume where it creates material cost;
- dedicated regional capacity, private connectivity, or dedicated deployment;
- professional services, migration, policy design, and custom integration.

Keep the meter customer-visible, exportable, and reconciled against signed or
auditable settlement evidence.

### 8.4 What is not a meter

Do not charge separately for:

- local LeanCTX use in the OSS/local-only mode;
- local source files, prompts, or model completions that never leave the machine;
- safety-policy denials or error retries caused by Thinkery defects;
- a feature called “Enterprise” that is not yet actually available.

### 8.5 Commercial motion

1. Start with paid design-partner tuning engagements.
2. Convert repeatable shared-profile/evidence value into Team subscriptions.
3. Expand within a customer when fleet policy, private registry, and economics are
   operationally indispensable.
4. Sell Enterprise on identity, governance, residency, deployment, and support
   requirements after those contractual controls are proven.

Professional services accelerates adoption but must not become the only way the
product can work.

### 8.6 Customer value measurement

The primary business metric remains verified cost per successful agent task.

Supporting metrics are successful-task quality, latency, safe adoption rate,
profile rollout time, policy compliance, avoided duplicated work, and evidence
completeness.

Savings claims need a stated baseline, method, confidence/limitations, and source
evidence; they must not be inferred from opaque telemetry.

---

## 9. Organizational operating model for Thinkery AG

### 9.1 Product operating responsibilities

| Function | Owns | Must not do |
|---|---|---|
| Product | tier boundary, outcome proof, customer discovery, packaging | promise unbuilt compliance or fleet controls |
| Runtime engineering | connector, local safety, open protocol, portability | require cloud for local use |
| Control-plane engineering | tenancy, APIs, registry, policy, fleet, evidence services | bypass runtime verification or tenant isolation |
| Security/privacy | threat model, data contract, access review, incident readiness | treat optional content upload as implicit consent |
| SRE/operations | availability, backup/restore, deployment, monitoring, incident response | certify unsupported self-hosting |
| Customer success | onboarding, adoption, tuning methodology, value realization | gain raw-work-data access by default |
| Sales/legal | accurate order forms, DPA, SLA, support and claim boundaries | sell roadmap as shipped product |

### 9.2 Customer operating responsibilities

The customer assigns an organization owner, security/identity owner, platform
owner, project administrators, and end users.

The customer approves data settings, identity integration, model/provider policy,
kit promotion, retention choices, and access to its own evidence.

Thinkery provides the service and contractually agreed support; the customer keeps
control of work content and its LLM-provider agreements.

### 9.3 Operating cadences

- Weekly: tuning experiment review, rollout/adoption exceptions, and budget drift.
- Monthly: artifact/policy release review, runtime health and version compliance.
- Quarterly: role/access review, data-path review, recovery exercise, and value
  review against verified-task economics.
- Annually: enterprise key/retention review, incident/tabletop exercise, and
  contract/SLA scope review.

### 9.4 Support and access model

Support access is least-privilege, ticket-bound, time-limited, and audited.

Customer content is inaccessible to routine support by default.

Break-glass access requires named approval, reason, scope, expiry, customer
notification where contractually feasible, and a tamper-evident audit record.

---

## 10. Non-goals and guardrails

- Do not turn Thinkery into a generic agent builder or workflow canvas.
- Do not make the local LeanCTX runtime a thin agent of a proprietary cloud.
- Do not centralize raw prompts, code, or completions for convenience.
- Do not use a plan flag, guide, or protocol type as evidence that a service ships.
- Do not present local RBAC as organization RBAC or local audit as central
  compliance retention.
- Do not sell SSO, SCIM, hosted proxy, fleet management, centralized control plane,
  production billing, or legal compliance certification until implemented,
  operated, tested, and supportable.
- Do not use remote directives as arbitrary remote execution; use signed,
  policy-bounded desired state with local verification.
- Do not close open protocols to manufacture lock-in.

---

## 11. Decision record and next actions

### Decisions

- Thinkery is the commercial organization/control-plane layer around LeanCTX, not
  a replacement runtime.
- SaaS is the default delivery model; dedicated and customer-managed deployments
  are Enterprise delivery modes once operationally mature.
- Local-by-default and BYOK are product invariants, not Enterprise-only add-ons.
- Team monetizes shared tuning and evidence; Business monetizes fleet operation;
  Enterprise monetizes identity, compliance, deployment, and support.
- Subscription is the commercial anchor; usage is limited to operated variable
  capacity.

### Immediate next actions

1. Validate this contract with design partners, security reviewers, and counsel.
2. Create a separate Thinkery service architecture decision record, threat model,
   and data-classification specification.
3. Select the minimal Phase 0 vertical slice: enrollment, signed artifact, narrow
   benchmark, redacted evidence manifest, and measured customer outcome.
4. Add LeanCTX connector/protocol work behind explicit opt-in and feature gates.
5. Maintain a public capability matrix that distinguishes local implementation,
   contract, beta, and generally available Thinkery services.

### Success criterion

The commercial layer is credible when a customer can answer, with evidence:

> Which approved tuning is active on which runtimes, what policy governed it, what
> it changed economically, and what data left the local environment?

