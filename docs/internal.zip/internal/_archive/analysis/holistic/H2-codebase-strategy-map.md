# H2 — Complete codebase-to-SDK-strategy map

## Scope and rating method

This maps every major deployable, public, or separately owned module family in
A1-codebase-map.md. Small algorithms are included under their owning family
rather than pretending each of the hundreds of Rust leaf files is a product
component.

- Status: production = shipped/hard-wired surface; working = implemented,
  usable capability but not yet the canonical v1 object/workflow; scaffolded =
  implementation substrate or experimental surface lacking a product contract;
  missing = no in-repository implementation.
- Object is the *primary* SDK object. A module can contribute to other objects.
- Integration depth uses the strategy taxonomy. “Run (local only)” is not the
  strategy’s future managed Run offering.
- Priority means what v1.0 needs to achieve the strategy’s 90-day success
  definition: connect an agent, tune it, prove before/after, and deploy a
  versioned profile.

## Executive readout

The codebase has far more than a compression utility. It already has the
working substrate for Attach, Wrap and Embed: MCP tools/hooks, proxy/wrapper,
and an in-process Rust SDK. It also has concrete predecessors for every
product object:

| Strategy object | Existing implementation | Assessment |
|---|---|---|
| LeanCTX | Rust runtime, MCP server, proxy, hooks, CLI, SDKs and clients | Production foundation |
| ContextSession | core/session SessionState, context_kernel usage/session state, memory, ledger | Working; needs one public canonical object/API |
| TuningProfile | core/profiles Profile and config/policy stack | Working; needs versioned public TuningProfile, lifecycle and deploy contract |
| Kit | kits ContextKit, context_package, skillify, pack CLI | Working; needs Profile linkage and signed/reproducible Kit contract |
| Receipt | protocol ExecutionReceiptV1, SavingsReceiptV1, ContextReceiptV1; evidence_flow | Working; strongest strategy-convergence area |
| Bundle | protocol ContextBundleV1; core evidence_bundle/evidence_ledger/provenance | Working; needs canonical EvidenceBundleV1 composed from receipts |

The central v1 gap is integration, not invention: the above pieces do not yet
compose into one stable SDK flow:

    connect -> ContextSession -> choose TuningProfile -> run/measure
            -> signed ExecutionReceipt + SavingsReceipt -> EvidenceBundle
            -> deploy Profile/Kit -> repeat with comparable baselines

No Dyno or AutoTune product implementation was found in Rust crates (the
source search for Dyno/AutoTune returned no hits). Existing benchmark,
adaptive, bandit, profile, evidence and receipt code is useful substrate, but
does not itself constitute either product.

## A. Public runtime, contracts, SDKs and developer surfaces

| Component(s) | Strategy concept | Product object | Depth | Status | v1.0 | Mapping |
|---|---|---|---|---|---|---|
| rust/src main binary, engine, CLI dispatcher and command families | Connect -> Tune -> Measure -> Prove -> Deploy | LeanCTX | Attach | production | critical | Primary local runtime and the existing user-facing control plane. |
| rust/crates/lean-ctx-sdk | Connect, Tune | LeanCTX | Embed | working | critical | In-process Rust facade for engine/read/compress/token APIs; must become the north-star SDK entry point. |
| rust/crates/lean-ctx-protocol | Measure, Prove, Deploy | Receipt | Embed | working | critical | Open wire contract already exports ExecutionReceiptV1, SavingsReceiptV1, ContextReceiptV1 and ContextBundleV1. |
| rust/crates/lean-ctx-ocla | Connect, Measure, Repeat | ContextSession | Embed | working | important | Lifecycle/event-bus protocol substrate; needs explicit ContextSession event ownership. |
| rust/crates/grammar-addons/* and signatures_ts grammar loader | Tune | LeanCTX | Embed | production | important | Language-aware parsing improves selection/compression across long-tail languages. |
| rust/crates/vendor/rmcp and rmcp-macros | Connect | LeanCTX | Attach | production | important | Vendored MCP transport dependency; not a product object, but critical Attach plumbing. |
| clients/rust/lean-ctx-client | Connect, Measure | LeanCTX | Attach | working | critical | HTTP client can be a supported integration, but needs v1 session/profile/receipt APIs. |
| clients/python/leanctx and packages/python-lean-ctx | Connect, Measure | LeanCTX | Attach | working | critical | Python Attach SDK/client; productize and conformance-test against canonical contracts. |
| packages/node-lean-ctx and packages/lean-ctx-bin | Connect, Deploy | LeanCTX | Attach | working | critical | Node integration and installer/distribution surface for coding agents. |
| packages/leanctx-verify | Prove | Bundle | Embed | working | critical | Offline verification is the right independent proof boundary; align to EvidenceBundleV1. |
| packages/ocla-grpc | Connect, Repeat | ContextSession | Embed | scaffolded | park | Useful future transport, but no v1 need until multi-process/enterprise interoperability is real. |
| cookbook/sdk and cookbook examples | Connect, Tune | LeanCTX | Embed | working | important | Reference integrations and contract examples; must demonstrate the complete SDK loop, not only endpoint calls. |
| examples/ocla_consumer | Connect, Repeat | ContextSession | Embed | scaffolded | nice-to-have | Protocol demonstration, not a v1 product path. |

## B. Connect — Attach and Wrap integration layer

| Component(s) | Strategy concept | Product object | Depth | Status | v1.0 | Mapping |
|---|---|---|---|---|---|---|
| rust/src/server, server/call_tool, server/dispatch, tool_defs, tools/registered | Connect, Tune | LeanCTX | Attach | production | critical | MCP server and registered ctx tools are the flagship coding-agent Attach path. |
| rust/src/tools/{ctx_read,ctx_search,ctx_semantic_search,ctx_explore,ctx_outline,ctx_impact,ctx_knowledge,ctx_patch,ctx_edit,ctx_refactor,ctx_multi_repo,ctx_cognitive} | Connect, Tune, Repeat | ContextSession | Attach | production | critical | Tool surface supplies the context-engine loop; should emit/consume canonical session and receipt identifiers. |
| rust/src/mcp_catalog with adapters and postprocess; mcp_manifest | Connect | LeanCTX | Attach | working | important | Discovers/adapts MCP capability; needs supported-integration registry and conformance declaration. |
| rust/src/hooks and hook_handlers, including agent-specific Codex/Copilot/Vibe handlers | Connect, Tune, Measure | LeanCTX | Attach | production | critical | Direct supported coding-agent installation/instrumentation; strongest current Connect wedge. |
| rust/src/wrap, proxy_setup, rules_inject | Connect, Deploy | LeanCTX | Wrap | production | critical | Existing wrapper/rule installation must be modelled as an integration record in ContextSession. |
| rust/src/proxy and proxy/forward | Connect, Tune, Measure | LeanCTX | Wrap | production | critical | Intercepts provider traffic, transforms context and tracks usage; central Wrap path. |
| rust/src/proxy/{web_app,effort,effort_routing,prose} | Tune, Measure | TuningProfile | Wrap | working | important | Runtime routing, effort and prose controls are profile dimensions but are not yet exposed as a public profile schema. |
| rust/src/http_server, ipc, sidecar_transport, capsule_transport | Connect, Deploy | LeanCTX | Embed | working | important | Local API/process seams; useful to host the canonical SDK lifecycle. |
| rust/src/daemon_autostart, proxy_autostart, core/launchd, core/update_scheduler | Connect, Deploy | LeanCTX | Run (local only) | production | important | Reliable local service installation; not the strategy’s hosted/managed Run offering. |
| rust/src/setup, uninstall, doctor/checks, doctor/integrations, codesign | Connect, Deploy | LeanCTX | Attach | production | critical | Installation, repair and integration health determine successful activation. |
| rust/src/editor_registry with writers/install, editor_signal, lsp | Connect, Measure | LeanCTX | Attach | working | important | IDE/editor integration discovery and signals; use it for explicit Connect coverage. |
| rust/src/cli/{agent_cmd,onboard,install,init,bootstrap,wrap,unwrap,status} and CLI dispatch/lifecycle/network | Connect, Deploy | LeanCTX | Attach | production | critical | Existing operator entry points; converge their outputs on one Session ID and integration descriptor. |
| rust/src/core/a2a and a2a_transport; core/agents and agent_identity/runtime_env/registry | Connect, Repeat | ContextSession | Embed | working | important | Agent identity, handoff and coordination substrate; valuable for multi-agent sessions. |
| rust/src/core/providers and providers/config_provider; model_registry/router; proxy translation | Connect, Tune | LeanCTX | Wrap | production | critical | Provider-neutral ingress/routing supports the strategy’s “agent stays agent” promise. |
| rust/src/core/plugins, addons, extension_registry; cli addon/plugin commands | Connect, Deploy | Kit | Attach | working | important | Distribution/extension path; needs signed Kit/Profile compatibility metadata. |
| rust/src/core/web and ctx_url_read | Connect, Tune | ContextSession | Attach | working | nice-to-have | External research content ingress; useful but not required for coding-agent v1 proof. |

## C. Tune — context engine and planning substrate

| Component(s) | Strategy concept | Product object | Depth | Status | v1.0 | Mapping |
|---|---|---|---|---|---|---|
| core/context_kernel, including activation, hotpath_wiring, proxy_bridge, tool_surface, degradation, usage_normalizer and attribution | Tune, Measure, Repeat | ContextSession | Embed | working | critical | Closest implementation of the Context Engine/Planning layer; already bridges MCP/proxy, context plans and receipts. |
| core/context_{ir,field,column,artifacts,handles,overlay,policies,overhead,deficit,radar,lint,proof,proof_v2,compiler} | Tune, Prove | ContextSession | Embed | working | critical | Internal representations, plans, selection policy and context proof; consolidate behind public ContextSession/plan APIs. |
| core/context_os and contextops | Tune, Deploy | LeanCTX | Embed | working | important | Runtime orchestration/control vocabulary; needs reduction to the strategy’s smaller product model. |
| core/context_package with manifest/deps, context_packing, context_capsule and context_capsule transport | Tune, Deploy | Kit | Embed | working | critical | Packaging substrate for ContextKit; needs canonical version/signature/Profile binding. |
| core/context_prefetch, predictive_prefetch, fep_prefetch, context_gc | Tune, Repeat | ContextSession | Embed | working | important | Performance optimizations for contextual retrieval; profile-governed behavior needed for reproducibility. |
| core/compressor, adaptive_compression, progressive_compression, chain_compression, compress_preview, compression_safety, preservation, protect | Tune | TuningProfile | Embed | production | critical | Primary context-performance engine; policy knobs should be first-class profile fields. |
| core/{terse,verbosity,markdown_compact,html_crush,json_crush,json_sample,tabular_crush,yaml_crush,structural_tokenizer,structured_read,structured_compact,transcript_compact} | Tune | TuningProfile | Embed | production | important | Format-specific transforms that a profile selects and a receipt must declare. |
| rust/src/shell with compress and exec/execution | Tune, Measure | LeanCTX | Wrap | production | critical | Shell interception/compression engine; major current efficiency surface. |
| core/{relevance_tracker,task_relevance,task_spine,attention_context,attention_model,attention_placement,attention_layout_driver,litm,litm_calibration} | Tune | TuningProfile | Embed | working | important | Selection and placement intelligence; expose only evaluated controls in v1 profiles. |
| core/{bm25_index,bm25_cache,search_index,semantic_cache,semantic_chunks,hybrid_search,search_reranking,search_delta,cooccurrence,spreading_activation} | Tune, Repeat | ContextSession | Embed | production | critical | Local retrieval/index foundation for contextual selection and reuse. |
| core/{embeddings,embedding_index,embedding_quant,dense_backend,hnsw,ann_cache,pgvector_store,qdrant_store} | Tune, Repeat | ContextSession | Embed | working | important | Dense retrieval backends; require deterministic fallback and profile disclosure. |
| core/{graph_analysis,graph_expand,graph_index,graph_context,graph_export,graph_features,graph_provider,graph_enricher,graph_coordinator,property_graph,call_graph,gamma_cover,pagerank,cross_source_edges,cross_source_hints} | Tune, Repeat | ContextSession | Embed | working | important | Code/knowledge graph improves planning and repomaps; do not make it a v1 activation dependency. |
| core/repomap, deep_queries, codebook, extractive, extractors, signatures, signatures_ts/handlers, ast_walk, type_ref_edges | Tune | ContextSession | Attach | production | critical | High-value code understanding and structural context extraction for the coding-agent wedge. |
| core/knowledge with knowledge_router, knowledge_bridge, knowledge_embedding, knowledge_provider_extract, knowledge_relations, knowledge_vault, negative_knowledge | Tune, Repeat | ContextSession | Embed | working | important | Persistent knowledge model; needs clear Session versus project knowledge boundaries. |
| core/{cache,content_cache,content_chunk,cache_diagnostics,cache_telemetry,content_handle,handle,hasher,hashing-related paths} | Tune, Measure | ContextSession | Embed | production | critical | Deterministic reuse and cache observability underpin the performance claim. |
| core/{import,import_resolver,ingestion,index_admission,index_orchestrator,index_bundle,index_namespace,index_paths,index_progress,reference_docs} | Connect, Tune | ContextSession | Embed | working | important | Project/source ingestion and index lifecycle. |
| core/{input_filters,filters,output_sanitizer,sanitize,redaction,secret_detection,binary_detect,pathjail,path_resolve,pathutil,paths} | Tune, Deploy | LeanCTX | Attach | production | critical | Safety and path/data hygiene for all integrations; mandatory for v1 SDK conformance. |
| core/{anti_interrupt,interrupt,recovery,io_boundary,io_health,bounded_lock,path_locks} | Connect, Repeat | ContextSession | Attach | production | important | Runtime continuity and bounded-failure controls; preserve session identity and receipt completeness across failures. |
| core/{policy,policy/org,shell_allowlist,sandbox,sandbox_landlock,sandbox_seatbelt,security_posture,owasp_alignment,ide_permissions,trust,integrity,process_guard,startup_guard} | Deploy, Prove | TuningProfile | Attach | production | critical | Policy enforcement and trust posture; profiles must declare policy compatibility rather than bypass it. |
| core/{config,config/schema,config_heal,workspace_config,runtime_flags,capabilities,client_capabilities,client_constraints,language_capabilities,limits,home,xdg_migrate} | Connect, Deploy | TuningProfile | Attach | production | critical | Configuration/feature negotiation is the immediate carrier for a versioned profile. |
| core/{intent_engine,intent_lang,intent_protocol,intent_router,triage,triage/distillation,route_extractor,query_aware,mdl_mode,mdl_selector} | Tune | TuningProfile | Embed | working | important | Intent-aware mode/routing selection; needs benchmark-backed profile defaults. |
| core/{model_router,provider_bandit,adaptive,adaptive_mode_policy,adaptive_thresholds,auto_mode_resolver,bandit,decision_loop,decision_loop_runtime,threshold_learning} | Tune, Repeat | TuningProfile | Embed | scaffolded | important | Viable AutoTune substrate, but no productized optimizer, experiment controller or profile promotion gate. |
| core/{cognitive,cognition_loop,cognition_scheduler,cognitive_gate,cognitive_load,neural,ort_environment,ort_execution_providers,information_bottleneck,ib,locomo,energy,free_energy_budget,qubo_select,wasserstein} | Tune, Repeat | TuningProfile | Embed | scaffolded | park | Research/advanced optimization components; keep behind experimental flags until Dyno proves benefit. |
| core/{patterns,patterns/git,git,git_cache,git_signals,git_util,project_hash,workspace_trust} | Tune, Prove | ContextSession | Embed | working | important | Repository-awareness and source provenance improve task plans and reproducible evidence. |
| core/{workflow,pipeline,canonical,contracts,protocol,openapi,ocp} | Deploy, Repeat | Kit | Embed | working | important | Workflow/contract foundations; make the v1 object transitions explicit here. |

## D. Measure — usage, economics and outcome measurement

| Component(s) | Strategy concept | Product object | Depth | Status | v1.0 | Mapping |
|---|---|---|---|---|---|---|
| core/measurement, metering, telemetry, telemetry_ledger, stats/stats/format, introspect | Measure | Receipt | Attach | production | critical | Core instrumentation and reporting; normalize around ExecutionReceiptV1. |
| core/tokens, token_calibration, tokenizer_translation_driver, grammar_usage | Measure, Tune | Receipt | Embed | production | critical | Token accounting and calibration feed cost/context measurements. |
| core/savings_ledger, savings_tracker, savings_footer, savings_autopush | Measure, Prove | Receipt | Attach | production | critical | Local savings accounting; map its records to canonical SavingsReceiptV1. |
| core/execution_ledger, context_ledger, journal, audit_trail, live_evidence_ledger | Measure, Repeat | ContextSession | Embed | working | critical | Durable lifecycle trail; needs a single Session/Execution identity model. |
| core/billing with settlement_evidence, finops_export, cost_per_outcome, gain, value_gate, marginal_gate | Measure, Prove | Receipt | Embed | working | critical | Cost/FinOps/value proof capability; use calculated/provider/reconciled cost taxonomy from strategy. |
| core/{outcome,outcome_engine,quality,quality_scorecard,scorecard,setup_report,efficacy,feedback,causal_attribution,attribution,agent_attribution} | Measure, Repeat | Receipt | Embed | working | critical | Outcome and attribution dimensions necessary for “savings without quality loss.” |
| core/{budgets,budget,budget_tracker,session_budget,agent_budget,agent_lease,free_energy_budget,energy,homeostasis} | Measure, Tune | TuningProfile | Embed | working | important | Constraints/guardrails that should be profile policy and receipt context. |
| core/{sensitivity,anomaly,surprise,echo_ratio,heatmap,relevance_gate,degradation_policy,verification_observability,slow_log,debug_log,crash_log,diagnostics_store,io_health,tool_health} | Measure, Prove | Receipt | Embed | working | important | Observability, anomaly and quality safeguards; not all metrics are current customer-facing evidence. |
| core/{code_health,smells,cyclomatic,safety_needles,tdd_schema,loop_detection,output_verification} | Measure, Prove | Receipt | Attach | working | important | Code-quality and verification diagnostics are quality dimensions for coding Dyno scenarios, not a separate product object. |
| core/{fleet_analytics,cross_customer_learning,learning_sync,stigmergy,community,buddy,godot,gotcha_tracker} | Repeat | ContextSession | Run (local only) | scaffolded | park | Learning/community/fleet concepts are not a v1 local SDK requirement and create OSS/privacy boundary questions. |
| rust/src/dashboard with api, routes/context and routes/graph; tui; visualizer | Measure, Prove | ContextSession | Attach | working | nice-to-have | Useful inspection/demo surface; v1 needs a concise receipt report before a broad dashboard. |
| rust/src/cli/{measure,token-report,stats,gain,spend,savings,learning,finops,roi,output-savings,value-report} and dispatch/analytics | Measure | Receipt | production | working | critical | Existing measurement commands; unify output and machine-readable schema with receipts. |

## E. Prove — benchmark, verification, receipts and evidence

| Component(s) | Strategy concept | Product object | Depth | Status | v1.0 | Mapping |
|---|---|---|---|---|---|---|
| protocol execution.rs and savings.rs | Prove | Receipt | Embed | working | critical | Actual V1 ExecutionReceipt and SavingsReceipt contracts with serialization tests; make them the sole canonical records. |
| protocol knowledge_routing.rs and auto_routing.rs | Prove, Tune | Bundle | Embed | working | important | ContextBundle/ContextReceipt and routing receipt contracts; align names/semantics with strategy object model. |
| core/evidence_flow, evidence_report, evidence_ledger, evidence_classification, evidence_bundle, evidence, live_evidence_ledger | Prove | Bundle | Embed | working | critical | Evidence assembly exists, including arm-to-ExecutionReceipt conversion, but not one canonical EvidenceBundleV1. |
| core/provenance, evidence/proof modules, signatures/signatures_ts, trust, integrity, compliance, compliance_report | Prove, Deploy | Bundle | Embed | working | critical | Provenance, integrity, signing and compliance are the credible-proof boundary. |
| core/benchmark, benchmark_compare, benchmark_study/{datasets,metrics,stats}, task_benchmark, quality_benchmark, quality_lab | Prove | Receipt | Attach | working | critical | Strong baseline/treatment and quality evaluation substrate; turn into Dyno’s fixed run contract. |
| core/eval_ab with testbench, shadow, benchmark-related CLI scenario commands | Prove, Repeat | Receipt | Wrap | working | critical | A/B and shadow evaluation can run controlled comparisons; lacks product-level scenario manifest and anti-cheating enforcement. |
| core/{conformance,output_verification,output_verification,contracts,claim_extractor,claims/evidence classification} | Prove | Bundle | Embed | working | critical | Conformance and claim governance foundations; add SDK conformance tests named in the strategy. |
| core/{compliance_report,finops_export,settlement_evidence,codesign,security_posture} | Prove, Deploy | Bundle | Embed | working | important | Enterprise-grade/verifiable exports, not the first local proof path. |
| cli/{evidence,evidence-export,prove,proof,verify,snapshot,eval,benchmark,scenario,shadow,audit,compliance,audit_report} | Prove | Bundle | Attach | working | critical | User-facing proof command set; consolidate into a one-command Dyno local result plus offline verify. |
| scripts/{benchmark*,verify*,delivery*,evidence*}, bench, benchmark, benchmarks | Prove | Receipt | Run (local only) | working | important | Test/automation evidence infrastructure; define deterministic input/output fixtures as Dyno scenarios. |
| public-build-policy-v1.json, delivery trust/manifest assets and test fixtures | Prove, Deploy | Bundle | Embed | working | important | Release/provenance governance; reuse patterns for bundle verification. |

## F. Deploy and Repeat — profiles, kits, session lifecycle and operations

| Component(s) | Strategy concept | Product object | Depth | Status | v1.0 | Mapping |
|---|---|---|---|---|---|---|
| core/profiles and profile_suggest; CLI profile command | Tune, Deploy, Repeat | TuningProfile | Attach | working | critical | Implements Profile with read, compression, translation, layout, routing, budget, pipeline and autonomy configuration; needs renamed/versioned TuningProfile public contract and lifecycle. |
| rust/src/kits, cli kit/kits and pack_cmd | Deploy | Kit | Attach | working | critical | Implements ContextKit, metadata, read/shell/quality plans and system prompts; needs canonical kit manifest, signature and profile compatibility. |
| core/skillify, rules_canonical/channel/sections/validation/artifacts/scorer/discovery, instruction_compiler, instructions | Deploy, Repeat | Kit | Attach | working | important | Converts policies/instructions into reusable operational material; a likely ContextKit compiler input. |
| core/session with types/playbook, session_summary, session_diff, session_token, ccp_session_bundle, handoff_ledger, handoff_transfer_bundle | Connect, Repeat | ContextSession | Attach | working | critical | Persists task, finding, decision, file and evidence state; needs canonical ContextSession API, durable IDs and receipt linkage. |
| core/{memory_archive,episodic_memory,procedural_memory,memory_scheduler,memory_lifecycle,memory_policy,memory_guard,memory_consolidation,memory_capacity,memory_salience,memory_boundary,memory_branch,multiscale_index} | Repeat | ContextSession | Embed | working | important | Memory/reuse machinery; scope to safe local session/project retention for v1. |
| core/{archive,archive_fts,artifact_index,artifacts,storage_maintenance,atomic_fs,eviction_orchestrator,data_dir,cloud_files} | Repeat, Deploy | ContextSession | Embed | working | important | Storage and artifact lifecycle; ensure reproducible bundle/profile retrieval. |
| core/{ocla,ocla_bus,ocla/adapters,ocla/builtin,ocla/reference_adapters}, events, event bus consumers | Repeat | ContextSession | Embed | working | important | Evented lifecycle and accounting integration; choose it or protocol events as the single public lifecycle feed. |
| core/{multi_repo,work_graph,conversation,shared_context,context_snapshot,edit_snapshot,read_provenance,delivered_ranges} | Repeat | ContextSession | Embed | working | important | Cross-repo/task state and provenance; should be subordinate to a stable ContextSession identity. |
| core/{packaging-related index_bundle,context_package,portable_binary,updater,version_check,update_scheduler} | Deploy | Kit | Attach | working | important | Distribution/update mechanisms; versioned Kit/Profile compatibility is the missing product seam. |
| core/{roles,persona,autonomy,autonomy_drivers,pro_triggers,solution_auto_capture,solution_commercial,solution_rules,solution_tracker,solution_types} | Repeat | TuningProfile | Embed | scaffolded | park | Product/automation experiments; do not let them define v1 before explicit AutoTune requirements exist. |
| cloud_client, cloud_sync, CLI cloud, CLI enterprise, CLI team | Deploy, Repeat | Bundle | Run (local only) | scaffolded | park | Cloud/enterprise seam exists but strategy assigns cloud/enterprise ownership outside this repo; retain contract only. |
| rust/src/dashboard, web app, theme, TUI, completions | Deploy, Measure | LeanCTX | Attach | working | nice-to-have | Experience layer; valuable after the command/API loop is coherent. |

## Explicitly missing for strategy fulfilment

### P0: the one SDK lifecycle

1. **Canonical public LeanCTX API.** The Rust SDK is an embedder facade, but
   there is no strategy-shaped API that creates a session, attaches/wraps an
   integration, applies a profile, executes, returns receipts, then deploys.
   Implement this above the existing engine/protocol modules with bindings or
   clients following it.

2. **Canonical ContextSessionV1.** core/session has SessionState and related
   stores, while context_kernel has separate usage/context state. Define a
   stable ID, identity/integration, task, context-plan, profile, execution,
   outcome and evidence references. Make MCP, proxy, SDK and CLI carry it.

3. **Canonical TuningProfileV1 lifecycle.** Existing Profile is capable
   configuration, not yet a strategy object. Add a versioned schema, immutable
   content digest, creation/baseline lineage, compatibility/conformance fields,
   evaluate/promote/deprecate states, and deploy/apply semantics.

4. **Profile deployment.** There is config, rules, hooks, wrappers and Kits,
   but no single deploy operation proving which profile was applied to which
   target integration. Required output: installation result plus profile digest
   in the ContextSession and ExecutionReceipt.

5. **Receipt composition and contract ownership.** ExecutionReceiptV1 and
   SavingsReceiptV1 already exist in lean-ctx-protocol; promote them over
   parallel ledger/report structures. Add the strategy-required fields,
   unambiguous cost basis (provider-reported/calculated/reconciled), quality
   evaluation reference, baseline/treatment identity, and signature status.

6. **EvidenceBundleV1.** Existing ContextBundleV1 and core evidence_bundle are
   different concepts. Define one signed, content-addressed bundle that contains
   scenario/commit/integration/profile references, baseline and treatment
   receipts, quality result, methodology, artifacts and verification manifest.
   Make leanctx-verify the offline verifier.

### P0: Dyno local

7. **Dyno scenario/run contract.** No Dyno module exists. Build a local
   deterministic runner over existing benchmark, eval_ab, shadow, quality_lab
   and evidence_flow. It needs a scenario manifest, fixed baseline/treatment
   construction, real provider usage capture, normalized costs, quality gate,
   anti-cheating checks, receipt generation and bundle export.

8. **Proof gate.** Add an enforceable gate: no customer-facing savings claim
   without a declared comparable baseline, matched task/scenario, quality
   threshold, cost-basis disclosure and independently verifiable bundle.

9. **SDK/integration conformance suite.** The strategy calls for local SDK,
   Profile, Kit, Evidence and Entitlement cross-repo tests. This repo needs
   v1 tests now for Attach, Wrap and Embed that prove each emits the same
   session/receipt/profile semantics.

### P1: Kit and product coherence

10. **ContextKitV1 contract.** ContextKit exists, but needs its v1 manifest:
    identity/version/digest/signature, target capabilities, compatible profile
    range, included rules/prompts/read/shell/quality plans, deterministic
    installation and rollback.

11. **Reference custom agent.** The strategy’s Phase 2 agent is absent. Build
    the smallest coding agent that uses the SDK directly, runs a ContextSession,
    accepts/deploys a Profile and emits evidence. It is both Embed proof and
    product documentation.

12. **Integration registry and activation report.** Current hooks/wrappers/
    setup are broad but implicit. Ship a supported-agent registry with
    integration depth, capabilities, installed version, profile assignment,
    health and last receipt. This is the concrete Connect UX.

13. **Product-level object serialization/API parity.** Python, Node, Rust
    clients and MCP must expose the same object schema. Current SDK/client
    surfaces focus on engine operations rather than the six product objects.

### Deliberately later, not blockers for v1.0

14. **AutoTune.** Adaptive/bandit/threshold code is useful substrate, but the
    missing product requires an optimization objective, experiment scheduler,
    search space, safety/quality constraints, promotion approval and profile
    registry. Do not label existing heuristics AutoTune.

15. **Managed Run, hosted Dyno, cloud control plane, team/entitlements and
    marketplace.** Local daemons and cloud/enterprise seams are not a managed
    runtime. Strategy places those capabilities behind later gates and, in part,
    in other repositories.

16. **Fleet/cross-customer learning.** Technically adjacent modules exist but
    need an explicit privacy, data-rights and commercial boundary before they
    become a product loop.

## Recommended v1.0 convergence sequence

1. Freeze protocol names: ContextSessionV1, TuningProfileV1, ContextKitV1,
   ExecutionReceiptV1, SavingsReceiptV1 and EvidenceBundleV1.
2. Build the SDK facade and one local ContextSession lifecycle on top of the
   existing engine, profiles, kits and protocol receipts.
3. Make current Codex/MCP Attach and proxy Wrap integrations emit the same
   receipt semantics; add a minimal Embed reference agent.
4. Implement Dyno local and the proof gate using existing benchmark/eval/
   evidence modules rather than a parallel measurement stack.
5. Ship profile deployment and Kit binding, then prove end-to-end:
   install -> tune -> measure -> verify -> deploy a versioned profile.
6. Keep AutoTune, managed Run and cloud/team machinery behind the evidence and
   SDK gates.

## Evidence used for the mapping

- SDK strategy: docs/internal/vision/SDK-STRATEGY-ALL-IN-ONE.md, read before
  the codebase map as requested.
- Codebase inventory: docs/internal/analysis/A1-codebase-map.md.
- Code confirmation: core/mod.rs; core/profiles/types.rs; kits/mod.rs;
  core/session/types.rs; core/context_kernel; evidence_flow/evidence_bundle/
  evidence_ledger; benchmark/eval/shadow modules; proxy/hooks/server/tool
  surfaces; and protocol execution.rs, savings.rs and knowledge_routing.rs.
- Notable direct confirmations: ContextKit is a concrete Rust struct; Profile
  is a concrete configuration model; SessionState preserves task, decision,
  file and evidence state; evidence_flow converts an experiment arm to
  ExecutionReceiptV1; the protocol defines both execution and savings receipt
  V1 types; no Dyno or AutoTune source module was found.
