# H20 — Final holistic synthesis working notes

## Source status

This synthesis was finalized after the requested wait plus a short final collection window.

- Read and incorporated: H1–H8, H10, H12–H19.
- Not present at finalization: H9, H11.
- The missing reports are an input gap. No claim, requirement, or decision has been inferred from them.

## Synthesis spine

LeanCTX is the local-first Context SDK for AI Agents. It improves the pre-inference context of an existing agent; it does not replace the agent, provider, host, or evaluation stack. The product loop is:

Connect → Measure → Tune → Prove → Deploy → Repeat

The next 90-day objective is not a platform launch. It is one paid, repeatable Tuning Sprint proving a quality-gated, workload-specific reduction in Verified Cost per Successful Agent Task (VCP-SAT). The fastest credible proof is one existing Python/OpenAI Agents SDK code-review agent, one pinned fixture, one code-review Kit, one stock/treatment comparison, and one locally signed offline-verifiable evidence bundle.

## Decisions used to resolve reports

1. Authority: H1 supplies the product direction; implementation proposals must conform to its frozen decisions and the anti-roadmap in H8.
2. Evidence layering: Preserve shipped ExecutionReceiptV1 compatibility. Add versioned Session and Dyno receipts as companions; use one logical EvidenceBundle contract and document any underlying archive-format migration explicitly.
3. Integration terms: Attach, Wrap, Embed, Run later are the only public taxonomy. CLI command names must not redefine these concepts.
4. Metric: VCP-SAT is the sole North Star. CPAO may appear only as explanatory prose, never as a competing product metric.
5. Python SDK ownership: packages/python-lean-ctx with import namespace lean_ctx is the sole public Python distribution path; freeze duplicate package work until a tested migration is approved.
6. Profile and Kit: author profiles and Kits in TOML; canonicalize to JSON for digest/signature; distribute sealed artifacts only through .ctxpkg; retain the legacy profile command as compatibility, not as TuningProfileV1.
7. Scope: Build one local POC and one code-review Kit before extra Kits, marketplace, control plane, scheduled AutoTune, dashboards, or hosted service work. A deployable TuningProfile follows demonstrated controls, rather than blocking first proof.
8. Commercial truth: Sell a bounded Tuning Sprint after a qualified scope. Keep monthly prices and platform tiers off the public site until terms and shipped capability are approved.
9. Product truthfulness: Any unreleased LeanCTX.wrap, session, Dyno, profile, or package example is visibly labelled Preview/Target Contract. Current CTAs lead to real supported local integration paths.

## Output set

- FINAL-INDEX.md — reading order, source index, decisions.
- FINAL-CONTRADICTIONS.md — conflicts, resolutions, missing inputs.
- FINAL-NEXT-STEPS.md — ten concrete actions for this week.
- FINAL-ONE-PAGER.md — German external briefing.

## Reality check

The reports describe strong implementation substrate, but not a completed customer-proof product. The most unrealistic path is attempting to ship the evidence platform, four-Kit ecosystem, marketplace, Thinkery control plane, broad website promise, and paid pilot simultaneously. The credible path is one thin proof loop, one paid customer workflow, then repeatability.
