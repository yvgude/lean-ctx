# H3 — Dyno and AutoTune Technical Architecture

## 1. Executive design

LeanCTX Dyno is the local, controlled execution system that runs a fixed workload
against a baseline and one or more context strategies, measures the complete agent
run, enforces quality gates, and emits signed evidence. It is not a faster version
of the current token-comparison commands: it is the canonical producer of
reproducible experiment facts.

Evidence is the signed, offline-verifiable record produced from a Dyno run.
AutoTune is the policy-constrained optimizer that consumes verified Dyno evidence,
searches valid TuningProfile candidates, and recommends an immutable profile version.

The architectural rule is:

```text
Dyno produces facts -> Evidence makes facts portable -> AutoTune consumes facts
```

Neither reports nor dashboards calculate a competing truth. They only render the
run plan, arm receipts, scorecards, comparison receipts, and signed bundle.

## 2. Product boundaries

### 2.1 Dyno

Dyno owns controlled comparison of an agent workload.

- It freezes a workload, source revision, adapter, provider settings, controls, and evaluator.
- It runs a named baseline plus one or more candidate arms.
- It captures provider usage, calculated cost, latency, context behavior, tool trace,
  retries, recovery, task outcome, and quality evaluation.
- It makes a cost/savings claim eligible only after the candidate passes quality,
  policy, and evidence-completeness gates.
- It creates a self-verifying evidence bundle suitable for local use or hosted ingestion.

### 2.2 Evidence

Evidence owns integrity and attribution, not experiment orchestration.

- Every claim is linked to the locked Dyno run plan and immutable arm artifacts.
- The bundle signs canonical bytes, hashes every included file, and is verifiable offline.
- Provider-reported usage, calculated cost, and reconciled invoice cost remain distinct.
- A report may include failed, retried, cached, synthetic, replayed, or partial arms,
  but must label them; only eligible live comparisons are promotional evidence.

### 2.3 AutoTune

AutoTune owns candidate search and profile recommendation.

- It never invents an improvement from telemetry alone.
- It asks Dyno to evaluate every candidate whose result may affect promotion.
- It optimizes a workload-specific objective under hard quality, policy, and evidence gates.
- It produces a recommendation and a signed decision receipt; it does not silently
  overwrite an active profile.

## 3. Canonical terminology

| Term | Meaning |
| --- | --- |
| Workload | A versioned task suite plus its source fixture, task inputs, adapter contract, and evaluator. |
| Run plan | The fully resolved and locked form of a Dyno spec before execution. |
| Arm | One controlled execution condition, such as stock, attach, native, or a profile candidate. |
| Trial | One isolated execution of one task in one arm; trials are paired across arms. |
| Baseline | The declared control against which an eligible candidate is compared. |
| Context envelope | The exact runtime-produced context sent or exposed to the agent, with digest and source provenance. |
| Quality contract | Required evaluator(s), threshold, tolerance, and evidence required for a workload. |
| TuningProfile | A versioned, immutable strategy configuration compiled into the existing runtime profile settings. |
| Eligible comparison | A comparison whose controls, quality, policy, evidence, and sample requirements all pass. |

## 4. Dyno operating model

### 4.1 Workload contract

A Dyno workload is not a prose prompt. It is a content-addressed fixture with:

- `workload_id` and semantic version;
- task IDs and task input hashes;
- a source revision (`git_commit`, dirty-tree prohibition, submodule digests, fixture digest);
- an agent adapter identifier, version, image/binary digest, and JSON protocol version;
- provider/model request settings, including temperature, seed when supported, and output cap;
- an allowlisted environment and tool/network policy;
- a quality contract and evaluator version/digest;
- fixture setup/teardown and allowed test commands;
- an explicit data classification and redaction policy.

The locked workload contains a source snapshot reference, not an ambient working tree.
For local Git work, Dyno creates a detached worktree at the declared commit. For a
hosted execution it uses a pinned image plus source archive. Each arm gets a fresh
copy so changes, caches, untracked files, and agent memory cannot leak between arms.

### 4.2 Arm model

The minimum arm set is:

- `stock`: the declared agent without LeanCTX context assistance;
- `attach`: the same agent supplied materialized LeanCTX context but without native runtime tool use;
- `native`: the same agent using LeanCTX through the chosen native adapter/MCP integration;
- `profile:<name>@<version>`: an explicit candidate TuningProfile.

`stock`, `attach`, and `native` are strategy labels, not vague marketing labels. The
resolved plan records the adapter settings, profile lock digest, enabled tools, prompt
framing, and context source policy for every arm. Any uncontrolled difference makes
the comparison invalid instead of merely adding a warning.

### 4.3 Trial scheduling and fairness

For every task/trial pair Dyno executes all arms under identical controls:

- same task input and source revision;
- same agent adapter build and system prompt;
- same provider/model unless model is explicitly declared as a candidate variable;
- same output cap, timeout, retry policy, and cost ceiling;
- same allowed tools, network policy, environment image, and quality evaluator;
- fresh isolated workspace and reset state for each arm;
- same cache policy, with warm-cache state either disabled or warmed symmetrically;
- randomized, counterbalanced arm order (`ABBA`/Latin order) recorded per trial.

Provider cache effects are measured, not hidden. The run plan declares `cache_policy` as
`disabled`, `cold`, or `symmetric_warm`; the receipt records cache hits and cache-read
pricing. A later arm cannot claim an advantage caused by an unreported warmer provider
prefix cache.

For stochastic providers Dyno uses a configured number of paired repeats. A seed is
pinned where the provider supports it; otherwise the receipt records that it is
unsupported. The report shows per-task values, all failures, retries, and confidence
intervals rather than smoothing an aggregate.

### 4.4 Anti-cheating enforcement

Dyno validates before execution and again before signing:

- reject a run plan with different commits, model settings, timeouts, or task hashes
  across matched arms unless the field is declared a deliberate variable;
- reject a dirty or unpinned source fixture;
- hash every context source, kit, prompt template, adapter build, evaluator, and
  environment image;
- preserve an append-only execution trace of context preparation, tool calls, retries,
  recovery, and evaluator invocation;
- forbid access to files outside the fixture and deny undeclared network endpoints;
- label replay, synthetic, estimated, unavailable, partial, and failed measurements;
- include failed arms and exhausted retries in results and denominators;
- prevent an eligible savings claim if any required quality/policy/evidence gate fails;
- redact secrets before persistence while preserving stable content digests and redaction events;
- require an explicit baseline; never select the weakest arm after seeing results.

Dyno cannot prove that a workload is representative by itself. The workload manifest must
declare sampling rationale and task strata; hosted AutoTune additionally requires holdout
tasks that candidate generation cannot inspect.

## 5. CLI design

The root command is `lean-ctx dyno`; `evidence` remains a verifier/export surface during
migration, not the primary experiment runner.

```bash
# Create a checked-in workload/run-spec skeleton.
lean-ctx dyno init --kind coding --output .lean-ctx/dyno/payment-review.yaml

# Validate without issuing provider calls.
lean-ctx dyno validate --spec .lean-ctx/dyno/payment-review.yaml

# Resolve and execute the controlled matrix.
lean-ctx dyno run --spec .lean-ctx/dyno/payment-review.yaml \
  --output .lean-ctx/dyno/runs/dyno_01J... --sign

# Compare one candidate to the plan-declared baseline and emit stable JSON.
lean-ctx dyno compare .lean-ctx/dyno/runs/dyno_01J... \
  --baseline stock --candidate native --format json

# Render Markdown, HTML, or JSON without recalculating the measurements.
lean-ctx dyno report .lean-ctx/dyno/runs/dyno_01J... --format markdown

# Recheck the signed immutable bundle offline.
lean-ctx verify .lean-ctx/dyno/runs/dyno_01J.../evidence-bundle.zip

# Local/manual tuning only: generate a bounded profile matrix and submit it to Dyno.
lean-ctx dyno profile experiment --spec review.yaml --base review \
  --set budget.max_context_tokens=60000,90000 \
  --set compression.output_density=terse,normal
```

`dyno run --json` emits a stable run result handle and artifact paths. Human terminal
output is a view and must never be parsed as the API. `dyno compare` exits non-zero for
an invalid comparison and exits zero with `eligible=false` for a faithfully recorded but
quality-ineligible candidate, so automation can distinguish infrastructure failure from a
negative result.

### 5.1 Dyno spec

```yaml
api_version: leanctx/v1
kind: DynoRun
metadata:
  name: payment-review-native-vs-stock
workload:
  id: payment-review
  version: 1.0.0
  source:
    git_commit: 4f9d2c1
    require_clean_tree: true
  tasks: .lean-ctx/dyno/payment-review.tasks.ndjson
agent:
  adapter: leanctx-agent-json@1
  image_digest: sha256:...
provider:
  name: openai
  model: gpt-5.4
  temperature: 0
  seed: 421
controls:
  timeout_secs: 300
  max_cost_usd: 10
  retries: 1
  cache_policy: symmetric_warm
  repeats: 3
arms:
  - id: stock
    strategy: stock
  - id: native-review
    strategy: native
    profile: review@1.0.0
quality:
  contract: coding-oracle@1
  threshold: 0.92
  noninferiority_margin: 0.02
  required_policy: baseline
evidence:
  methodology_version: dyno-method-v1
  signing: required
```

The submitted file is user intent. `dyno run` writes `run-plan.json`, which resolves all
defaults, profile inheritance, task order, exact tool allowlist, pricing-table digest,
environment digests, and candidate hashes. Only the run plan is evidence-grade input.

## 6. API design

### 6.1 Rust core boundary

Add a `core::dyno` facade independent of Clap and hosted transport:

```rust
pub struct DynoRunSpecV1 { /* user-declared intent */ }
pub struct DynoRunPlanV1 { /* canonical, resolved, hashable control plane */ }
pub struct DynoRunResultV1 { /* all arms, trials, comparison and artifact refs */ }

pub trait AgentAdapter: Send + Sync {
    fn descriptor(&self) -> AdapterDescriptor;
    async fn execute(&self, request: DynoInvocation) -> Result<AgentExecution>;
}

pub trait QualityEvaluator: Send + Sync {
    fn descriptor(&self) -> EvaluatorDescriptor;
    async fn evaluate(&self, input: EvaluationInput) -> Result<QualityScorecard>;
}

pub trait DynoArtifactStore: Send + Sync {
    fn persist(&self, artifact: DynoArtifact) -> Result<ArtifactRef>;
}

pub fn resolve(spec: DynoRunSpecV1, resolver: &DynoResolver) -> Result<DynoRunPlanV1>;
pub async fn run(plan: DynoRunPlanV1, services: DynoServices) -> Result<DynoRunResultV1>;
pub fn compare(run: &DynoRunResultV1, request: CompareRequest) -> Result<ComparisonReceiptV1>;
pub fn bundle(run: &DynoRunResultV1, signer: &AgentIdentity) -> Result<EvidenceBundleRef>;
```

`DynoInvocation` carries the canonical task, ContextEnvelope reference, isolated workspace
reference, declared tool policy, provider request settings, and trace correlation IDs.
`AgentExecution` returns structured events and result fields, not a scraped terminal log.

The first adapter is an out-of-process JSON-lines adapter. Dyno writes one invocation JSON to
stdin and expects one schema-validated result JSON plus event stream on stdout. This permits
Python, TypeScript, Codex, Cursor, and custom agents without embedding them in Rust. A native
LeanCTX adapter uses the same contract and obtains context through the Runtime.

### 6.2 Runtime and SDK API

The Runtime exposes Dyno through the local daemon/SDK, not as an unrestricted MCP mutation:

```python
run = ctx.dyno.run(DynoRunSpec.load("payment-review.yaml"))
assert run.comparisons["native-review"].eligible
ctx.dyno.report(run.id, format="markdown")

candidate = ctx.autotune.recommend(workload="payment-review", base_profile="review@1.0.0")
ctx.profiles.promote(candidate.profile_ref, environment="staging", approval=approval)
```

The public local API supports run/compare/report/profile experiment and local artifact storage.
Hosted APIs add authenticated history, scheduling, private fixtures/registries, large parallel
matrices, recommendation queues, and organization policy. SDK objects reference immutable
artifact IDs and content digests rather than returning raw private source by default.

### 6.3 Event stream

Every trial emits a correlated event sequence:

```text
RunPlanned -> TrialStarted -> ContextEnvelopeReady -> AgentToolEvent*
-> ProviderCallObserved* -> AgentCompleted -> QualityEvaluated
-> ArmFinalized -> ComparisonFinalized -> BundleSigned -> BundleVerified
```

Events are appended locally before aggregation. A crash leaves an explicit aborted state;
resumption creates a new attempt linked to the same plan, never overwrites the prior attempt.

## 7. Receipt and bundle architecture

### 7.1 Persisted run layout

```text
.lean-ctx/dyno/runs/<run-id>/
  run-plan.json
  workload.lock.json
  environment.lock.json
  arms/<arm-id>/profile.lock.toml
  arms/<arm-id>/trials/<task-id>/<attempt>/context-envelope.json
  arms/<arm-id>/trials/<task-id>/<attempt>/execution-receipt.json
  arms/<arm-id>/trials/<task-id>/<attempt>/quality-scorecard.json
  arms/<arm-id>/trials/<task-id>/<attempt>/trace.ndjson
  comparisons/<baseline>__<candidate>.json
  reports/summary.json
  evidence-bundle.zip
```

Raw prompt/context/response bodies are opt-in encrypted or redacted local artifacts. Their
digests, sizes, redaction manifest, and provenance remain in the signed bundle so an auditor can
verify the measurement without automatically receiving source code or secrets.

### 7.2 Receipt versions

Keep `ExecutionReceiptV1` valid and immutable. It is too narrow for Dyno because it has a
single call shape and no profile, kit, trial, evaluator, or environment fields. Introduce
versioned companion contracts rather than adding ambiguous optional fields to V1:

- `DynoRunPlanV1`: canonical controls and declared variables;
- `DynoArmExecutionReceiptV1`: one trial/attempt, provider usage, local context measurements,
  retries, tool/recovery counts, outcome, profile/kit locks, and trace/context digests;
- `DynoQualityReceiptV1`: evaluator descriptor, scorecard, raw-result digest, policy verdict,
  and confidence;
- `DynoComparisonReceiptV1`: paired statistics, cost/latency/quality deltas, CI method,
  failures, eligibility, and links to all arm receipts;
- `AutoTuneDecisionReceiptV1`: search configuration, candidate profile digest, objective,
  gate results, holdout result, recommendation ranking, approval, and promotion reference.

For interoperability, a Dyno arm can additionally project to the existing protocol
`ExecutionReceiptV1` and a two-arm eligible comparison can additionally project to
`SavingsReceiptV1`. The new receipts remain the canonical source when there are multiple calls,
tasks, arms, or profile candidates.

### 7.3 Evidence bundle

Use the existing deterministic `generate_artifact_bundle` path as the archive primitive:

- sorted entries, stored ZIP compression, and ZIP-epoch timestamps;
- canonical JSON and SHA-256 of every artifact;
- Ed25519 manifest signature and embedded public key;
- `lean-ctx verify` self-check before reporting success.

The Dyno manifest adds `methodology_version`, run-plan digest, workload/source/environment
digests, redaction state, measurement provenance, and a list of comparison eligibility verdicts.
The verifier gains schema validation for Dyno artifact types and must reject a bundle whose
declared baseline, source, model controls, or receipt linkage is inconsistent.

### 7.4 Measurement semantics

Each receipt has three separately named economic fields:

- `provider_reported_usage`: response usage/cached usage exactly as observed;
- `calculated_provider_cost`: usage multiplied by a content-addressed pricing table version;
- `reconciled_invoice_cost`: optional later billing reconciliation with evidence reference.

Local token estimates are useful diagnostics but never replace provider-reported values in an
eligible provider-cost claim. If usage is absent, the comparison is labelled `estimated` and can
be used for engineering diagnostics but not presented as observed provider savings.

## 8. Quality model

Quality is a workload plug-in, never a universal keyword-overlap heuristic.

```text
eligible(candidate) =
  controls_pass
  AND evidence_complete
  AND policy_pass
  AND task_completion_pass
  AND quality_lower_bound >= threshold
  AND quality_delta_lower_bound >= -noninferiority_margin
```

Coding workloads may combine build/test oracle, patch validity, static policy checks, review
score, and human acceptance. Research workloads may combine factual/citation evaluators;
support workloads resolution/acceptance; regulated workloads required human approval and evidence
completeness. The `QualityScorecard` dimensions already provide a useful common presentation,
but each evaluator must produce its own versioned raw evidence and confidence.

Quality is evaluated on every arm. Dyno reports a cheaper arm that fails quality as a failure,
not as a qualified savings percentage. Reports preserve per-task regressions and failures even
when an aggregate passes.

## 9. Statistical comparison

Dyno aggregates paired trial deltas, never unrelated arm averages.

- Pair by workload task ID, repeat, source revision, and shared control fingerprint.
- Use deterministic bootstrap CIs for reproducible local reporting, building on `eval_ab`.
- Record seed, iterations, estimator, sample count, exclusions, and every exclusion reason.
- Report mean and median cost/latency, p50/p95 latency, pass rate, quality delta, and
  provider cache rate separately.
- Apply a non-inferiority test to quality before cost ranking; use lower confidence bounds for
  automatic promotion eligibility.
- Declare a minimum sample/strata coverage in the workload contract; no empty result may be
  classified as non-inferior or as a win.

The existing `eval_ab` paired report is a direct seed for this component, but Dyno must make the
confidence result sensitive to multi-arm, trial, and task-stratum metadata.

## 10. TuningProfile architecture

### 10.1 Profile representation

The existing `core::profiles::Profile` is a mutable-style runtime preset with inheritance. Keep
it as the execution target, but add a portable `TuningProfileV1` wrapper:

```yaml
api_version: leanctx/v1
kind: TuningProfile
metadata:
  name: payments-review
  version: 1.4.2
  profile_id: tp_...
  parent: review@1.0.0
  immutable_digest: sha256:...
runtime:
  read: { default_mode: map, max_tokens_per_file: 60000, prefer_cache: true }
  compression: { crp_mode: compact, output_density: terse, adaptive: true }
  budget: { max_context_tokens: 64000, max_shell_invocations: 30, max_cost_usd: 2.50 }
  pipeline: { intent: true, relevance: true, compression: true, translation: true }
  routing: { max_model_tier: standard, degrade_under_pressure: true }
  autonomy: { auto_prefetch: true, auto_response: false }
kits: []
quality:
  contracts: [coding-oracle@1]
  gates: [tests-pass, "review-score>=0.92"]
evidence:
  approved_run_plan_digests: [sha256:...]
  status: candidate
```

The resolver compiles `runtime` into the existing `Profile` fields and writes a fully resolved
`profile.lock.toml`. Old `.lean-ctx/profiles/<name>.toml` files remain valid RuntimeProfiles;
they are importable as an unversioned base and cannot be called a promoted TuningProfile until
they have a resolved digest, version, quality contract, and evidence reference.

### 10.2 Profile lifecycle

```text
draft -> candidate -> dyno-validated -> approved -> staging -> production
                  \-> rejected
production -> rolled-back (previous immutable version restored)
```

Promotion changes a small signed pointer/registry record; it never edits the immutable profile
that was benchmarked. Agents resolve a named channel to a concrete profile version and record
that digest in every execution receipt. Pin, compare, export, and rollback work locally;
registry promotion, organization defaults, and retention are hosted/team extensions.

## 11. AutoTune design

### 11.1 Inputs and admissibility

AutoTune accepts only:

- verified Dyno bundles with approved methodology and schema versions;
- their run plans, arm receipts, quality receipts, and comparison receipts;
- configured workload metadata, policy constraints, and candidate-domain definitions;
- optional production receipt aggregates for drift detection, clearly separated from controlled
  Dyno evidence.

It rejects unsigned/invalid bundles, synthetic results, incomplete or ineligible comparisons,
unknown profile/kit digests, source/control mismatches, and data whose retention policy forbids
optimization. Hosted ingestion stores feature summaries by default; private raw artifacts stay
in the customer-selected storage boundary.

### 11.2 Candidate domain

Candidate generation is schema-aware and bounded. Tunable current runtime fields include:

- `budget.max_context_tokens`, per-file read limit, and shell-call limit;
- `read.default_mode` and cache preference;
- CRP/compression mode, density, entropy threshold, terse/adaptive behavior;
- translation and layout choices;
- relevance/intent/compression pipeline switches;
- routing tier and pressure-degradation policy;
- bounded autonomy/prefetch/response-shaping settings;
- allowed Kit set/version, model selection, and retry/fallback policy when explicitly enabled.

The generator validates dependent constraints before a provider call: a disabled pipeline cannot
tune a downstream mode; a policy max model tier constrains model candidates; no candidate may
increase allowed tools or bypass data policy. It materializes a canonical candidate profile lock
and content digest before scheduling Dyno.

### 11.3 Objective and gates

The default objective is multi-objective:

```text
minimize expected_calculated_cost and p95_latency
maximize quality and task_completion
subject to quality/policy/evidence hard gates
```

An organization may supply a normalized scalar ranking after hard gates, for example
`cost + latency_weight * p95_latency`, but AutoTune retains the Pareto frontier and never hides
a more expensive/higher-quality alternative behind a single score. Costs use the pricing table
declared in the run plan; a pricing-only refresh ranks existing evidence but cannot create a new
quality claim.

### 11.4 Search loop

```text
Verified representative workload and base profile
  -> validate candidate space against policy
  -> generate diverse low-risk candidates
  -> Dyno screen on stratified training tasks
  -> eliminate quality/policy failures
  -> allocate repeats to uncertain Pareto candidates
  -> Dyno confirm on untouched holdout tasks
  -> build constrained Pareto frontier
  -> write recommendation + AutoTuneDecisionReceipt
  -> human approval / staged promotion
  -> observe signed production receipts for drift
  -> schedule a new Dyno cycle when drift is significant
```

The local open implementation may expose deterministic grid/random profile experiments with
explicit budgets. Continuous Bayesian/TPE-style search, cross-workload prediction, scheduled
retuning, ranking from organization history, and fleet-scale execution belong to the commercial
service. This implements the strategy boundary: manual tuning remains open; continuous tuning
is commercial.

### 11.5 Safety against optimizer gaming

- Keep a locked holdout set unavailable to candidate generation and screening decisions.
- Require minimum task strata, paired repeats, and lower confidence-bound gates before promotion.
- Penalize failures, retries, recovery dependence, and incomplete evidence; do not drop them.
- Use production evidence only to detect drift or select the next representative workload, not
  as a substitute for controlled before/after evidence.
- Require approval by default and canary rollout with automatic rollback thresholds.
- Treat model/provider changes as a new experiment dimension, never as an invisible profile tweak.
- Re-run current production profile beside a candidate when source, provider, pricing, or workload
  fingerprints have changed; historic wins are not automatically transferable.

## 12. End-to-end data flow

```text
Agent request
  -> Runtime resolves channel to immutable TuningProfile lock
  -> ContextEnvelope + tool/provider events + execution result
  -> per-execution receipt (production observation)

Representative workload + baseline/candidate profile locks
  -> Dyno run plan + isolated paired trials
  -> Arm execution receipts + quality receipts
  -> Comparison receipt (eligible only after all gates)
  -> signed, offline-verifiable EvidenceBundle
  -> AutoTune verified-evidence ingestion
  -> candidate generation and further Dyno evaluations
  -> AutoTuneDecisionReceipt + approved immutable profile version
  -> registry/channel promotion
  -> next agent request resolves the new pinned profile
```

The critical causal path is therefore:

```text
Agent -> Dyno -> Receipt -> AutoTune -> Profile -> Agent
```

The first agent arrow supplies representative workload/production telemetry. The second agent
arrow consumes only an approved, pinned profile. AutoTune has no direct path to mutate live
runtime settings without a promotion record.

## 13. Current evidence system versus Dyno

| Surface | What exists today | Why it is not Dyno | Dyno disposition |
| --- | --- | --- | --- |
| `evidence realworld` | Five sequential direct OpenAI-compatible calls per raw/compressed arm; provider prompt/cache/completion usage and cache-aware cost. | Hard-coded review flow; two arms; no locked workload/agent adapter; no canonical quality gate; result JSON is not signed through `evidence_flow`. | Reuse provider usage parsing and multi-turn accumulation; replace orchestration/artifacts. |
| `evidence workflow` | Three fixed local scenarios, four constructed context turns, optional final LLM response and heuristic overlap quality, projected multi-model cost. | Local token simulation and projections are mixed with real evidence; simple heuristic quality; ZIP uses timestamped manifest and has no verifier-compatible signature. | Retire as evidence producer; retain as a demo/workload fixture only after migration. |
| `evidence run` | CLI subcommand exists. | It prints that provider comparison is unavailable. | Implement as a compatibility forwarder to `dyno run` or remove after deprecation. |
| `provider_run` | Matched direct-provider/proxy request with provider usage, cache parsing, latency, response, commit equality validation, and artifacts. | Single prompt/completion rather than agent workload; two fixed arms; no public CLI wiring. | Make its provider client a Dyno executor/measurement adapter. |
| `evidence_flow` | Canonical receipt projection, Ed25519 signing, deterministic artifact bundle, and offline self-verification. | Accepts only one baseline/treatment `ArmResult`; no production caller beyond tests; V1 lacks Dyno provenance. | Reuse as the signing/bundle seam; add Dyno receipt contracts and multi-arm projection. |
| `quality_scorecard` | Five-dimension scorecards and baseline/treatment tolerance comparison. | Evaluation creation is not plugged into a general workload/evaluator registry. | Reuse as common score view and add evaluator plugins/contracts. |
| `eval_ab` | Deterministic context assembly, paired task scoring, bootstrap CIs, non-regression verdict, signed A/B artifact/testbench. | A fixed raw-vs-LeanCTX evaluation harness, not a general agent adapter/profile matrix; no complete economics receipts. | Reuse paired statistics, replay mechanics, evaluator patterns, and signing tests. |
| `benchmark_study` | Four-arm control/compression/routing study over HumanEval/MBPP, sandbox oracle, cost metrics, bootstrap/non-inferiority publication analysis. | Benchmark-specific runner; arm semantics do not capture resolved profiles/workloads; no signed Dyno bundle or profile lifecycle. | Use as a benchmark workload adapter and analysis reference; do not build another parallel runner. |
| `benchmark` | Compression microbenchmark and shareable report. | Measures pipeline performance, not agent task quality or controlled provider economics. | Keep as a microbenchmark; never market it as Dyno evidence. |
| `evidence-export` | Aggregates assorted local reports, savings, and benchmarks. | A package assembler that can mix unrelated measurements and calculate summary prose. | Keep as a legacy export; Dyno reports must derive from one canonical bundle. |

## 14. Existing assets to reuse

The following source-level assets should be reused rather than rewritten:

- `rust/src/core/evidence_flow.rs`: signature, V1 receipt projection, bundle creation, and
  self-verification seam; it already validates provider/model/commit equality for matched arms.
- `rust/src/core/evidence_bundle.rs` and `rust/src/cli/dispatch/verify.rs`: deterministic archive,
  manifest hashing/signing, path safety, and offline verifier.
- `rust/src/cli/dispatch/analytics/provider_run.rs`: direct/proxy request execution, provider usage
  normalization, cached-token observation, latency capture, and pricing integration.
- `rust/src/core/quality_scorecard.rs`: common scorecard and tolerance comparison representation.
- `rust/src/core/eval_ab/`: deterministic conditions, per-task records, fixed-seed bootstrap,
  non-inferiority verdicts, recorded replay, and signed quality artifact patterns.
- `rust/src/core/benchmark_study/`: multi-arm result shape, sandboxed coding oracle, benchmark
  datasets, cost metrics, and publication-quality analysis.
- `rust/src/core/profiles/` and `rust/src/cli/profile_cmd.rs`: layered TOML loading, inheritance,
  runtime activation, profile comparison, creation, and existing knobs.
- `rust/src/cli/dispatch/evidence_realworld.rs`: multi-turn provider cache accounting and retry
  observations, after refactoring its OpenAI-specific client behind a provider adapter.

## 15. What must be built

### 15.1 Foundation

- `core::dyno` spec parser, canonical resolver, validators, plan hashing, run state machine, and
  isolated-workspace lifecycle.
- `cli/dispatch/dyno.rs` plus `dyno` route in `cli/dispatch/mod.rs`; stable JSON CLI contract.
- Agent adapter protocol, native Runtime adapter, external JSON-lines adapter, and provider
  measurement interface.
- General task/workload fixture format, task strata, source/environment locks, fixture redaction,
  tool/network containment, and cache policy implementation.
- Trial scheduler supporting N arms, paired repeats, counterbalancing, failure retention, resume,
  and cost ceilings.

### 15.2 Evidence convergence

- Versioned Dyno plan/arm/quality/comparison receipt schemas and JSON Schema/contract docs.
- Receipt projection from multi-call agent executions to existing `ExecutionReceiptV1`/
  `SavingsReceiptV1` where possible.
- Bundle manifest additions, Dyno-aware verifier validation, evidence-completeness checks, and
  deterministic report renderers.
- Strict separation of observed usage, calculated pricing, invoice reconciliation, estimated,
  replay, and synthetic results.
- Migration/import adapters for `evidence realworld`, `evidence workflow`, `eval_ab`, and
  `benchmark_study`, with truthful methodology labels.

### 15.3 Quality and statistics

- `QualityContract`/`QualityEvaluator` registry with coding, research, support, and regulated
  interfaces; oracle logs/digests and confidence markers.
- Multi-arm paired statistics, p95 latency, stratified coverage, minimum sample rules, and
  Dyno-specific non-inferiority/eligibility evaluator.
- Replay test harness that validates run-plan determinism without falsely calling replays live.
- Anti-cheating validation tests for mismatched source/model/cache/order, hidden preloaded inputs,
  failed-arm omission, and quality-gate bypass.

### 15.4 Tuning profiles

- `TuningProfileV1`, immutable/profile-lock digest, kit references, quality/evidence metadata,
  validation, import from existing TOML Profile, export, pin, and rollback.
- A local profile registry/channel pointer and Runtime resolver that records exact profile digest
  in context and execution receipts.
- Candidate patch/mutation schema describing which fields AutoTune may vary and their policy bounds.

### 15.5 AutoTune

- Verified-bundle ingestion and feature extractor with workspace isolation/privacy controls.
- Candidate generator, bounded local grid/random experiment runner, Pareto builder, and
  `AutoTuneDecisionReceiptV1`.
- Holdout management, sequential screening/repeat allocation, promotion gate, approval workflow,
  canary/rollback mechanics, and drift detector.
- Hosted scheduler, private fixture/profile registry, organization policy/RBAC, encrypted artifact
  storage, cross-workload ranking, continuous search, and fleet history for the commercial tier.

## 16. Recommended implementation sequence

### Milestone 0 — contracts first

- Publish Dyno spec, TuningProfile, receipt, bundle-manifest, and eligibility contracts.
- Add fixture-only tests proving canonical plan and deterministic archive generation.
- Do not add a CLI that implies `evidence run` is real until it can produce verified artifacts.

### Milestone 1 — local two-arm Dyno

- Implement `dyno validate/run/compare/report` for stock vs one native profile.
- Reuse provider-run transport and `evidence_flow` signing, but capture full plan/context/quality
  sidecars in a Dyno bundle.
- Require an executable coding oracle and show `eligible=false` without quality evidence.

### Milestone 2 — general agent workloads

- Add external adapter protocol, isolated trials, multi-turn event trace, task suites, repeats,
  cache controls, and evaluator registry.
- Move realworld/workflow flows behind the Dyno workload interface or mark them legacy demos.

### Milestone 3 — profiles and experiments

- Add TuningProfile locks and profile candidate matrix commands.
- Convert `eval_ab` and `benchmark_study` into reusable Dyno workload/evaluator adapters instead
  of maintaining separate results formats.

### Milestone 4 — AutoTune recommendation

- Ship local bounded/manual search, Pareto reports, holdout confirmation, and human-approved
  candidate promotion.
- Persist the decision receipt and make profile rollback one pointer change.

### Milestone 5 — hosted continuous intelligence

- Add scheduled runs, larger matrices, private registries, org policy, drift detection,
  recommendation queue, and continuous retuning under the commercial boundary.

## 17. Acceptance criteria

A first production-ready local Dyno is complete when all of the following are true:

- A checked-in spec deterministically resolves to a content-addressed run plan.
- A real stock-vs-native execution uses the same declared task/source/model/controls and fails
  closed if any control drifts.
- Every trial has provider usage provenance, profile/context provenance, execution trace digest,
  quality result, and failure/retry status.
- `dyno compare` reports paired quality/cost/latency results, preserves failures, and makes no
  savings claim without a passing quality contract.
- The generated bundle is deterministic for identical artifacts, signed, and accepted by
  `lean-ctx verify` offline.
- A TuningProfile lock generated from an eligible winner can be pinned, activated, observed in the
  next agent receipt, and rolled back to the previous immutable version.
- AutoTune cannot promote a profile without verified Dyno evidence, holdout quality, policy pass,
  and a recorded approval/promotion decision.

## 18. Key decisions

- Dyno, not legacy `evidence workflow` or `evidence realworld`, becomes the only source of new
  before/after performance evidence.
- Existing signed bundle/verifier and quality/statistics primitives are retained; orchestration
  converges around them rather than creating a third evidence format.
- `ExecutionReceiptV1` remains compatible; new Dyno-specific versioned receipts carry the full
  controlled-run semantics.
- Existing TOML profiles remain runtime configuration; immutable TuningProfiles add provenance,
  quality contracts, kit identity, lifecycle, and evidence links.
- Local Dyno and manual profile experiments are open. Continuous AutoTune, history-driven ranking,
  organization policy, and fleet-scale operations form the commercial layer.

