# H4 — TuningProfile system design

Status: design proposal for `TuningProfileV1`.

Scope: portable, versioned, workload-performance configuration that Dyno can
benchmark and production can deploy without ambiguity.

This design deliberately separates a production TuningProfile from three
existing uses of the word “profile”: legacy context profiles, config overlays,
and MCP tool-visibility profiles.

## 1. Decision summary

1. Author profiles as TOML; canonicalize to JSON for hashing, signing,
   comparison, and wire transport.
2. Define a strict Rust `TuningProfileV1` model that is the only runtime input.
3. Version the profile with immutable SemVer releases plus a content SHA-256.
4. Resolve a profile once at `ContextSession` start, compile it into an
   immutable `RuntimeTuningPlan`, and record that snapshot in every receipt.
5. Keep security, credentials, file access, command permissions, and network
   policy outside profiles; portable performance configuration may not weaken
   host or organization policy.
6. Make a Kit a referenced, pinned workload capability; it is not a profile and
   may not silently rewrite unrelated runtime tuning fields.
7. Make Dyno compare resolved, pinned profile snapshots, never mutable names.
8. Reuse `.ctxpkg` and its signing/integrity model for future registry and paid
   distribution; do not build marketplace services now.

## 2. Product boundary

A TuningProfile answers: “For this agent workload, which context strategy is
approved for production?”

It owns:

- selection defaults and constraints;
- representation/read-mode preferences;
- compression and recovery policy;
- context, shell, and cost budgets;
- pinned Kit bindings and compatibility requirements;
- quality contract references and deployment intent.

It does not own:

- arbitrary raw `Config` fields;
- API keys, provider credentials, or private endpoints;
- shell allowlists, path-jail roots, permissions, or security bypasses;
- model prompts embedded from remote URLs;
- schedules, billing, RBAC, or marketplace access checks;
- a mutable live experiment definition.

That boundary gives profiles portable behavior without creating an importable
privilege-escalation file.

## 3. Canonical schema and format

### 3.1 Authoring format

Use a standalone TOML document named `tuning-profile.toml` during authoring.

Reasons:

- LeanCTX already uses TOML for `config.toml`, legacy context profiles, and
  `kit.toml`.
- It is readable, reviewable, and creates small Git diffs.
- TOML supports comments for human-maintained operational policies.
- It makes local/offline use independent of an API or registry.

TOML is not the identity representation. The loader parses TOML, rejects
unknown core fields, applies imports, materializes defaults, normalizes ordered
collections, serializes the resulting value as RFC 8785 canonical JSON, then
computes `sha256(canonical_json)`. That digest is the immutable content
identity. JSON is the exported API/registry representation.

Do not hash source TOML bytes: whitespace, comments, key order, and equivalent
literal spelling must not create a different deployed artifact.

### 3.2 Root contract

```toml
api_version = "leanctx/v1"
kind = "TuningProfile"

[metadata]
namespace = "acme"
name = "payments-review"
version = "1.4.2"
description = "Approved context policy for payment-change reviews."
labels = ["payments", "review", "production"]

[spec]
inherits = ["leanctx://profiles/balanced@1.1.0"]
persona = "coding"

[spec.compatibility]
runtime = ">=3.10.0 <4.0.0"
agents = ["codex", "claude-code", "cursor"]
providers = ["openai", "anthropic"]
required_capabilities = ["ctx_read", "ctx_search", "ctx_shell"]

[spec.selection]
default_read_mode = "auto"
structure_first = true
search_limit = 12
retrieval_depth = "targeted"
reuse_threshold = 0.85
prefer_cache = true
progressive_disclosure = true

[spec.compression]
strategy = "balanced"
aggressiveness = 0.55
output_density = "terse"
shell_mode = "compressed"
adaptive = true

[spec.recovery]
mode = "enabled"
hint_level = "minimal"
retry_policy = "bounded"
max_recovery_attempts = 2

[spec.budget]
context_tokens = 64000
per_read_tokens = 12000
shell_invocations = 40
provider_cost_usd = 2.50
latency_ms_p95 = 30000

[[spec.kits]]
id = "payments-security"
version = "2.1.0"
digest = "sha256:..."
activation = "required"
mode = "advisory"

[spec.quality]
contract = "payments-review-v2"
gates = ["tests-pass", "review-score>=0.92"]
failure_action = "block_promotion"

[deployment]
channel = "production"
rollout = "manual"
rollback_to = "acme/payments-review@1.4.1#sha256:..."
```

### 3.3 Required versus optional fields

`api_version`, `kind`, `metadata.namespace`, `metadata.name`, and
`metadata.version` are required for every released profile.

`metadata.namespace` is optional only for an unpublished local draft; the
validator assigns the explicit local namespace `local`, never an implicit user
name. A release cannot use `local` in a registry.

`spec` is required. Each sub-section receives safe defaults only where an
omitted value preserves a deterministic runtime decision. No implicit provider
or security change is permitted.

`deployment` is optional for a draft and required for a promoted environment.
Its mutable promotion history is recorded in a registry/control plane, not in a
previously released profile. `rollback_to` is an advisory declared fallback;
the deployment lock remains the authoritative active pointer.

### 3.4 Rust model

```rust
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TuningProfileV1 {
    pub api_version: ApiVersion,
    pub kind: TuningProfileKind,
    pub metadata: TuningProfileMetadata,
    pub spec: TuningProfileSpec,
    #[serde(default)]
    pub deployment: Option<DeploymentIntent>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TuningProfileSpec {
    #[serde(default)]
    pub inherits: Vec<ProfileRef>,
    pub persona: PersonaName,
    pub compatibility: Compatibility,
    pub selection: SelectionPolicy,
    pub compression: CompressionPolicy,
    pub recovery: RecoveryPolicy,
    pub budget: BudgetPolicy,
    #[serde(default)]
    pub kits: Vec<KitBinding>,
    pub quality: QualityContractRef,
}

#[derive(Debug, Clone)]
pub struct ResolvedTuningProfile {
    pub reference: ResolvedProfileRef,
    pub canonical_json: Vec<u8>,
    pub content_digest: Sha256Digest,
    pub profile: TuningProfileV1,
    pub imported_profiles: Vec<ResolvedProfileRef>,
    pub kits: Vec<ResolvedKitBinding>,
}

#[derive(Debug, Clone)]
pub struct RuntimeTuningPlan {
    pub profile: ResolvedProfileRef,
    pub selection: EffectiveSelectionPolicy,
    pub compression: EffectiveCompressionPolicy,
    pub recovery: EffectiveRecoveryPolicy,
    pub budgets: EffectiveBudgetPolicy,
    pub kit_plan: ResolvedKitPlan,
    pub quality: EffectiveQualityContract,
}
```

`TuningProfileV1` is the declared artifact; `ResolvedTuningProfile` is an
auditable immutable resolution; `RuntimeTuningPlan` is the small, validated
structure consumed by runtime hot paths. Do not pass a loose `toml::Table` or
the global `Config` through tool dispatch.

### 3.5 Enumerations and validation

Use Rust enums rather than free-form strings for all LeanCTX-owned policies:

- read modes: current `ctx_read::ReadMode` values plus `auto`;
- selection depth: `metadata`, `structure`, `targeted`, `full`;
- compression strategy: `off`, `lossless`, `balanced`, `aggressive`;
- shell mode: `raw`, `compressed`, `focused`;
- recovery: `disabled`, `enabled`, `required`;
- Kit activation: `disabled`, `optional`, `required`;
- Kit application mode: `advisory`, `enforced`;
- rollout: `manual`, `canary`, `experiment`.

Validation must reject:

- unsupported `api_version` or `kind`;
- non-SemVer release version or invalid namespace/name;
- an import cycle, duplicate import, or import depth over five;
- unpinned Kit version/digest in a release or production deployment;
- a profile requiring a capability absent from its declared agent/runtime;
- non-finite thresholds, negative budgets, or a recovery attempt count above a
  bounded implementation maximum;
- a profile that tries to set credentials, permission, path, shell-allowlist,
  proxy-host, or arbitrary `Config` fields;
- a production profile without a quality contract and at least one gate;
- any unresolved profile or Kit reference after resolution.

Allow vendor extension fields only below `[extensions.<reverse-dns-name>]`.
Extensions do not affect `RuntimeTuningPlan` unless a registered extension
compiler explicitly declares its schema, deterministic canonicalization, and
capability requirement.

## 4. Filesystem and registry storage

### 4.1 Local layout

Use a new path; do not reuse `.lean-ctx/profiles`, which already contains legacy
context profiles.

```text
.lean-ctx/
  tuning-profiles/
    acme/payments-review/1.4.2/tuning-profile.toml
    acme/payments-review/1.4.2/profile.json
  tuning.lock
~/.lean-ctx/
  tuning-profiles/
    local/incident-hotfix/0.1.0/tuning-profile.toml
  tuning.lock                 # optional user default only
```

`profile.json` is a generated canonical export; source TOML remains the local
editing surface. It is regenerated and digest-checked by `profile validate`.

The project `tuning.lock` is committed with code and contains only exact
references and SHA-256 digests. It selects what CI/staging/production resolves:

```toml
format_version = 1

[active]
development = "acme/payments-review@1.4.2#sha256:..."
staging = "acme/payments-review@1.4.2#sha256:..."
production = "acme/payments-review@1.4.2#sha256:..."
```

### 4.2 Reference grammar

Use the stable identity:

```text
<namespace>/<name>@<semver>#sha256:<digest>
```

Examples:

```text
local/incident-hotfix@0.1.0#sha256:8f...
acme/payments-review@1.4.2#sha256:9a...
leanctx/balanced@1.1.0#sha256:4d...
```

A version without digest is allowed only as an interactive discovery request.
Resolution must add the digest before execution. Production, Dyno, receipt
creation, and comparison reject digest-less references.

### 4.3 Immutability and lifecycle

Profile release lifecycle:

```text
draft → validate → benchmarked → approved → promoted → active
                                      │                  │
                                      └──── rollback ────┘
```

- A draft can be overwritten locally.
- Releasing creates an immutable `(namespace, name, version, digest)` record.
- Re-publishing the same name/version with a different digest fails.
- A bad release is deprecated/yanked, never replaced or deleted.
- Rollback changes a lock/promotion pointer to an earlier immutable reference.
- Evidence attaches to the exact digest, never to a mutable name.

Use SemVer for the user-facing release channel:

- patch: compatible numeric/default adjustment;
- minor: additive capability or policy field with stable semantics;
- major: changed semantics, compatibility behavior, or unsafe migration.

The digest remains authoritative. SemVer communicates intent; it cannot prove
the exact bytes deployed.

## 5. Creation paths

### 5.1 Manual creation

Commands:

```bash
lean-ctx tuning-profile init acme/payments-review --from balanced
lean-ctx tuning-profile validate .lean-ctx/tuning-profiles/acme/payments-review/1.4.2
lean-ctx tuning-profile resolve acme/payments-review@1.4.2 --json
lean-ctx tuning-profile release acme/payments-review@1.4.2
```

`init` emits explicit values for every behaviorally material default so a
profile can be reviewed without needing to reconstruct a changing runtime
default. It can leave only descriptive metadata and optional extensions empty.

`validate` performs schema, semantic, compatibility, Kit-pin, and policy-boundary
checks. `resolve` displays declared, inherited, effective, and host-clamped
values separately. `release` writes canonical JSON/digest and refuses a release
without a clean validation result.

### 5.2 Creation from a Kit

Commands:

```bash
lean-ctx tuning-profile init acme/code-review --from-kit code-review@1.0.0
lean-ctx tuning-profile validate acme/code-review@0.1.0
```

The Kit compiler uses the selected Kit as a workload seed:

- creates a pinned `spec.kits` binding;
- maps Kit read modes to a proposed selection default/rule set;
- maps its shell focus to a proposed `focused` shell policy;
- copies Kit quality criteria into a named, editable quality-contract draft;
- never copies the Kit system prompt into unrestricted profile fields;
- never grants Kit-provided permission, network, command, or credential power.

The result is a normal editable draft. The user must assign budgets, agent and
provider compatibility, and quality promotion behavior. A Kit is evidence for a
task shape; it is not evidence that one generic budget is production-safe.

### 5.3 Creation from AutoTune

AutoTune never edits a promoted profile in place.

```text
baseline resolved profile
        ↓
bounded candidate patches
        ↓
Dyno runs against declared workload and quality contract
        ↓
Pareto-ranked candidates
        ↓
human selection
        ↓
new immutable profile release
```

Each candidate has:

- `parent_profile`: exact baseline reference;
- `candidate_patch`: typed changes only within AutoTune’s allowed dimensions;
- `search_space_version` and objective declaration;
- Dyno run references, arm receipts, and quality outputs;
- recommendation rationale and Pareto position;
- human approver and promotion event, stored as provenance rather than mutable
  semantic fields inside the canonical content.

AutoTune may search only explicitly allowed knobs: selection, compression,
recovery, budget, tool output shaping, and approved Kit set. Provider/model
selection, retry/fallback, or policy fields are searchable only when the parent
profile explicitly permits them and compatibility/policy checks pass.

The selected candidate becomes a new SemVer release, usually a patch/minor.
`candidate_patch` is retained in a provenance sidecar or `.ctxpkg` evidence
member; canonical profile semantics describe the resulting behavior, not the
historical optimization narration.

## 6. Runtime application

### 6.1 Resolution precedence

At session creation resolve in this order:

1. explicit SDK/CLI `TuningProfileRef` for this session;
2. `LEAN_CTX_TUNING_PROFILE` exact reference;
3. project `.lean-ctx/tuning.lock` environment selection;
4. user-level default pointer;
5. built-in `leanctx/balanced` profile;
6. host `Config` defaults for settings intentionally outside profile scope.

`LEAN_CTX_PROFILE`, `config_profile`, `[profiles.*]`, and `tool_profile` do
not participate. Those names remain reserved for current mechanisms.

The resolver:

1. obtains the artifact from the local cache or approved registry;
2. verifies package signature/integrity where applicable;
3. checks the exact digest and runtime/agent/capability compatibility;
4. resolves imports and Kit references deterministically;
5. applies enterprise/security clamps;
6. compiles `RuntimeTuningPlan` once;
7. freezes it in `ContextSession`.

If any step fails, fail closed for an explicit or production selection. A local
interactive session without an explicit profile may fall back to the built-in
balanced profile with a prominent diagnostic; it must not silently fall back
from a requested production profile to a different behavior.

### 6.2 Precedence inside a runtime decision

```text
hard runtime / enterprise security policy
        > explicit per-call safety requirement
        > resolved TuningProfile constraint
        > active Kit workflow recommendation
        > global Config default
        > built-in default
```

An explicit `ctx_read(mode="full")` can request more detail only within the
profile’s per-read/context ceilings and host policy. A profile can recommend
`auto`, map, or signatures; it cannot prevent correct recovery when runtime
safety or the caller’s explicit contract requires the complete content.

Kits may influence file-specific read ordering, shell evidence focus, quality
criteria, and system instruction only through a profile binding. A Kit does not
override a profile’s budget, provider, model tier, or recovery limits.

### 6.3 Session and receipt model

Add to `ContextSession`:

```rust
pub struct TuningProfileSnapshot {
    pub reference: ResolvedProfileRef,
    pub content_digest: Sha256Digest,
    pub schema_version: u32,
    pub resolved_at_session_start: bool,
    pub kit_bindings: Vec<ResolvedKitBinding>,
    pub plan_digest: Sha256Digest,
}
```

`ExecutionReceiptV1`, `SavingsReceipt`, and `EvidenceBundle` must include the
snapshot reference, profile digest, plan digest, each Kit version/digest, and
the runtime version. The existing `ContextProofV1` profile `name` plus
`policy_md5` is useful evidence but insufficient: it lacks SemVer identity,
SHA-256 portability, Kit pins, and a frozen resolved plan.

The receipt records the profile snapshot before the first tool/model event. A
later global config edit or registry publication cannot change a live session’s
plan or reinterpret its outcome.

### 6.4 Apply points in LeanCTX

The compiler should feed existing policy seams rather than add a parallel tool
path:

- `auto_mode_resolver`: default read mode and selection constraints;
- `ctx_read` dispatch/render: maximum per-read output, compression strategy,
  recovery behavior, and output hints;
- `ctx_shell`: output shaping, shell invocation budget, and Kit command focus;
- `intent_router`: permitted model tier and pressure behavior;
- `context_gate` and degradation policy: profile ceilings and enforcement mode;
- autonomy/prefetch: the compiled profile’s bounded autonomy flags;
- receipt/evidence writer: frozen profile and Kit snapshot.

The compiler must make these decisions pure functions of the resolved profile,
runtime capability set, declared task, and explicit request. Avoid using live
adaptive stores for a supposedly reproducible plan unless an adaptive policy is
itself declared and its state/version is captured in the receipt.

## 7. Profile and Kit interaction

### 7.1 Distinct responsibilities

| Concern | TuningProfile | ContextKit |
|---|---|---|
| Primary purpose | deployable performance policy | reusable task capability |
| Scope | agent/workload/runtime | workflow/domain |
| Version pin | mandatory for deploy/Dyno | mandatory when bound |
| Owns budget | yes | no |
| Owns read sequence | defaults and constraints | task-specific recommendation |
| Owns shell focus | policy/cost limit | command evidence focus |
| Owns quality | contract reference/gates | workflow criteria input |
| May alter security policy | no | no |

### 7.2 Binding rules

`spec.kits` uses coordinates rather than a bare kit name. A release must have
an exact Kit SemVer and content digest. Runtime validates the Kit before the
profile is eligible.

`activation = "required"` means the profile cannot start without that Kit.
`optional` permits a capability-matched session to omit it and logs that fact in
the receipt. `disabled` is useful only in a derived profile that deliberately
removes an inherited optional Kit.

`mode = "advisory"` is default: Kit read/shell suggestions affect planning but
an explicit request can diverge. `enforced` allows the Kit to demand its
declared workflow sequence only when profile quality/security policy names that
constraint; it still cannot exceed profile/host limits.

### 7.3 Compatibility bridge

Current `kit.toml` V1 has no content digest, compatibility, or profile-default
section. Preserve it as `ContextKitV1` and calculate a canonical digest when it
loads. Add optional fields only in `format_version = 2`:

```toml
[compatibility]
runtime = ">=3.10.0 <4.0.0"
capabilities = ["ctx_read", "ctx_shell"]

[profile_defaults.selection]
default_read_mode = "map"

[profile_defaults.compression]
shell_mode = "focused"
```

The loader must accept V1 unchanged. V1-derived profile drafts use a generated
digest and mark compatibility as inferred; a production release requires the
user to make compatibility explicit or use an upgraded V2 Kit.

## 8. Comparison and diff

Expose three deliberate comparison views:

```bash
lean-ctx tuning-profile diff declared A B
lean-ctx tuning-profile diff resolved A B --agent codex --runtime 3.10.0
lean-ctx tuning-profile diff impact A B --fixtures fixtures/payments-review
```

### 8.1 Declared diff

Compares canonical profile fields after TOML parsing but before imports/defaults.
Use JSON Pointer field paths and structured before/after values. It answers,
“what did the author change?”

### 8.2 Resolved diff

Resolves imports, defaults, Kit pins, and compatibility for an explicit runtime
target. It highlights effective differences grouped by:

- selection/read modes;
- compression/recovery;
- budgets and policy ceilings;
- Kit versions/digests;
- quality gates;
- deployment intent;
- security/enterprise clamps.

It answers, “what will actually change at runtime?” A clamp must appear as
`declared`, `effective`, and `reason`; hiding it would make production behavior
unreviewable.

### 8.3 Impact diff

Runs the two compiled plans against deterministic fixture paths/tasks without
calling a model. It reports mode choice, selected sources, estimated tokens,
Kit rules applied, predicted policy actions, and every budget ceiling crossed.
It answers, “which execution decisions differ for representative inputs?”

All diff formats support stable JSON for CI and a concise human table. Array
semantics are schema-specific: imports/Kits compare as ordered resolution
inputs, labels/gates compare as sets, and rule lists compare by explicit `id`.
Require IDs on V1 rule lists to prevent an insertion from looking like dozens of
unrelated edits.

Do not label a raw diff “better.” Only Dyno with a declared workload and quality
contract can establish a performance claim.

## 9. Dyno and A/B testing

Dyno arms reference immutable resolved profile coordinates:

```yaml
arms:
  - id: stock
    profile: leanctx/balanced@1.1.0#sha256:...
  - id: treatment
    profile: acme/payments-review@1.4.2#sha256:...
```

For each arm Dyno freezes:

- source/workload revision and fixture digest;
- agent adapter/version, provider/model, and permitted variables;
- profile canonical JSON digest and compiled plan digest;
- Kit artifacts/digests;
- cost/pricing table version;
- quality contract/evaluator version;
- retry/cache controls and random seed where relevant.

Profile selection is the intentional variable for a profile A/B test. If model,
agent, provider, Kit, timeout, or source revision differs, Dyno classifies it as
a multi-variable experiment rather than a valid pure profile comparison.

Dyno computes cost, latency, provider usage, quality, completion, and evidence
completeness per arm. It may rank Pareto-optimal profiles but must not promote a
winner automatically. Promotion requires declared quality gates, human approval,
and a lock-file/promotion-pointer update. Rollback is the inverse pointer
change, followed by a receipt linking the rollout to the previous profile.

## 10. Marketplace and paid distribution — later

Marketplace is explicitly deferred by strategy. Build the artifact boundary now,
not discovery, payment, ranking, or hosted execution services.

When demand exists, package a released profile in the existing `.ctxpkg` model:

```text
manifest.json                 # name, version, package kind, integrity, signer
profile/profile.json          # canonical TuningProfileV1
profile/tuning-profile.toml   # readable source, optional
kits/                         # optional pinned Kit artifacts or references
evaluation/                   # allowed Dyno fixture metadata, never secrets
provenance/                   # AutoTune/Dyno evidence references
```

Add `PackageKind::TuningProfile` to the established context-package manifest;
reuse its immutable name/version binding, SHA-256 integrity, Ed25519 signature,
download verification, yanking, and local cache. Do not create a parallel
profile registry or a second signing protocol.

Marketplace rules later:

- registry access/billing decides download entitlement, never runtime behavior;
- client validates signature, digest, schema, compatibility, and policy locally;
- profile bundles cannot contain executable code, secrets, network hooks, or
  permissions; extension modules require separately audited capabilities;
- public listings show methodology and compatible runtime/agent range, not
  universal savings claims;
- private organization profiles/Kits use the same identity model with private
  registry authorization;
- yanking warns/blocks new installs but preserves reproducibility for receipts
  that reference an already downloaded, verified artifact.

## 11. What exists today

Today LeanCTX has a substantial *legacy context profile* implementation, but it
is not the strategy’s deployable `TuningProfileV1` yet.

### 11.1 Existing context profiles

`rust/src/core/profiles/types.rs` defines `Profile` with TOML serde sections:

- `[profile]`: name, description, single-parent inheritance;
- `[read]`: `default_mode`, `max_tokens_per_file`, `prefer_cache`;
- `[compression]`: CRP mode, density, entropy, terse/adaptive behavior;
- `[budget]`: max context tokens, shell calls, and cost;
- pipeline/routing/degradation/autonomy/output-hint policy;
- memory and output-verification overrides.

`rust/src/core/profiles/loading.rs` loads a name with precedence project
`.lean-ctx/profiles/<name>.toml` → user `~/.lean-ctx/profiles/<name>.toml` →
built-in profile. It supports recursive field-level inheritance with maximum
depth five. Active selection is process override → `LEAN_CTX_PROFILE` →
`config.toml` `profile` → built-in `coder`.

`rust/src/core/profiles/builtins.rs` provides `coder`, `exploration`, `bugfix`,
`hotfix`, `ci-debug`, `review`, and `passthrough`. `lean-ctx profile` already
supports list/show/active/create/diff/set/suggest in
`rust/src/cli/profile_cmd.rs`.

These are the strongest direct predecessor for `TuningProfileV1`: they already
cover mode preference, compression policy, and budgets, and their settings are
consulted by the live runtime.

### 11.2 Existing runtime use

The legacy profile is active runtime policy today:

- `core/auto_mode_resolver.rs` reads its default read mode;
- `tools/ctx_read/dispatch.rs` and `core_logic.rs` use profile mode/compression
  to decide whether cache/degradation may force a compact result;
- `server/context_gate.rs` uses degradation enforcement;
- `core/intent_router.rs` uses routing/model-tier policy;
- `core/autonomy.rs` uses autonomy controls;
- `tools/registered/ctx_read.rs`, `ctx_shell.rs`, and read rendering use output
  hints and proactive context behavior;
- `core/context_proof.rs` writes profile name and a serialized-policy MD5.

This is a good migration seam: `RuntimeTuningPlan` can first compile to the
same effective policy interfaces, then progressively retire direct
`profiles::active_profile()` calls.

### 11.3 Existing configuration profiles are different

`rust/src/core/config/model.rs` also contains:

- `profile: Option<String>` — legacy context-profile selector;
- `config_profile: Option<String>` plus `profiles: BTreeMap<String, toml::Table>`
  — a named partial `config.toml` overlay;
- `tool_profile`/`tools_enabled` — MCP tool-surface selection;
- `active_kit: Option<String>` — an active Kit name.

`core/config/loader.rs::parse_config_with_profile` selects one `[profiles.<name>]`
overlay and recursively merges TOML tables. This is a convenient local config
mechanism, not a versioned release artifact: it has no artifact identity, SemVer,
digest, compatibility contract, Kit pin, receipt reference, or rollback model.

`Config` already owns relevant global defaults such as progressive disclosure,
structure-first, compression level/aggressiveness, recovery hints, context
overhead budget, cache/memory settings, and security boundaries. A TuningProfile
must use a curated performance allowlist rather than serialize `Config`.

### 11.4 Existing ContextKit

`rust/src/kits/mod.rs` defines TOML `ContextKit` V1 and loads from project,
user, then built-in catalog. `kits/code-review/kit.toml` is the built-in
example. It has:

- `format_version`, name, description, and version;
- ordered first-match `[read]` rules and staged modes;
- a `git_changed` priority plan;
- compressed shell command focus;
- quality criteria;
- a system-prompt template.

`lean-ctx kit load <name>` in `rust/src/cli/kit_cmd.rs` persists only the Kit
name in `Config.active_kit`; `kits::active()` loads it from `LEAN_CTX_KIT` or
that config field. The current Kit has no content hash, registry coordinate,
compatibility declaration, receipt linkage, `.ctxpkg` package, or profile
binding. It is a valuable capability model, but not yet the evidence object
required by the strategy.

## 12. Migration plan

### Phase A — introduce without behavior change

1. Add `core/tuning_profile/` with schema, canonicalization, validation,
   reference parsing, local store, and deterministic resolver tests.
2. Add built-in `leanctx/balanced@1.0.0` that compiles to current safe defaults.
3. Add `tuning-profile` CLI namespace; leave `profile` unchanged.
4. Add `TuningProfileSnapshot` to new receipt schema fields as optional.
5. Add `profile validate/resolve/diff` fixtures and canonical-hash regression
   tests before enabling runtime selection.

### Phase B — bridge legacy behavior

1. Add a one-way `legacy-profile export` adapter from `core::profiles::Profile`
   to a local `TuningProfileV1` draft.
2. Preserve legacy names as a compatibility selector that resolves to generated
   built-in TuningProfile references, never as mutable aliases in production.
3. Compile V1 plans into current profile-access seams behind a feature gate.
4. Emit both legacy `policy_md5` and V1 identity/digest in proof receipts.
5. Document that `[profiles.*]` stays config-only and is not deployable.

### Phase C — make deployment real

1. Add `tuning.lock`, exact pinning, session freeze, and receipt-required
   production selection.
2. Extend `ExecutionReceiptV1`/`SavingsReceipt`/evidence verifier with full
   profile and Kit snapshots.
3. Add local Dyno profile arms, structural/effective/impact diffs, and rollback
   commands.
4. Require profile compatibility and quality contract before promotion.

### Phase D — AutoTune and registry only after gates

1. Add bounded candidate generation and Dyno/Pareto recommendation.
2. Require human approval and create a new immutable release on acceptance.
3. Package released profiles as signed `.ctxpkg` artifacts.
4. Add private registry, promotion, drift, and marketplace services only after
   repeatable Profile/Kit supply and demand are demonstrated.

## 13. Acceptance criteria

The design is complete enough to implement when all of the following hold:

- a developer can manually create, validate, resolve, pin, apply, export,
  compare, and roll back a local profile offline;
- a Kit-derived profile is explicit about its Kit digest and does not inherit
  security authority from the Kit;
- an AutoTune recommendation becomes a new, reviewable immutable profile only
  after Dyno quality gates and human approval;
- a production session and every receipt identify profile SemVer, SHA-256,
  compiled-plan digest, Kit coordinates, and runtime version;
- the same pinned workload/agent/model/profile produces an equivalent resolved
  plan independent of registry availability or later mutable names;
- Dyno can A/B two profile snapshots while enforcing single-variable controls;
- current legacy profile, config overlay, tool-profile, and Kit behavior remain
  backward compatible during migration;
- no imported profile or package can weaken host security policy or carry a
  secret/executable payload.

## 14. Recommended next implementation slice

Build the narrow vertical slice first:

1. `TuningProfileV1` TOML parser + canonical JSON/SHA-256 resolver.
2. Local filesystem store and exact `TuningProfileRef` parser.
3. `validate`, `resolve`, and resolved diff commands.
4. One `balanced` built-in plus export adapter for existing `review` profile.
5. A `RuntimeTuningPlan` for read mode, compression, recovery, and budgets.
6. Session/ContextProof receipt fields with profile/Kit digests.
7. Local Dyno A/B arm support and rollback through `tuning.lock`.

This reaches the strategy’s Phase 5 exit: a winning Dyno configuration can be
deployed and later reproduced deterministically, without prematurely building a
hosted registry, marketplace, or autonomous rollout system.
