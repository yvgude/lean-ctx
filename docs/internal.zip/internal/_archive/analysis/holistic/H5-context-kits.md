# H5 — Context Kit Ecosystem

## Decision

Context Kits are LeanCTX's reusable workflow recipes.

They are the main adoption and distribution vehicle.

- Developers install a workflow that works immediately.
- Teams commit a workflow policy beside their source.
- Publishers distribute versioned workflows across integrations.
- Thinkery later supplies discovery, trust, and governance.

Keep four objects separate.

- Coding agent: executes work.
- Context Kit: selects and assesses workflow context.
- TuningProfile: supplies performance and governance policy.
- ctxpkg: portable, signed distribution artifact.

A Kit never replaces an agent.

A Kit never independently makes a cost-savings claim.

## Scope

V1.0 delivers local resolution, four built-in Kits, safe composition,
authoring, validation, deterministic packing, and project lockfiles.

V1.0 excludes remote code execution, dynamic permissions, a social
marketplace, hidden telemetry, and a generic agent builder.

The first promise is:

> Select a workflow, get a bounded context plan, and finish against a
> repeatable definition of done.

## Current implementation map

### kits today

- The repository has one checked-in Kit: kits/code-review/kit.toml.
- It uses format_version = 1.
- [kit] supplies name, description, and version.
- [read] supplies default modes and ordered glob rules.
- Default read modes are map plus signatures.
- Test-path rules precede the broad Rust rule.
- Current semantics are first matching rule wins.
- [priority] uses strategy = git_changed.
- [shell] has a compressed default and focused commands.
- [quality] has string criteria.
- [system_prompt] has a template.

This already expresses the five strategic Kit parts:

- File patterns.
- Read modes.
- Shell commands.
- Prompt templates.
- Quality criteria.

### rust/src/kits/mod.rs today

The Kit implementation is one focused module of about 414 lines.

- ContextKit holds format_version, metadata, read, priority, shell,
  quality, and system-prompt plans.
- KitMetadata holds name, description, and version.
- ReadPlan holds default modes and ordered ReadRule entries.
- ReadRule holds a glob and modes.
- PriorityPlan holds a strategy and description.
- ShellPlan holds a default mode and ShellCommand entries.
- ShellCommand holds a command and focus fields.
- QualityPlan holds criteria.
- SystemPrompt holds a template.
- LoadedKit joins a parsed Kit with its KitSource.
- modes_for_path applies the ordered read rules.
- preferred_mode_for_path selects the preferred mode.
- Validation rejects unknown read modes and unsafe Kit names.
- Glob matching honours path segments.
- Tests cover code-review read plan, unknown modes, glob paths, and names.

Current operations include load, active, active_mode_for_path, and list.

### Resolution today

Current loader precedence is already:

1. Project Kit.
2. User Kit.
3. Built-in Kit.

Project roots include .lean-ctx/kits while walking from the working directory
toward ancestors.

User Kits live below LeanCTX's user data directory.

The current built-in is embedded from the checked-in code-review Kit with
include_str.

The active Kit comes first from LEAN_CTX_KIT.

Persisted Config.active_kit is its fallback.

### CLI today

rust/src/cli/kit_cmd.rs supports:

- lean-ctx kit list
- lean-ctx kit load NAME
- lean-ctx kit show NAME
- lean-ctx kit unload

Loading persists the active Kit.

Showing prints source, read rules, quality criteria, and prompt.

Create, lint, test, pack, publish, add, and update are not implemented.

### context_package today

rust/src/core/context_package is a capable distribution substrate.

It is not the present Kit loader.

| Module | Existing capability | Kit ecosystem use |
| --- | --- | --- |
| manifest.rs | V1/V2 manifests, dependencies, integrity, kinds, layers | Package contract |
| content.rs | Layered content and token estimate | Prompt/document assets |
| builder.rs | Deterministic package construction | Kit pack |
| verify.rs | Structure and integrity report | Install/publish gate |
| signing.rs, keys.rs | Ed25519 signing/key handling | Publisher trust |
| registry.rs | Local store, import/export, materialization | Local-first Kit cache |
| remote.rs | Index lookup, checksum downloads, publish | Thinkery adapter |
| deps.rs, lockfile.rs | Dependency resolution and locks | Reproducible composition |
| skills.rs | Signed and verified skill packs | Hardened asset treatment |
| composition.rs | Context-graph composition | Future plan compilation |
| graph_model.rs | Graph and marketplace metadata | Discovery metadata |

The manifest supports dependencies, integrity information, and signatures.

MarketplaceMeta already carries categories, badges, and license.

The remote client already fetches version indexes, skips yanked versions
unless pinned, verifies download checksums, and publishes artifacts.

## Core architectural rule

Author source Kits as readable TOML directories.

Distribute public and private Kits as signed ctxpkg artifacts.

Do not create a second package format.

Do not create a parallel marketplace protocol.

This follows the strategy: ContextKitV1 uses ctxpkg as technical
distribution substrate.

## Source layout

~~~text
my-kit/
  kit.toml
  prompts/
    system.md
    report.md
  tests/
    fixture-repository/
    expectations.toml
  README.md
  CHANGELOG.md
~~~

kit.toml is required.

Prompt files and fixtures are optional for the smallest local Kit.

Built-ins should use files once multiline manifest content becomes difficult
to review.

Names remain lower-case and slash-free, preserving existing safety checks.

Public identity adds an immutable namespace such as acme/security-review.

Local use remains unqualified only when resolution is unambiguous.

## Schema policy

Keep format_version = 1 readable indefinitely.

Add optional fields with safe defaults.

Reject an unsupported future major version.

Unknown keys warn in author mode and fail in strict and publish modes.

Unknown security-relevant keys always fail.

## Target V1 source schema

~~~toml
format_version = 1

[kit]
name = "bugfix"
version = "1.0.0"
description = "Investigate, reproduce, repair, and prove a defect."
license = "Apache-2.0"
homepage = "https://example.invalid/kits/bugfix"
authors = ["LeanCTX"]
tags = ["maintenance", "debugging"]
min_lean_ctx = ">=1.0.0, <2.0.0"
visibility = "builtin"

[activation]
intent = ["bugfix", "debug", "incident"]
languages = ["rust", "python", "typescript"]
requires = ["git"]
conflicts = []
default = false

[read]
default_modes = ["map", "signatures"]
max_files = 80
max_tokens = 18000
follow_imports = "changed-only"

[[read.rules]]
glob = "**/tests/**/*"
modes = ["full"]
priority = 100
reason = "Tests define executable behavior."

[[read.rules]]
glob = "src/**/*.rs"
modes = ["map", "signatures"]
priority = 50

[priority]
strategy = "git_changed"
description = "Start with changed code and direct tests."
include = ["changed", "tests", "direct_callers"]
exclude = ["generated", "vendored"]

[shell]
default_mode = "compressed"
allow = ["cargo", "git", "rg"]
timeout_seconds = 120
network = "deny"

[[shell.commands]]
id = "test"
command = "cargo test --lib"
focus = ["failures", "panics", "test summary"]
when = "language == 'rust'"
required = true

[prompts]
system = "prompts/system.md"
report = "prompts/report.md"
variables = ["task", "changed_files", "quality_criteria"]

[quality]
criteria = [
  "reproduction exists or its absence is explained",
  "root cause is distinguished from symptom",
  "targeted regression test passes",
  "project quality gate passes"
]
required_checks = ["test"]
severity_policy = "blocker-and-critical"
evidence = "command-output"

[compatibility]
agents = ["codex", "claude-code", "cursor"]
platforms = ["darwin", "linux", "windows"]
~~~

## Schema semantics

### Metadata and activation

The kit table identifies an immutable authored artifact.

Version is SemVer and cannot change after publication.

Public Kits require authors, license, tags, and runtime compatibility.

Private project Kits may omit public catalog metadata.

Activation is advisory selection metadata.

V1 does not silently activate a Kit from task classification.

An explicit user or profile selector is still required.

### Read plan

Existing ordered rules remain backward compatible.

Explicit priority sorts highest first.

Equal priority retains manifest order.

Missing priority is zero, preserving old first-match behavior.

Read plans may reference only registered LeanCTX read modes.

They cannot register readers or bypass PathJail rules.

Effective files/tokens equal the minimum of runtime hard cap,
TuningProfile cap, and Kit request.

follow_imports is bounded and explainable:

- never
- changed-only
- bounded

### Priority plan

strategy is a constrained enum, never arbitrary code.

Initial supported strategies:

- git_changed
- task_paths
- test_first
- public_api
- documentation_graph

include and exclude are declarative candidate classes.

The resolver creates a bounded candidate set before any source read.

### Shell plan

Shell commands are recipes, not permission grants.

Runtime shell allowlist, PathJail, timeout ceiling, network policy, and
approval policy always win.

A Kit can narrow protections but never widen them.

Commands need stable IDs for tests and quality references.

when uses a small deterministic predicate language over project facts.

It is not an expression evaluator or shell interpolation.

Never substitute task text or prompt variables into shell commands.

Prompt and shell rendering use separate typed variable allowlists.

### Prompts

Prompts are versioned text assets.

The system prompt guides the workflow.

The report prompt specifies inspectable result format.

Variables are limited to task, repository facts, selected files, test results,
quality criteria, and resolved profile facts.

Undefined variables are validation errors.

Recursive template expansion is forbidden.

### Quality plan

String criteria remain the human-readable contract.

required_checks maps criteria to named declarative commands.

severity_policy decides whether unresolved findings block completion.

evidence declares receipt material needed to claim completion.

Quality assesses output and verification, never hidden model reasoning.

## Built-in Kits for 1.0

| Kit | Primary intent | Context shape | Required outcome |
| --- | --- | --- | --- |
| code-review | Review change before merge | Changed files, tests first, maps/signatures elsewhere | Findings carry severity, evidence, and impact |
| bugfix | Repair defect/regression | Reproduction/tests, changed code, direct callers | Root cause, regression coverage, targeted verification |
| refactor | Restructure safely | Public API, callers, tests, implementation | Invariants, preserved behavior, quality gate |
| documentation | Update docs accurately | Docs, APIs, examples, config, relevant tests | Claims trace to code; examples verified |

### code-review

Keep current behavior as canonical first built-in.

The 1.0 migration adds metadata, command IDs, and fixtures only.

Quality covers correctness, regression risk, tests, security, operability,
and an explicit no-findings conclusion.

### bugfix

Prioritize failing tests, reproductions, error output, and recent changes.

Expand only into direct callers, callees, and contracts needed to state root
cause.

Prefer a smallest targeted test command.

Do not make a full suite a surprise default.

### refactor

Start with public signatures, callers, interfaces, tests, and architecture docs.

Record invariants before renaming or moving code.

Passing tests alone are not complete proof of behavior preservation.

Require dependency and error-path review.

### documentation

Read target document, canonical code, configuration, and runnable examples.

Treat generated reference material as evidence unless selected for editing.

Require each factual claim to map to source/code/config evidence.

Verify examples when project tooling supports verification.

## Kit loading and resolution

For lean-ctx kit load NAME, resolve one Kit in this order:

1. Nearest project .lean-ctx/kits/NAME/kit.toml.
2. Parent project Kit directories toward filesystem root.
3. User data directory kits/NAME/kit.toml.
4. Embedded built-in NAME.

Nearest project wins.

This supports monorepo root defaults with package-specific overrides.

Resolver never silently merges same-name Kits from different scopes.

kit show --explain reports selected source, version, digest, and shadowed
candidates.

### Selector precedence

1. --kit NAME for one invocation.
2. LEAN_CTX_KIT for process.
3. Config.active_kit.
4. TuningProfile default only with no explicit selector.
5. No Kit: normal LeanCTX behavior.

This preserves the current environment/config contract.

### Names and remote identity

Unqualified names use local precedence.

Qualified thinkery:acme/secure-review@1.4.2 bypasses local shadowing.

Publishing creates immutable namespace/name/version artifacts.

Publishing different bytes under the same identity fails.

Yanking changes resolution metadata; it does not erase locks.

### Installation and locking

lean-ctx kit add acme/secure-review@^1.4 verifies and materializes a package.

It records exact version, content hash, signer fingerprint, and dependencies
in .lean-ctx/kits.lock.

Project execution defaults to locked resolution.

lean-ctx kit update shows manifest and trust changes before atomic lock update.

## Composition

Kits compose through named base Kits.

They do not merge arbitrary TOML tables or run extension code.

~~~toml
[compose]
extends = ["builtin:code-review@1"]

[[compose.overrides.read.rules]]
glob = "services/payments/**/*.rs"
modes = ["full"]
priority = 200
~~~

Resolve imports to immutable EffectiveKit before tools run.

Record sources and hashes in execution receipt.

| Field | Composition rule |
| --- | --- |
| Identity/version | Child owns identity; base stays provenance |
| Read defaults | Child replaces only when explicitly set |
| Read rules | Base-to-child, priority then stable source order |
| Includes/excludes | Union; exclude wins |
| Shell allowlist | Intersection |
| Shell commands | Unique IDs; replace only expressly overridable command |
| Prompts | Child may replace named assets, then variables revalidate |
| Quality criteria | Union; locked base criterion cannot be deleted |
| Required checks | Union |
| Token/file/timeout caps | Smallest finite value wins |

Cycles, duplicate command IDs, incompatible runtime ranges, and ambiguous
same-priority replacements fail before execution.

## Kits compose with TuningProfiles

TuningProfiles are performance/governance objects, not workflow bundles.

| Concern | Kit owns | TuningProfile owns |
| --- | --- | --- |
| Intent | Review, bugfix, refactor, documentation | None |
| Context | Globs, strategy, preferred modes | Global budget, reuse/cache policy, mode ceiling |
| Commands | Declarative named recipes | Approval, time, network, concurrency, cost ceiling |
| Prompts | Workflow instruction/report | Integration and immutable profile policy |
| Quality | Definition of done | Performance-claim evidence threshold |
| Distribution | Source/artifact/dependencies | Profile lineage/evidence |

Runtime computes:

EffectivePlan = Resolve(Kit, TuningProfile, Runtime)

Precedence is:

1. Hard safety and platform policy.
2. Explicit command-line restrictions.
3. TuningProfile governance and measured budgets.
4. Kit workflow preferences and quality obligations.
5. User configuration defaults.

For permissive fields, stricter value wins.

Examples include smaller cap, shorter timeout, denied network, narrower command
set, or more required checks.

Semantic conflicts are explicit.

A profile disallowing full reads and a Kit requiring full reads yields an
incompatibility error, not silent degradation.

Profiles may recommend a default Kit by intent.

Profiles record the resolved Kit digest in evidence.

Kits cannot claim cost savings; evidence-backed profiles can.

## Authoring workflow

### Create

~~~text
lean-ctx kit create bugfix --path .lean-ctx/kits/bugfix
lean-ctx kit create security-review --from builtin:code-review
~~~

create writes minimal valid source, prompt/report templates, README, and a
fixture skeleton.

It never activates the Kit or changes global configuration.

--from copies source assets with provenance in README.

--extends produces explicit composition instead.

### Lint and test

~~~text
lean-ctx kit lint .lean-ctx/kits/bugfix --strict
lean-ctx kit test .lean-ctx/kits/bugfix
lean-ctx kit test .lean-ctx/kits/bugfix --fixture tests/fixture-repository
lean-ctx kit test .lean-ctx/kits/bugfix --record-expectations
~~~

lint is static, offline, and deterministic.

test builds EffectiveKit against fixtures and checks selected paths, read modes,
rendered prompts, predicates, commands, quality obligations, and diagnostics.

--record-expectations is explicit because it mutates golden data.

It records normalized plans and hashes, never timestamps or absolute paths.

### Inspect and activate

~~~text
lean-ctx kit show bugfix --effective --profile team-default
lean-ctx kit plan bugfix --task "panic in import" --explain
lean-ctx kit load bugfix
~~~

plan prints source chain, applied rules, exclusions, estimates, commands,
variable names, and quality gate.

It never prints secret values or rendered sensitive prompt values.

### Pack and publish

~~~text
lean-ctx kit pack .lean-ctx/kits/bugfix --out dist/bugfix-1.0.0.ctxpkg
lean-ctx kit verify dist/bugfix-1.0.0.ctxpkg
lean-ctx kit publish dist/bugfix-1.0.0.ctxpkg --registry thinkery
~~~

pack constructs deterministically and signs when publisher key exists.

verify checks structure, hashes, byte size, signature, compatibility,
path safety, and Kit semantics.

publish mandates strict test, verification, namespace ownership, immutable
version preflight, then remote publish.

It emits artifact digest and signer fingerprint without creating credentials.

## Validation gates

### Gate 1 — schema

- Required identity, SemVer, format, and runtime compatibility.
- Safe normalized names and paths.
- Valid globs and registered read modes.
- Bounded files, tokens, and timeouts.
- Assets exist below Kit root.
- Template variables are declared and typed.
- No duplicate IDs, criteria, or ambiguous priorities.

### Gate 2 — safety

- Commands parse to approved executable and arguments.
- No task/prompt interpolation in commands.
- No traversal or unmanaged redirection.
- Kit policy only narrows runtime policy.
- Network requires runtime and profile permission.
- Secrets never enter source, fixtures, snapshots, or output.

### Gate 3 — deterministic plan

- Same source, fixture, profile, and task facts yield same EffectiveKit.
- Candidate selection has stable bounded order.
- Read rules choose expected modes.
- Prompts have no undefined variable.
- Predicates select expected commands.
- Quality gate yields expected pass, warn, or block.

### Gate 4 — package and trust

- Manifest, layers, integrity, and lock verify.
- Download bytes match registry index hash.
- Signature matches trusted publisher for public installation.
- Dependencies resolve and lock exactly.
- Yanked packages require explicit pin or policy exception.

## Quality scoring

Quality score supports discovery.

It never replaces hard validation.

| Dimension | Points | Evidence |
| --- | ---: | --- |
| Schema/package hygiene | 15 | Strict lint, signature, license, file manifest |
| Safety posture | 20 | Narrow commands, denied network, policy checks |
| Determinism | 15 | Stable plans and fixtures |
| Workflow coverage | 15 | Read, prompt, command, quality contract |
| Verification quality | 15 | Fixtures, checks, regression/evidence requirements |
| Compatibility | 10 | Tested runtime and agent matrix |
| Maintenance | 10 | Current support, changelog, security response |

Display raw subscores and evidence/runtime version.

Never hide a failed gate behind a high score.

Trust state is separate:

- Built-in.
- Verified publisher.
- Organization-approved.
- Unverified local.
- Deprecated.
- Yanked.

Built-ins target 90+ and zero hard-gate failures.

Private Kits still pass every hard gate.

## Thinkery marketplace architecture — later

Thinkery is discovery/governance over existing package protocol.

It is not a mandatory runtime dependency.

~~~text
Author TOML
  -> strict test plus deterministic pack
  -> signed ctxpkg
  -> Thinkery registry/index
  -> verified local cache
  -> lockfile resolver
  -> EffectiveKit plus receipt provenance
~~~

### Registry responsibilities

- Namespace ownership and publisher-key binding.
- Immutable artifacts addressed by identity and digest.
- Version indexes with yanked/deprecated/advisory metadata.
- Signed manifests and checksum delivery.
- Search over declared metadata, not prompt bodies by default.
- Score cards, compatibility reports, and test attestations.
- Public, organization-private, and project-private visibility.
- Audited publish, yank, ownership, and key events.

### Runtime responsibilities

- Resolve project/user/built-in before remote access.
- Download only on explicit add/update or policy-approved install.
- Verify before unpacking/materialization.
- Use project locks by default.
- Work offline with installed artifacts.
- Treat registry metadata as untrusted data.

### Trust model

Built-in publisher keys ship with LeanCTX.

Organizations configure local or enterprise keyrings.

Public signatures prove publisher control, not universal appropriateness.

Revocation controls new resolution and visible status.

Existing locks remain reproducible but warn/block under local policy.

### Explicit marketplace exclusions

- Marketplace-provided binaries.
- Host-mutating marketplace hooks.
- Ratings as security signals.
- One-click runs bypassing plan/policy inspection.
- A second workflow package format.

## Receipt provenance

Each run records a compact deterministic fragment:

~~~json
{
  "kit": {"name": "bugfix", "version": "1.0.0", "digest": "sha256:..."},
  "sources": ["project:.lean-ctx/kits/bugfix"],
  "profile": {"name": "team-default", "version": "1.2.0", "digest": "sha256:..."},
  "effective_plan_digest": "sha256:...",
  "selected_rules": ["tests", "rust"],
  "quality": {"required": ["test"], "outcome": "pass"}
}
~~~

Do not embed prompt bodies, repository source, secret values, or telemetry.

Reference evidence artifacts when richer provenance is required.

## Implementation milestones

### A — clarify current core

- Preserve current parsing and behavior byte-for-byte.
- Split module only into schema, loader, validation, resolver, and plan.
- Replace single embedded constant with a BuiltinKit registry.
- Add show --explain source/shadow diagnostics.
- Add bugfix, refactor, documentation, and fixture tests.

### B — composition and inspection

- Add extends, merge rules, cycle detection, and cap handling.
- Create immutable EffectiveKit and EffectivePlan digests.
- Add kit lint, kit test, and kit plan.
- Add static shell/template/path policy checks.
- Define a small typed predicate vocabulary.

### C — profiles

- Define TuningProfileV1 separately from Kits.
- Add compatibility negotiation and strict-cap composition.
- Record Kit/profile digests in execution/evidence receipts.
- Add incompatibility fixtures.

### D — package bridge

- Use existing package kind if semantically sufficient.
- Add PackageKind::Kit only if necessary.
- Map Kit manifest/assets to ctxpkg layers exactly.
- Reuse builder, verify, signing, registry, deps, and lockfile.
- Add pack, add, verify, and update commands.

### E — Thinkery

- Put existing remote client behind registry trait.
- Publish immutable indexes/artifacts with verification.
- Add namespace/key, visibility, yank, score, and audit services.
- Keep network opt-in and execution local-first.

## V1.0 acceptance criteria

- Four built-ins load with no remote service.
- Existing code-review remains valid and fixture-tested.
- Project > user > built-in is deterministic and explainable.
- Nearest monorepo project Kit wins.
- Bad modes, names, globs, assets, and variables fail clearly.
- Kits cannot widen shell, network, or path permissions.
- Same input yields stable kit plan output.
- Kit/Profile incompatibility is explicit.
- Built-ins test read, command, prompt, and quality behavior.
- Packed artifacts are deterministic and signature-verifiable.
- Project installs lock and work offline.
- Receipts identify Kit, profile, sources, and plan digest.

## Decisions required before implementation

1. Reuse current package kind or add PackageKind::Kit.
2. Freeze TuningProfileV1 source/artifact contract.
3. Reuse available SemVer parser, not new range syntax.
4. Require all public Kits signed or make unsigned blocked-by-default.
5. Derive predicates from built-in needs; do not create a scripting DSL.

## Recommendation

Ship reviewed TOML workflow recipes first.

Make four built-ins excellent and plans inspectable.

Compose them safely with evidence-backed TuningProfiles.

Then package exactly those recipes through existing signed ctxpkg mechanics.

Let Thinkery become optional discovery and governance.

This retains LeanCTX's local-first OSS wedge while making Kits a real adoption
and distribution vehicle rather than isolated tuning settings.

