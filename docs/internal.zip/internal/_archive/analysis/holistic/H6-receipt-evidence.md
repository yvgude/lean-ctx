# H6 — Receipt and Evidence Architecture

## Decision

LeanCTX should have one evidence truth:

```text
wrap() / provider call
  -> immutable ExecutionReceipt
  -> linked receipt chain
  -> SavingsReceipt (comparison or period claim)
  -> EvidenceBundle
  -> independent offline verifier
```

The dashboard, HTML report, CLI summaries, and sales material are views.

They must never calculate an alternative savings number.

An artifact is **verified** only when the declared offline verifier passes.

Verification proves integrity, provenance under a declared key, and declared
arithmetic/methodology constraints.

It does not prove universal performance, regulatory compliance, or that an
operator did not omit events before they were recorded.

## Design goals

- Emit a receipt for every completed `wrap()` invocation, including failures.
- Keep provider facts, calculated economics, and invoice reconciliation separate.
- Keep raw prompts, completions, API keys, and unredacted source out of default receipts.
- Make individual receipts and bundles valid without a network connection.
- Let a customer disclose a small, redacted bundle rather than a complete telemetry store.
- Make comparison claims fail closed when workload, controls, or quality are not comparable.
- Make byte representation, IDs, signatures, and verifier behavior test-vector stable.
- Preserve the existing local-first workflow and avoid a cloud dependency.

## Terms and scope

`ExecutionReceipt` is the signed record of one bounded agent execution.

One `wrap()` call produces one receipt, even when it contains several provider calls.

`SavingsReceipt` is a signed claim over a matched baseline/treatment comparison
or over a defined population of such comparisons during a period.

`EvidenceBundle` is a deterministic archive containing the receipts and source
artifacts needed to check one claim.

`Receipt chain` is the append-only sequence of receipt digests for one signer,
workspace, and chain scope.

`Evidence reference` is a typed URI plus content digest, never an unverified
string or a copy of arbitrary payload text.

`Provider-reported usage` is read from a provider response.

`Calculated provider cost` is an arithmetic result using a versioned price table.

`Reconciled invoice cost` is a separately attested result matched to billing data.

## Normative encoding rules

All signed records use UTF-8 canonical JSON.

Canonical JSON means recursively lexicographically sorted object keys,
preserved array order, compact separators, and no trailing newline.

Numbers in signed economics fields are integers, never binary floating point.

Money uses integer micros with an explicit ISO-4217 currency field.

Ratios and scores use integer milliunits in `[0,1000]`.

Timestamps are RFC 3339 UTC with nanoseconds omitted unless a source supplies
higher precision as a separate string field.

Every digest is lower-case hexadecimal and names its algorithm.

The default content digest is `sha256:<64 lowercase hex>`.

The default signature is `ed25519` encoded as unpadded base64url.

`key_id` is `ed25519:sha256:<first 32 hex of public-key SHA-256>`.

The signed payload excludes only its own `receipt_id` and `signature` fields.

`receipt_id` is `sha256(canonical unsigned payload)` with its `sha256:` prefix.

The receipt ID is therefore a content address, not a random identifier.

If a run must be distinguished before completion, it uses `run_id`; it does not
change the finished receipt ID rule.

Unknown required fields, invalid encodings, duplicate IDs, and non-canonical
payload bytes are verification failures.

## Canonical receipt document

The current protocol `ExecutionReceiptV1` has `deny_unknown_fields`.

Adding the required fields below to it would be wire-breaking.

Therefore freeze it as a legacy compatibility projection.

Introduce the new complete public contract as `ReceiptDocumentV1` with a
`kind` discriminator.

This avoids a misleading `ExecutionReceiptV1` retrofit while preserving current
deserializers and historical artifacts.

`ReceiptDocumentV1.kind` is one of `execution`, `savings`, or `checkpoint`.

Each document has this common header:

```json
{
  "document_version": 1,
  "kind": "execution",
  "receipt_id": "sha256:...",
  "chain": {
    "chain_id": "chain:workspace-7:agent-9",
    "sequence": 42,
    "previous_receipt_id": "sha256:...",
    "previous_signature_digest": "sha256:..."
  },
  "signing": {
    "algorithm": "ed25519",
    "key_id": "ed25519:sha256:...",
    "public_key": "base64url...",
    "signature": "base64url..."
  }
}
```

`previous_receipt_id` is `null` only for sequence zero.

`previous_signature_digest` is the SHA-256 digest of the previous signature
bytes, and is `null` only for sequence zero.

The header is included in the signed payload except `receipt_id` and
`signing.signature`.

The embedded public key permits self-contained verification.

An auditor-supplied trust store or `--public-key` converts this from
self-attested integrity to identified-signer verification.

## ExecutionReceipt schema — exact fields

`ReceiptDocumentV1` with `kind = "execution"` contains the common header plus
the following payload.

```yaml
execution:
  identity:
    run_id: string
    task_id: string
    trace_id: string | null
    project_id: string | null
    workspace_id: string | null
    agent:
      id: string
      version: string
      adapter: string
    runtime:
      lean_ctx_version: string
      integration: attach | wrap | embed
      host: string | null
  timing:
    started_at: rfc3339-utc
    finished_at: rfc3339-utc
    duration_ms: u64
  execution:
    status: succeeded | failed | cancelled | timed_out | partial
    error_class: string | null
    attempt: u32
    retry_count: u32
    tool_calls: [ToolCallSummary]
    provider_calls: [ProviderCallSummary]
  context:
    plan:
      id: string | null
      digest: sha256-digest | null
      strategy: string | null
      budget_tokens: u64 | null
    profile:
      id: string | null
      version: string | null
      digest: sha256-digest | null
    kits: [VersionedDigestRef]
    selections:
      selected: [SelectionSummary]
      excluded_digest: sha256-digest | null
      recovery_events: [RecoverySummary]
    balance:
      original_tokens: u64
      materialized_tokens: u64
      delivered_tokens: u64
      provider_billed_input_tokens: u64 | null
  usage:
    provider_reported:
      fresh_input_tokens: u64 | null
      cached_input_tokens: u64 | null
      output_tokens: u64 | null
      reasoning_tokens: u64 | null
      source_refs: [EvidenceRef]
    normalized:
      input_tokens: u64 | null
      output_tokens: u64 | null
      estimated: boolean
  economics:
    currency: string
    price_table:
      id: string | null
      version: string | null
      digest: sha256-digest | null
    calculated_provider_cost_micros: i64 | null
    reconciled_invoice_cost_micros: i64 | null
    cost_status: unavailable | calculated | reconciled
    baseline_reference: BaselineReference | null
  quality:
    contract_id: string | null
    contract_version: string | null
    gates: [QualityGateResult]
    overall_score_milli: u16 | null
    outcome_ref: EvidenceRef | null
    human_acceptance: accepted | rejected | not_required | pending
  evidence:
    methodology_id: string
    methodology_version: string
    inputs_digest: sha256-digest | null
    source_revision: string | null
    evidence_refs: [EvidenceRef]
    redaction: RedactionSummary
```

`ToolCallSummary` has exactly `tool`, `call_index`, `input_tokens`,
`output_tokens`, `cache_hit`, `status`, `duration_ms`, and `evidence_ref`.

`ProviderCallSummary` has exactly `provider`, `requested_model`,
`selected_model`, `call_index`, `response_id`, `request_digest`,
`response_digest`, `usage`, `latency_ms`, `retry_index`, and `evidence_ref`.

`ProviderCallSummary.usage` has `fresh_input_tokens`, `cached_input_tokens`,
`output_tokens`, and `reasoning_tokens`, each nullable when not provided.

`VersionedDigestRef` has `id`, `version`, `digest`, and `uri`.

`SelectionSummary` has `source_kind`, `source_ref`, `content_digest`,
`view`, `original_tokens`, `delivered_tokens`, and `reason_code`.

`RecoverySummary` has `event_id`, `reason`, `source_ref`, `tokens_added`, and
`evidence_ref`.

`BaselineReference` has `comparison_id`, `baseline_receipt_id`, and
`measurement_scope`; it is absent when this execution is not a treatment arm.

`QualityGateResult` has `gate_id`, `gate_version`, `required`, `status`,
`score_milli`, `evidence_ref`, and `notes_digest`.

`EvidenceRef` has `kind`, `uri`, `digest`, `media_type`, `bytes`, and
`signature_status`.

`RedactionSummary` has `policy_id`, `policy_version`, `redacted_fields`, and
`raw_payload_included`.

Receipts retain evidence digests and minimal selected-context descriptions.

They do not include raw prompts, completion text, source files, headers,
tokens, credentials, or personally identifying payloads by default.

An encrypted optional payload may be included in a bundle only when the
customer explicitly chooses it and its digest is listed in `evidence_refs`.

## ExecutionReceipt invariants

`finished_at >= started_at` and `duration_ms` must match within one millisecond.

`materialized_tokens <= original_tokens`.

`delivered_tokens <= materialized_tokens`.

The aggregate of non-null provider call usage must equal top-level reported
usage when every provider call is present.

`cost_status = calculated` requires a versioned price-table digest and a
non-null calculated cost.

`cost_status = reconciled` requires both calculated and reconciled cost plus an
invoice evidence reference.

`status = succeeded` cannot contain a required quality gate with `failed`.

`human_acceptance = accepted` requires a signed or identified human evidence ref.

An execution can be signed when provider usage or quality is unavailable.

It is then a valid execution record but cannot make an eligible savings claim.

## SavingsReceipt schema — exact fields

`ReceiptDocumentV1` with `kind = "savings"` contains the common header plus
this payload.

```yaml
savings:
  savings_id: sha256-digest
  claim_type: paired_comparison | cumulative_period
  subject:
    project_id: string | null
    workspace_id: string | null
    workflow_id: string
    workflow_version: string
  period:
    from: rfc3339-utc
    to: rfc3339-utc
  methodology:
    id: string
    version: string
    digest: sha256-digest
    matching_rules: [string]
    exclusions: [string]
  population:
    baseline:
      receipt_count: u64
      receipt_ids: [sha256-digest]
      receipt_merkle_root: sha256-digest
      selection_digest: sha256-digest
    treatment:
      receipt_count: u64
      receipt_ids: [sha256-digest]
      receipt_merkle_root: sha256-digest
      selection_digest: sha256-digest
  economics:
    currency: string
    baseline_calculated_cost_micros: i64 | null
    treatment_calculated_cost_micros: i64 | null
    avoided_calculated_cost_micros: i64 | null
    baseline_reconciled_cost_micros: i64 | null
    treatment_reconciled_cost_micros: i64 | null
    avoided_reconciled_cost_micros: i64 | null
    measurement_method: provider_reported | calculated | reconciled | unavailable
  tokens:
    baseline_provider_billed_input_tokens: u64 | null
    treatment_provider_billed_input_tokens: u64 | null
    avoided_provider_billed_input_tokens: u64 | null
    savings_ratio_milli: u16 | null
  quality:
    contract_id: string
    contract_version: string
    baseline_score_milli: u16 | null
    treatment_score_milli: u16 | null
    eligible_pairs: u64
    excluded_pairs: u64
    quality_preserved: boolean
    gate_evidence_refs: [EvidenceRef]
  controls:
    workload_digest: sha256-digest
    source_revision: string
    provider: string
    model: string
    timeout_ms: u64
    budget_micros: i64 | null
    cache_policy: string
    randomized_assignment: boolean | null
  evidence:
    comparison_pairs: [ComparisonPair]
    evidence_refs: [EvidenceRef]
    limitations: [string]
```

`ComparisonPair` has `pair_id`, `baseline_receipt_id`, `treatment_receipt_id`,
`match_digest`, `eligible`, and `exclusion_reason`.

For `paired_comparison`, each population has exactly one receipt and one pair.

For `cumulative_period`, `receipt_ids` may be capped at 10,000 elements.

Above that cap, the receipt contains every pair ID, cardinality, and the Merkle
root, while the full member list remains a separately hashed bundle artifact.

The SavingsReceipt itself is not a dashboard aggregate.

It is the signed, reproducible aggregate from which a dashboard aggregate is made.

## SavingsReceipt invariants

Every included pair must have identical methodology matching dimensions.

At minimum these dimensions are workload digest, source revision, provider,
model, timeout, budget, cache policy, and declared quality contract.

A methodology may deliberately vary one dimension only if that dimension is in
its declared experimental variable list.

`avoided_*_micros = baseline_*_micros - treatment_*_micros` exactly when both
cost values are known.

No avoiding-cost claim is emitted when either side is unavailable.

`savings_ratio_milli` is zero when the baseline billed input is zero.

Otherwise it is floor(`1000 * avoided / baseline`) and must be `[0,1000]`.

`quality_preserved` is true only when every eligible treatment pair passes all
required gates and meets or exceeds the declared quality threshold.

Pair exclusion must be explicit; failed arms and retries are evidence, not
silently discarded records.

A `calculated` claim says “calculated provider cost,” never “provider billed.”

A `reconciled` claim must include an invoice or billing-export evidence ref.

## Receipt-chain design

Each chain has a stable `chain_id` scoped to `(workspace_id, agent key_id)`.

The signer appends the next receipt only after durable local persistence.

The append record stores the canonical receipt bytes, its ID, and a small index.

The index is an optimization and is never a source of truth.

The chain link covers the previous receipt ID and previous signature digest.

Changing, deleting, inserting, or reordering an accepted receipt breaks the
next link.

Every 1,024 entries or 24 hours, whichever comes first, emit a `checkpoint`
ReceiptDocument containing `chain_id`, sequence range, Merkle root, head ID,
and head signature digest.

The checkpoint is signed by the same local key and can be exported with a
bundle anchor.

The v1 chain is local append-only evidence, not a globally witnessed ledger.

It proves continuity after durable recording, not omission before recording.

## Automatic creation on every `wrap()` call

`wrap()` creates a `ReceiptRecorder` before it materializes or forwards context.

The recorder receives a generated `run_id`, task/trace IDs, start timestamp,
runtime identity, and the active profile/Kit digests.

Each context selection calls `record_selection()`.

Each tool result calls `record_tool_call()` with token and digest facts.

Each provider response is normalized once and calls `record_provider_call()`.

Each retry and recovery event is appended in causal order.

Quality evaluators call `record_quality_gate()` before the invocation finalizes.

`wrap()` finalizes through a `finally`/RAII guard on success, error, timeout,
cancellation, and panic boundary recovery.

Finalization sets the terminal status, captures the final timing, validates
invariants, canonicalizes, derives the receipt ID, signs, persists, and appends
the receipt to the chain.

Persistence failure is surfaced as `receipt_persistence_failed` telemetry.

It must not rewrite the completed model result, but it must mark the execution
as ineligible for a verified savings claim.

The hot path writes an append-only local spool first, then a compact SQLite or
JSONL index asynchronously.

The spool record is `length || canonical bytes || checksum` to permit crash
recovery without accepting a partial final write.

The receipt writer is idempotent by `receipt_id`.

Repeated delivery of the same finalization bytes does not create a second chain
entry.

`wrap()` returns an optional `receipt_id` in debug/SDK metadata, never embeds
raw receipt payloads in model-visible context by default.

Unwrapped paths can emit an observation, but they cannot claim to be a
complete ExecutionReceipt.

## Local signing and offline key management

Use the existing local Ed25519 identity store as the v1 key source.

The private seed remains in the LeanCTX data directory with owner-only mode.

The public key is written beside it and is exportable without secrets.

Resolve the signing key exactly once per receipt/bundle construction.

This avoids the current split-read race where a signature and embedded public
key could come from different key files.

Sign canonical unsigned receipt bytes with Ed25519.

Store the public key and `key_id` in every signed receipt and bundle manifest.

The verifier accepts an embedded key for self-attested mode.

The verifier accepts `--public-key` or a trust-store mapping for trusted mode.

When an external key differs from an embedded one, verification fails unless a
rotation certificate in the bundle authorizes the exact transition.

V1 key rotation creates a new chain; it does not silently continue an old one.

The final checkpoint from the old key and the first checkpoint from the new
key may be co-signed as a `key-transition` bundle artifact.

Private keys never travel in a receipt, bundle, report, or debug log.

## EvidenceBundle schema and layout

An EvidenceBundle is a deterministic ZIP named `evidence-bundle-v2` in this
architecture, because the existing `evidence-bundle-v1` contract is audit-chain
specific and cannot be changed compatibly.

Its root manifest has these exact fields:

```yaml
bundle: evidence-bundle
version: 2
bundle_id: sha256-digest
claim:
  type: execution | savings | period_savings
  receipt_ids: [sha256-digest]
  savings_receipt_id: sha256-digest | null
  statement: string
  limitations: [string]
subject:
  project_id: string | null
  workspace_id: string | null
  agent_id: string
created_from:
  methodology_id: string
  methodology_version: string
  source_revision: string | null
files: [{path, media_type, bytes, sha256}]
chain_anchors: [{chain_id, first_receipt_id, last_receipt_id, checkpoint_receipt_id}]
signing: {algorithm, key_id, public_key, signature}
```

The manifest’s `bundle_id` is the SHA-256 of canonical manifest bytes with
`bundle_id` and `signing.signature` absent.

The bundle signature signs those same canonical bytes.

V2 removes the old signed-digest special case and has one signature rule.

The ZIP uses lexicographically ordered paths, Stored compression, ZIP epoch
timestamps, and canonical JSON for all JSON documents.

The standard customer-proof layout is:

```text
manifest.json
receipts/execution/<receipt_id>.json
receipts/savings/<savings_receipt_id>.json
chains/<chain_id>.jsonl
checkpoints/<checkpoint_receipt_id>.json
methodology/methodology.json
pricing/<price_table_id>-<version>.json
quality/<quality_evidence_digest>.json
evidence/<digest>.<extension>
members/<savings_receipt_id>.json       optional large population list
README.md                               generated explanation, not signed claim data
```

The manifest lists every payload artifact except `manifest.json` and `README.md`.

No unknown payload is allowed outside explicitly reserved future directories.

## Bundle assembly for customer proof

1. Select a precise claim, scope, period, and audience-approved redaction policy.

2. Resolve baseline/treatment receipts using the methodology’s deterministic
selection query and retain every excluded/failed pair reason.

3. Validate pair controls and quality before calculating any savings total.

4. Build and sign the SavingsReceipt from the selected immutable executions.

5. Collect receipts, signed chain segments, the nearest preceding checkpoint,
methodology, price table, quality evidence, and provider-use evidence digests.

6. Materialize only customer-approved raw evidence; otherwise use digest-only
evidence references and state that limitation in the manifest claim.

7. Canonicalize each JSON payload, hash it, build the manifest, derive its ID,
and sign it with the resolved local key.

8. Create the deterministic archive and immediately verify it with the
independent verifier in trusted-key mode when a customer public key is known.

9. Generate HTML/PDF reports solely from the verified receipt and manifest data.

10. Embed the bundle ID and verifier version in reports so the report is a view,
not an independent truth source.

The customer-facing statement must name the workflow, sample size, period,
cost vocabulary, methodology version, quality contract, and limitations.

The statement must never extrapolate a workload-specific result into a
universal savings percentage.

## Offline verifier design

The verifier is a separate minimal-dependency package with no LeanCTX runtime
dependency and no network behavior.

`leanctx-verify bundle.zip --public-key customer-pinned-key --json` returns a
machine-readable result and a nonzero exit status for every invalid bundle.

Verification performs the following fail-closed steps.

1. Enforce archive byte, entry-count, path-length, and decompression-size limits.

2. Reject duplicate ZIP entries, absolute paths, parent traversal, and unsafe
symlink-like entries.

3. Parse the manifest with a strict versioned schema and reject unknown
non-reserved payload paths.

4. Check canonical JSON bytes for every JSON receipt, methodology, price table,
and manifest; accept no alternate formatting under a signed filename.

5. Recompute every listed SHA-256 and require the archive inventory to match
the manifest exactly.

6. Recompute the manifest bundle ID and verify the Ed25519 bundle signature
with the external trusted key or explicitly report self-attested mode.

7. Parse every receipt strictly, recompute each receipt ID, and verify each
receipt signature against its embedded or trusted signer key.

8. Replay each chain segment: sequence is contiguous, prior IDs and prior
signature digests match, and every referenced checkpoint root and head matches.

9. Resolve every receipt reference and evidence digest required by the claim.

10. Recalculate provider-use totals, calculated cost from the bundled price
table, token savings, and quality eligibility using integer arithmetic.

11. Re-run every baseline/treatment matching rule and reject mixed controls,
unknown exclusions, missing failures, or an ineligible pair counted as a win.

12. Produce a result distinguishing `integrity_valid`, `signer_trusted`,
`chain_valid`, `arithmetic_valid`, `quality_eligible`, and `claim_valid`.

`claim_valid` is true only when all applicable components are true.

A report may display lower-level checks, but it cannot label the customer claim
“verified” when `claim_valid` is false.

## Current implementation inventory

`receipt_builder.rs` correctly aggregates context balances, normalized provider
usage, model selections, costs, and digest-only evidence references.

It sorts and deduplicates knowledge, decision, and evidence refs before build.

It derives a deterministic BLAKE3 receipt ID from canonical JSON without ID or
signature, which is a useful content-addressing foundation.

`canonical.rs` provides deterministic sorted compact JSON and proper Ed25519
receipt/manifest signing primitives.

`savings.rs` defines a paired `SavingsReceiptV1` with costs, balances, quality
scores, methodology, evidence refs, and validation of basic numeric bounds.

`evidence_flow.rs` can turn a matched provider run plus quality comparison into
two signed execution receipts, one signed savings receipt, artifacts, a bundle,
and an internal self-verification result.

`evidence_bundle.rs` produces deterministic Stored ZIP files with sorted paths,
fixed ZIP timestamps, payload hashes, and Ed25519 material in the manifest.

`verify.rs` checks the internal bundle manifest hashes and signature offline.

`packages/leanctx-verify` is a genuinely independent verifier for the existing
audit-oriented `evidence-bundle-v1` contract.

The Context Kernel’s `envelope_wiring.rs` automatically records proxy and MCP
activity into an in-memory `receipt_chain` when the feature is enabled.

## Gap analysis

### Receipt production and linkage

- No reviewed `wrap()` path instantiates `ReceiptBuilder` and guarantees final
  receipt persistence for every terminal outcome.
- `ReceiptBuilder` is an isolated builder, not the lifecycle owner/recorder
  proposed above.
- Kernel `receipt_chain.rs` is process-local memory, uses a monotonic integer
  plus wall-clock seconds, and carries neither a digest link nor a signature.
- Chain state disappears on restart and cannot establish an audit trail across
  machines or exported customer evidence.
- The existing `ContextReceiptV1` and `McpReceipt` are separate legacy models,
  so several receipts can describe the same event without a canonical join.

### Schema and provenance

- Current `ExecutionReceiptV1` is a fixed aggregate projection; it lacks run
  timing, agent/runtime identity, integration mode, per-call provider facts,
  exact selection provenance, profile/Kit digests, price-table provenance,
  quality-contract identity, redaction metadata, signer key ID, and public key.
- Its `signature: String` has no declared algorithm or encoding.
- `ReceiptBuilder::sign` stores a BLAKE3 hash in that field, while
  `canonical::sign_receipt` stores a base64 Ed25519 signature in the same field.
- `evidence_flow` overwrites the builder-style meaning with the Ed25519 value;
  a consumer cannot reliably interpret a standalone current receipt.
- Current receipt IDs use BLAKE3 while bundle payloads use SHA-256; this is
  workable but undocumented as a deliberate cross-artifact policy.

### Savings claims

- `SavingsReceiptV1` is one baseline/treatment pair, not cumulative time-window
  evidence with member provenance or a Merkle root.
- `compute_from_arms` starts with `quality_preserved = true` and zero scores;
  callers must correct it, so the primitive does not make eligibility safe.
- Validation checks only that avoided cost is not greater than baseline; it does
  not require exact delta arithmetic, matching task/workload controls, valid
  signature, cost-source provenance, or a quality contract.
- Savings signing is a private helper in `evidence_flow.rs`; protocol users do
  not have one canonical signing/verification API for savings receipts.

### Bundles and verification

- `generate_artifact_bundle` omits the audit trail and `chain` data required by
  the published standalone `evidence-bundle-v1` verifier.
- Its provider-run bundle self-verifies with the internal CLI verifier but does
  not satisfy the standalone verifier’s mandatory chain replay step.
- `verify.rs` warns about an unlisted ZIP payload instead of rejecting it,
  whereas the published bundle contract says payload additions must fail.
- `verify.rs` accepts several manifest-signature encodings and fallback signing
  payloads, masking incompatible producer behavior rather than enforcing one
  canonical contract.
- `evidence_bundle.rs` has two different signing conventions: `generate()`
  uses `sign_manifest`, while `generate_artifact_bundle()` signs a digest string
  and hex-encodes the signature.
- The standalone verifier inserts duplicate ZIP names into a map rather than
  explicitly rejecting duplicates; a v2 verifier must fail before parsing.

### CLI evidence products

- `lean-ctx evidence run` explicitly has no implementation.
- `evidence workflow` writes an ordinary dynamic ZIP manifest (`version: 2.0.0`)
  without listed file hashes, receipt documents, deterministic ZIP metadata, or
  a signature; it is not an offline-verifiable EvidenceBundle.
- `evidence realworld` captures useful per-turn provider usage and cache facts,
  but writes unsigned pretty JSON with floating-point costs and no receipt or
  signed manifest.
- `evidence report` computes a SHA-256 display hash of the result JSON; it is
  not a cryptographic signer verification and the report is not a proof object.
- `evidence_cost.rs` projects economics as `f64` and does not bind a price-table
  version/digest to its projected claim.
- `evidence inspect` only lists files and prints a manifest; it does not verify.

## V1.0 delivery boundary

V1.0 should deliver a credible local customer-proof loop, not the entire
organization evidence platform.

- `ReceiptDocumentV1` and strict canonical test vectors.
- Automatic final receipt emission/persistence for the public `wrap()` path.
- A compatibility adapter that projects new executions to existing
  `ExecutionReceiptV1` where required by current callers.
- One local Ed25519 key, key export, trusted-key verification, and explicit
  self-attested verification status.
- A durable signed, hash-linked local chain and signed periodic checkpoint.
- Per-run execution receipts with per-call aggregate facts, profile/Kit digests,
  provider-reported usage, calculated costs, and quality gate references.
- Paired baseline/treatment SavingsReceipts with strict control matching,
  quality eligibility, and integer cost/token arithmetic.
- Deterministic `evidence-bundle-v2` customer bundles containing receipts,
  methodology, price table, quality evidence, chain segment, and checkpoints.
- One independent fail-closed verifier implementation plus mutation and golden
  vector tests shared only through the published contract, never shared code.
- Migration of `evidence realworld` and provider-run output into this pipeline.
- HTML reports rendered only after a valid bundle exists and labeled with bundle
  ID, verifier version, cost vocabulary, and limitations.

V1.0 explicitly does not promise invoice reconciliation, managed custody,
hosted history, multi-workspace aggregation, or third-party timestamping.

## V2.0 delivery boundary

V2.0 adds organization-scale proof only after V1 produces repeatable customer
evidence and the quality methodology is stable.

- Cumulative period SavingsReceipts with large-population Merkle membership
  proofs, deterministic selectors, and sampled audit support.
- Multi-signer chains for agent, workspace, reviewer, and customer acceptance.
- KMS/HSM/OS-keystore key adapters, rotation certificates, revocation feeds,
  and policy-controlled key trust stores.
- Optional external timestamp/notary or transparency-log checkpoint anchoring.
- Provider-native signed usage artifacts where providers expose them.
- Invoice import and reconciled-cost receipts with statement-period matching.
- Privacy-preserving encrypted evidence payloads, selective disclosure, and
  customer-managed encryption keys.
- Hosted storage, retention, legal hold, RBAC, workspace sharing, and audit
  exports, while retaining offline bundle verification.
- AutoTune experiment matrices, randomized assignment records, Pareto results,
  human approvals, Profile deployment/rollback receipts, and organization-wide
  economics.
- Claim governance workflows that approve customer case-study statements from
  verified savings receipts rather than manual spreadsheets.

## Migration sequence

1. Publish the canonical JSON, signature, ID, and verifier test-vector spec.

2. Add `ReceiptDocumentV1`, a durable `ReceiptStore`, and `ReceiptRecorder`.

3. Wire the recorder into `wrap()` first; emit compatibility projections to
current receipt consumers without changing their wire schema.

4. Replace in-memory `receipt_chain` as the proof source with links to durable
signed receipts; retain it only as a live metrics cache.

5. Move savings construction/signing/verification into the protocol/core
contract and make every mismatch or failed quality gate ineligible by default.

6. Replace `generate_artifact_bundle`’s ambiguous signing paths with the v2
manifest rule and build a matching independent verifier.

7. Make CLI `evidence workflow`, `realworld`, and `run` produce receipts and
verified bundles; make `inspect` invoke verification or rename it `list`.

8. Deprecate the overloaded `ExecutionReceiptV1.signature` interpretation and
display legacy artifacts as `integrity format: legacy` until migrated.

## Acceptance tests

- A successful wrap produces one signed execution receipt and one chain entry.
- An error, timeout, and cancellation each produce exactly one signed terminal
  receipt with no fabricated usage or quality facts.
- Altering any signed receipt byte fails receipt and bundle verification.
- Removing, inserting, or reordering a chain entry fails chain replay.
- Changing one provider usage field fails derived cost and savings verification.
- A failed quality gate prevents a savings claim even when treatment costs less.
- A baseline/treatment model mismatch prevents a paired claim unless methodology
  explicitly declares model as the experimental variable.
- A bundle with an extra, duplicate, missing, or traversal payload fails.
- A customer-supplied key mismatch fails trusted verification even if the
  embedded self-attested key validates.
- Rebuilding the same artifact set produces byte-identical ZIP output.
- The independent verifier and runtime verifier agree on golden valid and
  mutation-invalid bundles, while sharing only data fixtures and the contract.

## Final architectural rule

Execution receipts are facts.

Savings receipts are constrained claims over those facts.

Evidence bundles are portable proof packages.

Receipt chains make fact history tamper-evident.

Everything else is a view.
