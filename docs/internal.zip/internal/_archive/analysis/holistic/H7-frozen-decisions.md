# H7 — Frozen-Decisions Analysis

## Scope and method

- **Strategy authority:** `docs/internal/vision/SDK-STRATEGY-ALL-IN-ONE.md`, Part II, D-001 through D-020 (lines 3875–3948).
- **Implementation inspected:** public Rust runtime/protocol/SDK, CLI, proxy, packaging, evidence flow, README, contracts, guides, and reference documentation.
- **Vision set inspected:** `docs/internal/vision/00-NORTH-STAR.md` through `04-GO-TO-MARKET.md`.
- **Meaning of status:** **Met** = current material implementation follows the decision; **Partial** = direction/primitive exists but not the frozen product contract; **Absent** = neither contract nor implementation exists; **Violation** = current material asserts or exposes a conflicting scope/sequence.
- This is a repository-state audit, not a claim about private Thinkery/Cloud repositories that are not present here.
- “Existing code” means a working public implementation or documented user-facing command, not a proposed API printed only in the strategy.

## Executive finding

- The repository has strong building blocks for local context control, `.ctxpkg`, proxy/MCP integration, coding-agent setup, and signed evidence artifacts.
- The central future product spine—Dyno, `TuningProfileV1`, `ContextKitV1`, and one receipt path—is not yet the public implementation.
- The most material current conflicts are public multi-agent orchestration, existing marketplace/registry language, fragmented receipt/evidence exports, and `LeanCTX Cloud` branding.
- The 00–04 vision documents are directionally coherent, but they omit seven frozen decision literals/contracts and sequence the Playground alongside broad hosted/team work rather than clearly before it.

## D-001

### Frozen decision (exact)

> **LeanCTX public descriptor:**
> **The Context SDK for AI Agents.**

### Existing implementation mapping

- The public crate is an Apache-2.0 Rust in-process SDK façade: `rust/crates/lean-ctx-sdk`.
- Its actual `Engine` exposes read, search, symbol, outline, tree, and generic registered-tool calls (`engine.rs:149–257`).
- The runtime also exposes CLI, MCP, and opt-in proxy surfaces, so a context SDK substrate exists.
- `00-NORTH-STAR.md:1,9,222` already presents the chosen descriptor exactly.

### Status

**Partial.** The descriptor is correct in the new vision, but the shipped SDK is a context-engine/tool façade rather than the proposed five-primitives Context SDK.

### Violations / contradictions

- README currently leads with a broad tool/product narrative rather than the frozen descriptor.
- `rust/Cargo.toml:28` describes a long feature inventory—memory, multi-agent sharing, bandits, and 24+ tools—rather than the focused SDK position.
- README’s “84 MCP tools” scope dilutes the externally legible product identity.

### Changes required

- Make “The Context SDK for AI Agents” the README, package, docs-site, and CLI onboarding descriptor.
- Publish an explicit bridge from today’s `Engine` to the future SDK primitives, without claiming those future primitives are shipped.
- Move broad capability inventories behind the product narrative and clearly separate supporting runtime capabilities from the public product abstraction.

## D-002

### Frozen decision (exact)

> **Product promise:**
> **Tune any agent. Prove every gain.**

### Existing implementation mapping

- Local proxy, shell hooks, MCP tools, context compression, and evidence code can support portions of “tune” and “prove.”
- `lean-ctx evidence realworld` is a real multi-turn API evidence path (`rust/src/cli/dispatch/evidence.rs`).
- `ExecutionReceiptV1`, `SavingsReceiptV1`, signed bundles, and offline verification primitives exist.

### Status

**Partial.** The necessary ingredients exist, but the product promise is neither the public message nor uniformly backed by a canonical end-to-end user path.

### Violations / contradictions

- The exact promise has zero occurrences in the 00–04 vision files other than its source strategy.
- `evidence run` explicitly says provider comparison generation “is not available yet” (`evidence.rs:131–134`).
- README’s “up to 99%” and broad feature language can be read as an unbounded savings promise, contrary to the proof-qualified wording.

### Changes required

- Put the exact promise below the descriptor in public and internal product copy.
- Make the claim conditional in every placement: declared workload, matched baseline/treatment, quality gate, method, and limitations.
- Replace the placeholder `evidence run` with the Dyno-backed canonical path before marketing “prove every gain” as a shipped experience.

## D-003

### Frozen decision (exact)

> LeanCTX owns context performance, not generic agent orchestration.

### Existing implementation mapping

- The main runtime focuses on context reads, compression, cache/reuse, proxying, and MCP, all compatible with context performance.
- The Rust SDK README explicitly says it embeds the context engine and dispatches registered context tools.
- The local proxy adjusts context flowing to an existing provider request; it does not replace the customer’s model or agent loop.

### Status

**Partial with a material public-scope violation.** The core is context performance, but adjacent product surfaces market and document orchestration.

### Violations / contradictions

- README:652 advertises “84 MCP tools … to multi-agent orchestration.”
- `docs/reference/08-multi-agent.md` calls `ctx_task` “A2A task orchestration” and documents a shared task board.
- `docs/reference/appendix-mcp-tools.md` presents `ctx_task` as “Multi-agent task orchestration.”
- `rust/src/core/work_graph.rs` is explicitly a “Bounded Work Graph for multi-agent orchestration.”
- The old material makes it easy to interpret LeanCTX as an agent platform rather than a context-performance layer.

### Changes required

- Remove generic orchestration from the public product descriptor, primary README feature list, and marketing navigation.
- Either park/deprecate `ctx_task`/A2A public exposure, or narrowly reframe it as internal coordination supporting context evidence with no agent-control-plane promise.
- Add a scope test to product RFCs: no feature may own agent planning, task assignment, execution, or workflow control unless it is strictly needed for the context loop.

## D-004

### Frozen decision (exact)

> Integration taxonomy:
> 1. Attach
> 2. Wrap
> 3. Embed
> 4. Run later

### Existing implementation mapping

- **Attach:** local proxy/MCP path is real; README:259 documents `lean-ctx proxy enable`.
- **Wrap:** `lean-ctx wrap <agent>` is real for Claude, Codex, Cursor, and others (`rust/src/cli/wrap_cmd.rs:1,158,667`).
- **Embed:** `lean-ctx-sdk::Engine` provides a real Rust in-process embedding façade.
- **Run later:** no managed execution/runtime-hosting product is implemented in this repository.

### Status

**Partial.** The three technical depths exist in rough form, but they are not one formal, interoperable taxonomy and “Run later” is missing from the current vision.

### Violations / contradictions

- `00-NORTH-STAR.md` presents only Attach, Wrap, Embed; “Run later” has zero occurrences in 00–04.
- `01-PRODUCT-ARCHITECTURE.md` uses a different taxonomy: Baseline, Proxy/MCP, Native SDK, which collapses/renames Attach and Wrap.
- Current CLI `wrap` installs hooks/proxy/MCP config; it is not the proposed named lifecycle adapter with a common session/receipt contract.
- `02-OSS-VS-PAID.md` describes “Managed execution and operations” in the current capability table, without retaining the explicit later/deferred taxonomy position.

### Changes required

- Make one canonical four-state taxonomy normative in 00, 01, 02, 03, and public docs.
- Map legacy terms explicitly: Proxy/MCP = Attach; named agent adapter = Wrap; in-process lifecycle = Embed.
- Label “Run” as Thinkery-managed execution, **later**, conditional on demand, and never as a generic agent builder.
- Define the shared contract that must remain stable across Attach/Wrap/Embed: session identity, policy, profile, Kit, receipt, and degradation fields.

## D-005

### Frozen decision (exact)

> Claude Code, Codex and Cursor remain first-class.

### Existing implementation mapping

- `lean-ctx wrap` explicitly supports `claude`, `codex`, and `cursor`.
- README:275,281 and `rust/src/wrap/mod.rs:264–266` document those paths.
- The hook layer contains dedicated Cursor, Claude Code, and Codex handling.
- The current roadmap requires release smoke tests for all three (`03-ROADMAP.md:88,118,267`).

### Status

**Met for current coding-agent setup; partial for the future SDK product.**

### Violations / contradictions

- `01-PRODUCT-ARCHITECTURE.md` names initial adapter surfaces as OpenAI, Anthropic, Vercel AI SDK, LangGraph, and LiteLLM, but does not say how the three first-class coding agents map to Attach/Wrap/Embed.
- No current evidence/Dyno smoke matrix is shown as a maintained implementation artifact in the public repository.
- “First-class” is not expressed as a versioned compatibility contract with supported capability/degradation matrices.

### Changes required

- Publish a per-agent matrix: integration depth, observability limits, supported versions, install/doctor/uninstall behavior, and receipt fields marked `unobserved`.
- Make all three mandatory in CI release gates and in the initial Dyno/reference-agent evidence matrix.
- Keep support symmetric: no premium-only reliability or hidden degradation for any of the three.

## D-006

### Frozen decision (exact)

> The real-world evidence path converges into **LeanCTX Dyno**.

### Existing implementation mapping

- `lean-ctx evidence realworld` performs an actual multi-turn provider run and writes `realworld-result.json`.
- `rust/src/core/evidence_flow.rs` can materialize execution/savings receipts and generate/self-verify a signed bundle.
- `rust/src/core/evidence_report.rs` can render a customer-readable report.

### Status

**Partial.** Real-world evidence exists, but it has not converged into a single Dyno command, object model, or report contract.

### Violations / contradictions

- No `Dyno` type/command is found in runtime/protocol code; the term is vision-only.
- The user-facing `evidence run` branch is a placeholder (`evidence.rs:131–134`).
- Evidence is split among `evidence run`, `evidence workflow`, `evidence realworld`, `evidence report`, `evidence inspect`, and the separate `evidence-export` command.
- `evidence-export` assembles heterogeneous summaries and reruns synthetic/local benchmark components rather than emitting the canonical signed Dyno result.

### Changes required

- Introduce `DynoWorkloadV1`, matched arm runner, quality gate, cache/pricing record, and canonical result/receipt emitter.
- Make `evidence realworld` a backward-compatible alias or migration path to `lean-ctx dyno run`.
- Retire the placeholder behavior and route report/export/inspect through the same Dyno bundle manifest.
- Add tamper, matched-input, quality-regression, cache-attribution, and offline-verifier tests to the unified command.

## D-007

### Frozen decision (exact)

> North Star:
> **Verified cost per successful agent task.**

### Existing implementation mapping

- The repository records savings, provider usage/cost evidence, and acceptance-like quality facts in several modules.
- `00-NORTH-STAR.md:99–110` defines `VCP-SAT` precisely using provider-reported net cost divided by tasks passing a predeclared quality bar.
- `03-ROADMAP.md` makes VCP-SAT the primary metric and sets a qualified commercial threshold.

### Status

**Partial.** The metric is well specified in vision but has no identifiable canonical protocol field, calculator, dashboard/export, or acceptance contract in current code.

### Violations / contradictions

- Source search finds no `VCP-SAT` or “Verified Cost per Successful” implementation symbol outside vision.
- `README.md` and existing analytics focus on token savings, savings cards, and aggregate gains; that can reward cheap failed tasks.
- `evidence-export` reports reductions, “CPAO,” raw savings, and synthetic benchmark data instead of canonical VCP-SAT.

### Changes required

- Add a versioned `VcpSatV1` calculation to the protocol and the canonical receipt/bundle.
- Require predeclared quality gate + successful-task denominator before a VCP-SAT claim can render.
- Rework CLI/HTML/report dashboards to lead with qualified cost per accepted task, not token-reduction percentages.
- Preserve provider-reported, calculated, estimated, and reconciled costs as separate fields (see D-010).

## D-008

### Frozen decision (exact)

> `TuningProfileV1` becomes a first-class product object.

### Existing implementation mapping

- Current code has context strategies, policies, budgets, cache/reuse behavior, and benchmark profile concepts.
- Vision documents repeatedly describe a tuning profile concept and a versioned profile in future architecture.
- Existing package/profile-adjacent code can provide storage and verification ingredients.

### Status

**Absent as the frozen contract.** No `TuningProfileV1` symbol, schema, CLI create/validate/export command, or binding exists in the inspected implementation.

### Violations / contradictions

- The exact `TuningProfileV1` token has zero occurrences in 00–04, despite being a frozen decision.
- `01-PRODUCT-ARCHITECTURE.md` talks about generic “Tuning profile” but supplies no stable object schema, identity, digest, validation, or lifecycle.
- Current scattered policies/profiles cannot yet be mounted/pinned/replayed uniformly across CLI, MCP, proxy, and SDK.

### Changes required

- Define and version `TuningProfileV1` in `lean-ctx-protocol` with identity, strategy, budget, quality gate, cache/reuse, recovery, policy references, compatibility, and rollback fields.
- Implement local create, validate, inspect, export/import, pin, apply, and rollback commands.
- Include profile name/version/digest in every canonical receipt and Dyno result.
- Make adapters translate the same profile, rather than inventing per-surface settings.

## D-009

### Frozen decision (exact)

> Context Kits use `.ctxpkg`; no parallel package system.

### Existing implementation mapping

- `.ctxpkg` is a real signed, versioned package substrate with pack create/verify/publish and a lockfile.
- `rust/src/core/context_package` implements package creation, registry access, signatures, export, and auto-load.
- Guides correctly describe `.ctxpkg` as a signed distribution unit (`docs/guides/knowledge-formats.md:66–77`).

### Status

**Partial.** The technical substrate is strong, but no first-class `ContextKitV1` semantic layer is implemented over it.

### Violations / contradictions

- `ContextKitV1` and `load_kit()` are absent from code and from 00–04.
- `01-PRODUCT-ARCHITECTURE.md` calls for a `KnowledgeKit` but never says its physical distribution is `.ctxpkg`.
- Existing package docs distinguish context packages, addons, skills, and registry/marketplace structures; `docs/specs/unified-distribution-v1.md:29–56` explicitly records multiple registries/signing/marketplace surfaces awaiting convergence.
- A legacy `.lctxpkg` extension remains accepted by package code, which should be handled as compatibility only—not a second product package system.

### Changes required

- Define `ContextKitV1` as the semantic manifest embedded in or referenced by `.ctxpkg`; do not create another archive, registry, signing, or lockfile format.
- Add a protocol-level Kit verifier/loader with immutable version + digest result.
- Amend 01/02/03 to say “Context Kit uses `.ctxpkg`,” and document how existing packages migrate/validate.
- Consolidate or clearly scope addons/skills so users cannot mistake them for a competing Context Kit package system.

## D-010

### Frozen decision (exact)

> One canonical receipt/evidence path.

### Existing implementation mapping

- The protocol defines `ExecutionReceiptV1` (`execution.rs:103`) and `SavingsReceiptV1` (`savings.rs:34`).
- Canonical serialization/signature helpers and signed evidence-bundle generation exist.
- `evidence_flow` self-verifies generated bundles, and `evidence inspect` can inspect archives.

### Status

**Partial with active fragmentation.** Strong components exist, but the public command and data model have not converged on one receipt/bundle route.

### Violations / contradictions

- Separate receipt types exist: protocol `ExecutionReceiptV1`, protocol `SavingsReceiptV1`, protocol `ContextReceiptV1`, core `ContextReceiptV1`, and core `McpReceipt`.
- `evidence-export` emits six unrelated JSON files plus a markdown summary rather than an `EvidenceBundleV1` manifest.
- `evidence run` is unimplemented while workflow/realworld/export paths produce different artifacts.
- Cost vocabulary is not centrally enforced: exports mix savings, CPAO, benchmark reductions, and no-data fallbacks.

### Changes required

- Name one canonical top-level bundle and receipt schema (the strategy points to `ExecutionReceiptV1` / `EvidenceBundleV1`) and define the relationship of savings/context/MCP events as nested sections or declared supporting records.
- Funnel proxy, SDK, MCP, workflow, realworld, HTML report, export, and offline verification through it.
- Version deterministic serialization, redaction, pricing, cache, verification method, limitations, and signature behavior centrally.
- Retain legacy artifact readers only as explicitly labelled import adapters with migration tests.

## D-011

### Frozen decision (exact)

> Strong local Runtime/SDK/tuning remains OSS.

### Existing implementation mapping

- `rust/Cargo.toml:29` and `lean-ctx-sdk/Cargo.toml` declare Apache-2.0.
- The Local-Free Invariant says the local personal experience is account/license/plan-free and local capabilities must not be license-gated.
- Public runtime, MCP, proxy, CLI, package/verifier, and Rust embedding SDK are present in this repository.

### Status

**Met for today’s runtime; partial for the intended tuning product.**

### Violations / contradictions

- D-008 and D-006 are not yet shipped, so “local tuning” is not yet the complete local Dyno/Profile experience promised by the decision.
- Old documentation sometimes calls the commercial service “LeanCTX Cloud,” blurring the OSS product versus commercial operator boundary.
- Existing remote registry and cloud terminology need an explicit account-free local fallback in all product docs.

### Changes required

- Keep Dyno local mode, manual Profiles, Kit verification/loading, local receipt creation/export, and offline verification in the OSS repository.
- Add regression tests that an account, network connection, or plan cannot gate these local operations.
- Publish one concise “local capability never paywalled” matrix aligned to 02.

## D-012

### Frozen decision (exact)

> Continuous AutoTune and organization-scale intelligence are commercial.

### Existing implementation mapping

- `02-OSS-VS-PAID.md` states “Manual tuning is open. Continuous tuning is commercial.”
- It classifies hosted history, scheduled runs, AutoTune, private sync, shared receipts, governance, and fleet recommendations as Thinkery value.
- There is no present AutoTune product implementation in the inspected public Rust sources.

### Status

**Met as future boundary; absent as a shipped commercial product.**

### Violations / contradictions

- The phrase AutoTune appears in roadmap/OSS planning but has no technical contract that enforces quality, budget, approval, promotion, and rollback.
- Existing multi-agent/orchestration features in OSS could be misread as organization-scale intelligence rather than local support primitives.
- 02’s “single developer = free, organization = paid” slogan is too absolute for self-hosted/open organizational deployments; the real boundary is operated continuity/shared governance, not headcount alone.

### Changes required

- Define AutoTune as a Thinkery control-plane service that submits only explicitly approved, bounded profile candidates.
- Require quality, policy, budget, baseline, human/policy promotion, profile version, rollback, and receipt coverage for every candidate.
- Keep manual local candidate generation/replay and inspection OSS, but reserve continuous scheduling/operation/fleet intelligence for Thinkery.

## D-013

### Frozen decision (exact)

> Thinkery AG is company/commercial operator. LeanCTX remains developer-facing brand.

### Existing implementation mapping

- `00-NORTH-STAR.md` presents Thinkery as the commercial organizational layer around LeanCTX.
- `02-OSS-VS-PAID.md` names Thinkery as the paid operator.
- `04-GO-TO-MARKET.md` describes developer adoption through LeanCTX and organizational conversion into Thinkery services.

### Status

**Partial.** The new vision gets the hierarchy right, but current public material and CLI still use `LeanCTX Cloud` for the commercial account/sync experience.

### Violations / contradictions

- `rust/src/cli/cloud.rs:91,142,664,669` says “LeanCTX Cloud.”
- `docs/reference/09-team-cloud-ci.md:103` calls the cloud sync service “LeanCTX Cloud.”
- The exact “Thinkery AG” name has zero occurrences in current vision 00–04; only “Thinkery” is used.
- A developer cannot reliably infer whether remote account/billing/registry services are LeanCTX OSS adjuncts or Thinkery operations.

### Changes required

- Establish brand rules: LeanCTX = developer product/runtime; Thinkery AG = legal company; Thinkery = paid operated service/control plane.
- Rename or subtitle commercial account/sync pages and CLI messages where appropriate, while preserving migration aliases.
- Add a footer/legal/terms mapping and consistent ownership wording in README, package registry, cloud, pricing, and support docs.

## D-014

### Frozen decision (exact)

> Primary near-term B2B cash product:
> **Agent Tuning Sprint**.

### Existing implementation mapping

- `04-GO-TO-MARKET.md:260–286` describes a bounded CHF 7,500–15,000 Sprint with one agent/workflow, method, deliverables, exclusions, and conversion rule.
- `02-OSS-VS-PAID.md` classifies Agent Tuning Sprint as a Thinkery service.
- `03-ROADMAP.md` preserves Sprint selling alongside the v2 repeat loop.

### Status

**Met in the vision; absent as a current operational product surface.**

### Violations / contradictions

- README/current commercial documents still foreground tooling, cloud, packs/addons, and broad feature inventory—not a Sprint.
- No public intake, qualification, security preflight, statement-of-work, acceptance, or result-report template is identifiable outside vision.
- Pricing is a strategy hypothesis unless commercial terms and sales collateral are authorized/published.

### Changes required

- Treat the Sprint as the primary sales CTA after local proof, before platform-plan selling.
- Create private/approved operational artifacts: qualification checklist, fixed scope, data-handling preflight, baseline/treatment protocol, quality acceptance, report, and conversion decision.
- Do not imply an open-ended consulting or managed-service offer.

## D-015

### Frozen decision (exact)

> Ship a narrow real Playground before a broad cloud platform.

### Existing implementation mapping

- `04-GO-TO-MARKET.md` defines “Try Live” with Live Demo, Evidence Lite, and Hosted Evidence Run.
- Live Demo rules sensibly start with one sealed public workload through the production engine.
- Existing code includes local proxy/gateway UI, cloud login/sync, hosted registry documents, and broader team/cloud material.

### Status

**Partial with a sequencing contradiction.** A narrow real Demo is specified, but it is not isolated as the prerequisite before hosted/team/platform work.

### Violations / contradictions

- `03-ROADMAP.md` v2 bundles Pro, hosted Dyno history, profile sync, scheduled benchmarks, AutoTune credits, shared receipts, dashboard beta, private Kits, Live Demo, Evidence Lite, and hosted evidence runs together.
- That is not demonstrably “Playground before broad cloud platform”; it starts several cloud/platform capabilities at the same gate.
- 04’s three-level playground includes private hosted evidence, which risks becoming a broad cloud workflow before the narrow public Demo proves demand.
- Existing `LeanCTX Cloud`, hosted registry, and team/cloud documentation predate any narrow Playground as the primary customer-facing proof.

### Changes required

- Make Phase/Release 1 of Playground only: one rate-limited sealed workload, production engine path, declared method, and downloadable evidence.
- Set explicit proof gates (completion, install conversion, verifier use, cost ceiling) before Evidence Lite, BYOK hosted runs, accounts, dashboards, or scheduled jobs.
- Rewrite v2 ordering so cloud controls are gated after the narrow Playground has earned them.

## D-016

### Frozen decision (exact)

> Managed Relay is later.

### Existing implementation mapping

- The public repo has a local opt-in proxy/sidecar, not a hosted managed relay.
- `02-OSS-VS-PAID.md` classifies a managed relay as Thinkery and says “if ever introduced.”
- `03-ROADMAP.md` parks it in v2 and allows v4 only if customer demand earns it.

### Status

**Met in current code and mostly met in vision.**

### Violations / contradictions

- 02’s capability table places Managed relay alongside active product modules; the “later” qualifier is easy to miss.
- Existing cloud/proxy wording can confuse a locally managed daemon/service with a Thinkery-managed relay.
- No customer-demand gate, threat model, pass-through disclosure contract, or cost model is attached in current implementation.

### Changes required

- Keep local proxy terminology separate from any future Managed Relay.
- Retain a hard roadmap gate: repeated paid demand, direct/BYOK path still available, transparent pass-through/infrastructure pricing, and explicit data/retention controls.
- Do not add relay account dependencies to Attach, Wrap, or Embed.

## D-017

### Frozen decision (exact)

> Managed Execution is later and is not a generic Agent Builder.

### Existing implementation mapping

- No public managed execution runner is identified in the repository.
- `00-NORTH-STAR.md` parks both generic agent builder and hosted-agent platform.
- `03-ROADMAP.md` parks default agent-execution hosting in v3 and forbids Thinkery orchestration in v4.

### Status

**Met in code; ambiguous in current vision wording.**

### Violations / contradictions

- `02-OSS-VS-PAID.md` table lists “Managed execution and operations” as Thinkery paid without a later/deferred label.
- `04-GO-TO-MARKET.md` sells Team “up to five managed agents” and Business “up to 25 managed agents”; this must mean managed context operation, not hosted execution, but is undefined.
- D-003’s existing public A2A task-orchestration material makes the non-Agent-Builder boundary less credible.

### Changes required

- Rename “managed agents” to “managed context integrations/workflows” unless Thinkery actually executes customer agents.
- Put Managed Execution in a later, demand-earned roadmap phase with a strict non-goal: no arbitrary agent construction, workflow builder, model hosting, or customer control-flow ownership.
- If built later, require customer-owned agent logic, BYOK/direct option, bounded runtime contract, receipts, portability, and exit/export path.

## D-018

### Frozen decision (exact)

> Marketplace is deferred.

### Existing implementation mapping

- The product already has `.ctxpkg` publishing/registry support and add-on/pack publication commands.
- `docs/guides/publishing-packages.md` directs publication to `ctxpkg.com`.
- `docs/specs/unified-distribution-v1.md` describes existing marketplace/catalog convergence work.

### Status

**Violation in current code/docs; correctly deferred in 00–04 planning.**

### Violations / contradictions

- Existing package/addon documentation describes a hosted registry and marketplace.
- `docs/guides/addons.md` explicitly frames addons as trustworthy in “the marketplace.”
- `docs/specs/unified-distribution-v1.md:29–56` documents multiple marketplace/registry/signing systems.
- `00-NORTH-STAR.md:214` and `03-ROADMAP.md:125,172,214,255` park/defer marketplaces, so the new vision conflicts with the visible product narrative.

### Changes required

- Freeze new marketplace discovery, monetization, ranking, and social distribution work.
- Retain only necessary package transport, verification, and direct install—label it registry/distribution infrastructure, not a Marketplace.
- Hide/de-emphasize marketplace language and CTAs until a proven deployment loop has earned the decision to resume it.
- Consolidate package trust systems as D-009 requires, but do not treat technical convergence as authorization to launch a marketplace.

## D-019

### Frozen decision (exact)

> Competitive strategy:
> own the workload → context strategy → outcome → evidence → retuning loop.

### Existing implementation mapping

- `00-NORTH-STAR.md` gives a compatible loop: observe, select, tune, compare, validate, prove, deploy, repeat.
- `04-GO-TO-MARKET.md` guides local Dyno/Receipt adoption through a bounded paid proof and continuous operation.
- Existing real-world evidence, context packages, proxy, and local runtime provide partial stages of the loop.

### Status

**Partial.** The strategy is strongly articulated in vision, but end-to-end product objects do not yet make the loop executable as one system.

### Violations / contradictions

- Current README competes on tool count, many agents, broad context features, and large token-savings claims rather than owning a specific workload proof loop.
- Dyno, `TuningProfileV1`, `ContextKitV1`, VCP-SAT, and canonical receipt convergence are missing, breaking several loop links.
- “Retune” is mostly prose; continuous retuning is appropriately commercial/future but lacks an explicit local-to-managed handoff contract.

### Changes required

- Make workload manifests, matched baseline/treatment, profile, quality gate, receipt, deployment decision, and drift/retune trigger the core product record chain.
- Use this chain, not generic benchmark claims, in comparisons and sales materials.
- Give every installed integration a clear path from local workload evidence to manual replay, then to opt-in Thinkery continuous operation.

## D-020

### Frozen decision (exact)

> Any new material feature must state:
> - user,
> - context problem,
> - measurable outcome,
> - product-loop step,
> - OSS/commercial classification,
> - displaced current work.
>
> No answer → no implementation.

### Existing implementation mapping

- The roadmap has evidence gates, explicit parks, and revenue gates.
- 02 contains a useful OSS/Thinkery classification table.
- 00 has a product-test question: connect, measure, tune, prove, deploy, or repeat.

### Status

**Absent as an enforceable admission control.**

### Violations / contradictions

- All six exact admission fields have zero occurrences in 00–04 as a feature template or required checklist.
- Roadmap v2/v3 deliverables list many material features without an explicit user, context problem, measurable outcome, loop step, classification, and displaced work per item.
- Existing broad additions—marketplace, A2A orchestration, cloud sync, addons—show why an auditable admission gate is needed.

### Changes required

- Add a mandatory product/RFC template with the six frozen fields and a final “no answer → no implementation” decision.
- Require the template in issue/PR labels or acceptance checklist for material code, product documentation, and commercial capability changes.
- Include a named owner and evidence source for every claimed measurable outcome.
- Audit the active roadmap backlog and explicitly park/displace work that cannot pass the gate.

## Cross-decision implementation map

| Product layer | What exists now | Frozen-contract gap |
| --- | --- | --- |
| Local context runtime | Rust CLI/MCP/proxy, cache/compression, policies, Apache-2.0 | Needs a product-oriented session/profile/receipt surface |
| Attach | Local proxy and MCP path | Formal Attach contract and evidence semantics |
| Wrap | Agent setup wrapper for coding agents | Named lifecycle adapters and common session contract |
| Embed | Rust `Engine` façade | `LeanCTX()` / `session()` product SDK, multi-language bindings |
| Context package | Signed `.ctxpkg`, lockfile, registry tooling | `ContextKitV1` semantics over the one package system |
| Evidence | Receipts, signing, bundle/report primitives, real-world command | One Dyno-first receipt/bundle/user flow |
| Tuning | Strategies, budgets, policies, benchmark profiles | First-class `TuningProfileV1` lifecycle |
| Metric | Savings, costs, quality-related artifacts | VCP-SAT protocol field and canonical rendering |
| Commercial | Cloud/registry/team material, service planning | Thinkery brand/operator boundary and demand-gated sequencing |
| Scope control | Local proxy does not replace agent logic | Remove/reframe generic A2A orchestration and marketplace scope |

## Current vision files 00–04: decision-respect audit

### Overall verdict

The set respects the strategic direction but does **not** fully respect all 20 frozen decisions as a normative contract. It is strongest on local-first OSS, evidence discipline, Thinkery commercial operation, Sprints, and deferring agent builders/marketplaces. It is weakest on exact promise/terminology, Kit/Profile contracts, integration taxonomy, sequencing, and feature admission governance.

### Per-decision matrix

| Decision | 00–04 result | Evidence / contradiction | Required documentation correction |
| --- | --- | --- | --- |
| D-001 | **Respected** | 00 title and external language use descriptor | Repeat in shared document preamble and public migration plan |
| D-002 | **Omitted** | Exact promise has zero occurrences | Put exact promise under descriptor with qualified-claim rule |
| D-003 | **Mostly respected** | 00 parks generic Agent Builder/hosted platform | Add an explicit “not agent orchestration” non-goal across 01/03/04 |
| D-004 | **Partial** | 00 has Attach/Wrap/Embed; 01 uses another taxonomy; Run later absent | Make four-state taxonomy normative and map legacy terms |
| D-005 | **Respected** | 00/02/03/04 name all three and 03 requires smoke tests | Add a capability/version matrix in 01 |
| D-006 | **Mostly respected** | Dyno is central in 00/02/03/04 | State migration from `evidence realworld` explicitly in architecture/roadmap |
| D-007 | **Respected** | 00 and 03 define VCP-SAT | Add protocol/receipt realization gate to 01/03 |
| D-008 | **Partial** | Generic profiles described, `TuningProfileV1` absent | Name schema/identity/digest/rollback contract directly |
| D-009 | **Violation by omission** | `.ctxpkg` has zero occurrences in 00–04 | State Context Kit uses `.ctxpkg`, no parallel system |
| D-010 | **Mostly respected** | 00/01 require one Receipt schema/engine | Add migration from existing multiple receipt/evidence artifacts |
| D-011 | **Respected** | 00/02/03 protect local account-free runtime/SDK/Dyno/receipt | Name local Profile/Kit/Dyno contract as OSS deliverables |
| D-012 | **Respected** | 02 commercializes continuous tuning; 03 stages it | Preserve approval/budget/rollback language in any pricing copy |
| D-013 | **Partial** | Thinkery is commercial layer; exact Thinkery AG absent | Add legal/company versus product/operator brand rule |
| D-014 | **Respected** | 02/03/04 make Sprint bounded cash offer | State it is the **primary near-term** offer in 03 and top GTM summary |
| D-015 | **Sequencing conflict** | v2 ships Live Demo beside accounts/history/dashboard/hosted work | Make narrow public Playground a prior gated release |
| D-016 | **Mostly respected** | 02 says if ever; 03 parks then v4 demand-gates | Mark as later in all tables and separate local proxy wording |
| D-017 | **Ambiguous** | 00/03 park it, but 02 says managed execution and 04 says managed agents | Define terms and clearly defer managed execution |
| D-018 | **Respected in future plan** | 00/03 park marketplace | Reconcile existing registry/marketplace docs; call technical transport non-marketplace |
| D-019 | **Respected** | 00 loop and 04 final GTM test match it | Use exact workload→strategy→outcome→evidence→retune wording in competitive guidance |
| D-020 | **Omitted** | No six-field feature-admission template; many feature lists | Add mandatory template and roadmap audit |

### File-specific contradictions and omissions

#### `00-NORTH-STAR.md`

- Correctly anchors D-001, D-003, D-005, D-007, D-010, D-011, D-013, D-018, and D-019.
- Omits D-002’s exact promise.
- Reduces D-004 to three integration depths; “Run later” is absent.
- Uses “kit format” but never commits to `.ctxpkg` (D-009).
- Uses generic tuning profile language, not `TuningProfileV1` (D-008).
- Its product-test table is helpful but does not satisfy all six D-020 feature-admission fields.

#### `01-PRODUCT-ARCHITECTURE.md`

- Strongly supports D-003’s existing-agent boundary and D-010’s unified receipt intent.
- Uses Baseline/Proxy-MCP/Native-SDK instead of frozen Attach/Wrap/Embed/Run-later taxonomy (D-004).
- Describes future public APIs as if precise contracts, while today’s `lean-ctx-sdk` exposes `Engine` context-tool calls, not `LeanCTX`, sessions, Kits, Profiles, and receipts.
- Names neither `.ctxpkg` nor `TuningProfileV1` (D-008/D-009).
- Does not map Codex/Cursor/Claude Code into its declared adapter/depth model (D-005).

#### `02-OSS-VS-PAID.md`

- Strongest document for D-011 and D-012; its local-free commitments are aligned with the frozen OSS boundary.
- Says “Managed execution and operations” in a present matrix, weakening D-017’s “later” posture.
- Uses “Single developer = free, organization = paid,” which should be refined to an operated-value boundary.
- Calls for open Kit format/verifier without saying it is `.ctxpkg` (D-009).
- Mentions manual profiles but does not establish the `TuningProfileV1` object (D-008).

#### `03-ROADMAP.md`

- Strongly supports first-class coding-agent compatibility, Sprint discipline, relay deferral, marketplace deferral, and quality/evidence gates.
- v2 conflates narrow Playground proof with hosted history, scheduled benchmarks, AutoTune credits, dashboard, roles, private Kits, and shared receipts; this violates D-015’s explicit ordering.
- v3/v4 avoid generic execution but require a definition for “managed agents” so D-017 cannot drift.
- Roadmap entries lack a D-020 per-feature admission record and displaced-work decision.
- It should include explicit P0 tasks for `TuningProfileV1`, `ContextKitV1`/`.ctxpkg`, VCP-SAT, and canonical receipt convergence.

#### `04-GO-TO-MARKET.md`

- Strongly supports D-006, D-014, D-019, measurable pilot qualification, and bounded evidence claims.
- “Try Live” is valuable, but three levels immediately include Evidence Lite and Hosted Evidence Run; the narrow first Playground needs an explicit separate launch gate (D-015).
- Team/Business “managed agents” wording is ambiguous under D-017.
- It should use the exact D-002 promise and the Thinkery AG/LeanCTX naming hierarchy.
- It should require the D-020 six-field gate before promising a new GTM surface, plan, integration, or service.

## Priority remediation order

1. **Make the boundary visible:** update README/public docs to D-001/D-002/D-003/D-013; remove multi-agent orchestration and marketplace-led positioning.
2. **Converge proof:** turn `evidence realworld` into Dyno, eliminate the `evidence run` placeholder, and designate one canonical receipt/bundle path.
3. **Create portable tuning objects:** implement `TuningProfileV1` and `ContextKitV1` on `.ctxpkg`, then include pinned digests in every receipt.
4. **Protect the product sequence:** ship one narrow measured Playground before accounts, dashboard, hosted evidence, or broad platform expansion.
5. **Enforce scope continuously:** add D-020 admission checks to roadmap/RFC/issue/PR process and audit existing orchestration/marketplace/cloud work against them.

## Acceptance criteria for closing this audit

- The external descriptor and promise are exact, qualified, and consistent in README, docs, CLI onboarding, and website copy.
- Codex, Cursor, and Claude Code have published, tested Attach/Wrap/Embed capability matrices and uninstall paths.
- `lean-ctx dyno run` produces one signed, offline-verifiable canonical bundle with quality, cost vocabulary, limitations, profile, Kit, and VCP-SAT facts.
- `TuningProfileV1` and `ContextKitV1` are versioned OSS objects; Kits use `.ctxpkg` only.
- Thinkery naming and paid boundaries are consistent; local functionality remains account-free and portable.
- Managed Relay, Managed Execution, and Marketplace remain visibly deferred until their stated proof/demand gates are met.
- Every new material feature includes all six D-020 fields and explicitly names the work it displaces.

