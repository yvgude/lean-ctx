# H8 — Definitive Anti-roadmap

**Decision date:** 2026-08-20  
**Owner:** Product / SDK v1.0  
**Status:** Binding until a stated re-entry gate is met

## The rule

LeanCTX is not a generic AI platform.

The only product loop worth funding is:

```text
Connect → Measure → Tune → Prove → Deploy → Repeat
```

The customer-facing proof is a supported agent whose accepted outcome is
preserved or improved while context economics are measurably better.

The binding test from `06-NOT-TO-DO.md` is stricter:

> If work does not advance a supported agent from integration to a
> quality-gated, verifiable receipt, park it.

"Interesting," "strategic," "demoable," and "we already wrote some code" do
not pass this test.

## Operating policy

| Class | Meaning | Default action |
|---|---|---|
| **Core now** | Directly closes the v1 SDK pilot loop. | Build, test, document. |
| **Later** | Could improve the loop, but lacks paid repeated demand. | Freeze public surface; no net-new scope. |
| **Enterprise-only** | Needs organizational contract, operations, or controls. | Isolate behind an explicit commercial feature boundary. |
| **Park** | Does not serve the loop or creates a second primary job. | No roadmap, no marketing, no new code. |
| **Deprecate** | Existing code actively embodies parked scope. | Stop extension; measure reachability; remove or archive. |

No exception is granted by implementation age, sunk cost, an internal demo, or
a speculative partner conversation.

## Re-entry protocol

Every parked item remains parked until all applicable gates are evidenced.

1. A named, paying customer asks for the capability in the same agent workflow.
2. The request has a written connection to one loop stage above.
3. The local SDK/reference-wrapper path has already succeeded for that customer.
4. The new scope has an accountable support and security owner.
5. Its acceptance criterion produces a redacted, reproducible receipt.
6. The work is funded and does not displace a current SDK exit criterion.
7. A product decision records the evidence, narrow boundary, expiry, and rollback.

One prospect request is not a demand signal.

An integration request without an observed quality or economics improvement is
not a demand signal.

An enterprise questionnaire is not a product requirement until it sits inside a
signed contract with delivery and support ownership.

## Absolute no-build list — product scope

The following items are explicitly prohibited by Strategy Part III and/or the
SDK v1.0 not-to-do decision. Each row is independently parked.

| Do not build | Why this is a no | Reconsider only when |
|---|---|---|
| Generic Agent Builder | Replaces context-performance work with agent authoring. | Repeated paid demand ties agent creation directly to verified context economics. |
| Workflow canvas | Makes LeanCTX a visual orchestration product, not an SDK. | A named buyer funds a narrow UI that operates a proven SDK loop and owns support. |
| CRM automation | Starts a vertical automation business with CRM permissions, support, and compliance. | A customer funds a CRM workflow whose measurable bottleneck is context economics. |
| Voice platform | Adds realtime media, latency, telephony, privacy, and reliability obligations. | A signed customer proves an agent-quality/context ROI case and funds the full operating surface. |
| Template zoo | Optimizes for catalog breadth and content maintenance instead of one supported reference wrapper. | Several externally maintained canonical kits exist with compatibility and deprecation owners. |
| Generic browser-agent product | Creates a separate autonomy, browsing, safety, and web-execution product. | A paid customer proves browser execution is essential to the same measured agent loop. |
| Marketplace | Requires publisher ownership, provenance, review, compatibility, support, revocation, and deprecation. | Canonical kit contracts exist and several external kits are actively maintained. |
| Provider marketplace | Competes as a provider/reseller ecosystem rather than proving context value. | BYOK SDK integrations demonstrably fail a named paid customer use case. |
| Own model | Diverts capital to model training, evaluation, inference, model risk, and model distribution. | Customer evidence shows SDK-level context optimization cannot meet the outcome without a funded model program. |
| Large hosted execution fleet | Makes LeanCTX responsible for customer workloads, SLOs, incident response, and operations. | A customer funds hosted operation after local SDK success and a dedicated operations owner exists. |
| Unified billing | Entangles the SDK with payments, usage attribution, taxes, disputes, and provider resale. | The end-to-end acceptance, verification, invoicing, and payment chain already works. |
| Every framework adapter | Fragments and weakens the contract before the reference wrapper earns external proof. | The OpenAI Agents SDK reference wrapper has evidence plus repeated, specific pull for one next adapter. |
| Complete enterprise dashboard | Creates a multi-user product, ongoing UI program, and control-plane promise. | A paying organization needs shared continuous operation after a successful pilot. |
| Complete fleet scheduler | Converts evidence/tuning into a hosted orchestration and reliability problem. | Paid repeated tuning demand exists, operations are funded, and the scheduler is bounded to a proven loop. |
| New package format | Splits the ecosystem and creates migration, tooling, signing, registry, and compatibility debt. | Existing kit/package contracts demonstrably block a paid customer workflow. |
| Big-bang repository migration before proof | Consumes delivery capacity without producing customer evidence. | A small migration is a hard prerequisite to a contracted pilot and has a staged rollback plan. |
| Zapier/n8n-style automation | Competes on connector breadth rather than better context for an existing agent. | One connector measurably improves SDK activation or evidence in a paid workflow. |
| Connector catalogue | Becomes a permanent compatibility and credential-support obligation. | A narrow connector is shown to increase activation or receipt production, with an owner. |
| Playground | Risks a simulated result that weakens the credibility of the real evidence claim. | It executes the identical engine and evidence path on a bounded public workload. |
| Marketing simulator | Produces persuasion artefacts rather than verifiable receipts. | It is a transparent view of real receipts, not an alternate calculation path. |

## Absolute no-build list — organization, cloud, and commercial scope

These are not "platform foundations." They are organization-scale commitments
that are forbidden before paid demand is real.

| Do not build or promise | Why this is a no | Reconsider only when |
|---|---|---|
| Control plane | Requires durable shared operations, authorization, policy administration, and incident ownership. | A paying customer needs shared continuous operation after pilot success. |
| Team dashboard | Needs multi-user data semantics, roles, retention, support, and UI ownership. | The same paid organization needs it to operate an already successful loop. |
| Fleet controls | Implies remote execution authority, rollout safety, and operations responsibility. | A paid fleet use case has a named ops owner and explicit rollback controls. |
| Central evidence service | Creates retention, access, provenance, privacy, and availability obligations. | A contracted organization cannot use local/redacted evidence and funds the service. |
| Organization policies | Requires identity, governance, enforcement semantics, and support across users. | A signed customer requires named policies for a deployed pilot. |
| Central budgets | Starts financial controls and allocation support beyond SDK proof. | Shared continuous operation is paid for and budget semantics are contractually specified. |
| AutoTune | Promises autonomous optimization beyond a bounded, observable evaluation loop. | Repeat tuning demand is real and the paid operating model, safety limits, and rollback are defined. |
| Hosted experiments | Requires run scheduling, isolation, storage, cost controls, and experiment support. | A customer pays for repeated operation after local/offline evaluation proves value. |
| Scheduled experiments | Makes LeanCTX accountable for unattended execution and missed-run reliability. | A funded operational owner accepts the SLO and failure model. |
| Private profile sync | Adds identity, synchronization, conflict, retention, and privacy surface. | A signed organization requires shared profiles for a proven workflow. |
| SSO | Is an organizational access-control commitment, not pilot functionality. | Required by a signed organizational contract. |
| SCIM | Requires lifecycle synchronization and operational correctness across identity systems. | Required by a signed organizational contract with testable provisioning requirements. |
| RBAC | Needs a durable authorization model and audit semantics. | Required by a signed organizational contract. |
| Multi-tenant service | Requires tenant isolation, limits, incident response, and data governance. | A funded buyer requires it and the security/operations model is staffed. |
| Retention platform | Creates legal, privacy, deletion, retrieval, and support obligations. | A signed contract defines retention obligations that local artifacts cannot meet. |
| Audit workflow | Becomes a productized governance process instead of local proof tooling. | A signed customer contract requires it and the audit evidence model is accepted. |
| Checkout | Starts tax, payment, fraud, refund, and customer-support responsibility. | The verification-to-invoice-to-payment chain succeeds end to end. |
| Billing and entitlements | Adds commercial enforcement and account administration before value is accepted. | The acceptance, verification, invoice, and payment chain works end to end. |
| Automated savings settlement | Creates disputable financial commitments from measured savings. | Acceptance criteria, verification, invoices, and payment are proven end to end. |
| Managed relay | Makes LeanCTX a hosted data path with availability and privacy commitments. | BYOK integration is insufficient for a named customer need and the relay is funded. |
| Unified provider billing | Makes LeanCTX responsible for provider metering, attribution, payment, and support. | BYOK is proven insufficient for an identified customer and commercial operations exist. |
| Model resale | Starts a reseller business with commercial, provider, and usage-risk exposure. | A named customer need survives a BYOK alternative and funds the operating model. |
| Self-hosted enterprise offering | Multiplies release, support, security, upgrade, and compatibility burden. | A qualified buyer makes it a funded purchase requirement with support ownership. |
| Air-gapped release | Adds offline dependency, signing, update, and support requirements. | A qualified buyer funds it as a hard purchase requirement. |
| Kubernetes deployment | Adds production platform support and a broad compatibility matrix. | A qualified buyer funds it with a defined support boundary. |
| Multi-region deployment | Adds distributed data, consistency, availability, and incident complexity. | A paid contract requires it and operations own the SLO. |
| Enterprise compliance claims | A claim without available controls, evidence, support, and contractual commitment is a liability. | Controls, evidence, support, and contractual commitments are actually available. |

## What is allowed now

Only the following work clears the anti-roadmap filter.

- Local Runtime correctness, safety, performance, and supported CLI/MCP paths.
- The v1.0 SDK contract and one reference wrapper/agent.
- Local Kits that serve that one customer workflow rather than a marketplace.
- Local evidence and receipt tooling.
- Quality evaluation, offline verification, rollback/uninstall, and pilot release compatibility.
- Customer-specific hardening only if redacted and reproducible, with a regression test or documented contract decision.

Quality evaluation is allowed because it measures and proves the loop.

Offline verification is allowed because it makes the receipt credible.

Rollback and uninstall are allowed because a deployed SDK must fail safely.

Everything else carries the burden of proof.

## Existing code already on the anti-roadmap

`A1-codebase-map.md` shows a large amount of code that creates platform-shaped
surface area. Its existence is evidence for containment, not authorization for
future investment.

The following classifications are deliberately severe. "Park" means no
feature work, no documentation promotion, no default installation, and no
public product claim. "Deprecate" means prepare deletion after an explicit
reachability and replacement audit.

| Existing code / inventory evidence | Why it violates or exceeds v1 | Decision |
|---|---|---|
| `rust/src/core/buddy/` — 9 files / 1,888 LOC; `core/godot/` — 2 / 128 | Pet, RPG, sprite, mascot, and Godot logic are unrelated to customer context receipts. | **Deprecate.** Remove from default build and product surface; delete after reachability audit. |
| `rust/src/dashboard/` — dashboard CLI plus a 1,034-line root module and static cockpit assets | A dashboard is the prohibited enterprise/team UI unless it is a minimal local receipt viewer. | **Park.** Retain only a local, read-only receipt view that uses the real evidence path. |
| `rust/src/core/workflow/` — 4 files / 450 LOC | General workflow definitions/orchestration is the workflow-canvas trajectory in code form. | **Deprecate.** Keep a narrowly named internal pilot sequence only if the reference wrapper calls it. |
| `rust/src/core/a2a/` — 15 files / 3,312 LOC, including relay, remote transport, DLQ, rate limiter, agent cards | Agent-to-agent transport and relay machinery is a hosted execution/platform foundation, not a context SDK. | **Park.** No new remote execution capability; isolate or delete unused transport paths. |
| `rust/src/core/agents/` — 9 files / 1,844 LOC, registry, leases, directives, presence, bus | A multi-agent registry and coordination bus is agent-platform/control-plane surface. | **Later.** Keep local development coordination only; no customer-facing registry, tenancy, or fleet controls. |
| `rust/src/core/mcp_catalog/` — 17 files / 3,294 LOC, catalog, client, pool, router, adapters | A remote catalog and adapter pool trends toward connector catalogue/marketplace ownership. | **Park.** Allow only connectors required by the reference workflow; no public discovery catalogue. |
| `rust/src/core/addons/` — 29 files / 8,323 LOC, including commerce, publish, registry, revocation, store | Publishing, commerce, registries, and stores are marketplace infrastructure. | **Deprecate marketplace paths.** Preserve local signed grammar/addon loading only if SDK-critical. |
| `rust/src/core/plugins/` — 6 files / 1,582 LOC, registry, manifests, executor, sandbox | A generic plugin ecosystem is a second platform and expands compatibility/support obligations. | **Park.** No plugin marketplace or broad public plugin API in v1. |
| `rust/src/core/context_package/` — 19 files / 6,773 LOC, import/export, remote, registry, lockfile, signing | This is a new package format plus registry/remote distribution apparatus. | **Deprecate remote/registry/export ambitions.** Keep only the smallest local Kit contract necessary for the pilot. |
| `rust/src/core/context_snapshot/` — 8 files / 1,660 LOC, publish, restore, signing, timeline | Publication/timeline features drift into synchronized platform state. | **Later.** Keep local rollback/restore; park publish and shared-timeline scope. |
| `rust/src/core/billing/` — 5 files / 2,724 LOC and `settlement_evidence/` — 2 / 2,114 | Metering, plans, commercial entitlements, settlement evidence, and savings accounts pre-build billing/settlement. | **Deprecate commercial paths.** Retain local cost measurement only; do not gate local features by plan. |
| `rust/src/core/finops_export/` — 5 files / 1,093 LOC | Financial export formats move from proof to enterprise cost-management product. | **Enterprise-only.** No broad export promises until a contracted organization needs them. |
| `rust/src/core/gain/` — 8 files / 2,837 LOC and `savings_ledger/` — 10 / 4,849 | Live pricing, savings ledger, outcome scoring, and value accounting can become automated settlement. | **Later.** Keep transparent local measurement; prohibit financial claims, invoices, or automated payout. |
| `rust/src/core/compliance_report/` — 5 files / 1,567 LOC, including PDF rendering | Formal compliance reports invite unsupported enterprise compliance claims. | **Enterprise-only.** Use as internal evidence export only; no certification/claim language. |
| `rust/src/core/compliance.rs`, `provenance/`, `trust/`, `value_gate/` | Governance and compliance vocabulary can turn pilot evidence into a premature assurance product. | **Later.** Retain evidence integrity; park policy/audit workflow and external claims. |
| `rust/src/core/policy/org/` — 4 files / 604 LOC | Organization policy models/stores are direct organization control-plane scope. | **Enterprise-only.** No activation absent a signed organizational contract. |
| `rust/src/core/config/enterprise.rs` | An explicit enterprise config surface risks promising an offering not yet sold or supported. | **Enterprise-only.** Hidden/off by default; document no capability claims. |
| `rust/src/core/ocla/` — 64 files / 20,621 LOC, scheduler service/client and connector scheduler | The largest subsystem includes scheduling and connector lifecycle beyond a narrow local SDK proof. | **Split.** Keep stable local contracts and receipt primitives; park scheduler/service/remote-control paths. |
| `lean-ctx-protocol` exposes `control_plane`, `fleet_control`, `auto_routing`, `rollout`, `value_share` | Public wire contracts prematurely encode prohibited control-plane, fleet, AutoTune, rollout, and settlement ideas. | **Freeze/deprecate.** Do not add consumers; mark experimental/non-v1 and set removal/review dates. |
| `rust/src/core/eval_ab/` — 15 files / 4,913 LOC; `benchmark_study/` — 19 / 2,077 | Evaluation is core, but hosted/scheduled experimentation and broad lab frameworks are not. | **Later.** Keep offline, reproducible evaluation tied to receipts; park unattended experiment service. |
| `rust/src/core/quality_lab/` — 5 files / 1,380 LOC | A lab can become a playground/marketing simulator if it has a separate calculation path. | **Park public surface.** It may remain only when it exercises the production engine and evidence contract. |
| `rust/src/core/providers/` — 20 files / 6,250 LOC, including OAuth, health, execution adapters | Provider execution, OAuth, and broad adapters can become provider marketplace or managed relay. | **Later.** Limit to BYOK integrations required by the reference wrapper. |
| `rust/src/proxy/` and `proxy_setup/` | A local interception proxy is core; extending it into a managed relay is forbidden. | **Keep local only.** No hosted forwarding, unified billing, or provider resale. |
| `rust/src/core/web/` — 10 files / 3,998 LOC, feed, fetch, PDF, YouTube, rewrite | Broad web ingestion is browser-agent/vertical-agent gravity unless strictly used for context retrieval. | **Park expansion.** Retain only safe retrieval needed by a supported agent. |
| `rust/src/core/skillify/` — 4 files / 741 LOC | Skill generation/packaging can become the prohibited template zoo. | **Later.** Keep one internal workflow kit; no generated public template catalogue. |
| `rust/src/kits/`, CLI `kit`/`kits`, `pack`, addon commands | Local Kits are allowed; a store, publisher, or distribution catalogue is not. | **Keep local only.** No registry, store, commerce, or external publisher program. |
| `rust/src/core/neural/` — 6 files / 1,548 LOC and optional neural backends | Learned context ranking may be valid; a road to "own model" is not. | **Later.** No training/inference product, model hosting, or model marketing. |
| CLI commands `team`, `dashboard`, `enterprise`, `billing`, `finops`, `provider`, `serve`, `watch`, `demo` | The top-level CLI exposes more platform surface than the v1 customer loop needs. | **Quarantine.** Mark experimental/internal, remove from default help, and avoid documentation promotion. |

## Mandatory containment actions for existing violations

1. Add an owner and a **Core now / Later / Enterprise-only / Park / Deprecate**
   label to every subsystem above.
2. Remove **Park** and **Deprecate** subsystems from default product narratives,
   demos, onboarding, and default CLI help.
3. Freeze public APIs and wire-contract additions for parked concepts.
4. Add a reachability report before deleting code; preserve only dependencies
   proven necessary to Connect, Measure, Tune, Prove, Deploy, or Repeat.
5. Default-disable remote, hosted, commercial, registry, scheduler, and
   organization features.
6. Put each retained enterprise feature behind an explicit non-default feature
   boundary with no implied support commitment.
7. Delete code that has no reference-wrapper path, receipt path, test user, or
   funded re-entry evidence.
8. Do not refactor dead platform code "for later." That is investment.
9. Do not create compatibility promises for APIs designated experimental,
   parked, deprecated, or enterprise-only.
10. Never use an anti-roadmap subsystem to justify a sales or compliance claim.

## Features specifically marked enterprise-only or later

These are not v1 promises. They must not be presented as available platform
capabilities to ordinary SDK users.

| Feature | Label | Allowed boundary before demand gate |
|---|---|---|
| Organization policy and policy store | Enterprise-only | Internal models only; no organization-management UX or service. |
| Enterprise configuration | Enterprise-only | Off by default; no public support or compliance claim. |
| Compliance report/PDF generation | Enterprise-only | Internal pilot evidence export with a clear non-certification disclaimer. |
| FinOps export | Enterprise-only | One contracted customer format after data handling review. |
| Central evidence, retention, audit workflow | Enterprise-only | None; local redacted artifacts only. |
| SSO, SCIM, RBAC, tenancy | Enterprise-only | None; do not build partial identity controls. |
| Self-hosted, air-gapped, Kubernetes, multi-region | Enterprise-only | None; funded purchase requirement and support plan required. |
| Billing, plans, entitlements, settlement | Later | Local measurement only; no financial enforcement. |
| Savings ledger, live pricing, ROI/value reports | Later | Transparent local estimates attached to a receipt, never settlement. |
| OCLA scheduler/service and fleet control | Later | Local, explicit invocation only; no unattended or fleet service. |
| Profiles, private sync, AutoTune | Later | Local config and human-approved tuning only. |
| A/B and quality lab execution | Later | Offline reproducible evaluation only. |
| Provider OAuth, adapter breadth, remote MCP catalog | Later | BYOK adapter needed by the reference wrapper only. |
| Plugins, addons, kit packaging | Later | Local trusted components only; no publisher/store/registry program. |
| Neural/learned ranking | Later | Deterministic, measured local enhancement; no model product. |
| Dashboard | Later | Minimal local receipt inspection only; no team or fleet UI. |

## Decision test for every pull request

Before implementation, the author must answer all three questions from the
not-to-do decision in the PR description.

1. Which Week 2 SDK exit criterion does this close?
2. Which customer-workflow artifact will this produce or improve?
3. Why can this not wait until a paid organization-scale need exists?

If any answer is absent, the task is not "backlog." It is parked.

The reviewer must also state the loop stage:

| Loop stage | Acceptable work | Rejection trigger |
|---|---|---|
| Connect | Integration contract, one wrapper, BYOK setup, safe local installation. | Adds a broad framework, provider, or connector catalogue. |
| Measure | Deterministic telemetry, costs, quality baselines, local receipts. | Adds pricing, settlement, entitlement, or central-finance workflow. |
| Tune | Bounded human-approved configuration and deterministic optimization. | Adds autonomous scheduling, AutoTune service, profiles sync, or fleet control. |
| Prove | Offline verification, outcome preservation, provenance, rollback evidence. | Adds unsupported compliance claims, audit products, or a fake simulator. |
| Deploy | Local release compatibility, safety, uninstall, reference-wrapper delivery. | Adds hosted execution, relay, multi-tenant, Kubernetes, or multi-region operations. |
| Repeat | Re-run the same accepted workflow with regression coverage. | Adds marketplaces, templates, agent builders, or new primary jobs. |

## Final position

The next truth to earn is not that LeanCTX has a huge platform vision.

It is that a real customer paid because LeanCTX measurably improved a real
agent while preserving the accepted outcome.

Until that is true, the anti-roadmap wins every prioritization dispute.

