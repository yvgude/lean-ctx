# H9 — What We Have Exactly

Audit date: 2026-08-20

Repository audited: `/Users/yvesgugger/Documents/Privat/Projects/lean-ctx`

Requested strategy source: `docs/internal/vision/SDK-STRATEGY-ALL-IN-ONE.md`

Audit method: source inspection plus focused executable tests.

This is a current-state audit, not product copy.

It deliberately separates code existence from a working product path.

## Verdict vocabulary

**REAL** means working code exists and this audit found direct test evidence.

**SCAFFOLDED** means meaningful code exists, but the product path is incomplete,

not end-to-end proven, not consistently exposed, or only locally usable.

**PLANNED** means the strategy specifies it, but this repository has no matching

implemented product object or runtime path.

**BROKEN** means a claimed path, test suite, or command is currently non-working.

“REAL” never means universally benchmarked, production deployed, secure for every

customer, or commercially ready.

## First finding: the named authority is absent

The strategy bundle cites `21-WHAT-WE-HAVE-EXACTLY.md` as the authority for

current state at `SDK-STRATEGY-ALL-IN-ONE.md:3752`.

That standalone source file is not present under `docs/` in this checkout.

The bundle contains only a source-map paragraph summarising its supposed facts.

Therefore this document is the replacement audit based on repository evidence.

The strategy itself also labels major capabilities as future phases and unchecked

tasks; those TODOs are treated as evidence of **PLANNED**, not shipped functionality.

## Executive verdict

LeanCTX has a substantial local Rust runtime.

Its strongest confirmed capability is local context compression at tool and shell

boundaries, with functioning CLI integration tests.

It also has real receipt-signing and independent bundle-verification primitives.

It has real local agent presence, message, handoff, claim, and lease primitives.

It has a real, narrow Context Kit loader with one TOML code-review kit.

It has four overlapping Python client/SDK trees rather than one settled Python SDK.

It has a real provider-call experiment command, but that command does not produce

the signed canonical receipts/evidence bundle promised by the planned Dyno path.

It has extensive proxy code and a live proxy smoke test, but this audit did not

complete a compressed request through an authenticated upstream provider.

It has a serious current test-build failure.

`cargo test --lib proxy::integration_tests` fails before tests run.

It has a second independent broken suite: `pytest tests/delivery` cannot collect

because five referenced scripts are absent.

Consequently, “all tests pass” and “release-quality repository” are false today.

The company/product layers named Dyno, AutoTune, TuningProfileV1, hosted

Playground, managed relay, managed execution, billing, and team operation are not

implemented as product surfaces in this repository.

## Summary table

| Claimed area | Honest status | Short verdict |
|---|---|---|
| Local tool/shell compression | REAL | Direct CLI tests passed. |
| Structural code modes | REAL | Used by read/compression runtime; tested indirectly. |
| MCP tool runtime | REAL | Runtime/tool code and integration surfaces exist. |
| Local proxy listener/auth | REAL | Live localhost smoke test passed. |
| Proxy compression through provider | SCAFFOLDED | Code is wired; no completed live upstream compression E2E here. |
| Context memory/knowledge | SCAFFOLDED | Large implementation exists; not fully audited end-to-end. |
| Python SDK | SCAFFOLDED | Four divergent client trees; each has limited passing tests. |
| OCLA wire clients/contracts | REAL | Typed clients and conformance fixtures pass. |
| Context Kits | SCAFFOLDED | One TOML kit loads and selects read modes; no runtime evidence object. |
| `.ctxpkg` package substrate | SCAFFOLDED | Package/registry code exists but it is separate from Kits. |
| Local agent coordination | REAL, local only | Registry/message/handoff/lease implementation is tested. |
| Hosted scheduler/fleet coordination | PLANNED | No scheduler/control plane demonstrated here. |
| Receipt signing | REAL | Ed25519 sign/verify and tamper tests pass. |
| Offline evidence-bundle verification | REAL | Independent verifier passes tamper/key tests. |
| Provider-usage experiment | REAL, narrow | Makes actual HTTP provider calls when given a key. |
| Canonical Dyno proof path | SCAFFOLDED | Experiment result is not converted to signed canonical evidence. |
| Quality-preserved savings claim | SCAFFOLDED | Canonical gate remains an explicit roadmap task. |
| Cost calculation | REAL, calculated | Uses usage fields plus local price table; not invoice reconciliation. |
| `evidence run` comparison | BROKEN | Says unavailable and exits success. |
| TuningProfileV1 | PLANNED | Strategy has unchecked implementation tasks; no type found. |
| AutoTune | PLANNED | OSS functions are explicit enterprise-error/no-op stubs. |
| Playground/BYOK | PLANNED | Strategy design only. |
| Team/enterprise/cloud billing | PLANNED here | OSS includes boundary stubs, not implementations. |
| Repository-wide quality gate | BROKEN | Rust lib-test compile and delivery Python collection fail. |

## Evidence and test ledger

The following commands were run against the current checkout.

### Python clients

`cd clients/python && python3 -m pytest -q`

Result after allowing localhost test binding: **44 passed, 6 skipped**.

The initial sandbox run failed only because mock HTTP servers could not bind and

one wheel test could not fetch locked build dependencies.

Those environmental failures disappeared when the same suite was run with the

required localhost/dependency permission.

`cd packages/python-lean-ctx && python3 -m pytest -q`

Result after allowing localhost binding: **28 passed, 1 skipped**.

`cd py-sdk && python3 -m pytest -q`

Result: **3 passed**.

`cd python-sdk && python3.11 -m pytest -q`

Result: **6 passed**.

The default `python3` is 3.9.6.

`python-sdk` declares Python `>=3.10` and fails collection under 3.9 because its

Pydantic models use union syntax evaluated by the installed dependency stack.

That is an unsupported-runtime result, not a failure under its declared Python 3.11.

### Rust evidence, receipt, and protocol tests

`cargo test --test execution_receipt_roundtrip`

Result: **1 passed**.

`cargo test --test evidence_bundle_e2e --test evidence_tamper_tests --test ocla_contract_suite_v1`

Result: **3 + 7 + 8 passed**.

`cd packages/leanctx-verify && cargo test`

Result: **4 verifier integration tests passed**.

They detect a single payload-byte flip, wrong out-of-band key, truncated chain,

and verification under both supported key modes.

### Rust Kits, local compression, agent, and proxy tests

`cargo test --lib kits::`

Result: **4 passed**.

`lean-ctx kit show code-review`

Result: the installed CLI loaded the repository's `kits/code-review/kit.toml`

and displayed its read rules and quality criteria.

`cargo test --lib auto_mode_resolver::`

Result: **32 passed**.

`cargo test --test main suite::integration_tests`

Result: **20 passed**.

This includes `shell_hook_compresses_echo`, binary read/grep/gain behavior, and

pipe/redirect safety paths.

`cargo test --test main suite::proxy_smoke::proxy_serves_health_and_enforces_auth`

Result: **1 passed**.

The test binds a live loopback listener, returns `/health`, and rejects an

unauthenticated provider route before upstream egress.

`cargo test --test power_user_worksession phase8_agent_register_and_diary`

Result: **1 passed**.

### Confirmed failing quality checks

`cargo test --lib proxy::integration_tests`

Result: **fails to compile** with Rust errors E0631 and E0599.

The immediate source is `rust/src/core/shell_allowlist/repro1482_test.rs:13`.

It uses `split_on_operators(cmd).iter().map(str::trim)`.

The iterator item is `&&str`, so `str::trim` has the wrong function signature.

This failure happens before the selected proxy tests can run.

`python3 -m pytest -q tests/delivery`

Result: **5 collection errors**.

Tests reference missing files:

- `scripts/check-release-tag.py`
- `scripts/verify-delivery-manifest.py`
- `scripts/rehearse-delivery.py`
- `scripts/verify-delivery-evidence.py`

These failures mean the repository-wide stated quality bar is not currently met.

## Capability audit: local Context Engine

### Local compression — REAL

Code exists across `rust/src/shell/compress/`, `rust/src/core/compressor.rs`,

`rust/src/tools/ctx_compress.rs`, and the registered MCP tool wrappers.

The passing main-suite integration tests exercise the installed binary, not just

an isolated token-count helper.

`shell_hook_compresses_echo` passed.

The suite also passed pipe guards which preserve byte-faithful stdout when data is

piped or redirected unless compression is explicitly forced.

This is a real local feature.

It does not prove a particular percentage saving for arbitrary agent workloads.

### Structural code understanding — REAL

The runtime includes signatures, map, and language-aware read paths.

The code-review Kit selects `map -> signatures` for Rust sources.

`rust/src/proxy/integration_tests.rs` builds a realistic 200+ line source fixture,

extracts signatures, and asserts at least 50% token reduction for that fixture.

The main-suite binary tests also passed file read and grep behavior.

This confirms useful structural transforms exist.

It does not prove semantic correctness across every supported language.

### Context selection/planning — SCAFFOLDED

`rust/src/core/auto_mode_resolver.rs` implements configured, learned, intent, size,

and pressure-based mode selection.

All 32 targeted resolver tests passed.

That is a real policy component.

It is not a finished public “Context Planning” SDK object or a validated agent-wide

optimization loop.

### Context memory and knowledge — SCAFFOLDED

The repository has episodic, procedural, prospective, archive, lifecycle,

consolidation, and policy modules under `rust/src/core/`.

It also has `ctx_knowledge`, session summaries, and export/import code.

This audit did not run a durable multi-process memory recovery scenario.

No claim of production-grade memory fidelity should be made from code presence alone.

The honest label is substantial implementation, not end-to-end proof.

### MCP access — REAL, bounded

There are registered MCP tool implementations under `rust/src/tools/registered/`

and a stdio MCP runtime in `rust/src/mcp_stdio.rs`.

The local runtime is actively used in this audit's project environment.

The audit did not run a third-party MCP client compatibility matrix.

So “MCP server exists” is real; “all MCP integrations are reliable” is unproven.

## Capability audit: integrations

### ATTACH for coding agents — REAL, partial

The repository contains agent hook modules for Codex, Claude, Cursor and many

other editor/agent surfaces under `rust/src/hooks/agents/`.

The passing main-suite integration tests include CLI agent initialization and hook

behavior, although the focused run here did not cover every agent target.

The strategy's three named coding agents have installation code.

The strategy's own Phase 4 checklist still leaves connect, doctor, smoke, Dyno,

receipt, uninstall, and docs unchecked for each target.

Therefore attachment is real integration substrate, not “boringly reliable” for all.

### WRAP via proxy — SCAFFOLDED

The proxy has substantial OpenAI, Anthropic, Google, Bedrock, routing, history,

cache, and compression modules under `rust/src/proxy/`.

`openai.rs`, `anthropic.rs`, and `forward/prepare.rs` explicitly call compression

when configuration allows it.

The actual proxy listener/auth guard passed its localhost smoke test.

The local shell compression runtime also passed 20 binary integration tests.

However, this audit did not send an authenticated request through a configured

upstream provider and inspect the rewritten payload and billed response.

The proxy-focused Rust lib tests cannot currently be run because the unrelated

`repro1482_test.rs` compile error blocks lib test compilation.

Therefore: compression code is real and wired; provider-path proof is incomplete.

Do not claim measured provider savings from the proxy based on this audit.

### EMBED SDK — SCAFFOLDED

Several client packages exist, but none exposes the strategy's proposed top-level

`LeanCTX`, `ContextSession`, `TuningProfile`, `ContextKit`, and receipt API model.

The strategy's Phase 3 lists those as unchecked work.

The public SDK story is not yet a single coherent developer product.

### RUN / managed execution — PLANNED

The strategy labels RUN as later.

No managed execution scheduler or hosted runner was verified in this repository.

The strategy also explicitly defers managed execution.

This must not be presented as shipped.

## Python SDK: what actually works

### `clients/python` — REAL thin HTTP client

Package name: `lean-ctx-client` version `0.1.0`.

Import namespace: `leanctx`.

Primary class: `leanctx.client.LeanCtxClient`.

It uses only Python standard-library `urllib`.

It supports health, manifest, capabilities, OpenAPI, list-tools, tool calls,

context summary, event search, lineage, metrics, cache stats, and SSE parsing.

It can attach bearer, workspace, and channel identifiers.

Its complete local test suite passed: 44 passed, 6 skipped.

The skipped tests are not a customer production proof.

This is the strongest Python HTTP client in the repository.

### `packages/python-lean-ctx` — REAL CLI/proxy wrapper, not the same client

Package name: `lean-ctx-sdk` version `0.3.0`.

Import namespace: `lean_ctx`.

Primary class: `lean_ctx.client.LeanCtxClient`.

It shells out to the `lean-ctx` binary for read, grep, shell, gain, and benchmark.

It also contains LangChain, LlamaIndex, LiteLLM, discovery, and proxy adapters.

Its suite passed: 28 passed, 1 skipped.

It is a useful wrapper layer.

It does not expose the same API or transport contract as `clients/python`.

It is not evidence of one canonical Python SDK.

### `py-sdk` — REAL but minimal OCLA sync client

Package name: `leanctx` version `0.1.0`.

Import namespace: `leanctx`, which collides conceptually with `clients/python`.

It uses `httpx` and supports only OCLA health, capabilities, envelope, and ledger

summary endpoints.

Its suite passed: 3 passed.

This is a small wire client, not the strategy's full developer SDK.

### `python-sdk` — REAL under Python 3.10+, but minimal async OCLA client

Package name: `lean-ctx-ocla` version `0.1.0`.

Import namespace: `lean_ctx`, which collides conceptually with the CLI wrapper.

Primary class: `OclaClient`.

It supports async health, capabilities, envelope validation, capsule register/

resolve/fork, ledger summary, and event streaming.

Its tests pass under the declared supported Python 3.11: 6 passed.

It cannot collect under the host's unsupported Python 3.9.

That is expected compatibility behavior, but packaging discoverability remains poor.

### Python SDK conclusion — SCAFFOLDED product surface

There are four separate, tested pieces of Python client code.

They use conflicting distribution names, two conflicting import namespaces, and

different endpoint families.

There is no repository evidence that one is selected, published, documented as

canonical, versioned together, or implements the strategy's north-star API.

The honest public statement is: “LeanCTX has several Python client prototypes and

thin clients with passing local tests.”

The dishonest statement is: “LeanCTX has a complete unified Python SDK.”

## Evidence system: what produces real results

### `lean-ctx evidence realworld` — REAL provider-call experiment

Implementation: `rust/src/cli/dispatch/evidence_realworld.rs`.

It accepts endpoint, model, API key, target, and output directory.

It performs five sequential baseline HTTP calls and five sequential treatment HTTP

calls using `ureq`.

It reads the response body's `usage.prompt_tokens`, `completion_tokens`, and

`usage.prompt_tokens_details.cached_tokens` fields.

It calculates cost with local `ModelPricing` rates.

It writes `realworld-result.json` plus per-turn JSON files.

It is capable of producing a result from real provider responses when a valid key

and compatible endpoint are supplied.

This audit did not provide credentials or charge a provider account.

Therefore no new real-provider result was independently reproduced here.

### What `realworld` does not prove — SCAFFOLDED

It does not call `build_evidence_from_run` in `rust/src/core/evidence_flow.rs`.

It does not emit `ExecutionReceiptV1`.

It does not emit `SavingsReceiptV1`.

It does not emit a signed `EvidenceBundleV1`.

It does not invoke the offline bundle verifier.

It does not attach a canonical quality comparison/gate.

It timestamps its result and renders a report hash, but a SHA-256 report hash is

not an Ed25519-attested outcome receipt.

It is a real measurement experiment, not the promised canonical Dyno proof loop.

### `lean-ctx evidence workflow` — SCAFFOLDED workflow demo

Implementation: `rust/src/cli/dispatch/evidence_workflow.rs`.

It can collect local filesystem, command, read, search, and compression data.

It can call an LLM for analysis when configured.

It contains synthetic/example output paths and a default “skip” API-key behavior.

Its evidence-flow unit tests construct synthetic provider arms.

It is useful engineering/demo infrastructure.

It is not an independently verified customer savings pipeline.

### `lean-ctx evidence run` — BROKEN / unavailable

The dispatch code literally prints:

`Provider comparison evidence generation is not available yet.`

It then returns exit status zero.

This is both unavailable functionality and a bad automation contract.

An unavailable requested operation should not report shell success.

### Evidence data contracts — REAL

`ExecutionReceiptV1`, `SavingsReceiptV1`, and related OCLA contracts exist in

`rust/crates/lean-ctx-protocol`.

The OCLA fixture/round-trip suite passed 8 tests.

The execution receipt round-trip test passed and cryptographically verifies its

synthetic fixture signature.

These are real portable protocol artifacts.

They do not themselves establish that a provider usage number or accepted outcome

is true.

### Evidence bundle generation — REAL primitive

`rust/src/core/evidence_bundle.rs` creates deterministic ZIP bundles.

The code documents sorted entries, stored compression, fixed ZIP timestamps, hashes,

and a signed manifest.

The bundle E2E tests passed: deterministic output, concurrent chain behavior, and

empty-period rejection.

The tamper suite passed 7 tests, including changed file, removed file, manifest

tamper, wrong public key, and valid bundle verification.

This is a genuine offline integrity primitive.

It is not proof that the inputs were honestly collected or comparable.

### Calculated cost versus reconciled cost — REAL / missing boundary

`realworld` receives provider-reported token fields.

It multiplies them by local pricing-table rates.

That produces **calculated API cost**.

It does not ingest provider invoices.

It does not reconcile invoice cost.

It must not be called actual customer billing savings.

### Quality evidence — SCAFFOLDED

`EvidenceFlow` can accept `QualityComparison` and marks a savings receipt as

quality-preserved when the treatment score is not lower than baseline.

Its focused tests use synthetic arms and synthetic scorecards.

The strategy's Dyno phase still has unchecked “Add quality gate” work.

No canonical realworld quality gate was found in the realworld command path.

Therefore “same accepted outcome” is not yet automatically established.

## Receipt signing: does it actually verify?

### Answer: yes, for artifact integrity

`rust/src/core/canonical.rs` canonicalizes JSON, signs receipts with Ed25519,

and verifies with a supplied public key.

Its tests cover successful round trip, altered receipt content, and a different key.

The runtime `EvidenceFlow` signs baseline and treatment execution receipts and a

savings receipt, validates them, bundles them, then self-verifies the bundle.

The independent `packages/leanctx-verify` executable also passed 4 external tests.

That is much stronger than a self-reported checksum.

### Receipt-signing limit

Signing proves that a key signed specific canonical bytes.

Signing does not prove that the tool measured the provider response correctly.

Signing does not prove a baseline and treatment had equivalent task conditions.

Signing does not prove a human accepted the outcome.

Signing does not prove a customer invoice reconciles to calculated price.

The current evidence system needs provenance and quality gates before claims expand

beyond “this artifact passed this verifier.”

## Context Kits: what loads and what applies

### What is real

Implementation: `rust/src/kits/mod.rs` and `rust/src/cli/kit_cmd.rs`.

One checked-in Kit exists: `kits/code-review/kit.toml`.

It is schema-validated TOML with a format version, metadata, read rules, priority,

shell evidence hints, quality criteria, and a system prompt.

`lean-ctx kit show code-review` loaded it from the project.

All four Kit unit tests passed.

They prove built-in/project loading, validation, glob matching, and path-traversal

rejection for kit names.

### What applies at runtime

`kits::active_mode_for_path` is called by

`rust/src/core/auto_mode_resolver.rs`.

When active, a Kit can select the first read mode for a path.

For this Kit, Rust gets `map` first, tests get `signatures`, and TOML gets `full`.

The resolver's precedence and mode-selection suite passed 32 tests.

So a Kit does influence automatic read-mode choice.

### What does not apply

The runtime does not execute the Kit's shell command list.

The runtime does not enforce the Kit's quality criteria.

The runtime does not automatically inject the system prompt as an agent contract.

The runtime only automatically consumes the first selected read mode; its advertised

multi-stage plan is retained for a caller to request later.

No Kit receipt hash or Kit reference was found in the canonical realworld path.

### `.ctxpkg` mismatch — SCAFFOLDED / strategy contradiction

Strategy decision D-009 says Context Kits use `.ctxpkg`.

The actual Context Kit is TOML (`kit.toml`), not `.ctxpkg`.

The repository separately contains substantial `core/context_package` and `pack`

code for exports, imports, signing, verification, registry, and auto-load.

`auto_load_packages` can load registered packages and call a package loader.

That package system is distinct from `rust/src/kits/mod.rs`.

There is no demonstrated mapping from a Context Kit to `.ctxpkg`.

The strategy's Phase 6 explicitly leaves that mapping unchecked.

Claiming a unified Kit package format today would be false.

### Context package substrate — SCAFFOLDED

The `.ctxpkg`/pack subsystem is much more than a doc placeholder.

It has manifests, integrity, content layers, loader, registry, remote, signing,

import/export, lockfile, and auto-load code.

The older session package export shown in `context_package/export.rs` writes

`.ctx.json`, a second adjacent package representation.

This multiplicity reinforces that packaging is still converging.

No focused end-to-end package publish/install/apply verification was run in this

audit because its lib-unit suite is blocked by the current Rust test-build failure.

The defensible statement is “strong package foundation,” not “finished Kit delivery.”

## Agent Bus: does it actually coordinate agents?

### Answer: yes, locally; no, not as a hosted scheduler

The repository has two overlapping agent registries.

`core/agent_registry.rs` supports durable CLI identity, key generation, attestation,

lifecycle state, heartbeat, suspend/resume, decommission, and audit trail behavior.

`core/agents/registry.rs` supports local MCP-process presence, status, diary,

scratchpad messages, TTLs, project scoping, and persistence.

`tools/ctx_agent.rs` exposes register, list, post, read, status, handoff, claim,

release, briefing, return synthesis, event polling, and local lease operations.

The audit itself successfully registered an agent through `lean-ctx agent register`.

The command returned a public key and current registry list.

`phase8_agent_register_and_diary` passed against the integrated work-session path.

The source unit tests cover targeted/broadcast messages, TTL expiry, project scope,

message routing through the OCLA agent gateway, capsule forks, and zero-budget reject.

Therefore the local coordination primitives are real.

### What “coordinate” means here

Agents can record presence.

Agents can post/read messages.

Agents can hand off a summary.

Agents can make advisory short-lived claims.

Agents can acquire local opaque path/symbol leases.

Agents can emit/poll local context events.

Agents can create deterministic briefing material from stored knowledge.

### What it does not mean

No automatic task planner was found.

No durable hosted scheduler was found.

No queue with delivery acknowledgement and retry semantics was proven.

No organization/fleet control plane was proven.

Remote relay is conditional on a configured transport and the source comments state

that local OCLA checks are admission-oriented rather than proof of delivery,

authorization, billing, or interoperability.

The strategy's own wording “local primitives do not equal full hosted scheduler” is

accurate and should remain unchanged.

## OCLA protocol and clients

### OCLA contracts — REAL

`lean-ctx-protocol` defines token envelopes, execution receipts, savings receipts,

agent envelopes, capabilities, budgets, task structures, outcomes, and more.

Eight conformance fixture tests passed.

The independent Rust and Python OCLA clients implement limited wire operations.

This is real interoperability substrate.

### OCLA limitations — SCAFFOLDED

Contracts are not a hosted control plane.

The client README/source explicitly distinguishes local admission checks from remote

delivery, authorization, billing, and broad interoperability.

The protocol may be stable enough for fixtures while still not constituting a

commercial product service.

## Profiles, Dyno, AutoTune, and the product loop

### `ContextSession` — PLANNED

The strategy describes a first-class bounded context lifecycle object.

No matching public SDK type was found in Python, Rust, TypeScript, or Go code

searched for the strategy's exact product object.

Phase 3 still says “Define `ContextSession`.”

### `TuningProfile` / `TuningProfileV1` — PLANNED

The runtime has config profiles and task/profile-related internal heuristics.

That is not the product object's versioning, pinning, load, rollback, compare, and

receipt-reference lifecycle proposed by the strategy.

Phase 5 leaves every `TuningProfileV1` task unchecked.

No `TuningProfileV1` type was found.

### Dyno — SCAFFOLDED name, PLANNED product

The realworld experiment is valid raw material for a Dyno.

It is not yet a stable `DynoWorkloadV1`, matched runner, quality gate, canonical

receipt emitter, offline-verifiable evidence product, or reproducible benchmark UI.

Every one of those is explicitly unchecked in Phase 1.

Calling the existing command “Dyno” without qualification would overstate it.

### AutoTune — PLANNED

The OSS `solution_commercial.rs` file contains explicit enterprise stubs.

Recommendations, solution fingerprints, team policy, cross-project patterns,

verified attribution, and solution audit all return “requires enterprise license.”

`model_router.rs` is an explicit OSS no-op: it chooses the first configured model

and discards outcome recording.

No working continuous optimization loop was found in this repository.

The honest status is planned/private-repository boundary, not shipped OSS AutoTune.

### Deploy and repeat — PLANNED as a product loop

The runtime can change local configuration and choose automatic read modes.

It does not provide the strategy's deterministic winning-profile deployment,

roll-back, outcome tracking, retuning, and fleet feedback product loop.

## Cloud, enterprise, and commercial claims

### Enterprise OSS boundaries — REAL boundaries, not implementations

`rust/src/core/solution_commercial.rs` intentionally returns enterprise-license

errors for commercial functionality.

Its tests assert those functions are gated rather than silently exposing logic.

That is a real OSS/IP boundary.

It is not evidence that the private Enterprise implementation exists or deploys.

This checkout cannot verify another repository or an unprovided branch.

### Team server/push rails — SCAFFOLDED

The savings ledger has configurable team push/error-handling code.

The audit did not find or exercise a deployed team service.

No access-control, shared-evidence, or organization-economic workflow was tested.

Treat the client rails as scaffolding.

### Billing and Stripe — PLANNED here

The strategy says cloud billing historically requires account/session/database/Stripe

configuration.

No working account, payment, entitlement, or invoice-reconciliation service was

verified in this repository.

No billing claim should be made from these sources.

### Playground — PLANNED

The bundle gives a detailed v0 through v3 design.

Phase 7 retains unchecked tasks for fixed workload, visualization, methodology,

install CTA, and no-fake-benchmark enforcement.

No actual no-login Playground was verified.

### Managed relay and managed execution — PLANNED

The strategy expressly defers both.

The local OCLA relay and proxy should not be marketed as a managed relay service.

## Strategy claim-by-claim reconciliation

### “Context compression”

Status: **REAL**.

Reason: local binary and shell-hook integration tests passed.

Limit: workload savings require a declared methodology.

### “Structural code understanding”

Status: **REAL**.

Reason: map/signature paths, kits, and realistic source fixture test evidence.

Limit: not a claim of semantic proof for all languages.

### “Memory”

Status: **SCAFFOLDED**.

Reason: broad implementation exists but no focused persistence/recovery run here.

Limit: do not claim durable enterprise memory behavior.

### “MCP”

Status: **REAL, bounded**.

Reason: server and registered tool implementation exists.

Limit: third-party client matrix was not run.

### “Proxying”

Status: **SCAFFOLDED**.

Reason: listener works and rewrite code exists.

Limit: no authenticated upstream compression E2E and proxy lib tests blocked.

### “Evidence”

Status: **REAL primitives; SCAFFOLDED product path**.

Reason: signing/bundles/verifier pass; realworld can call provider.

Limit: current realworld path does not emit signed canonical proof or quality gate.

### “Cost accounting”

Status: **REAL calculated accounting**.

Reason: provider usage parsing plus pricing calculation exists.

Limit: no invoice reconciliation.

### “Package primitives”

Status: **SCAFFOLDED**.

Reason: rich package code exists.

Limit: package representations and Kit mapping are not converged/proven.

### “SDK surfaces”

Status: **SCAFFOLDED**.

Reason: several tested client libraries exist.

Limit: no single canonical, north-star SDK.

### “Agent coordination primitives”

Status: **REAL, local only**.

Reason: registry/message/handoff/lease behavior is implemented and tested.

Limit: no hosted scheduling/fleet control plane.

### “Enterprise Suite”

Status: **UNVERIFIABLE from this checkout**.

Reason: this public checkout only contains explicit OSS gates/stubs.

Limit: do not translate a private-repo assertion into a current public fact.

### “Cloud billing primitives”

Status: **PLANNED / unverified here**.

Reason: no deployed configuration or end-to-end service was available to test.

Limit: no sales claim.

## Claims that are safe today

LeanCTX is an open local context-compression/runtime project with working CLI,

MCP, structural-read, and hook-based integration components.

It can compress local tool and shell output under tested safety rules.

It has local agent coordination primitives.

It can create and independently verify signed evidence bundles for supplied data.

It has a narrow real-provider experiment command that records provider usage and

calculates workload-specific cost results when credentials are provided.

It has several Python clients with passing local tests.

It has one working TOML code-review Context Kit that selects automatic read modes.

## Claims that require qualifiers

“Proxy compression” requires “code and local runtime path exist; live upstream

compression was not reproduced in this audit.”

“Verified” requires “the declared artifact passed the declared verifier.”

“Cost savings” requires workload, provider-usage versus calculated-cost language,

and a quality limitation.

“Python SDK” requires “several client packages,” until one is made canonical.

“Agent coordination” requires “local registry/messaging/lease primitives,” not

“hosted scheduler.”

“Kits” requires “TOML read-mode plans,” not `.ctxpkg` runtime evidence objects.

“Enterprise” requires an accessible, separately audited implementation.

## Claims that should not be made today

Do not say LeanCTX has a finished unified Context SDK.

Do not say the proposed `ContextSession` API is shipped.

Do not say `TuningProfileV1` is shipped.

Do not say Kits are `.ctxpkg` objects or receipt-bound deployment artifacts.

Do not say Dyno is a finished canonical benchmark product.

Do not say `evidence realworld` proves quality-preserved outcomes.

Do not say calculated cost equals invoice-reconciled savings.

Do not say receipt signatures prove business truth.

Do not say AutoTune is available in OSS.

Do not say team/enterprise/cloud billing is deployable from this checkout.

Do not say managed relay, managed execution, or Playground is available.

Do not say all tests pass.

## Immediate repair priorities exposed by the audit

1. Fix `rust/src/core/shell_allowlist/repro1482_test.rs:13` so `cargo test --lib`

   compiles and the full Rust test suite can be trusted again.

2. Restore or remove the five absent delivery scripts so `tests/delivery` collects.

3. Choose and document one canonical Python package, distribution name, namespace,

   API family, versioning policy, and support matrix.

4. Wire `evidence realworld` into `EvidenceFlow` or label it explicitly as an

   unsigned experimental report.

5. Make unavailable `evidence run` exit non-zero.

6. Implement and test a canonical quality gate before broad savings language.

7. Decide whether a Context Kit is TOML, `.ctxpkg`, or a mapping between them;

   then make the runtime consume the complete contract rather than only a read mode.

8. Publish a clear line between local Agent Bus primitives and any future hosted

   scheduling/control-plane product.

9. Run an authenticated hermetic/mock-upstream proxy compression E2E that asserts

   the outgoing provider payload is compressed without requiring real credentials.

10. Only after the above, turn the strategy's intentionally planned Phase 1–7

    objects into current-product claims.

## Final current-state statement

What exists today is a capable but uneven local runtime with genuine compression,

integrity, protocol, and coordination foundations.

What does not exist today is the single coherent Context SDK product described by

the strategy's future-state diagrams.

The shortest honest description is:

> LeanCTX has real local context-compression and evidence-integrity primitives,
> plus several partial integrations and SDK clients. Its canonical tuning,
> quality-proof, profile, Kit-package, hosted, and commercial product loops are
> still being built, and the repository currently has material test-suite failures.
