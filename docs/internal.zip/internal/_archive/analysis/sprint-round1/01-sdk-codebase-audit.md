# SDK codebase audit — Context SDK for AI Agents

## Bottom line

lean-ctx already has the substance of a Context Runtime: structured context
operations, a persistent session/memory layer, a network proxy, evidence
artifacts, and an embedded Rust façade.  It is not yet a coherent, broadly
distributable **Context SDK**.  The public surface is fragmented across:

- a thin, unpublished Rust in-process façade;
- a working Python HTTP client plus framework adapters;
- a TypeScript HTTP client located under `cookbook/`, not a product client
  directory; and
- an MCP/CLI-first runtime whose internal `core` APIs are far larger and less
  stable than an SDK contract should be.

The highest-value gap is a versioned, language-neutral Context SDK contract
that makes context, memory, policy, evidence, and interception first-class
typed concepts rather than tool names and JSON payloads.

### Maturity legend

- **Exists** — implemented and wired to a runtime path, with tests/examples.
- **Scaffolded / partial** — useful code exists, but it is an example, a thin
  wrapper, internal-only, or only partially connected.
- **Missing** — required to make the component a reliable SDK product.

## 1. Rust SDK crate — `rust/crates/lean-ctx-sdk/`

### Exists

`lean-ctx-sdk` is a real in-process embedding façade, not an empty crate.

- `Engine::builder(project_root)` builds a multi-threaded Tokio-backed engine
  with a shared `SessionCache`, `SessionState`, tool registry, PathJail-aware
  resolution, and an explicit data directory.
- `EngineBuilder` makes write and execution capability opt-in via
  `allow_write` and `allow_exec`; the generic `call` gate rejects dangerous
  tools unless enabled.
- The ergonomic operations are `read`, `search`, `symbol`, `outline`, `tree`,
  and generic `call`; `Output` carries rendered text, original/saved tokens,
  and mode.
- Public support modules include `ReadMode`, token counting, BLAKE3 helpers,
  shell-output compression helpers, and add-on manifest scaffold/audit
  helpers.
- There is an embedding example and integration tests for cache savings,
  path-escape rejection, search, unknown tools, and execution opt-in.

Evidence: `src/engine.rs`, `src/read.rs`, `src/output.rs`, `src/addon.rs`,
`examples/embed.rs`, and `tests/engine_read.rs`.

### Scaffolded / partial

- It is deliberately a **thin façade** over the application crate.  `Engine`
  builds the normal `ToolRegistry` and calls tools by raw string plus
  `serde_json::Map`, so most capabilities are not typed SDK methods.
- The crate defines its own `Error`, `Output`, and non-exhaustive `ReadMode`,
  which is the beginning of a stability boundary, but the rest of the public
  model is still the engine's tool protocol.
- Add-on helpers are a small, independent-looking API; no comparable typed
  wrappers exist for memory, sessions, evidence, provider routing, or proxy
  configuration.
- The implementation has to configure process environment and boot a Tokio
  runtime.  Its Cargo manifest notes that the underlying engine currently
  still needs proxy/HTTP/ORT-related features even for embedding.

### Missing for the SDK vision

- It has `publish = false`: no crates.io distribution, release policy,
  compatibility matrix, or independent consumer-install test.
- A stable typed surface for the roughly 26 runtime capabilities envisioned in
  `docs/rfcs/sdk-embedding-v1.md`; generic `call("ctx_*", json)` is an escape
  hatch, not the primary SDK design.
- Async and streaming APIs, cancellation/deadlines, structured diagnostics,
  lifecycle hooks, and an explicit multi-tenant/isolated-instance model.
- Public first-class types for `Context`, `ContextHandle`, `Memory`, `Session`,
  `Evidence`, `Policy`, and `Receipt`; all currently leak through tool output
  or private engine structures.
- A small feature-minimal runtime crate.  Today the SDK embeds a large product
  binary's dependency graph rather than a purpose-built library runtime.

## 2. Runtime primitives — `rust/src/core/`

### Exists

The runtime is unusually rich.  `core/mod.rs` wires primitives in at least
these usable families:

| Family | Implemented primitives |
| --- | --- |
| Context construction | cache/content chunks, read modes, structural reads, compression, context IR/kernel/handles/ledger/overlay/snapshot, packing and policies |
| Retrieval and code intelligence | BM25/dense/embedding/hybrid indexes, semantic chunks/cache, graph/call-graph/symbol-map, knowledge routing |
| Runtime safety and control | PathJail, sandboxing, secret detection/redaction, shell allowlist, policy/config/capabilities, quotas/budgets |
| Agent execution | A2A/agent identity and registry, workflow, tool profiles, protocol/events, provider and extension registries |
| Continuity | session, knowledge, cache, episodic/procedural memory, handoff ledgers/bundles, archive/lifecycle/retention |
| Measurement | metering, savings and execution ledgers, audit trail, evidence, quality/scorecards, outcomes and attribution |

This is real runtime substrate; the Rust SDK itself already reuses
`SessionCache`, `SessionState`, `ToolRegistry`, and the common tool context.

### Scaffolded / partial

- `core` is a very large product-internal namespace rather than a deliberately
  layered public runtime API.  Many modules are `pub` for in-crate reach but
  several key boundaries remain `pub(crate)`.
- Overlapping concepts exist (`context_*`, `memory_*`, `evidence_*`, multiple
  ledgers and caches).  They are powerful but require intimate knowledge of
  the implementation to compose safely.
- The feature layout is not yet a minimal embeddable kernel; the SDK manifest
  explicitly records this as a current build constraint.

### Missing for the SDK vision

- A small, supported `lean_ctx_runtime` API with stable ownership/lifecycle
  semantics and a private implementation crate behind it.
- A canonical domain model shared by Rust, Python, TypeScript, MCP, and HTTP;
  current boundaries are mostly individual tool schemas and internal structs.
- Extension points for custom stores, retrievers, compressors, policy engines,
  telemetry, and tool transports that do not require depending on internals.
- Explicit capability negotiation/versioning for runtime features, not only
  the server's current tool/manifest discovery.

## 3. Python and TypeScript clients, wrappers, and adapters

### Exists

**Python (`clients/python/leanctx/`)**

- `LeanCtxClient` is an HTTP client for health, manifest, capabilities,
  OpenAPI, tool list/call/text, context summary, event search/lineage,
  metrics, cache stats, and SSE event subscription.
- It defines structured HTTP errors, tool-result-to-text conversion,
  conformance checks, OCLA parsing/verification helpers, and tests.
- Adapters produce callable tools for OpenAI, LangChain, LlamaIndex, and
  CrewAI; shared adapter code converts the discovered tool surface to each
  framework's callable shape.

**TypeScript (`cookbook/sdk/`)**

- `LeanCtxClient` implements the same HTTP-oriented product surface,
  bearer authentication, typed HTTP errors, tool text conversion, SSE parsing
  and async event iteration.
- It declares capabilities and event types and includes conformance and E2E
  tests.

Evidence: `clients/python/leanctx/client.py`, `conformance.py`,
`adapters/{openai,langchain,llamaindex,crewai}.py`; and
`cookbook/sdk/src/{client,conformance,types,index}.ts`.

### Scaffolded / partial

- Python is a usable HTTP integration client, not an in-process SDK.  It
  mirrors server routes and raw tool payloads rather than exposing a typed
  context domain model.
- TypeScript code is functional but lives under `cookbook/sdk`, which signals
  sample/reference-client status rather than a supported, published SDK
  package alongside the Python client.
- Framework adapters are tool adapters only.  They do not integrate memory
  injection, evidence capture, lifecycle/turn callbacks, or proxy routing.
- The conformance suites are a strong start: they validate advertised routes,
  contract status, error shape, tool calls, events, and summaries.  They do
  not establish cross-language semantic parity for all context operations.

### Missing for the SDK vision

- Published/versioned PyPI and npm packages with generated API docs,
  changelogs, compatibility guarantees, and install-from-clean-environment CI.
- A shared OpenAPI/JSON Schema (or IDL) generated client model so Rust/Python/
  TypeScript do not hand-maintain divergent route wrappers.
- Typed high-level APIs such as `context.capture()`, `memory.remember()`,
  `session.resume()`, `evidence.attest()`, and `agent.middleware()`.
- Async Python, streaming tool invocation, retries/timeouts/cancellation,
  auth/provider configuration helpers, and richer framework middleware.

## 4. Proxy mode — interception path

### Exists

The proxy is a production-shaped L7 gateway, not a shell shim.

- `start_proxy_with_token` binds an Axum server, establishes upstreams, and
  routes Anthropic `/v1/messages`, OpenAI chat/completions and Responses,
  ChatGPT/Codex backend routes and WebSocket bridge, Gemini, configured
  provider routes, and configured MCP gateway routes.
- Authentication, loopback behavior, host validation, rate limiting,
  upstream reload, provider credentials, and per-provider stats are part of
  `ProxyState`/`ProxyConfig`.
- Provider handlers parse requests, then forward through a pipeline that can
  apply compression, cache/prefix alignment, context retrieval/knowledge
  routing, routing, policy, determinism checks, metering, and the context
  kernel bridge before forwarding upstream.
- OpenAI and Anthropic handlers make content-shape-aware edits: text/tool
  result compression, optional CCR markers/retrieval, cache breakpoints,
  history handling, role-specific aggressiveness, reasoning effort, and
  verbosity steering.  They preserve unsupported/non-text content where
  appropriate and have targeted tests.
- `/v1/compress` is a direct gateway compression endpoint with stats and
  deterministic-output tests.

Evidence: `rust/src/proxy/mod.rs`, `forward/mod.rs`, `openai.rs`,
`anthropic.rs`, `compress_api.rs`, and `core/config/proxy.rs`.

### Scaffolded / partial

- Interception is primarily configuration/base-URL based and provider-wire
  specific.  It is not a reusable host-language interceptor API.
- Provider behavior is implemented in separate handlers, so support expands
  by adding wire-shape code rather than registering a stable adapter contract.
- The context kernel bridge records request identity, coverage and outcome
  signals, but those results are not presented as a stable SDK receipt API.

### Missing for the SDK vision

- Rust/Python/TypeScript middleware packages that expose the same pipeline
  without requiring an HTTP base-URL rewrite or a local proxy process.
- A stable provider-adapter SPI and documented request/response mutation
  contract, including streaming/cancellation/retry guarantees.
- Typed per-request receipts explaining exactly what changed, why it was
  allowed, what data was retrieved, and the measured versus estimated savings.
- A simple SDK bootstrap that creates/configures/probes the proxy and falls
  back cleanly when it is unavailable.

## 5. MCP tools — inventory and categories

### Exists

- `server/registry.rs` has **89 static `registry.register(...)` calls** in the
  source audit.  Plugin tools can be added dynamically, while disabled tools
  and tool profiles determine the effective advertised surface.
- Profiles deliberately reduce schema overhead; the documented `standard`
  profile exposes 16 balanced tools, while the power profile exposes the full
  registry.
- The registry is the source of truth for tool definitions, names, schemas,
  active/profile-filtered lists, and plugin collision handling.  Tests check
  registry/profile/doc drift.
- The surface naturally falls into: file/context access and read modes;
  search/symbol/graph exploration; compose/explore/expansion; shell/execute/
  patch actions; knowledge/session/continuity; URL/web/provider integrations;
  diagnostics/capabilities/profiles; and extension/add-on operations.

### Scaffolded / partial

- Categories above are inferred from tool modules and profiles; they are not
  first-class metadata exposed by a tool discovery schema.
- Counts must be read from the running registry/profile rather than copied
  from prose.  For example, the capabilities-contract document includes an
  older 42-tool example, while the present source registry is larger.
- `ctx_call`/generic dispatch is practical for coverage, but it leaves SDK
  consumers with stringly typed tool names and JSON arguments.

### Missing for the SDK vision

- A compact, domain-oriented SDK surface that treats MCP as one transport,
  rather than requiring every SDK user to learn dozens of individual tools.
- Formal categories, stability tiers, deprecation metadata, capability
  requirements, side-effect/permission annotations, and typed schemas exposed
  in discovery.
- Code generation from one manifest into Rust, Python, TypeScript, MCP, and
  HTTP bindings.

## 6. Context Kits — `kits/` and `rust/src/kits/`

### Exists

- A validated v1 TOML format (`ContextKit`) supports metadata, default and
  glob-based read plans, priority strategy, shell guidance, quality criteria,
  and a system-prompt template.
- Kits resolve from project and user locations; loading/listing/showing/unload
  is implemented in the CLI with config-backed active-kit selection.
- The only repository kit, `kits/code-review`, is a concrete code-review read
  plan.  The active kit is wired into `auto_mode_resolver`, so its per-path
  read-mode rule affects real automatic reads.

### Scaffolded / partial

- The repository contains one bundled kit only, so this is a format and a
  sample rather than an ecosystem.
- The parser validates the priority, shell, quality, and system-prompt
  sections, but source search finds only the **read-mode** selection consumed
  by the runtime.  `system_prompt.template` is otherwise only displayed by
  `kit show`; priority/shell/quality sections are descriptive today.

### Missing for the SDK vision

- Public kit SDK objects, scaffolding, packaging/signing/distribution,
  dependency/version resolution, and automated kit conformance tests.
- Runtime injection for the prompt, priority strategy, shell plan, and
  quality rules—not merely read mode selection.
- APIs to compose kit policies with agent/framework/provider configuration and
  return applied-kit provenance in a context receipt.

## 7. Evidence — real-world, flow, and canonicalization

### Exists

This is one of the strongest implementation areas.

- `cli/dispatch/evidence_realworld.rs` runs baseline and treatment turns
  against a configured Chat Completions-compatible endpoint, records prompt/
  cached/completion token use, cost, response, duration, run metadata, and
  writes JSON artifacts.  The CLI can also render a standalone HTML report.
- `core/evidence_flow.rs` converts provider-run arms plus quality comparison
  into baseline/treatment execution receipts and a savings receipt, signs
  them, creates an artifact bundle, then self-verifies it.  Tampering tests
  exercise failure.
- `core/canonical.rs` provides deterministic sorted JSON serialization and
  Ed25519 signing/verification for execution receipts and manifests.
- `core/evidence_bundle.rs` writes safe ZIP bundles with content hashes,
  signed manifests, audit-trail segments, policy/compliance material, and
  path/duplicate checks.
- `evidence_ledger.rs` records deterministic tool/manual/artifact evidence
  keys with lineage metadata; `live_evidence_ledger.rs` appends bounded,
  locked completion telemetry.  Classification labels measurement method and
  evidence confidence.

### Scaffolded / partial

- The real-world runner is a purpose-built CLI experiment harness, not a
  general evidence SDK.  Its default path is a Chat Completions endpoint and
  direct API key configuration; it is not automatically coupled to every
  proxy/MCP/SDK operation.
- Evidence generation is excellent for run artifacts but APIs are internal to
  the Rust product.  Neither the Rust façade nor Python/TypeScript clients
  expose typed receipt/bundle creation or verification.
- Several evidence forms coexist (session evidence records, evidence ledger,
  live ledger, audit trail, signed bundle), without one SDK-level evidence
  lifecycle.

### Missing for the SDK vision

- Public, typed, cross-language `EvidenceRecorder` and `Verifier` APIs;
  standardized receipts for every SDK context transformation.
- Provider-neutral measurement adapters and repeatable CI workflows that
  distinguish measured, reconciled, estimated, and synthetic results.
- A provenance graph linking source context, policy decision, transformation,
  model request, outcome, and signed artifact through a single stable ID.
- Key-management/identity integration designed for applications and tenants,
  rather than file-path signing identity supplied to a CLI flow.

## 8. Memory and session continuity

### Exists

- `SessionState` persists task, findings, decisions, touched files/read modes,
  test snapshot, progress, next steps, evidence, intents, compression state,
  live-zone state, playbook, and statistics.  Session code includes save,
  latest-pointer, normalization, compaction snapshot, resume, and deletion
  safeguards.
- `SessionCache` keeps full content, compressed variants, stable file refs,
  shared blocks/deduplication, read/delivery state, co-access signals, stats,
  and budgeted eviction.
- `ProjectKnowledge` stores facts, patterns, consolidated insight and judged
  pairs with confidence, validity, retrieval, feedback, privacy/sensitivity,
  provenance/archetype, and fidelity fields.
- Episodic memory stores session outcomes/actions/metrics with locked JSON
  persistence and indexed-like search/filtering.  Procedural memory discovers
  recurring successful tool sequences, suggests procedures, and updates
  confidence from outcomes.
- Lifecycle and archive code applies deterministic confidence decay (linear or
  Ebbinghaus), feedback/spacing effects, consolidation, compacted digests,
  retention and bounded rehydration.  Handoff/session bundles include privacy
  redaction and PathJail-aware import handling.

Evidence: `core/session/types.rs`, `core/cache/session.rs`,
`core/knowledge/types.rs`, `episodic_memory.rs`, `procedural_memory.rs`,
`memory_lifecycle.rs`, `memory_archive.rs`, `ccp_session_bundle.rs`, and
`handoff_ledger.rs`.

### Scaffolded / partial

- The primitives are strong but spread across internal modules and JSON stores.
  A Rust SDK engine creates the base session/cache, but exposes no typed
  session/memory lifecycle methods; consumers must use generic tools or HTTP.
- Python/TypeScript expose context summaries and events, not typed durable
  memory/session/knowledge APIs.
- Retrieval is a mix of token matching, knowledge routing, graph and search
  layers; applications have no simple stable `remember/query/forget` contract.

### Missing for the SDK vision

- A single versioned memory API with explicit scopes (turn/session/project/
  organization), retention, consent, privacy, encryption, export/delete, and
  conflict-resolution semantics.
- Transactional/concurrent multi-agent memory operations and tenant isolation
  suitable for hosted applications, beyond local locks and per-project files.
- Typed resume/handoff APIs with budget negotiation, evidence links, and
  durable handles that work identically through embedded, HTTP, and MCP
  transports.

## Recommended SDK shaping sequence

1. Publish a small Rust runtime/SDK boundary and freeze typed models for
   context handles, sessions, memory, policies, and evidence receipts.
2. Define one versioned protocol/IDL; generate HTTP/MCP bindings and use it to
   ship supported Python and TypeScript packages.
3. Make the proxy pipeline available as SDK middleware and return a structured
   per-request receipt.
4. Promote kits into signed, composable policy packages and wire every declared
   field into runtime behavior.
5. Unify existing ledgers into one provenance/evidence graph consumable by all
   transports.

## Important source map

- SDK/RFC: `rust/crates/lean-ctx-sdk/`, `docs/rfcs/sdk-embedding-v1.md`
- Runtime and continuity: `rust/src/core/mod.rs`, `core/session/`,
  `core/cache/`, `core/knowledge/`, `core/*memory*`
- HTTP SDKs: `clients/python/leanctx/`, `cookbook/sdk/`
- Proxy: `rust/src/proxy/`, `rust/src/core/config/proxy.rs`
- MCP: `rust/src/server/registry.rs`, `rust/src/core/tool_profiles.rs`
- Kits: `rust/src/kits/mod.rs`, `rust/src/cli/kit_cmd.rs`, `kits/code-review/`
- Evidence: `rust/src/cli/dispatch/evidence_realworld.rs`,
  `rust/src/core/{evidence_flow,canonical,evidence_ledger,evidence_bundle}.rs`
