# Vision and convergence documentation restructuring

## Decision

Replace the current collection with a small, canonical product-document set.

- **LeanCTX** is the developer-facing Context SDK and Context Runtime for AI
  agents.
- **Thinkery** is the paid organizational layer: shared control, private Kits,
  centralized evidence, fleet operation, and enterprise administration.
- The public product surface must lead with `ContextSession`, `prepare()`,
  `wrap()`, `load_kit()`, and `receipt()`; it must not lead with a generic
  platform, agent marketplace, or an agent-as-a-service offer.
- Integration depth is a product model, not an implementation footnote:
  **Attach** (Proxy/MCP), **Wrap** (adapter), and **Embed** (native SDK).

`the_plan.md` supports this explicitly: it calls LeanCTX “The Context SDK for
AI Agents” (line 290), defines the five-primitives direction (around
1104–1106), treats Thinkery as the commercial organization layer (148), and
asks for one short SDK Contract Document plus a single reference agent and an
Attach/Wrap/Embed benchmark (1826–1832). Those statements supersede older
platform- and service-first narratives.

## Scope note

The directory contents do not match the requested counts. Review scope found:

- `docs/internal/vision/`: 25 numbered documents (`00`–`24`) plus
  `the_plan.md`, not 24.
- `docs/internal/convergence/`: 15 documents, not 17.

The plan below covers every file currently present.

## Classification rules

| Disposition | Meaning |
| --- | --- |
| Keep + rewrite | The subject is essential, but its primary frame must change. |
| Merge, then retire | Extract durable material into a canonical document; remove the source document. |
| Keep as reference | Factual engineering/audit material; not a product source of truth. |
| Delete or move | The content is contradictory, stale operational state, or belongs in issues/projects rather than strategy docs. |

“Retire” means delete the duplicate source after the merged document is reviewed;
use Git history for recovery rather than keeping competing live narratives.

## Vision directory: file-by-file disposition

| File | Disposition | Rationale and destination |
| --- | --- | --- |
| `00-EXECUTIVE-SUMMARY.md` | Merge, then retire | It is useful raw narrative, but its Thinkery/platform-first summary duplicates the new thesis. Extract market, customer, and commercial facts into the new thesis and Thinkery docs. |
| `01-MARKET-PAIN.md` | Keep + rewrite | Keep the problem evidence; recast the buyer pain as poor context, repeat work, unreliable agent outcomes, and unprovable cost/quality tradeoffs. Move competitor assertions to the market landscape. |
| `02-VISION.md` | Merge, then retire | Its role becomes the new canonical product thesis; do not leave a second “vision” alongside it. |
| `03-CONTEXT-KITS.md` | Keep + rewrite | Directly aligned with `load_kit()`. Define Kit contract, provenance, access control, lifecycle, versioning, and OSS/private boundary. |
| `04-ARCHITECTURE.md` | Merge, then retire | Preserve runtime and evidence architecture, but organize around ContextSession, runtime boundary, adapter contract, recovery, and Attach/Wrap/Embed. |
| `05-CODEBASE-MAP.md` | Keep as reference | Valuable capability inventory, including existing embeddable/SDK-adjacent work. Rename to `reference/current-capability-audit.md`; update it when capabilities change. |
| `06-AGENT-AS-A-SERVICE.md` | Delete | A separate managed-agent product is a competing product category. It contradicts the plan’s SDK-first surface and “one reference agent, no showcase theatre” direction. |
| `07-PARTNER-STRATEGY.md` | Merge, then retire | Partnerships are a commercial distribution topic, not a product pillar. Extract only near-term adapter/channel implications into Thinkery GTM. |
| `08-COMPETITIVE-MOAT.md` | Merge, then retire | Retain evidence-based differentiation, especially native integration depth and receipts; remove broad or reactive moat claims. Destination: market landscape. |
| `09-MONETIZATION.md` | Merge, then retire | Revenue remains relevant only for Thinkery. Replace Kit-attach/consulting-heavy framing with commercial organization capabilities and a clearly bounded tuning-sprint motion. |
| `10-ROADMAP.md` | Merge, then retire | Old timelines conflict with the reference-agent, benchmark, and SDK-contract sequence. Fold surviving work into one decision-linked roadmap. |
| `11-PROOF-OF-CONCEPT.md` | Merge, then retire | The evidence and receipt material is valuable; combine with the POC/runbook set around one reference custom-agent experiment. |
| `12-OSS-BOUNDARY.md` | Merge, then retire | Essential topic, but duplicate with `23`. Consolidate into the OSS/commercial boundary decision record. |
| `13-INFRASTRUCTURE.md` | Merge, then retire | Keep runtime/platform constraints only. Do not make cloud infrastructure or a control plane a prerequisite for the developer SDK and playground. |
| `14-NINE-ANSWERS.md` | Merge, then retire | Useful objections and answers belong in the product thesis FAQ. Remove agent-service and multi-product answers that violate the new non-goals. |
| `15-BRANDING.md` | Merge, then retire | Replace with a concise brand architecture: LeanCTX = SDK/runtime; Thinkery = commercial organization layer. |
| `16-FEASIBILITY.md` | Merge, then retire | Convert claims into an evidence-plan appendix: feasibility must be demonstrated by the benchmark, outcome gates, provider usage, and versioned receipts. |
| `17-GO-TO-MARKET.md` | Merge, then retire | Preserve ICP, messaging, and early-sale insights; make the initial offer SDK adoption/tuning rather than a broad platform rollout. |
| `18-USE-CASES.md` | Merge, then retire | Reframe as integration examples by depth and adapter: existing coding agent, framework adapter, and embedded internal agent. |
| `19-INVESTOR-PITCH.md` | Merge, then retire | Investor narrative must follow the product boundary, not define it. Fold into the commercial/pitch narrative after the thesis is stable. |
| `20-WHAT-WE-HAVE-EXACTLY.md` | Keep as reference | Strong factual audit. Rename to `reference/current-capability-audit.md` and reconcile it with the codebase map rather than duplicating audits. |
| `21-FASTEST-POC.md` | Merge, then retire | Its speed bias is right, but the target must be one small reference custom agent and the integration-depth benchmark. |
| `22-REPO-CONVERGENCE.md` | Merge, then retire | Keep engineering consolidation decisions in the capability/roadmap documents, not as a parallel product thesis. |
| `23-OSS-PROTECTION.md` | Merge, then retire | Consolidate with `12`; protection language must become enforceable scope, entitlement, and private-Kit rules. |
| `24-FOCUS-AND-IDENTITY.md` | Merge, then retire | It contains the closest predecessor to the new focus. Extract its durable constraints into the canonical thesis and non-goals. |
| `the_plan.md` | Keep as decision record | It is the authoritative transition input, but it is not a clean product spec. Link it from the canonical thesis; do not ask readers to infer the product contract from this long working document. |

## Convergence directory: file-by-file disposition

| File | Disposition | Rationale and destination |
| --- | --- | --- |
| `01-TRUTH-HIERARCHY.md` | Keep + rewrite | Keep decision authority and evidence hierarchy. Make the SDK contract, benchmark protocol, and verified receipts the top product sources of truth. |
| `02-CONTRACT-INDEX.md` | Keep + rewrite | High-value basis for `ExecutionReceiptV1`, evidence, policy, and Kit contracts. Add `ContextSession` and Adapter contracts, remove orphan/aspirational contracts, and link each to its specification. |
| `03-SEAM-TICKETS.md` | Move, then delete | Detailed closure tickets are implementation backlog, not durable convergence documentation. Move live tickets to the issue tracker; retain only named contract gaps in the roadmap. |
| `04-WEEK-BY-WEEK.md` | Merge, then retire | The 12-week solo plan is superseded by a thesis-first sequence. Extract uncompleted dependencies into the new roadmap; delete calendar detail. |
| `05-FACTS-TABLE.md` | Keep as reference | Preserve verified facts and explicit unknowns. Replace claims with receipt/benchmark evidence as it becomes available. |
| `06-NOT-TO-DO.md` | Merge, then retire | Its scope discipline is essential. Put the current prohibitions in the SDK contract’s non-goals and the canonical thesis. |
| `07-REVENUE-LOOP.md` | Merge, then retire | Fold commercial hypotheses into Thinkery’s commercial model; do not let revenue loops define LeanCTX’s SDK scope. |
| `08-RESPONSIBILITY-MATRIX.md` | Delete | The role/agent allocation is stale operational scaffolding and does not define product behavior. Recreate only if an active delivery team needs it. |
| `09-POC-RUNBOOK.md` | Merge, then retire | Retain its checklists and real-provider evidence discipline; rebuild it as the reference-agent and depth-benchmark runbook. |
| `10-EXECUTION-CONSTITUTION.md` | Keep + rewrite | Keep concise operating principles and decision gates. Strip product claims duplicated by the thesis and contracts. |
| `11-COMPETITIVE-RESPONSE.md` | Merge, then retire | A Headroom-specific response should become a small, dated market-landscape section; avoid reactive roadmap commitments. |
| `12-PITCH-UPDATE.md` | Merge, then retire | Fold into the Thinkery commercial/pitch narrative after it uses the correct SDK/runtime split. |
| `13-ACCELERATED-PLAN.md` | Merge, then retire | Consolidate with the active roadmap; preserve only dependencies, owners, and measurable exit criteria. |
| `CUSTOMER-ONE-PAGER.md` | Keep + rewrite | This should become the first customer-facing explanation: connect an existing agent, improve context, and receive verifiable receipts. Do not promise unqualified “80%+” savings. |
| `SPRINT-TRACKER.md` | Move, then delete | Live status belongs in a project board/issue tracker. A static Markdown tracker becomes false evidence immediately. |

## Canonical merge map

Create these documents first; then migrate source material in this order.

| New canonical document | Merge sources | Output purpose |
| --- | --- | --- |
| `product/00-product-thesis.md` | `the_plan`, vision `00`, `02`, `14`, `15`, `24`, convergence `06` | Single answer to what LeanCTX is, what Thinkery is, who each serves, and what is explicitly out of scope. |
| `product/01-sdk-contract.md` | `the_plan`, vision `03`, `04`, convergence `02`, `06` | Versioned product contract: ContextSession, `prepare`, `wrap`, `load_kit`, `receipt`, recovery, runtime boundary, adapter contract, and non-goals. |
| `product/02-integration-depth.md` | `the_plan`, vision `04`, `18`, `21`, convergence `09` | Attach/Wrap/Embed definitions, support matrix, developer tradeoffs, and migration paths. |
| `product/03-context-kits.md` | vision `03`, `12`, `23`, convergence `02` | Kit schema, provenance, discovery, permissions, private/public lifecycle, and `load_kit()` examples. |
| `product/04-runtime-and-adapters.md` | vision `04`, `05`, `13`, `22` | Runtime boundary, adapter interface, security/opt-in rules, supported first-party adapters, and implementation status. |
| `product/05-receipts-and-evidence.md` | vision `11`, `16`, convergence `01`, `02`, `05`, `09` | Receipt types, verification, cost/quality methodology, evidence limits, and retention/privacy rules. |
| `product/06-benchmark-protocol.md` | `the_plan`, vision `11`, `16`, `21`, convergence `09`, `13` | Raw vs Attach vs Wrap vs Embed protocol; same task/model/provider; quality gate; versioned pricing and receipts. |
| `strategy/market-landscape.md` | vision `01`, `08`, convergence `11` | Buyer problem, alternatives, dated competitor observations, and differentiation that can be evidenced. |
| `strategy/active-roadmap.md` | vision `10`, `21`, `22`, convergence `04`, `13` | Ordered decisions and measurable exits; not a narrative calendar. |
| `commercial/thinkery-offering.md` | vision `00`, `07`, `09`, `17`, `19`, convergence `07`, `12` | Commercial organization capabilities, packaging, ICP, first revenue motion, and partner implications. |
| `commercial/oss-commercial-boundary.md` | vision `12`, `23`, convergence `02` | Open local SDK/runtime versus paid organization, shared control, private Kits, central evidence, fleet, SSO/RBAC, and enterprise operations. |
| `commercial/customer-one-pager.md` | convergence `CUSTOMER-ONE-PAGER`, vision `17`, `18` | Short customer narrative and bounded proof promise. |
| `reference/current-capability-audit.md` | vision `05`, `20`, convergence `05` | Verified current state, known gaps, supported languages/adapters, and proof links. |
| `governance/decision-and-evidence-rules.md` | convergence `01`, `10` | Source hierarchy, update ownership, claim policy, and retirement rules for strategy documents. |

## Explicit deletion/move set

After content migration and review, remove these source documents rather than
retaining live duplicates:

- Delete: `vision/06-AGENT-AS-A-SERVICE.md`.
- Delete: `convergence/08-RESPONSIBILITY-MATRIX.md`.
- Move to the issue/project system, then delete: `convergence/03-SEAM-TICKETS.md`
  and `convergence/SPRINT-TRACKER.md`.
- Retire after merge: all documents marked “Merge, then retire” above, including
  the old timeline documents. Their historical record remains in Git.

Do **not** delete the factual capability/facts audits (`05`, `20`, convergence
`05`) until the combined audit has been checked against the repository.

## Missing documentation

The present set explains many ambitions but lacks the documents needed for a
developer to adopt or an organization to buy the new product safely.

1. **SDK contract** — exact type/lifecycle semantics of ContextSession, the five
   primitives, failure/recovery behavior, and non-goals.
2. **Integration-depth guide** — Attach/Wrap/Embed definitions, compatibility
   matrix, value/effort tradeoffs, and upgrade path.
3. **Reference-agent quickstart** — a minimal existing agent transformed into
   `existing_agent + LeanCTX`, with an inspectable receipt in minutes.
4. **Adapter contract and support policy** — what an adapter must implement;
   which of Claude Code, Codex, Cursor, OpenAI SDK, and LangGraph are supported
   now versus experimental.
5. **Context Kit specification** — schema, provenance, versioning, permissions,
   cache/invalidations, evaluation, and private-Kit behavior.
6. **Receipt and evidence specification** — signed/verified fields, quality
   gates, pricing version, provider usage versus estimated savings, privacy,
   retention, and claim policy.
7. **Integration-depth benchmark protocol and published result template** —
   eliminates unsupported native-integration and savings claims.
8. **OSS/commercial boundary decision record** — enforceable entitlement and
   deployment rules, not only positioning language.
9. **Thinkery product specification** — organization graph, shared control,
   private Kits, centralized evidence, fleet, RBAC/SSO, and why each is paid.
10. **Documentation governance index** — document owner, status, source of
    truth, review trigger, and retirement rule so a parallel strategy library
    cannot regrow.

## Migration order and exit criteria

1. Freeze `the_plan.md` as the transition decision record; no new strategy prose
   goes into legacy files.
2. Write `00-product-thesis.md` and `01-sdk-contract.md`; approve the LeanCTX /
   Thinkery boundary and explicit non-goals.
3. Write the integration-depth, Kit, runtime, and receipt documents from the
   existing technical material.
4. Build the reference-agent quickstart and benchmark protocol; make receipts
   the evidence source for product and customer claims.
5. Rewrite the Thinkery offering and customer one-pager only after the product
   contract is stable.
6. Migrate the factual audits, move live operational trackers to the project
   system, and delete/retire all marked sources.

The restructure is complete when a reader can answer these four questions from
the canonical set without opening any legacy document: “How do I integrate an
agent?”, “What value does deeper integration unlock?”, “What evidence do I
receive?”, and “What does Thinkery add beyond the open local SDK/runtime?”
