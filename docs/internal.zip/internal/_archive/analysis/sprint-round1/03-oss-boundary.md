# OSS / Thinkery boundary audit

## Decision

The boundary is **local execution and user-owned artifacts** versus **organization
control and shared authority**.

- **OSS (`lean-ctx`)** is the complete offline, single-developer runtime.  It
  must work with no account, plan, token, network service, remote registry, or
  administrator.  It may create and verify local evidence, but it may only call
  it *observed*, *estimated*, or *unverified*.
- **Thinkery** owns every shared/authoritative surface: dashboard/console,
  registry, policies, identity and RBAC/SSO, central evidence, fleet control,
  billing/entitlements, and any hosted connector.  It is a private service plus
  private clients/adapters; it may consume open wire contracts, but its decision
  logic must not be linked into or shipped by the OSS binary.

This deliberately makes the dashboard paid, as requested.  That is a change to
the repository's current stated model, which calls the local dashboard part of
the Engine.

## Exact OSS allow-list

Keep these public and Apache-2.0, subject only to the exclusions below.

| Area | OSS modules / directories | Boundary rule |
|---|---|---|
| Runtime and compression | `rust/src/{engine,shell,hook_handlers,hooks,server,tools,wrap,proxy}` | Keep the local proxy/wrappers, read/search/shell compression, MCP runtime, cache, and local provider adapters.  Remove the specific Thinkery subpaths listed below. |
| Local memory and knowledge | `rust/src/core/{cache,bm25_index,graph_*,property_graph,knowledge,session,context_kernel,context_os,embeddings,providers}` | Local files/databases and local retrieval only.  No shared graph, hosted ingestion, or account-backed synchronization. |
| Local kits/packages | `kits/`, `skills/`, `cookbook/`, `rust/src/kits/`, `rust/src/core/{addons,context_package}` | Keep local install/import, signatures, lockfiles, pack building, and local add-on registries.  Exclude remote-registry transport/publish code. |
| Local evidence | `security/evidence/`, `contracts/`, `rust/src/core/{provenance,context_snapshot,context_ledger,execution_ledger,savings_ledger,trust,audit_trail,compliance_report}` | Generate, sign, export, import, and verify artifacts locally.  Exclude central push, attribution, settlement, retention, and organization audit functions. |
| SDKs and wrappers | `rust/crates/lean-ctx-{protocol,sdk,ocla}/`, `clients/`, `go-sdk/`, `py-sdk/`, `python-sdk/`, `ts-sdk/`, `packages/`, editor extensions | Protocols and local-client wrappers stay open.  Remove dashboard UI entrypoints from editor extensions. |
| Security primitives | PathJail, shell allowlist, workspace trust, secret redaction, signature verification, local safety defaults | These protect a developer's machine; they are not organization-policy management. |

`TenantId`, evidence envelopes, signed-policy envelope types, and neutral
protocol types may remain in OSS.  They do **not** imply that OSS owns tenants,
membership, policy authoring, or central storage.

## Exact Thinkery ownership

| Thinkery capability | Private responsibility | OSS may retain |
|---|---|---|
| Dashboard / Console | Hosted administrative and analytical UI, all dashboard APIs and webviews | CLI/TUI/text summaries of **local** state only. |
| Registry | Package/add-on discovery, private packages, publishing, accounts, trust decisions, marketplace operations | Local package builder/importer, signature verification, local lockfile. |
| Policies | Authoring, approval, signing, distribution, revocation, organization policy packs and reporting | At most a small generic verifier/enforcer for a previously signed instruction; no policy authoring or pack management UX. |
| RBAC / SSO | Organizations, memberships, role assignments, scopes, OIDC/SAML/SCIM, credential vault | Local process/user configuration; no server identities or role administration. |
| Central evidence | Ingest, retention, correlation, attribution, verified savings, compliance/audit views, settlement inputs | Local signed evidence and explicitly unverified estimates. |
| Fleet | Runtime registration, rollout, remote configuration, group-level budgets/routing, managed connectors, aggregate analytics | Stand-alone runtime and local agent bus. |
| Commercial control plane | Accounts, plans, checkout, entitlements, quota, billing and upgrade UX | Nothing required for local execution. |

The public contract is a narrow versioned protocol such as
`lean-ctx-protocol`: observations and signed instructions cross from OSS to
Thinkery.  Thinkery's client implementation, control-plane API, console, and
all decision-making remain private.

## Public-repository findings

The table identifies code currently tracked in the public repository that is on
the Thinkery side of the requested boundary.  `git ls-files` confirms the named
source and documentation files are tracked.

| Surface | Currently public modules | Finding / required disposition |
|---|---|---|
| **Dashboard** | `rust/src/dashboard/**`; dashboard startup in `rust/src/cli/dispatch/network/mod.rs`; `vscode-extension/src/dashboard-panel.ts`, `uri-handler.ts`, dashboard contributions in `vscode-extension/package.json`; dashboard commands in `packages/sublime-lean-ctx/**` | Entire dashboard is public today, including local APIs, live views, provenance/ROI routes and static UI.  Move the whole dashboard/console to Thinkery; remove the OSS `dashboard` command and editor webview commands. |
| **Cloud accounts and central sync** | `rust/src/cloud_client.rs`, `rust/src/cloud_sync.rs`, `rust/src/cli/cloud.rs`; unconditional exports in `rust/src/lib.rs` | Public code implements registration/login/OAuth, plan cache/checkout, account cloud status, automatic sync, hosted-index push/pull, and synchronization of knowledge, commands, CEP, gain, gotchas, buddy, and feedback.  Move all of it to a private Thinkery connector. |
| **Enterprise gateway and fleet identity** | `rust/src/core/config/enterprise.rs`, `rust/src/cli/enterprise.rs`, `rust/src/proxy/gateway_identity.rs`, `rust/src/proxy/forward/enterprise_headers.rs`; enterprise-only branches in `rust/src/proxy/{mod.rs,forward/mod.rs,forward/prepare.rs,lineage.rs,pre_optimize.rs,policy_gate.rs,usage_meter.rs}` and `rust/src/core/value_gate/mod.rs` | Public source injects instance, agent, session, task and savings headers plus bearer credentials to an Enterprise Suite gateway; it also carries organization-routing/policy branches.  Extract these branches and the `enterprise` Cargo feature to Thinkery. |
| **Policies and RBAC** | `rust/src/core/policy/**`, `rust/src/core/{roles.rs,context_policies.rs}`, `rust/src/cli/{policy_cmd.rs,policy_enforce_cmd.rs,policy_org_cmd.rs}`, `rust/src/server/{policy_guard.rs,role_guard.rs,call_tool/policy.rs}`, `rust/src/proxy/policy_gate.rs` | Public code contains policy-pack resolution, organization signing/trust, role-scoped tools/shell limits, policy enforcement and audit events.  Move authoring, packs, role administration, distribution and reporting to Thinkery.  Reintroduce only a minimal, format-agnostic signed-decision enforcer in OSS if offline fail-closed enforcement is required. |
| **Hosted registry** | `rust/src/core/context_package/remote.rs`, `rust/src/cli/pack_remote.rs`, remote portions of `rust/src/cli/pack_cmd/**`; `rust/src/core/addons/publish.rs`, remote parts of `rust/src/cli/addon_cmd/**` | The public binary resolves/downloads/publishes to a hosted `ctxpkg` registry and supports private packages/tokens.  Move all remote transport, publish and account-token paths to Thinkery; retain local registry/import/signature code. |
| **Central evidence and team roll-up** | `rust/src/core/savings_autopush.rs`, `rust/src/core/savings_ledger/push.rs`; `push` and `team` commands in `rust/src/cli/dispatch/analytics/savings.rs`; team URL/token fields in `rust/src/core/config/{model.rs,schema/sections_core.rs}` | Public code pushes signed savings batches to `/v1/savings/summary`, handles team tokens/scopes and auto-pushes aggregate evidence.  Move these paths.  Keep local `summary`, `roi`, export, sign, verify, and rechain operations. |
| **Commercial plan UX** | `rust/src/core/billing/{mod.rs,plans.rs,metering.rs,settlement_evidence/**}`, `rust/src/cli/dispatch/analytics/billing.rs`, `rust/src/cli/upgrade_hint.rs` | The current code intentionally avoids local gating, but it still models plans, entitlements, hosted quotas and upgrade messages.  Under this stricter Thinkery boundary, move it all; OSS emits neutral local observations only. |
| **Fleet placeholders and documents** | `rust/src/core/fleet_analytics.rs`; `rust/src/cli/dispatch/network/team.rs`; `docs/reference/09-team-cloud-ci.md` | `fleet_analytics.rs` and `team.rs` are explicitly no-op OSS stubs, not a leaked server implementation.  Keep them only as a one-line “available in Thinkery” compatibility response, or remove them.  The public Journey document describes a team server and managed connectors and should move/private-link instead. |
| **SSO** | `rust/src/cli/upgrade_hint.rs`; `docs/guides/org-sso-setup.md`; `docs/contracts/team-invite-links-v1.md` | No OIDC/SAML/SCIM implementation was found in the public Rust runtime; the public guide/upgrade UX nevertheless exposes the paid SSO product.  Move the guide, contracts and upgrade mapping to Thinkery. |

### What is *not* a paid leak

- `rust/src/core/cloud_files.rs` detects OS cloud-placeholder files to avoid
  downloading them during local indexing; it is an offline file-safety feature.
- `rust/src/core/agent_registry.rs` is a local agent-bus registry, not a fleet
  control plane.
- `rust/src/core/fleet_analytics.rs` and `rust/src/cli/dispatch/network/team.rs`
  are no-op compatibility stubs; do not add an implementation to OSS.
- Local add-on/plugin registries and local `.ctxpkg` verification serve local
  kits.  Only the hosted registry and its account/publish transport are paid.
- Local evidence-chain and tenant-bound types can remain public as portable,
  offline-verifiable data structures.  Authoritative tenant resolution and
  cross-tenant orchestration cannot.

## Boundary conflicts found

1. `ECOSYSTEM.md` currently labels a **local dashboard** as Engine and describes
   Cloud as accounts, sync, team provisioning, billing and registry.  That is
   incompatible with this decision that Dashboard and all organization/cloud
   control-plane surfaces belong to Thinkery.
2. `docs/contracts/oss-plane-separation-v1.md` says the public Engine includes
   its dashboard and explicitly leaves plan catalog/metering open.  ADR-010 also
   permits OSS enforcement of signed policy bundles.  Update these documents to
   the stricter Thinkery ownership above, while retaining only protocol types
   and optional generic instruction enforcement in OSS.
3. `docs/enterprise-ci.md` correctly states that `lean-ctx-enterprise` is a
   separate private workspace, yet the public tree still contains enterprise
   gateway client/configuration code and `cfg(feature = "enterprise")` paths.
   A compile flag is not a confidentiality boundary.
4. Publicly tracked docs include `docs/contracts/billing-plane-v1-catalog.json`,
   `ctxpkg-registry-v1.md`, `personal-cloud-encryption-v1.md`,
   `team-invite-links-v1.md`, `docs/guides/org-sso-setup.md`, and
   `docs/reference/09-team-cloud-ci.md`.  These must move alongside the private
   implementation if Thinkery is the paid plane.
5. The existing `.github-ignore` and CI commercial-path list only guard a few
   billing/licensing paths.  They do not block the cloud, dashboard, policy,
   enterprise-client, registry-client, or central-evidence modules above.

## Exact extraction plan

1. **Create the private Thinkery workspace** with three explicit components:
   `thinkery-control-plane` (API, identity, policy, registry, evidence and
   fleet), `thinkery-console` (dashboard), and `thinkery-runtime-connector`
   (the current cloud/enterprise/remote-registry clients).
2. **Move, do not feature-gate, the listed Thinkery modules.**  Delete
   `cloud_client`, `cloud_sync`, `dashboard`, `cli/cloud`, `cli/enterprise`,
   remote-registry modules and all Enterprise feature branches from the OSS
   workspace.  A disabled public implementation is still an IP and security
   leak.
3. **Split mixed modules at named operations.**  In particular, retain local
   savings ledger operations in `cli/dispatch/analytics/savings.rs`, but move
   `push`, `team`, team URL/token resolution and aggregate rendering.  Retain
   local package construction/import in `context_package`, but move `remote`.
4. **Publish only neutral contracts.**  Put observations, evidence envelopes,
   signed policy-instruction envelopes, and protocol version negotiation in
   `lean-ctx-protocol`; exclude account, entitlement, policy-pack, registry,
   tenant-membership, pricing and attribution semantics.
5. **Make the OSS default isolated by construction.**  Remove API URLs,
   OAuth/account credentials, plan cache, hosted tokens, dashboard listeners,
   `enterprise` config and team tokens from its configuration schema.  No OSS
   command should require or offer login, registration, checkout, sync, cloud
   status, publish, dashboard, enterprise init or team roll-up.
6. **Strengthen the public-repo gate.**  Add every Thinkery path above to the
   public-mirror deny list and CI check, including exact source paths and docs;
   test both tracked files and newly added files.  Require the open workspace to
   build/test with no Thinkery crate, feature or environment variable present.

## Acceptance tests for the boundary

- `git ls-files` in OSS returns no Thinkery source, UI, server-side contract,
  billing/plan, SSO/RBAC, hosted-registry, cloud-sync, or central-evidence path.
- `cargo build --release`, all SDK builds, and all local CLI/MCP/wrapper tests
  succeed with network disabled and no account/configuration.
- A single developer can compress, search, remember, install local kits, create
  and verify evidence, and export/import portable artifacts without Thinkery.
- Thinkery can consume OSS protocol artifacts, but the OSS source contains no
  policy authoring, membership/tenant administration, attribution/verification,
  entitlement decision, or fleet orchestration implementation.
- The only policy code remaining in OSS, if any, verifies a signed decision and
  enforces it locally; it cannot create, alter, approve, distribute or revoke a
  policy.

