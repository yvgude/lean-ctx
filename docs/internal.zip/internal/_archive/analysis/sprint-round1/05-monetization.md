# LeanCTX / Thinkery monetization plan

## Decision

**LeanCTX is free to build and tune an agent locally. Thinkery is paid when tuning becomes continuous, shared, governed, or operated at organizational scale.**

This is one land-and-expand motion, not separate B2C and B2B businesses:

```text
Try live → install OSS → prove a local gain → Pro → bring one agent to work
         → Tuning Sprint / pilot → Team → Business → Enterprise / AutoTune
```

The commercial unit is not "tokens compressed." It is **lower cost per successful agent task, evidenced against a declared baseline and quality gate**. Every commercial claim needs a Receipt with workload, model, provider, pricing version, cache treatment, quality method, run ID, and limitations.

All prices below are launch hypotheses in CHF, excluding VAT and pass-through model inference. They should be reviewed after the first ten paid accounts; do not wait for statistical certainty before quoting the service offer.

## 1. Packaging and the open-core boundary

| Layer | LeanCTX OSS — always open | Thinkery — paid |
|---|---|---|
| Use by one developer | Runtime, SDK, wrappers/adapters, MCP/proxy, compression, local memory | — |
| Tune and prove | Local Dyno, local profiles, local receipts, local metrics, manual tuning | Hosted run history, scheduled runs, continuous AutoTune, extended evidence history |
| Context | Kit format/loader and Community Kits | Private registry, private/premium Kits, managed refresh and access controls |
| Organization | Exportable local results | Shared receipts, team economics, policies, budget controls, RBAC, SSO/SCIM, retention, fleet recommendations, audit and SLA |

The rule is deliberately simple: **manual tuning is open; continuous tuning is commercial.** Do not put core compression, the SDK, a usable local Dyno, or local receipts behind a paywall. Those are the adoption wedge and the credibility mechanism.

## 2. B2C: individual developers (really B2D power users)

### Adoption wedge

Make LeanCTX valuable before an account, credit card, or sales conversation:

1. A developer sees a real stock-versus-tuned run in the web playground.
2. They install once and connect the coding agent they already use: Codex, Claude Code, or Cursor.
3. They run a local Dyno on their own workflow and receive a local Receipt.
4. They keep the local runtime free, or pay when they need its results to persist, repeat, or travel with them.

The first-run promise should be: **"Keep your agent. Add LeanCTX underneath it. See the receipt."** The README, adapters, uninstall path, and reference custom agent matter more than a broad framework matrix.

### Individual plans

| Plan | Price | What it contains | Why someone upgrades |
|---|---:|---|---|
| **Developer** | CHF 0 | Local runtime and SDK; adapters; local Dyno, profiles, receipts and metrics; Community Kits | It must be fully useful forever for one local developer. |
| **Pro Tuner** | CHF 29/month or CHF 290/year | Everything in Developer; hosted Dyno history; private profiles; cross-device sync; 5 BYOK cloud Dyno jobs/month; one scheduled benchmark; 30-day evidence retention; priority profile/model updates | A developer repeatedly tunes a private project, wants a durable history, schedules regression checks, or uses more than one machine. |
| **Experiment credits** | CHF 19 / 5 BYOK hosted Dyno jobs; CHF 49 / 10 AutoTune experiment credits | Prepaid only for hosted work beyond Pro's included quota; credits never include the customer's model spend | Keeps the subscription predictable and stops heavy experiment users from being subsidized by light users. |

Provider inference is **BYOK by default**. LeanCTX should not charge an individual per input token: it obscures the value, punishes successful usage, and creates unnecessary billing complexity. If Thinkery later provides a managed relay, provider cost is passed through separately with a clearly disclosed infrastructure fee.

Pro is not a crippled SDK. It sells continuity: history, privacy, scheduling, convenience, and machine-assisted tuning. The Pro conversion moment is visible and honest: "your third private project / next scheduled run / additional hosted experiment needs Pro." No hidden local feature should suddenly stop working.

## 3. B2B: turn proven local value into organizational infrastructure

### 3.1 Entry offers

#### Founding Design Pilot — preserve, but tightly bound it

Keep the existing offer for **at most three named founding design partners**:

- CHF 0 implementation fee; one workflow; four weeks; a sponsor and accessible baseline are mandatory.
- Thinkery connects LeanCTX by SDK, wrapper, or proxy, runs baseline and treatment, applies a pre-agreed quality gate, and returns a signed evidence report plus tuning profile.
- If the proof succeeds and the customer elects production continuation, Thinkery earns **10% of verified savings** for the agreed first-year measurement period.
- "Verified savings" means an agreed baseline and treatment period, matched workflow, declared provider prices, quality pass, customer approval, and an immutable statement. Opportunity estimates, avoided hypothetical hires, and unapproved dashboards are excluded.
- The agreement must define a savings cap, review cadence, what happens when the workflow changes, and who approves the statement. Invoice quarterly only after acceptance.

This is a lighthouse/reference mechanism, not an open-ended free-pilot program. It proves confidence without training the market to expect free consulting.

#### Agent Tuning Sprint — the immediate paid offer

For all subsequent prospects, sell a productized **Agent Tuning Sprint: CHF 7,500–15,000**.

| Included | Boundary |
|---|---|
| One production agent and one representative workflow | No generic AI strategy or broad migration |
| 1–2 weeks, baseline, native/sidecar/SDK treatment, quality validation | No claim without a pre-agreed quality gate |
| Tuned profile, integration recommendation, Receipt/evidence report, rollout recommendation | No permanent managed service or unlimited support |

Credit 50% of a Sprint fee against the first annual Business or Enterprise contract signed within 60 days. This creates urgency without giving away delivery. The three founding pilots remain the only CHF 0 exception.

### 3.2 Recurring organization pricing

Charge a platform fee for organizational value plus bounded hosted tuning usage; do **not** rely only on seats. Value follows agents, workflows, evidence, and control.

| Plan | Price | Fit and included scope | Clear upgrade trigger |
|---|---:|---|---|
| **Team** | CHF 499/month, annual preferred | One workspace, up to 5 managed agents, shared dashboard and receipts, 3 private Kits, workspace roles, basic policies, business-hours support | Sixth agent; fourth private Kit; team needs persistent shared evidence rather than exported files |
| **Business** | CHF 2,499/month, annual | Up to 25 managed agents, cross-team economics, unlimited private Kits, approvals/audit logs, policy controls, team AutoTune budget, priority support | Multiple squads, policy or audit requirements, budget ownership, or department rollout |
| **Enterprise** | From CHF 10,000/month on annual contract, plus implementation where needed | Contracted fleet scale, advanced/delegated administration, SSO/SCIM, contractual retention/evidence packs, private registry/connectors, self-hosted or dedicated deployment option, negotiated SLA and named support | Regulated data, identity integration, data-residency/self-hosting need, 25+ agents, or cross-business-unit governance |

Usage is deliberately secondary and must be visible before it accrues:

- Hosted Dyno and AutoTune consume included or prepaid experiment credits.
- A managed relay, if launched, bills provider inference as pass-through plus a transparent infrastructure charge.
- Avoid a token-processing fee as the primary launch model. It produces negligible revenue at proposed rates and distracts from the higher-value control and tuning loop.

For Enterprise, make performance pricing an **option**, never the sole purchase path: annual platform minimum **CHF 24,000**, credited against 10% of accepted verified savings. Example: if the contracted savings share is CHF 41,000, the customer pays CHF 41,000 total—not CHF 24,000 plus CHF 41,000. This retains aligned upside while preserving predictable revenue. Never settle savings-share invoices until the run-to-statement, customer-acceptance, and payment chain are operational.

## 4. Playground / Try Live: prove value before installation

The playground is a conversion product, not a marketing animation. It must use the same LeanCTX engine path as the SDK and label precisely whether values are measured or estimated.

### The three-step experience

| Step | User action | What LeanCTX does | Conversion outcome |
|---|---|---|---|
| **Live Demo** | No login; choose Codex, Claude Code, Cursor, or Custom Agent; run a public sample workload | Streams Stock and LeanCTX-tuned context transformations side-by-side on a sealed public fixture using the production engine path | "I understand the mechanism" → install or test my workflow |
| **Evidence Lite** | Paste a public GitHub URL or upload a capped repository/agent trace | Runs structural analysis and compression preview in an ephemeral sandbox; returns source inventory, candidate reductions, and a clearly labelled estimate | Captures qualified interest without requiring local installation |
| **Hosted Evidence Run** | BYOK + private GitHub connection or encrypted upload | Executes a baseline/treatment benchmark with quality checks, produces an immutable Receipt and downloadable report | Creates a self-qualified Team, Sprint, or Enterprise lead |

For the live demo, show the context path—not only a big percentage:

```text
STOCK                      LEANCTX-TUNED
READ 14,421 tokens         OUTLINE 1,822 tokens
SEARCH 8,822               SEARCH 1,104
TEST 21,425                TEST SUMMARY 3,120
HISTORY 64,110             REUSED 7,233 avoided

Same task | quality: pass / pass | model and pricing version declared
```

The public sample may be free and rate-limited, but it cannot be a mocked bar chart. If inferred prices are displayed, call them estimates. A `VERIFIED` badge is reserved for a completed evidence run that passes the declared method; it never means "secure," "compliant," or universally better.

### Privacy and cost guardrails

- Start with one public demo workload and no login. Do not require a cloud account to understand LeanCTX.
- For private code, use presigned direct upload/OAuth, an isolated ephemeral runner, encryption in transit and at rest, automatic source deletion at job completion, and a report-retention choice. Never train on repository contents.
- BYOK first: the customer pays OpenAI/Anthropic/Gemini directly; Thinkery charges only for tuning/measurement when applicable.
- Cap the free Evidence Lite input and queue. A full hosted evidence run is either an included Pro/Team credit, a paid experiment credit, or part of a Tuning Sprint—never an unbounded anonymous compute endpoint.
- The report must show scope, model, provider, cache treatment, pricing version, quality method, run ID, and exclusions. This is the lead artifact sales follows up on.

## 5. Revenue timeline

| Period | Sell now / ship | Revenue motion | Deliberate non-goal |
|---|---|---|---|
| **Months 1–3** | OSS SDK/adapters/local Dyno; no-login public live demo; three capped founding pilots; Agent Tuning Sprint | Invoice Tuning Sprints at CHF 7.5k–15k. Continue the CHF 0 + 10% verified-savings pilot only for the three named founding partners. Sell founder-led annual Business/Enterprise contracts manually only where delivery is real. | Do not promise self-serve checkout, recurring cloud entitlements, or automated savings settlement before payment/acceptance are proven end-to-end. |
| **Months 3–6** | Pro hosted history/private profiles/scheduled BYOK runs; Evidence Lite; hosted BYOK evidence reports; shared receipt/dashboard beta | Launch Pro at CHF 29/month and Team at CHF 499/month; sell Business at CHF 2,499/month with founder-led onboarding; sell prepaid experiment credits. | Do not subsidize provider inference or launch a broad agent-hosting platform. |
| **Months 6–12** | AutoTune, central evidence, policy/audit controls, private registry, managed relay if demanded, enterprise identity/deployment | Expand Sprints into annual Business/Enterprise agreements; launch Enterprise from CHF 10k/month; use performance-share terms only with accepted statement infrastructure. | Do not build generic workflow automation, an agent builder, or a marketplace before the tuning loop has repeatable demand. |

The commercial priority is therefore: **services cash first, recurring cloud second, enterprise control third**. Self-serve Pro is strategically important for developer pull; it is not the first revenue dependency.

## 6. Unit economics and margin rules

These are target steady-state contribution economics, not audited forecasts. They exclude model inference because the default is BYOK, exclude acquisition cost, and assume implementation work is priced separately. Validate them against actual cloud and support records every month.

| Offer | Monthly / engagement revenue | Target direct cost to serve | Target gross margin | Cost discipline |
|---|---:|---:|---:|---|
| OSS Developer | CHF 0 | ~CHF 0 marginal product infrastructure; only shared docs/GitHub/community overhead | n/a | Local execution is the point: no hosted metering, logs, or inference required. |
| Pro Tuner | CHF 29/month | CHF 6–9: storage, queue/runner, egress, support allocation; provider inference is BYOK | 69–79% | Prepaid experiment credits cover expensive hosted variants; retain summaries, not raw code/context. |
| Team | CHF 499/month | ~CHF 70: shared storage/compute, observability, and business-hours support | ~86% before onboarding | Hard caps on managed agents, private Kits, and included hosted experiments; charge for sustained excess. |
| Business | CHF 2,499/month | ~CHF 400–500: stronger isolation, AutoTune allowance, retention, priority support | ~80–84% | Budget AutoTune by workspace; separate custom connectors and implementation from subscription. |
| Enterprise | CHF 10,000+/month | ~CHF 2,500–3,000: dedicated environment, enterprise support, observability, SLA reserve | ~70–75% | Price self-hosting, security review, bespoke connectors, and migration as implementation—not hidden COGS. |
| Tuning Sprint | CHF 7,500–15,000 | Keep delivery labor at <=45% of realized fee | >=55% service gross margin | Standardize the five-step methodology and reuse profiles/connectors; do not accept undefined consulting scope. |

The Year-3 portfolio goal of roughly **77% blended gross margin** is credible only if:

1. OSS remains local-first and does not become a free hosted compute service.
2. Provider inference stays pass-through/BYOK until a managed relay earns a transparent fee.
3. AutoTune is credit- and budget-controlled.
4. Enterprise implementation and custom work are priced separately from recurring subscription revenue.
5. Savings-share settlement remains auditable and is not used to disguise unpaid consulting.

## 7. Operating metrics and decision gates

Track the funnel as one system:

```text
Demo completion → install/connect → first local Receipt → repeat Dyno
→ Pro conversion → developer-led work introduction → Sprint/pilot
→ Team/Business annual contract → agents and verified workflows expanded
```

Weekly leading indicators: demo completion, install-to-first-Receipt rate, repeat Dyno rate, private-project demand, and qualified evidence reports. Monthly commercial indicators: Pro conversion, Team activation, Sprint win rate, pilot-to-annual conversion, paid-agent/workflow expansion, verified savings accepted, net revenue retention, and gross margin.

Pricing changes need a gate, not intuition:

- Keep Pro at CHF 29 until the first 30 paying users show whether scheduled runs/history—not core features—drive conversion.
- Keep Team at CHF 499 until at least ten teams activate shared receipts and two upgrade based on a real control/scale trigger.
- Do not market savings-share beyond founding/enterprise contracts until customer acceptance and payment reconciliation are live.
- Increase or narrow free playground capacity when its qualified Evidence Lite-to-install conversion is known; do not use anonymous usage volume as a vanity metric.

## Bottom line

Give every developer a complete local Context SDK and the proof to trust it. Charge individuals for continuous, private, hosted tuning. Sell organizations shared evidence, control, and AutoTune. Use three exceptional CHF 0 pilots to create evidence, then make the **Agent Tuning Sprint** the immediate cash product. This keeps LeanCTX credible as open infrastructure while giving Thinkery a high-margin path from one tuned agent to organizational agent-performance engineering.
