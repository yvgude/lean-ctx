# LeanCTX SDK Contract

## Purpose and boundary

LeanCTX is the context lifecycle layer for an AI-agent task. It is not a
language-model SDK, an agent framework, or a second orchestration framework.
It prepares, retrieves, reuses, recovers, measures, and evidences context while
the application keeps ownership of prompts, tools, models, and control flow.

The public core deliberately exposes five primitives:

| # | Primitive | Responsibility |
|---|---|---|
| 1 | `LeanCTX(...)` | Bind a project and a shared runtime. |
| 2 | `ctx.session(...)` | Represent one agent task's context lifecycle. |
| 3 | `ctx.wrap(...)` | Add that lifecycle to a supported client or agent. |
| 4 | `ctx.load_kit(...)` | Resolve verified, version-pinned domain knowledge. |
| 5 | `ctx.receipt(...)` | Return the immutable evidence for an execution. |

`prepare`, `retrieve`, `reuse`, `recover`, and `close` are methods on a
`ContextSession`, not additional top-level primitives. Adapters live in
`leanctx.adapters.*`, not in the core namespace. This follows the plan's
direction: hide the runtime's many capabilities behind a small mental model.

### Shared data model

All language bindings map to the same `lean-ctx-protocol` records:

- `SessionId`, `ContextSession`, `Budget`, `ContextBundle`, `KnowledgeKit`
- `PreparedContext`, `RecoveryPlan`, `Outcome`, `ExecutionReceipt`
- `LeanCTXError { code, message, retryable, cause? }`

The Rust `lean-ctx-sdk` is the reference in-process implementation. Python and
TypeScript bindings communicate through the same protocol and must preserve
the record names, error codes, receipt schema, and context digests. Convenience
types may be idiomatic; semantics may not diverge.

## Integration depths

All depths use one Context Engine, one kit format, one session ID format, and
one receipt schema. A project can start shallow and move deeper without losing
cached context, correlation, or auditability.

| Depth | How it is selected | Engine visibility | Intended value |
|---|---|---|---|
| **Attach** | `LeanCTX(..., integration=Attach(...))`; deploy proxy or MCP gateway | Provider requests, responses, and tool traffic | Low-effort measurement, compression, and evidence. |
| **Wrap** | `ctx.wrap(target, adapter=...)` | Agent run, model call, tool, stream, and retry lifecycle supplied by that adapter | Strong lifecycle-aware preparation, reuse, and recovery. |
| **Embed** | `ctx.session(...)` plus session methods | Full application-owned context lifecycle | Maximum control and optimization. |

Attach is a transport deployment mode, not a sixth SDK primitive. It must
accept and emit the same `SessionId` as the SDK (for example,
`x-leanctx-session`) and must never require an application rewrite. Wrap is
only for explicit adapters; `wrap(anything)` is not a promise. Embed never
silently sends a provider request: it returns context for the host application
to send.

## 1. `LeanCTX(...)`

Create a project-scoped runtime facade. Construction validates configuration,
opens or connects to the selected runtime, and establishes default policy; it
does not start an agent task or inject a prompt.

**Signatures**

```python
ctx = LeanCTX(project: str | Path = ".", *, integration: Integration = Embed(),
              runtime: RuntimeOptions | None = None, policy: ContextPolicy | None = None)
```

```ts
const ctx = new LeanCTX({ project?: string, integration?: Integration,
  runtime?: RuntimeOptions, policy?: ContextPolicy });
```

Rust parity: `LeanCtx::new(LeanCtxOptions) -> Result<LeanCtx, InitError>`.

**Runtime path**

`lean-ctx-sdk` binding bootstrap -> project/path-jail resolver ->
`lean-ctx-protocol` negotiation -> runtime host. The host selects either the
in-process Context Engine (Embed), the adapter runtime (Wrap), or the
Proxy/MCP gateway client (Attach); all share configuration, policy, cache keys,
and the evidence ledger.

**Returns**

`LeanCTX`: a cheap, shareable facade. It owns no task state; state belongs to
sessions. Multiple facades for the same compatible project/runtime may share
the engine's cache and kit store.

**Errors**

- `INIT_INVALID_PROJECT` — root is absent, inaccessible, or outside PathJail.
- `INIT_INVALID_CONFIG` — invalid policy, integration, or mutually exclusive options.
- `RUNTIME_UNAVAILABLE` / `PROTOCOL_INCOMPATIBLE` — selected service cannot be reached or negotiated.
- `ATTACH_AUTH_REQUIRED` — an Attach gateway requires credentials not supplied.

**Example**

```python
ctx = LeanCTX(project=".", integration=Embed())
```

```ts
const ctx = new LeanCTX({ project: ".", integration: embed() });
```

## 2. `ctx.session(...)`

Create the context lifecycle for exactly one agent task. A session records what
was seen, what remains relevant, context references, token/cost budget,
provider activity, recoveries, and outcome across many model and tool calls.

**Signatures**

```python
session = ctx.session(task: str, *, budget: Budget = "balanced",
                      metadata: Mapping[str, JSONValue] | None = None,
                      parent: ContextSession | None = None) -> ContextSession
```

```ts
const session = ctx.session({ task: string, budget?: Budget,
  metadata?: Record<string, JsonValue>, parent?: ContextSession });
```

Rust parity: `ctx.session(SessionOptions::new(task).budget(budget)) -> Result<ContextSession, SessionError>`.

**Session methods (not top-level primitives)**

| Method | Contract |
|---|---|
| `await session.prepare(input, options?)` | Plans and compacts host-provided input; returns `PreparedContext` with stable context references and a provider-ready view. |
| `await session.retrieve(query, options?)` | Returns a ranked `ContextBundle`; it never mutates the application's prompt on its own. |
| `await session.reuse(reference)` | Rehydrates an eligible prior context artifact and returns a `ReuseHit` or `None`. |
| `await session.recover(failure, options?)` | Produces and records a bounded `RecoveryPlan`; retry execution remains the host or adapter's responsibility. |
| `await session.close(outcome)` | Seals the session and returns its `ExecutionReceipt`. `session.receipt()` delegates to `ctx.receipt(session)`. |

Python sessions support `async with`; TypeScript sessions use an explicit
`try/finally { await session.close(...) }` or an adapter-owned lifecycle.
Context propagation is task-local (`contextvars`, `AsyncLocalStorage`, and Rust
task-local storage), so a wrapper can find the current explicit session without
guessing from prompt text.

**Runtime path**

`SessionCoordinator` -> `BudgetController` -> `ContextPlanner` -> retrieval,
reuse/cache, and recovery services -> consolidation pipeline. Consolidation
persists `ConsolidationArtifacts` to the BM25 index, graph index, project
knowledge store, and session cache. Every decision and lifecycle event is sent
to `EvidenceLedger` under the session ID.

**Returns**

An open `ContextSession` in the `created` state. It is single-task and
concurrency-safe, but not reusable after `close`. Nested sessions are allowed
only with an explicit parent and inherit policy, not budget, by default.

**Errors**

- `SESSION_INVALID_TASK` / `SESSION_INVALID_BUDGET` — empty task or invalid budget policy.
- `SESSION_CLOSED` / `SESSION_SCOPE_MISMATCH` — operation after close or on the wrong task-local scope.
- `BUDGET_EXHAUSTED` — requested work violates the hard budget; a partial result may be attached to the error.
- `CONTEXT_INPUT_INVALID` / `CONTEXT_REFERENCE_UNKNOWN` — malformed input or unknown reuse reference.

**Example**

```python
async with ctx.session("Review PR #482", budget="balanced") as session:
    prepared = await session.prepare(prompt)
    result = await agent.run(prepared)
```

```ts
const session = ctx.session({ task: "Review PR #482", budget: "balanced" });
const prepared = await session.prepare(prompt);
const result = await agent.run(prepared);
```

## 3. `ctx.wrap(...)`

Wrap a supported provider client, agent, graph, or model with a named adapter.
The wrapper preserves the target's normal return type and streaming behavior
while adding context lifecycle observations and transformations. It is an
explicit integration boundary, never reflective magic over arbitrary objects.

**Signatures**

```python
wrapped = ctx.wrap(target: T, *, adapter: AdapterName | Adapter = "auto",
                   session: ContextSession | None = None,
                   policy: WrapPolicy | None = None) -> T
```

```ts
const wrapped = ctx.wrap<T>(target, { adapter?: AdapterName | Adapter,
  session?: ContextSession, policy?: WrapPolicy }): T;
```

Rust parity: `ctx.wrap(target, WrapOptions::adapter(name).session(session)) -> Result<Wrapped<T>, AdapterError>`.

`"auto"` is permitted only when exactly one installed adapter positively
identifies the target type. Ambiguity is an error, not a best guess.

**Runtime path**

`AdapterRegistry.resolve` -> adapter request normalizer -> current explicit
session (or a clearly labelled implicit session) -> `ContextPlanner` and
`PolicyEnforcer` -> provider/framework call -> stream/result observer -> usage
and recovery observer -> `EvidenceLedger`. The adapter must strip LeanCTX-only
options before invoking the provider and leave provider response objects,
error types, and chunk ordering intact.

**Returns**

The wrapped target with its original public calling convention. The wrapper
adds only adapter-documented extension points such as a session binding; it
does not require callers to rewrite their agent framework.

**Errors**

- `ADAPTER_NOT_FOUND` / `ADAPTER_AMBIGUOUS` — no exact adapter or more than one match.
- `ADAPTER_VERSION_UNSUPPORTED` / `ADAPTER_OPERATION_UNSUPPORTED` — target version or endpoint is outside the adapter contract.
- `WRAP_POLICY_CONFLICT` — wrapper policy conflicts with its bound session.
- `STREAM_FINALIZATION_FAILED` — response was delivered, but receipt finalization failed; it carries a retryable cause and session ID.

**Example**

```python
client = ctx.wrap(OpenAI(), adapter="openai")
response = await client.responses.create(model="gpt-5", input="Review this diff")
```

```ts
const model = withLeanCtx(openai("gpt-5"), { ctx });
const result = await generateText({ model, prompt: "Review this diff" });
```

## 4. `ctx.load_kit(...)`

Resolve a named, immutable knowledge kit. A kit is domain knowledge plus its
metadata, policy, and integrity manifest; it is not a hidden prompt template.
Loading pins the exact version and digest used by a session.

**Signatures**

```python
kit = await ctx.load_kit(name: str, *, version: str | None = None,
                         source: KitSource | None = None, verify: bool = True) -> KnowledgeKit
```

```ts
const kit = await ctx.loadKit(name, { version?: string, source?: KitSource,
  verify?: boolean }): Promise<KnowledgeKit>;
```

Rust parity: `ctx.load_kit(KitRequest::named(name).version(version)).await -> Result<KnowledgeKit, KitError>`.

A session mounts a returned kit explicitly: `await session.use(kit)`. Mounting
records the kit digest in the receipt and makes its artifacts eligible for
retrieval; it does not force all kit text into every provider request.

**Runtime path**

`KitCatalog` -> local/cache/approved registry resolver -> `KitVerifier` ->
kit manifest pinning -> consolidation pipeline -> knowledge, graph, and BM25
stores. The returned handle carries the verified manifest digest used as part
of retrieval and receipt identity.

**Returns**

`KnowledgeKit { name, version, digest, capabilities, manifest }`, an immutable
handle that may be shared by sessions. `version=None` resolves once according
to policy and is immediately pinned to a concrete version.

**Errors**

- `KIT_NOT_FOUND` / `KIT_VERSION_UNAVAILABLE` — requested name or version is absent.
- `KIT_INTEGRITY_FAILED` / `KIT_SIGNATURE_INVALID` — manifest or artifact verification failed.
- `KIT_INCOMPATIBLE` — kit protocol, policy, or project compatibility does not match.
- `KIT_PERMISSION_DENIED` / `KIT_OFFLINE_MISS` — access denied or absent from an offline cache.

**Example**

```python
kit = await ctx.load_kit("payments", version="2026.08")
await session.use(kit)
```

```ts
const kit = await ctx.loadKit("payments", { version: "2026.08" });
await session.use(kit);
```

## 5. `ctx.receipt(...)`

Read a session's execution receipt. A receipt is evidence, not a diagnostic
log: it identifies exactly which context inputs, transformations, kits,
policies, recoveries, and accounting facts produced an outcome.

**Signatures**

```python
receipt = await ctx.receipt(session: ContextSession | SessionId | None = None,
                            *, wait: bool = False) -> ExecutionReceipt
```

```ts
const receipt = await ctx.receipt(session?: ContextSession | SessionId,
  options?: { wait?: boolean }): Promise<ExecutionReceipt>;
```

Rust parity: `ctx.receipt(session_id, ReceiptOptions { wait }).await -> Result<ExecutionReceipt, ReceiptError>`.

With no argument, the method resolves the current task-local session only. It
must fail if no scoped session exists; there is no global "latest receipt"
because it is unsafe under concurrency. `wait=false` returns only a sealed
receipt; `wait=true` waits for close/finalization subject to the runtime's
deadline.

**Runtime path**

`EvidenceLedger` -> receipt assembler -> redaction/policy filter -> canonical
protocol serializer -> optional signature verifier. In Attach mode the same
path reads gateway facts; in Wrap and Embed it reads direct session events.

**Returns**

An immutable `ExecutionReceipt` with at least:

- `session_id`, task label, outcome, integration depth, SDK/runtime versions
- context input/output digests and reference IDs, transformation decisions,
  budgets, usage/cost accounting, and cache/reuse facts
- mounted kit name/version/digest, applicable policy digest, provider and tool
  event summaries, recovery actions, and any truncation/degradation reason
- an ordered event sequence and integrity/signature metadata; secrets, raw
  credentials, and policy-excluded content are absent by construction

**Errors**

- `RECEIPT_SCOPE_REQUIRED` / `RECEIPT_NOT_FOUND` — no current scope or unknown session ID.
- `RECEIPT_NOT_READY` — session remains open and `wait=false`.
- `RECEIPT_EXPIRED` — retention policy removed the underlying evidence.
- `RECEIPT_INTEGRITY_FAILED` — receipt exists but fails digest/signature verification.

**Example**

```python
receipt = await ctx.receipt(session)
assert receipt.outcome == "succeeded"
```

```ts
const receipt = await ctx.receipt(session);
console.log(receipt.context.reuse);
```

## Adapter contract and supported adapters

Every adapter implements the same internal `AdapterContract`; this is the only
way `ctx.wrap` enters a third-party runtime. It must:

1. identify supported target and operation versions precisely;
2. normalize provider/framework input into `ContextInput` without losing tool,
   message, and stream semantics;
3. bind an explicit task-local session or create a labelled implicit one;
4. apply only policy-approved `PreparedContext` transformations;
5. observe success, usage, stream close/cancel, and failure; and
6. emit canonical lifecycle events through `lean-ctx-protocol`.

An adapter must preserve cancellation and backpressure, finalize streams in a
`finally` path, and record a partial/aborted outcome rather than fabricate
success. Adapter-specific extensions belong under `leanctx.adapters`, keeping
the five core primitives unchanged.

| Adapter | Integration surface | What LeanCTX observes and does |
|---|---|---|
| **OpenAI SDK** | Python/TS OpenAI clients; Responses and supported chat endpoints | Normalizes messages, tools, and structured output; injects prepared context; observes usage, response IDs, errors, and streaming completion. |
| **Anthropic SDK** | Python/TS Messages client and supported streaming helpers | Preserves Anthropic system/message/tool semantics while applying approved context and recording token usage, tool-use, stop reason, and stream lifecycle. |
| **Vercel AI SDK middleware** | `withLeanCtx(model, { ctx, session? })` / middleware around `generate*` and `stream*` | Wraps the language model at the AI SDK boundary; transforms parameters, preserves stream chunks/backpressure, and attaches a receipt to the generation lifecycle. |
| **LangGraph integration** | `with_leanctx(graph, ...)` or `LeanCTXCallback` passed in graph config | Correlates graph run, node, model, and tool events; checkpoints references rather than duplicating full state; creates one parent session with explicit child sessions when requested. |
| **LiteLLM callback** | `LeanCTXCallback(ctx, session?)` registered in LiteLLM callbacks | Works as a compression/evidence sidecar in Attach or Wrap depth; maps pre-call, success, failure, and streaming callbacks to the canonical lifecycle without changing application call sites. |

The adapter matrix is intentionally targeted. OpenAI and Anthropic adapters
cover provider SDKs; Vercel covers model middleware; LangGraph covers agent
state/lifecycle; LiteLLM covers provider-routing sidecar use. New frameworks
must implement `AdapterContract` and declare their capability/version matrix
rather than expanding the core API.

## Behavioral guarantees and non-goals

- **Explicit ownership:** LeanCTX never chooses the model, executes an agent
  tool, retries an application operation, or changes application control flow.
- **No invisible prompt mutation:** Attach and Wrap transformations are
  observable in the receipt; Embed returns `PreparedContext` for the host to
  use. Policy can prohibit transformation entirely while retaining evidence.
- **Portable evidence:** receipts and kit manifests use canonical protocol
  records, so one execution can be verified by Python, TypeScript, Rust, a
  gateway, or an offline verifier.
- **Predictable failure:** a context optimization failure may degrade to the
  original provider request only when policy explicitly permits it; the
  receipt records the degradation. Otherwise the SDK returns a typed error.
- **No framework replacement:** LeanCTX does not expose agent planning,
  workflow graphs, tool registries, or provider-specific model APIs in the
  core contract.

## Compatibility rules

- Public core additions require an SDK-contract version review; an adapter
  feature must not create a sixth core primitive.
- Protocol fields are additive; changing a receipt digest, event ordering, or
  error code is a breaking change.
- Adapters declare supported upstream versions and fail closed outside that
  range. They do not rely on undocumented client internals.
- Receipt schema and redaction behavior are identical across Attach, Wrap,
  and Embed for the facts visible at each depth. Less-visible depths report
  `unobserved`, never invented values.
