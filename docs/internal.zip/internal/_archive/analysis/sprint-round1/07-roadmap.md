# LeanCTX: The Context SDK for AI Agents — Roadmap

**Planning horizon:** 6 months  
**Product principle:** earn the right to scale by proving measurable context savings and agent quality for a real customer first.

## v1.0 — Prove It Works for One Customer

**Timeline:** Days 1–30

**Outcome:** A single design partner runs a production-relevant agent workflow through LeanCTX and can quantify the result.

### Scope — maximum three features

1. **Context capture and compression SDK** — stable API to ingest files, command output, and retrieved documents; deterministic compression with source references.
2. **One production integration** — a maintained TypeScript/Python package and a reference agent integration for the design partner’s stack.
3. **Evidence dashboard/report** — per-run token reduction, latency, cost estimate, retrieval/source coverage, and before/after quality review.

### Customer deliverable

- A working integration in one chosen workflow, an implementation guide, and a 30-day outcome report jointly reviewed with the customer.

### Success metric

- One design partner completes **100+ real agent runs** with **≥50% context-token reduction** and **no material decline in task acceptance rate** versus its baseline.

### We do **not** include

- Multi-tenant SaaS, self-serve signup, billing, organization controls, marketplace, or a generalized adapter framework.
- Broad model-provider coverage; support the partner’s chosen agent/runtime only.

---

## v2.0 — SDK Developer Experience

**Timeline:** Days 31–90 (60 days)

**Outcome:** Developers can install LeanCTX, see value in minutes, and extend it without learning its internals.

### Scope

- **The “wow in 10 minutes” path:** install, one-line instrumentation, local trace viewer, and a runnable quickstart that shows raw versus optimized context side by side.
- **Developer-grade SDK:** typed APIs, streaming hooks, source attribution, configurable policies/budgets, clear errors, offline/local mode, and versioned compatibility guarantees.
- **First adapter:** a first-class adapter for the highest-leverage agent framework identified by v1 validation (for example, LangChain/LangGraph or OpenAI Agents SDK), with an end-to-end example.

### Success metric

- A new developer reaches a verified optimized run in **under 10 minutes**; **70%+** of pilot developers complete the quickstart unaided; the first adapter powers **25+ weekly active projects**.

### We do **not** include

- An adapter for every framework, a visual workflow builder, enterprise identity, or usage-based invoicing.
- Custom compression research that delays a stable, delightful developer loop.

---

## v3.0 — Team / Organization

**Timeline:** Days 91–180 (90 days)

**Outcome:** LeanCTX becomes a shared operating layer for teams, and Thinkery billing begins on clear, value-aligned limits.

### Scope

- **Organizations:** team workspaces, roles, shared policies, environment separation, audit-ready traces, and aggregated usage/quality analytics.
- **Operational controls:** spend/context budgets, retention settings, export, alerts, and API keys/service accounts.
- **Thinkery paid plans:** self-serve team billing, metering, invoices, and plan management.

### What triggers paid

Free remains for a solo developer’s local experimentation. A paid Thinkery plan is required when a customer needs any of:

- A shared organization/workspace or more than one production user.
- Production-hosted traces, longer retention, audit export, or access controls.
- Usage beyond the included monthly optimized-context volume.
- Managed support/SLA or private deployment requirements.

### Success metric

- **10 paying organizations**, **$10k MRR**, and **70%+** of paid accounts with two or more weekly active users; less than **5%** of billed usage needs manual correction.

### We do **not** include

- A full enterprise sales motion, on-premises deployment for every customer, procurement-heavy custom features, or a multi-sided marketplace.
- Monetizing opaque “AI magic”; invoices stay tied to measurable optimized-context usage and team controls.

---

## v4.0 — Platform Scale

**Timeline:** Months 6–12

**Outcome:** LeanCTX is the default context layer across agent runtimes, with compounding data, integration, and workflow advantages.

### Scope

- **Adapter platform:** stable provider/runtime contracts, adapter SDK, certification tests, and a curated integration registry.
- **Context intelligence network:** privacy-preserving, opt-in aggregate benchmarks that improve budget policies, compression choices, and quality evaluation by task/runtime.
- **Enterprise platform:** policy-as-code, regional/data-residency options, high-scale observability, and partner APIs for agent hosts, model providers, and systems integrators.

### Moat and network effects

- Every adapter makes LeanCTX easier to adopt in another agent stack; more deployed stacks create more demand for adapters.
- Opt-in aggregate outcome data improves recommendations and benchmarks; better recommendations attract more production workloads.
- Portable context traces, policies, and evaluation history become a team’s operational record, raising the cost of rebuilding the layer elsewhere without locking in raw customer data.

### Success metric

- **5,000 active projects**, **10 certified adapters**, **50+ paying organizations**, and evidence that benchmark-informed policies improve either token efficiency or task quality for **75%+** of opted-in workloads.

### We do **not** include

- Building a general-purpose agent framework, owning customers’ models or vector databases, or exchanging customer context data without explicit opt-in.
- Growth that compromises deterministic behavior, source attribution, privacy, or developer portability.

---

## Sequencing gates

| Move only when | Evidence required |
| --- | --- |
| v1.0 → v2.0 | Customer value is proven | ≥100 real runs, measurable savings, and a customer reference or renewal intent |
| v2.0 → v3.0 | Developers can self-serve | 10-minute time-to-value and sustained adapter usage |
| v3.0 → v4.0 | Teams will pay and retain | Paying organizations use shared controls weekly and billing is reliable |
