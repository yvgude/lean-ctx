# Integration Depth Benchmark

## Decision

Test the thesis as an end-to-end coding-agent experiment, not as a compression
microbenchmark:

> Given the same coding task, repository, model, prompt, tool contract, and
> acceptance gates, deeper LeanCTX integration reduces resource use without
> reducing task quality.

Use the five-model-turn coding-agent workload described in plan sections 13–14.
One **run triplet** is the same task and seed executed once in each arm. Run at
least 20 triplets, balanced in six `A-B-C` order permutations. Pin the base
commit, model revision, harness revision, LeanCTX revision, configuration hash,
and price-card version in every run manifest.

## 1. Task candidates

| Option | Task | Why it is useful | Risk |
|---|---|---|---|
| **1 — recommended** | **Historical multi-file regression replay.** Freeze the parent of an already accepted LeanCTX fix and give the agent the original issue-level prompt and focused failing test. Select a fix that needs 4–8 relevant files, 1–3 production edits, and has deterministic Rust tests. | Real defect, known-good oracle, meaningful repository exploration, and no synthetic solution. | Requires a small task-selection pilot and hidden acceptance tests. |
| 2 | **Evidence-package manifest feature.** Add a machine-readable run manifest to `evidence-export`, including source revision, benchmark configuration, model/price-card provenance, and task acceptance. | Exercises CLI parsing, evidence assembly, JSON schema, and tests; easy to inspect. | A little too localized, so the input-token separation may be modest. |
| 3 | **SDK path-safety/telemetry regression.** Repair a frozen regression in SDK `Engine` path handling or `Output` accounting, with unit and integration tests. | Directly exercises the existing SDK surface and cross-module reasoning. | Security-sensitive task selection must avoid a patch that is obvious from a single test. |

Choose option 1 for the headline result. Build a frozen task manifest before
running it; the manifest names the base SHA, prompt, allowed paths, initial
focused failing test, hidden grader, and expected quality gates. Options 2 and
3 become secondary workloads, reported separately rather than pooled. A
historical replay makes “same task” literal and prevents a hand-made benchmark
from quietly favoring LeanCTX.

Task-selection acceptance criteria:

- Raw pilot: typically needs several repository reads/searches, not one file.
- Competent agent: can finish within five model turns and the shared wall-time
  cap.
- Baseline checkout: focused test fails; known-good checkout: it passes.
- No network, credentials, generated artifacts, or nondeterministic tests.
- The task does not modify the benchmark harness or LeanCTX configuration.

## 2. Fixed experiment contract

The provider model is `gpt-5` (or an immutable provider revision recorded in
the manifest), with identical system prompt, user task, temperature, max output
tokens, tool schemas, turn cap, timeout, and retry policy. Use a provider seed
where supported; otherwise retain the requested seed plus provider model
fingerprint and treat triplets as paired replications, not deterministic runs.

Every scheduled run receives:

- a fresh worktree at the same immutable base SHA;
- an arm/run-specific LeanCTX data directory—no shared LeanCTX cache or session
  state;
- a unique cache-partition label fixed for all five turns in that run, so
  cross-arm provider-cache leakage cannot create a result;
- the same normal edit backend (`apply_patch`/structured edit) and the same
  check backend; edits never write a compressed read result back to disk;
- the identical visible tool contract: `tree`, `search`, `read_file`,
  `run_command`, and `apply_patch`.

The agent harness always follows this loop:

1. Send the fixed conversation, visible tools, and accumulated transcript to
   the provider; record returned usage and request latency.
2. Execute all requested tool calls serially through that arm’s backend;
   record agent-visible calls and backend calls separately.
3. Append the tool result(s) byte-for-byte as returned by that backend and
   repeat until a final response or five provider turns.
4. Stop the agent, capture its diff, and run the independent acceptance and
   quality gates in a clean evaluator process.

The limit is five *provider turns*, not five individual tool calls; batched tool
calls are permitted in all arms. The harness must not add planning hints,
prefetches, or special system-prompt text to only one arm.

## 3. The three arms

| Property | ARM A — Raw | ARM B — Attach | ARM C — Embed |
|---|---|---|---|
| LeanCTX path | Disabled, including hooks/proxy. | Agent host attaches to local LeanCTX over MCP/proxy. | Agent host links `lean-ctx-sdk`; no MCP/process boundary for context operations. |
| `tree/search/read_file` | Normal filesystem walk, `rg`, raw file text. | Adapter calls the corresponding LeanCTX MCP capability (`ctx_tree`, `ctx_search`, `ctx_read`). | Adapter calls `Engine::tree/search/read` directly. |
| `run_command` | Normal constrained command runner. | MCP/proxy `ctx_shell`. | `Engine::call("ctx_shell", args)` with execution explicitly enabled. |
| Edits | Shared raw structured-edit backend. | Same shared backend. | Same shared backend. |
| State scope | Per-run harness state only. | Per-run harness state + isolated LeanCTX state. | Per-run `Engine` + isolated data directory. |
| Instrumentation | Harness I/O interceptor. | Harness interceptor plus MCP request/response spans. | Harness interceptor plus SDK `Output` spans. |

The external tool *names and JSON schemas* remain identical. The model is not
told the arm name. ARM B’s adapter deliberately uses the normal Attach product
path; ARM C’s adapter uses only semantically equivalent SDK operations. This
keeps the comparison about integration depth rather than giving Embed extra
repository knowledge.

Count two call totals:

- **Agent-visible calls:** model-issued calls under the common contract. This
  reflects whether better context lets it work with fewer actions.
- **Backend calls:** filesystem/MCP/SDK operations. This exposes Attach
  transport and orchestration overhead without hiding it behind one tool call.

## 4. Quality equivalence and scoring

An arm cannot claim an efficiency win unless it is quality-non-inferior.

**Task completion (binary)** is true only if the evaluator finds the expected
behavior and all mandatory gates pass. Run the evaluator after the model exits,
outside its transcript, from the resulting worktree:

```text
cargo test --lib
cargo clippy --all-features -- -D warnings
cargo fmt --check
task-specific focused tests + hidden acceptance tests
```

Use the project’s exact gate commands at the frozen SHA. The evaluator is
blinded to arm by an opaque run ID and records full command exit status/log
digest. It must use a fresh process and the same dependency/cache policy for
all arms.

**Quality score (0–100)** is computed identically from evaluator artifacts:

| Points | Criterion |
|---:|---|
| 55 | Hidden and focused functional acceptance tests pass. |
| 20 | No regressions: library tests pass. |
| 15 | Clippy and formatting pass. |
| 10 | Diff review rubric: minimal scope, required tests, no forbidden artifacts or weakened checks. |

Publish both completion rate and score distribution; never replace a failure
with a token-normalized score. Primary non-inferiority bounds are: completion
not more than 5 percentage points lower and mean quality not more than 2 points
lower than Raw. Report cost/token deltas for all scheduled runs, but describe
them as a thesis confirmation only after those bounds hold.

## 5. Measurements and accounting

Capture per provider request and aggregate per run:

| Metric | Definition |
|---|---|
| Provider input tokens | Provider-reported prompt/input tokens. Also store `uncached_input = input - cached_input` when the provider reports cached input as a subset. |
| Cached tokens | Provider-reported cached-input tokens; never infer it from LeanCTX’s own cache. |
| Output tokens | Provider-reported completion/output tokens. |
| Provider cost (USD) | `uncached_input × input_rate + cached_input × cached_rate + output × output_rate`, using the immutable price-card in the manifest. Store token totals and component costs, not only a rounded total. |
| Tool calls | Agent-visible and backend calls, each grouped by tool and outcome. |
| Files/content read | Unique canonical files; physical source bytes/lines/tokens read; model-delivered bytes/tokens. For B/C, retain LeanCTX `original_tokens`, `saved_tokens`, mode, and source path per result. |
| Latency | Provider request latency, tool latency, gate latency, and end-to-end monotonic wall time. Report p50/p95 and total; do not mix CPU time with wall time. |
| Completion/quality | Binary completion, 0–100 quality score, per-gate results, and diff digest. |

`files/content read` must distinguish source material from delivered context.
For example, a compressed B/C read is one physical file read with 800 source
tokens and 250 delivered tokens; Raw is usually 800/800. This prevents “we read
less” from meaning merely “we failed to measure the original source.”

The run JSON should contain raw per-turn provider usage, tool spans, source and
delivered-content accounting, gate result, price-card hash, configuration hash,
and cryptographic diff/log digests. The summary reports medians, paired
differences, bootstrap 95% confidence intervals, and every raw run—not only
means or successful runs.

## 6. ARM C implementation now

The existing `lean-ctx-sdk` is sufficient for a native benchmark adapter; no
new engine capability is required. Its thin façade already exposes
`Engine::builder`, `data_dir`, `allow_exec`, `allow_write`, `worker_threads`,
`build`, and direct `read`, `search`, `symbol`, `outline`, `tree`, and generic
`call` methods. `Output` carries `text`, `original_tokens`, `saved_tokens`, and
`mode`—the measurement fields needed by the runner.

Illustrative adapter setup (the harness owns edits, so SDK writes stay off):

```rust
use lean_ctx_sdk::{Engine, ReadMode};

let engine = Engine::builder(&worktree)
    .data_dir(&run_data_dir)       // unique for this arm/run
    .allow_exec(true)              // only for the common run_command tool
    .allow_write(false)            // common edit backend writes raw patches
    .worker_threads(4)             // fixed across ARM C runs
    .build()?;

let result = engine.read(path, ReadMode::Auto)?;
record_read(path, result.original_tokens, result.saved_tokens,
            result.mode.as_deref());
return_to_agent(result.text);
```

`search`, `tree`, `symbol`, and `outline` map directly to the corresponding
`Engine` methods. The common command adapter uses `Engine::call("ctx_shell",
args)` and records the returned `Output`; path resolution remains inside the
SDK. If the selected SDK revision names the automatic read mode differently,
the harness pins that mode in its adapter and records the exact enum/version in
the manifest. Do not fall back to spawning the CLI in ARM C—doing so converts
it into an Attach measurement.

Relevant current implementation: `rust/crates/lean-ctx-sdk/src/engine.rs` and
`output.rs`. The SDK deliberately avoids forcing a global allocator into the
embedding host, which is important for a realistic agent-process embedding.

## 7. CLI and evidence package

Today’s internal primitives are useful but do **not** run a three-arm external
agent comparison:

```bash
lean-ctx benchmark --config standard --repeats 20 --output artifacts/task-benchmark.md
lean-ctx evidence-export --output artifacts/evidence --format json
```

The first executes the existing task benchmark; the second packages current
benchmark/savings/proof data. Add a dedicated runner rather than overloading
either result as proof of integration depth.

Recommended target UX:

```bash
lean-ctx evidence benchmark \
  --spec benchmarks/integration-depth/v1.yaml \
  --repo . --base-sha <frozen-sha> --model gpt-5 \
  --arms raw,attach,embed --turns 5 --runs 20 \
  --price-card benchmarks/pricing/gpt-5-<version>.json \
  --quality-gates benchmarks/integration-depth/quality-gates.toml \
  --output artifacts/integration-depth/<run-id>
```

This is a **proposed command**, not a currently shipped one. It should emit:

```text
manifest.json                 # versions, hashes, pricing, task definition
runs/<arm>/<run-id>.json      # request/tool/gate events, no lossy aggregation
summary.json                  # paired deltas, CIs, non-inferiority outcome
summary.md                    # human-readable table and methodology
evidence/                     # signed/digested logs, diffs, evaluator output
```

`evidence-export` can then be extended to ingest that immutable directory (or
the new command can call its shared package writer) and include an
`integration_depth` section. Do not call the result “evidence” if it contains
only averages without manifests and evaluator artifacts.

## 8. Expected result and interpretation

Pre-register directional hypotheses:

1. **Quality:** Attach and Embed are non-inferior to Raw on completion and
   quality score.
2. **Efficiency:** `Embed <= Attach < Raw` for delivered provider input tokens
   and provider cost, conditional on hypothesis 1.
3. **Operational overhead:** Embed has lower context-operation latency than
   Attach because it removes MCP/proxy serialization and process/transport
   work. Agent-visible calls may be equal; backend latency is still a valid
   integration-depth result.
4. **Caching:** Embed/Attach may show more usable provider cached input because
   deterministic, compact context repeats across turns. Cached tokens are
   reported, never silently counted as free input.

Plan material cites 79–86% calculated API-cost reduction for controlled
five-turn workloads. Treat that as prior calibration, not as the pass threshold
for this task: task shape, provider price card, and cache behavior can change
the magnitude. The benchmark proves the SDK thesis only if the raw artifacts
show a positive paired cost/input effect, the quality non-inferiority criteria
hold, and Embed’s incremental benefit over Attach is not explained by different
prompts, caches, tool schemas, or a weaker evaluator.

A null result between B and C is still useful: it means current SDK embedding
removes transport overhead but does not yet materially change provider-context
efficiency. It is not evidence to claim a deeper integration advantage until a
quality-equivalent, statistically supported delta appears.
