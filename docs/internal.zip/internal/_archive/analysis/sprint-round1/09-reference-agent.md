# Reference Custom Agent — SDK Demonstrator

## Decision

Build a **Python 3.11+ repair agent** that works against a supplied local
repository. It is one real agent loop, not an orchestration framework:

```text
task → plan → search → read → patch → test → answer
```

`patch` is mandatory for a repair and is the only addition to the requested
six-stage loop; diagnostic tasks may skip it. Search and read can repeat within
a small, explicit budget. The agent makes real OpenAI Responses API calls,
edits real files through a constrained patch tool, and runs a declared test
command. It has no fake model, mocked tools, or scripted answer.

Python is the right demonstration language:

- `openai`, `subprocess`, `pathlib`, and `json` make the complete agent legible.
- It has a broadly familiar tool-calling example surface.
- LeanCTX's value is visible on exactly the expensive operations: repository
  search, file reads, and test output.

Use `uv` so the walkthrough remains one command after cloning this repository:

```bash
OPENAI_API_KEY=... uv run examples/reference-agent/agent_leanctx.py \
  --repo examples/reference-agent/target \
  --task "Fix the duplicate-refund idempotency bug; keep the public API stable" \
  --test-cmd "uv run pytest -q"
```

The same command works with `agent_plain.py`; changing only that filename is
the A/B comparison. `--repo .` makes it useful on a real local Python project.
The checked-in `target/` is a maintained, production-shaped reconciliation
service (pagination, idempotency keys, persistence boundary, and tests), not a
single-file puzzle. Its default defect is a realistic refund replay across page
boundaries, and the regression test is initially failing.

## Scope and guardrails

The demonstration stays understandable in five minutes by deliberately having:

- one model, one thread, at most six model turns, and a 25-tool-call budget;
- five tools only: `search`, `read`, `patch`, `test`, and `diff`;
- a repository path jail; search ignores `.git`, virtual environments, and
  generated directories;
- a configured `--test-cmd` allowlist, rather than model-provided arbitrary
  shell; and
- a final answer that reports changed files, test status, and unresolved risks.

It is nevertheless a real coding agent: the model chooses files, inspects
source, proposes an actual unified diff, runs the repository's tests, uses the
test failure to make one more repair if necessary, and bases its answer on the
actual results. The fixed task is intentionally small enough to finish within
the budget but requires cross-file reasoning: a paginated event reader,
idempotency store, service logic, and regression test.

## Agent loop

| Stage | Agent action | Bound |
|---|---|---|
| Task | Validate repository, task, and declared test command; collect a compact repository map. | No model tool call. |
| Plan | Ask the model for a 3-step repair hypothesis and evidence it needs. | One response. |
| Search | Model calls literal/regex search to locate likely owner code and tests. | Up to 4 calls. |
| Read | Model reads only selected paths and ranges, then decides whether it has evidence. | Up to 8 calls. |
| Patch | Model submits one unified diff; host validates it is inside the path jail and applies it. | Up to 2 attempts. |
| Test | Host runs the declared command; model may inspect failure output and make one corrective patch. | Initial + one retry. |
| Answer | Model summarizes the diagnosis, exact fix, tests, and limitations. | One response. |

The model sees tool results in the same OpenAI tool-call format in both arms.
That makes completion quality comparable; LeanCTX changes the context transport,
not the task, prompt, model, tools, budgets, or test command.

## Version A — plain OpenAI agent

`agent_plain.py` is intentionally a single ~50-line script (helpers such as
`search_repo` and `apply_unified_diff` live in `tools.py` and are shared without
change). The pseudocode uses the Responses API shape, but the real source should
use the installed SDK's current method names.

```python
import argparse, json
from openai import OpenAI
from tools import search_repo, read_file, apply_unified_diff, run_test, git_diff

SYSTEM = """You repair Python repositories. Use evidence. Work: plan, search,
read, patch, test, answer. Stay within the supplied repository and tools."""
TOOLS = [search_repo.schema, read_file.schema, apply_unified_diff.schema,
         run_test.schema, git_diff.schema]

def call_tool(name, args, repo, test_cmd):
    if name == "search": return search_repo(repo, **args)
    if name == "read":   return read_file(repo, **args)
    if name == "patch":  return apply_unified_diff(repo, **args)
    if name == "test":   return run_test(repo, test_cmd)
    if name == "diff":   return git_diff(repo)
    raise ValueError(f"unknown tool: {name}")

def run(task, repo, test_cmd):
    client = OpenAI()
    messages = [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": f"Task: {task}"}]
    plan = client.responses.create(model="gpt-5", input=messages)
    messages += plan.output

    for turn in range(6):
        response = client.responses.create(model="gpt-5", input=messages,
                                           tools=TOOLS)
        messages += response.output
        calls = [x for x in response.output if x.type == "function_call"]
        if not calls:
            return response.output_text
        for call in calls:
            result = call_tool(call.name, json.loads(call.arguments), repo,
                               test_cmd)
            messages.append({"type": "function_call_output",
                             "call_id": call.call_id, "output": result})
    return "Stopped at the six-turn safety budget; inspect the test output."

if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("--repo", required=True)
    args.add_argument("--task", required=True)
    args.add_argument("--test-cmd", required=True)
    ns = args.parse_args()
    print(run(ns.task, ns.repo, ns.test_cmd))
```

Production code will include ordinary validation/error handling omitted by the
pseudocode's compression: reject unsafe patches, cap file/result sizes, surface
tool failures to the model, and persist a run record. Those helpers are exactly
identical in both versions.

## Version B — same agent with LeanCTX SDK

The only behavioral change is a LeanCTX session that wraps each existing tool
result immediately before it is returned to the model. It applies the chosen
context policy to search/read/test results, tracks observed versus delivered
context, and emits a receipt. OpenAI is still called directly by the same
`OpenAI()` client.

The proposed SDK surface is `ctx.session(...).wrap(...)`; if the published SDK
settles on `ctx.wrap(...)`, preserve the same five-line shape. The important
contract is that wrapping is transparent to the `call_tool` return values and
the standard OpenAI tool-call protocol.

```python
import argparse, json
from openai import OpenAI
from leanctx import ctx                                  # + SDK import
from tools import search_repo, read_file, apply_unified_diff, run_test, git_diff

SYSTEM = """You repair Python repositories. Use evidence. Work: plan, search,
read, patch, test, answer. Stay within the supplied repository and tools."""
TOOLS = [search_repo.schema, read_file.schema, apply_unified_diff.schema,
         run_test.schema, git_diff.schema]

def call_tool(name, args, repo, test_cmd):
    if name == "search": return search_repo(repo, **args)
    if name == "read":   return read_file(repo, **args)
    if name == "patch":  return apply_unified_diff(repo, **args)
    if name == "test":   return run_test(repo, test_cmd)
    if name == "diff":   return git_diff(repo)
    raise ValueError(f"unknown tool: {name}")

def run(task, repo, test_cmd):
    client = OpenAI()
    session = ctx.session(task=task, root=repo)           # + start receipt
    messages = [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": f"Task: {task}"}]
    plan = client.responses.create(model="gpt-5", input=messages)
    messages += plan.output

    for turn in range(6):
        response = client.responses.create(model="gpt-5", input=messages,
                                           tools=TOOLS)
        messages += response.output
        calls = [x for x in response.output if x.type == "function_call"]
        if not calls:
            session.close()                               # + finalize metrics
            return response.output_text, session.receipt() # + emit receipt
        for call in calls:
            raw = call_tool(call.name, json.loads(call.arguments), repo,
                            test_cmd)
            result = session.wrap(tool=call.name, output=raw) # + transform result
            messages.append({"type": "function_call_output",
                             "call_id": call.call_id, "output": result})
    session.close()                                       # + same budget exit
    return "Stopped at the six-turn safety budget", session.receipt()

if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("--repo", required=True)
    args.add_argument("--task", required=True)
    args.add_argument("--test-cmd", required=True)
    ns = args.parse_args()
    answer, receipt = run(ns.task, ns.repo, ns.test_cmd)
    print(answer); print(receipt.to_json())
```

Conceptual diff: one import, session start, one wrapped tool result, and two
receipt lines. In implementation,
the `session.close()` calls should be a `try/finally`; that does not change the
comparison point. Do not fork the agent logic, prompts, or tools between arms.

## Receipt and A/B report

The Version B receipt is machine-readable JSON (`receipt.json`) plus a short
human table. It must report measured facts, distinguish estimates from provider
usage, and never claim that compression alone made the repair correct.

| Group | Receipt fields |
|---|---|
| Run identity | agent version, SDK version/policy, model, task hash, target revision, fixture/case ID |
| Context | tool calls by type, source bytes/tokens observed, tokens delivered to model, tokens avoided, reduction percentage, and per-tool breakdown |
| OpenAI usage | provider prompt/cached/input/output token usage by call; unknown values are explicitly `null` |
| Cost | actual or configured per-token prices, input/output cost, LeanCTX overhead, and total; price source/version recorded |
| Quality | patch applied, changed paths/diff hash, test command/exit code, initial and final test status, and final-answer completion |
| Reliability | rejected tool/patch attempts, truncation or transformation reason, timeout/budget outcome, and elapsed time |

`compare.py` runs A and B against the same clean worktree, case, model, seed
where supported, budgets, and test command. Its comparison table adds delta
input tokens, delta cost, delta wall time, final test pass/fail, and patch/diff
hash. It reports a result as **inconclusive** if the two arms do not both finish
or produce different test outcomes; it never presents token savings as a
quality win. Multiple runs should show median and range rather than a single
cherry-picked result.

## Repository layout

```text
examples/reference-agent/
├── README.md                 # 5-minute explanation and both commands
├── pyproject.toml            # Python/OpenAI/LeanCTX dependencies and uv entry points
├── agent_plain.py            # Version A, legible side-by-side baseline
├── agent_leanctx.py          # Version B, only the five logical changed lines
├── tools.py                  # shared jailed search/read/patch/test/diff tools
├── prompts.py                # shared system prompt and plan schema
├── compare.py                # clean-worktree A/B harness and receipt table
├── target/                   # maintained miniature reconciliation service
│   ├── src/reconcile/
│   └── tests/
├── cases/
│   └── duplicate_refund.md   # task, success test, and expected invariant
└── receipts/                 # gitignored local A/B artifacts
```

Keep `README.md` focused on two things: the exact one-command run and the
five-line diff. Put SDK policy options, receipt schema, and benchmark notes in
adjacent docs so the agent source stays readable in one screen.

## Acceptance criteria

- A new reader can explain every model call and tool in five minutes.
- Both scripts solve the same checked-in repair case with a real model, a real
  patch, and a passing regression test.
- Replacing `--repo` and `--task` turns it into a useful constrained agent for
  another Python repository.
- `git diff --no-index agent_plain.py agent_leanctx.py` shows only the SDK
  import/session/wrap/receipt changes (3–10 logical lines).
- The receipt attributes every savings number to observed source versus
  delivered context and labels provider cost estimates accurately.
