# Focused 90-Day Execution Plan

**Execution clock:** 19 August–10 November 2026 (12 weeks)  
**Founder capacity:** Yves plus AI agents; no workstream exists unless it advances the proof loop or protects existing OSS users.

## The irreversible choices

### One metric: Verified Cost per Successful Agent Task (VCP-SAT)

`VCP-SAT = provider-reported net LLM cost (uncached input + cached input + output) / number of tasks that pass the predeclared quality bar`.

- Compare treatment to a matched baseline: same task, commit, prompt, provider, model, and quality test.
- A task counts only when it passes its predeclared automated acceptance test **and** the agreed human/code-review check. A cheaper failed task is worth zero.
- Every reported value includes the provider's cache fields and is backed by a signed, offline-verifiable evidence bundle.
- The commercial threshold is **at least 40% lower VCP-SAT with no quality regression**. The existing 79–86% real-cost result is proof of potential, not a customer promise.

This is the one optimizing metric. Leads, GitHub stars, total tokens saved, and dashboard activity are diagnostic only.

### One first customer persona

**Head of Engineering (or the staff platform engineer they appoint) at a 20–80 person B2B SaaS company that already runs 100+ coding-agent tasks per week and owns the AI-tool budget.**

They have enough recurrent usage to measure, can authorize a short paid pilot, and need a budget/quality answer rather than another agent framework.

### One first integration

**Python wrapper for the OpenAI Agents SDK: `LeanCTX.wrap(agent)`**.

It is the narrowest route from an existing agent to a matched provider measurement and is aligned with the current real OpenAI evidence. The customer keeps its own agent and provider account; LeanCTX supplies context decisions, receipts, and verification. No second framework integration is built before this wrapper has produced customer evidence.

### The thing being sold

**Founding Design Partner: 30-Day Verified Savings Pilot — US$5,000 prepaid.**

- Scope: up to three existing coding-agent workflows, OpenAI Agents SDK/Python, one non-production repository or approved workload.
- Deliverable: signed baseline/treatment bundles, quality comparison, offline verification command, executive report, and a conversion recommendation.
- Commercial success: the customer receives a reproducible answer to “Did LeanCTX reduce VCP-SAT without harming task success?”—not a promise to rebuild its agent stack.
- Conversion offer in Week 8: US$1,500/month, three-month minimum, for the verified runtime/evidence workflow. Price is reviewed only after two paying pilots; bespoke feature work is never bundled into the pilot.

## Non-negotiable OSS guardrails

Every release in this plan must pass a smoke test for **Cursor, Codex, and Claude Code**. The existing CLI/MCP integrations remain free, require no account, and retain their documented behavior. Commercial work is an optional SDK/evidence layer, never a feature removal, forced telemetry, or hosted-service dependency. A regression gets a same-day triage; commercial work pauses if a critical compatibility regression remains open for more than one business day.

## Weekly execution plan

### Week 1 — 19–25 August: make the existing proof customer-grade

**Exact deliverables**

- Resolve the remaining receipt signature-format compatibility failures so the evidence integration suite passes completely.
- Freeze `EvidenceBundleV1` and publish a short methodology note: matched inputs, provider-cache accounting, quality criteria, signing, and offline verification.
- Package the already completed small, medium, and large OpenAI scenarios as three redacted, signed evidence folders plus one customer-readable HTML/Markdown report.
- Add one release-gate script and CI job that installs/smoke-tests the supported Cursor, Codex, and Claude Code paths against the current OSS release.
- Write the one-page pilot scope, standard data-handling note, US$5,000 invoice template, and a named list of 30 persona-matched companies.

**Success metric**

- Three bundles verify offline from a clean checkout; receipt tests are green; all three OSS smoke tests pass; 30 accounts are researched with a named buyer and reason they likely exceed 100 tasks/week.

**Explicitly PARK**

- Marketplace, Agent Builder, hosted agents, control plane, dashboards, team accounts, and every new provider/framework adapter.

**Risk + mitigation**

- *Risk:* The 79–86% result is dismissed as a repository benchmark.  
  *Mitigation:* State the conservative methodology and customer threshold plainly; do not market the benchmark as a promised saving.

### Week 2 — 26 August–1 September: ship one installable SDK wedge

**Exact deliverables**

- Ship `LeanCTX.wrap(agent)` for the Python OpenAI Agents SDK with a versioned configuration object, explicit opt-in evidence mode, error handling, and rollback/uninstall path.
- Ship a 15-minute quickstart that runs one agent task, produces a receipt, and verifies it offline; include a working sample repository and a pinned dependency lockfile.
- Extend `scripts/pilot-setup.sh` to install this wrapper, check prerequisites, configure a local output directory, and remove all pilot configuration cleanly.
- Add a deterministic integration test that executes the sample workflow in baseline and treatment modes and checks that the resulting bundle verifies.
- Send 15 highly personalized research/pilot invitations and schedule five discovery calls; the request is for a workflow and spend profile, not an architecture pitch.

**Success metric**

- A developer unfamiliar with the repository completes the quickstart in 15 minutes or less; the wrapper test and all three OSS smoke tests are green; at least five qualified discovery calls are booked.

**Explicitly PARK**

- TypeScript SDK enhancements, Vercel/LangChain/LiteLLM changes, automatic model routing, persistent memory, and an SDK abstraction redesign.

**Risk + mitigation**

- *Risk:* The wrapper changes agent behavior or feels invasive.  
  *Mitigation:* Make wrapping opt-in and reversible, preserve the agent's native call path, and record the context decision separately from the application logic.

### Week 3 — 2–8 September: make a customer run safe and comparable

**Exact deliverables**

- Ship a pilot workload manifest that pins repository commit, task, prompt, model, provider options, quality tests, and redaction policy before a run starts.
- Ship a local redaction/preflight command that lists files and fields leaving the machine, blocks secrets by default, and creates a consent record in the evidence bundle.
- Add quality-scorecard support for the customer's automated test command plus a named human reviewer decision; a bundle cannot claim success without both fields.
- Run two internal rehearsal pilots using the exact setup and report template, including failure/rollback drills.
- Select one design-partner candidate with a qualified workflow and obtain written agreement on scope, quality bar, access path, and decision date.

**Success metric**

- Two rehearsal bundles pass offline verification and meet the 40% VCP-SAT threshold without quality regression; one prospect has a signed pilot scope or a dated technical-validation session.

**Explicitly PARK**

- Cloud data ingestion, remote storage, SSO, enterprise audit dashboards, production-repository access by default, and unsupported-provider claims.

**Risk + mitigation**

- *Risk:* Security review stalls access to source code.  
  *Mitigation:* Start with a non-production repo or representative task; keep all artifacts local/redacted and give the customer the offline verifier before requesting any data.

### Week 4 — 9–15 September: prove the end-to-end customer delivery

**Exact deliverables**

- Execute the selected prospect's first matched baseline/treatment run on one agreed workflow and hand over the signed evidence folder within two business days.
- Ship an executive report template containing VCP-SAT, cache treatment, quality outcome, reproducibility instructions, limitations, and a one-page recommendation.
- Ship an operator runbook for a repeat test: prepare manifest, run baseline, run treatment, review quality, verify, and export report.
- Publish a truthful product page and one-pager that use only verified ranges and explain the paid pilot; preserve the separate OSS installation path.
- Hold the results review and issue the US$5,000 paid-pilot proposal with the measured workload and decision date inserted.

**Success metric**

- One prospect has a complete, independently verifiable customer-specific result and a proposal; the prospect can re-run `lean-ctx verify` without Yves.

**Explicitly PARK**

- Claims of general “agent orchestration,” a freemium conversion funnel, fundraising materials, and building a public customer dashboard.

**Risk + mitigation**

- *Risk:* Baseline and treatment differ in hidden ways.  
  *Mitigation:* Reject any unmatched run; use the manifest hash, pinned commit/model, signed receipts, and pre-agreed quality checks as the admission criteria.

### Week 5 — 16–22 September: sell a bounded outcome

**Exact deliverables**

- Conduct the five discovery calls and record one-page qualification notes: task volume, monthly provider spend, current framework, buyer, quality bar, security constraint, and next date.
- Deliver three live evidence demos using the same 20-minute script: existing agent → wrapper → matched run → offline verifier → commercial decision.
- Send at least 20 additional account-specific outreach messages and five pilot proposals; each proposal is the fixed US$5,000/30-day scope, not a custom software quote.
- Create a concise objection sheet for caching, quality, data exposure, OSS longevity, and “we can just compress prompts ourselves.”
- Maintain a single deal board with only qualified accounts and a next action/date; drop unqualified leads instead of nurturing a broad funnel.

**Success metric**

- Ten qualified conversations completed, three technical validations scheduled or completed, and at least one US$5,000 prepaid proposal in a buyer's approval process.

**Explicitly PARK**

- Discounts below the fixed founding price, pilots without a measurable workflow, custom feature commitments, content marketing campaigns, and partner/channel work.

**Risk + mitigation**

- *Risk:* Buyers want a free proof of concept.  
  *Mitigation:* Offer the existing public evidence and a 20-minute validation demo free; reserve bespoke setup, customer runs, and signed reporting for the prepaid pilot.

### Week 6 — 23–29 September: collect the first revenue

**Exact deliverables**

- Close one fixed-scope pilot: signed order, US$5,000 payment collected, named technical owner, agreed quality gate, and a kickoff date within five business days.
- Onboard that customer using the Week-3 manifest and runbook; complete the first of up to three agreed workflows.
- Release the OSS compatibility-checked version with a changelog separating free runtime improvements from optional commercial pilot tooling.
- Send a clear “not now” response to every request outside the single integration and maintain a public/OSS issue label for compatibility regressions.

**Success metric**

- **First paying customer and at least US$5,000 cash collected**; its first workflow has a pinned manifest and a scheduled result review; Cursor, Codex, and Claude Code smoke tests remain green.

**Explicitly PARK**

- Building for the second customer's stack, usage-based billing, a self-serve checkout, internal analytics, and hiring.

**Risk + mitigation**

- *Risk:* Procurement delays payment beyond the 90-day window.  
  *Mitigation:* Target founder-led SaaS buyers able to pay by card or simple invoice; offer a standard short order form and move stalled enterprise accounts out of the active slot.

### Week 7 — 30 September–6 October: make the pilot repeatable

**Exact deliverables**

- Convert the customer delivery steps into a versioned Pilot-in-a-Box repository: intake questionnaire, manifest template, redaction checklist, setup script, report template, and rollback instructions.
- Add an evidence-run status file that records only deterministic phase/state (prepared, baseline complete, treatment complete, reviewed, verified); no hosted control plane.
- Complete the paid customer's remaining agreed workflows and hold a weekly result review against VCP-SAT and quality.
- Prepare an anonymized before/after case-study draft and a reference-request script, subject to written customer approval.

**Success metric**

- A second qualified engineer can prepare a pilot environment in two hours or less using the runbook; all customer workflows have reproducible manifests and signed bundles.

**Explicitly PARK**

- Multi-tenant architecture, user management, managed secrets, live telemetry, and expansion to a second integration.

**Risk + mitigation**

- *Risk:* Yves becomes the bottleneck for every run.  
  *Mitigation:* Time-box concierge support, encode every repeated step in the kit, and have an AI agent execute/review the documented checklist before Yves intervenes.

### Week 8 — 7–13 October: turn proof into repeatable revenue

**Exact deliverables**

- Deliver the paid customer's final report, signed evidence archive, executive results call, and US$1,500/month conversion proposal.
- Obtain either a written reference/case-study approval or a pre-approved anonymized quote; never publish customer numbers without consent.
- Use the completed proof to send 25 tightly targeted outreach messages and run four second-wave demos.
- Issue two new fixed-scope pilot proposals using the now-standard Pilot-in-a-Box package.
- Publish a support matrix that explicitly names the first supported paid path (Python/OpenAI Agents SDK) and the continuously supported OSS paths (Cursor, Codex, Claude Code).

**Success metric**

- The first customer has a verified report with a measured VCP-SAT result, a conversion decision date, and at least two new qualified proposals are active.

**Explicitly PARK**

- Publishing unapproved customer data, changing OSS licensing, case-study embellishment, adding a second framework adapter, and a broad “Thinkery platform” launch.

**Risk + mitigation**

- *Risk:* Savings are real but below the 40% commercial threshold.  
  *Mitigation:* Report the honest result, diagnose task/context composition with the customer, and do not convert on a false claim; use the finding to refine qualification rather than adding features.

### Week 9 — 14–20 October: expand customers, not product surface

**Exact deliverables**

- Start a second paid pilot or close a three-month conversion from the first customer; use the identical scope, wrapper, manifest, and report template.
- Ship only the SDK hardening exposed by the first pilot: documented error codes, stable receipt schema migration guidance, and regression fixtures from real (redacted) failure modes.
- Add a local CI example that runs the same OpenAI Agents SDK wrapper on a scheduled representative task and exports a verified bundle; it must remain optional and customer-controlled.
- Produce a one-page unit-economics sheet showing the customer's VCP-SAT change, monthly run rate, pilot price, and payback calculation from provider-reported inputs.

**Success metric**

- Two paid commercial commitments total (two pilots or one pilot plus one conversion), and the SDK hardening changes are traceable to a recorded customer failure or request.

**Explicitly PARK**

- Second-provider/framework support, per-seat pricing, sales automation, SOC 2 work, managed hosting, and speculative SDK APIs.

**Risk + mitigation**

- *Risk:* Every prospect asks for a different framework.  
  *Mitigation:* Treat framework demand as evidence: record buyer, revenue, workflow volume, and willingness to prepay; no adapter is built on interest alone.

### Week 10 — 21–27 October: decide expansion using revenue evidence

**Exact deliverables**

- Run a 90-minute product/revenue review over all signed bundles, VCP-SAT outcomes, sales stages, support time, and explicit integration requests.
- Write and publish internally an integration decision memo. A second adapter may enter the next plan only with **two paid/prepaid requests totaling at least US$10,000 annualized value** and a shared framework; otherwise Python/OpenAI remains the sole paid integration.
- Ship a maintenance OSS release if needed and execute the Cursor/Codex/Claude Code regression matrix before release.
- Finalize the first customer's conversion or document a measured non-conversion reason in the deal board.

**Success metric**

- A written, evidence-backed go/no-go decision exists; no roadmap item is accepted without a revenue/proof link; OSS compatibility remains green.

**Explicitly PARK**

- Letting a loud user choose the roadmap, unpriced enterprise requirements, an integration “matrix,” and building an investor demo unrelated to a buyer workflow.

**Risk + mitigation**

- *Risk:* The founder expands prematurely after a single good result.  
  *Mitigation:* Enforce the two-paid-request/US$10,000 annualized gate; retain the one-integration focus until the gate is met.

### Week 11 — 28 October–3 November: audit the thesis, not activity

**Exact deliverables**

- Produce the 90-day Evidence Ledger: every customer/workflow, matched baseline and treatment cost, successful-task count, VCP-SAT delta, quality result, verification status, cash collected, and support hours.
- Produce an SDK Thesis Scorecard: time-to-first-wrapped-task, external developer completion rate for the quickstart, number of independently verified customer bundles, paid commitments, and OSS regression record.
- Hold renewal/expansion calls with every paying customer and make a written next-step decision for each: convert, repeat pilot, pause, or stop.
- Publish one redacted public evidence update only if it passes customer approval and is exactly reproducible from the linked methodology.

**Success metric**

- The ledger shows at least one paying customer, at least one independently verifiable customer bundle, no unresolved critical OSS regression, and an explicit conversion/renewal outcome for every customer.

**Explicitly PARK**

- Rebranding, fundraising process, broad press, feature launches, and interpreting anecdotal praise as validation.

**Risk + mitigation**

- *Risk:* Positive conversations conceal weak economics or excessive founder support.  
  *Mitigation:* Include cash received and support hours in the ledger, and use verified VCP-SAT plus renewal intent—not sentiment—as the decision inputs.

### Week 12 — 4–10 November: state exactly where we are and choose the next 90 days

**Exact deliverables**

- Write the 90-day decision memo with all evidence, misses, customer quotes (approved only), OSS status, unit economics, and a single next-quarter choice.
- Archive signed customer bundles, manifests, reports, and methodology in a reproducible customer-delivery folder; test restore/verification from a clean machine.
- Send a direct status update to the OSS community describing maintained compatibility, what remains free, what the optional pilot proves, and what is deliberately not being built.
- Select exactly one next-quarter path using the gates below, then create only the first two weeks of that follow-on plan.

**Success metric — where we are at day 90**

The SDK thesis is **validated enough to continue** only if all of these are true:

1. At least **one paying customer** has paid (target: two paid commitments and at least US$10,000 collected/contracted).
2. At least one customer-specific, signed bundle independently verifies a **>=40% VCP-SAT reduction with no quality regression**.
3. An external developer completed the OpenAI Agents SDK wrapper quickstart and produced a valid bundle without Yves changing their agent architecture.
4. Cursor, Codex, and Claude Code remain supported by passing release smoke tests, with no critical unresolved compatibility issue.
5. Support time is below four founder hours per active customer per week after onboarding.

If every gate passes: keep the Context Runtime/SDK wedge, convert the first customer, repeat the fixed pilot, and build the next integration only when the Week-10 demand gate passes. If any proof or revenue gate fails: keep the OSS runtime healthy, stop platform expansion, publish the honest learning, and run one narrowly redesigned paid-pilot cycle based on the failure—rather than building Marketplace, hosted agents, or a control plane.

**Explicitly PARK**

- Any next-quarter feature list before the decision memo; unvalidated platform ambitions; licensing changes that harm current OSS users.

**Risk + mitigation**

- *Risk:* The plan ends with technology output but no durable buyer signal.  
  *Mitigation:* Treat failure to collect payment or demonstrate quality-preserving VCP-SAT reduction as a stop-and-redesign signal, not a reason to widen the roadmap.

## Founder operating cadence

- **Monday:** inspect VCP-SAT/evidence ledger, choose the week's one customer/proof bottleneck, and explicitly park anything else.
- **Tuesday–Wednesday:** build or deliver only the current proof-loop artifact; AI agents handle bounded implementation, testing, prospect research, and documentation.
- **Thursday:** customer calls, demos, pilot results, and proposals; no “research” call without a next decision/date.
- **Friday:** ship one compatibility-checked OSS release or pilot artifact, update the deal board and Evidence Ledger, and prune scope.

This cadence protects the core: LeanCTX stays a strong OSS context runtime for Cursor, Codex, and Claude Code while Thinkery earns the right to exist through independently verifiable customer economics.
