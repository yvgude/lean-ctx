# Vision rewrite report

## Completed

- Replaced the legacy numbered vision set with five focused documents:
  - `00-NORTH-STAR.md`
  - `01-PRODUCT-ARCHITECTURE.md`
  - `02-OSS-VS-PAID.md`
  - `03-ROADMAP.md`
  - `04-GO-TO-MARKET.md`
- Deleted obsolete numbered documents `05` through `24`.
- Kept `the_plan.md` unchanged as the source of truth.

## Editorial decisions

- Positioned LeanCTX as the Context SDK for AI Agents and an efficiency layer
  for existing workflows.
- Defined Thinkery as the paid organizational operating layer, not a gated
  "LeanCTX Pro" tier.
- Used the chiptuner model to explain measured, safe, profile-guided tuning.
- Made the OSS boundary structural: manual local tuning stays open; continuous,
  shared, governed tuning is commercial.
- Framed claims around comparable evidence and quality gates rather than
  universal token-savings assertions.
