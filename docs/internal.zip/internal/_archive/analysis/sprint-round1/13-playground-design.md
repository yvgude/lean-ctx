# LeanCTX Playground — product and delivery brief

## Recommendation

Launch a **static web UI backed by one stateless, rate-limited compression endpoint**. It is the fastest credible one-week route: visitors get the same compression behaviour as LeanCTX, with no local installation, while the browser remains responsible for editing, presentation, local history, and sharing.

Do not make a browser-only WASM port a launch dependency. It is the right long-term privacy and unit-cost destination, but porting the production compression pipeline and proving output parity is a larger project than a one-week MVP. Define a small `CompressionEngine` interface now, implement it with the HTTP endpoint first, and introduce a WASM implementation behind the same interface when the portable core is ready.

**North-star moment:** a developer pastes a file, hits Compress, and in under two seconds understands exactly what context was removed, retained, and saved.

## UX: paste → compare → trust

### Primary screen

The first screen is deliberately single-purpose:

1. A language-aware editor says “Paste a file or drop one here” and includes a short, realistic sample.
2. Controls are minimal: language (auto-detected, editable), compression mode, and **Compress**. The initial MVP can support the default LeanCTX mode only; show the chosen mode in the result so the comparison is reproducible.
3. The result appears side-by-side: **Original** on the left and **LeanCTX output** on the right. Preserve line numbers and syntax highlighting, with omitted regions rendered as a visible, explanatory fold—not silently erased text.
4. A persistent savings bar presents: `12,480 → 3,110 tokens · 75% less context · 9,370 tokens saved`. It also shows bytes and lines as secondary facts.
5. Below it, two plain-language callouts establish trust: “Kept: imports, public API, error paths” and “Condensed: repetitive implementation/detail.” These must be derived from actual compressor metadata; omit them until the backend can provide evidence.

Useful result actions:

- Copy compressed output
- Download `.leanctx` / copy CLI equivalent
- Compare as unified diff
- Reset / try another file
- Share result

### Key product choices

- Default to **nothing leaving the browser until Compress is clicked**; say this plainly adjacent to the button.
- Display a brief retention promise: requests are processed in memory, not logged or retained. This must be operationally true before it is claimed.
- Use the same tokenizer/version for both numbers, label it (for example, `cl100k_base estimate`), and include it in copied/shareable results. “Token saving” without a defined tokenizer is misleading.
- Set a 200 KB MVP input limit and gracefully offer CLI installation for larger repositories. A playground should produce a fast first win, not become an upload service.
- Support Markdown, Rust, TypeScript/JavaScript, Python, Go, JSON, and YAML initially; treat unknown text as plain text. Do not imply language-aware handling where none exists.

### Empty, loading, and failure states

- Empty: show the sample, never a dense documentation wall.
- Loading: retain both panes, show `Compressing locally/securely…`, and avoid progress percentages that cannot be measured accurately.
- Failure: preserve the input, show the specific safe remediation (file too large, rate limited, unsupported mode, service unavailable), and offer retry/copy input.
- Mobile: use stacked panes and make the savings bar remain visible; the editor experience remains desktop-first.

## Architecture decision: WASM versus thin server

| Concern | WASM in browser | Thin stateless server | MVP decision |
| --- | --- | --- | --- |
| No install / first use | Excellent | Excellent | Tie |
| Privacy | Code never leaves device | Code crosses TLS to service | Server must have explicit no-retention policy |
| Output parity with CLI | Needs portable core and parity harness | Calls canonical engine | Server wins |
| One-week delivery risk | High if Rust core uses filesystem, threads, native crates, or config | Low–medium | Server wins |
| First-load cost | WASM binary can be material | Small UI; compute happens remotely | Server wins |
| Marginal compute cost | Near zero | Per request | WASM wins later |
| Abuse control | Browser absorbs work | Needs rate limits / max body / WAF | Required server hardening |

### Thin-server MVP design

```
Browser (editor, diff, local history, token display)
        │ POST /v1/compress { content, language, mode, engineVersion }
        ▼
Edge Worker / small HTTP service
  validate size + rate-limit + no request logging
        ▼
Canonical LeanCTX compression core
        ▼
{ compressed, metrics, omissionRanges, engineVersion, tokenizerVersion }
```

Host the UI as immutable static assets. The endpoint accepts raw pasted text, uses an in-memory request lifecycle only, disables application/request-body logs, never writes source to analytics/error reporting, and returns strict CSP/CORS headers. Apply per-IP and per-session quotas plus a hard input/output timeout. Avoid a database, authentication, accounts, or a queue in the MVP.

The compressor should return structured ranges/metadata, not only a rendered string; this lets the UI highlight folds and explain the delta without attempting to reverse-engineer output. Return an `engineVersion` and `tokenizerVersion` in every response so later regressions can be diagnosed.

### Path to WASM

Extract a deterministic, filesystem-free compression-core crate with an API similar to:

`compress(source, language, mode) -> { output, metrics, omissions }`

Run the same corpus against the server/native build and the WASM build in CI, requiring byte-for-byte output plus equal metrics. Once it is within a reasonable download budget (target: <1 MB compressed) and has parity, load it progressively after the static UI. Keep the endpoint as a fallback for unsupported modes and older browsers.

The potential end state is compelling: static hosting only, private-by-default compression, and a “Runs entirely in your browser” claim. It should be earned through parity tests, not approximated with a JavaScript reimplementation.

## One-week MVP

### In scope

- Paste/drop one text file (max 200 KB)
- Auto-detect/select language
- One production LeanCTX compression mode
- Original/compressed side-by-side view with folds
- Token/byte/line metrics and percentage saved
- Copy result and reset
- Client-side share links for small payloads
- Static deploy, stateless endpoint, basic abuse protection, privacy copy
- Instrument only aggregate, source-free events: page loaded, sample used, compression succeeded/failed, copy, share

### Explicitly out of scope

- Repository/GitHub import, multi-file projects, login, collaboration, saved server history
- Arbitrary custom modes/configuration, account billing, private team deployments
- A full WASM port, real-time collaboration, AI explanations

### Day-by-day delivery plan

| Day | Deliverable |
| --- | --- |
| 1 | Clickable UI and API contract; choose tokenizer; build a fixed example corpus and visual acceptance criteria. |
| 2 | Stateless `/v1/compress` wrapper around the canonical engine with limits, timeout, version fields, and contract tests. |
| 3 | Editor, paste/drop, language selection, request flow, original/compressed panes. |
| 4 | Diff/fold rendering, accurate metrics, copy/download, empty/error/accessibility states. |
| 5 | Fragment sharing, event instrumentation, rate limits, CSP, privacy/security review. |
| 6 | Cross-browser/mobile QA, load test to quota, docs/README integration, polish. |
| 7 | Dogfood with maintainers and 5–10 target developers; fix top friction and launch. |

**Launch acceptance criteria:** a 100–200 KB supported source file completes within 2 seconds at p95 under expected early traffic; saving calculations use a declared tokenizer; pasting source does not persist it; and server output matches the tested LeanCTX engine version.

## Viral loops that do not leak code

### Shareable results

Make sharing opt-in and source-private by default.

- **Small share:** encode a compressed, URL-safe payload in the URL fragment (`#…`), which browsers do not send to the server. The receiving app decodes it locally. Enforce a conservative URL length limit and display the exact share contents before copying.
- **Large share:** create an optional, expiring server token only after explicit consent. Encrypt stored payloads, make expiry short (for example 7 days), allow revocation, and never index public links. This is post-MVP unless there is strong demand.
- **Safer social card:** provide a share card containing language, original/compressed token counts, percent saved, engine version, and an optional user-selected project name—but never source text. “I cut 75% of my context with LeanCTX” is enough to create curiosity.

### README badges

Offer a static badge generator based on a user-selected result, e.g.:

```md
[![LeanCTX: 75% fewer tokens](https://leanctx.dev/badge/75-percent.svg)](https://leanctx.dev/playground)
```

The first version can be a canonical static SVG route, where the percent is presentation only. Label it “from this file/run” rather than a project-wide claim. A later verified badge can come from a CI action that emits a signed result, preventing vanity or misleading values.

Add a compact “Try this file in the playground” README link convention for open-source repos. It should deep-link to a public example or an explicitly generated fragment link, never scrape a repository automatically.

### Distribution surfaces

- Seed the playground with real, consented before/after examples from LeanCTX’s own codebase and documentation.
- Show a one-click “copy result summary” suitable for PR descriptions and developer social posts.
- Add the playground link to CLI output, docs, package pages, and release notes.
- Track activation as `first successful compression`; optimize the path to that event before adding gamification or leaderboards.

## Hosting cost and operating envelope

### Recommended initial deployment: Cloudflare Pages + Worker

For a pure static UI, CDN asset delivery is effectively the cost floor; Cloudflare Pages advertises unlimited free static-asset requests. If a Worker/Pages Function is used, the Free plan has a 100,000 request/day shared limit; the paid Workers plan has a $5/month minimum and no data-transfer charge, with usage thereafter. See [Cloudflare Pages pricing](https://developers.cloudflare.com/pages/functions/pricing/) and [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/).

Practical budget:

| Stage | Architecture | Expected platform cost | Notes |
| --- | --- | ---: | --- |
| Prototype / low traffic | Static Pages + WASM or Free Worker | $0/month | Viable if compute is client-side or well below daily function quota. |
| Public MVP | Static Pages + paid Worker | $5–20/month | Start here if the engine fits Workers and traffic is modest; monitor CPU, not only requests. |
| Canonical engine needs a container | Static CDN + small container/VPS | $10–40/month | Includes an always-on small service; add a CDN/WAF in front. |
| Strong adoption | CDN + autoscaled API / hybrid WASM | $50–300+/month | Compute volume and observability dominate until WASM moves most work to browsers. |

If we choose Vercel instead, Hobby is $0 for personal/small-scale use and Pro is $20/month with usage credits; the pricing page lists function usage beyond included limits. That is convenient for a Next.js build, but has less compelling economics than static + Worker for this very small API. See [Vercel pricing](https://vercel.com/pricing).

### Cost controls

- Cap input size, compression time, output size, and requests per IP/session.
- Perform token counting and UI diffing in the browser when possible.
- Avoid sending analytics that include source, paths, or prompt text.
- Cache only consented, content-addressed public examples—never arbitrary developer input.
- Set a monthly budget alert and a fail-closed degradation: static UI remains available and tells visitors to try the CLI if compression capacity is exhausted.

## Decisions needed before implementation

1. Confirm whether the canonical compression core can execute within the chosen edge runtime; if not, deploy a small container rather than rewriting behaviour for the playground.
2. Select and document the tokenizer used for the public savings number.
3. Approve the no-retention policy and verify logs, traces, and error tracking enforce it.
4. Choose the first compression mode and language set from an existing tested LeanCTX corpus.

## Success measures

- Visitor → first compression conversion
- Median and p95 time to first result
- Median token reduction for successful runs, segmented by language
- Copy/share rate after a result
- Endpoint error/rate-limit rate
- Zero detected source retention events

The leading product metric is not page views: it is the share of visitors who reach a credible, reproducible “before/after” result and then choose to copy, share, or install LeanCTX.
