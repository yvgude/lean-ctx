# Quality belongs in the real-world evidence receipt

## Scope and source note

`docs/internal/vision/the_plan.md` is not present in this checkout, so its quality
and receipt wording could not be read directly. This proposal follows the requested
receipt headings and the implementation seams that do exist:

- `rust/src/cli/dispatch/evidence_realworld.rs` runs two five-turn arms and retains
  every turn response in `TurnResult`.
- `rust/src/cli/dispatch/evidence_workflow.rs` already has a useful, but lightweight,
  `QualityScore` based on issue count, keyword overlap, code presence, and length.
- `rust/src/cli/dispatch/evidence_report.rs` renders `RealWorldResult` as HTML.

The core claim must become: **lean-ctx lowers cost while treatment quality met a
declared equivalence gate**. It must not claim that token overlap or response length
alone proves quality.

## Study design

### The fifth turn is a shared, scoreable final task

Keep turns 1--4 unchanged. Make turn 5 a constant `FINAL_REVIEW_QUESTION` with the
same system prompt, task text, model parameters, and response schema for both arms.
Neither arm sees the other arm's answer.

Suggested final question (version and SHA-256 are recorded):

> Based only on the material supplied in turns 1--4, identify the highest-value
> review findings. For each finding give: a precise `path` plus `line` or `symbol`,
> the observed evidence, why it matters, and a concrete fix. Do not report a finding
> without an anchor. Return the requested JSON schema.

Use a JSON schema when the provider supports it; otherwise require one fenced JSON
object and fail the quality gate as `inconclusive` if it cannot be parsed. A response
schema makes automatic checks reproducible and avoids treating prose length as a
quality signal.

```json
{
  "summary": "string",
  "findings": [
    {
      "id": "F1",
      "severity": "critical|high|medium|low",
      "title": "string",
      "location": { "path": "src/x.rs", "line_start": 12, "line_end": 16, "symbol": "optional" },
      "evidence": "exact short source excerpt or test-output excerpt",
      "impact": "string",
      "fix": "concrete code or test change",
      "confidence": "high|medium|low"
    }
  ]
}
```

Fairness controls:

- Set `temperature: 0`; supply a provider seed when supported; record unsupported
  controls rather than pretending determinism.
- Use identical task/response/schema hashes in both arms, and record the input hashes
  and tool modes actually shown to each arm.
- Score after both turn-5 responses are complete. Quality scoring must not affect
  either model conversation.
- Keep evaluator cost separate from task cost. Include it in the receipt so an
  evidence run cannot hide the price of proving its claim.

## Automatic quality scoring

The automatic scorer evaluates each response independently, then compares treatment
with baseline. It verifies the *grounding* of an issue against the checked-out target,
not merely that both models used similar words.

| Dimension | Automatic evidence | Per-arm score |
| --- | --- | --- |
| Correctness | Location exists; requested line/symbol resolves; quoted evidence occurs there; issue is distinct; any referenced test output exists in the captured turn material. | 0--100 |
| Actionability | Finding has an anchor, impact, and a specific fix; full credit when the fix names the code/test change rather than just "handle this". | 0--100 |
| Completeness | Coverage of an independently produced candidate set: deterministic static checks plus unique, grounded findings from either arm. A response is not rewarded for duplicate variants. | 0--100 |
| Hallucination | Invalid paths/lines/symbols, unverified quotes, unsupported test claims, and duplicate claims are violations. Score is `100 - violation_rate`. | 0--100 |

`issue_count`, `actionable_count`, `anchored_count`, `invalid_anchor_count`,
`unsupported_claim_count`, `duplicate_count`, and matched candidate IDs are emitted
alongside the four scores. They are audit evidence, not hidden heuristics.

Candidate-set construction must be deterministic and versioned. Start with targeted
checks that have low false-positive rates for the reviewed language/project (for
example, a failing test reference, an actual `unwrap` in a relevant error path, or a
public API without a documented error branch). Each candidate includes the source
hash and range that triggered it. The union of valid, non-duplicate findings from both
arms may be shown as *supplemental coverage*, but must not become the only oracle:
agreement can reproduce the same mistake.

Composite score:

```text
quality = 0.35 * correctness
        + 0.30 * actionability
        + 0.20 * completeness
        + 0.15 * non_hallucination
```

Default equivalence gate:

```text
PASS only when
  treatment.composite >= baseline.composite - 5.0
  treatment.correctness >= baseline.correctness - 5.0
  treatment.hallucination >= baseline.hallucination - 2.0
  treatment.parseable && treatment.anchored_count > 0
  scorer_status == "complete"
```

`5.0` is a tolerance, not a universal truth; record it as `quality_policy` and make
it configurable. If no static candidate source applies, label completeness
`not_measured` and set the verdict to `inconclusive`, not pass. The receipt can still
report cost savings, but cannot make the equivalence claim.

## Optional LLM-as-judge

The automatic scorer is mandatory and cheap. An LLM judge is opt-in corroboration,
not a replacement.

1. Send a second model the final question, masked answers `A` and `B`, and the
   per-finding verification packets (path/range/source excerpt/hash and static
   candidate set). Do not reveal baseline/treatment labels or cost.
2. Ask it to score correctness, actionability, completeness, and hallucination on
   the same 0--100 rubric; require a machine-readable result and concise citations to
   the packets.
3. Repeat with A/B order reversed, average the two per-answer scores, and record
   disagreement. This controls positional bias.
4. Prefer a configured model distinct from the task model. If the same model is
   selected, mark `independent: false` in the receipt.
5. A judge transport/parse failure yields `judge.status: unavailable`; automatic
   evidence remains usable, but the report must not say "judge verified".

Recommended CLI policy:

```text
--quality-judge off                 # default; automatic scoring only
--quality-judge <model>             # enables blind two-order judging
--quality-judge-endpoint <url>
--quality-judge-api-key <key>
--quality-equivalence-tolerance 5
```

Judge request/response hashes, model/provider details, and judge token/cost usage
are retained in `quality-judge.json`; do not put API keys or full source contents in
the receipt.

## Integration plan

### `evidence_realworld.rs`

1. Add `FinalReviewResponse` parsing, deterministic verification helpers, and
   serializable types `ArmQuality`, `QualityDimensionScores`, `QualityPolicy`,
   `QualityJudge`, and `QualityComparison`. Reuse/adapt the workflow module's
   `score_quality` only for its issue extraction concepts; do not reuse keyword
   overlap as a correctness proof.
2. Define the fixed fifth `TurnContent` from `FINAL_REVIEW_QUESTION` and run the
   arms as today. `ArmResult.turns.last().response` is the score input.
3. Immediately after both `run_arm` calls, invoke
   `score_realworld_quality(target, baseline_final, treatment_final, args)`. It reads
   only the target and captured final responses; it never changes either arm.
4. Add this field to `RealWorldResult`:

   ```rust
   pub quality_score: QualityComparison,
   ```

   The field name meets the command contract, while the object preserves baseline,
   treatment, dimensions, verdict, policy, and scorer evidence. Do not reduce the
   result to a single opaque number.
5. Persist `quality.json` and (when enabled) `quality-judge.json` in the existing
   realworld output directory. Print a terse terminal line such as
   `Quality: equivalent (treatment 87.0 vs baseline 86.2; automatic + blind judge)`.
6. Add tests for malformed final JSON, invalid anchors, source-hash mismatch,
   duplicate findings, threshold boundary behavior, A/B label masking, and receipt
   serialization. Tests must prove `inconclusive` is never reported as equivalent.

The current realworld code calls the provider once per turn and records real usage;
quality checking must use the same `call_llm_with_usage` path for a judge so its cost
is accounted for. The baseline/treatment task costs remain comparable even if judge
cost is separately displayed.

### `evidence_report.rs`

Add a **Quality equivalence** section directly after the cost summary:

- verdict badge: `Equivalent`, `Not equivalent`, or `Inconclusive` -- never a green
  treatment badge solely because cost fell;
- headline: baseline/treatment composite score and delta;
- four-row dimension table (baseline, treatment, delta, measurement status);
- finding evidence counts (reported, anchored, actionable, rejected/hallucinated,
  deterministic-candidate coverage);
- judge provenance/status and a link/reference to `quality-judge.json` if present;
- clear footnote: automatic grounding is evidence, while semantic correctness and
  completeness are bounded by the recorded candidate set.

Escape all response-derived text as the existing report does. Show final answer
hashes by default; place full answers behind an opt-in details element to keep a
receipt useful without exposing potentially sensitive source details.

## Receipt JSON

Use exactly these top-level receipt headings, in this order for canonical JSON:
`Task`, `Model`, `Provider`, `Context`, `Kit`, `Quality`, `Cost`, `Savings`,
`Signature`. The lower-case serializable Rust names may use `serde(rename = "Task")`
etc.; this preserves a machine-stable public format.

```json
{
  "schema_version": "realworld-receipt/v2",
  "Task": {
    "id": "code-review-final-v1",
    "target": "example-project",
    "turns": 5,
    "final_question_sha256": "6b1b...",
    "response_schema_sha256": "97dd..."
  },
  "Model": {
    "id": "gpt-4o-mini",
    "temperature": 0,
    "seed": 1729,
    "seed_status": "applied"
  },
  "Provider": {
    "endpoint": "https://api.openai.com/v1/chat/completions",
    "api": "chat-completions",
    "usage_source": "provider-reported"
  },
  "Context": {
    "baseline": {
      "prompt_tokens": 12400,
      "content_sha256": ["...", "...", "...", "...", "..."]
    },
    "treatment": {
      "prompt_tokens": 4300,
      "content_sha256": ["...", "...", "...", "...", "..."]
    },
    "target_sha256": "a13f...",
    "turns": 5
  },
  "Kit": {
    "name": "code-review",
    "version": "1.4.0",
    "definition_sha256": "c92e..."
  },
  "Quality": {
    "status": "equivalent",
    "policy": {
      "version": "quality-equivalence/v1",
      "weights": { "correctness": 0.35, "actionability": 0.30, "completeness": 0.20, "non_hallucination": 0.15 },
      "score_tolerance": 5.0,
      "hallucination_tolerance": 2.0
    },
    "baseline": {
      "composite": 86.2,
      "dimensions": { "correctness": 90.0, "actionability": 84.0, "completeness": 80.0, "non_hallucination": 100.0 },
      "evidence": { "issues": 5, "anchored": 5, "actionable": 4, "invalid_anchors": 0, "unsupported_claims": 0, "candidate_coverage": "4/5" },
      "response_sha256": "..."
    },
    "treatment": {
      "composite": 87.0,
      "dimensions": { "correctness": 90.0, "actionability": 88.0, "completeness": 80.0, "non_hallucination": 100.0 },
      "evidence": { "issues": 4, "anchored": 4, "actionable": 4, "invalid_anchors": 0, "unsupported_claims": 0, "candidate_coverage": "4/5" },
      "response_sha256": "..."
    },
    "delta": 0.8,
    "scorer": { "name": "grounded-final-review", "version": "1", "status": "complete" },
    "judge": {
      "status": "complete",
      "model": "gpt-4.1-mini",
      "independent": true,
      "label_orders": 2,
      "result_sha256": "..."
    }
  },
  "Cost": {
    "currency": "USD",
    "baseline_task": { "prompt": 0.0182, "completion": 0.0021, "total": 0.0203 },
    "treatment_task": { "prompt": 0.0065, "completion": 0.0019, "total": 0.0084 },
    "quality_evaluation": { "automatic": 0.0, "judge": 0.0017, "total": 0.0017 },
    "measurement_total": 0.0304
  },
  "Savings": {
    "prompt_tokens_pct": 65.3,
    "task_cost_usd": 0.0119,
    "task_cost_pct": 58.6,
    "quality_equivalence": "equivalent",
    "claim": "58.6% task-cost reduction at the recorded quality-equivalence gate"
  },
  "Signature": {
    "status": "signed",
    "algorithm": "ed25519",
    "key_id": "lean-ctx-evidence-2026-01",
    "canonicalization": "JCS/RFC8785",
    "signed_fields": ["Task", "Model", "Provider", "Context", "Kit", "Quality", "Cost", "Savings"],
    "value_base64": "..."
  }
}
```

When no signing key is configured, emit `Signature.status: "digest-only"` with a
canonical SHA-256 digest and no `value_base64`. A digest is not a signature; the
report must say that plainly. Likewise, use `Kit: null` or `{ "name": "none" }`
when no kit participated rather than inventing a kit identity.

## Acceptance criteria

- A realworld run evaluates both turn-5 answers with the same versioned question and
  saves enough hashes/counts to independently inspect the decision.
- The receipt has Task, Model, Provider, Context, Kit, Quality, Cost, Savings, and
  Signature sections; Quality says `equivalent`, `not_equivalent`, or `inconclusive`.
- The HTML report makes quality result as prominent as cost savings and exposes the
  four requested dimensions.
- Missing/invalid quality inputs cannot produce an equivalence pass.
- Judge use, independence, artifacts, and incremental costs are disclosed.
