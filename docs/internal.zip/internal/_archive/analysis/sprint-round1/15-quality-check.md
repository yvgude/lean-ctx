# Quality Check — Vision Sprint Synthesis

## Review scope and verdict

Reviewed the nine reports present: `02`, `04`–`06`, `08`–`10`, `12`, and
`14`. Reports `01`, `03`, `07`, `11`, and `13` were not present. This is a
material traceability gap, not evidence that their topics were resolved.

**Verdict: focused, credible direction; not yet an executable 90-day plan.**
The category, OSS intent, and evidence standard are unusually strong. The
launch contract, first offer, receipt/quality policy, and one integration must
be reconciled before implementation or sales materials are treated as source
of truth. A solo founder supported by AI agents can deliver the narrow wedge;
they cannot safely deliver every proposed adapter, benchmark, hosted product,
and sales motion in parallel.

## Top 5 issues

1. **The public SDK contract is internally inconsistent — P0 blocker.**
   `06-sdk-contract.md` defines `LeanCTX(...)`, `ctx.session()`,
   `session.prepare()`, and `ctx.wrap(target, ...)`. `09-reference-agent.md`
   instead uses a module-global `ctx`, `ctx.session(task, root)`, and
   `session.wrap(tool, output)`. `10-execution-plan.md` promises
   `LeanCTX.wrap(agent)`. These are materially different APIs and integration
   seams, so the claimed five-line reference diff cannot yet be true. Choose
   one executable API, update the reference agent to use the *OpenAI Agents
   SDK* named in the plan (not a direct Responses-only loop), and make the
   contract test/quickstart the sole authority.

2. **The first commercial offer has three incompatible versions.**
   `05-monetization.md` offers up to three CHF 0 founding pilots with a 10%
   verified-savings share, then a CHF 7,500–15,000 Tuning Sprint. `10` calls
   the first offer a US$5,000 prepaid 30-day pilot and proposes US$1,500/month
   conversion. They cannot all be the launch motion. Pick one currency,
   buyer, scope, payment point, and conversion rule. Recommendation: one
   prepaid fixed-scope pilot; defer zero-fee and savings-share arrangements
   until acceptance and settlement are proven.

3. **Evidence and quality rules have competing schemas and gates.**
   `10` freezes `EvidenceBundleV1` in Week 1; `14` proposes a title-cased
   `realworld-receipt/v2`; `06` describes a separate canonical
   `ExecutionReceipt`. The quality rules also differ: `08` uses task
   completion plus tests/clippy/fmt/diff review, `10` requires automated plus
   human review, and `14` specifies a code-review-finding composite and an
   optional LLM judge. Without one versioned profile, VCP-SAT is not stable
   enough for customer claims. Specify `EvidenceBundleV1` once, with a
   workload-specific quality-gate extension; adopt the `08` acceptance gates
   for repair tasks and retain `14` as a later review-task profile.

4. **The plan exceeds founder capacity before it reaches a buyer.**
   Week 1 alone combines signature repair, three signed/redacted bundles,
   three-agent compatibility CI, methodology, legal/payment collateral, and
   30-account research. It is followed by a new production wrapper,
   quickstart, installer/uninstaller, deterministic baseline/treatment test,
   redaction system, rehearsals, and active sales. In parallel, `08` proposes
   a new three-arm runner with 60 external-agent runs and `14` proposes a
   grounded scoring subsystem. AI agents can accelerate code and research, but
   cannot remove customer access, approval, payment, or review latency. Reduce
   the proof to one wrapper, one task, one local verifier, one internal
   rehearsal, and one paid pilot before building statistical benchmarking or
   elaborate quality automation.

5. **The scope is directionally focused but delivery still drifts outward.**
   The reports correctly reject agent frameworks, gateways, marketplaces, and
   governance platforms. Yet `06` specifies five adapter families, `08`
   requires Attach/Embed infrastructure, `05` schedules a playground,
   hosted evidence, Pro, Team, AutoTune, private registries, and enterprise
   controls, while `10` says the sole paid integration is Python/OpenAI Agents
   SDK. Keep the existing Cursor/Codex/Claude Code OSS paths healthy, but do
   not expand them during validation. The reference agent, contract, and
   customer offer must all demonstrate the same single wedge.

## Top 5 strengths

1. **Clear category and non-goals.** `02`, `04`, and `06` consistently frame
   LeanCTX as the Context SDK/runtime that improves an existing agent rather
   than replacing its runtime, gateway, observability, or governance stack.

2. **A differentiated, defensible mechanism.** Source-aware context at file,
   search, shell, provider, and handoff boundaries; deterministic recovery;
   and portable receipts are stronger than an unsupported “best compressor”
   claim.

3. **Evidence discipline is excellent.** `08`, `10`, and `14` insist on
   matched inputs, provider-reported accounting, quality gates, cache
   disclosure, signed/offline-verifiable artifacts, and honest inconclusive
   results.

4. **The OSS/commercial principle is sound.** `05` and `10` protect the free
   local runtime, SDK, adapters, local tuning, local receipts, and current
   agent integrations; paid value is continuous/shared/hosted/operational
   work rather than a crippled core.

5. **The execution philosophy has real stopping rules.** `10` uses VCP-SAT,
   a 40% no-regression threshold, explicit compatibility gates, demand gates,
   and a willingness to stop platform expansion when proof or revenue fails.

## OSS-boundary assessment

No paid capability is proven to be accidentally implemented in the public repo
by these reports alone; they contain no code-level entitlement inventory or
deployment map. Therefore **OSS leakage is unverified, not cleared**.

The intended boundary is coherent:

| Keep public and usable locally | Keep paid/private or require a Thinkery service |
| --- | --- |
| Runtime, SDK, supported wrappers/adapters, MCP/proxy, local Dyno/profiles/metrics, local receipts/verifier, Kit format/loader, Community Kits | Hosted history/scheduling/AutoTune, cross-device private profiles, private registry/premium Kits and managed refresh, shared receipts/economics, policy/budget controls, fleet ops, RBAC/SSO/SCIM, enterprise retention/SLA |

Required controls before a commercial release:

- Publish a capability/entitlement matrix and test it in CI.
- Keep protocol, local receipt generation, verifier, and client interfaces
  public; keep the multi-tenant hosted control-plane implementation and its
  credentials/deployment private.
- Do not gate local `wrap`, local receipts, local Kits, or manual tuning.
- Make every hosted/organization call explicit and fail safely without an
  account; no forced telemetry or silent upload.
- Define private-Kit access, cache, export, revocation, and self-hosted
  behavior before selling it. `02` identifies this missing specification.

## Recommended priority order

1. **Write a one-page launch decision record.** Fix the canonical public API,
   named first integration, `EvidenceBundleV1` schema/quality policy, OSS vs
   paid matrix, and one paid-pilot price/scope. This resolves Issues 1–3
   before code or promises fossilize them.

2. **Build one public, local wedge.** A Python OpenAI Agents SDK wrapper,
   exact reference agent, local receipt, offline verifier, rollback path, and
   deterministic acceptance test. Treat existing CLI/MCP compatibility as a
   regression obligation, not a new product stream.

3. **Run one internal rehearsal.** Use one frozen task/workload and the
   selected V1 quality gate. Measure matched baseline/treatment, validate
   redaction and recovery, and fix only blockers discovered here.

4. **Sell and deliver one prepaid pilot.** Obtain the customer’s quality bar,
   consent, workload manifest, and payment before bespoke delivery. Use the
   same wrapper, bundle, and report rather than a new integration.

5. **Make the expansion decision from evidence.** Only after a verified paid
   result should the team decide whether to build the rigorous 20-triplet
   integration-depth runner, a second adapter, or hosted/shared operations.

## What to PARK

- All new adapters beyond the first Python/OpenAI Agents SDK path: Anthropic,
  TypeScript/Vercel, LangGraph, LiteLLM, and framework matrices.
- The full 20-triplet Raw/Attach/Embed benchmark runner and its external-agent
  infrastructure; retain the protocol as a future standard, not a launch
  deliverable.
- LLM-as-judge, broad static candidate discovery, and the general code-review
  quality scorer until the repair-task V1 gate is working.
- Playground/Evidence Lite, hosted Evidence Runs, Pro, Team, AutoTune,
  private registry, shared dashboards, RBAC/SSO/SCIM, managed relay, and
  enterprise deployment.
- Zero-fee founding pilots, savings-share billing, self-serve checkout,
  usage/token pricing, and automated settlement.
- Marketplace, agent builder/hosting, control plane, generic governance,
  fundraising, and broad partner/channel work.

## Missing inputs to close before declaring readiness

- The absent sprint reports `01`, `03`, `07`, `11`, and `13`, or an explicit
  index explaining why they do not exist.
- A repository-backed feature inventory identifying what is shipped, proposed,
  and private-service-only.
- One named owner and version for the public API, receipt schema, quality
  policy, and commercial offer.
- Evidence from an external developer completing the quickstart and from a
  customer workflow; internal scenario results are encouraging but not
  sufficient market validation.
