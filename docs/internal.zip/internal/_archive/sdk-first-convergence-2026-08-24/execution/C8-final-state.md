# C8 — Final convergence state

> **Classification:** Historical snapshot. It is not current authority.

**Date:** 2026-08-20  
**Inputs read:** C1, C2, C3, C4, C5, C6, C7


## Execution status — 2026-08-21

Treat [`MASTER-EXECUTION-PLAN.md`](MASTER-EXECUTION-PLAN.md) as the live tracker. This C8 snapshot is historical.

## Final file count and structure

`docs/internal/` contains **99 files**:

```text
docs/internal/
├── root:        2 files  (README + top-level source material)
├── vision/:     5 files  (strategy and commercial direction)
├── execution/: 12 files  (weekly action, convergence, SDK, positioning)
├── reference/: 16 files  (technical, evidence, ICP, consistency analysis)
└── _archive/:  64 files  (6 root, 57 analysis, 1 roadmap)
```

The convergence workspace contains **8 reports** after this write: C1–C8.
`docs/internal/README.md` indexes every non-archive Markdown document. The
only unmatched README names are the two intentionally referenced archive
source files. `docs/internal/` is ignored by `.gitignore` at line 95.

## Remaining contradictions

No unresolved contradiction blocks execution.

Two wording guardrails remain:

1. LeanCTX is a provider-neutral product category; **v1 is deliberately
   OpenAI-Agents-SDK-first**. State both scopes together; do not market v1 as
   provider-complete.
2. V-ZUG validates an advanced-enterprise discovery lane; the initial paid
   wedge remains the 20–80 person B2B SaaS team. Do not treat validation as
   permission for a second roadmap, generic agent SDK, or harness migration.

The README now also uses the complete depth model: Baseline Control → Attach
→ Wrap → Embed.

## How do we converge everything?

**Converge responsibility, contracts, and releases—not directory trees or Git
histories.** Publish one versioned public facade with one owner and wire shape
per product object; keep existing engines and stores as implementation
substrate; prove the result through the receipt-and-evidence path before
shipping v1.

## Top five decisions Yves must make now

1. **Approve the v1 public contract:** LeanCTX, ContextSession,
   TuningProfile, ContextKit, ExecutionReceipt, and EvidenceBundle, with the
   five top-level SDK operations and a single canonical owner for each.
2. **Approve authority boundaries:** GitHub `main` is public truth;
   `packages/python-lean-ctx` / `lean_ctx` is the sole Python SDK/import;
   Rust workspace, CLI, and stdio MCP server remain singular; GitLab is a
   private legacy/deployment seam.
3. **Lock the v1 scope:** Python + one exact OpenAI adapter + real `ctx.wrap()`
   lifecycle surface; preserve legacy compatibility; reject framework,
   marketplace, broad migration, and invented-savings work.
4. **Choose the commercial motion:** sell the CHF 7,500 / 30-day / one-workflow
   founding pilot to the primary B2B SaaS wedge; run V-ZUG-style enterprise
   work only as a bounded, decision-dated validation lane.
5. **Set the release gate and owners:** no gain claim without baseline,
   quality outcome, immutable signed receipt, evidence bundle, and offline
   verifier; assign owners for facade, runtime coordinator, receipt/evidence,
   adapter, and conformance tests before implementation starts.
