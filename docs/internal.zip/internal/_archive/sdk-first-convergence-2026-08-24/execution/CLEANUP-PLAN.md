# D3 safe cleanup plan

Status: definitive execution plan

Prepared: 2026-08-20

Scope: public OSS repository yvgude/lean-ctx

Decision: stage, prove, archive, then remove.

This is a cleanup plan.

It is not authorization to delete every old-looking directory.

The public repository contains more shipped compatibility surfaces than its
top-level layout suggests.

No cleanup PR may change that fact by accident.

## Execution status — 2026-08-21

**WS-1 code cleanup is complete on `main`.** This document remains the safety contract (gates, rollback, archive-not-delete). Do not treat remaining Wave-4 OCLA items as WS-1 work — they belong to WS-4 after the paid-pilot exit criterion.

| Wave / follow-up | Status | Evidence |
|---|---|---|
| Wave 1 duplicate Python SDKs | **done** | `_archive/py-sdk/`, `_archive/python-sdk/`, `_archive/clients-python/` |
| Wave 2 unused experiments | **done** | `_archive/{marketing,email-templates,demo,blog,lean}/`; `lab/` stays gitignored |
| Wave 3 benchmark consolidation | **done then superseded** | `bench/`+`benchmark/` → `benchmarks/` (`6679c89`); later `benchmarks/` itself archived to `_archive/benchmarks/` (`6ff1e48`). Canonical runner: `scripts/benchmark/` |
| Prio 1 | **done** | deleted `ts-sdk/`; merged `contracts/` → `docs/contracts/ocla/`; merged `examples/` → `cookbook/examples/`; deleted stale `ci/gitlab-ci.yml` (`8ea700f`) |
| Prio 2+3 | **done** | archived specs, discord-faq, editor extensions, go-sdk, integrations (`6ff1e48`) |
| Prio 4+5 | **done** | archived stale scripts to `_archive/scripts/` (`235d135`); `bin/lctx` kept |
| GitLab | **done** | #1242–#1244 closed; milestone WS-1 closed (2026-08-21) |

**Active top-level tracked dirs (14):** `_archive/` `assets/` `aur/` `bin/` `clients/` `cookbook/` `docs/` `kits/` `packages/` `rust/` `scripts/` `security/` `skills/` `tests/`

**Canonical packages:** `packages/python-lean-ctx/` (PyPI `lean-ctx-python` 1.0.0), `packages/node-lean-ctx/`, `packages/ocla-grpc/`, `packages/leanctx-verify/`, `packages/lean-ctx-bin/`.

**Still open (not WS-1):** Wave 4 OCLA normalization = WS-4 (#1262+), blocked until GitLab #1254.

Restoration metadata: `_archive/README.md`.

---

## 1. Non-negotiable safety contract

1. Never delete on main directly.

2. Create one cleanup branch per logical batch.

3. Use the naming form cleanup/<wave>-<short-scope>.

4. Start each branch from current github/main.

5. Record the base commit in the PR description.

6. Do not mix feature work with cleanup.

7. Do not mix formatting sweeps with cleanup.

8. Do not mix dependency upgrades with cleanup.

9. Move uncertain code to an archive location first.

10. An archive move uses git mv.

11. A final removal uses git rm.

12. Never use untracked filesystem deletion as a repository cleanup mechanism.

13. Preserve history through Git for every move and removal.

14. Keep a removal manifest in each PR description.

15. The manifest lists old path, new path or deletion, owner, and reason.

16. Every candidate needs an evidence classification.

17. Classification values are shipped, supported, used, experimental, dead,
    or unknown.

18. Unknown means retain.

19. Shipped means retain until a published deprecation has completed.

20. Supported means retain until a replacement has passed compatibility tests.

21. Used means retain until all callers have moved.

22. Experimental means archive before removal.

23. Dead means remove only after the global gates pass.

24. A name that sounds obsolete is not evidence of dead code.

25. An ignored path is not evidence that a tracked predecessor is removable.

26. A missing path is not a cleanup target.

27. Never create a delete-only PR for a missing path.

28. Do not delete CI checks merely to make a removal pass.

29. Do not delete tests merely because their implementation is absent.

30. Restore a required implementation or make a reviewed policy change.

31. Do not change a frozen contract document in a cleanup PR.

32. Do not alter a public command only because its implementation moves.

33. Keep a compatibility shim when hidden local users are plausible.

34. Gate a new or replacement implementation behind an explicit feature flag.

35. Feature flags need an owner, default, removal condition, and test.

36. A flag is not a substitute for a migration plan.

37. Public removals follow the repository deprecation policy.

38. Stable public surfaces are deprecated for at least two minor releases.

39. Experimental surfaces still need a clear experimental marker.

40. The main binary lean-ctx is a release-blocking invariant.

41. Each wave must leave lean-ctx buildable from rust/Cargo.toml.

42. Each wave must leave its test suite green.

43. Each wave must leave required CI green.

44. A failed gate stops the wave.

45. A failed gate does not get bypassed by weakening the gate.

46. Revert the smallest failing cleanup commit first.

47. Do not continue into a later wave with unresolved rollback debt.

48. Archive paths must contain a README with source path, commit, reason,
    status, owner, and restoration instructions.

49. Archive status is not a support guarantee.

50. Archive content remains searchable and reviewable in Git history.

---

## 2. Evidence collected before planning

### 2.1 Repository and tag evidence

The checkout is on main and was clean at inspection.

The ten most recent local tags shown by git tag | tail -10 were:

- v3.9.2

- v3.9.3

- v3.9.4

- v3.9.5

- v3.9.6

- v3.9.7

- v3.9.8

- v3.9.9

- vscode-v0.1.0

- vscode-v0.2.0

The local tag tail is not a complete release inventory.

It does demonstrate independently tagged engine and VS Code release lines.

Do not treat a directory as private merely because its tag prefix differs.

### 2.2 GitHub release evidence

GitHub marks v3.9.13 as the latest release at inspection.

That release contains fourteen assets.

The assets include source, macOS binaries, Linux binaries, Windows binaries,
and a JetBrains plugin archive.

The release assets include these main-binary target families:

- aarch64-apple-darwin

- x86_64-apple-darwin

- aarch64-unknown-linux-gnu

- aarch64-unknown-linux-musl

- x86_64-unknown-linux-gnu

- x86_64-unknown-linux-gnu-cuda

- x86_64-pc-windows-gnu

- x86_64-pc-windows-msvc

Release checksums are published with the assets.

The binary distribution path is therefore a public contract.

No cleanup may remove target-specific packaging, install metadata, or update
logic without a replacement release rehearsal.

### 2.3 Main Rust binary evidence

rust/Cargo.toml declares package name lean-ctx.

The package version at inspection is 3.9.19.

rust/Cargo.toml declares a library named lean_ctx.

rust/Cargo.toml declares the binary lean-ctx at src/main.rs.

The package contains binstall metadata resolving release asset URLs from v tags.

The main binary is published through GitHub release artifacts.

The release workflow also builds its target archives.

Main-binary build and smoke checks are mandatory in every cleanup wave.

### 2.4 npm publication evidence

npm currently publishes lean-ctx-bin at version 3.9.19.

npm currently publishes lean-ctx-sdk at version 0.3.0.

npm currently publishes pi-lean-ctx at version 3.9.19.

The local package directories map to those public names:

- packages/lean-ctx-bin maps to lean-ctx-bin.

- packages/node-lean-ctx maps to lean-ctx-sdk.

- packages/pi-lean-ctx maps to pi-lean-ctx.

The local ts-sdk package declares @lean-ctx/ocla-sdk at 0.1.0.

The npm registry returned 404 for @lean-ctx/ocla-sdk at inspection.

That 404 is not proof that ts-sdk is dead.

It is evidence that it is not a currently published npm compatibility surface.

pi-lean-ctx is explicitly public in npm and README installation guidance.

pi-lean-ctx is also exercised by the CI pi-extension job.

It is not an unused Wave 2 deletion candidate.

### 2.5 PyPI publication evidence

PyPI currently publishes lean-ctx-sdk at version 0.3.0.

The source directory is packages/python-lean-ctx.

PyPI currently publishes lean-ctx-client at version 0.1.0.

The source directory is clients/python.

PyPI currently publishes leanctx at version 0.3.1.

The source directory is py-sdk.

The local python-sdk package declares lean-ctx-ocla at 0.1.0.

PyPI returned 404 for lean-ctx-ocla at inspection.

The published leanctx project is a separate public Python compatibility risk.

It must be deprecated before its source is archived or removed.

The published lean-ctx-client project must be handled as a real compatibility
surface even if the convergence target prefers packages/python-lean-ctx.

### 2.6 crates.io publication evidence

crates.io currently lists lean-ctx version 3.9.19.

crates.io currently lists lean-ctx-ocla version 1.0.0.

crates.io currently lists lean-ctx-protocol version 0.1.0.

crates.io currently lists lean-ctx-client version 0.1.0.

The local lean-ctx-sdk Rust crate has publish = false.

The local ocla-grpc Rust package has publish = false.

Published Rust crates are not Wave 1 removal candidates.

They need a deprecation and compatibility decision first.

### 2.7 Ignore-file evidence

.gitignore ignores discord-bot/ as private and separately deployed.

.gitignore ignores n8n-workflows/ as private workflows.

Neither directory is currently tracked in this checkout.

There is no n8n path to delete in the public repository.

There is no discord-bot path to delete in the public repository.

The tracked discord-faq documentation is not a Discord bot.

It remains a documentation surface until an owner decides otherwise.

.gitignore also excludes private lab and model artifacts.

Those patterns are governance signals, not a license to alter public paths.

### 2.8 CI and release evidence

The primary CI workflow has a test job.

It has clippy, build-minimal, fmt, cookbook, pi-extension, rust-sdk,
embed-sdk, python-sdk, hermes-plugin, sdk-conformance, coverage, deny,
adversarial, bench, quality-gate, doc, and ci-green jobs.

CI runs Rust tests, including all-feature library, main-suite, and
performance-stress coverage.

CI runs cargo clippy and cargo fmt checks.

CI runs cookbook npm lint, typecheck, test, and build checks.

CI runs a distinct pi-extension typecheck and test path.

CI runs Rust SDK tests, clippy, formatting, and example build coverage.

CI runs Python tests.

CI runs SDK conformance against a live server and uploads the matrix artifact.

CI runs adversarial compression coverage and a release-mode benchmark build.

The separate Go conformance workflow runs go test -v -run TestConformance ./....

The release workflow builds target-specific lean-ctx archives.

The release workflow packages a JetBrains plugin.

The release workflow publishes the lean-ctx, lean-ctx-ocla, and
lean-ctx-protocol Rust crates when their versions are absent.

The release workflow publishes lean-ctx-bin and pi-lean-ctx when their
versions are absent.

The independent client and SDK publishing workflows remain public-surface
evidence even where a future convergence would replace them.

---

## 3. Mandatory gates for every cleanup PR

### 3.1 Before any removal or archive move

- Confirm the branch starts from current github/main.

- Confirm git status is clean before the first planned change.

- Record candidate paths and classification in the PR description.

- Search tracked references in source, tests, docs, scripts, workflows,
  manifests, package locks, Cargo workspace metadata, and release tooling.

- Search public documentation for installation and import examples.

- Search release workflow paths and upload artifact names.

- Search package manifests for package name, bin, files, exports, and
  postinstall lifecycle hooks.

- Search configuration defaults and feature flags for path references.

- Search test fixtures and golden files for referenced names.

- Search GitHub issues and support channels if an existing integration might
  have users outside the repository.

- Identify a maintainer accountable for the decision.

- State whether the candidate is shipped, supported, used, experimental,
  dead, or unknown.

- Treat no result from a textual search as insufficient for a public API.

- Confirm public registry state before changing a published package.

- Identify the previous release that introduced the surface.

- Identify the replacement, if any.

- Write deprecation wording before changing a shipped surface.

- Add a feature flag before changing an uncertain runtime integration.

- Define how the flag is observed in tests.

- Verify that the main binary has not been removed from the Rust manifest.

- Run the pre-removal build gate below.

### 3.2 Pre-removal build gate

Run from rust:

    cargo build --release --locked

    cargo test --lib

    cargo clippy --all-features -- -D warnings

    cargo fmt --check

Also run the stronger scope checks when dependencies are available:

    cargo test --all-features

    cargo test --test main

Smoke the release binary:

    ./target/release/lean-ctx --version

    ./target/release/lean-ctx --help

Do not stop the installed lean-ctx runtime before building or testing.

Use the project's normal build workflow, not a global uninstall/reinstall.

Record failures that predate the cleanup in the PR before changing anything.

Do not claim a removal is safe while its baseline is red.

### 3.3 Post-removal verification gate

Run the pre-removal build gate again after each logical removal.

Run targeted tests for every changed package.

Run the CI job corresponding to every changed public surface.

Run cookbook checks when a Node package or cookbook path changes.

Run pi-extension checks when packages/pi-lean-ctx changes.

Run Python tests when a Python package or import path changes.

Run Rust SDK checks when a Rust crate or OCLA boundary changes.

Run SDK conformance when HTTP, SDK, or protocol paths change.

Run Go conformance when conformance fixtures or wire contracts change.

Run grammar-addon workflow coverage when its host or release asset path changes.

Run release dry-run or a release-artifact rehearsal when binary packaging,
  package metadata, installer URLs, or upload names change.

Run git diff --check.

Confirm no compression omission marker entered a tracked file.

Confirm documentation links resolve at their new locations.

Confirm archive README points to the canonical replacement.

Confirm the target binary remains executable and reports its version.

Confirm required checks on the PR are green before merge.

### 3.4 Rollback rule

Every cleanup commit must be independently revertible.

Do not squash unrelated batches before the PR is accepted.

If a regression appears before merge, revert the affected commit on the branch.

If a regression appears after merge, revert the merged PR first.

Use git revert for a merged cleanup PR.

Do not repair public history by force push.

Restore archive content with git mv before copying files manually.

Restore a removed path from the cleanup commit with git revert or git restore
from the known parent commit in a new corrective commit.

Re-run the same gates after restoration.

Document the false-positive signal so later waves do not repeat it.

---

## 4. Wave 1 — obvious dead candidates and duplicate Python SDKs

### 4.1 Objective

Eliminate only candidates that can be proven unused or make duplicate Python
publish paths explicit before any final deletion.

This wave prioritizes certainty over size.

The expected result is fewer ambiguous sources, not fewer public packages by
fiat.

### 4.2 Candidate inventory

Candidate: py-sdk/.

Local package name: leanctx.

Registry status: published on PyPI at 0.3.1.

Initial classification: shipped.

Default action: retain while a deprecation decision is made.

Permitted first change: archive-copy or source move only after a shim,
deprecation notice, migration guide, and release-window decision exist.

Candidate: python-sdk/.

Local package name: lean-ctx-ocla.

Registry status: not found on PyPI at inspection.

Initial classification: unknown experimental.

Default action: use audit, then move to an archive location.

Final deletion requires zero callers, zero documentation references, and an
OCLA owner sign-off.

Candidate: clients/python/.

Local package name: lean-ctx-client.

Registry status: published on PyPI at 0.1.0.

Initial classification: shipped and supported.

Default action: do not delete.

Convergence may later deprecate it in favor of one canonical SDK only after
the migration conditions are met.

Candidate: packages/python-lean-ctx/.

Local package name: lean-ctx-sdk.

Registry status: published on PyPI at 0.3.0.

Initial classification: shipped and convergence target.

Default action: retain and strengthen.

Candidate: empty or no-op public commercial stubs.

Known example class: solution_commercial boundary functions that only error
or no-op.

Initial classification: unknown public surface.

Default action: inventory first.

Do not delete a public boundary until it has a structured replacement,
a clear unavailable error, or a removed command with deprecation.

### 4.3 Wave 1 pre-removal checklist

- Create cleanup/w1-python-and-stubs.

- Inventory every Python manifest, console script, import namespace, and
  package export.

- Record every PyPI project and its latest version.

- Inspect package build and publish workflows.

- Inspect README, cookbook, docs, and examples for pip commands.

- Inspect package tests and conformance fixtures.

- Inspect lockfiles, CI working directories, and build artifacts.

- Search imports for leanctx, lean_ctx, and client namespaces.

- Search third-party wrapper and adapter references.

- For each public name, write a replacement and deprecation statement.

- Add a warning or compatibility alias before moving a public import.

- Keep public import tests during the announced transition.

- For an empty stub, identify command, config, MCP, HTTP, and SDK exposure.

- Add a feature flag if a replacement behavior is not proven equivalent.

- Run the pre-removal build gate.

### 4.4 Wave 1 execution sequence

1. Add a tracked cleanup inventory document to the branch.

2. Mark each candidate retain, archive, or delete-after-window.

3. Move only unshipped, zero-reference Python sources with git mv to
   _archive/python-experiments/<name>/.

4. Add an archive README at each moved root.

5. Update internal developer references to the archive location.

6. Do not change public installation instructions in the same PR unless they
   were already incorrect.

7. For shipped duplicate packages, add deprecation metadata and migration
   guidance in a dedicated compatibility PR.

8. Keep the old package buildable while the compatibility window remains open.

9. For a verified empty, unexported stub, remove it with git rm in a separate
   small PR.

10. Remove only its test fixtures that assert the removed behavior.

11. Retain tests that validate a replacement boundary.

12. Run all post-removal verification.

### 4.5 Wave 1 acceptance criteria

- packages/python-lean-ctx remains buildable and tested.

- clients/python remains buildable and tested.

- Published leanctx remains supported or explicitly deprecated.

- No public Python import disappears without a documented replacement.

- No pypi publishing workflow points at an archived path.

- The lean-ctx binary passes release build and smoke checks.

- CI stays green.

### 4.6 Wave 1 rollback

If a hidden Python user reports an import failure, restore the archived source
with git mv and ship a shim first.

If a package build fails, restore the manifest and package source in one
revert commit.

If a stub removal breaks command parsing or documentation, revert the
delete-only commit and replace it with a deprecation path.

Never republish a changed version to overwrite a released package.

Publish a corrected version only after the restored source is verified.

---

## 5. Wave 2 — unused experiments and private-integration boundaries

### 5.1 Objective

Separate genuine repository experiments from private or already shipped
integrations.

This wave must reduce confusion without deleting a public integration.

### 5.2 Hard exclusions from removal

discord-bot/ is ignored and absent from the tracked public tree.

n8n-workflows/ is ignored and absent from the tracked public tree.

There is nothing to remove for either path.

The correct action is no deletion PR.

discord-faq/ is tracked documentation, not the ignored Discord bot.

It is retained unless a documentation owner separately approves consolidation.

packages/pi-lean-ctx is public on npm.

README documents Pi installation and removal commands.

CI has a pi-extension job.

Pi is therefore retained.

No plan may label pi-lean-ctx unused without new contrary publication evidence
and an explicit deprecation decision.

rust/experiments/grammar-dlopen-spike is not automatically dead.

The grammar-addons workflow builds grammar-dlopen-host from that area.

It is retained until the workflow is retargeted and a replacement rehearsal
passes.

### 5.3 Candidate classes for archive

An experiment may be archived only when all conditions hold:

- It is tracked.

- It has no release artifact dependency.

- It has no CI job dependency.

- It has no package publication dependency.

- It has no documented installation path.

- It has no code, test, or fixture caller.

- Its owner accepts the archive status.

- Its README names the canonical alternative or says no replacement exists.

Examples can include abandoned local spikes, private-integration scaffolds
that were accidentally tracked, and obsolete sample provider code.

Do not infer that any named example meets these conditions.

### 5.4 Wave 2 pre-removal checklist

- Create cleanup/w2-experiment-boundaries.

- Compare git ls-files against .gitignore entries.

- Prove the candidate is tracked before proposing a cleanup.

- Search release.yml, publish workflows, and CI jobs for its path.

- Search README, cookbook, docs, and package manifests for its name.

- Search Cargo workspace membership and npm workspaces.

- Search binary source for embedded asset and include path references.

- Search external registry names for a corresponding published package.

- Confirm its feature flag state, if any.

- Confirm existing issue or customer references are absent or migrated.

- Run the pre-removal build gate.

### 5.5 Wave 2 execution sequence

1. Create a candidates table with one row per tracked experiment.

2. Mark ignored-and-absent paths as no-op rather than pretending to remove
   them.

3. Exclude pi-lean-ctx and grammar-dlopen-host from broad experimentation
   cleanup.

4. Use git mv for verified unshipped experiments.

5. Place them under _archive/experiments/<area>/.

6. Add archive README metadata and restoration instructions.

7. Retarget only internal documentation that claimed the archived item was a
   current product path.

8. Keep an explicit experimental feature flag for any risky code path that
   must remain callable during the review period.

9. Wait for at least one green full CI run after the archive move.

10. Make a later delete-only PR only after the stated retention period and
    fresh zero-reference audit.

### 5.6 Wave 2 post-removal verification

- Confirm no release artifact build references the moved path.

- Confirm grammar-addons still produces its expected host artifact.

- Confirm Pi extension lint, typecheck, and tests still pass.

- Confirm npm package install behavior is unchanged for lean-ctx-bin and
  pi-lean-ctx.

- Confirm the main binary builds and smokes.

- Confirm no documentation calls a private ignored path a public feature.

- Confirm archive entries are not accidentally packaged into published crates.

### 5.7 Wave 2 rollback

Restore the moved directory with git mv if CI, a release rehearsal, or a
maintainer finds an untracked dependency.

If an archive exclusion list was wrong, revert that batch and split it into
smaller evidence-backed PRs.

If a feature flag exposes regression, default it back to the known working
path and revert the archive move.

---

## 6. Wave 3 — benchmark consolidation

### 6.1 Objective

Consolidate the three benchmark roots into one discoverable, documented
benchmark hierarchy without losing methodology, fixtures, historical results,
or CI coverage.

The observed roots are:

- bench/

- benchmarks/

- benchmark/

Rust microbenchmarks also exist at rust/benches/.

The initial scope is the three top-level roots.

rust/benches/ remains a Cargo benchmark surface and is out of the first move.

### 6.2 Current evidence

The README directly links to bench/agent-task/r2.

benchmark/ contains a shell runner, LOCoMo material, and result JSON files.

bench/ contains agent-task, compress, lifecycle, and research areas.

benchmarks/ contains capability-comparison and efficiency areas.

CI has a bench job and benchmark-study workflow.

Benchmark data may be evidence rather than disposable generated output.

No root may be deleted because its name is inconsistent.

### 6.3 Canonical structure decision

Use a dedicated PR to approve the canonical benchmark root.

The provisional target is bench/ because it has the README entry point and
multiple active categories.

The decision must be recorded before moving data.

The target structure should separate:

- bench/cases/ for reproducible input workloads.

- bench/harness/ for runners and shared utilities.

- bench/results/ for committed representative results.

- bench/archive/ for superseded datasets and methodologies.

- bench/docs/ for methodology and interpretation.

- rust/benches/ for Cargo criterion or Rust-native microbenchmarks.

Do not create a new fourth top-level benchmark root.

### 6.4 Wave 3 pre-removal checklist

- Create cleanup/w3-benchmark-consolidation.

- Inventory every benchmark script, manifest, fixture, dataset, and result.

- Classify each result as reproducible evidence, generated cache, or obsolete.

- Identify which workflows read or upload each path.

- Identify all README and documentation links.

- Record the command, toolchain, inputs, and expected output for every
  reproducible benchmark.

- Pin or document external datasets where legally and practically possible.

- Preserve raw measurements with their method and commit identity.

- Verify that result files do not contain secrets or private data before moves.

- Add a benchmark index before changing paths.

- Run the pre-removal build gate.

### 6.5 Wave 3 execution sequence

1. Land the benchmark index and canonical layout decision first.

2. Move one source root per PR with git mv.

3. Move benchmarks/ content into the approved bench categories.

4. Update runner paths, documentation links, and CI in the same focused PR.

5. Run the affected benchmark harness before and after the move.

6. Compare structural result fields, not only a headline percentage.

7. Preserve immutable raw result snapshots under a date-free, descriptive path.

8. Move benchmark/ LOCoMo material only after its runner path is exercised.

9. Archive intentionally non-reproducible historical results rather than
   deleting them.

10. Delete an empty old root only with git rm after references are zero.

11. Keep rust/benches separate unless a later Rust-specific plan changes it.

### 6.6 Wave 3 post-removal verification

- README benchmark links resolve.

- CI bench job remains green.

- benchmark-study workflow remains green.

- Rust release binary still builds and smokes.

- Benchmark commands operate from a clean checkout.

- Documentation names one canonical entry point.

- Historical results retain method, input, and source-commit context.

- No result comparison silently changes units, tokenizers, model names, or
  quality constraints.

### 6.7 Wave 3 rollback

Revert the root-specific move PR if a runner cannot reproduce its prior result.

Restore old path compatibility with a small forwarding script only when needed
for an announced transition.

Do not use symlinks as a permanent cross-platform compatibility mechanism.

Remove a forwarding script only after all documented callers have moved.

---

## 7. Wave 4 — architecture alignment and OCLA normalization

### 7.1 Objective

Align OCLA ownership with the composable vision without destroying a released
protocol, SDK, or future capability foundation.

Wave 4 is primarily an audit and normalization sequence.

It is not a license for a broad mechanical refactor.

### 7.2 Vision constraints

The composable vision requires LeanCTX Native to implement the canonical
Capability contract first.

It then calls for one trivial external capability and one local-process or
provider mechanism.

It explicitly rejects a public marketplace, many competitor integrations,
generic plugin store, generic agent orchestration, managed hosting, a universal
model marketplace, and a generic enterprise workflow platform.

The founder directive asks one question first:

Can an existing native capability use a stable open Capability contract,
be selected by a Performance Profile, measured by Benchmark, and recorded
in a Receipt?

The architecture must remain ahead of the product promise.

### 7.3 Required OCLA audit before refactor

Create docs/internal/architecture/OCLA_CURRENT_STATE.md before moving OCLA
code in this wave.

The audit must list:

- all current traits.

- all implementors.

- all registries.

- all wire interfaces.

- all call sites.

- all overlaps.

- all unused interfaces.

- all feature flags.

- all public exports.

- all package manifests.

- all release artifact consequences.

Audit these known locations at minimum:

- rust/src/core/ocla/.

- rust/crates/lean-ctx-ocla/.

- rust/crates/lean-ctx-protocol/.

- rust/crates/lean-ctx-sdk/.

- packages/ocla-grpc/.

- ts-sdk/.

- python-sdk/.

The audit must distinguish current runtime dependency from aspirational SDK.

The audit must distinguish published crate from unpublished package.

No major OCLA refactor begins before the audit is reviewed.

### 7.4 Wave 4 pre-removal checklist

- Create cleanup/w4-ocla-normalization.

- Complete and review OCLA_CURRENT_STATE.md.

- Make one native capability the reference implementation.

- Define a minimal Capability Manifest v0.

- Include ID, version, type, execution mode, input/output, lossiness,
  recoverability, permissions, and telemetry.

- Link Capability identity and version to Execution Receipt.

- Link Capability identity and version to Performance Profile.

- Make these links observable in benchmark results.

- Identify every published Rust crate and SDK compatibility boundary.

- Add compatibility adapters for old trait or wire names where users may exist.

- Put replacement dispatch behind a feature flag where equivalence is uncertain.

- Test both flag values.

- Run the pre-removal build gate.

### 7.5 Wave 4 execution sequence

1. Land the audit document only.

2. Land Capability Manifest v0 only.

3. Land one native reference capability only.

4. Add Profile and Receipt identity fields with compatibility defaults.

5. Run the existing benchmark through the capability path.

6. Add one sample external local-process capability only after the native
   path is stable.

7. Move duplicate internal OCLA implementation code only after callers pass
   through the reference contract.

8. Keep released lean-ctx-ocla and lean-ctx-protocol compatibility surfaces
   intact unless a versioned deprecation has completed.

9. Archive an unpublished OCLA SDK only when the audit proves no runtime,
   test, documentation, or future reference implementation needs it.

10. Use git rm only for a fully replaced, zero-reference internal component.

11. Keep the PRs narrowly ordered and independently revertible.

### 7.6 Wave 4 post-removal verification

- Main Rust package builds in release mode.

- Main binary answers --version and --help.

- OCLA crate tests pass.

- Protocol and SDK tests pass.

- SDK conformance matrix passes.

- Existing benchmark executes through the Capability path.

- Profile identifies the Capability version.

- Receipt identifies the Capability version.

- Feature-on and feature-off paths both pass their defined tests.

- Published crate package checks pass before a release.

- No documentation advertises an ecosystem platform that the narrow product
  does not provide.

### 7.7 Wave 4 rollback

Default the feature flag to the old path if a replacement contract regresses.

Restore a moved implementation with git mv when needed.

Revert the isolated OCLA PR rather than overlaying a second registry.

Preserve the audit document and record what equivalence gap blocked progress.

Do not delete the old protocol solely because the new contract is more elegant.

---

## 8. PR batching and merge order

Merge only after each preceding wave is green and observed.

Recommended batch order:

1. cleanup/w1-python-inventory.

2. cleanup/w1-unshipped-python-archive.

3. cleanup/w1-verified-stub-removal.

4. cleanup/w2-experiment-inventory.

5. cleanup/w2-verified-experiment-archive.

6. cleanup/w3-benchmark-index.

7. cleanup/w3-benchmarks-root-move.

8. cleanup/w3-benchmark-root-move.

9. cleanup/w4-ocla-audit.

10. cleanup/w4-capability-manifest.

11. cleanup/w4-native-reference-capability.

12. cleanup/w4-ocla-internal-normalization.

One PR must have one dominant reason to exist.

The reviewer must be able to answer what moved, why it was safe, how it was
tested, and how it is reverted without reading future PRs.

Any public deprecation gets its own compatibility-focused PR.

Any release workflow change gets its own release-focused PR.

Any broad formatting change is deferred.

---

## 9. Required PR template

Use this body for every cleanup batch.

### Scope

State the single cleanup objective.

### Base

State the github/main commit used to create the branch.

### Candidate table

List old path, classification, evidence, action, replacement, and owner.

### Public-surface check

List GitHub releases, npm, PyPI, crates.io, CLI, MCP, HTTP, SDK, and
documentation effects.

### Feature-flag check

State flag name, default, test coverage, and removal condition.

### Commands run

List baseline and post-change commands with results.

### CI evidence

List the required workflow jobs and their status.

### Rollback

State the exact commit or PR to revert.

### Follow-up

State the next separate cleanup batch, if any.

---

## 10. Stop conditions

Stop the current batch and request a maintainer decision when:

- a candidate is published but has no approved deprecation replacement.

- a candidate has an external user signal.

- a release workflow references the path.

- a CI job references the path.

- a hidden or dynamic path reference cannot be ruled out.

- the pre-removal baseline is red.

- an archive move changes binary packaging.

- a public contract needs a major-version change.

- OCLA audit exposes conflicting ownership.

- benchmark results cannot be reproduced or interpreted safely.

- a cleanup requires deletion on main.

The correct result of an uncertain batch is retain and document.

---

## 11. Completion definition

The cleanup program is complete only when:

- every removed path has a reviewed evidence record.

- every archived path has restoration metadata.

- every shipped surface has an explicit support or deprecation status.

- no private ignored path is falsely represented as a removed public feature.

- one canonical benchmark entry point exists.

- no benchmark root is deleted without migrated method and result records.

- OCLA current state is documented before normalization.

- one native capability proves the Capability, Profile, Benchmark, and Receipt
  path.

- lean-ctx release builds, tests, and CI checks remain green after every wave.

- Git history contains moves and removals as reviewable commits.

The repository becomes smaller only where proof makes it safe.

### Executed vs remaining (2026-08-21)

Waves 1–3 and Prio 1–5 are executed. Restoration index: `_archive/README.md`.

Remaining from this document's original completion list, **moved out of WS-1**:
- OCLA current-state documentation exists (`reference/OCLA-CURRENT-STATE.md`)
- Native capability proving Capability → Profile → Benchmark → Receipt is **WS-4**, after GitLab #1254
