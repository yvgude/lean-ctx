# Complete Vision Delivery Plan

> **Classification:** Execution tracker  
> **Status:** Supporting execution blueprint; not architecture authority.  
> **Higher authority:** [`../vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md`](../vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md).  
> **Authority:** [`../vision/06-ENGINE-SDK-CLOUD-PLAN.md`](../vision/06-ENGINE-SDK-CLOUD-PLAN.md) defines Engine/SDK/Cloud boundaries; [`../vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md`](../vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md) defines post-v1 local context work.  
> **Scope:** All product and technical work; website delivery is intentionally excluded.

## Completion standard

No capability is considered complete because code exists. Every deliverable must
have a named owner, versioned contract, deterministic tests, security boundary,
operational limits, migration stance, documentation, and release evidence.

```text
Engine contract and factual evidence
      ↓
separate BSL 1.1 Production SDK — primary product
      ↓
real customer and embedded adoption
      ↓
SDK hardening and repeatability
      ↓
optional Cloud research later
```

## Non-negotiable product rules

- Engine remains Apache-2.0, local-first and independently useful.
- A host owns agent tasking, tools, retries, permissions, scheduling and UX.
- No raw source leaves a machine without an explicit data mode and policy.
- A measured value, an estimate and an accepted outcome are distinct facts.
- A new public surface needs a schema, fixtures, compatibility policy and
  deprecation path before release.
- A later phase may be designed in full now, but may not be promoted publicly
  before its listed exit evidence is satisfied.

## Workstream A — canonical documentation and surface inventory

**Purpose:** eliminate contradictory product contracts before more feature work.

| Deliverable | Acceptance criteria |
| --- | --- |
| One product/status matrix | Every Engine, Python, in-process, OCLA, SDK and Cloud surface has owner, repository, status, contract reference and migration stance. |
| Five-primitive SDK contract | `ContextSession`, `ContextSource`, `ContextView`, `ContextPlan`, `ContextReceipt` are the only stable-v1 candidates. |
| Deferred-feature ledger | Kits, Profiles, Project Context, Policy, Handoff, Delta, adaptive planning and adapter breadth are individually classified with their entry gate. |
| Claim lint | Public docs/package metadata cannot label Preview, internal or Research surfaces as Available. |

**Required corrections:** align `05-CONTEXT-SDK-POSITIONING`, Product
Architecture, SDK v1 specification, Roadmap and Master Execution Plan with the
five-primitive contract and the Preview status of Python. Historical documents
stay historical and must carry a visible superseded link.

**Exit:** no active document describes an unavailable route as a current
runtime API or promotes a deferred primitive into SDK v1.

## Workstream B — Engine completion and release contract

**Purpose:** make the local Engine a small, dependable foundation.

| Deliverable | Acceptance criteria |
| --- | --- |
| Engine Interface v1 | Versioned identity, operation, invocation, admission, observation, failure and receipt records with golden fixtures and compatibility tests. |
| Native proof path | At least one jailed local capability proves admission, exact input/output integrity, source recovery, structured failure and receipt lineage. |
| Capability admission policy | Local policy inputs, limits and redaction are explicit; rejected work cannot enter an adapter. |
| Artifact durability | Atomic writes, permission checks, content addressing, corruption detection and retention/cleanup policy. |
| Legacy containment | Existing generic `Engine`, Agent Bus, OCLA and provider paths are marked internal until a named contract replaces them. |

**Exit:** released Engine compatibility matrix, reproducible fixture package and
offline verification of the native proof path.

## Workstream C — production SDK foundation

**Decided:** separate repository, primary-product priority, BSL 1.1, Apache-2.0
Engine, and optional/later Cloud.

**Parameter gate before production publication:** written approval of:

1. production repository owner and access model;
2. package namespace and registry owner;
3. BSL Change Date, Change License, Additional Use Grant, permitted-use/OEM/
   pricing terms and notices;
4. contributor agreement, DCO/CLA and security-reporting process.

This is an authority decision, not an engineering inference. Record it in the
[Production SDK Decision Record](SDK-PRODUCTION-DECISION-RECORD.md). These
parameters do not reopen BSL 1.1 or SDK priority. Once gated, the implementation
sequence is fixed:

1. Create the separate SDK repository, release pipeline, provenance policy,
   vulnerability process and Engine compatibility matrix.
2. Implement only the five v1 primitives and the `LeanCTX` ergonomic root after
   they are stable.
3. Define canonical JSON/schema fixtures for every primitive; reject unknown
   fields and invalid lineage.
4. Implement deterministic `prepare()` over a supplied task, policy, Engine
   version and bounded sources. No host scheduling or retries enter the SDK.
5. Build one custom-host reference agent that uses Engine contracts directly,
   demonstrates Select → Shape → Reuse → Recover, budget enforcement and a
   factual receipt.
6. Add an Engine×SDK release matrix, protocol migration tests and a local-only
   degradation test.

**Exit:** a developer creates a useful custom agent without internal `ctx_*`
tools; its fixture is deterministic and independently verifies its receipt.

## Workstream D — evaluated workload and evidence system

**Purpose:** turn local behaviour into reproducible, bounded evidence.

| Deliverable | Acceptance criteria |
| --- | --- |
| Evaluated workload manifest | Versioned source fixture, baseline/treatment identity, evaluator, threshold, limits, redaction class and verifier command. |
| Local runner | Bounded execution, deterministic fixture loading, named Engine/SDK identity and no unrecorded network dependency. |
| Evidence bundle | Canonical inventory links inputs, outputs, evaluator result, receipt, environment and exact verifier version. |
| Independent verifier | Fresh process validates signatures/trust basis, digests, semantic constraints, replay boundaries and duplicate-key rejection. |
| Capability matrix | Each supported capability proves success, policy rejection, source failure, resource limit and disabled/unavailable behaviour. |

**Exit:** a clean checkout verifies a named workload offline and can state only
the precise measured result under its declared quality threshold.

## Workstream E — ContextWorkspace, reuse and recovery

**Purpose:** design and then deliver durable local context without turning
LeanCTX into an orchestrator. The sequence from the authoritative Workspace plan
is strict:

1. **W0 — five-primitive proof:** finish a bounded local
   `ContextSession`/`ContextSource`/`ContextView`/`ContextPlan`/`ContextReceipt`
   reference path before adding durable workspace state.
2. **W1 — ContextWorkspace contract:** define a local-first workspace identity,
   membership, scope, lineage, freshness, conflict and migration contract.
3. **W2 — checkpoints and packages:** add recoverable checkpoints and `.ctxpkg`
   transfer only with integrity, retention, redaction and recovery semantics.
4. **W3 — parallel local work:** add explicit delta, merge and bounded handoff
   artifacts; never synchronize opaque transcripts or schedule agents.
5. **W4 — optional Cloud:** evaluate cloud synchronization only after local
   workspace invariants and degradation behavior are proven.

Every record must state scope, source lineage, freshness semantics, retention,
redaction class and invalidation/recovery path. Adaptive planning is permitted
only after deterministic strategies have comparable evidence.

**Exit:** a new local session continues a bounded task from verified source
references while the host retains complete scheduling control.

## Workstream F — maintained integration paths

**Purpose:** offer depth, not an adapter catalogue.

1. Keep coding-agent Attach as the supported OSS wedge.
2. Keep the current Python/OpenAI Agents wrapper explicitly Preview until it
   consumes a stable Engine/SDK contract and has runtime-parity tests.
3. Promote at most one or two integrations after the reference workload proves
   correct cancellation, errors, ordering, backpressure, fail-open/fail-closed
   behaviour and receipt observability limits.
4. Deprecate or freeze adapters that cannot meet the same contract.

**Exit:** every promoted adapter has an owner, compatibility matrix, fixture,
observability statement and removal/migration policy.

## Workstream G — Cloud Receipt Board and control-plane readiness

**Purpose:** preserve a bounded Research design only. Do not schedule or build
Cloud until real SDK adoption, repeatability, and an explicit re-entry decision.

### G1. Complete design package

- API/schema for signed or integrity-aware receipt/evaluation ingestion;
- tenant, project and actor identity model;
- metadata-only default data mode and explicit opt-in for derived context;
- retention, deletion, export, audit, incident response and key rotation;
- threat model covering cross-tenant access, forged receipts, replay, raw-data
  exfiltration, aggregation disclosure and compromised local agents;
- local degradation and outage behaviour; Cloud can never block Engine/SDK;
- billing/quotas only after measurement methodology and tenancy isolation;
- privacy review, support owner, SLOs, backups, disaster recovery and abuse
  controls.

The complete G1 baseline is [Cloud Receipt Board — Design v1](CLOUD-RECEIPT-BOARD-DESIGN-V1.md). Its required approvals are a gate, not a claim that a Cloud service exists.

### G2. Implementation sequence

1. Authenticated metadata-only ingestion and immutable receipt inventory.
2. Tenant/project isolation with authorization tests and audit trail.
3. Receipt detail view showing measured, estimated and accepted fields apart.
4. Retention/deletion/export jobs with testable policy enforcement.
5. Derived-context data mode behind explicit project policy and redaction gate.
6. Only then evaluate synchronized Project Context, policy distribution and
   fleet controls as separate contracts.

**Exit:** a team can inspect declared context behaviour across runs without raw
source upload and without Cloud being required locally.

## Workstream H — release, security and operational excellence

- SemVer/version support matrix across Engine, SDK and Cloud releases.
- Contract-fixture compatibility suite in CI for every released version.
- Security review: PathJail, shell allowlist, bounded I/O, secrets scanning,
  symlink/TOCTOU checks, dependency advisories and signed provenance.
- Deterministic output regression suite; no timestamps, counters or randomness
  in content-addressed contract artifacts.
- Migration guide and deprecation window for every public breaking change.
- Release evidence bundle and reproducible verification command for every
  promotion.

## Dependency order and gates

```text
A documentation convergence
        ↓
B Engine release contract ──→ D evaluated evidence
        ↓                         ↓
C remaining parameters → C SDK foundation → real adoption → SDK hardening
                                                     ↓
                              optional E/F Research → G Cloud re-entry later
```

| Gate | Required decision/evidence | Authority |
| --- | --- | --- |
| SDK publication | repository access, namespace, exact BSL parameters, OEM/pricing, contributor/security/release policy | product/legal/release owner |
| SDK Preview promotion | deterministic reference demo, fixtures, compatibility matrix | engineering/release owner |
| Project-context promotion | scope/freshness/privacy/conflict/support contract | product/security owner |
| Cloud re-entry | repeat SDK adoption plus approved G1 tenancy/privacy/security ownership | product/security/operations owner |
| Cloud promotion | production evidence, SLOs, audit and local-degradation proof | release owner |

## Immediate execution queue

1. Finish Workstream A documentation convergence and add automated stale-claim
   checks.
2. Package Workstream B's native proof as a released compatibility fixture and
   close any remaining offline-verifier replay gaps in Workstream D.
3. Complete the named SDK parameters, then create the separate BSL 1.1 SDK
   repository and begin Workstream C without expanding the Engine repository.
4. Win and retain a real build-vs-buy customer/embedded path; keep G1 Cloud
   design frozen until that evidence earns re-entry.

This plan has no unspecified future feature bucket: every later capability is
either a gated deliverable above or explicitly outside LeanCTX's product
boundary.
