# Historical LeanCTX convergence plan

> **Status:** Historical architecture and migration proposal, not the active
> delivery tracker or an availability record. [Internal README](../README.md),
> [Engine, SDK & Cloud Plan](../vision/06-ENGINE-SDK-CLOUD-PLAN.md), and
> [Context Workspace & `.ctxpkg` Plan](../vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md)
> prevail where this record differs.
>
> **Date:** 2026-08-20. References below to shipped Python packages, websites,
> pilots, milestones, or an active execution order are historical planning
> context and require independent current evidence.

**Author:** Agent C1 — CONVERGENCE-MASTER-PLAN  
**Product direction at capture:** **LeanCTX — The Context SDK for AI Agents**

---


## 1. Executive decision

LeanCTX converges around one product contract, not around a single Git history.

The product is a local-first, provider-neutral Context SDK.

It sits inside an existing agent loop.

It does not become an agent framework, model router, managed execution service, or generic cloud control plane.

The durable public primitives are deliberately small:

```text
LeanCTX()
session()
wrap()
load_kit()
receipt()
```

Everything already built must either become an implementation of one of those primitives, a supporting contract, a supported integration, or be retired.

The convergence rule is:

> One owner per responsibility, one canonical implementation per public API, one release path per artifact, and one receipt schema across Attach, Wrap, and Embed.

This does **not** require merging all repositories into one Git repository.

It does require ending parallel product definitions.

The public source of truth is GitHub `yvgude/lean-ctx` on `main`.

The single public Python distribution root is `packages/python-lean-ctx`.

The single permanent Python import namespace is `lean_ctx`.

The Rust workspace stays rooted at `rust/Cargo.toml`.

The Rust engine remains the reference runtime underneath CLI, MCP, Proxy, and every SDK binding.

Thinkery-owned private systems consume released public contracts.

They never become runtime dependencies of a local OSS installation.

---

## 2. Why this is the right convergence

V-ZUG validates the category.

An advanced enterprise has already built context routing, reduction, caching, evals, MCP optimization, and outcome controls internally.

That proves context performance is infrastructure worth maintaining.

It does not mean LeanCTX should clone one customer's internal harness.

LeanCTX wins when it standardizes the reusable layer those teams should not repeatedly rebuild.

The differentiated product is therefore not "a compressor."

It is a portable context-performance system with versioned profiles, reusable Kits, explicit integration depths, and inspectable evidence.

The value proposition for a mature team is:

```text
Bespoke per-agent optimization
        ↓
Shared Context SDK
        ↓
Portable profiles + reusable kits + comparable evidence
        ↓
Less platform maintenance and faster trustworthy tuning
```

The V-ZUG "Fabian Test" is the standard for every advanced feature.

If an advanced team can say "we already built this," the LeanCTX version must be easier to integrate, portable across providers/frameworks, versioned, reproducible, independently benchmarked, evidence-linked, or easier to maintain.

If it is none of those things, it does not belong in the product.

---

## 3. Non-negotiable product boundaries

LeanCTX owns context selection, transformation, reuse, recovery, measurement, tuning constraints, Kit verification, and evidence assembly.

LeanCTX does not own the customer agent's task logic.

LeanCTX does not choose models for the customer by default.

LeanCTX does not execute customer tools or silently take over application retries.

LeanCTX does not claim savings without a comparable baseline, a quality gate, disclosed cost basis, and a verifiable evidence bundle.

LeanCTX remains useful offline and without a Thinkery account.

Cloud failure must not break local CLI, MCP, Proxy, SDK, Kit, profile, or receipt use.

Every public integration depth uses the same session identity, profile identity, Kit identity, event order, and receipt semantics.

```text
Attach  = coding agent / MCP / sidecar path
Wrap    = named SDK adapter around a supported client or framework
Embed   = native application lifecycle integration
```

The initial commercial wedge is Python plus the OpenAI Agents SDK wrapper.

Additional wrappers ship only with paid demand and an explicit version/capability matrix.

---

## 4. Current state: repository and branch inventory

### 4.1 Main public repository: `lean-ctx` on GitHub

Canonical remote:

```text
github = git@github.com:yvgude/lean-ctx.git
```

Canonical public branch:

```text
github/main
```

Observed checkout branch:

```text
main
```

Observed local checkout commit at inspection:

```text
3baabe0d31
```

This repository stays.

It is the OSS source of truth.

It owns the public product definition, public contracts, Rust runtime, CLI, MCP server, local proxy, SDKs, public examples, Kits, conformance fixtures, verifiers, documentation, and public release automation.

It must be reorganized by ownership, not replaced.

What stays in the main repository:

- `rust/` as the Rust engine workspace.
- `rust/src/main.rs` as the `lean-ctx` CLI binary entry point.
- `rust/src/mcp_stdio.rs` and `rust/src/tools/registered/` as the MCP server surface.
- `rust/src/hooks/` and hook handlers as supported coding-agent Attach integrations.
- `rust/src/proxy/` and `rust/src/wrap/` as the Wrap/sidecar substrate.
- `rust/src/core/` as internal engine implementation, not a customer-facing API.
- `rust/crates/lean-ctx-protocol/` as the public schema/type authority.
- `rust/crates/lean-ctx-sdk/` as the public Rust Embed facade.
- `rust/crates/lean-ctx-ocla/` as the protocol/lifecycle compatibility boundary.
- `packages/python-lean-ctx/` as the only public Python distribution root.
- `packages/node-lean-ctx/` as the JavaScript/TypeScript SDK/package surface where it maps to the same contracts.
- `cookbook/sdk/` as the TypeScript HTTP/conformance sibling until it is deliberately moved to `clients/typescript/`.
- `clients/rust/lean-ctx-client/` as the Rust HTTP client if it remains separately publishable.
- `kits/` as source-controlled first-party Kit definitions and fixtures.
- `packages/leanctx-verify/` as the independent offline evidence verifier.
- `docs/contracts/`, `contracts/`, and cross-language fixtures as public contract material.

What gets reorganized inside the main repository:

- Four Python attempts become one package and one compatibility policy.
- Internal `Profile`, session, evidence, and Kit implementations acquire public V1 contracts instead of parallel internal representations.
- Existing benchmark, quality, evidence, and receipt paths become one Dyno local workflow.
- Existing hooks, proxy, MCP, CLI, and SDK paths emit the same `ContextSessionV1` and receipt records.
- Public publish workflows are reduced to one Python publisher.
- The public build policy moves its Python contract path from `clients/python/pyproject.toml` to `packages/python-lean-ctx/pyproject.toml` in the same reviewed migration.

What must not be done to the main repository:

- Do not merge divergent GitLab history wholesale.
- Do not import private Cloud, Stripe, Postgres, customer, or billing source.
- Do not leave a second Python publisher after cutover.
- Do not market scaffolded AutoTune, hosted execution, cloud billing, or a complete Dyno before the product path exists.

### 4.2 GitLab `origin`

Observed remote:

```text
origin = https://root@gitlab.pounce.ch/root/lean-ctx.git
```

Observed state:

- GitLab `main` and GitHub `main` have divergent history.
- GitLab advertises `deploy`.
- GitLab also advertises enterprise/intelligence-related branches.
- The current public checkout does not prove GitLab's production ownership, deployment target, database, secret model, or branch promotion model.

Going-forward purpose:

GitLab is **not** a public source-of-truth mirror.

GitLab is an access-controlled integration/deployment legacy until a named owner classifies it.

The required classification record must answer:

- Is it private Cloud source, Enterprise source, website deployment, a CI mirror, or a legacy repository?
- Which repository and branch owns a deployed system?
- Which pipeline promotes it?
- Which artifact digest is deployed?
- Who owns rollback?
- Where do database migrations run?
- Where are secrets managed?
- Which source branch is still allowed to receive commits?

Until that record exists, GitLab receives no product-convergence merges.

Selected changes move between public and private systems only as reviewed commits or versioned release artifacts.

Never fast-forward GitHub `main` from GitLab `deploy`.

Never treat the GitLab name `origin` as evidence that it owns public development.

Recommended immediate remote naming after inventory:

```bash
git remote rename origin gitlab-legacy
git remote set-url --push gitlab-legacy DISABLED
```

Run those commands only after the designated owner confirms that disabling push cannot interrupt a live deployment pipeline.

### 4.3 `deploy` branch and deploy worktree

Observed local worktree:

```text
/Users/yvesgugger/Documents/Privat/Projects/lean-ctx-deploy  [deploy]
```

Target decision:

`deploy` is website-only.

It may contain static website source, generated website build output, redirects, documentation-site deployment configuration, and site-specific deployment metadata.

It must not contain runtime source of record.

It must not be used to ship the Rust CLI, MCP server, Python SDK, protocol changes, Cloud service code, or enterprise code.

Website application code belongs in the public main repository or a dedicated Thinkery website repository.

The deploy branch consumes an immutable website artifact created from a reviewed public source commit.

The promotion record must contain:

- public source commit SHA;
- website build artifact digest;
- deploy branch commit SHA;
- deployment target;
- release owner;
- rollback commit.

The branch must not become a second product-development branch.

### 4.4 `packages/python-lean-ctx`: the canonical Python SDK

Current location:

```text
packages/python-lean-ctx/
```

Current distribution name:

```text
lean-ctx-sdk
```

Current import namespace:

```python
lean_ctx
```

Current version at inspection:

```text
0.3.0
```

Current useful implementation files:

- `packages/python-lean-ctx/lean_ctx/client.py`
- `packages/python-lean-ctx/lean_ctx/discovery.py`
- `packages/python-lean-ctx/lean_ctx/proxy.py`
- `packages/python-lean-ctx/lean_ctx/errors.py`
- `packages/python-lean-ctx/lean_ctx/langchain.py`
- `packages/python-lean-ctx/lean_ctx/litellm.py`
- `packages/python-lean-ctx/lean_ctx/llamaindex.py`
- `packages/python-lean-ctx/tests/`

This becomes **the** Python SDK.

It owns the documented Python facade:

```python
from lean_ctx import LeanCTX

ctx = LeanCTX(project=".")
session = ctx.session("review pull request")
client = ctx.wrap(OpenAI(), adapter="openai")
receipt = ctx.receipt(session)
```

The distribution name remains `lean-ctx-sdk` for the first convergence release unless PyPI ownership and package-name research justify a deliberate rename.

The permanent import namespace is `lean_ctx`.

Python 3.10+ is the proposed supported floor for v1.0.

That floor must be adopted in an explicit compatibility decision and CI matrix before it is enforced in `pyproject.toml`.

### 4.5 `clients/python`: migrate capability, do not discard it

Current location:

```text
clients/python/
```

Current distribution name:

```text
lean-ctx-client
```

Current import namespace:

```python
leanctx
```

Its high-value implementation includes:

- `clients/python/leanctx/client.py` for dependency-free `/v1` HTTP transport.
- `clients/python/leanctx/conformance.py` for conformance scorecards.
- `clients/python/leanctx/tool_text.py` for tool-result conversion.
- `clients/python/leanctx/ocla.py` for OCLA-related client behavior.
- `clients/python/leanctx/ocla_verify.py` for verification/CLI behavior.
- `clients/python/leanctx/adapters/openai.py`.
- `clients/python/leanctx/adapters/langchain.py`.
- `clients/python/leanctx/adapters/llamaindex.py`.
- `clients/python/leanctx/adapters/crewai.py`.

This is not dead code.

It is the public `/v1` client and conformance source that the canonical package lacks.

It migrates into `packages/python-lean-ctx/lean_ctx/` with behavior-preserving tests.

`clients/python` becomes an archived/tombstoned migration source only after parity gates pass and the deprecation window closes.

### 4.6 `py-sdk`: merge types and synchronous OCLA behavior first

Current location:

```text
py-sdk/
```

Current distribution name:

```text
leanctx
```

Current import namespace:

```python
leanctx
```

Files to preserve before deletion:

- `py-sdk/leanctx/types.py`.
- `py-sdk/leanctx/client.py`.
- `py-sdk/leanctx/__init__.py`.
- `py-sdk/tests/`.

`scripts/validate-sdk-types.sh` currently reads `py-sdk/leanctx/types.py` directly.

Therefore this directory cannot be deleted first.

Its types move to `packages/python-lean-ctx/lean_ctx/ocla/types.py`.

Its synchronous health, capability, envelope, and ledger operations move to `packages/python-lean-ctx/lean_ctx/ocla/client.py`.

Only after the validator points at the canonical path and cross-language parity passes may `py-sdk/` be removed.

### 4.7 `python-sdk`: merge asynchronous OCLA behavior before retirement

Current location:

```text
python-sdk/
```

Current distribution name:

```text
lean-ctx-ocla
```

Current import namespace:

```python
lean_ctx
```

This distribution conflicts at installation time with `packages/python-lean-ctx` because both install `lean_ctx`.

That collision is a packaging correctness defect.

Files to preserve before deletion:

- `python-sdk/lean_ctx/client.py`.
- `python-sdk/lean_ctx/models.py`.
- `python-sdk/lean_ctx/streaming.py`.
- `python-sdk/tests/`.

Move its Pydantic/wire-validation decisions into canonical OCLA models only after reconciling them with `py-sdk` fields and protocol fixtures.

Move its streaming implementation to `packages/python-lean-ctx/lean_ctx/ocla/streaming.py`.

Expose an explicit `AsyncOclaClient` rather than mixing sync and async methods on one client.

Delete this tree only after clean-install tests prove the old `lean_ctx` collision is gone.

### 4.8 `lean-ctx-cloud` references: what they mean and where they belong

`lean-ctx-cloud` is not in this public checkout.

The public repository has no `cloud/` source directory.

The public build policy explicitly forbids `cloud/` and private Cloud dependencies.

The repository only contains intentional boundary references, for example:

- `rust/tests/outcome_pricing_e2e.rs` describes a private control-plane consumer.
- `rust/src/core/solution_commercial.rs` returns OSS enterprise-required errors.
- `rust/crates/lean-ctx-ocla/README.md` describes a public-to-enterprise contract boundary.

Meaning:

`lean-ctx-cloud` is the **private commercial Cloud owner**.

Its intended responsibilities are account lifecycle, organizations/workspaces, hosted private registry, Pro/Team services, dashboards, commercial entitlement state, and Stripe-backed billing lifecycle.

It does not own the local context engine.

It does not own public protocol schemas.

It does not become a dependency of public Rust or Python packages.

Where it is:

The exact repository URL, default branch, CI pipeline, deployment target, database migration system, and operational owner are unknown from this checkout.

They must be entered into an access-controlled repository inventory.

This plan does not invent those facts.

Required Cloud inventory output:

```text
private repository URL:
default branch:
deployment branch/tag policy:
artifact registry:
production environment:
database migration owner:
secret-management owner:
Stripe account/environment owner:
rollback operator:
public contract versions consumed:
```

Cloud consumes released `lean-ctx-protocol` schemas and public SDK/CLI artifacts.

It may publish an entitlement or registry service contract.

That contract must be versioned and consumable by the public runtime without importing Cloud source.

### 4.9 `kits/`: evolve from read-mode TOML to verified ContextKitV1

Current checked-in first-party Kit:

```text
kits/code-review/kit.toml
```

Its current capabilities include read rules, priority, shell guidance, quality criteria, and a system prompt.

The runtime currently applies only part of the declared contract: mainly first matching read-mode selection through `rust/src/kits/mod.rs` and `rust/src/core/auto_mode_resolver.rs`.

The shell list, quality criteria, system prompt, full staged plan, receipt linkage, and package identity are not yet canonical runtime behavior.

Target role:

`kits/` is the source tree for public, inspectable ContextKit definitions and fixtures.

Each Kit becomes a `ContextKitV1` with:

- immutable name, version, and content digest;
- manifest and optional signature;
- target runtime/protocol capability requirements;
- profile compatibility range;
- explicit rules, prompts, read plan, shell plan, quality plan, and policy requirements;
- deterministic install and rollback semantics;
- a locked resolved reference placed in the session and receipt.

Migration rule:

Do not claim the current TOML file is already a `.ctxpkg` runtime artifact.

Do not delete existing `rust/src/core/context_package/` substrate.

Instead define a single mapping:

```text
kit.toml source manifest
        ↓ deterministic pack command
ContextKitV1 manifest + payload
        ↓ optional signing
.ctxpkg distribution artifact
        ↓ verified install/cache
immutable KnowledgeKit handle
```

The initial v1 implementation may preserve `kit.toml` as the editable source format.

`.ctxpkg` becomes the distributable sealed artifact after the mapping, signing, and verification path pass end-to-end tests.

### 4.10 Rust crates: retain clear roles

#### `rust/`

`rust/Cargo.toml` remains the only Rust workspace root.

The root crate remains package `lean-ctx` and binary `lean-ctx`.

It owns the local reference runtime, CLI, MCP server, Proxy, Attach hooks, Wrap infrastructure, engine implementations, local state, and default release binary.

#### `rust/crates/lean-ctx-sdk`

Role: the public Rust **Embed** SDK facade.

Current status: an opt-in workspace member and thin facade around the engine.

Target: expose the same V1 concepts as Python:

- `LeanCtx` facade;
- `ContextSessionV1` lifecycle;
- `ContextKitV1` loader/handle;
- `TuningProfileV1` construction/application;
- `Receipt` retrieval;
- typed named integration adapters where applicable.

It must not expose arbitrary engine internals as its stable contract.

Its `publish = false` setting is correct for the current state.

Change it only when semver surface, documentation, test matrix, and crate publication ownership are ready.

#### `rust/crates/lean-ctx-protocol`

Role: the canonical public **schema and type authority**.

It owns the additive-versioned contract definitions and fixtures for:

- `ContextSessionV1` identity/events;
- `ContextKitV1` manifest/reference;
- `TuningProfileV1` manifest/lifecycle reference;
- `ExecutionReceiptV1`;
- `SavingsReceiptV1`;
- `EvidenceBundleV1` manifest;
- OCLA envelope and compatibility types;
- capability and error-code identifiers shared across surfaces.

It must not depend on the engine, Cloud, Enterprise, Python, Node, or a private service.

It must have documented schema ownership, compatibility rules, fixtures, deprecation rules, and language parity tests.

#### `rust/crates/lean-ctx-ocla`

Role: provider-neutral lifecycle/OCLA traits and contract bridge.

It is the stable boundary that downstream Enterprise and Cloud implementations can consume without coupling OSS runtime code to private source.

It should depend on `lean-ctx-protocol`.

It should not contain product-specific Cloud entitlement logic or an enterprise implementation.

Clarify in its README whether it is internal-only or a supported external crate before publication; its current README says it is not intended for direct use.

---

## 5. Honest current product state

The plan begins from the audited state, not aspirational copy.

Real foundations:

- Local shell and tool compression.
- Structural code read modes.
- CLI and local MCP runtime.
- Hook installation for coding agents, including Codex, Cursor, and Claude paths.
- Local proxy listener/auth substrate.
- Local agent registry, messages, handoffs, claims, and leases.
- Receipt signing and independent evidence-bundle verification primitives.
- OCLA protocol fixtures and typed client substrate.
- A narrow real-provider usage experiment.
- A working TOML code-review Kit that influences read mode selection.

Scaffolded or partial foundations:

- Proxy rewriting through a fully authenticated upstream provider E2E path.
- Context planning as a public SDK object.
- Memory recovery as a proven end-to-end product path.
- Python SDK as a unified customer product.
- Kit packaging as a unified `.ctxpkg` delivery path.
- Canonical evidence workflow with quality-preserved comparison.
- Team push rails and cloud/enterprise seams.

Planned rather than currently shipped product objects:

- `ContextSessionV1` public lifecycle.
- `TuningProfileV1` lifecycle.
- Dyno local product runner.
- AutoTune.
- Hosted Playground.
- Managed relay and execution.
- Billing, accounts, organization operations, and team control plane.

Broken quality facts that block a v1 release claim:

- `cargo test --lib` is blocked by `rust/src/core/shell_allowlist/repro1482_test.rs` compile errors.
- `tests/delivery` collection refers to delivery scripts reported absent by the audit.
- `lean-ctx evidence run` reports unavailable work yet exits success.

Convergence does not hide those facts.

It schedules their repair before a v1.0 release gate.

---

## 6. Target state: one clean product architecture

### 6.1 Product shape

```text
Any agent / provider / framework
        │
        ├── Attach: CLI + MCP + hooks + sidecar
        ├── Wrap: named Python/TS/Rust adapters
        └── Embed: native SDK session lifecycle
        │
        ▼
LeanCTX Context SDK
        │
        ├── ContextSessionV1
        ├── ContextKitV1
        ├── TuningProfileV1
        ├── Evidence receipts + EvidenceBundleV1
        └── local-first Rust runtime
        │
        ▼
Existing model provider, tools, data, and customer agent
```

The same product objects cross every surface.

No integration gets a private alternate Profile, Kit, Session, or Receipt format.

### 6.2 One Rust workspace

Workspace root:

```text
rust/Cargo.toml
```

Workspace membership remains deliberately explicit:

```text
rust/                               # engine binary and internal runtime
rust/crates/lean-ctx-protocol/      # contract authority
rust/crates/lean-ctx-ocla/          # lifecycle/OCLA contract bridge
rust/crates/lean-ctx-sdk/           # public Rust embed facade
rust/crates/grammar-addons/*/       # optional parser extensions
```

Default workspace behavior continues to build/test the engine only unless an SDK or all-workspace release check is explicitly requested.

The engine internal module map becomes conceptually clear even if physical moves occur later:

```text
core/session* + core/context_kernel*       → session lifecycle implementation
core/profiles*                             → TuningProfile implementation
rust/src/kits + core/context_package*      → ContextKit source/pack/install implementation
core/compressor* + core/repomap* + search* → context planning/transformation/reuse engine
core/measurement* + billing*               → observation and cost accounting
core/evidence_* + canonical*               → receipt/bundle assembly and verification
core/benchmark* + eval_* + quality_*       → Dyno local runner substrate
```

Do not initiate a large rename-only Rust refactor before contract ownership and v1 integration tests exist.

The first goal is behavior convergence behind stable facade modules.

### 6.3 Feature gate policy for OSS and enterprise

Public engine features must be honest about availability.

The current empty `enterprise = []` feature flag and `solution_commercial.rs` stubs are not a product implementation.

Target feature policy:

```text
default             = supported local OSS runtime features
context-kernel      = local context-engine implementation
proxy               = local provider-sidecar/wrap support
integrations-*      = optional public adapter dependencies/capabilities
experimental        = explicitly unstable OSS experiments
enterprise          = compile-time compatibility surface only; no private code
```

The public `enterprise` flag must never fetch or link proprietary code.

It may enable public interfaces, capability discovery, or a clear `ENTITLEMENT_REQUIRED` response.

Private Enterprise code lives in a separate access-controlled repository and depends on released public crates/protocol artifacts.

Private Cloud depends on released public artifacts and Enterprise service contracts as needed.

Dependency direction is fixed:

```text
lean-ctx-protocol
        ↓
lean-ctx OSS runtime + public SDKs
        ↓
lean-ctx-enterprise (private)
        ↓
lean-ctx-cloud (private)
```

There is no arrow upward from OSS to private source.

The public build gate in `security/public-build-policy-v1.json` remains mandatory and is updated whenever public paths move.

### 6.4 One Python package on PyPI

Canonical root:

```text
packages/python-lean-ctx/
```

Canonical distribution for convergence release:

```text
lean-ctx-sdk
```

Canonical import:

```python
lean_ctx
```

Canonical source layout after migration:

```text
packages/python-lean-ctx/
├── pyproject.toml
├── README.md
├── lean_ctx/
│   ├── __init__.py
│   ├── facade.py                 # LeanCTX and public entry points
│   ├── session.py                # ContextSession binding/lifecycle
│   ├── errors.py                 # one stable public hierarchy
│   ├── local/
│   │   ├── client.py             # CLI wrapper
│   │   └── discovery.py          # local daemon access
│   ├── compress/
│   │   ├── proxy.py              # existing ProxyClient/helpers
│   │   └── types.py
│   ├── http/
│   │   ├── client.py             # migrated /v1 client
│   │   ├── transport.py
│   │   ├── events.py             # SSE
│   │   └── tool_text.py
│   ├── ocla/
│   │   ├── __init__.py
│   │   ├── types.py              # migrated py-sdk authoritative types
│   │   ├── client.py             # sync OCLA client
│   │   ├── async_client.py       # migrated async OCLA behavior
│   │   ├── models.py             # reconciled Pydantic models if justified
│   │   ├── streaming.py
│   │   └── verify.py
│   ├── integrations/
│   │   ├── openai.py             # first ctx.wrap adapter
│   │   ├── langchain.py
│   │   ├── litellm.py
│   │   ├── llamaindex.py
│   │   └── crewai.py
│   ├── conformance/
│   │   ├── scorecard.py
│   │   └── fixtures.py
│   └── _compat/
│       └── leanctx.py            # temporary legacy import re-exports
└── tests/
    ├── unit/
    ├── contract/
    ├── integration/
    ├── packaging/
    └── compatibility/
```

The exact physical split can vary, but the ownership boundaries cannot.

The top-level public facade cannot silently decide whether a call is local, remote HTTP, or OCLA.

Each constructor must name its transport/integration semantics.

The temporary `leanctx` compatibility import, if adoption data justifies it, is a re-export-only shim inside the canonical wheel.

It has no distinct source implementation, transport, dependency graph, or PyPI distribution.

It emits a `DeprecationWarning` with a removal release/date.

### 6.5 One website

Canonical public domain target:

```text
leanctx.dev
```

The current package metadata still references `leanctx.com`.

Choose one canonical marketing/docs hostname before v1 launch, set permanent redirects from alternate domains, and update package metadata consistently.

The website contains product narrative, documentation, API references, architecture guarantees, integrations, Dyno methodology, examples, changelog, security/disclosure information, and install paths.

The website does not become the product control plane.

The website is built from reviewed content/source and deployed through the website-only `deploy` promotion mechanism.

SDK and CLI content must be generated or validated from public contracts to avoid copy drift.

### 6.6 One CLI

Binary name:

```text
lean-ctx
```

The CLI remains the local operator control surface.

It owns install/onboard/doctor, configuration, profile and Kit operations, local Attach setup, local Wrap/proxy setup, local Dyno execution, receipt inspection/export, and offline verify invocation.

CLI command families must resolve to the same V1 objects as SDK code.

Target lifecycle:

```text
lean-ctx onboard
lean-ctx profile apply <profile>
lean-ctx kit install <kit>
lean-ctx dyno run <scenario>
lean-ctx receipt show <session-or-receipt>
lean-ctx verify <evidence-bundle>
```

Existing command aliases may remain during migration.

`lean-ctx evidence run` must either become the real Dyno-compatible comparison path or fail non-zero with a clear replacement command.

It may not signal success for unavailable work.

### 6.7 One MCP server

The Rust stdio MCP runtime remains the one server implementation.

It is surfaced through `rust/src/mcp_stdio.rs`, registered tools, and supported hooks.

Codex, Cursor, and Claude Code are supported Attach paths, not independent products.

All must emit or carry the same session identity and evidence facts where the integration allows.

MCP exposes context operations.

It does not become a separate generic agent framework.

MCP's core capabilities map to the Context SDK:

```text
read/search/compose       → context selection and transformation
knowledge/session         → local memory and ContextSession state
kit/profile               → reusable operating policy
measurement/evidence      → observation and receipts
agent coordination        → local collaboration support, not a cloud scheduler
```

### 6.8 OSS versus Thinkery private boundary

| Area | Owner | Location | Rule |
| --- | --- | --- | --- |
| Context engine, CLI, MCP, proxy, hooks | OSS LeanCTX | public GitHub | Must work locally without account/network. |
| Public SDKs and contract fixtures | OSS LeanCTX | public GitHub | One public source of truth and versioned compatibility. |
| Kits, local profiles, local Dyno, local evidence | OSS LeanCTX | public GitHub | Local-first, inspectable, verifiable. |
| Protocol schemas | OSS LeanCTX | `rust/crates/lean-ctx-protocol` plus fixtures | Additive compatibility and language parity required. |
| Organization policy and enterprise control | Thinkery Enterprise | private repo | Depends on released public contracts; no reverse import. |
| Account, workspace, hosted registry, dashboard, billing | Thinkery Cloud | private repo/service | Optional consumer of public artifacts; owns Stripe lifecycle. |
| Customer deployment/configuration | Thinkery private operations | access controlled | Never committed to OSS. |
| Brand, website, cases, commercial narrative | Thinkery | website/content repo or website source | Must not define runtime behavior. |

Open-core rule:

Solo developer local use remains free.

Organization-scale features may be commercial.

The boundary is enforced through external private implementations and public contracts, not through secret code hidden behind a fake OSS feature.

---

## 7. Canonical contracts that every repository must consume

Every contract has one owner, schema, producer, consumer, compatibility rule, fixtures, and deprecation rule.

| Contract | Canonical owner | Main producers | Main consumers |
| --- | --- | --- | --- |
| `ContextSessionV1` | `lean-ctx-protocol` | CLI, MCP, proxy, SDKs | receipts, Dyno, profiles, adapters |
| `TuningProfileV1` | `lean-ctx-protocol` + engine implementation | profile commands/SDK | planner, deployment, Dyno |
| `ContextKitV1` | `lean-ctx-protocol` + Kit packer | `kits/`, registry/cache | session, planner, receipt |
| `ExecutionReceiptV1` | `lean-ctx-protocol` | session/evidence ledger | Dyno, verifier, Cloud optional ingest |
| `SavingsReceiptV1` | `lean-ctx-protocol` | evidence comparison | Dyno, verifier, reports |
| `EvidenceBundleV1` | `lean-ctx-protocol` + `packages/leanctx-verify` | evidence assembler | customer, CI, optional Cloud |
| OCLA envelopes/capabilities | `lean-ctx-ocla` + protocol | runtime and clients | public/private integrations |
| `EntitlementV1` | public protocol schema only | private Cloud | optional OSS capability check |

Protocol changes are additive by default.

Changing a digest algorithm, canonical event order, error code semantics, redaction semantics, or existing field meaning is breaking.

No Python, TypeScript, Rust, or Cloud implementation hand-copies a contract without a fixture-parity test.

---

## 8. Ordered migration program

The plan is intentionally ordered.

It prevents a directory deletion from becoming accidental API or evidence loss.

Effort assumes one experienced engineer with review support.

Parallel work is possible only after Phase 0 contracts and owners are fixed.

### Phase 0 — freeze, repair, and inventory

**Effort:** 3–5 engineering days  
**Outcome:** safe starting point and releasable CI baseline

1. Appoint an accountable Python API owner.

2. Appoint an OCLA/protocol compatibility owner.

3. Appoint a PyPI release owner.

4. Appoint a GitLab/deploy/Cloud-inventory owner.

5. Freeze feature additions in `py-sdk/` and `python-sdk/`.

6. Permit only defect fixes and migration tests in `clients/python/`.

7. Continue correctness fixes in `packages/python-lean-ctx/`.

8. Create a short ADR naming `lean_ctx` as the permanent Python namespace.

9. Create a short ADR selecting Python 3.10+ or explicitly retaining 3.9.

10. Create a short ADR selecting sync primary APIs plus explicit async APIs.

11. Snapshot manifests, wheel/sdist metadata, exported symbols, and current PyPI ownership/release information.

12. Repair `rust/src/core/shell_allowlist/repro1482_test.rs` so `cargo test --lib` can compile.

13. Restore the delivery scripts referenced by `tests/delivery/`, or update the tests and policy only if the replacement delivery contract is deliberate and tested.

14. Change unavailable `lean-ctx evidence run` behavior to fail non-zero until its real replacement exists.

15. Record GitLab remote and deploy ownership facts in a private inventory.

16. Add a worktree-safe note: current unrelated modified Rust files are not part of this convergence migration.

Required exit gates:

```text
cargo test --lib                         # compiles and passes
python3 -m pytest -q tests/delivery       # collects and passes
all Python legacy suites run under their supported Python versions
GitLab/deploy/Cloud inventory has a named owner and status
```

### Step 1 — consolidate Python into `packages/python-lean-ctx`

**Effort:** 8–12 engineering days  
**Owner:** Python SDK owner  
**Goal:** one wheel, one primary namespace, one public facade, preserved behavior

#### Step 1A — add the canonical package boundaries

Create package directories without changing top-level public exports first:

```bash
cd /Users/yvesgugger/Documents/Privat/Projects/lean-ctx
mkdir -p packages/python-lean-ctx/lean_ctx/{local,compress,http,ocla,integrations,conformance,_compat}
mkdir -p packages/python-lean-ctx/tests/{unit,contract,integration,packaging,compatibility}
```

Move current canonical package behavior to ownership-based locations with compatibility re-exports:

```bash
git mv packages/python-lean-ctx/lean_ctx/client.py \
  packages/python-lean-ctx/lean_ctx/local/client.py
git mv packages/python-lean-ctx/lean_ctx/discovery.py \
  packages/python-lean-ctx/lean_ctx/local/discovery.py
git mv packages/python-lean-ctx/lean_ctx/proxy.py \
  packages/python-lean-ctx/lean_ctx/compress/proxy.py
git mv packages/python-lean-ctx/lean_ctx/langchain.py \
  packages/python-lean-ctx/lean_ctx/integrations/langchain.py
git mv packages/python-lean-ctx/lean_ctx/litellm.py \
  packages/python-lean-ctx/lean_ctx/integrations/litellm.py
git mv packages/python-lean-ctx/lean_ctx/llamaindex.py \
  packages/python-lean-ctx/lean_ctx/integrations/llamaindex.py
```

Keep `packages/python-lean-ctx/lean_ctx/client.py`, `proxy.py`, `langchain.py`, `litellm.py`, and `llamaindex.py` as one-release compatibility re-export modules if in-repo or PyPI users depend on those paths.

Create `facade.py` and `session.py` only after their API is specified against the Rust protocol/runtime behavior.

Do not use a Python facade to invent semantics not supported by the Rust engine.

#### Step 1B — migrate `clients/python` `/v1` functionality

Source-to-destination map:

| Source | Destination | Migration requirement |
| --- | --- | --- |
| `clients/python/leanctx/client.py` | `packages/python-lean-ctx/lean_ctx/http/client.py` | Preserve `/v1` behavior, auth, status/error mapping, and tests. |
| transport code embedded in client | `packages/python-lean-ctx/lean_ctx/http/transport.py` | Keep standard-library transport viable unless optional HTTPX is intentionally chosen. |
| `clients/python/leanctx/errors.py` | merge into `packages/python-lean-ctx/lean_ctx/errors.py` | One stable hierarchy plus aliases only when needed. |
| `clients/python/leanctx/tool_text.py` | `packages/python-lean-ctx/lean_ctx/http/tool_text.py` | Preserve text conversion exactly under regression tests. |
| `clients/python/leanctx/conformance.py` | `packages/python-lean-ctx/lean_ctx/conformance/scorecard.py` | Keep behavior and fixtures language-neutral where practical. |
| `clients/python/leanctx/ocla.py` | `packages/python-lean-ctx/lean_ctx/ocla/` | Reconcile with `py-sdk` before selecting types. |
| `clients/python/leanctx/ocla_verify.py` | `packages/python-lean-ctx/lean_ctx/ocla/verify.py` | Preserve only after protocol parity tests pass. |
| `clients/python/leanctx/adapters/*` | `packages/python-lean-ctx/lean_ctx/integrations/*` | Deduplicate by observed behavior, not filename. |

Illustrative migration commands, executed only after import-path tests exist:

```bash
git mv clients/python/leanctx/client.py \
  packages/python-lean-ctx/lean_ctx/http/client.py
git mv clients/python/leanctx/tool_text.py \
  packages/python-lean-ctx/lean_ctx/http/tool_text.py
git mv clients/python/leanctx/conformance.py \
  packages/python-lean-ctx/lean_ctx/conformance/scorecard.py
git mv clients/python/leanctx/ocla_verify.py \
  packages/python-lean-ctx/lean_ctx/ocla/verify.py
git mv clients/python/leanctx/adapters/openai.py \
  packages/python-lean-ctx/lean_ctx/integrations/openai.py
git mv clients/python/leanctx/adapters/crewai.py \
  packages/python-lean-ctx/lean_ctx/integrations/crewai.py
```

Do not blindly `git mv` `clients/python/leanctx/ocla.py` before deciding canonical model representation with `py-sdk` and `python-sdk`.

#### Step 1C — merge `py-sdk` types and synchronous OCLA client

Move `py-sdk/leanctx/types.py` first.

It is a current input to `scripts/validate-sdk-types.sh`.

Migration sequence:

```bash
git mv py-sdk/leanctx/types.py \
  packages/python-lean-ctx/lean_ctx/ocla/types.py
git mv py-sdk/leanctx/client.py \
  packages/python-lean-ctx/lean_ctx/ocla/client.py
```

Then update the validator in the same change:

```diff
- validate_sdk "python" "$ROOT/py-sdk/leanctx/types.py" extract_python_types
+ validate_sdk "python" "$ROOT/packages/python-lean-ctx/lean_ctx/ocla/types.py" extract_python_types
```

Before accepting that move, add fixtures for every public enum wire value, dataclass field, optional field, JSON serialization form, and deserialization behavior.

Run Go, TypeScript, Rust, and Python type parity after the retarget.

Retain a temporary `leanctx.types` compatibility re-export only if real adoption data requires it.

#### Step 1D — merge `python-sdk` async/OCLA behavior

Run its tests first using Python 3.10+.

Its failure under host Python 3.9 is not a behavior verdict because its declared floor is 3.10.

Reconcile `python-sdk/lean_ctx/models.py` with `lean_ctx/ocla/types.py`.

Choose a single canonical representation per wire contract.

Use Pydantic only where validation/serialization materially earns the dependency.

Move only the selected behavior:

```bash
git mv python-sdk/lean_ctx/streaming.py \
  packages/python-lean-ctx/lean_ctx/ocla/streaming.py
git mv python-sdk/lean_ctx/client.py \
  packages/python-lean-ctx/lean_ctx/ocla/async_client.py
```

Rename the migrated public async facade to `AsyncOclaClient`.

Do not overload the synchronous `OclaClient` with coroutine methods.

Preserve capsule retrieval/fork and event streaming only when covered by contract tests.

#### Step 1E — unify the Python facade and errors

The canonical top-level exports should be small:

```python
from lean_ctx import LeanCTX, ContextSession, LeanCtxError
from lean_ctx.ocla import OclaClient, AsyncOclaClient
```

`LeanCtxClient` may remain as a deprecated alias during the convergence release if its exact historical behavior is documented.

It must not ambiguously refer to a local CLI wrapper in one context and an HTTP client in another.

Use explicit names such as `LocalClient`, `HttpClient`, and `OclaClient` below the facade.

Unify errors in `packages/python-lean-ctx/lean_ctx/errors.py`.

Preserve old names through aliases only where safe.

Give all public errors stable machine-readable codes aligned with protocol codes where applicable.

#### Step 1F — package metadata, release automation, and compatibility

Update `packages/python-lean-ctx/pyproject.toml` to:

- declare the accepted Python floor;
- define only justified optional extras (`openai`, `http`, `ocla`, `langchain`, `litellm`, `llamaindex`, `crewai`);
- own one `lean_ctx*` package discovery rule;
- own source-only test tooling;
- state the public product description as Context SDK, not only compression wrapper.

Retire Python publication from `.github/workflows/publish-clients.yml`.

Keep TypeScript and Rust publication in that workflow or split it into explicitly named language workflows.

Make `.github/workflows/publish-sdk.yml` the single Python publication path, or rename it to a product-neutral `publish-python.yml` once it no longer conflates Node and Python packages with the same package name.

Do not leave tag patterns `sdk-v*` and `client-v*` capable of publishing two incompatible Python distributions.

Replace the public-build-policy contract entry only with the matching source move:

```diff
- "clients/python/pyproject.toml"
+ "packages/python-lean-ctx/pyproject.toml"
```

Update the corresponding gate snapshots/hashes/tests by the project's prescribed policy workflow.

#### Step 1G — Python cutover tests and exit gates

Required test classes:

- old package behavior regression tests migrated with each source file;
- `/v1` HTTP/conformance tests;
- OCLA type serialization/parity tests;
- sync and async streaming tests;
- OpenAI wrapper tests;
- local CLI wrapper tests;
- clean wheel/sdist installation tests;
- import tests on Python 3.10, 3.11, and current maximum;
- legacy import shim tests if released;
- installer-order tests for old collision pairs;
- namespace test proving one canonical wheel owns `lean_ctx`.

Required clean-install proof commands:

```bash
python -m build packages/python-lean-ctx
python -m venv /tmp/leanctx-sdk-clean
/tmp/leanctx-sdk-clean/bin/python -m pip install packages/python-lean-ctx/dist/*.whl
/tmp/leanctx-sdk-clean/bin/python -c 'import lean_ctx; print(lean_ctx.__file__)'
```

Repeat in every supported Python version through CI.

The legacy co-install cases must be tested only as failure/migration evidence, not offered as supported configuration.

#### Step 1H — archive/deletion order

Deletion order after a published compatibility window:

1. `py-sdk/`, because its types have moved and validator has been retargeted.

2. `python-sdk/`, because its async behavior has moved and collision tests pass.

3. `clients/python/`, because `/v1`, conformance, verifier, adapters, public-build policy, and docs have moved.

Each legacy deletion is a separate reviewable commit.

Each commit must include:

- a repository-wide reference search;
- migrated test evidence;
- supported interpreter results;
- built wheel inspection;
- release/workflow change if applicable;
- documentation update;
- public-build-policy update where applicable.

Do not rewrite Git history.

History is the archive.

Use a tombstone README only for one release cycle if source consumers need migration guidance.

### Step 2 — clean the Rust workspace and enforce the OSS/private boundary

**Effort:** 10–15 engineering days  
**Owner:** Rust runtime/protocol owner  
**Goal:** contracts-first public runtime with honest optional/private seams

#### Step 2A — freeze V1 public names before rewiring

Create or finalize V1 definitions in `rust/crates/lean-ctx-protocol/src/` for:

- `ContextSessionV1`;
- `TuningProfileV1`;
- `ContextKitV1`;
- `ExecutionReceiptV1`;
- `SavingsReceiptV1`;
- `EvidenceBundleV1`.

Keep existing protocol execution/savings contracts as canonical starting points rather than creating a second receipt family.

Add fields only through an explicit compatibility review.

Required fields include session/task identity, integration depth, runtime/SDK versions, profile/Kit digests, input/output digests, transformations, budgets, usage, cost basis, provider/tool observations, quality result/reference, baseline/treatment identity, recovery/degradation records, ordered events, and integrity/signature metadata.

Cost basis must distinguish:

```text
provider-reported usage
calculated API cost
invoice-reconciled cost
```

Receipt signing proves artifact integrity, not business truth.

That limitation belongs in the contract documentation and reporting surfaces.

#### Step 2B — introduce facade modules before wholesale moves

Build a `SessionCoordinator`/public facade over existing substrate:

- `rust/src/core/session/` and session-related modules;
- `rust/src/core/context_kernel/`;
- `rust/src/core/profiles/` and `profile_suggest`;
- `rust/src/kits/mod.rs`;
- `rust/src/core/evidence_flow.rs`;
- `rust/src/core/evidence_bundle.rs`;
- `rust/src/core/benchmark.rs`;
- evaluation, shadow, quality, measurement, billing, ledger, and cache modules.

Do not expose every `core/` struct.

The public Rust SDK should have a narrow `LeanCtx` facade that validates project, integration, runtime, and policy configuration.

It then creates a single task-scoped session lifecycle.

#### Step 2C — make Attach, Wrap, and Embed semantically identical

Wire the same V1 event/receipt semantics through:

- `rust/src/mcp_stdio.rs` and `rust/src/tools/registered/` for MCP Attach;
- `rust/src/hooks/` and hook handlers for coding-agent Attach;
- `rust/src/proxy/` and proxy forward paths for sidecar/Wrap observation;
- `rust/src/wrap/` for local wrapper setup;
- `rust/crates/lean-ctx-sdk/` for Embed;
- CLI install/onboard/doctor/profile/kit commands for local operations.

Each integration must declare its depth, capabilities, installed version, session carriage method, profile assignment, health result, and last receipt reference.

The integration registry becomes the concrete Connect experience.

#### Step 2D — turn existing profiles into `TuningProfileV1`

Existing configuration/profile substrate becomes the implementation behind the contract.

Add:

- immutable content digest;
- schema/version identifier;
- origin/baseline lineage;
- capability and policy compatibility;
- state (`draft`, `evaluated`, `promoted`, `deprecated`);
- explicit apply/deploy operation;
- rollback reference;
- profile reference written to session and receipts.

No profile is "deployed" merely because a configuration file changed.

Deployment must return a result that identifies the target, applied digest, validation, and rollback point.

#### Step 2E — converge Kit source, package, and install

Keep `rust/src/kits/mod.rs` as Kit source/validation logic.

Keep `rust/src/core/context_package/` as a useful pack/registry substrate until its behavior is absorbed behind the single `ContextKitV1` contract.

Implement an explicit `kit.toml` → deterministic package → verifier → cache/loader path.

Bind the resolved Kit name/version/digest to a session and receipt.

Make all declared Kit capabilities either implemented or rejected at validation time.

Do not silently ignore shell/quality/system-prompt sections in a product-labeled Kit.

#### Step 2F — enterprise feature gates

Refactor `rust/src/core/solution_commercial.rs` so it does one of two honest things:

1. expose only stable public capability interfaces and return a structured `ENTITLEMENT_REQUIRED` result; or

2. remove unsupported public command surfaces until private integration is ready.

Do not retain no-op AutoTune logic that looks enabled.

Place experimental local heuristics under `experimental` and do not call them AutoTune.

Keep all proprietary implementation in `lean-ctx-enterprise` private source.

Maintain public-build-gate coverage proving no forbidden private imports, URLs, dependency names, paths, credentials, Stripe, database configuration, or customer code leak into GitHub.

#### Step 2G — Rust acceptance gates

```bash
cd rust
cargo test --lib
cargo test --workspace
cargo clippy --all-features -- -D warnings
cargo fmt --check
```

Add focused conformance tests that prove Attach, Wrap, and Embed produce compatible session/profile/receipt semantics for the same declared scenario.

Add protocol fixture compatibility tests for Rust, Python, and TypeScript bindings.

### Step 3 — implement `ctx.wrap()` in `packages/python-lean-ctx`

**Effort:** 8–12 engineering days for OpenAI v1 wrapper  
**Owner:** Python SDK owner with runtime/protocol review  
**Goal:** a real lifecycle-aware Wrap path, not another compression helper

#### Step 3A — public API contract

Initial Python API:

```python
from lean_ctx import LeanCTX

ctx = LeanCTX(project=".")
client = ctx.wrap(OpenAI(), adapter="openai")

with ctx.session("Review this diff") as session:
    response = client.responses.create(
        model="gpt-5",
        input="Review this diff",
    )

receipt = ctx.receipt(session)
```

Async form uses the same conceptual API and native context manager shape.

`ctx.wrap()` accepts only a declared adapter name or `auto` where exactly one adapter positively identifies the target.

Ambiguous recognition is an error.

Initial supported adapter:

```text
adapter="openai"
```

The OpenAI Agents SDK wrapper is the first commercial implementation target.

Other integrations remain optional modules until demand and version testing justify support.

#### Step 3B — adapter architecture

Create:

```text
lean_ctx/integrations/registry.py
lean_ctx/integrations/base.py
lean_ctx/integrations/openai.py
lean_ctx/session.py
lean_ctx/facade.py
```

The adapter flow is:

```text
AdapterRegistry.resolve(target, adapter)
        ↓
validate supported target and operation version
        ↓
normalize request to ContextInput
        ↓
bind explicit task-local session or labelled implicit session
        ↓
ask Rust runtime/planner for policy-approved preparation
        ↓
strip LeanCTX-only options
        ↓
call unchanged upstream SDK method
        ↓
observe usage, output, error, cancellation, and stream close
        ↓
append canonical events and seal/queue receipt finalization
```

Use `contextvars` for task-local Python session propagation.

Nested sessions require an explicit parent.

They never inherit an implicit global budget.

#### Step 3C — behavioral guarantees

`wrap()` preserves normal upstream return values.

It preserves response object types.

It preserves errors unless the failure is itself a documented LeanCTX initialization/policy error before provider invocation.

It preserves cancellation semantics.

It preserves backpressure and chunk ordering for streaming.

It removes LeanCTX-only keyword arguments before calling upstream.

It never reflects/wraps arbitrary objects without a named adapter contract.

It never sends provider traffic itself for `session.prepare()`.

It never silently retries the customer operation.

Policy-approved degradation passes the original request and records the decision.

#### Step 3D — adapter errors and capability matrix

Expose stable errors/codes:

```text
ADAPTER_NOT_FOUND
ADAPTER_AMBIGUOUS
ADAPTER_VERSION_UNSUPPORTED
ADAPTER_OPERATION_UNSUPPORTED
WRAP_POLICY_CONFLICT
STREAM_FINALIZATION_FAILED
```

Ship a tested adapter matrix covering exact supported OpenAI SDK/Agents SDK versions and operations.

Do not claim generic OpenAI compatibility.

Each adapter release must name its supported upstream versions, operation coverage, streaming coverage, session carriage behavior, and receipt completeness level.

#### Step 3E — `wrap()` tests

Required tests:

- direct completion/response return type equality;
- request normalization and LeanCTX-option stripping;
- unsupported version/operation rejection before request execution;
- explicit and implicit labelled session binding;
- nested-session failure semantics;
- provider error passthrough;
- cancellation passthrough;
- streaming chunk order and finalization;
- no duplicate requests/retries;
- observable transformation/degradation in receipt;
- quality/cost event capture with mock provider facts;
- contract fixture parity with Rust receipts.

Step 3 exit gate:

```text
One supported OpenAI wrapper creates a valid ContextSessionV1,
preserves upstream behavior,
and yields a sealed or explicitly pending canonical receipt.
```

### Step 4 — wire evidence and receipts to `wrap()` and Dyno

**Effort:** 10–15 engineering days  
**Owner:** runtime/evidence owner with Python wrapper owner  
**Goal:** turn observation into verifiable before/after proof

#### Step 4A — canonical runtime evidence path

Existing useful components include:

- `rust/src/cli/dispatch/evidence_realworld.rs`;
- `rust/src/core/evidence_flow.rs`;
- `rust/src/core/evidence_bundle.rs`;
- receipt/signature/canonicalization modules;
- `rust/src/core/benchmark.rs`;
- evaluation, shadow, and quality modules;
- `packages/leanctx-verify/`.

They become one path:

```text
scenario manifest
        ↓
matched baseline run
        ↓
matched Wrap/Attach/Embed treatment run
        ↓
provider usage + normalized cost facts
        ↓
quality gate
        ↓
ExecutionReceiptV1 for each arm
        ↓
SavingsReceiptV1 only if gate passes
        ↓
EvidenceBundleV1
        ↓
independent offline verification
```

`evidence_realworld` must call the canonical evidence-flow assembler or be renamed explicitly as an unsigned experiment.

It must not be advertised as Dyno proof until it has matched arms, quality gate, canonical receipts, signature/bundle, and offline verifier output.

#### Step 4B — direct `wrap()` wiring

The Python adapter records normalized lifecycle events with stable session identity.

The Rust runtime supplies planning/policy results and assembles canonical facts.

On provider completion, the adapter records provider-reported token usage, cached-token fields if supplied, model/provider identity, latency, cancellation/failure state, and transformation facts.

On session close, the runtime seals `ExecutionReceiptV1`.

If the receipt cannot finalize after an upstream result was successfully delivered, return the result and report `STREAM_FINALIZATION_FAILED`/pending finalization state without lying that evidence exists.

For comparisons, the runner creates baseline and treatment with:

- the same scenario/task;
- the same model/provider contract unless comparison intentionally says otherwise;
- the same repository/data revision;
- the same quality evaluator and threshold;
- disclosed randomization/repetition rules;
- declared profile/Kit/integration-depth differences only.

#### Step 4C — quality gate and proof gate

No savings receipt is emitted if:

- baseline is absent or incomparable;
- provider/cost basis is absent;
- quality evaluation is absent;
- treatment quality falls below threshold;
- scenario integrity fails;
- profile/Kit/commit identity is not pinned;
- evidence bundle fails verification.

The user-facing wording must distinguish:

```text
measured provider usage
calculated cost using local price table
invoice-reconciled cost
quality-preserved result under declared evaluator
artifact integrity verified by supplied key
```

The system must not claim business savings from a signature alone.

#### Step 4D — Dyno local

Implement Dyno local on existing benchmark/eval/evidence substrate rather than a parallel measurement stack.

Add:

- `DynoScenarioV1` manifest;
- deterministic baseline/treatment runner;
- anti-cheating/reproducibility checks;
- quality gate interface;
- canonical receipt assembler;
- evidence-bundle exporter;
- offline verification command;
- human-readable and machine-readable result report.

Suggested CLI:

```bash
lean-ctx dyno run scenarios/openai-review-v1.toml
lean-ctx verify out/openai-review-v1.evidence.zip
```

Initial proof target:

```text
OpenAI Python Wrap
same workload
baseline versus LeanCTX profile
quality gate
signed bundle
offline verify
```

That is enough for a v1.0 evidence claim.

It is not a hosted benchmark platform.

#### Step 4E — evidence acceptance gates

- Baseline and treatment produce valid `ExecutionReceiptV1` fixtures.
- A passing comparison produces `SavingsReceiptV1` and `EvidenceBundleV1`.
- A failing quality gate produces no savings claim.
- Tampered evidence fails in `packages/leanctx-verify/`.
- Attach, Wrap, and Embed receipts have compatible core semantics.
- Receipt output has no secrets and passes redaction/policy tests.
- Deterministic bundle tests remain stable.

### Step 5 — ship v1.0 on PyPI

**Effort:** 5–8 engineering days after prior gates  
**Owner:** release owner with all domain-owner sign-off  
**Goal:** one honest, installable public Context SDK release

#### Step 5A — release contents

v1.0 must include:

- one canonical Python distribution from `packages/python-lean-ctx`;
- primary `lean_ctx` namespace;
- documented `LeanCTX`, `session()`, `wrap()`, `load_kit()`, and `receipt()` public surface;
- one tested OpenAI wrapper path;
- explicit local/HTTP/OCLA client modules;
- a documented supported Python version range;
- contract fixtures compatible with Rust runtime;
- integration capability/version matrix;
- Dyno local proof path and offline verify instructions;
- migration guide from every legacy Python distribution;
- one publisher workflow and protected release owner;
- signed/tagged release artifact and SBOM/provenance according to repository policy.

v1.0 must not claim:

- AutoTune;
- managed execution;
- hosted Cloud billing;
- generic framework wrapping;
- invoice-reconciled savings unless that capability is implemented;
- quality-preserved savings without Dyno evidence.

#### Step 5B — PyPI release procedure

1. Verify PyPI ownership of `lean-ctx-sdk` and legacy names.

2. Build canonical sdist/wheel from a clean checkout.

3. Run package tests on supported Python versions.

4. Inspect wheel contents to ensure only canonical `lean_ctx` implementation files are present.

5. Test clean install and import.

6. Test OpenAI wrapper fixture and Dyno local fixture.

7. Publish first to TestPyPI if its dependency resolution matches the target release process.

8. Publish only through the single reviewed Python workflow.

9. Publish migration release notes and old-to-new constructor/import table.

10. Mark legacy distributions deprecated after canonical package availability is confirmed.

11. Keep legacy packages available, but do not silently republish them with a new incompatible API.

12. Delete source directories only after the announced deprecation window and exit evidence.

#### Step 5C — versioning guidance

Because the current package is `0.3.0`, a public `1.0.0` is a compatibility promise, not a marketing milestone.

Do not issue `1.0.0` until all documented core primitives and their test/contract guarantees are real.

If convergence release only delivers package unification without the promised five primitives and evidence path, ship it as `0.x` with precise release notes.

The product version must follow delivered semantics, not desired positioning.

---

## 9. Detailed future-state ownership map

| Existing asset | Future owner | Future role | Action |
| --- | --- | --- | --- |
| `rust/src/main.rs` | OSS runtime | one `lean-ctx` CLI | retain and converge commands on V1 objects |
| `rust/src/mcp_stdio.rs` | OSS runtime | one MCP server | retain; wire session/receipt semantics |
| `rust/src/tools/registered/` | OSS runtime | Attach tool surface | retain; map tools to SDK lifecycle |
| `rust/src/hooks/` | OSS runtime | coding-agent Attach integrations | retain; capability registry and health reporting |
| `rust/src/proxy/` | OSS runtime | sidecar/Wrap substrate | retain; add upstream E2E proof and receipt facts |
| `rust/src/wrap/` | OSS runtime | local wrap setup | retain; bind integration/profile identity |
| `rust/src/core/context_kernel/` | OSS implementation | planner/session internals | retain; hide behind public facade |
| `rust/src/core/compressor*` | OSS implementation | transformation engine | retain; profile-controlled |
| `rust/src/core/repomap*`, search, cache | OSS implementation | context selection/reuse | retain; session-owned facts |
| `rust/src/core/profiles*` | OSS implementation | `TuningProfileV1` backend | converge to versioned lifecycle |
| `rust/src/kits/` | OSS implementation | Kit source/validation | converge to `ContextKitV1` pack/install |
| `rust/src/core/context_package/` | OSS implementation | package/registry substrate | retain until mapped to Kit contract |
| `rust/src/core/evidence_*` | OSS implementation | receipt/bundle assembly | converge to one canonical path |
| `rust/src/core/benchmark*`, eval, quality | OSS implementation | Dyno local substrate | reuse, do not duplicate |
| `rust/crates/lean-ctx-protocol` | OSS contracts | V1 schema source | strengthen and fixture-test |
| `rust/crates/lean-ctx-ocla` | OSS contracts | OCLA lifecycle bridge | retain public/private seam |
| `rust/crates/lean-ctx-sdk` | OSS SDK | Rust Embed facade | productize V1 lifecycle |
| `clients/rust/lean-ctx-client` | OSS client | Rust HTTP client | retain only with contract parity |
| `packages/python-lean-ctx` | OSS SDK | one Python distribution | canonicalize and ship |
| `clients/python` | migration source | `/v1` and conformance behavior | migrate then archive/delete |
| `py-sdk` | migration source | types/sync OCLA behavior | migrate then delete |
| `python-sdk` | migration source | async OCLA/streaming behavior | migrate then delete |
| `cookbook/sdk` | OSS client | TypeScript client/conformance sibling | retain as TypeScript; share fixtures |
| `packages/node-lean-ctx` | OSS SDK | JS/TS compression/wrap surface | align later to same contracts |
| `packages/leanctx-verify` | OSS verifier | independent evidence verification | retain; make canonical bundle verifier |
| `kits/code-review` | OSS Kit fixture | first ContextKitV1 reference | evolve and use in E2E tests |
| `rust/src/core/solution_commercial.rs` | OSS boundary | explicit unavailable/entitlement seam | simplify; no fake implementation |
| GitLab `origin` | private/legacy | classified deployment/integration only | inventory before mutation |
| `deploy` | Thinkery website | website-only artifact promotion | prohibit runtime source of record |
| `lean-ctx-enterprise` | Thinkery private | organization controls/policy | downstream private consumer |
| `lean-ctx-cloud` | Thinkery private | accounts/billing/hosted services | downstream private consumer |

---

## 10. What to delete, archive, or explicitly defer

### 10.1 Delete only after migration gates

The following are deletion candidates, not immediate deletion commands:

```text
py-sdk/
python-sdk/
clients/python/
```

Deletion requirements are listed in Step 1H.

No legacy directory is deleted merely because its name is confusing.

The behavior, types, tests, documentation references, workflows, policy references, and compatibility decision must move first.

### 10.2 Archive rather than maintain as product surface

Archive raw strategy-analysis documents that are superseded by approved canonical documentation.

Keep them under `docs/internal/_archive/` with a clear source-of-truth pointer.

Do not create a second divergent repo-convergence strategy.

The accepted plan should be linked from the internal documentation index and reconciled with `docs/internal/reference/REPO-CONVERGENCE.md`.

The future extracted decision record should point to this plan rather than restate it.

### 10.3 Remove or reclassify misleading enterprise stubs

Candidate files include public functions in `rust/src/core/solution_commercial.rs` that resemble AutoTune/commercial features but only return errors or no-op.

Do not delete the boundary without a replacement.

Replace it with one of:

- a structured public capability/entitlement interface;
- a clear runtime error for unavailable commercial features;
- removal of unsupported commands from the public interface.

Move any actual private implementation out of public history/source paths.

Do not call local heuristic code "AutoTune" until it has an objective, search space, experiment scheduler, quality constraints, promotion governance, profile registry, and evidence gate.

### 10.4 Remove duplicate publishing paths

After canonical Python cutover:

- Remove the Python publication job from `.github/workflows/publish-clients.yml`.
- Remove obsolete `client-v*` logic that can publish a Python distribution.
- Keep one named release owner and one protected PyPI path.
- Update documentation so it never recommends `pip install lean-ctx-client`, `leanctx`, or `lean-ctx-ocla` as the current SDK.

Retain legacy PyPI projects only as deprecated migration signposts during the announced window.

### 10.5 Delete dead delivery references only after restoration decision

The audit found `tests/delivery` references to absent scripts including:

- `scripts/check-release-tag.py`;
- `scripts/verify-delivery-manifest.py`;
- `scripts/rehearse-delivery.py`;
- `scripts/verify-delivery-evidence.py`.

Do not merely delete tests to make CI green.

Either restore the delivery tooling/contract or replace it through a reviewed delivery-policy change with equivalent tested guarantees.

### 10.6 Do not delete valuable foundations

Do not delete any of the following merely because they are not v1 product APIs yet:

- evidence signing/bundle/verifier code;
- benchmark/evaluation/quality substrate;
- context package substrate;
- profile and session substrate;
- local agent bus primitives;
- proxy code;
- protocol fixtures;
- first-party Kit data.

They are convergence inputs.

Their fate is to move behind a product contract, remain internal, or be explicitly deferred—not to be casually removed.

### 10.7 Safe phased cleanup sequence

Cleanup is a convergence activity, not a bulk-deletion exercise.

Every batch starts from current GitHub main on a dedicated
cleanup/<wave>-<scope> branch.

Never delete on main directly.

Every move uses git mv.

Every final removal uses git rm.

Every uncertain candidate is retained or moved to a documented _archive/
location before deletion is considered.

Every cleanup PR contains a candidate table with path, classification,
evidence, action, replacement, owner, test evidence, and rollback commit.

Classification is shipped, supported, used, experimental, dead, or unknown.

Unknown means retain.

Published packages, GitHub release artifacts, documented CLI/MCP/SDK surfaces,
and release workflow inputs are shipped compatibility surfaces.

They require a replacement, an announced deprecation, and the applicable
compatibility window before removal.

Stable public surfaces follow CONTRACTS.md: deprecate for at least two minor
releases before removal.

Feature-flag a replacement whenever hidden users, behavior equivalence, or
runtime dispatch is uncertain.

The flag needs a default, owner, removal condition, and tests for both paths.

Before and after each logical removal, run:

    cd rust
    cargo build --release --locked
    cargo test --lib
    cargo clippy --all-features -- -D warnings
    cargo fmt --check
    cargo test --all-features
    cargo test --test main
    ./target/release/lean-ctx --version
    ./target/release/lean-ctx --help

Do not stop the installed runtime before project builds or tests.

Run the affected CI jobs in addition to the Rust gate: cookbook for Node and
cookbook paths, pi-extension for Pi, python-sdk for Python, rust-sdk and
embed-sdk for Rust SDK work, sdk-conformance for wire/SDK changes, the Go
conformance workflow for conformance fixtures, grammar-addons for its host and
asset path, and a release rehearsal for packaging changes.

CI must stay green.

The main lean-ctx binary must still build, answer --version and --help, and
remain packageable for all released target families.

#### Wave 1 — verified dead candidates and duplicate Python paths

First inventory all Python manifests, imports, console scripts, package exports,
workflows, documentation references, and registry projects.

packages/python-lean-ctx is the published lean-ctx-sdk convergence target and
stays.

clients/python publishes lean-ctx-client and stays until an explicit
compatibility migration completes.

py-sdk publishes leanctx and is a shipped surface, not a delete-on-sight
duplicate.

python-sdk declares the unpublished lean-ctx-ocla package, but remains
unknown until its callers, tests, docs, and OCLA role are audited.

Move a verified unshipped, zero-reference source to
_archive/python-experiments/<name>/ with git mv and an archive README first.

Only then make a small git rm PR for code that remains zero-reference after the
retention and review period.

No-op or error-returning commercial-looking public stubs require a replacement
boundary, clear unavailable error, or command deprecation before removal.

Rollback by reverting the smallest move or removal commit, then restore a
compatibility shim if an external import or command appears.

#### Wave 2 — experiment boundaries

Compare tracked paths with .gitignore before proposing a cleanup.

discord-bot/ and n8n-workflows/ are ignored and absent from this public
checkout; they are not deletion targets.

Tracked discord-faq documentation is not the ignored Discord bot.

packages/pi-lean-ctx is published on npm, documented in the README, and
covered by the pi-extension CI job; retain it as a public integration.

rust/experiments/grammar-dlopen-spike is not automatically dead because the
grammar-addons workflow builds grammar-dlopen-host from that area.

Archive only a tracked experiment with no release, CI, package, documentation,
test, runtime, or feature-flag dependency.

Use _archive/experiments/<area>/ with an owner, source commit, canonical
alternative, status, and restoration instructions.

Rollback by git mv back to its original path and re-run its release or CI
coverage.

#### Wave 3 — benchmark consolidation

There are three top-level benchmark roots: bench/, benchmarks/, and benchmark/.

rust/benches/ is a separate Cargo benchmark surface and is out of the first
top-level consolidation.

Approve one canonical root before moving content; bench/ is the provisional
target because the README already links to bench/agent-task/r2.

First land a benchmark index that maps every runner, fixture, dataset, result,
workflow, command, method, and documentation link.

Then move one source root per PR with git mv, updating runners and CI in the
same focused batch.

Preserve raw measurement provenance, constraints, input identity, and commit
identity.

Archive non-reproducible historical results rather than deleting evidence.

Remove an old empty root with git rm only after a fresh zero-reference audit.

Rollback a root-specific move PR if a clean checkout cannot execute its former
runner or preserve its structural results.

#### Wave 4 — OCLA normalization

Do not start a major OCLA refactor before the required audit.

Create docs/internal/architecture/OCLA_CURRENT_STATE.md listing traits,
implementors, registries, wire interfaces, call sites, overlaps, unused
interfaces, public exports, package manifests, feature flags, and release
consequences.

Audit rust/src/core/ocla/, rust/crates/lean-ctx-ocla/,
rust/crates/lean-ctx-protocol/, rust/crates/lean-ctx-sdk/,
packages/ocla-grpc/, ts-sdk/, and python-sdk/ at minimum.

Published lean-ctx-ocla and lean-ctx-protocol crates remain intact until a
versioned compatibility decision completes.

Define a minimal Capability Manifest v0 with ID, version, type, execution mode,
input/output, lossiness, recoverability, permissions, and telemetry.

Make one mature native provider abstraction the reference capability.

Link the Capability identity and version to both Performance Profile and
Execution Receipt.

Run the existing benchmark through that capability path before adding broader
external integrations.

Any uncertain old/new dispatch remains feature-flagged and is tested in both
states.

Rollback by defaulting to the old flag path or reverting the isolated OCLA PR;
do not overlay a second registry or casually remove a released protocol.

#### Review and rollback discipline

One PR contains one logical cleanup batch.

Do not combine cleanup with feature changes, dependency upgrades, broad
formatting, or release-policy rewrites.

Run git diff --check and confirm no compression omission marker is written to
tracked source.

If a gate fails, stop the wave and revert the smallest affected cleanup commit.

For a merged regression, use git revert in a new corrective PR.

Do not force-push public history.

The companion D3 safe cleanup plan records the full public-surface inventory,
per-wave checklists, CI mapping, and rollback rules.

---

## 11. Release, documentation, and website convergence

### 11.1 One version story

The product must stop publishing incompatible SDKs on independent version tracks without an ownership map.

The engine, protocol, Python SDK, TypeScript SDK, and Rust SDK may have independent semver versions where release cadence requires it.

But each release must publish compatibility metadata:

```text
runtime version range
protocol version range
Python SDK version range
adapter capability/version matrix
Kit/Profile schema versions
evidence verifier compatibility
```

The website documentation and generated API references consume this compatibility table.

### 11.2 One installation story

For the Python v1 path:

```bash
pip install lean-ctx-sdk[openai]
```

For the local coding-agent path:

```bash
lean-ctx onboard
```

For verification:

```bash
lean-ctx verify <bundle>
```

For legacy users, publish a migration table:

| Legacy distribution/import | Replacement | Support window |
| --- | --- | --- |
| `lean-ctx-client` / `leanctx` | `lean-ctx-sdk` / `lean_ctx` | documented deprecation window |
| `leanctx` from `py-sdk` | `lean-ctx-sdk` / `lean_ctx.ocla` | documented deprecation window |
| `lean-ctx-ocla` / `lean_ctx` | `lean-ctx-sdk` / `lean_ctx.ocla` | documented deprecation window |

Never tell users to co-install old and new distributions that own the same import namespace.

### 11.3 One evidence story

Marketing language follows the actual evidence level.

Safe current language before Step 4:

```text
LeanCTX provides local context compression/runtime tooling,
structural context views, MCP/CLI integrations, and signed evidence-bundle primitives.
```

Safe v1 language after Step 4:

```text
LeanCTX can run a declared local baseline/treatment benchmark,
apply a tested profile through a supported integration,
evaluate the declared quality gate,
and export an independently verifiable evidence bundle.
```

Do not replace methodology with an unqualified percentage claim.

### 11.4 One website promotion story

Public content lands through a reviewed source commit.

The website artifact is built once.

The artifact is promoted to `deploy` with source SHA/digest/rollback record.

The deployment channel cannot alter product code after review.

---

## 12. Sequencing, effort, and critical path

| Phase | Effort | Depends on | Blocks |
| --- | --- | --- | --- |
| 0. Freeze/repair/inventory | 3–5 days | ownership | every public v1 claim |
| 1. Python consolidation | 8–12 days | Phase 0 decisions | v1 PyPI release, `ctx.wrap()` |
| 2. Rust contracts/workspace cleanup | 10–15 days | Phase 0 | consistent session/profile/receipt semantics |
| 3. OpenAI `ctx.wrap()` | 8–12 days | Python facade + V1 contracts | commercial Python wedge |
| 4. Evidence + Dyno local | 10–15 days | Wrap + receipts/contracts | verified-gain promise |
| 5. Release v1.0 | 5–8 days | all prior gates | public launch |

Estimated critical-path effort:

```text
44–67 engineering days
```

That estimate excludes unknown private Cloud/GitLab operational inventory work and any production-service migration.

Those are intentionally outside the OSS product critical path.

The fastest credible first slice is:

```text
Python consolidation
        +
OpenAI Wrap
        +
one local Dyno scenario
        +
quality gate
        +
signed evidence bundle
        +
offline verifier
```

That slice proves the complete product loop:

```text
Connect → Measure → Tune → Prove → Deploy → Repeat
```

without prematurely building Cloud, marketplace, managed Run, autonomous tuning, or a customer control plane.

---

### Post-v1 extension: composable capability architecture

This roadmap starts only after the current Phase 0–5 product program and its
definition of done.  It does not change Phase A scope, effort, gates, or its
v1 release condition.

#### Phase A — Product proof (unchanged)

Phase A remains the current work:

- Performance Benchmark;
- Quality Gate;
- Receipt;
- Reference Agent;
- SDK;
- Paid Customer.

Its completion criteria remain the existing **Definition of done** in the next
section.  No Capability substrate, external capability, selection engine,
marketplace, or commercial intelligence work is pulled into Phase A.

#### Conceptual codebase target

The target below is an ownership map, not a directive to create or move folders
before the audit.  First map the current Cargo workspace into these
responsibilities; only then make a physical refactor decision.

```text
lean-ctx/
  crates/
    leanctx-protocol/
      task/
      context/
      receipt/
      profile/
      capability/

    leanctx-ocla/
      manifest/
      registry/
      traits/
      adapters/
      conformance/

    leanctx-runtime/
      planner/
      context/
      execution/
      evidence/

    leanctx-capabilities/
      native/
        code/
        compression/
        shell/
        memory/
        retrieval/
        evidence/

    leanctx-sdk/
      session/
      profiles/
      kits/
      capabilities/

  cli/
    capability/
    profile/
    benchmark/
```

#### Phase B — Capability substrate

The first architectural task after v1 is an OCLA audit.  Document every
current trait, implementor, registry, wire interface, call site, overlap, and
unused interface in `OCLA_CURRENT_STATE.md`.  Map existing Native features to
the target capability categories.  Do not begin a broad OCLA or Cargo-workspace
refactor before that audit is accepted.

Define `CapabilityManifestV0` as the smallest stable contract.  Every manifest
must declare:

- capability ID and immutable version;
- capability type;
- execution mode;
- bounded input and output contract;
- lossiness semantics;
- recoverability semantics;
- permissions and data-access boundary;
- telemetry and reported metrics.

The resolved identity is a pinned `(id, version, manifest content hash)`;
mutable aliases are selectors, never Profile or Receipt identity.  The
manifest must be sufficient to establish a bounded invocation, safe disablement,
and the measurements the Benchmark needs.  It is not a marketplace format,
selection language, or general plugin framework.

Choose one mature LeanCTX Native capability as the reference implementation.
Normalize that capability through the contract without mechanically wrapping
every existing function.  A Performance Profile pins its resolved capability
identity; the Benchmark executes that identity; and the Receipt records the
same identity and version.

Phase B is done when:

- `OCLA_CURRENT_STATE.md` is accepted and the current workspace is mapped to
  the ownership target;
- `CapabilityManifestV0` has a versioned specification, fixtures, and
  conformance checks for its required fields;
- one Native capability runs end-to-end through the canonical contract;
- one Performance Profile, Benchmark result, and Receipt carry the same pinned
  capability identity; and
- no broad refactor or additional provider integration was required to prove
  that path.

#### Phase C — External proof

Build one sample external local-process Capability against the same manifest
and conformance path.  It must be installable or registrable, declare a
manifest, receive bounded input, return output, report metrics, appear in a
Performance Profile, execute in the Benchmark, appear in the Receipt, and be
disabled safely.

~~If RTK is available as a real partner, run one small joint Benchmark experiment~~

**CANCELLED (2026-08-21):** Partnership-Track gestrichen zugunsten Monopol-Strategie.
Phase C is done when the sample external capability satisfies all nine
properties above and produces the same Profile/Benchmark/Receipt evidence path
as the Native reference. No external partnerships are pursued.

#### Phase D — Selection

Add selection only after Phase B and C produce comparable evidence.  Start
with simple, inspectable rules, candidate comparison, and a manual
recommendation.  Selection consumes pinned Capability manifests, Performance
Profiles, and comparable Benchmark/Receipt evidence; it does not silently
change a customer deployment.

Phase D is done when a documented rule set can compare eligible candidates for
one workload, show the evidence and constraints behind its result, and emit a
manual, reviewable recommendation.  Learned ranking, automatic rollout, and
Continuous Optimization remain out of scope.

#### Phase E — Commercial intelligence

Only after selection has sufficient trustworthy evidence, add learned ranking,
Continuous Optimization, and the Capability Performance Graph as commercial
intelligence.  These capabilities build on the same manifest pins, Profiles,
Benchmarks, Receipts, Quality Gates, and rollback/policy boundaries established
in the earlier phases.

Phase E is done when learned ranking is validated against held-out comparable
evidence, optimization is controlled by explicit policy and rollback, and the
Capability Performance Graph can trace each recommendation to its capability
identity, workload evidence, quality result, and receipt lineage.  It is not
done merely because a ranking model or graph exists.

---

## 13. Definition of done

Convergence is complete enough to call LeanCTX "The Context SDK for AI Agents" when all of the following are true.

### Product coherence

- The public docs define exactly five core SDK primitives.
- Python, Rust, CLI, MCP, and proxy use the same session/profile/Kit/receipt contract family.
- Attach, Wrap, and Embed have explicit capabilities and compatible evidence semantics.
- LeanCTX stays local-first and provider-neutral.

### Repository coherence

- GitHub `main` is documented and operated as OSS source of truth.
- GitLab is classified and no longer ambiguously treated as a mirror.
- `deploy` is website-only.
- `lean-ctx-cloud` has a private inventory and consumes public releases/contracts downstream.
- No private source, credential, customer config, Stripe, or database configuration is in OSS.

### Python coherence

- `packages/python-lean-ctx` is the only supported Python distribution root.
- `lean_ctx` is the only permanent primary import namespace.
- `/v1`, OCLA sync, OCLA async, adapters, local wrappers, errors, and conformance are one package with named modules.
- There is one Python publication workflow.
- Legacy packages have a published migration path and are no longer co-installable/conflicting.

### Rust coherence

- `rust/Cargo.toml` is the sole workspace root.
- `lean-ctx-protocol`, `lean-ctx-ocla`, and `lean-ctx-sdk` have documented non-overlapping roles.
- Enterprise is a downstream private consumer with honest public capability gates.
- Public build gate and full quality gate pass.

### Proof coherence

- `ctx.wrap()` has a tested OpenAI adapter.
- Baseline/treatment flows create canonical execution receipts.
- Quality failure prevents savings claims.
- A successful scenario emits a signed `EvidenceBundleV1`.
- `leanctx-verify` independently rejects tampering.
- The product labels cost basis and evidence limits accurately.

### Release coherence

- A clean virtual environment installs the one canonical Python wheel.
- The documented `LeanCTX` API works against a supported local runtime.
- The website, package metadata, CLI help, and examples use the same product name and installation path.
- v1.0 release notes disclose migration, compatibility, supported integration versions, and known non-goals.

---

## 14. Final recommendation

Do not converge by moving every directory into one location this week.

Converge by making one product contract real.

GitHub `main` becomes the public authority.

`packages/python-lean-ctx` becomes the one Python SDK.

`lean_ctx` becomes the one permanent Python import.

`rust/Cargo.toml` remains the one Rust workspace.

`lean-ctx` remains the one CLI.

The Rust stdio runtime remains the one MCP server.

`deploy` becomes website-only.

GitLab becomes a classified private/legacy deployment seam, not an alternate product truth.

`lean-ctx-enterprise` and `lean-ctx-cloud` remain private downstream consumers of versioned public contracts.

Kits become versioned, verified ContextKitV1 artifacts rather than loosely interpreted TOML.

Profiles become versioned deployable operating contracts.

Existing receipt, benchmark, quality, and verifier foundations become a single local Dyno proof path.

`ctx.wrap()` turns the first Python SDK integration into a real lifecycle-aware product surface.

Only then should LeanCTX ship v1.0 and make its promise in full:

> Tune any agent. Prove every gain.
