# Die nächsten zehn Schritte für diese Woche

## Wochenziel — Stand 2026-08-21 (Abend)

**Sales/Pilot ist ein paralleler kommerzieller Track** (#1254, #1270, #1271), kein Engineering-Gate.
**Aktuell: Vision Engineering.** `calibrate --live` vergleicht explizite Profile mit echter Agent-Initiierung; Quality Evaluator und Receipt-Verbindung sind abgeschlossen.

## Hold

| Ticket | Warum |
|---|---|
| #1254 paid Sprint | Kommerzieller Track, nicht Engineering-Gate |
| #1270 Live 15-Min | Optionaler Provider-/Operator-Test |
| #1271 Outreach | Kommerzieller Track |
| #1260/#1261 Website | weiter ON HOLD |

## Technik jetzt

| # | Was | Done when |
|---:|---|---|
| 1 | **DONE** (5736ebdc): `benchmark-run` ruft `LocalRunner` + echten `AgentConnector::execute` | kein „Local Runner not yet wired“ |
| 2 | **DONE** (timeout.rs, connector kill-on-timeout): Timeout aus `TaskRequest.timeout_ms` | Prozess wird gekillt, kein Hang |
| 3 | **DONE** (MockConnector tests, 11 tests pass): Tests ohne Live-Agent | cargo test grün |
| 4 | **DONE** (`calibrate.rs`): `--live --profiles A,B` führt jedes Profil mit eigenem `LEAN_CTX_PROFILE` aus | kein rein nomineller Kandidatenvergleich |
| 5 | **DONE**: expliziter QA Evaluator, `--spec`-Gate und Receipt-Link-Contract im lokalen Vergleich | nur deterministisch evaluierte Suites sind selektionsfähig; fehlende explizite Provider-Kosten bleiben korrekt `OBSERVED` |

## Completed 2026-08-21

- Wired `benchmark-run` to `LocalRunner` and the real `AgentConnector::execute` (5736ebdc).
- Added task timeout handling and connector kill-on-timeout (acc97c6f).
- Added MockConnector coverage; 11 tests pass without a live agent.
- Wired `calibrate --live` to real agent invocation with an explicit named-profile comparison; each candidate propagates `LEAN_CTX_PROFILE` to the child agent.
- Premium quality pass on calibrator module: deterministic tie-breaking, edge-case hardening, 57 tests.
- Calibration Quality Gate: declared QA evaluator, evidence-consistent summary, `--spec` validation, and canonical connector receipts are wired; missing explicit provider cost remains observed rather than fabricated.

## Nächster technischer Schritt

Phase C als Research starten: eine deklarierte Multi-Workload-Benchmark-Suite,
Capability-Coverage und reproduzierbare, workload-spezifische Vergleiche bauen.
Die Promotion zu einem öffentlichen Claim bleibt evidence-gated.

## Nicht

Marketplace, OSS-Paywalling und öffentliche Plattformclaims bleiben ausgeschlossen.
Pairing, Ranking und kommerzielle D/E-Funktionen folgen dem Vision-Execution-
Modus: Research zuerst; private D/E-Implementierung und keine ungestützten
öffentlichen Claims.
