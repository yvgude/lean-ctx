# Historical Python Preview implementation specification

> **Status:** Historical Preview compatibility design, not the current public SDK
> contract. The [internal README](../README.md),
> [Engine, SDK & Cloud Plan](../vision/06-ENGINE-SDK-CLOUD-PLAN.md), and
> [Context Workspace & `.ctxpkg` Plan](../vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md)
> prevail where they differ.
>
> **Runtime-parity boundary:** the Python façade expects `/v1/sessions`, kit and
> receipt routes that are not implemented by this Rust checkout. Its loopback
> tests prove client behavior against a fixture, not a released cross-language
> contract. Do not create a production integration from this document.

Target: `packages/python-lean-ctx` Preview source.

The specification describes an early Python façade for a task-scoped LeanCTX
lifecycle. It does not supersede the Rust runtime or versioned protocol, and it
must not be read as an assertion that the described HTTP routes are available.

The Rust runtime remains the authority for policy, PathJail, Kit verification,
planning, session persistence, canonical receipt assembly, and signatures.

The Python package is a small, synchronous, standard-library-first façade over
the intended local proxy contract.

## Execution status — 2026-08-22

The implementation lives in `packages/python-lean-ctx/` and remains **Preview**.
Its declared reference path is the OpenAI Agents `LeanCTX().wrap(agent)`
integration; exporting a helper or type does not broaden that support claim.

The Python package has a client-side `ContextSession` façade, but the Rust HTTP
session routes it expects are absent in this checkout. It cannot be represented
as a general cross-language lifecycle contract until that gap has passing
compatibility fixtures.

## 1. Source constraints

The specification is grounded in:

- `docs/internal/vision/06-ENGINE-SDK-CLOUD-PLAN.md`.
- `docs/internal/vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md`.
- `docs/internal/reference/CONTEXT-SESSION.md`.
- Every existing file in `packages/python-lean-ctx`.

The architecture limits the developer-facing core to five primitives:

- `LeanCTX()`.
- `session()`.
- `wrap()`.
- `load_kit()`.
- `receipt()`.

No sixth top-level primitive is introduced by this package.

`ContextWorkspace`, ContextCheckpoint, ContextDelta, fork, merge, remote
sync and package-registry behavior are explicitly excluded from v1. They are
post-v1 Research targets with separate contract, migration and support gates.

`prepare`, `retrieve`, `reuse`, `recover`, `use`, and `close` belong to a
session rather than to `LeanCTX`.

The v1 convenience surface requested for Python is intentionally narrower than
the eventual async Runtime API.

It offers a synchronous `run()` wrapper for a supported, run-method agent.

It does not claim to adapt arbitrary frameworks, monkey-patch provider SDKs,
change the user's model choice, invoke user tools, or retry application work.

## 2. Normative v1 decisions

1. Core runtime dependencies are limited to the Python-version-conditional
   `tomli` compatibility dependency; source `pyproject.toml` is normative.

2. HTTP uses `urllib.request`; the SDK adds no HTTP client dependency.

3. Existing `compress()`, `ProxyClient`, `LeanCtxClient`, and framework
   adapters remain supported compatibility APIs.

4. `POST /v1/compress` remains a deterministic `messages -> messages + stats`
   body transformation.

5. Session attribution travels in authenticated request headers and immutable
   response header evidence; it does not alter the compression body.

6. A `WrappedAgent` returns the original value exactly as `run.output`.

7. Receipt generation is observational: unavailable proxy usage is recorded as
   unknown or not-addressable, never invented from estimates.

8. A final receipt is immutable; post-final feedback is a separate amendment
   managed by the Runtime, not a Python mutation.

9. `receipt.verify()` returns `False` for incomplete, unverifiable, malformed,
   or stale evidence.  It never treats a transport failure as verified.

10. V1 sync methods must not call `asyncio.run()` or start hidden loops.

## 3. Package structure

The following is the v1 source layout.

```text
packages/python-lean-ctx/
├── pyproject.toml
├── README.md
├── conftest.py
├── lean_ctx/
│   ├── __init__.py
│   ├── core.py
│   ├── wrap.py
│   ├── session.py
│   ├── kit.py
│   ├── receipt.py
│   ├── profile.py
│   ├── proxy.py
│   ├── discovery.py
│   ├── client.py
│   ├── errors.py
│   ├── langchain.py
│   ├── litellm.py
│   └── llamaindex.py
└── tests/
    ├── test_core.py
    ├── test_wrap.py
    ├── test_session.py
    ├── test_kit.py
    ├── test_receipt.py
    ├── test_proxy.py
    ├── test_discovery.py
    ├── test_langchain_compress.py
    └── test_litellm.py
```

`client.py`, `discovery.py`, `errors.py`, and the three integration modules are
retained even though they are not new v1 primitives.

They are compatibility modules and must not be deleted in the v1 release.

`core.py`, `wrap.py`, `session.py`, `kit.py`, `receipt.py`, and `profile.py`
are new v1 modules.

## 4. Exact `pyproject.toml` contract

The project name is `lean-ctx-python`. The import remains `lean_ctx`.

The package is Apache-2.0, Preview/Beta and has only the
Python-version-conditional `tomli` dependency. The OpenAI Agents reference
path is an optional dependency.

```toml
[build-system]
requires = ["setuptools>=68.0"]
build-backend = "setuptools.build_meta"

[project]
name = "lean-ctx-python"
version = "1.0.0"
description = "Preview SDK for LeanCTX — context selection, shaping, reuse, recovery, and local evidence for AI agents"
readme = "README.md"
license = {text = "Apache-2.0"}
requires-python = ">=3.9"
dependencies = ["tomli>=2.0; python_version < '3.11'"]
keywords = ["llm", "context", "compression", "evidence", "ai", "mcp"]
classifiers = [
  "Development Status :: 4 - Beta",
  "Intended Audience :: Developers",
  "Topic :: Software Development :: Libraries",
  "Programming Language :: Python :: 3",
  "Programming Language :: Python :: 3 :: Only",
  "Programming Language :: Python :: 3.9",
]

[project.optional-dependencies]
langchain = ["langchain-core>=0.2"]
llamaindex = ["llama-index-core>=0.10"]
litellm = ["litellm>=1.0"]
openai-agents = ["openai-agents>=0.19.4,<0.20.0"]
verify = ["cryptography>=42.0"]
all = [
  "langchain-core>=0.2",
  "llama-index-core>=0.10",
  "litellm>=1.0",
  "openai-agents>=0.19.4,<0.20.0",
  "cryptography>=42.0",
]
test = ["pytest>=8.0"]

[tool.setuptools.packages.find]
include = ["lean_ctx*"]
```

`cryptography` is optional because core verification uses a Runtime verification
endpoint plus canonical-digest checks.

When installed, it enables offline Ed25519 verification of a signed receipt.

No secret, provider SDK, or protocol generator is a hard dependency.

## 5. Public exports: `lean_ctx/__init__.py`

The module must export the following names.

```python
from .core import LeanCTX, LeanCTXConfig
from .kit import ContextKit
from .profile import TuningProfile
from .receipt import ExecutionReceipt, SavingsInfo
from .session import ContextSession
from .wrap import LeanCtxRun, WrappedAgent
from .proxy import CompressResult, ProxyClient, compress
from .client import LeanCtxClient
from .errors import LeanCtxAuthError, LeanCtxConnectionError, LeanCtxError

__version__ = "1.0.0"
```

`__all__` must contain exactly those public names in the order above.

Existing exports from v0.3.0 remain available:

```python
from .langchain import LeanCtxRetriever, compress_messages
from .litellm import LeanCtxLiteLLMHandler, compress_request_data
from .llamaindex import LeanCtxNodeParser
```

Those three compatibility exports follow the core exports in `__all__`.

`discovery` remains importable as a module but is not a new advertised v1
primitive.

## 6. Exact public API

The following signatures are normative.

```python
class LeanCTX:
    def __init__(self, config=None) -> None: ...

    def wrap(self, agent, kit=None, profile=None) -> "WrappedAgent": ...

    def session(self) -> "ContextSession": ...

    def load_kit(self, name) -> "ContextKit": ...
```

```python
class WrappedAgent:
    def run(self, task) -> "LeanCtxRun": ...
```

```python
class LeanCtxRun:
    output: object
    receipt: "ExecutionReceipt"
```

```python
class ExecutionReceipt:
    def verify(self) -> bool: ...

    @property
    def savings(self) -> "SavingsInfo": ...
```

These calls must therefore work without an API key when a local mock or local
unauthenticated development proxy is configured.

```python
from lean_ctx import LeanCTX

ctx = LeanCTX()
wrapped_agent = ctx.wrap(agent, kit="payments", profile="balanced")
run = wrapped_agent.run("Review the payments module")

assert run.output == agent_output
assert run.receipt.verify() in (True, False)
savings = run.receipt.savings
```

The API must not expose the proxy response object as the run result.

The original agent output is always available as `run.output`.

The immutable evidence view is always available as `run.receipt`.

## 7. `LeanCTXConfig`

`LeanCTX(config=None)` accepts one of:

- `None`.
- A `LeanCTXConfig` instance.
- A mapping with exactly the keys defined below.

Unknown mapping keys raise `ValueError`.

```python
@dataclass(frozen=True)
class LeanCTXConfig:
    project: str | None = None
    agent_id: str | None = None
    proxy_url: str | None = None
    proxy_token: str | None = None
    timeout: float = 30.0
    default_profile: str = "balanced"
    fail_open: bool = True
    integration_depth: str = "wrap"
```

`project=None` means the current working directory after PathJail-compatible
normalization by the Runtime or proxy session API.

`agent_id=None` derives a stable package-local identifier from the agent type at
wrap time; it must never include a token, absolute home path, or task text.

`timeout` must be finite and greater than zero.

`integration_depth` accepts only `"attach"`, `"wrap"`, or `"embed"`.

V1 uses `"wrap"` for `WrappedAgent` and rejects `"embed"` because no native
Python Runtime binding exists yet.

`fail_open=True` means a proxy or telemetry failure executes the original agent
request unmodified and records a degradation in the receipt.

`fail_open=False` means a pre-execution proxy/session failure raises
`LeanCtxConnectionError` before the agent is invoked.

An agent exception is never swallowed by either setting.

## 8. `core.py`: `LeanCTX`

`LeanCTX` is a lightweight facade, not a task or a global receipt registry.

Construction must:

1. Normalize the supplied config.
2. Build one reusable `ProxyClient` from explicit values or discovery.
3. Keep a `ContextVar[ContextSession | None]` for task-local current session.
4. Keep an in-process, bounded Kit cache keyed by verified `(id, version, hash)`.
5. Perform no provider call, agent call, compression, or session creation.

Construction may validate local config eagerly.

It must not require the proxy to be reachable until an operation needs it.

`LeanCTX.session()` returns a new pending `ContextSession` bound to this facade.

The pending handle has no task event and no Runtime `session_id` yet.

Its identity is allocated only by `_begin(task, kit, profile)` immediately before
`WrappedAgent` invokes the agent.

This laziness reconciles the required zero-argument `ctx.session()` API with the
runtime invariant that no session may be created with an empty root task.

A pending session is not a durable execution session and cannot issue a receipt.

`LeanCTX.wrap(agent, kit=None, profile=None)` validates the selectors and
returns `WrappedAgent`; it must not invoke the agent or contact a provider.

`LeanCTX.load_kit(name)` delegates to `kit.load_kit()` with this facade's proxy,
policy configuration, and cache.

`name` must be a non-empty string or a `ContextKit` instance.

Passing a `ContextKit` returns the same immutable handle after compatibility
validation.

## 9. `profile.py`: `TuningProfile`

`TuningProfile` represents a resolved, pinned operating configuration.

```python
@dataclass(frozen=True)
class TuningProfile:
    id: str
    version: str
    content_hash: str
    source_ref: str
    context_budget: int | None = None
    compression_mode: str | None = None
    recovery_policy: str | None = None
```

All four identity fields are required after resolution.

The SDK must not use a mutable active profile as receipt input.

A string selector such as `"balanced"` is resolved once per run through the
session endpoint, producing a pinned `TuningProfile`.

A selector with `@version` requests that exact version.

An already-resolved `TuningProfile` is sent by `(id, version, content_hash)`.

If the Runtime resolves a different hash, the run fails before agent execution.

`TuningProfile` instances are immutable and hashable.

## 10. `kit.py`: `ContextKit` and `load_kit()`

`ContextKit` is an immutable verified handle, never an implicit prompt string.

```python
@dataclass(frozen=True)
class ContextKit:
    id: str
    version: str
    package_hash: str
    activation_ref: str
    manifest: Mapping[str, object] = field(repr=False, compare=False)
```

The only public module-level helper is:

```python
def load_kit(name, *, proxy, cache, timeout) -> ContextKit: ...
```

`ctx.load_kit(name)` is the supported public entry point.

The helper makes an authenticated `GET /v1/kits/{urlencoded-name}` request.

The Runtime response must contain `id`, `version`, `package_hash`,
`activation_ref`, and a manifest object.

The client validates opaque-ID length, lowercase hexadecimal hash shape, and
that all required fields are non-empty strings before caching the result.

The cache key is `(id, version, package_hash)`.

Mutable aliases such as `latest` are resolved by the Runtime and are never kept
as the cache or receipt identity.

The SDK must not expand manifest text into a provider request.

The Kit identity is sent to the session API and appears in the receipt.

## 11. `session.py`: `ContextSession`

`ContextSession` is the client-side handle for exactly one root task execution.

It is not a process, a provider conversation, workspace memory, or a global
latest-session holder.

Its visible lifecycle is:

```text
pending -> created -> configured -> executing -> receipt_ready -> closed
                         |              |               |
                         +------------> aborted <-------+
```

The session implementation must use a `ContextVar` token when making itself
current and must reset that token in `finally`.

Nested runs require an explicit parent field added in a later API revision.

V1 never silently shares a budget or receipt across nested wrapper calls.

The minimal implementation fields are:

```python
class ContextSession:
    _ctx: LeanCTX
    _phase: str
    _session_id: str | None
    _task_id: str | None
    _run_id: str | None
    _trace_id: str | None
    _task: str | None
    _profile: TuningProfile | None
    _kits: tuple[ContextKit, ...]
    _observations: list[ProxyObservation]
    _degradations: list[str]
    _receipt: ExecutionReceipt | None
```

`_begin(task, kit, profile)` is private to the package.

It rejects a non-string task, an empty or whitespace-only task, and a task
longer than 16 KiB.

It calls `POST /v1/sessions` before the first agent action.

The create payload contains the task label, project identity, agent identity,
requested profile selector, Kit selectors, integration depth `wrap`, and v1
protocol version.

The reply must return session, task, run, and trace IDs plus resolved profile
and Kit pins.

All externally supplied IDs are opaque ASCII values with a 256-character cap.

The client must not construct them from a task or user data.

`_begin` transitions atomically from `pending` to `executing` only after the
create/configuration acknowledgement is validated.

`proxy_headers()` returns the immutable header mapping for the current run.

`record_proxy_response(response)` appends one validated `ProxyObservation`.

`complete(output)` posts the ordered header observations and output digest to
`POST /v1/sessions/{session_id}/complete`, then parses its final receipt.

`abort(error)` posts the same observations and a sanitized error category to
`POST /v1/sessions/{session_id}/abort` when execution began.

Both terminal calls are idempotent by the generated event ID.

If a terminal retry receives the same receipt ID and canonical hash, it returns
the original parsed `ExecutionReceipt`.

`close()` releases only client-local state; it never deletes Runtime evidence.

## 12. Session API deliberately deferred from v1 convenience docs

The Runtime's eventual async API includes `prepare`, `observe`, `complete`,
`receipt`, `checkpoint`, `close`, and `resume`.

The v1 wrapper invokes equivalent private session actions.

It does not expose public async methods because that would conflict with the
required synchronous `WrappedAgent.run(task) -> LeanCtxRun` contract.

The wire protocol and receipt models must nevertheless use the Runtime's
versioned session terms, event order, and error codes.

This keeps a later async facade additive rather than a redesign.

## 13. `proxy.py`: compatibility-preserving transport changes

The following existing behavior must remain unchanged:

- `ProxyClient(base_url=None, token=None, timeout=30.0)` auto-discovers URL and
  token through `discovery.py`.
- `ProxyClient.compress(messages, model=None)` accepts only a list and returns
  `CompressResult`.
- Module function `compress(messages, model=None, *, base_url=None, token=None,
  timeout=30.0)` returns only the rewritten message list.
- `CompressResult` exposes `original_tokens`, `compressed_tokens`,
  `saved_tokens`, and `saved_pct` from `stats`.
- `resolve_reference(reference_id)` keeps URL quoting and its existing errors.
- Authentication remains `Authorization: Bearer <token>` when configured.
- `401` and `403` map to `LeanCtxAuthError`.
- transport failure maps to `LeanCtxConnectionError`.

Add two internal immutable models:

```python
@dataclass(frozen=True)
class ProxyHTTPResponse:
    body: bytes
    headers: Mapping[str, str]
    status: int

@dataclass(frozen=True)
class ProxyObservation:
    request_id: str | None
    execution_receipt_id: str | None
    canonical_hash: str | None
    usage: Mapping[str, int | None]
    coverage: str
    provider: str | None
    model: str | None
    latency_ms: int | None
```

Refactor private `_send()` to return `ProxyHTTPResponse`, preserving current
public result shapes.

Add private `_post_response(path, payload, headers=None)` to expose parsed JSON
and normalized response headers to the session bridge.

Add private `compress_bound(messages, model, session_headers)` for an adapter
that controls its provider-to-proxy path.

`compress_bound` sends exactly the same JSON body as `compress` plus the trusted
session request headers in section 16.

It returns `(CompressResult, ProxyObservation)`.

`compress()` must never add session headers by itself because old callers have
not established a trusted ContextSession.

## 14. Reuse from `discovery.py`

Reuse `discovery.py` unchanged for normal endpoint/token resolution.

The existing precedence is normative:

1. Explicit parameter.
2. `LEAN_CTX_PROXY_URL`, `LEAN_CTX_PROXY_PORT`, or `LEAN_CTX_PROXY_TOKEN`.
3. First `config.toml` / `session_token` in configured data directories.
4. UID-derived loopback port for the URL.

The base URL strips one or more trailing slashes.

The default is `http://127.0.0.1:<uid-derived-port>`.

The UID formula remains base port `4444`, with an offset for Unix UIDs at or
above `1000`; Windows falls back to `4444`.

The code must keep the existing XDG and `LEAN_CTX_DATA_DIR` directory order.

Never log or place the resolved session token in a receipt.

## 15. Reuse from `client.py` and integration modules

`LeanCtxClient` remains a CLI subprocess convenience wrapper.

Its `read`, `search`, `shell`, `gain`, and `benchmark` methods are unchanged.

`LeanCTX` and `ContextSession` must not build their lifecycle by spawning this
CLI for every action.

Use the proxy/session Runtime HTTP surface instead.

Existing LangChain behavior remains:

- Convert messages to OpenAI wire format.
- Compress through the proxy.
- Reattach changed text only with Pydantic `model_copy`.
- Preserve originals if message counts do not match.

Existing LiteLLM behavior remains:

- Rewrite mutable request `messages` in place.
- Pass through unchanged if no messages exist.
- Fail open unless its caller requests `raise_on_error=True`.

Existing LlamaIndex behavior remains:

- Read file-backed document content through `LeanCtxClient.read`.
- Emit a `TextNode` with `compression_mode` metadata.

Those adapters are not automatically transformed into v1 `WrappedAgent`
adapters in this release.

They may later use the common session bridge through a declared capability
matrix, after a supported framework operation and version range are specified.

## 16. Wrap-to-proxy protocol

The wrapper creates a Runtime session before an agent's first action.

The wrapper places its session in the task-local `ContextVar` while the agent
runs.

An agent that sends traffic through the LeanCTX proxy obtains the current
binding by importing the package-private adapter context.

The public, supported agent contract is one of the following:

```python
class ProxyBoundAgent(Protocol):
    def set_leanctx_transport(self, *, proxy, headers) -> object: ...
    def run(self, task) -> object: ...
```

```python
class ContextAwareAgent(Protocol):
    def run(self, task, *, leanctx) -> object: ...
```

`leanctx` in the second protocol is a `RunTransport` containing the bound
`ProxyClient`, immutable session headers, and `record_proxy_response()`.

The `ProxyBoundAgent` adapter calls `set_leanctx_transport` before `run` and
restores the previous transport in `finally` if the method returns a reset
callable.

The `ContextAwareAgent` adapter passes the transport as the explicit keyword.

No hidden monkey-patching of `openai`, `requests`, `httpx`, environment
variables, or arbitrary methods is permitted.

A third `RunOnlyAgent` adapter supports `agent.run(task)` exactly.

It creates a valid Wrap receipt with coverage `not_addressable`, zero proxy
observations, and a recorded degradation `provider_transport_not_bound`.

That adapter is allowed only when `fail_open=True`.

With `fail_open=False`, `ctx.wrap` rejects an agent that cannot bind the proxy.

`ctx.wrap` selects only those three named adapters.

Ambiguity is an explicit `LeanCtxError`; arbitrary reflection is not allowed.

## 17. Request header contract

The proxy bridge uses the exact v1 headers below.

```text
X-LeanCTX-Protocol: 1
X-LeanCTX-Session-Id: <opaque session id>
X-LeanCTX-Agent-Id: <opaque agent id>
X-LeanCTX-Task-Id: <opaque task id>
X-LeanCTX-Trace-Id: <opaque trace id>
X-LeanCTX-Event-Id: <opaque caller-generated event id>
```

Header names are case-insensitive on the wire and lowercased for storage.

Header values must be ASCII opaque IDs, trimmed, non-empty, and at most 256
characters.

The SDK must not put task text, prompts, Kit text, provider keys, or bearer
tokens in those headers.

The proxy accepts these fields for attribution only after authentication marks
the caller trusted.

An arbitrary localhost caller or a provider-key fallback path is unmanaged and
must not write events to a session merely by guessing an ID.

The `Authorization` header is independent from this lineage contract.

## 18. Proxy response header contract

Every bound `/v1/compress` response must include these headers when the proxy
could attribute the request:

```text
X-LeanCTX-Protocol: 1
X-LeanCTX-Request-Id: <opaque request id>
X-LeanCTX-Execution-Receipt-Id: <opaque execution receipt id>
X-LeanCTX-Canonical-Hash: sha256:<64 lowercase hex characters>
X-LeanCTX-Coverage: observed|compressed|context_controlled|full_inline|not_addressable
X-LeanCTX-Input-Tokens: <non-negative decimal>|unknown
X-LeanCTX-Output-Tokens: <non-negative decimal>|unknown
X-LeanCTX-Cached-Tokens: <non-negative decimal>|unknown
X-LeanCTX-Reasoning-Tokens: <non-negative decimal>|unknown
X-LeanCTX-Compression-Original-Tokens: <non-negative decimal>|unknown
X-LeanCTX-Compression-Delivered-Tokens: <non-negative decimal>|unknown
X-LeanCTX-Provider: <bounded provider identifier>|unknown
X-LeanCTX-Model: <bounded model identifier>|unknown
X-LeanCTX-Latency-Ms: <non-negative decimal>|unknown
```

The receipt itself is not serialized into a response header.

Headers identify and summarize an immutable Runtime-side execution receipt.

The SDK uses the ID and canonical hash to retrieve or finalize the full receipt
through the session endpoint.

`unknown` must map to `None`, not to zero.

Invalid known-value syntax is a protocol error; it must not become zero.

Missing headers mean that the particular call is unobserved.

The resulting receipt reports that limited coverage rather than failing an
otherwise successful fail-open agent run.

Response headers may carry request-scoped attribution, but the JSON compression
body must remain byte-stable for identical request bodies and config.

No clock, global counter, mutable receipt state, or header field may alter the
rewritten messages or their `stats` body.

## 19. `wrap.py`: types and operation

`wrap.py` defines the following public data types.

```python
@dataclass(frozen=True)
class LeanCtxRun:
    output: object
    receipt: ExecutionReceipt

class WrappedAgent:
    def run(self, task) -> LeanCtxRun: ...
```

`LeanCtxRun` must not forward unknown attributes to `output`.

This avoids ambiguous behavior when agent output itself has a `receipt` field.

`WrappedAgent` stores:

- The owning `LeanCTX` facade.
- The original agent object.
- The selected named adapter.
- The unresolved Kit selector or `ContextKit`.
- The unresolved profile selector or `TuningProfile`.

The exact `run(task)` algorithm is:

1. Validate `task` before any external call.
2. Create a new pending session with `ctx.session()`.
3. Resolve the Kit once if supplied.
4. Resolve the profile selector once at session creation.
5. Call private `session._begin(task, kit, profile)`.
6. Bind `session` to the facade's task-local context.
7. Construct `RunTransport(proxy, session.proxy_headers(), session)`.
8. Configure the selected agent adapter.
9. Invoke exactly one original agent `run` call.
10. Restore adapter state and reset the task-local context in `finally`.
11. On success, call `session.complete(output)`.
12. Return `LeanCtxRun(output=output, receipt=receipt)`.

If the original agent raises, `WrappedAgent` must first make a best-effort
`session.abort(error)` and then raise the original exception unchanged.

If receipt sealing fails after a successful agent output:

- With `fail_open=True`, return the output with an incomplete receipt whose
  `integrity_status` is `"unsealed"` and `verify()` is `False`.
- With `fail_open=False`, raise the sealing exception and do not fabricate a
  result.

Cancellation and streaming are outside the synchronous `run` v1 contract.

They are deferred to named async adapters, which must preserve chunk ordering,
backpressure, cancellation, and finalization semantics.

## 20. `receipt.py`: data model

`ExecutionReceipt` is a frozen model around Runtime-generated canonical data.

It is not the Rust `ExecutionReceiptV1` rewritten with arbitrary extra fields.

The Runtime returns a versioned session wrapper that may reference one or more
per-route execution receipts.

The Python v1 type flattens the single wrapped run while preserving references.

```python
@dataclass(frozen=True)
class SavingsInfo:
    original_tokens: int | None
    delivered_tokens: int | None
    saved_tokens: int | None
    saved_pct: float | None
    provider_input_tokens: int | None
    provider_cached_tokens: int | None
    provider_output_tokens: int | None
    reasoning_tokens: int | None
    methodology: str
    baseline_ref: str | None
    quality_status: str | None
```

```python
@dataclass(frozen=True)
class ExecutionReceipt:
    schema_version: str
    receipt_id: str | None
    session_id: str | None
    task_id: str | None
    run_id: str | None
    trace_id: str | None
    agent_id: str | None
    project_id: str | None
    profile: TuningProfile | None
    kits: tuple[ContextKit, ...]
    integration_depth: str
    coverage: str
    execution_receipt_ids: tuple[str, ...]
    canonical_hash: str | None
    signature: str | None
    signer_key_id: str | None
    integrity_status: str
    outcome: str
    degradations: tuple[str, ...]
    _savings: SavingsInfo
    _canonical_json: bytes
    _verify_url: str | None = field(repr=False, compare=False)

    @property
    def savings(self) -> SavingsInfo: ...

    def verify(self) -> bool: ...
```

The properties are read-only.

`canonical_hash` must be computed over canonical JSON with sorted keys and
without `signature` or ephemeral transport fields.

The output value is represented only by an optional digest in Runtime evidence.

The receipt must never serialize raw output, prompts, bearer tokens, or raw
provider credentials by default.

`SavingsInfo` differentiates compression savings from provider token facts.

No field may claim "saved" from a header alone as a valid comparative saving.

`methodology` is `"compression_observation"` when it only describes a bound
proxy transform.

It is `"baseline_treatment"` only when a compatible baseline, quality result,
and method reference are all supplied by the Runtime.

## 21. Receipt construction from proxy headers

This is the required receipt path for v1.

1. A bound proxy response yields one `ProxyObservation` from section 18.
2. `ContextSession.record_proxy_response()` validates and stores it in call
   order together with its event ID.
3. `session.complete(output)` sends observations, profile pin, Kit pins,
   integration depth, outcome, degradation list, and output digest to Runtime.
4. Runtime builds compatible per-route `ExecutionReceiptV1` values using its
   existing `ReceiptBuilder`.
5. Runtime seals a `SessionReceiptV1` referencing those values and returns its
   canonical representation, hash, signature metadata, and SavingsInfo.
6. Python parses the final response into an immutable `ExecutionReceipt`.

The Python client must not calculate a provider cost, quality result, or a
baseline/treatment saving comparison from the compression headers.

It may derive `saved_tokens = original - delivered` only for
`compression_observation`, and only when both values are known and ordered.

If a proxy call has no response headers, the session records one observation
with `coverage="not_addressable"` and all usage values `None`.

If an agent binds a proxy but does not report its response to `RunTransport`,
the receipt records `proxy_response_not_observed`.

## 22. Receipt verification

`ExecutionReceipt.verify()` executes this sequence.

1. Reject an unsealed receipt, absent canonical JSON, invalid hash syntax, or
   a canonical SHA-256 mismatch.
2. If `cryptography` is installed and `signature` plus public key material are
   present, verify the Ed25519 signature over canonical JSON locally.
3. Otherwise, if `_verify_url` and `receipt_id` are present, issue authenticated
   `GET /v1/receipts/{id}/verify` through `ProxyClient`.
4. Return `True` only when the Runtime response names the same receipt ID and
   canonical hash and says `verified: true`.
5. Return `False` for 404, authentication failure, protocol mismatch,
   connection failure, invalid JSON, or a false verification response.

The method is a predicate, so expected verification failures do not raise.

Malformed receipt construction is rejected earlier by parsers and raises
`LeanCtxError` rather than producing a permissive object.

The verification endpoint response must be:

```json
{"receipt_id":"...","canonical_hash":"sha256:...","verified":true}
```

The local digest check works without an API key and is what the mock-proxy
tests exercise by default.

## 23. Error behavior

Reuse existing public exception classes:

- `LeanCtxError` for invalid proxy/runtime response or SDK protocol errors.
- `LeanCtxConnectionError` for an unreachable proxy/runtime.
- `LeanCtxAuthError` for `401` or `403`.

Add no generic `Exception` wrappers around original agent failures.

Use `ValueError` for local selector/config/task validation.

Use `LeanCtxError` for a valid local call that violates the negotiated runtime
protocol, missing receipt header syntax, a mismatched profile/Kit pin, or a
missing required Runtime response field.

`fail_open` applies only to LeanCTX infrastructure degradation.

It does not turn malformed caller input, untrusted header values, or a profile
integrity failure into an unobserved successful run.

## 24. Runtime endpoints required for this SDK

V1 requires the following authenticated local Runtime/proxy endpoints.

```text
POST /v1/sessions
POST /v1/sessions/{session_id}/complete
POST /v1/sessions/{session_id}/abort
GET  /v1/sessions/{session_id}/receipt
GET  /v1/receipts/{receipt_id}/verify
GET  /v1/kits/{name}
POST /v1/compress
GET  /v1/references/{id}
```

The last two already exist in the Python proxy client.

`POST /v1/compress` remains compatible with current unbound callers.

The session routes are a separate authenticated side channel.

They must not make the compression response body stateful or non-deterministic.

`POST /v1/sessions` must resolve and return exact profile/Kit hashes.

`complete` and `abort` must accept a caller event ID for at-least-once retry
deduplication.

The routes must reject IDs that are unknown, too long, malformed, or not owned
by the authenticated caller.

## 25. Implementation order

Implement the package in this exact order.

1. Update `pyproject.toml` and `__init__.py` exports/version.
2. Add frozen `TuningProfile` and `ContextKit` models plus parser validation.
3. Refactor `proxy.py` privately to retain response headers without changing
   `compress()` or `CompressResult` behavior.
4. Add session header and `ProxyObservation` parsing tests before wrapper code.
5. Add `ExecutionReceipt` and `SavingsInfo`, canonical JSON parsing, digest
   checks, and verification endpoint behavior.
6. Add pending-to-executing `ContextSession` with create, observation,
   complete, abort, and close paths.
7. Add `LeanCTX` config normalization, session factory, Kit cache, and wrapper
   factory.
8. Add the three named `WrappedAgent` adapters and exception/fail-open paths.
9. Retain and run existing proxy, discovery, LiteLLM, LangChain, and LlamaIndex
   compatibility tests.
10. Only then enable integration documentation and publish v1.0.0.

No package code may fake a session receipt locally before the Runtime returns
the corresponding sealed protocol data.

## 26. Detailed test plan

All tests use a loopback `http.server.HTTPServer` mock proxy.

Tests must not call a provider, use a real API key, depend on the developer's
home directory, or require a running lean-ctx daemon.

The mock server must receive base URL and token explicitly from each test.

### Core tests: `tests/test_core.py`

- `LeanCTX()` uses a default config and performs no network call.
- A mapping config normalizes to `LeanCTXConfig`.
- Unknown config keys fail locally.
- Invalid timeout and integration depth fail locally.
- `ctx.session()` returns a new pending session for every call.
- `ctx.wrap()` does not call the agent during construction.
- `ctx.load_kit()` caches only the exact verified pin.

### Kit tests: `tests/test_kit.py`

- Successful Kit response parses all required identity fields.
- URL escaping prevents slash/path traversal in a Kit name.
- Missing identity fields fail with `LeanCtxError`.
- Invalid hash, mutable manifest identity, and malformed JSON fail closed.
- The same `(id, version, package_hash)` returns the cached immutable handle.
- A changed hash creates a distinct handle rather than silently replacing one.

### Session tests: `tests/test_session.py`

- A pending session sends no create request.
- `_begin` rejects an empty, non-string, and overlong task.
- `_begin` sends task and selectors, then preserves returned opaque IDs.
- Requested and resolved profile/Kit pin mismatches fail before `agent.run`.
- `proxy_headers()` contains exactly the v1 lineage headers.
- Header values never contain task text or configured token.
- Response observations retain `unknown` as `None`.
- Invalid known numeric header values fail the protocol parser.
- Completion sends observations in event order.
- Duplicate completion event ID returns the same receipt instance semantics.
- Abort is attempted after a raised agent exception.
- Session context is reset after success and after exceptions.

### Proxy tests: extend `tests/test_proxy.py`

- Preserve every current `/v1/compress` behavior and exception mapping.
- `compress()` sends no `X-LeanCTX-*` request header for legacy callers.
- `compress_bound()` sends all trusted lineage fields verbatim.
- Bound compression returns `CompressResult` plus parsed observation.
- A response without v1 headers is representable as unobserved.
- Header casing is normalized while values remain unchanged.
- The bound response JSON body is identical to legacy compression output.
- `resolve_reference()` still URL-quotes reference IDs and maps missing IDs.

### Wrapper tests: `tests/test_wrap.py`

- A `RunOnlyAgent` receives exactly its original `task` argument.
- `run.output` is object-identical to the value from the original agent.
- `run.receipt` has `coverage="not_addressable"` for a run-only agent.
- A context-aware agent receives a usable `RunTransport` and records one mock
  proxy observation.
- A proxy-bound agent receives proxy and immutable headers, then its reset hook
  runs even if its `run` method raises.
- `fail_open=True` returns original output with unsealed receipt if completion
  transport fails.
- `fail_open=False` prevents an unbindable agent from running.
- `fail_open=False` raises on a failed pre-run session create.
- Original agent exception type, instance, and message remain unchanged.
- A wrapper creates a new session/run for every call; it never reuses receipts.

### Receipt tests: `tests/test_receipt.py`

- Parse a valid sealed canonical Runtime response.
- `receipt.savings` returns exactly the frozen `SavingsInfo` model.
- Local canonical SHA-256 validation makes `verify()` true without a key.
- Mismatched canonical hash makes `verify()` false.
- Unsealed/incomplete receipt makes `verify()` false.
- Mock verification endpoint true/false values are honored.
- Verification endpoint mismatched receipt ID/hash makes `verify()` false.
- Connection and auth errors during predicate verification return false.
- No raw task, output, prompt, token, or authorization value appears in the
  canonical public receipt JSON fixture.
- `unknown` usage remains null in canonical JSON; it is never converted to zero.

### Existing regression tests

Keep all existing tests and add no real service dependency.

- Discovery precedence and UID port tests remain unchanged.
- Proxy loopback auth, malformed body, stats, connection, and references remain.
- LangChain reattachment type/metadata preservation remains.
- LiteLLM in-place rewrite and fail-open/raise-on-error behavior remains.
- LlamaIndex import guard and node parser behavior remain.

## 27. Mock proxy fixture design

Use one reusable fixture with `HTTPServer(("127.0.0.1", 0), Handler)`.

Run `serve_forever` on a daemon thread and always call `shutdown()` and
`thread.join(timeout=2)` in `finally`.

The fixture state stores:

- `last_request`.
- `requests` in arrival order.
- `sessions` keyed by opaque ID.
- `receipts` keyed by immutable receipt ID.
- `require_token` boolean.
- response behavior toggles for missing headers, invalid header, failed seal,
  verification false, and profile/Kit mismatch.

The handler implements only the v1 endpoints in section 24.

For `/v1/compress`, it must rewrite only string `content` fields, preserve all
other message content, return old-style `messages` and `stats`, and optionally
add the response headers from section 18.

Use a fixed canonical JSON serializer in the fixture.

Use fixed IDs, hashes, and signature placeholders; do not put a timestamp,
counter, or random UUID in expected response bodies.

The test never needs a provider key.

When authorization needs exercising, use a local constant such as
`"test-token"`; assert only header presence/equality and never log it.

## 28. Acceptance criteria

The v1 implementation is complete only when all statements below hold.

- `pip install` of the core SDK adds no runtime dependency beyond Python.
- `from lean_ctx import LeanCTX` works with Python 3.9 through supported Python
  versions.
- All requested public API signatures exist exactly.
- `run.output` is the original agent output, not transformed proxy data.
- `run.receipt` is immutable and exposes `verify()` and `savings`.
- `ctx.wrap` creates a session before the agent starts.
- The proxy only attributes trusted, bounded, authenticated lineage headers.
- Legacy `compress()` traffic remains unbound and byte-stable in body behavior.
- Proxy response headers feed observations; unknown fields are never invented.
- Runtime finalization, not Python guesses, creates final evidence receipts.
- A failed receipt verification is false, never a successful best effort.
- Real-provider and API-key-free tests are both unnecessary for the suite.
- Existing v0.3.0 proxy/discovery/framework integration behavior is preserved.
- `cargo`/Rust Runtime work may implement endpoints independently, but Python
  cannot publish v1 until the protocol header and session endpoint contracts
  are versioned and available.

## 29. Explicit non-goals for v1.0

V1 does not provide:

- A general reflection-based wrapper for arbitrary Python objects.
- Automatic interception of all provider SDK traffic.
- An asynchronous `WrappedAgent.run` surface.
- Streaming receipt finalization.
- A Python implementation of Context Kernel planning or Kit verification.
- Direct mutable access to session events, evidence files, or receipt internals.
- Global latest-receipt lookup.
- Savings claims based solely on a compression estimate.
- A change to the deterministic `/v1/compress` JSON body contract.

These limits preserve the architecture's evidence guarantees while delivering a
small, implementation-ready SDK v1 package.
