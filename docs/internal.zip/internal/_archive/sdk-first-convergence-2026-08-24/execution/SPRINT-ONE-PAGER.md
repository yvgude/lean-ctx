# Thinkery Agent Tuning Sprint

**Verbindlicher Umfang für einen begrenzten Evidenz-Sprint**

## Angebot

| Preis | Dauer | Ergebnis |
| --- | --- | --- |
| CHF 7,500–15,000 | 1–2 Wochen | Nachvollziehbare Entscheidung für Fortsetzung, engeren Versuch oder No-Go |

Der Sprint ist eine Thinkery-Operatorleistung. Provider-Inferenz erfolgt
standardmässig über das Konto des Kunden (BYOK) und ist nicht Teil der Sprint-Gebühr.

## Umfang und Vergleich

- Ein bestehender Produktionsagent und ein repräsentativer, vorab gepinnter Workflow.
- Vor Ausführung wird ein Workload-Manifest freigegeben: Commit oder bereinigte
  Fixture, Aufgabe und Abnahmekriterium, Modell/Parameter/Provider, Cache-Regel,
  Preis-Snapshot, Qualitätsregel, Datenfreigabe und Redaktionsregel.
- Derselbe Agent, dieselbe gepinnte Aufgabe und dieselben Kontrollen in zwei Armen:
  Baseline ohne LeanCTX und Treatment mit `LeanCTX.wrap()`.
- LeanCTX verändert nur den Kontextpfad; der ursprüngliche Agenten-Output bleibt
  als Nachweis erhalten.

## Qualitäts-, Daten- und Stop-Regeln

- **Qualitätsgate:** Beide Arme werden gegen die vorab deklarierten erwarteten
  Findings/Abnahmekriterien geprüft; ein benannter menschlicher Reviewer prüft
  Relevanz, Korrektheit und umsetzbare Begründung.
- **Vergleichsregel:** Ein günstigeres Treatment gilt nur dann als Ergebnis,
  wenn beide Arme das automatisierte Gate und die menschliche Prüfung bestehen.
- **Datenklasse:** Ausschliesslich im Manifest genehmigte Kontextdaten aus einer
  bereinigten Fixture, einem nicht-produktiven Repository oder einem ausdrücklich
  freigegebenen Workload. Standardartefakte enthalten Hashes, Kennungen,
  Zusammenfassungen und redigierte Beschreibungen, keine Rohprompts oder
  vollständigen Quelltexte.
- **Stop-Regel:** Bei automatischem Qualitätsfehler, Budgetüberschreitung,
  fehlender Provider-Nutzung, fehlendem Qualitätsresultat oder nicht freigegebener
  Daten-/Redaktionsgrenze wird der Vergleich gestoppt. Es entsteht kein
  Einsparclaim; Evidenz wird als `unavailable` oder `partial` ausgewiesen.

## Liefergegenstände

- Zwei korrelierte Ausführungs-Receipts und ein Baseline-/Treatment-Vergleich.
- Lokal signiertes Evidenz-Bundle samt Offline-Verifikation und dokumentiertem
  Manipulationsschutz.
- Versioniertes Tuning-Profil mit Kontextpolitik, Konfigurations-Fingerprint und
  ausgewählten/ausgeschlossenen Kontextbeschreibungen.
- Kurzbericht mit Qualitätsstatus, deklarierter Einschränkung und Empfehlung:
  Fortsetzung, engerer Folgeversuch oder No-Go.

## Integrität

Keine synthetischen Kosten-, Cache-, Qualitäts- oder Einsparwerte. Geldwerte
werden ausschliesslich als `provider-reported`, `estimated` oder `unavailable`
gekennzeichnet. Cache-Nutzung wird je Arm erfasst und nicht als LeanCTX-Einsparung
ausgegeben.

## Nicht enthalten

Keine übergreifende KI-/AI-Strategie, keine Framework-Migration, kein dauerhafter
Managed Service, keine unbegrenzte Unterstützung und kein Calibrator-Produkt.

## OSS und Fortsetzung

Die lokale LeanCTX-Runtime, das SDK, der Wrapper, lokale Receipts und die
Offline-Verifikation bleiben frei nutzbar. Dieser Sprint verkauft nicht den
Zugang zu diesen Werkzeugen, sondern deren begrenzte Operator-Lieferung,
Evidenzbericht und Fortsetzungsentscheidung.

50 % der Sprint-Gebühr werden auf einen qualifizierenden jährlichen
Business- oder Enterprise-Vertrag angerechnet, wenn dieser innerhalb von
60 Tagen abgeschlossen wird.

## Zustimmung

Mit der Unterschrift bestätigen die Parteien diesen Umfang, die Daten- und
Stop-Regeln sowie die Evidenzregeln als Grundlage des konkret beauftragten Sprints.

| Für den Kunden | Für Thinkery |
| --- | --- |
| Name/Funktion: ______________________________ | Name/Funktion: ______________________________ |
| Datum: ______________________________________ | Datum: ______________________________________ |
| Unterschrift: _______________________________ | Unterschrift: _______________________________ |
