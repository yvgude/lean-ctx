# Sprint Outreach — 10 Accounts, 5 Discovery Calls

Parent: GitLab #1271 / #1254  
Offer: [SPRINT-ONE-PAGER.md](SPRINT-ONE-PAGER.md)  
Demo harness: `examples/sprint-poc/` (#1270, needs `OPENAI_API_KEY`)

Do not sell Pro CHF 29, Team, Calibrator, or website. Sell the Sprint.

## Who qualifies (all must be true)

From GTM. Skip anyone missing a row.

| Gate | Pass when |
|---|---|
| Existing agent | Production coding agent already running (not a greenfield build) |
| Volume | Recurring tasks (target: 100+/week) or material provider spend |
| Quality bar | They can say what a successful task is today |
| Pin | Representative commit or approved non-prod workload exists |
| Data | Security path agreed before access |
| Buyer | Named person can decide paid continuation |
| Date | Result-review date can be booked |

Persona for customer 1: B2B SaaS, 20–80 people, Python / OpenAI Agents SDK, technical buyer reachable by founder.

## Discovery agenda (30 min)

1. Which agent workflow is already running?
2. How often, and who owns provider spend?
3. What constitutes a successful task today?
4. Can we pin commit, prompt, and test?
5. Which security boundary applies to source and evidence?
6. What would make a measured result commercially useful?
7. Who decides continuation, and by when?

Do not teach generic AI strategy on this call.

## Promise on the call

> Keep your agent, model, provider account, and workflow. LeanCTX changes only the context path, measures the task, and gives you evidence you can verify without trusting our dashboard.

Then: one-pager, 15-min stock vs wrap() if rehearsed, ask for one pinned workflow.

## Sequence

| Week | Action | Target |
|---|---|---|
| Now | Fill the 10 rows below | Named buyer + stack + next date |
| Same week | Personalized invite (workflow/spend, not architecture) | 15 messages |
| Same week | Discovery | 5 calls |
| After demo | Scoped Sprint | One technical-validation session |

## Account tracker (Yves fills — no invented logos)

| # | Company | Buyer | Stack | Volume / spend | Pain | Data constraint | Next action / date |
|---:|---|---|---|---|---|---|---|
| 1 |  |  |  |  |  |  |  |
| 2 |  |  |  |  |  |  |  |
| 3 |  |  |  |  |  |  |  |
| 4 |  |  |  |  |  |  |  |
| 5 |  |  |  |  |  |  |  |
| 6 |  |  |  |  |  |  |  |
| 7 |  |  |  |  |  |  |  |
| 8 |  |  |  |  |  |  |  |
| 9 |  |  |  |  |  |  |  |
| 10 |  |  |  |  |  |  |  |

## Invite (adapt, do not add fake savings)

Subject: Same agent, pinned task, verifiable receipt

We wrap the agent you already run, compare stock vs LeanCTX on one pinned workflow, and leave a receipt you can verify offline. Quality gate first; no savings claim if quality fails. One to two weeks, CHF 7,500–15,000. Local runtime stays free.

## Blocked until

- One-pager sent: #1269 file exists
- Live rehearsal: export `OPENAI_API_KEY`, then `examples/sprint-poc` stock → wrap → compare → verify
