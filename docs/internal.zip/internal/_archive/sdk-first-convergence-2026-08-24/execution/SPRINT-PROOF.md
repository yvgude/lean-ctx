# Sprint Proof — 15-minute paid-pilot harness

**Status:** engineering harness complete; live rehearsal and sales/pilot **ON HOLD** (2026-08-21)  
**Parent:** GitLab #1254 — first paid Agent Tuning Sprint  
**Cash offer:** CHF 7,500–15,000, one agent, one workload, 1–2 weeks  
**Not this track:** website, Calibrator, pair, leaderboard, Pro SaaS

## Why this exists

OSS already has `wrap()`, receipts, and offline verify. The POC design
(`POC-DESIGN.md`) specified a 15-minute run of show. The reference agent,
fixture, deterministic quality evaluator, and `poc.py` harness are in
`examples/sprint-poc/`; the local test suite passes. A live model rehearsal
and customer-facing delivery remain deliberately on hold.

## Subtickets

| ID | Work | Owner | Done when | Status |
|---|---|---|---|---|
| 1254.1 | One-page Sprint scope (workload, quality gate, data class, stop rule) | Yves | PDF/one-pager a buyer can sign | pending |
| 1254.2 | Reference fixture + quality evaluator | Engineering | `examples/sprint-poc/` evaluates findings without inventing cost | **done** (10 offline tests) |
| 1254.3 | `poc.py` doctor / run / compare / verify | Engineering | Stock vs wrap() writes two run dirs + comparison | **done**; comparison re-verifies persisted receipt material and rejects a canonical-payload tamper |
| 1254.4 | Live rehearsal with real model | Yves | Both arms pass quality; receipts verify; no fabricated savings | **ON HOLD** (#1270, operator/key) |
| 1254.5 | Outreach: 10 accounts, 5 discovery calls | Yves | Calendar + same evidence standard as the product | **ON HOLD** (sales) |

## Integrity

- No synthetic cost, cache, or quality result.
- Treatment cheaper **only if** both arms pass the declared gate.
- Label money as `provider-reported`, `estimated`, or `unavailable`.
- Savings claim requires both quality gates and a re-verified persisted receipt; a changed canonical payload fails verification.

## OSS vs paid (do not blur)

| In the harness (OSS) | Sold as Sprint (Thinkery service) |
|---|---|
| Agent, fixture, wrap(), local Receipt, offline verify | Operator time, scoped delivery, report, continuation decision |
| Manual re-run on the customer's machine | Not a Pro subscription, not hosted Dyno |

## Command surface (this repo)

```bash
cd examples/sprint-poc
python poc.py doctor
python poc.py run --arm stock --out ../../.sprint-poc
python poc.py run --arm leanctx --out ../../.sprint-poc
python poc.py compare --out ../../.sprint-poc
python poc.py verify --out ../../.sprint-poc
```

Real `OPENAI_API_KEY` is required for `run`. `doctor` and `quality` tests run without it.
