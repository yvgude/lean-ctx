# Product Architecture

> **Classification:** Superseded target-design reference. Use
> [Canonical Product and Repository Architecture](00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md).

> **Target-design reference, not an active implementation roadmap.** For
> current boundaries use [06](06-ENGINE-SDK-CLOUD-PLAN.md); for implementable
> sequencing use [08](08-COMPLETE-IMPLEMENTATION-ROADMAP.md). Source and tests
> win over this document's future API examples.

> **Status: Target architecture.** This document describes the intended SDK
> contract; it is not an installation guide or an availability claim. The public
> product surface and status labels are governed by the
> [internal README](../README.md) and
> [canonical Product Architecture](PRODUCT-ARCHITECTURE.md): Runtime/CLI/MCP are
> Available; the Python wrapper is Preview; Profiles, Kits, Benchmark, and
> organization-scale surfaces are Research.

## Vision map

This document implements the [North Star](00-NORTH-STAR.md). The commercial boundary is defined in [OSS vs. Paid](02-OSS-VS-PAID.md); the sequencing and customer proof gates are in the [Roadmap](03-ROADMAP.md) and [Go-to-Market](04-GO-TO-MARKET.md).

LeanCTX is a context-control layer placed inside an agent's operating loop. It
turns context work from ad-hoc prompts and tool calls into explicit primitives
that can be measured, tuned, and reused.

## SDK primitives

| Primitive | Responsibility | Durable output |
| --- | --- | --- |
| Context | The task-relevant information available to an agent | A bounded, attributable context set |
| Context selection | Chooses what enters the working set | Selection rationale and limits |
| Transformation | Compresses, structures, summarizes, or recovers context | A representation fit for the task |
| Local memory | Reuses validated knowledge across turns and runs | Recoverable local state |
| Context Kit | Versioned, verifiable context recipe for a job | Kit specification and loader |
| Tuning profile | Explicit operating constraints for an agent | Budget, strategy, thresholds, recovery policy |
| Evidence receipt | Records what happened and whether it met the gate | Signed, inspectable execution evidence |
| Runtime | Executes the lifecycle across tools and providers | A portable local control surface |

The SDK groups these primitives into five developer-facing areas:

1. **Context** — select, read, search, compose, and transform.
2. **Kits** — package reusable context strategies and validate them.
3. **Evidence** — capture cost, quality, savings, and provenance per run.
4. **Integrations** — connect existing agents, providers, and tool surfaces.
5. **Examples** — demonstrate complete agent loops, not isolated features.

## Runtime loop

```text
discover → select → transform → act → evaluate → record → recover
                  ↑                         │
                  └──── tuning profile ─────┘
```

The runtime is local-first and provider-neutral. It coordinates context and
evidence around an existing agent instead of owning the model or application.
It must remain useful without Thinkery or a network connection.

## Integration depths

| Depth | Shape | LeanCTX can control | Best use |
| --- | --- | --- | --- |
| Baseline (control) | Raw agent | Nothing; establishes the comparison | Prove the current cost and quality |
| Attach | Proxy or MCP sidecar around an existing agent | Tool I/O, context delivery, local receipts | Fast adoption and compatibility |
| Wrap | Named adapter around an agent or provider client | Declared lifecycle events, prepared context, and receipts | Evidence-rich integration without owning application control flow |
| Embed | Runtime integrated into the agent lifecycle | Context production, selection, memory, recovery, and profiles | Maximum efficiency and control |

Depth is a product hypothesis to verify, not a slogan. A deeper integration may
provide more control; any efficiency claim requires a comparable baseline,
treatment, and declared quality gate. The Integration Depth
Benchmark compares the same task, model, repository, agent loop, and quality
gate across the three depths. It records provider input, cached and output
tokens, provider cost, tool calls, files/context recovered, latency, completion,
tests, quality score, and human correction.

## Tuning profiles and evidence

A tuning profile makes operating choices explicit—for example context budget,
read strategy, search limits, cache/reuse threshold, compression mode, and
recovery behavior. Profiles are deliberate configurations, not opaque magic.

An evidence receipt binds a run to its task, model, provider, context, kit,
quality result, cost, savings, and signature. This is the bridge from a local
optimization to a trustworthy organizational decision.

## The five public SDK primitives

The product architecture exposes five developer-facing primitives and no more.

```text
LeanCTX()     bind a project to the runtime and default policy
session()     create one task's context lifecycle
wrap()        integrate a supported agent or client through an adapter
load_kit()    resolve verified, version-pinned domain knowledge
receipt()     read the immutable evidence for an execution
```

`prepare`, `retrieve`, `reuse`, `recover`, `use`, and `close` are methods on a
`ContextSession`, not additional top-level primitives.

This preserves a small mental model while allowing the runtime underneath to
remain deep.

| Primitive | Contract | Must not do |
|---|---|---|
| `LeanCTX()` | Validate project, integration, runtime, and policy configuration | Start an agent task or inject a prompt |
| `session()` | Track one agent task’s context lifecycle | Become a reusable global task container |
| `wrap()` | Add lifecycle behavior through a named supported adapter | Reflectively wrap arbitrary objects |
| `load_kit()` | Return an immutable verified knowledge handle | Hide unpinned prompt text in a request |
| `receipt()` | Return canonical evidence for a sealed session | Return an unsafe global “latest” result |

### `LeanCTX()`

```python
ctx = LeanCTX(project=".", integration=Embed(), runtime=None, policy=None)
```

```ts
const ctx = new LeanCTX({ project: ".", integration: embed() });
```

Construction validates PathJail, configuration, selected runtime access, and
`lean-ctx-protocol` compatibility.

It returns a cheap facade that may share a compatible runtime cache and kit
store with other facades for the same project.

| Error code | Meaning |
|---|---|
| `INIT_INVALID_PROJECT` | Root is absent, inaccessible, or outside PathJail |
| `INIT_INVALID_CONFIG` | Policy or integration options conflict |
| `RUNTIME_UNAVAILABLE` | Selected local host or gateway cannot be reached |
| `PROTOCOL_INCOMPATIBLE` | Binding and runtime cannot negotiate protocol |
| `ATTACH_AUTH_REQUIRED` | Attach gateway credentials are missing |

### `session()`

```python
async with ctx.session("Review PR #482", budget="balanced") as session:
    prepared = await session.prepare(prompt)
    result = await agent.run(prepared)
```

The session represents exactly one task.

It records inputs, relevance decisions, context references, budget, provider
and tool observations, recovery proposals, and final outcome.

```text
created
  ├── prepare(input)  → PreparedContext
  ├── retrieve(query) → ranked ContextBundle
  ├── reuse(ref)      → ReuseHit or None
  ├── recover(error)  → bounded RecoveryPlan
  └── close(outcome)  → sealed ExecutionReceipt
```

| Method | Responsibility | Ownership boundary |
|---|---|---|
| `prepare` | Plan and compact host-provided input | Does not send provider traffic |
| `retrieve` | Return ranked context artifacts | Does not silently mutate prompt |
| `reuse` | Rehydrate an eligible stable reference | Does not fabricate a cache hit |
| `recover` | Record a bounded suggested recovery | Does not retry application work |
| `use` | Mount a verified Kit | Does not paste an entire Kit into every call |
| `close` | Seal the task and evidence | Does not reopen a session |

Bindings use task-local propagation: Python `contextvars`, TypeScript
`AsyncLocalStorage`, and Rust task-local storage.

Nested sessions require an explicit parent and inherit policy, not an implicit
shared budget.

| Error code | Meaning |
|---|---|
| `SESSION_INVALID_TASK` / `SESSION_INVALID_BUDGET` | Invalid task label or budget policy |
| `SESSION_CLOSED` / `SESSION_SCOPE_MISMATCH` | Operation after close or outside its scope |
| `BUDGET_EXHAUSTED` | Hard budget would be exceeded |
| `CONTEXT_INPUT_INVALID` | Input is malformed or policy-rejected |
| `CONTEXT_REFERENCE_UNKNOWN` | Reuse reference is absent or ineligible |

### `wrap()`

```python
client = ctx.wrap(OpenAI(), adapter="openai")
response = await client.responses.create(model="gpt-5", input="Review this diff")
```

`wrap()` preserves normal return values and streaming behavior while an
explicit adapter prepares allowed context and observes lifecycle events.

```text
AdapterRegistry.resolve
        ↓
normalize request into ContextInput
        ↓
bind explicit task-local session or labelled implicit session
        ↓
ContextPlanner + PolicyEnforcer
        ↓
native provider/framework call
        ↓
result and stream observer
        ↓
EvidenceLedger canonical events
```

`adapter="auto"` is allowed only when exactly one installed adapter positively
identifies the target type. Ambiguity is an error.

The adapter strips LeanCTX-only options before the underlying call and preserves
response objects, errors, cancellation, backpressure, and chunk ordering.

| Error code | Meaning |
|---|---|
| `ADAPTER_NOT_FOUND` | No exact compatible adapter is installed |
| `ADAPTER_AMBIGUOUS` | More than one adapter matches |
| `ADAPTER_VERSION_UNSUPPORTED` | Upstream version is outside declared support |
| `ADAPTER_OPERATION_UNSUPPORTED` | Requested endpoint is outside contract |
| `WRAP_POLICY_CONFLICT` | Wrapper and session policy conflict |
| `STREAM_FINALIZATION_FAILED` | Result delivered but receipt sealing needs retry |

### `load_kit()`

```python
kit = await ctx.load_kit("payments", version="2026.08")
await session.use(kit)
```

A `KnowledgeKit` is domain knowledge plus its metadata, policy, and integrity
manifest. It is not a hidden prompt template.

```text
KitCatalog → local/cache/approved registry → KitVerifier
          → concrete version pin + manifest digest
          → consolidation into BM25, graph, knowledge, cache
          → immutable KnowledgeKit handle
```

`version=None` resolves once under policy and is immediately pinned.

The mounted name, version, and digest enter the Receipt; retrieval may use the
Kit’s artifacts without forcing all Kit text into every request.

| Error code | Meaning |
|---|---|
| `KIT_NOT_FOUND` / `KIT_VERSION_UNAVAILABLE` | Name or requested version is absent |
| `KIT_INTEGRITY_FAILED` / `KIT_SIGNATURE_INVALID` | Artifact or manifest verification fails |
| `KIT_INCOMPATIBLE` | Project, policy, or protocol mismatch |
| `KIT_PERMISSION_DENIED` / `KIT_OFFLINE_MISS` | Access denied or offline cache unavailable |

### `receipt()`

```python
receipt = await ctx.receipt(session)
assert receipt.outcome == "succeeded"
```

The receipt path is:

```text
EvidenceLedger → receipt assembler → redaction/policy filter
               → canonical protocol serializer → optional signature verifier
```

With no argument, `receipt()` resolves the current task-local session only.

`wait=False` returns only a sealed result. `wait=True` waits for finalization
subject to a runtime deadline.

A receipt includes session/task/outcome identity; integration depth; SDK and
runtime versions; input/output digests; transformations; budgets; usage/cost
and cache facts; Kit/policy digests; provider/tool event summaries; recovery or
degradation; ordered events; and integrity metadata. Secrets are absent by
construction.

## Integration-depth contract

All integration depths use one Context Engine, one kit format, one session-ID
format, and one Receipt schema.

| Depth | Selection | Technical visibility | Boundary |
|---|---|---|---|
| Attach | `LeanCTX(..., integration=Attach(...))` plus Proxy/MCP gateway | Provider requests/responses and tool traffic that transit gateway | No application rewrite; header such as `x-leanctx-session` carries identity |
| Wrap | `ctx.wrap(target, adapter=...)` | Agent run, model call, tool, stream, retry lifecycle exposed by named adapter | Existing calling convention stays intact |
| Embed | `ctx.session(...)` and session methods | Full host-owned context lifecycle | Host sends all provider requests explicitly |

Attach is the minimal-change evidence path.

Wrap is the lifecycle-aware integration path for declared adapters.

Embed is the maximum-control native path; it never silently sends traffic.

## Rust engine underneath every surface

The Rust Context Engine is the reference runtime for CLI, MCP, Proxy, and SDK
bindings.

```text
CLI · MCP · Proxy · Python SDK · TypeScript SDK · Rust SDK
                           │
                    lean-ctx-protocol
                           │
             ┌─────────────▼─────────────┐
             │ Rust Context Runtime       │
             │ SessionCoordinator         │
             │ BudgetController           │
             │ ContextPlanner             │
             │ PolicyEnforcer             │
             └───────┬─────────────┬─────┘
                     │             │
         Consolidation layer    Evidence Ledger
         BM25 · graph ·         receipts · signatures
         knowledge · cache      accounting · retention
```

The engine owns PathJail resolution, protocol negotiation, policy/redaction,
budget control, planning, retrieval, reuse, recovery, consolidation, Kit
verification, cache/index stores, canonical lifecycle events, and Receipt
assembly.

Python and TypeScript bindings may expose idiomatic convenience types, but
they cannot diverge in record names, error codes, Receipt schema, event order,
or context digests.

## One runtime, many surfaces

| Surface | User entry | Shared artifact |
|---|---|---|
| CLI | Local commands for coding-agent workflows | Local profiles, cache, receipts |
| MCP | Context tools inside existing coding agents | Context references, knowledge, receipts |
| Proxy | Sidecar/gateway around traffic | Gateway-backed receipt facts |
| SDK | Native application integration | Sessions, Kits, Receipts |

This prevents product fragmentation: a Kit, policy, profile, and Receipt do
not acquire different semantics because a user began through CLI instead of a
Python application.

## Adapter compatibility rules

Every adapter must identify supported target and operation versions; normalize
messages, tools, and streams without loss; bind an explicit or labelled
implicit session; apply only policy-approved transformation; observe success,
usage, failure, cancellation, and stream close; and emit canonical events.

Initial adapter surfaces are OpenAI SDK, Anthropic SDK, Vercel AI SDK
middleware, LangGraph lifecycle integration, and LiteLLM callback.

The first commercial wedge remains Python plus the OpenAI Agents SDK wrapper.

Any second integration needs repeated paid demand and a declared capability /
version matrix before it ships.

## Architecture guarantees

- LeanCTX never chooses a model, executes a customer tool, or takes over
  application retries/control flow.
- Transformations are observable in Wrap and Attach receipts.
- Policy can retain evidence while prohibiting transformation.
- Degradation to the original request occurs only when policy explicitly
  permits it and is recorded.
- Protocol fields are additive; changing digest, event order, error code, or
  redaction semantics is a breaking change.
- An adapter feature cannot create a sixth public core primitive.

The architecture succeeds when a developer can start shallow, deepen safely,
and retain the same evidence contract all the way through.
