# Historical product-version roadmap

> **Classification:** Historical
>
> **Product-horizon reference, not the active implementation tracker.**
> Version labels, prices and hosted examples here are Research hypotheses unless
> independently promoted. Use [08](08-COMPLETE-IMPLEMENTATION-ROADMAP.md) for
> dependency order and [Master Execution](../execution/MASTER-EXECUTION-PLAN.md)
> for scheduled work.

> **Status:** Historical strategy scenario, not the active delivery plan or a
> current availability statement. The [internal README](../README.md),
> [Engine, SDK & Cloud Plan](06-ENGINE-SDK-CLOUD-PLAN.md), and
> [Context Workspace & `.ctxpkg` Plan](07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md)
> define the current scope, sequence, and promotion gates.
>
> References below to versions, published SDKs, paid pilots, websites, or
> milestone dates are historical planning context and require independent
> evidence before they become a public claim.

## Vision map

This document sequences the [North Star](00-NORTH-STAR.md) and [product architecture](01-PRODUCT-ARCHITECTURE.md). [OSS vs. Paid](02-OSS-VS-PAID.md) defines what remains local and open; [Go-to-Market](04-GO-TO-MARKET.md) turns each proof gate into a customer motion.

The sequence is deliberate: establish the engine, prove deeper integration,
make the work reusable, then operate the loop for organizations.

| Release | Product outcome | LeanCTX delivery | Thinkery trajectory | Exit criterion |
| --- | --- | --- | --- | --- |
| **v1.0 — Context Engine** | A developer can improve a real agent locally | Stable runtime, SDK, proxy/MCP path, context selection and transformation, local memory, receipts | No dependency | One reference agent produces a reproducible local receipt |
| **v2.0 — Native Context** | Context is controlled inside the agent lifecycle | Native SDK integration, Context Kits, tuning profiles, recovery, Integration Depth Benchmark | Evidence format ready for aggregation | Native integration is shown to preserve quality while improving the measured operating envelope |
| **v3.0 — Team Context** | A team can share and govern its agent context work | Open kit/verifier and local benchmark remain complete | Private registry, shared state, central evidence, policy, RBAC, budgets, and fleet view | Teams can approve, distribute, and audit context strategies across agents |
| **v4.0 — Continuous Tuning** | Organizations run a managed optimization loop | Manual profiles and local control remain open | Hosted tuning runs, generated profiles, replay/evaluation, Pareto selection, deployment, monitoring, retuning | Thinkery improves a fleet under explicit quality, policy, cost, and latency constraints |

## Evidence gates

Every release must answer a narrower question than "does LeanCTX save tokens?"

- **v1.0:** Can a real agent recover and use less unnecessary context?
- **v2.0:** Does deeper integration improve the outcome against a comparable baseline?
- **v3.0:** Can a team govern the same work without losing local agency?
- **v4.0:** Can continuous tuning improve production workloads without violating quality or policy?

Cost savings are reported only with the workload, model, provider pricing,
quality criteria, and measurement method that produced them. The roadmap does
not turn a limited benchmark into a universal performance claim.

## Roadmap operating rule

The roadmap is a sequence of proof gates, not a feature inventory.

```text
Runtime → one SDK wedge → matched evidence → repeatable delivery
        → shared operation → governed continuous tuning → fleet scale
```

Each stage earns the next one.

Every release preserves the useful local developer loop and the documented OSS
paths for Codex, Cursor, and Claude Code.

The primary metric is **Verified Cost per Successful Agent Task** (`VCP-SAT`):

```text
VCP-SAT = provider-reported net LLM cost
          ─────────────────────────────────────────
          tasks passing the predeclared quality bar
```

The commercial threshold is at least 40% lower VCP-SAT with no quality
regression. Existing 79–86% results are evidence of potential, not a universal
customer promise.

| Version | Time window | Job | Exit evidence |
|---|---|---|---|
| v1.0 — Prove | Months 0–3 | Add LeanCTX to one existing agent and prove a matched result | Paid pilot, verified bundle, external quickstart success |
| v2.0 — Repeat | Months 3–6 | Make the proof loop easy to repeat for developers and early teams | Pro/Team pull and repeatable delivery |
| v3.0 — Operate | Months 6–12 | Govern continuous tuning for a team | Business adoption, policy, budgets, private assets |
| v4.0 — Scale | Months 12–24 | Operate context performance across enterprise fleets | Renewal, governed deployment, profitable operation |

# v1.0 — Prove the Context SDK

## Objective

Prove that a customer can wrap an existing Python OpenAI Agents SDK workflow,
receive a verifiable Receipt, and decide whether LeanCTX reduces VCP-SAT
without rebuilding the agent.

## First buyer and integration

The first buyer is a Head of Engineering or appointed staff platform engineer
at a 20–80 person B2B SaaS company running 100+ coding-agent tasks per week.

The first integration is `LeanCTX.wrap(agent)` for Python OpenAI Agents SDK.

### V-ZUG ICP feedback

Feedback from V-ZUG validates an enterprise/industrial discovery lane, but does not broaden the v1.0 wedge. Treat it as a founding-design-pilot candidate only when it has a recurring coding-agent workflow, a named sponsor and technical owner, an approved representative workload, a declared quality gate, and a continuation decision date. If it requires a second adapter or bespoke platform work, defer that work until the paid-demand gate for a second integration is met.

No second framework integration is built before this wedge produces customer
evidence.

## Deliverables

- Freeze `EvidenceBundleV1`, receipt signature behavior, redaction policy,
  price-source versioning, and offline verification method.
- Package three redacted evidence scenarios and one customer-readable report.
- Ship a versioned Python wrapper with explicit opt-in evidence mode, typed
  errors, and rollback/uninstall path.
- Publish a 15-minute quickstart with pinned dependencies and deterministic
  baseline/treatment integration test.
- Ship a real Python repair agent with identical plain and LeanCTX arms,
  real model calls, real patching, declared tests, and comparison Receipt.
- Ship workload manifest, secret-blocking preflight, quality scorecard,
  operator runbook, and report template.
- Run two internal pilot rehearsals, including failure/rollback drills.
- Run release smoke tests for Cursor, Codex, and Claude Code.

## Twelve-week path

| Week | Focus | Required result |
|---|---|---|
| 1 | Make evidence customer-grade | Three offline-verifiable bundles, green receipt tests, OSS smoke matrix, 30 named accounts |
| 2 | Ship one installable wedge | 15-minute quickstart, deterministic wrapper test, five discovery calls booked |
| 3 | Make customer runs safe | Two rehearsal bundles, approved redaction/quality template, one scoped candidate |
| 4 | Deliver an end-to-end proof | Customer-specific matched result and independent verifier path |
| 5 | Sell bounded outcome | Ten qualified conversations and one fixed-scope proposal in approval |
| 6 | Collect first revenue | One signed/paid pilot and pinned first workflow |
| 7 | Make delivery repeatable | Pilot-in-a-Box and reproducible manifests/receipts |
| 8 | Convert proof to revenue | Final report, conversion decision date, two new qualified proposals |
| 9 | Expand customers, not surface | Second paid commitment or conversion; pilot-driven SDK hardening only |
| 10 | Decide from revenue evidence | Written adapter decision memo and green OSS compatibility |
| 11 | Audit thesis | Evidence ledger, support hours, renewal/expansion decision |
| 12 | Choose honestly | Reproducible archive and one next-quarter choice |

## Success metrics

1. At least one paying customer pays; target two paid commitments and at least
   CHF 10,000 collected or contracted.
2. One customer-specific signed bundle independently verifies ≥40% VCP-SAT
   reduction with no quality regression.
3. An external developer finishes the quickstart and produces a valid bundle
   without founder intervention in their agent architecture.
4. Codex, Cursor, and Claude Code smoke tests pass with no critical unresolved
   compatibility issue.
5. Support time is below four founder hours per active customer per week after
   onboarding.

## Explicitly park in v1.0

- Marketplace, Agent Builder, hosted agents, and generic control plane.
- Broad dashboards/team accounts/multi-tenant architecture.
- TypeScript redesign and every second framework/provider adapter.
- Persistent-memory product category, auto-routing, and self-serve checkout.
- Fundraising or content work that does not advance a buyer workflow.

If a v1.0 gate fails, preserve OSS, stop platform expansion, document the
learning, and run one narrower redesigned paid-pilot cycle.

## Capability integration sequencing — engineering-first, promotion gated by proof

**Phase A remains the commercial proof loop.** The product owner has authorized
phased internal engineering in parallel: the absence of a paid run does not
block Research implementation. Paid-customer evidence remains mandatory before
an offer is promoted as Available, before customer-derived intelligence is used,
or before organization-scale operation is sold.

| Phase | When | Capability outcome | Required proof before advancing |
| --- | --- | --- | --- |
| **A — Product proof** | Now; v1.0 | Performance Benchmark, Quality Gate, Receipt, Reference Agent, SDK v1, and a commercial proof loop | A declared workload has a reproducible baseline/treatment, quality result, and offline-verifiable Receipt |
| **B — Capability substrate** | Engineering now; Research | Audit OCLA traits, implementors, and call sites; define CapabilityManifest v0 with ID, version, type, I/O, permissions, and telemetry; normalize one Native Capability; link its ID/version from Profile and Receipt; run the Benchmark through that capability path | One existing Native Capability can be selected by a Profile, measured by the Benchmark, and identified in the Receipt |
| **C — Performance dominance** | After B; Research | Expand native capability coverage and prove workload-specific results across a declared benchmark suite; external capability path stays an Enterprise fallback | Multiple reproducible workload comparisons with declared scope, quality, provider, and cost method; no universal performance claim |
| **D — Selection rules** | After C evidence; Research/Preview | Compare a small candidate set, provide a manual recommendation, and allow customer capability registration through the open contract | Recommendations remain manual, evidence-backed, reversible, and never silently change a deployment |
| **E — Commercial intelligence** | Private Thinkery work after D foundations | Learned workload classification, automated candidate ranking, Continuous Optimization, Capability Performance Graph, and organization-wide Profile deployment | Repeated governed workloads, rollback, budgets, policy authority, and a private D/E data boundary justify automation |

The phases constrain the capability path, not the local-first product boundary:
no marketplace, broad adapter matrix, or automatic selection is implied before
its stated proof gate.


## Calibrator and Performance Benchmark milestones (Research — 2026-08-21)

These milestones extend the capability integration sequence above. They map the [Calibration Vision](14-LEANCTX-CALIBRATION-PERFORMANCE-PLATFORM-VISION.md) to the existing phase gates. No milestone advances without its stated prerequisite.

| Step | Phase gate | Deliverable | Prerequisite |
|---|---|---|---|
| Unified BenchmarkSpec | B | `BenchmarkSpecV1` protocol type; consolidate 6 fragmented benchmark engines | Phase A proof |
| PerformanceProfileV1 | B | Profile with `capabilities` + `constraints` fields | `CapabilityManifest v0` (Phase B) |
| Manual Calibration | B | User changes Profile, re-runs Benchmark, compares results | BenchmarkSpec + PerformanceProfile |
| Calibrator v0 | D | Fixed candidate set, Pareto frontier, recommendation | Manual Calibration works end-to-end |
| Agent Connector (1) | D | Programmatic invocation of one agent (Codex or Claude Code) for benchmark | Calibrator v0 |
| Local Runner / Pairing | D–E | `lean-ctx pair` WebSocket to Thinkery, browser shows live progress | Agent Connector works |
| Result page | D–E | Web rendering of Profile, cost, quality, latency, Receipt | Local Runner works |
| Simple verified ranking | E | Table of verified results, Community vs Official distinction | Hosted Verified Runs |
| Automated candidate generation | E | Learned candidate selection from historical evidence | Performance Registry with sufficient data |
| Continuous Optimization | E | Drift detection, re-calibration, governed Profile rollout | Enterprise customer with repeated workloads |

**V1 Anti-scope:** No gamification, social profiles, achievements, badges, or broad community platform. V1 is: Standard Benchmark Suite, Local Runner, one Agent Connector, Performance Profile, Receipt, result URL, and a simple table of verified results.

# v2.0 — Repeat the proof loop

## Objective

Let a developer preserve, schedule, and share a proof using the same runtime,
profile, Kit, and Receipt contract.

## Deliverables

- Launch Pro Tuner at CHF 29/month or CHF 290/year.
- Add hosted Dyno history, private profile sync, five BYOK jobs/month, one
  scheduled benchmark, and explicit retention/deletion controls.
- Add prepaid hosted experiment and AutoTune credits; never hide provider
  inference in these prices.
- Launch no-login Live Demo through the production engine path.
- Launch capped Evidence Lite and BYOK hosted evidence reports.
- Launch shared Receipt history, one workspace dashboard beta, basic roles,
  three private Kits, durable links, and export.
- Maintain Pilot-in-a-Box and sell Agent Tuning Sprints at CHF 7,500–15,000.

## Success metrics

| Metric | Evidence required |
|---|---|
| Pro conversion | First 30 paying users prove that continuity/scheduling drives upgrade |
| Repeat use | Meaningful first-Receipt users run a second Dyno on a private workflow |
| Team activation | At least ten teams activate shared Receipts |
| Upgrade quality | At least two teams upgrade for a real control/scale trigger |
| Delivery economics | Sprint labor remains at or below 45% of realized fee |
| Integrity | Hosted/local reports remain truthful, portable, and verifiable |
| OSS safety | Coding-agent release smoke matrix remains green |

## Explicitly park in v2.0

- Self-serve enterprise purchase flow.
- Generic multi-tenant platform architecture.
- Managed relay unless explicit customer demand earns it.
- Per-token pricing as primary business model.
- Marketplace mechanics and broad adapter matrix.
- Automatic tuning without explicit quality gates.

Advance only when hosted continuity shows repeatable pull and the hosted cost
model is margin-positive.

# v3.0 — Operate context performance

## Objective

Let engineering organizations govern private context assets, shared evidence,
policy, and bounded continuous tuning across an agent fleet.

## Deliverables

- Launch Business at CHF 2,499/month annually for up to 25 managed agents.
- Add cross-team VCP-SAT economics, named budget ownership, policy controls,
  approval workflows, audit logs, and priority support.
- Operate private Kit registry with access control, refresh, manifest pinning,
  integrity verification, and portable export.
- Launch AutoTune experiment queues with workspace budgets, predeclared
  baselines, quality gates, human/policy promotion, profile versioning, and
  rollback.
- Add a second adapter only after an approved shared-framework workload and
  reproducible safety/evidence gate. Paid demand remains commercial validation,
  not an engineering prerequisite.

## Success metrics

| Metric | Evidence required |
|---|---|
| Business adoption | Paying teams use policy/evidence controls, not dashboards alone |
| AutoTune safety | Every proposal has quality gate, budget, profile version, rollback |
| Private Kit demand | Governed assets are repeatedly used with no integrity regression |
| Retention | Expansion follows verified workflows and managed agents |
| Margin | Business stays within 80–84% target gross-margin model |
| Operations | Routine work follows productized runbooks, not founder improvisation |
| Adapter discipline | Every adapter meets the revenue and contract gate |

## Explicitly park in v3.0

- Default agent-execution hosting.
- Generic workflow automation or model-hosting products.
- Agent marketplace and social distribution mechanics.
- Unreviewed autonomous profile deployment.
- Compliance promises unsupported by actual controls.

# v4.0 — Scale the performance operating system

## Objective

Let enterprise teams govern, verify, and continually improve context strategies
across a fleet without losing provider choice, deployment control, or evidence
portability.

## Deliverables

- Launch Enterprise from CHF 10,000/month on annual contract.
- Add SSO, SCIM, delegated administration, contractual retention/evidence
  packs, private registry/connectors, dedicated/self-hosted options, security
  review, SLA, and named support.
- Introduce managed relay only if demanded; retain BYOK/direct provider access
  and disclose pass-through plus infrastructure cost.
- Add fleet policy/profile recommendations based on verified repeated workloads.
- Expose drift, adoption, rollback, and evidence coverage to designated owners.
- Use annual platform minimums for performance terms and price dedicated
  deployment, custom connectors, and implementation separately.

## Success metrics

| Metric | Evidence required |
|---|---|
| Enterprise renewal | Customers renew for evidence, control, and operational value |
| Deployment trust | Identity, retention, and private deployment pass contracted review |
| Fleet outcome | Multiple agents sustain verified VCP-SAT gains with no quality regression |
| Coverage | Material fleet decisions map to Receipts and profile versions |
| Economics | Enterprise direct cost stays within 70–75% target margin model |
| Support | SLA and named-support performance is measured and met |
| Portability | Customers export Receipts, Kits, and profiles according to contract |

## Explicitly park in v4.0

- Becoming a foundation-model vendor.
- Replacing customer agent frameworks with Thinkery orchestration.
- Consumer marketplace unrelated to context deployment.
- Unbounded “AI transformation” consulting.
- Any service that turns local-first OSS into a funnel trap.

## Cross-version gates

Every promotion must pass:

1. Quality: no claim without automated and human quality gates.
2. Evidence: Receipts verify offline with method, cache, pricing, scope, and
   limitations declared.
3. Compatibility: Codex, Cursor, and Claude Code release smoke tests pass.
4. Reversibility: integration and profile rollback do not rebuild the agent.
5. OSS: local runtime, SDK, Dyno, and Receipt remain useful account-free.
6. Revenue: new integrations/features require repeated paid demand.
7. Margin: hosted/support-heavy work has a documented cost model.

The release sequence remains intentionally simple:

> v1 proves one agent. v2 repeats the proof. v3 governs the loop. v4 operates
> it across a fleet.
