# 14 — LeanCTX Calibration & Performance Platform Vision

> **Research architecture.** Calibration, recommendation and platform language
> must remain behind the P2/P9 evidence, open-core and Cloud gates in
> [08](08-COMPLETE-IMPLEMENTATION-ROADMAP.md).
>
> **Classification:** Research / non-authoritative. This document cannot
> override the canonical architecture or promote Calibrator, platform, Cloud,
> Continuous Optimization or Selection Intelligence.

**Status:** Research strategy record  
**Date:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX  

**Public product descriptor:** **The Context SDK for AI Agents.**  
**Category:** **The Context SDK for AI Agents**  
**Primary narrative:** **Give every agent a context system.**  
**Technical thesis:** **The context path determines what an agent sees next.**  
**Proof doctrine:** **Measure. Compare. Verify.**  
**Business North Star:** **Verified cost per successful agent task.**

---

# 1. Executive summary

LeanCTX should evolve from its local Runtime toward a Context SDK with
evidence-gated calibration research for AI agents.

The core insight is simple:

> **AI agent performance is shaped before inference.**

Before a model answers, an agent has already decided what to search, read, retain, repeat, retrieve, compress, reuse and send to the model.

LeanCTX makes that context path explicit, measurable and tunable.

The architecture then goes one step further:

> **LeanCTX does not need to implement every optimization itself.**

LeanCTX should provide:

1. a strong native Runtime,
2. an open Capability layer,
3. Performance Profiles,
4. a Benchmark,
5. a Calibrator,
6. Receipts,
7. a Performance Registry,
8. Continuous Optimization.

Capabilities may come from LeanCTX, the community, customers, third parties, model providers, knowledge systems, memory systems and routers.

The long-term question LeanCTX answers is:

> **Which context-performance configuration produces the best accepted outcome for this workload?**

---

# 2. The product model

```text
CAPABILITIES
     │
     ▼
PERFORMANCE PROFILE
     │
     ▼
BENCHMARK
     │
     ▼
CALIBRATOR
     │
     ▼
RECEIPT
     │
     ▼
PERFORMANCE REGISTRY
     │
     ▼
CONTINUOUS OPTIMIZATION
```

These are not disconnected products. They form one closed performance loop.

---

# 3. Runtime

The Runtime is the local execution engine underneath LeanCTX.

It owns or coordinates:

- context planning,
- structural code understanding,
- selection,
- compression,
- reuse,
- recovery,
- memory,
- Context Kits,
- capability execution,
- local evidence,
- usage and cost measurement.

The Runtime remains valuable without Thinkery Cloud.

Local-first stays a core trust and distribution property.

---

# 4. Capabilities

A **Capability** is a bounded component that can influence agent context performance.

Examples:

```text
Compression Engine
Context Planner
Shell Output Optimizer
Response Optimizer
Retrieval Provider
Knowledge Graph
Memory Provider
Model Router
Evaluation Provider
Outcome Tracker
Policy Provider
Evidence Provider
```

A Capability can be:

- LeanCTX-native,
- community-built,
- customer-built,
- third-party,
- local,
- remote.

The Capability is a component.

LeanCTX is the system that composes, measures and selects components.

---

# 5. LeanCTX Native

Composable architecture does not mean LeanCTX stops building strong native technology.

LeanCTX Native remains the default capability set because it provides:

- zero-dependency value,
- OSS distribution,
- reference implementations,
- fallback behavior,
- low-latency local execution,
- direct technical differentiation.

Examples:

```text
LeanCTX Structural Code Context
LeanCTX Compression
LeanCTX Reuse
LeanCTX Recovery
LeanCTX Project Memory
LeanCTX Evidence
```

Rule:

> **LeanCTX Native is the default capability set, not the only capability set.**

---

# 6. OCLA

OCLA should become the stable open contract for LeanCTX-compatible Capabilities.

OCLA defines:

- capability identity,
- type,
- supported inputs/outputs,
- execution mode,
- lossiness,
- recoverability,
- cache behavior,
- permissions,
- trust properties,
- telemetry.

OCLA should remain open.

The commercial moat is not:

> what a Capability can do.

It is:

> **which Capability or combination should be used for a particular workload.**

---

# 7. Capability examples

## Compression

```text
CompressionProvider
```

Possible implementations:

- LeanCTX native,
- customer compressor,
- third-party compressor.

## Tool / Shell Optimization

```text
ResponseOptimizer
```

Possible implementations:

- LeanCTX native,
- RTK,
- customer-specific optimizer.

## Retrieval

```text
RetrievalProvider
```

Possible implementations:

- code search,
- vector database,
- SQL,
- internal search,
- graph query.

## Knowledge

```text
KnowledgeProvider
```

Possible implementations:

- LeanCTX local knowledge,
- Obsidian-style graph,
- Neo4j,
- enterprise knowledge hub,
- private documentation graph.

## Memory

```text
MemoryProvider
```

## Routing

```text
ModelRouter
```

## Evaluation

```text
EvaluationProvider
```

Possible implementations:

- tests,
- compiler,
- LLM judge,
- human review,
- compliance checks.

---

# 8. Performance Profile

A **Performance Profile** is the versioned configuration used to run an agent workload.

It can contain:

- context budget,
- compression settings,
- reuse threshold,
- search depth,
- recovery policy,
- Capability choices,
- Capability order,
- Knowledge Provider,
- model router,
- quality floor.

Conceptual example:

```yaml
api_version: leanctx/v1
kind: PerformanceProfile

metadata:
  name: codex-rust-monorepo
  version: 7

constraints:
  quality_floor: 0.96
  max_cost_usd: 0.40
  max_latency_ms: 900

context:
  budget_tokens: 48000
  recovery: true

capabilities:
  code_context:
    provider: leanctx
    strategy: structural

  shell_output:
    provider: rtk

  knowledge:
    provider: company-graph

settings:
  reuse_threshold: 0.87
  compression: balanced
```

A Profile is:

> **the deployable configuration of agent context performance.**

---

# 9. Manual calibration

Users should be able to change LeanCTX settings themselves.

Examples:

- context budget,
- compression level,
- reuse threshold,
- search depth,
- recovery,
- read strategy,
- Capability providers,
- Capability order,
- Knowledge Provider,
- routing strategy.

This makes LeanCTX a performance system rather than a black box.

Conceptual UI:

```text
PERFORMANCE PROFILE

Context budget
32k ─────●──────── 128k

Compression
Lossless ───●──── Aggressive

Reuse
Low ─────────●─── High

Recovery
[ ON ]

Search depth
4 ─────●──────── 32

Read strategy
○ Exact
● Structural
○ Adaptive

Shell optimizer
○ LeanCTX
● RTK
```

Then:

> **Run Benchmark**

---

# 10. Performance Benchmark

The Benchmark measures a defined configuration.

It answers:

> **How does this agent + model + Profile perform on this workload?**

It measures:

- provider input tokens,
- cached tokens,
- output tokens,
- calculated cost,
- latency,
- context volume,
- tool calls,
- retries,
- quality,
- task success.

The Benchmark measures. It does not search the configuration space.

---

# 11. Benchmark controls

A credible Benchmark uses:

```text
same workload
same source revision
same model/provider
same quality requirements
same timeout/budget
```

unless one variable is intentionally changed.

Every public result must record methodology and versions.

---

# 12. Calibrator

The **Calibrator** searches for a better Performance Profile.

```text
BENCHMARK
= measure configuration

CALIBRATOR
= search configuration space
```

The Calibrator may test:

- settings,
- Capabilities,
- Capability combinations,
- ordering,
- budgets,
- reuse strategies,
- compression strategies.

---

# 13. Automated calibration

Example candidate set:

```text
01 baseline
02 balanced
03 aggressive
04 reuse-high
05 RTK-shell
06 RTK-shell + reuse-high
07 graph-enabled
...
```

Each candidate is Benchmark tested.

Example result:

```text
PROFILE                    COST     QUALITY   LATENCY

Baseline                   $1.00      96.4      1.00x
LeanCTX Default            $0.49      96.6      0.91x
Aggressive                 $0.31      91.2      0.84x  FAILED
LeanCTX + RTK              $0.38      96.8      0.88x
LeanCTX + Graph            $0.42      98.1      0.93x

RECOMMENDED
LeanCTX + RTK

Cost       -62%
Quality    +0.4
Latency    -12%
```

The winner is not the configuration with the fewest tokens.

The winner is the best accepted performance point.

---

# 14. Optimization objective

```text
minimize:
  verified cost
  + latency penalty
  + operational penalty

subject to:
  quality >= quality floor
  policy == pass
  trust constraints == satisfied
```

Core rule:

> **The goal is not maximum compression. The goal is the best verified configuration for an accepted outcome.**

---

# 15. Receipt

A Receipt proves what happened.

It should include:

```text
Task
Agent
Agent version
Model/provider

Performance Profile
Capability IDs + versions
Context Kit IDs + versions

Provider usage
Calculated cost
Latency
Quality
Outcome

Methodology
Signature
Verification status
```

The Receipt makes performance claims reproducible.

---

# 16. Capability Registry

The Capability Registry answers:

> **What is available?**

Example:

```text
LeanCTX Structural Context
RTK Shell Optimizer
Company Knowledge Graph
```

Initially this is a local execution catalog, not a marketplace.

---

# 17. Performance Registry

The Performance Registry answers:

> **What actually works?**

It stores relationships between:

```text
Workload
+
Agent
+
Model
+
Profile
+
Capabilities
+
Configuration
+
Outcome
```

This is one of the strongest long-term Thinkery assets.

---

# 18. Performance data model

Useful metadata can include:

```text
workload_class
agent_type
agent_version
model/provider
runtime_version

profile_hash
capability_ids
capability_versions

context_budget
compression_strategy
reuse_threshold
recovery
search_depth

repository_size_bucket
language
tool_mix

provider_usage
cost
latency
quality_score
accepted
```

Raw code is not required.

Raw prompts are not required.

Raw tool contents are not required.

---

# 19. Privacy model

Three modes:

| Mode | Raw data | Performance metadata | Thinkery use |
|---|---|---|---|
| Private | Local | Local | None |
| Anonymous contribution | Local | Anonymous/aggregated | Global learning |
| Team/Enterprise | Customer-controlled | Tenant-isolated | Organization-only unless explicitly agreed |

Anonymous telemetry must be opt-in.

Example:

```text
Help improve LeanCTX?

Share anonymous performance telemetry:

✓ Agent type
✓ Model
✓ Profile settings
✓ Capability versions
✓ Token/cost/quality metrics

Never shared:

✗ Source code
✗ Prompts
✗ Tool contents
✗ Secrets
✗ Repository names
```

No hidden telemetry.

---

# 20. Why the data matters

Long-term, Thinkery can learn patterns such as:

```text
Large Rust repository
+
Codex
+
high shell usage
→ RTK shell + LeanCTX structural context
often performs well
```

or:

```text
Architecture task
+
knowledge graph
→ quality improves

Bugfix task
+
same graph
→ unnecessary context
```

This turns historical evidence into better candidate generation.

---

# 21. Candidate generation

Early Calibrator:

```text
brute force
+
rules
+
heuristics
```

Later:

```text
workload fingerprint
+
agent
+
model
+
repo characteristics
+
historical outcomes
        ↓
candidate generator
```

Instead of testing hundreds of combinations, LeanCTX tests the most promising candidates.

This is a strong commercial intelligence layer.

---

# 22. Continuous Optimization

Calibration eventually becomes continuous.

```text
Production workload
      ↓
Performance observation
      ↓
Drift detection
      ↓
Candidate generation
      ↓
Calibration
      ↓
Quality gate
      ↓
Recommended Profile
      ↓
Controlled rollout
      ↓
New evidence
```

This is **Continuous Optimization**.

---

# 23. Drift

A Profile may become stale because:

- models change,
- provider prices change,
- cache behavior changes,
- repositories grow,
- workloads change,
- Capability versions change,
- Knowledge Graphs change.

Continuous Optimization detects when the current Profile is no longer on the best known cost/quality frontier.

---

# 24. Public Benchmark — the “Speedtest for Agents”

A public LeanCTX Benchmark can become the product-led entry point.

The experience:

> **Benchmark your agent.**

Supported targets can include:

- Codex,
- Claude Code,
- Cursor,
- custom agents.

The website should not directly control local software.

A local LeanCTX Runner bridges the browser and agent.

---

# 25. Agent pairing architecture

```text
leanctx.com
     │
     │ pairing
     ▼
Local LeanCTX Runner
     │
     ├── Codex
     ├── Claude Code
     ├── Cursor
     └── Custom Agent
     │
     ▼
Benchmark
     │
     ▼
Receipt
     │
     ▼
leanctx.com
```

The browser never needs direct filesystem access.

---

# 26. Pairing flow

```text
1. User opens:
   leanctx.com/benchmark

2. Website creates pairing code:
   LCTX-A9F2

3. User runs:
   lean-ctx pair LCTX-A9F2

4. LeanCTX detects supported local agents.

5. Website shows available agents.

6. User selects an agent.

7. Thinkery sends signed BenchmarkSpec.

8. Local Runner executes workload.

9. Quality Gate runs.

10. Receipt is produced.

11. Approved metrics are uploaded.

12. Website renders result.
```

The local agent remains locally authenticated.

Thinkery should not require consumer session cookies or agent login credentials.

---

# 27. Benchmark Suite

Benchmark Suites are versioned.

Example:

```text
LeanBench Coding / v1

Task 01
Explore repository

Task 02
Locate regression

Task 03
Fix bug

Task 04
Run tests

Task 05
Explain architecture
```

Each run records:

- suite version,
- workload version,
- source revision.

---

# 28. Public vs private workloads

## Public Benchmark

Standardized public workloads.

Purpose:

- community comparison,
- public leaderboards,
- product discovery.

## Private Benchmark

Company-specific workloads.

Purpose:

- production calibration,
- private Enterprise comparison.

Same engine.

Different trust boundary.

---

# 29. Leaderboard

The public Leaderboard should rank **verified performance**, not vanity metrics.

Do not rank only by tokens.

Preferred primary metric:

> **Lowest verified cost per accepted task under a declared quality floor.**

Example:

```text
LEANBENCH CODING / V1
Quality floor >= 95%

                             COST/TASK   QUALITY   LATENCY

1  Codex + Profile 18          $0.118     96.2%      41s
2  Claude + Profile 7          $0.134     97.1%      48s
3  Cursor + Profile 12         $0.142     96.8%      39s
4  Stock Codex                 $0.391     96.5%      45s
```

---

# 30. Community vs Official results

## Community Run

Executed on user-controlled infrastructure.

Label:

```text
COMMUNITY RUN
```

Useful for experimentation and sharing.

## Official Verified Run

Reproduced under controlled infrastructure or a defined verification protocol.

Label:

```text
OFFICIAL / VERIFIED
```

Only verified results should drive the official ranking.

---

# 31. Profile Leaderboard

Profiles can be ranked.

Example:

```text
BEST PUBLIC PROFILES / CODEX / LARGE MONOREPOS

1. codex-large-monorepo-v14
2. codex-rust-performance-v8
3. codex-low-latency-v11
```

Metrics:

- verified runs,
- median cost improvement,
- quality pass rate,
- latency.

---

# 32. Capability and Stack rankings

Capabilities can eventually have empirical performance pages.

Stacks can also be compared.

Example:

```text
BEST STACKS / CODE REVIEW

LeanCTX Structural + RTK Shell
LeanCTX Structural + Company Graph
LeanCTX Native only
...
```

The goal is evidence, not vendor marketing.

---

# 33. Community Profile iteration

A user can create:

```text
codex-rust-large-v1
```

Another can fork:

```text
codex-rust-large-v2
```

If v2 benchmarks better while preserving quality, it becomes a stronger candidate.

Community experimentation can become distributed performance R&D.

---

# 34. Public and private Profiles

## Public

Shareable and discoverable.

## Private

Visible only to user/team/company.

No requirement to publish proprietary configurations.

---

# 35. Profiles as distribution

Potential future:

```text
LeanCTX Performance Profile
codex-large-monorepo-v14

1,842 verified runs
-43% median cost
98.2% quality pass

Install:
lean-ctx profile install codex-large-monorepo
```

Profiles can become a developer-distribution surface.

---

# 36. Enterprise Benchmark

Companies can run private internal rankings.

Example:

```text
COMPANY AGENT PERFORMANCE

                                        COST/TASK   QUALITY

1  Support Agent / Profile 12             CHF 0.42     98.1
2  Engineering Agent / Profile 9          CHF 0.61     97.4
3  ERP Agent / Profile 4                  CHF 0.73     99.1
4  Existing baseline                      CHF 1.17     98.0
```

This is internal performance engineering.

---

# 37. Enterprise Calibrator

Enterprise can compare:

- LeanCTX Native,
- internal harnesses,
- customer routers,
- internal Knowledge Graphs,
- approved third-party Capabilities.

LeanCTX does not need to replace every internal component.

It finds the best verified configuration.

---

# 38. Composable Capability example

```yaml
capabilities:
  code_context:
    provider: leanctx

  shell_output:
    provider: rtk

  compression:
    provider: third-party

  knowledge:
    provider: company-graph

  router:
    provider: company-router
```

The Calibrator can test alternatives and combinations.

---

# 39. Blind stacking is not the strategy

Multiple optimizers may reduce more tokens but also cause:

- quality loss,
- cache degradation,
- higher latency,
- duplicate work,
- lost recoverability.

Therefore:

> **The right optimization is better than more optimization.**

LeanCTX should compose only when evidence supports it.

---

# 40. Capability interaction constraints

The system eventually needs to understand:

- ordering,
- idempotency,
- lossiness,
- recoverability,
- cache safety,
- latency,
- cost,
- privacy,
- policy.

This is why selection intelligence is a real systems problem.

---

# 41. First interoperability experiment

If RTK collaboration proceeds:

```text
ARM A — Stock
ARM B — RTK
ARM C — LeanCTX
ARM D — LeanCTX + RTK
```

Same:

- workload,
- model/provider,
- quality gate.

Measure:

- cost,
- usage,
- latency,
- quality,
- task success.

If combination wins, composability is validated.

If it loses, blind stacking is disproven and selection becomes more valuable.

Both outcomes are useful.

---

# 42. OSS / Commercial boundary

## OSS

Keep open:

- LeanCTX Runtime,
- SDK,
- OCLA Capability contracts,
- Capability Manifest,
- local Capability Registry,
- local Benchmark,
- manual Calibration,
- Performance Profile format,
- public/community Profiles,
- Context Kit format,
- Receipt format,
- verifier,
- LeanCTX Native Capabilities.

A developer should be able to:

> benchmark and manually calibrate their own agent locally for free.

## Pro

Potential:

- private Profiles,
- cloud Benchmark history,
- hosted verified runs,
- larger suites,
- Profile comparisons,
- automated parameter sweeps,
- scheduled re-Benchmark,
- limited automated Calibration.

## Team

Potential:

- shared Profiles,
- private team leaderboard,
- private Capability Registry,
- internal Benchmark suites,
- central Receipts,
- approved Profiles.

## Enterprise

Potential:

- custom/private workloads,
- private Capabilities,
- internal harness integration,
- centralized policy,
- controlled rollout,
- tenant-isolated Performance Registry,
- Continuous Optimization,
- learned recommendations,
- organization economics,
- self-hosted/VPC operation.

---

# 43. Commercial moat

```text
Workload
 ↓
Capabilities
 ↓
Configurations
 ↓
Benchmarks
 ↓
Quality evidence
 ↓
Performance Registry
 ↓
Better candidate selection
 ↓
Better Profile
 ↓
Production outcome
 ↓
More evidence
```

The compounding asset is:

> **workload × capability × configuration × accepted outcome**

Not raw customer context.

---

# 44. Thinkery's role

Thinkery commercializes:

- calibration intelligence,
- ranking,
- recommendations,
- drift,
- Benchmark infrastructure,
- Performance Registry,
- enterprise policy,
- rollout,
- organizational analytics.

Thinkery does not need to own every optimization implementation.

Brand line:

> **Systems for agent performance.**

---

# 45. LeanCTX's role

LeanCTX remains the developer-facing product.

Category:

> **The Context SDK for AI Agents**

Product descriptor:

> **The Context SDK for AI Agents.**

Narrative:

> **Give every agent a context system.**

---

# 46. Canonical product vocabulary

### Runtime
Executes context-performance logic.

### Capability
Composable performance component.

### Performance Profile
Versioned configuration.

### Benchmark
Measures configuration.

### Calibrator
Searches configuration space.

### Receipt
Proves result.

### Capability Registry
What is available.

### Performance Registry
What actually works.

### Continuous Optimization
Keeps Profiles calibrated.

This vocabulary should remain stable.

---

# 47. Public product flow

```text
Give every agent a context system
        ↓
Benchmark your agent
        ↓
Connect local LeanCTX Runner
        ↓
Run workload
        ↓
See baseline
        ↓
Calibrate
        ↓
Save Performance Profile
        ↓
Share verified result
```

---

# 48. The Speedtest moment

```text
CALIBRATING CODEX

Candidate 04 / 12

Context budget
48k

Reuse
0.87

Shell
RTK

Recovery
ON

Best so far
$0.31 / task
97.2% quality
```

Result:

```text
CALIBRATION COMPLETE

Recommended Profile
codex-rust-v7

Cost
-49.2%

Latency
-13.1%

Quality
maintained

[ Save Profile ]
[ Share Result ]
```

This can become the clearest product demonstration of LeanCTX.

---

# 49. Conceptual CLI

```bash
lean-ctx benchmark
lean-ctx calibrate
lean-ctx profile list
lean-ctx profile use <profile>
lean-ctx capability list
lean-ctx capability add <provider>
lean-ctx pair
```

Final commands must align with existing CLI architecture before implementation.

---

# 50. V1 build sequence

## Step 1 — Benchmark
One real canonical Benchmark with:
- workload,
- agent runner,
- provider usage,
- Quality Gate,
- Receipt.

## Step 2 — Performance Profile
Small `PerformanceProfileV1` for current LeanCTX settings.

## Step 3 — Manual Calibration
User changes Profile and re-runs Benchmark.

## Step 4 — Calibrator v0
Test a fixed small candidate set.

## Step 5 — Local Runner / Pairing
Connect browser UI to local LeanCTX.

## Step 6 — Result page
Show Profile, cost, quality, latency, Receipt.

## Step 7 — Simple verified ranking
A table, not a social network.

## Step 8 — Capability identity
Record Capability provider/version in Profile and Receipt.

## Step 9 — External Capability
One sample provider, then potentially one real partner.

---

# 51. What not to build now

Do not build:

- social profiles,
- badges,
- achievements,
- follower systems,
- large community platform,
- marketplace,
- ten partner integrations,
- full ML optimizer,
- broad Enterprise fleet UI,
- managed agent hosting.

First prove:

> **people want to benchmark and calibrate their agents.**

---

# 52. Product validation questions

1. Will developers run an Agent Benchmark?
2. Will they change settings and run it again?
3. Will they save a Profile?
4. Will they share a result?
5. Will users compare/fork Profiles?
6. Will third parties expose Capabilities?
7. Does Capability composition create measurable improvement?
8. Will companies pay to calibrate private workloads?
9. Will users opt into privacy-preserving performance telemetry?
10. Can historical evidence improve candidate selection?

Each answer determines the next layer.

---

# 53. Public product success metric

Funnel:

```text
Website visit
→ Benchmark started
→ Benchmark completed
→ Calibration started
→ Profile saved
→ Profile used again
→ Result shared
```

Most important activation:

> **First successful calibrated Profile.**

---

# 54. Commercial success metric

Primary:

> **Verified cost per successful agent task.**

Supporting:

- calibrated workloads,
- Profiles deployed,
- retained production savings,
- quality pass rate,
- drift-to-recalibration time,
- expansion to additional agents.

---

# 55. Strategic flywheel

```text
Developers
    ↓
Benchmarks
    ↓
Calibration
    ↓
Profiles
    ↓
Community / private use
    ↓
Receipts
    ↓
Performance Registry
    ↓
Better recommendations
    ↓
Continuous Optimization
    ↓
Better performance
    ↓
More developers / enterprises
```

---

# 56. Final consolidated thesis

> # **LeanCTX is the Context SDK and calibration layer for AI agent performance.**
>
> It gives developers and organizations a way to measure how an agent uses context, change the configuration, test different capabilities and prove which setup delivers the best accepted outcome.
>
> **Capabilities are the parts.**
>
> **Performance Profiles are the configuration.**
>
> **The Benchmark measures performance.**
>
> **The Calibrator searches for a better configuration.**
>
> **Receipts prove the result.**
>
> **The Performance Registry learns from evidence.**
>
> **Continuous Optimization keeps the system calibrated.**
>
> LeanCTX Native provides a powerful default capability set, while an open Capability architecture allows community tools, customer infrastructure and third-party optimizers to participate.
>
> Thinkery commercializes the intelligence that learns which capability and configuration works best for a particular workload under quality, cost, latency and trust constraints.

---

# 57. Final hierarchy

```text
THINKERY
Systems for the context agents need to work.
        │
        ▼
LEANCTX
The Context SDK for AI Agents
        │
        ├── Runtime
        ├── Capabilities
        ├── Performance Profiles
        ├── Benchmark
        ├── Calibrator
        ├── Receipts
        └── Performance Registry
                │
                ▼
       Continuous Optimization
```

---

# 58. Founder directive

The vision is large.

The next implementation must remain small.

The next milestone is **not**:

> Build the Leaderboard.

It is:

> **Run one supported agent against one controlled workload, change one Performance Profile, re-run it, preserve quality, produce a Receipt and correctly recommend which Profile is better.**

When that works:

> connect it to the web.

When that works:

> let another user run it.

When that works:

> let them share a verified result.

When that works:

> add one external Capability.

Only then should the broader Performance Registry and ecosystem accelerate.

---

# 59. Immediate next actions

1. Finalize `PerformanceProfileV1`.
2. Finalize Benchmark workload schema.
3. Integrate Quality Gate into the current real-world evidence path.
4. Finalize `ExecutionReceiptV1`.
5. Build one reference custom coding agent.
6. Implement manual Profile switching.
7. Implement `benchmark profile A vs profile B`.
8. Implement Calibrator v0 with a predefined candidate set.
9. Build Claude Code / Codex / Cursor Runner adapters.
10. Design local Browser Pairing protocol.
11. Build public Benchmark result page.
12. Keep the first public leaderboard as a simple verified table.
13. Keep raw code/content local by default.
14. Define explicit anonymous telemetry opt-in.
15. Extend OCLA Capability identity into Profile and Receipt.
16. Add one sample external Capability.
17. Explore RTK interoperability only after the base path works.
18. Continue selling Agent Tuning Sprints in parallel.

---

# 60. The two sentences that govern the system

> **The goal is not maximum compression. The goal is the best verified configuration for an accepted outcome.**

> **Give every agent a context system.**
