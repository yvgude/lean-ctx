# 13 — LeanCTX Composable Context SDK Vision

> **Research architecture.** It does not authorize partner ecosystems,
> marketplaces, automatic capability selection or a control plane. The active
> Engine path and stop conditions are in
> [06](06-ENGINE-SDK-CLOUD-PLAN.md) and
> [08](08-COMPLETE-IMPLEMENTATION-ROADMAP.md).
>
> **Classification:** Research / non-authoritative. This vision cannot promote
> an ecosystem, marketplace, planner, Selection Intelligence or Cloud surface.

**Status:** Research architecture proposal  
**Date:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX  
**Public product descriptor:** **The Context SDK for AI Agents.**  
**Category:** **The Context SDK for AI Agents**  
**Primary narrative:** **Give every agent a context system.**  
**North-star business metric:** **Verified cost per successful agent task.**

---

# 1. Executive decision

LeanCTX should evolve through a composable **Context SDK** for AI agents.

The key strategic decision is:

> **LeanCTX does not need to be the best implementation of every context
> operation. It needs to make selection, shaping, reuse, recovery, and evidence
> composable inside the agent loop a customer already owns.**

LeanCTX keeps its own powerful native capabilities.

At the same time, the architecture should allow additional capabilities to come from:

- the LeanCTX community,
- customers,
- internal enterprise teams,
- third-party open-source tools,
- commercial optimization vendors,
- model/provider-native features,
- knowledge and memory systems,
- routing engines,
- future context infrastructure.

The long-term value of LeanCTX moves from:

> “We perform every optimization.”

toward:

> **“We determine which context-performance strategy should be used for this workload, prove the outcome and deploy the winning configuration.”**

This is the strategic layer above a compression feature race.

---

# 2. What does not change

This vision does **not** replace the current LeanCTX product strategy.

The public product remains:

> # **LeanCTX — The Context SDK for AI Agents.**

The near-term product loop remains:

```text
CONNECT
   ↓
MEASURE
   ↓
TUNE
   ↓
PROVE
   ↓
DEPLOY
   ↓
REPEAT
```

The immediate priorities remain:

1. Real Performance Benchmark.
2. Quality Gate.
3. Canonical Receipt / Evidence.
4. Reference Custom Agent.
5. Attach vs Embed Integration Depth Benchmark.
6. Performance Profile.
7. Excellent Claude Code / Codex / Cursor integration.
8. Paid Agent Tuning customer.

The composable capability architecture is the **design direction behind these products**, not permission to start ten new integrations immediately.

---

# 3. Why this architecture matters

The Context Performance market is already fragmenting into specialized capabilities.

Different systems may become particularly strong at:

- shell-output reduction,
- code-aware context planning,
- JSON compression,
- provider-cache alignment,
- memory,
- context reuse,
- retrieval,
- knowledge graphs,
- model routing,
- tool-output shaping,
- quality evaluation,
- evidence,
- enterprise policy.

If every company tries to build every feature itself, products converge into large overlapping suites.

That produces a capital and distribution race.

LeanCTX has another strategic option:

> **Make specialized context-performance capabilities interoperable.**

Then a new strong optimizer is not automatically a threat.

It can become potential capability supply.

---

# 4. The central abstraction: Capability

A **Capability** is any bounded component that can improve or influence an agent's context-performance path.

Examples:

```text
Compression Engine
Context Planner
Shell Output Optimizer
Response Optimizer
Retrieval Engine
Memory System
Knowledge Graph
Context Cache
Model Router
Evaluation Engine
Outcome Tracker
Policy Engine
Evidence Provider
Execution Adapter
```

A Capability may be:

- built into LeanCTX,
- installed locally,
- implemented by a customer,
- supplied by a third party,
- available through a local process,
- available through a remote service.

The Capability itself is not the product category.

It is a component within the LeanCTX performance system.

---

# 5. Existing foundation: OCLA

LeanCTX already has an important architectural substrate for this direction: OCLA.

Current strategy documents describe OCLA as an open protocol/capability layer.

The current implementation model is primarily in-process, with wire/API surfaces for external access where needed.

Existing OCLA-related concepts already include capability/provider abstractions such as:

- `CompressionProvider`,
- `ResponseOptimizer`,
- `ModelRouter`,
- `OutcomeTracker`,
- registries and execution/measurement-related traits.

The strategic decision is:

> **OCLA should become the stable open capability contract beneath LeanCTX Context Performance.**

OCLA should define:

- what a capability can do,
- what inputs it accepts,
- what outputs it produces,
- its constraints,
- how it reports evidence,
- how compatibility is declared.

OCLA should **not** encode proprietary workload-selection intelligence.

---

# 6. Architectural separation

The system should deliberately separate two questions.

## Question A — Can this component perform an optimization?

This belongs to the **Capability Plane**.

Open interfaces.

Examples:

```text
Can compress JSON.
Can optimize shell output.
Can retrieve graph context.
Can route to a model.
Can summarize tool output.
Can provide project memory.
```

## Question B — Should this capability be used for this workload?

This belongs to the **Performance Planner / Selection Intelligence**.

Examples:

```text
Use LeanCTX native for shell output.
Do not use compression for this exact policy clause.
Use LeanCTX structural code planning first.
Use provider-native cache for old history.
Use customer Knowledge Graph for architectural facts.
Do not stack optimizer B after optimizer A if quality regresses.
```

This second question is the higher-value commercial decision layer.

---

# 7. Target architecture

```text
                            TASK
                             │
                             ▼
                    ┌─────────────────┐
                    │ Task Envelope   │
                    │ goal            │
                    │ constraints     │
                    │ quality floor   │
                    │ cost budget     │
                    │ trust policy    │
                    └────────┬────────┘
                             │
                             ▼
                ┌────────────────────────┐
                │ LEANCTX PERFORMANCE    │
                │ PLANNER / RUNTIME      │
                └───────────┬────────────┘
                            │
                  discover / select
                            │
          ┌─────────────────┼─────────────────┐
          │                 │                 │
          ▼                 ▼                 ▼
     NATIVE LEANCTX      COMMUNITY        THIRD PARTY
      CAPABILITIES       CAPABILITIES      CAPABILITIES
          │                 │                 │
          │             custom plugin      enterprise tool
          │             customer engine    provider-native
          │
          └─────────────────┼─────────────────┘
                            │
                            ▼
                   PERFORMANCE PIPELINE
                            │
                            ▼
                    CONTEXT ENVELOPE
                            │
                            ▼
                          AGENT
                            │
                            ▼
                    MODEL / TOOLS
                            │
                            ▼
                         OUTCOME
                            │
                            ▼
                         RECEIPT
                            │
                            ▼
                  PERFORMANCE BENCHMARK
                            │
                            ▼
                    PERFORMANCE PROFILE
                            │
                            └───────────────┐
                                            ▼
                                      next execution
```

---

# 8. LeanCTX native capabilities remain first-class

Composable architecture does **not** mean LeanCTX stops building its own technology.

LeanCTX native capability remains strategically important because:

- it provides a strong zero-dependency default,
- it is the OSS adoption wedge,
- it provides reference implementations,
- it creates immediate value without third parties,
- it lets the project dogfood its own capability contracts,
- it provides fallback behavior,
- it gives Thinkery direct technical differentiation.

Examples of LeanCTX-native strengths can include:

```text
structure-aware code context
tree / outline / targeted read
context selection
compression
reuse
recovery
project memory
cross-agent context reuse
context packages / Kits
local evidence
cost measurement
```

The rule becomes:

> **LeanCTX Native is the default capability set, not the only capability set.**

---

# 9. Capability categories

The following taxonomy is proposed for the target architecture.

Some categories map to existing OCLA concepts.

Others are proposed extensions and should not be treated as current shipped interfaces.

## 9.1 Context Planning

Purpose:

> Decide what information should become active context.

Potential interface:

```text
ContextPlanner
```

Inputs:

- task,
- candidate sources,
- context budget,
- current session state,
- Profile,
- policy.

Outputs:

- selected sources,
- representation/fidelity,
- recovery strategy,
- estimated context cost.

LeanCTX should likely retain a strong native planner.

## 9.2 Compression

Existing conceptual interface:

```text
CompressionProvider
```

Examples:
- code compression,
- JSON compression,
- prose compression,
- log compression,
- tool output compression.

Possible providers:
- LeanCTX native,
- third-party optimizer,
- customer-specific compressor.

## 9.3 Response / Tool Output Optimization

Existing conceptual interface:

```text
ResponseOptimizer
```

Examples:
- shell output,
- MCP response,
- test logs,
- compiler output,
- database results,
- API responses.

## 9.4 Retrieval

Proposed interface:

```text
RetrievalProvider
```

Purpose:
> Retrieve candidate information for the task.

Examples:
- filesystem/code search,
- vector database,
- SQL,
- internal search,
- graph query,
- REST connector.

LeanCTX should treat retrieval as candidate supply, not automatically active context.

## 9.5 Knowledge / Graph

Proposed interface:

```text
KnowledgeProvider
```

Examples:
- LeanCTX local knowledge,
- Obsidian-style knowledge graph,
- enterprise Knowledge Hub,
- customer graph,
- vector-backed knowledge,
- systems of record.

Important metadata:
- provenance,
- authority,
- validity,
- freshness,
- classification.

## 9.6 Memory

Proposed interface:

```text
MemoryProvider
```

Memory remains subject to:
- selection,
- freshness,
- policy,
- provenance.

## 9.7 Model Routing

Existing conceptual interface:

```text
ModelRouter
```

Inputs may include:
- task class,
- context size,
- quality floor,
- cost limit,
- latency,
- policy,
- historical outcome evidence.

The interface can be open.

Learned workload-specific selection can remain commercial.

## 9.8 Evaluation

Proposed/generalized interface:

```text
EvaluationProvider
```

Examples:
- tests,
- compiler/build,
- human review,
- LLM judge,
- factual verification,
- compliance checks.

No optimization should be promoted solely because it reduces tokens.

## 9.9 Outcome Tracking

Existing conceptual interface:

```text
OutcomeTracker
```

The outcome closes the optimization loop.

## 9.10 Policy / Trust

Potential interface:

```text
PolicyDecisionProvider
```

Examples:
- data residency,
- model allowlist,
- agent permissions,
- PII policy,
- no-lossy-transform policy.

Trust constrains performance decisions.

## 9.11 Evidence

Proposed interface:

```text
EvidenceProvider
```

Canonical Receipt formats remain LeanCTX/open contracts.

## 9.12 Execution — later

Potential interface:

```text
ExecutionProvider
```

Implementations:
- local process,
- customer Kubernetes,
- external framework,
- Thinkery-managed runtime.

LeanCTX should not become a generic Agent Builder.

---

# 10. Capability Manifest

Every capability should eventually declare machine-readable metadata.

Conceptual schema:

```yaml
api_version: ocla/v1
kind: Capability

metadata:
  id: com.example.shell-optimizer
  name: Example Shell Optimizer
  version: 1.2.0
  publisher: example
  license: Apache-2.0

capability:
  type: response_optimizer
  operations:
    - shell_output

inputs:
  content_types:
    - text/x-shell-output
  max_bytes: 10000000

properties:
  lossy: false
  recoverable: false
  deterministic: true
  cache_safe: true
  streaming: false

execution:
  mode:
    - in_process
    - local_process
  network_required: false

performance:
  expected_latency_ms: 10
  resource_class: low

trust:
  sends_raw_content_remote: false
  supported_classifications:
    - public
    - internal

evidence:
  emits_metrics: true
  supports_receipt_linkage: true
```

This exact schema is proposed, not frozen.

The principle is:

> LeanCTX must understand the operational characteristics of a capability before selecting it.

---

# 11. Capability properties that matter

The planner cannot choose intelligently based only on capability name.

Important properties:

### Semantics
- content types,
- task classes,
- supported operations.

### Fidelity
- lossless,
- lossy,
- structural,
- summarizing.

### Recoverability
- original recoverable?,
- reference retention?,
- expiry?

### Cache behavior
- preserves provider prefix cache?,
- modifies stable turns?,
- deterministic?

### Cost
- execution cost,
- external inference cost,
- licensing/usage cost.

### Latency
- expected and measured latency.

### Privacy
- local/remote,
- raw content leaves environment?,
- region,
- classification support.

### Quality history
- measured success by workload class.

### Compatibility
- Runtime,
- OS/architecture,
- language,
- dependencies.

---

# 12. Capability execution modes

## In-process

Best for:
- LeanCTX built-ins,
- trusted Rust implementations,
- maximum performance.

Risks:
- crash isolation,
- supply-chain trust,
- API coupling.

## Local process

Communication:
- stdio,
- local socket,
- loopback HTTP.

Advantages:
- language independence,
- process isolation,
- easier third-party development.

This may become the most practical community model.

## MCP / tool-mediated

Useful where capabilities already exist as MCP tools.

Do not overload MCP where a narrower capability contract is cleaner.

## Remote service

For:
- hosted optimizer,
- enterprise Knowledge Graph,
- remote evaluator.

Requires explicit:
- trust boundary,
- data classification,
- timeout,
- fallback,
- cost accounting.

---

# 13. Capability Registry

LeanCTX needs a registry of available capabilities.

This is initially an execution catalog, **not a marketplace**.

## Local Registry — OSS

Stores:
- capability id,
- version,
- manifest,
- execution adapter,
- trust metadata,
- enabled state.

Conceptual CLI:

```bash
lean-ctx capability list
lean-ctx capability info <id>
lean-ctx capability enable <id>
lean-ctx capability disable <id>
lean-ctx capability doctor <id>
```

## Enterprise Registry — commercial

Adds:
- organization allowlist,
- publisher trust,
- version pinning,
- rollout policy,
- private capabilities,
- approvals,
- audit,
- signed manifests.

## Marketplace — later only

Only after:
- real third-party supply,
- stable contracts,
- clear security model,
- repeated installation demand,
- licensing/moderation readiness.

---

# 14. Community-defined capabilities

The community should be able to build capabilities without modifying LeanCTX core.

```text
Community developer
     ↓
implements OCLA capability
     ↓
provides manifest
     ↓
local install
     ↓
LeanCTX Benchmark
     ↓
Performance Profile
```

Potential community capabilities:

- language-specific compressor,
- Terraform plan optimizer,
- Kubernetes log optimizer,
- database result optimizer,
- documentation knowledge provider,
- domain-specific evaluator.

---

# 15. Customer-defined capabilities

Enterprise customers should be able to bring internal systems into LeanCTX.

Examples:

- internal context harness,
- proprietary code index,
- internal Knowledge Graph,
- company-specific compression engine,
- approved model router,
- security policy engine,
- domain evaluator.

Strategic promise:

> **Bring your context infrastructure. LeanCTX can benchmark and operate it as part of the same performance system.**

This lowers replacement friction.

---

# 16. Competitors as capabilities

Long term, today's competitors may be:
- competitors,
- ~~partners,~~ (cancelled)
- capability providers,

at the same time.

Possible future roles:

```text
~~RTK~~ (cancelled — monopoly strategy)
→ specialized shell/tool optimization

Headroom
→ specialized compression

Caveman
→ specialized optimization/evaluation

Provider-native compaction
→ provider capability
```

This document does **not** claim any vendor has agreed to integrate or that technical/legal compatibility exists today.

The architecture should make such integration possible when commercially and technically appropriate.

---

# 17. Blind stacking is not the product

> **More optimization is not automatically better optimization.**

Blind stacking may produce:
- more token reduction,
- worse quality,
- worse cache reuse,
- higher latency,
- duplicated work,
- lost recoverability,
- incompatible transformations.

Therefore LeanCTX should not become "stack everything."

LeanCTX should become a **measured selection and composition system**.


# 18. Composition model

Some capabilities can be safely composed.

A proposed `PerformancePipeline` describes the ordered execution.

Example:

```yaml
pipeline:
  - capability: leanctx.code-context
    operation: structural_plan

  - capability: company.architecture-graph
    operation: retrieve

  - capability: rtk.shell-output
    operation: optimize

  - capability: leanctx.evidence
    operation: record
```

The order matters.

The Profile must record exact versions.

---

# 19. Composition constraints

The planner must consider interaction constraints.

### Ordering
A structural code planner may need to run before compression.

### Idempotency
Running the same optimizer twice may be harmful.

### Fidelity
A lossy transform may block a downstream exact parser.

### Recoverability
A downstream capability may require exact original references.

### Cache safety
A transform may destroy provider cache reuse.

### Trust
A remote capability may be forbidden for sensitive data.

### Latency
A chain may exceed task SLO.

### Cost
The optimization itself may cost more than it saves.

This is why capability composition becomes a real systems problem.

---

# 20. Performance Profile evolves

The current Performance Profile idea becomes more powerful.

It should eventually describe not just LeanCTX parameters, but the selected capability composition.

Conceptual example:

```yaml
api_version: leanctx/v1
kind: PerformanceProfile

metadata:
  name: payments-code-review
  version: 7

constraints:
  quality_floor: 0.98
  max_cost_usd: 0.40
  max_latency_ms: 800

context:
  budget_tokens: 48000
  recovery: enabled

capabilities:
  - id: leanctx.code-context
    version: 1.8.0
    config:
      strategy: outline-first

  - id: company.architecture-graph
    version: 3.1.0
    config:
      top_k: 8

  - id: rtk.shell-output
    version: 2.0.0

kits:
  - payments-security@2.1

quality:
  evaluator: payments-review-v3
```

This turns a Profile into:

> **the versioned performance configuration for an agent workload.**

---

# 21. Performance Benchmark becomes a capability laboratory

The LeanCTX Performance Benchmark becomes the empirical foundation of capability selection.

A Benchmark can compare:

```text
Stock
LeanCTX Native
Third-party A
Third-party B
LeanCTX + A
LeanCTX + customer Knowledge Graph
Profile v4
Profile v5
```

Always under controlled:

- workload,
- model/provider,
- source revision,
- quality floor,
- budget,
- time window.

---

# 22. Quality-gated optimization

The system must never optimize primarily for context reduction.

The core objective is:

```text
minimize:
  verified cost
  + latency penalty
  + operational penalty

subject to:
  accepted outcome >= quality floor
  policy == pass
  trust constraints satisfied
```

A 95% compression result that drops quality below threshold is not a winning Profile.

---

# 23. Capability Performance History

Over time, LeanCTX can record performance evidence by capability.

Conceptual data:

```text
workload class
agent type
model/provider
capability
capability version
configuration
pipeline position
input characteristics
cost
latency
quality
recovery
accepted outcome
```

This forms a **Capability Performance Graph**.

The graph becomes increasingly valuable as real workloads are observed.

Raw customer content does not need to be centralized for this to be useful.

---

# 24. The proprietary selection intelligence

This is a primary long-term Thinkery moat.

The open ecosystem can know:

> what capabilities exist and what they claim to do.

Thinkery's commercial intelligence can learn:

> **which capability or combination actually works best for a workload under real constraints.**

This can include:

- workload classification,
- candidate generation,
- capability ranking,
- pipeline ranking,
- Profile recommendation,
- outcome prediction,
- confidence,
- drift detection,
- counterfactual comparison.

This should live in the proprietary commercial layer where it compounds.

---

# 25. Continuous Optimization

The future commercial product should be described externally as **Continuous Optimization** rather than an overly playful AutoTune brand.

The system:

```text
Production workload
      ↓
observed performance
      ↓
drift / opportunity detection
      ↓
candidate Profile generation
      ↓
Performance Benchmark
      ↓
quality gate
      ↓
approved winner
      ↓
controlled rollout
      ↓
new evidence
```

Initial versions require human approval.

Do not autonomously modify production agents without explicit guardrails.

---

# 26. Customer-developed routers

A customer may already have its own model router.

LeanCTX should allow:

```text
CustomerModelRouter
```

to register through the open contract.

LeanCTX can then Benchmark:

- customer router,
- native LeanCTX reference router,
- provider-native routing,
- other approved routers.

The goal is not to force replacement.

It is to make routing part of the same measurable performance system.

---

# 27. Customer-developed compression engines

A company should be able to implement:

```text
CompressionProvider
```

for a specific internal format.

Examples:

```text
SAP event log compressor
industrial telemetry compressor
internal DSL compressor
customer-support transcript compressor
```

LeanCTX can:

- discover it,
- validate its manifest,
- run it,
- measure latency,
- record result,
- compare quality,
- include version in Receipt.

This allows domain specialization without bloating LeanCTX core.

---

# 28. Knowledge Graph integration

Knowledge systems should become capability providers, not hard-coded dependencies.

Potential sources:

- LeanCTX local knowledge,
- Obsidian-style graph,
- Neo4j,
- enterprise Knowledge Hub,
- vector store,
- customer knowledge service,
- internal documentation graph.

A `KnowledgeProvider` should expose candidates with metadata such as:

- source,
- authority,
- timestamp,
- validity,
- classification,
- provenance,
- confidence.

LeanCTX still decides what becomes active context.

---

# 29. Obsidian-style example

Conceptual flow:

```text
Agent task
  "Why does service X retry twice?"
        │
        ▼
LeanCTX Planner
        │
        ├── source code search
        ├── project memory
        └── Obsidian KnowledgeProvider
                 │
                 ▼
          Architecture Decision
          ADR-029 / retries
                 │
                 ▼
LeanCTX selects:
- exact current implementation
- verified ADR summary
- current test failure
                 │
                 ▼
Context Envelope
```

The Knowledge Graph supplies candidates.

LeanCTX owns task-specific context selection.

---

# 30. Third-party capability trust

An open capability ecosystem creates supply-chain risk.

Therefore each capability should eventually support:

- signed package/manifest,
- publisher identity,
- license,
- version,
- requested permissions,
- network behavior,
- supported classifications,
- integrity hash.

Enterprise environments can enforce:

```text
Only organization-approved publishers.
Only pinned versions.
No remote raw-context transmission.
No lossy transforms for protected sources.
```

---

# 31. Capability permission model

Proposed permission classes:

```text
context:read
context:transform
context:recover
filesystem:read
filesystem:write
network:outbound
model:call
tool:execute
memory:read
memory:write
evidence:append
```

Least privilege.

Capabilities must not inherit all Runtime privileges automatically.

---

# 32. Failure and fallback

Every capability must fail predictably.

Possible policy:

```text
FAIL_OPEN
FAIL_CLOSED
FALLBACK_NATIVE
SKIP_CAPABILITY
ABORT_TASK
```

Selected by workload/policy.

Examples:

- optional compression may fall back native,
- compliance redaction must fail closed,
- evidence-signing failure may block a "verified" claim,
- knowledge-provider outage may continue without that source.

---

# 33. Capability observability

Every capability invocation should emit structured performance telemetry:

- capability id/version,
- operation,
- input size,
- output size,
- duration,
- status,
- estimated/actual cost,
- recoverability,
- errors,
- quality relationship where known.

This feeds both:

- Receipt,
- Performance Benchmark.

---

# 34. Receipt evolution

The canonical Execution Receipt should eventually record:

```text
Task
Agent
Model/provider

Performance Profile
Capability Pipeline
  capability A / version
  capability B / version
  capability C / version

Context delivered
Provider usage
Cost
Latency
Quality
Outcome
Policy decisions
Verification
```

This makes optimization reproducible.

---

# 35. Task remains canonical unit

The architecture must continue to optimize a **task**, not merely an API request.

One task may include:

- multiple tool calls,
- multiple context transforms,
- multiple model calls,
- retries,
- routing,
- recovery.

The value question is:

> **What did it cost to produce the accepted outcome?**

Not:

> How cheap was this individual request?

---

# 36. Performance Planner vs Agent Orchestrator

This boundary is critical.

LeanCTX should orchestrate:

> **context-performance decisions and capabilities**

It should not automatically become the system orchestrating:

- business workflows,
- every agent process,
- CRM operations,
- human work queues,
- browser workflows.

The Planner can say:

```text
Use capability X.
Use context Y.
Apply Profile Z.
Use model B.
```

It does not need to own the customer's complete business process.

---

# 37. Product language

Public now:

> **LeanCTX — The Context SDK for AI Agents.**

Category:

> **The Context SDK for AI Agents**

Primary narrative:

> **Give every agent a context system.**

Technical thesis:

> **The context path determines what an agent sees next.**

Do not publicly lead today with:

> "Universal optimizer orchestration platform."

The composable Capability Layer is the architecture underneath the focused product.

---

# 38. Developer experience vision

A developer should eventually be able to use LeanCTX without understanding every capability.

Simple:

```python
ctx = LeanCTX(project=".")
agent = ctx.wrap(agent)
```

Advanced:

```python
ctx = LeanCTX(
    profile="payments-review@7"
)
```

Expert:

```python
ctx.capabilities.register(
    MyCompanyKnowledgeProvider(...)
)
```

This creates progressive disclosure.

Simple usage stays simple.

Advanced extensibility exists when needed.

---

# 39. Community developer experience

Possible future SDK:

```rust
impl CompressionProvider for MyCompressor {
    fn capabilities(&self) -> CapabilityManifest {
        ...
    }

    fn compress(&self, request: CompressionRequest)
        -> Result<CompressionResult> {
        ...
    }
}
```

Or language-neutral local provider:

```text
lean-ctx capability install ./my-provider
```

The exact API is future work.

The architectural requirement is:

> Third parties should not need to fork LeanCTX to add specialized capability.

---

# 40. Performance Profile UX

For ordinary users:

```text
Profile
balanced-code-review-v7

Status
VERIFIED

Expected behavior
- structural code context
- shell output optimization
- architecture graph retrieval

Quality floor
98%

Last benchmark
2026-08-20
```

Do not expose plugin complexity unless the user asks.

---

# 41. Enterprise configuration UX

Enterprise admins can control:

### Allowed Capabilities

```text
✓ LeanCTX Native
✓ Internal Architecture Graph
✓ Approved Shell Optimizer
✗ Remote External Compressor
```

### Policies

```text
PII workloads:
local capabilities only

Source code:
no unapproved remote processing

Critical tasks:
lossy compression disabled
```

### Profile rollout

```text
Development
→ Staging
→ 10% Canary
→ Production
```

---

# 42. Open-source strategy

The composable ecosystem strengthens the case for open contracts.

Keep open:

- OCLA capability contracts,
- manifests,
- local Capability Registry,
- capability SDK/reference implementations,
- conformance suite,
- Performance Profile format,
- Context Kit format,
- Task/Context/Receipt schemas,
- verifier,
- local Runtime,
- LeanCTX native capabilities.

Why:

> A capability ecosystem only works if participants can implement against stable open interfaces.

---

# 43. Commercial strategy

Thinkery monetizes the intelligence and operations that compound.

Commercial:

- hosted Benchmark at scale,
- Continuous Optimization,
- candidate generation,
- workload-specific ranking,
- Capability Performance Graph,
- private organization Registry,
- enterprise approvals,
- centralized policy,
- organization performance analytics,
- Profile rollout,
- fleet-level optimization,
- managed infrastructure,
- support/SLA.

---

# 44. Commercial moat

The strongest proprietary loop becomes:

```text
Workload
 ↓
Capability candidates
 ↓
Benchmark
 ↓
Quality evidence
 ↓
Performance ranking
 ↓
Profile
 ↓
Production outcome
 ↓
Performance Graph
 ↓
better next decision
```

This compounds.

The open ecosystem increases available capability supply.

Thinkery monetizes the increasingly valuable selection and operation layer.

---

# 45. Ecosystem economics — later

Long-term capability classes:

### Free OSS capability
Community provider.

### Commercial third-party capability
Vendor licensed separately or through a future commercial arrangement.

### Thinkery premium capability
Thinkery commercial implementation.

### Enterprise private capability
Customer-owned internal implementation.

The Planner does not need to care who authored the capability.

It cares about:

- compatibility,
- policy,
- performance,
- evidence.

---

# 46. Marketplace is not required

This architecture works without a marketplace.

Initially:

- manual installation,
- local manifests,
- customer-private providers,
- ~~explicit partner integrations.~~ (cancelled)

Only build discovery/commerce later if real supply and demand justify it.

Do not confuse ecosystem architecture with marketplace product.

---

# 47. ~~First partnership experiment: RTK~~ CANCELLED

**Decision (2026-08-21):** Partnership-Track gestrichen.
LeanCTX verfolgt eine Monopol-Strategie: absolute Performance aus einer Hand.
Die technische Faehigkeit (external capability path) existiert als Enterprise-Fallback,
wird aber nicht aktiv fuer Partner-Integrationen entwickelt oder beworben.

---
> **Prove whether composable optimization creates additional value.**

---

# 48. What if stacking loses?

That is still valuable.

Possible result:

```text
LeanCTX alone
better than
~~RTK + LeanCTX~~ (cancelled)
```

Then the product insight is:

> **Blind stacking is wrong. Capability selection matters.**

This makes the Planner more valuable.

---

# 49. What if stacking wins?

Then:

- capability composition is validated,
- interoperability gains credibility,
- the joint pipeline can become a technical case if both sides agree,
- Performance Profiles become more meaningful.

Either result advances the product.

---

# 50. Integration sequence

Do not start with many competitors.

Recommended:

## Step 1
Make LeanCTX Native implement the canonical Capability contract.

## Step 2
Make a trivial/sample external capability.

## Step 3
Support one external local-process/provider mechanism.

## Step 4
~~Integrate one real external partner if mutually agreed.~~ CANCELLED — monopoly strategy.

## Step 5
Benchmark composition.

## Step 6
Stabilize contract.

## Step 7
Only then invite broader ecosystem.

Dogfood before ecosystem marketing.

---

# 51. Proposed codebase target

The following is a **conceptual ownership target**, not a command to create these folders blindly.

```text
lean-ctx/
  crates/
    leanctx-protocol/
      task/
      context/
      receipt/
      profile/
      capability/

    leanctx-ocla/
      manifest/
      registry/
      traits/
      adapters/
      conformance/

    leanctx-runtime/
      planner/
      context/
      execution/
      evidence/

    leanctx-capabilities/
      native/
        code/
        compression/
        shell/
        memory/
        retrieval/
        evidence/

    leanctx-sdk/
      session/
      profiles/
      kits/
      capabilities/

  cli/
    capability/
    profile/
    benchmark/
```

Before any physical refactor:

> **Audit the current Cargo workspace and map existing code into these responsibilities.**

---

# 52. Proposed commercial codebase ownership

Conceptually:

```text
lean-ctx-enterprise/
  performance/
    planner/
    ranking/
    candidate_generation/
    rollout/

  intelligence/
    workload_classification/
    outcome_prediction/
    drift/
    capability_graph/

  registry/
    private_capabilities/
    publisher_trust/
    approvals/

  policy/
    capability_policy/
    data_policy/
    rollout_policy/

  fleet/
    profiles/
    agents/
    economics/
```

Again: responsibility map first, folder moves second.

---

# 53. Capability conformance suite

An open ecosystem requires conformance tests.

Every provider should be testable for:

- manifest validity,
- deterministic identity,
- input/output contract,
- error behavior,
- timeout,
- permission declaration,
- evidence fields,
- version compatibility.

Capability-specific suites add deeper tests.

---

# 54. CompressionProvider conformance example

Test:

1. valid input,
2. empty input,
3. protected span,
4. output accounting,
5. declared lossy/lossless behavior,
6. recovery if claimed,
7. determinism if claimed,
8. timeout,
9. invalid encoding,
10. metrics.

---

# 55. KnowledgeProvider conformance example

Test:

- provenance included,
- timestamps valid,
- classification included,
- no result outside requested scope,
- stable object identity,
- timeout,
- stale data represented correctly,
- authority metadata preserved.

---

# 56. Capability security model

A third-party Capability is code execution.

Treat it accordingly.

Required eventually:

- signed artifacts,
- checksums,
- publisher identity,
- explicit permissions,
- sandbox/process isolation where possible,
- network policy,
- resource limits,
- audit,
- kill/disable switch.

Do not make "plugins" a casual convenience feature.

---

# 57. Capability licensing

Each capability must have explicit license metadata.

Categories:

- OSS,
- proprietary local,
- proprietary SaaS,
- internal enterprise.

LeanCTX must not silently redistribute third-party code.

Marketplace/legal complexity is deferred.

---

# 58. Versioning

A Receipt should pin:

```text
LeanCTX Runtime version
Performance Profile version
Capability IDs + versions
Context Kit IDs + versions
Model/provider
Methodology version
```

Without this, a performance result cannot be reproduced reliably.

---

# 59. Rollback

Every promoted Profile should have:

- previous known-good version,
- quality benchmark,
- compatibility record.

If a Profile regresses:

```text
Profile v8
 ↓ regression
rollback
 ↓
Profile v7
```

Infrastructure-grade behavior.

---

# 60. Drift

Performance can drift because:

- model changes,
- provider pricing changes,
- cache behavior changes,
- repository changes,
- tool output changes,
- capability updates,
- Knowledge Graph changes.

Commercial Continuous Optimization can detect:

> Previously verified Profile no longer lies on the best known cost/quality frontier.

Then request a new Benchmark.

---

# 61. Why this stays understandable externally

Do not explain the full architecture to every user.

### Developer
> **LeanCTX is the Context SDK for AI Agents.**

### Advanced team
> **Standardize and benchmark the context-performance layer instead of rebuilding it inside every agent.**

### Capability developer
> **Implement a LeanCTX/OCLA-compatible capability and make it usable by LeanCTX workloads.**

### Enterprise
> **Bring your existing optimizers, routers and knowledge systems. LeanCTX operates them through one performance framework.**

Each audience sees only the necessary layer.

---

# 62. Brand compatibility

This architecture fits the current narrative exactly.

Category:

> **The Context SDK for AI Agents**

Hero:

> **Give every agent a context system.**

Technical thesis:

> **The context path determines what an agent sees next.**

Proof doctrine:

> **Measure. Compare. Verify.**

No new public metaphor is required.

---

# 63. V-ZUG compatibility

An advanced company with its own harness should not be forced to replace it immediately.

Future flow:

```text
Existing internal harness
       ↓
OCLA adapter
       ↓
LeanCTX Benchmark
       ↓
compare with LeanCTX Native
       ↓
Performance Profile
       ↓
organization rollout
```

Build-vs-buy becomes measurable.

---

# 64. ~~Partner compatibility~~ CANCELLED

**Decision (2026-08-21):** Partner-Kompatibilitaet wird nicht aktiv verfolgt.
LeanCTX bietet absolute Performance aus einer Hand. Die technische Faehigkeit
(OCLA external capability) existiert als Enterprise-Fallback, nicht als
Partner-Oekosystem-Feature.

---

# 65. Anti-roadmap

This vision does **not** authorize current work on:

- public marketplace,
- ten competitor integrations,
- generic plugin store,
- generic agent orchestration,
- managed agent hosting,
- universal model marketplace,
- generic enterprise workflow platform.

Current work remains narrow.

---

# 66. Immediate codebase changes this vision justifies

These are the first architecture changes worth making because they reinforce current product work.

## P0.1 — Audit OCLA

Document:

- all current traits,
- implementors,
- registries,
- wire interfaces,
- call sites,
- overlaps,
- unused interfaces.

Deliver:

```text
OCLA_CURRENT_STATE.md
```

No major refactor before audit.

## P0.2 — Define Capability Manifest v0

Small draft.

Minimum:

- ID,
- version,
- type,
- execution mode,
- input/output,
- lossiness,
- recoverability,
- permissions,
- telemetry.

Use LeanCTX Native first.

## P0.3 — Make one Native capability explicit

Do **not** mechanically wrap every function.

Pick one existing, mature provider abstraction and make it the reference implementation.

## P0.4 — Link Capability identity to Receipt

Every Benchmark result should record which capability/version executed.

## P0.5 — Link Capability identity to Performance Profile

A Profile should be able to pin the same Capability.

---

# 67. Near-term proof sequence

```text
Existing LeanCTX native function
      ↓
canonical Capability contract
      ↓
Performance Profile references it
      ↓
Benchmark runs it
      ↓
Receipt records it
      ↓
external sample capability
      ↓
same Benchmark
```

If this works, the abstraction is real.

---

# 68. First external-capability milestone

Definition of done:

A sample/third-party capability can:

1. be installed or registered,
2. declare a manifest,
3. receive bounded input,
4. return output,
5. report metrics,
6. appear in a Performance Profile,
7. execute in Benchmark,
8. appear in Receipt,
9. be disabled safely.

That is enough.

No marketplace needed.


---

# 69. ~~First partnership milestone~~ CANCELLED

See section 47. Partnership-Track cancelled in favour of monopoly strategy.

---

---

# 70. 90-day sequencing with this vision

## Phase A — Product proof
- Performance Benchmark,
- Quality Gate,
- Receipt,
- Reference Agent,
- paid customer.

## Phase B — Capability substrate
- OCLA audit,
- Capability Manifest v0,
- one Native Capability normalized,
- Profile linkage,
- Receipt linkage.

## Phase C — External proof
- sample external provider,
- ~~then one real partner if available.~~ CANCELLED

## Phase D — selection
Only after enough evidence:
- simple rules,
- candidate comparison,
- manual recommendation.

## Phase E — commercial intelligence
Later:
- learned ranking,
- Continuous Optimization,
- Capability Performance Graph.

---

# 71. OSS / Paid boundary

## OSS

- OCLA Capability contracts,
- manifests,
- local Registry,
- Capability author SDK/reference,
- conformance suite,
- local Runtime,
- LeanCTX Native Capabilities,
- local Performance Benchmark,
- Performance Profile format,
- Receipt/verifier,
- Context Kit format.

## Commercial Thinkery

- large-scale Benchmark execution,
- private organization Registry,
- capability approval,
- rollout,
- learned capability ranking,
- workload-specific selection,
- Capability Performance Graph,
- Continuous Optimization,
- drift detection,
- fleet-wide Profiles,
- centralized policy,
- enterprise support/deployment.

This is a strong open-ecosystem / commercial-intelligence split.

---

# 72. Why the commercial moat improves

Open Capability contracts mean more supply can enter the system.

That can increase the value of LeanCTX if LeanCTX owns the measured selection loop.

```text
more Capabilities
       ↓
more candidate strategies
       ↓
more Benchmark evidence
       ↓
better selection
       ↓
better Performance Profiles
       ↓
more production use
       ↓
more outcome evidence
       ↓
better selection
```

That is the flywheel.

---

# 73. Potential strategic network effect

The important future network effect is **not** merely "more plugins."

It is:

> **More performance evidence across more capability/workload combinations improves the ability to choose the right strategy.**

This must be privacy-preserving and consent-based.

Cross-customer learning cannot be assumed.

Customer-specific intelligence may remain isolated.

---

# 74. Customer ownership

Customers should be able to:

- pin Capability versions,
- pin Profile versions,
- export Receipts,
- export Context Kits,
- use local capabilities,
- disable cloud intelligence,
- choose model/providers,
- retain raw context locally.

This reduces lock-in fear and supports enterprise trust.

---

# 75. One important architecture inversion

The old mental model is:

```text
LeanCTX
  has feature A
  has feature B
  has feature C
```

The target mental model becomes:

```text
LeanCTX
  understands a task
  understands constraints
  sees available capabilities
  measures candidates
  selects a strategy
  proves the outcome
```

That is a stronger product identity.

---

# 76. The strategic role of Thinkery

Thinkery commercializes the intelligence above the open capability ecosystem.

Thinkery does not need to own every implementation.

Thinkery needs to build:

- decision intelligence,
- organizational control,
- Benchmark/evidence infrastructure,
- enterprise trust,
- commercial operations.

Brand line:

> **Systems for agent performance.**

---

# 77. End-state architecture

```text
                                   THINKERY
                     Organization Performance Intelligence
                                      │
                                      ▼
                          ┌──────────────────────┐
                          │ CONTINUOUS           │
                          │ OPTIMIZATION         │
                          │ ranking / drift      │
                          │ recommendation       │
                          └──────────┬───────────┘
                                     │
                                     ▼
                               LEANCTX
                      Context Performance Runtime
                                     │
               ┌─────────────────────┼─────────────────────┐
               │                     │                     │
          PERFORMANCE           CAPABILITY              EVIDENCE
           PROFILES               PLANE                  PLANE
               │                     │                     │
               │          ┌──────────┼──────────┐          │
               │          │          │          │          │
               │       LeanCTX     Partner    Customer     │
               │       Native      Capability  Capability  │
               │          │          │          │          │
               └──────────┴──────────┼──────────┴──────────┘
                                     │
                                     ▼
                                  AGENTS
                    Codex / Claude / Cursor / Custom
                                     │
                                     ▼
                               Models / Tools
                                     │
                                     ▼
                                  Outcome
                                     │
                                     ▼
                                  Receipt
                                     │
                                     └───────────────┐
                                                     ▼
                                               better next
                                                 decision
```

---

# 78. End-state product promise by audience

## Developers

> **Build context-efficient agents without rebuilding context infrastructure.**

## Advanced teams

> **Bring your existing context stack. Benchmark it, compose it and operate it through one performance layer.**

## Enterprise

> **Standardize context performance across agents, models and teams.**

## Ecosystem developers

> **Build a capability once. Make it available to LeanCTX-compatible workloads.**

## Thinkery

> **Own the intelligence that determines which strategy produces the best accepted outcome.**

---

# 79. Final strategic statement

The consolidated vision is:

> # **LeanCTX is the Context SDK and Runtime for composable agent performance.**
>
> It starts by making existing agents use context more efficiently.
>
> It evolves by turning compression engines, routers, memory systems, knowledge graphs, evaluators and customer-built infrastructure into interoperable capabilities.
>
> LeanCTX measures those capabilities against real workloads, combines them where useful, rejects combinations that hurt quality, and records the winning configuration as a versioned Performance Profile.
>
> The open ecosystem defines what capabilities can do.
>
> Thinkery's commercial intelligence learns which capability or combination should be used for a particular workload under real quality, cost, latency and trust constraints.
>
> LeanCTX therefore does not need to win every feature race.
>
> **It needs to become the place where agent context performance is composed, measured, proven and continuously improved.**

---

# 80. Founder directive

This vision is large.

Execution must remain small.

The next implementation question is **not**:

> Which ten competitors do we integrate?

It is:

> **Can one existing LeanCTX capability be expressed through a stable open Capability contract, selected through a Performance Profile, measured through the Benchmark and recorded in the Receipt?**

When that works:

> Can one external capability do the same?

When that works:

> Does composition improve a real workload?

Only then should the broader ecosystem accelerate.

---

# 81. Immediate next actions

1. Freeze this document as the target architecture.
2. Audit the existing OCLA traits and call sites.
3. Map current Native features to Capability categories.
4. Design a minimal Capability Manifest v0.
5. Choose one Native Capability for the first end-to-end implementation.
6. Add Capability identity/version to Performance Profile.
7. Add Capability identity/version to Execution Receipt.
8. Run the existing Performance Benchmark through the Capability path.
9. Build one sample external local-process Capability.
10. ~~If RTK is interested, define one small joint Benchmark experiment.~~ CANCELLED — monopoly strategy.
11. Do not expand public messaging yet.
12. Continue selling the understandable wedge:
   **Context Performance / Context SDK / Verified Agent Efficiency.**

The architecture can be far ahead.

The product promise must remain earned.
