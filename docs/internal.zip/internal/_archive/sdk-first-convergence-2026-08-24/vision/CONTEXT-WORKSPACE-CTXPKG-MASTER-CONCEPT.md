> **Classification: Superseded Research source — not current authority.**
>
> This document is preserved as strategic input. It proposes a large future
> state model; it does not establish a shipped API, roadmap, licensing decision,
> Cloud capability or customer claim. Current status and boundaries are governed
> by [Internal README](../README.md),
> [Engine, SDK & Cloud Plan](06-ENGINE-SDK-CLOUD-PLAN.md), and
> [Context Workspace & `.ctxpkg` Plan](07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md).
> Where this document conflicts with those sources or code, those sources win.

# LeanCTX Context Workspace — The Programmable State Model for AI Agents

**Status:** Superseded Research input; preserved for background only  
**Version:** 1.0  
**Date:** 2026-08-22  
**Scope:** LeanCTX SDK, LeanCTX Engine, LeanCTX Cloud, `.ctxpkg`, Context Snapshots, Project Context, Handoffs and Context State  
**Purpose:** Define the central developer abstraction for LeanCTX and map the substantial state-management capabilities that already exist in the open-source Engine into a coherent, commercial SDK and Cloud product.

---

# Executive decision

LeanCTX should make **`ContextWorkspace`** the central resource abstraction of the new SDK.

The idea is inspired by a simple product-design principle visible in products such as Box by ASCII:

> Turn a complicated infrastructure problem into one programmable resource with a small lifecycle.

Box turns machine state into a resource developers can create, stop, resume, snapshot, fork and inspect.

LeanCTX can do the equivalent for **context state**:

> **A Context Workspace is a persistent, forkable, inspectable and portable context environment for an AI agent or project.**

The developer should not need to think in terms of dozens of independent context features such as caches, read modes, knowledge graphs, session state, handoffs, packages, snapshots, recovery stores and receipts.

Those mechanisms still exist.

But they become implementation details behind one coherent resource:

```text
ContextWorkspace
│
├── Sources
├── ProjectContext
├── Policies
├── Derived Views
├── Recovery References
├── Context Packages
├── Checkpoints
├── Sessions
├── Handoffs
├── Receipts
└── Lineage
```

A workspace can then be operated through a small lifecycle:

```text
create
attach
prepare
checkpoint
fork
diff
handoff
merge
restore
seal
sync
inspect
```

This gives LeanCTX a product model that is far easier to understand than a collection of context-engineering tools.

The strategic analogy is:

```text
Git
manages source state.

Box
manages compute state.

LeanCTX
manages context state.
```

Or more precisely:

> **Box gives every agent a machine.  
> LeanCTX gives every agent a context workspace.**

This should **not** become a fourth product next to Engine, SDK and Cloud.

Instead:

- **LeanCTX Engine** implements the low-level mechanisms required to materialize and operate workspace state.
- **LeanCTX SDK** owns the `ContextWorkspace` abstraction and the semantics of preparing, branching, diffing, merging and governing context.
- **LeanCTX Cloud** becomes the remote control plane and synchronization layer for workspaces across agents, people, machines and organizations.
- **`.ctxpkg`** becomes the open portable artifact format used to seal, distribute, template and recreate selected workspace state.

The resulting stack is:

```text
┌──────────────────────────────────────────────────────────────────┐
│                         LEANCTX CLOUD                            │
│                                                                  │
│  remote workspaces · sync · lineage · shared context             │
│  performance · governance · registry · teams · organization      │
└───────────────────────────────▲──────────────────────────────────┘
                                │
                         Workspace Remote
                                │
┌───────────────────────────────┴──────────────────────────────────┐
│                          LEANCTX SDK                             │
│                                                                  │
│                        ContextWorkspace                          │
│                                                                  │
│  session · plan · checkpoint · fork · diff · handoff · merge     │
│  policy · reuse · recovery · package · receipts · adapters       │
└───────────────────────────────▲──────────────────────────────────┘
                                │
                          Engine Contract
                                │
┌───────────────────────────────┴──────────────────────────────────┐
│                         LEANCTX ENGINE                           │
│                                                                  │
│ read · search · parse · index · cache · compress · recover       │
│ graph · archive · tokenize · redact · hash · local persistence   │
└──────────────────────────────────────────────────────────────────┘
```

The core public positioning remains:

> **LeanCTX is the Context SDK for AI Agents.**

The workspace is the developer model that makes that category tangible.

---

# 1. Why this is more than a metaphor

The strongest part of this direction is that LeanCTX does **not** need to invent the underlying foundations.

The current open-source repository already contains many of the hard mechanisms required for a Box-like lifecycle for context.

## Existing `.ctxpkg` capabilities

The repository already contains a substantial Context Package subsystem:

```text
rust/src/core/context_package/
├── builder.rs
├── bundle.rs
├── composition.rs
├── content.rs
├── deps.rs
├── export.rs
├── graph_model.rs
├── import.rs
├── keys.rs
├── loader.rs
├── lockfile.rs
├── manifest.rs
├── registry.rs
├── signing.rs
├── verify.rs
└── ...
```

The `.ctxpkg v2` specification already defines context packages as:

> portable, versioned, composable and installable context.

It already supports concepts such as:

- manifest versioning;
- SemVer package versions;
- scoped names such as `@company/auth-service-context`;
- knowledge;
- code graph data;
- session state;
- patterns;
- gotchas;
- a graph-native context model;
- typed relationships;
- package dependencies;
- optional dependencies;
- conflicts;
- provenance;
- project identity hashes;
- integrity hashes;
- Ed25519 signing;
- compatibility metadata;
- private visibility;
- install/import/export;
- a local package registry;
- auto-loading;
- compositional graph merge;
- contradiction detection;
- superseding knowledge;
- package lockfiles.

The existing `ctxpkg.lock` already records:

```text
package name
version
artifact SHA-256
registry
```

which means LeanCTX already has the beginning of **reproducible context dependency management**.

That is unusually important for the workspace model.

---

## Existing Context Snapshot / Time Machine capabilities

The current repository also already contains:

```text
rust/src/core/context_snapshot/
├── builder.rs
├── digest.rs
├── publish.rs
├── restore.rs
├── signing.rs
├── timeline.rs
└── types.rs
```

The existing `ContextSnapshotV1` is already defined as:

> a git-anchored, signed, point-in-time record of context-layer state.

It records:

- snapshot identity;
- parent snapshot;
- timestamp;
- LeanCTX version;
- Git commit / branch / dirty state;
- project identity hashes;
- token ROI;
- context lineage;
- context ledger state;
- Φ / inclusion state;
- session task;
- decisions;
- touched files;
- progress;
- signature.

The Context Time Machine already ships:

```text
snapshot create
snapshot list
snapshot show
snapshot verify
snapshot restore
snapshot publish
snapshot import
```

This is extremely close to the lifecycle we want.

---

## Existing session-delta capabilities

LeanCTX also already has:

- structured session state;
- findings;
- decisions;
- touched files;
- task progress;
- playbook deltas;
- stable playbook IDs;
- local checkpoint behavior;
- session diffing.

`session_diff.rs` already compares:

```text
files added / removed
read-mode changes
findings
decisions
tool-call statistics
tokens saved
files read
commands
mode distributions
```

The existing session playbook deliberately grows through stable deltas rather than repeatedly rewriting summaries.

That is directly compatible with an immutable / incremental workspace-state model.

---

## Conclusion

The new idea should therefore **not** be approached as:

> “Build a new workspace system from scratch.”

It should be approached as:

> **Unify the state concepts LeanCTX already has into one coherent resource model.**

The architectural work is primarily:

1. define the resource;
2. define its invariants;
3. define lifecycle semantics;
4. make existing Engine mechanisms serve those semantics;
5. move high-level lifecycle/product logic into the commercial SDK;
6. make Cloud the remote/shared implementation.

---

# 2. The product-design lesson from Box

Box by ASCII is useful as an inspiration because it hides a lot of infrastructure behind one obvious noun.

A Box is:

> a persistent Linux environment.

The developer gets a lifecycle:

```text
new
fork
stop
resume
snapshot
inspect
```

The important insight is not virtualization.

The insight is:

> **Find the persistent resource. Make everything else an operation on that resource.**

LeanCTX needs the same simplification.

Today LeanCTX contains many nouns:

```text
session
knowledge
memory
graph
context package
snapshot
handoff
archive
cache
ledger
proof
IR
agent bus
playbook
context OS
```

Every one of these may be technically legitimate.

But a developer should not have to build the mental model from those pieces.

The resource should be:

> **ContextWorkspace**

Everything else fits underneath it.

---

# 3. The canonical mental model

A `ContextWorkspace` represents:

> **The durable context state associated with a body of agent work.**

It is not:

- a chat;
- a model context window;
- a vector database;
- a filesystem;
- a VM;
- a memory store;
- an agent;
- an agent scheduler.

It is a persistent context environment from which task-specific model context can be constructed.

The hierarchy is:

```text
ContextWorkspace
        │
        ├── durable ProjectContext
        ├── attached ContextSources
        ├── ContextPolicy
        ├── derived ContextViews
        ├── recovery references
        ├── package dependencies
        ├── checkpoints
        ├── lineage
        │
        └── ContextSession
              │
              ├── task
              ├── ContextPlan
              ├── active ContextViews
              ├── findings
              ├── decisions
              ├── recovery actions
              └── ContextReceipt
```

Multiple sessions happen inside one workspace.

A workspace can be forked into a new workspace.

A workspace can be restored from a checkpoint.

A workspace can be seeded from a `.ctxpkg`.

A selected workspace state can be sealed into a `.ctxpkg`.

A workspace can synchronize selected state through LeanCTX Cloud.

---

# 4. Critical distinction: workspace, session, checkpoint and package

These four concepts must **never** become interchangeable names for roughly the same thing.

They have different responsibilities.

## 4.1 ContextWorkspace = live mutable state

A workspace is **alive**.

It changes over time.

It may:

- attach sources;
- receive new knowledge;
- create sessions;
- invalidate views;
- update policies;
- create checkpoints;
- accept handoffs;
- fork;
- merge approved state.

Think:

> working tree.

Not:

> commit.

## 4.2 ContextSession = one unit of work

A session represents:

> **One task or bounded unit of agent work inside a workspace.**

Example:

```text
Workspace:
acme/payment-platform

Session:
Investigate intermittent payment failures
```

Another session may be:

```text
Review retry-policy changes
```

Sessions use workspace state.

Sessions may contribute approved knowledge back to the workspace.

Sessions are not the workspace itself.

## 4.3 ContextCheckpoint = immutable point in workspace history

A checkpoint freezes a logical state.

It is:

- immutable;
- content-verifiable;
- linked to parent history;
- restorable;
- diffable;
- forkable.

Think:

> commit / VM snapshot.

A checkpoint should contain or reference enough information to recreate the relevant context state.

It should **not** necessarily copy every local cache byte.

## 4.4 `.ctxpkg` = portable sealed artifact

A `.ctxpkg` is not the live workspace.

It is:

> **a portable, signed, versioned package containing selected context state or context dependencies.**

It answers a different question:

> “How do I move or distribute this context?”

Examples:

```text
@acme/base-architecture@2.1.0
@acme/payment-service@4.0.3
@official/rust-review@1.2.0
```

A package may seed a workspace.

A workspace may depend on packages.

A workspace may export a package.

A checkpoint may eventually be transported inside a `.ctxpkg` envelope.

But a package remains a **sealed artifact**, not a mutable workspace.

This distinction is foundational.

---

# 5. The LeanCTX state lifecycle

The canonical lifecycle should be:

```text
CREATE
   ↓
ATTACH
   ↓
PREPARE
   ↓
WORK
   ↓
CHECKPOINT
   ↓
   ├────────── FORK ──────────┐
   │                          │
   ▼                          ▼
CONTINUE                   PARALLEL WORK
   │                          │
   │                          ▼
   │                         DIFF
   │                          │
   │                     HANDOFF / MERGE
   │                          │
   └──────────────┬───────────┘
                  ▼
                 SEAL
                  │
             .ctxpkg artifact
                  │
                  ▼
                 SYNC
                  │
             LeanCTX Cloud
```

Not every user will use every verb.

The power comes from the fact that the primitives compose naturally.

---

# 6. Proposed SDK surface

The exact syntax is not final.

The conceptual API should feel roughly like this:

```python
from leanctx import LeanCTX

lean = LeanCTX()

workspace = lean.workspace.create(
    name="acme/payment-platform"
)

workspace.attach(RepoSource("./repo"))
workspace.attach(DocsSource("./docs"))

session = workspace.session(
    task="Investigate intermittent payment failures",
    budget=24_000
)

prepared = await session.prepare()

result = await agent.run(context=prepared.context)

receipt = await session.complete(outcome=result)

checkpoint = await workspace.checkpoint(
    message="Payment failure root cause identified"
)
```

Fork:

```python
review = await workspace.fork(
    name="payment-review",
    from_=checkpoint
)
```

Diff:

```python
delta = await review.diff(workspace)
print(delta.explain())
```

Handoff:

```python
handoff = await workspace.handoff(
    to="reviewer",
    include=[
        "decisions",
        "findings",
        "changed_sources",
        "evidence",
    ]
)
```

Seal:

```python
package = await workspace.seal(
    name="@acme/payment-context",
    version="2.4.0"
)

package.write("payment-context.ctxpkg")
```

Cloud:

```python
workspace.connect(
    remote="leanctx://acme/payment-platform"
)

await workspace.push()
```

This is far more coherent than exposing the developer directly to dozens of individual `ctx_*` operations.

---

# 7. The workspace state model

A workspace should logically contain the following state.

This is a logical model, not necessarily one physical JSON object.

## 7.1 Identity

```text
workspace_id
name
created_at
owner / namespace
lineage root
head checkpoint
base checkpoint
```

Important:

> **Workspace identity must not equal project-root hash.**

Why?

Because production agents will not necessarily operate on one repository.

A workspace may include:

```text
Git repository
documentation
Jira
database schema
API descriptions
prior agent results
customer-specific domain context
```

Therefore the workspace gets its own durable ID.

Project/repository hashes become source identities inside the workspace.

## 7.2 Source catalog

The workspace maintains a catalog of attached sources.

Example:

```text
src_01   repo        acme/payments
src_02   docs        internal/payment-docs
src_03   jira        PAY project
src_04   postgres    payments schema
src_05   package     @acme/base-architecture@2.0.0
```

Each source binding should know:

```text
source_id
kind
canonical identity
current revision
trust level
freshness
permissions
available view mechanisms
recovery capability
```

## 7.3 ProjectContext

The durable scoped context state.

Contains things such as:

```text
facts
decisions
constraints
gotchas
relationships
unresolved questions
procedures
source references
prior validated outcomes
```

This is one of the workspace's most important durable components.

## 7.4 Policy state

Workspace-level policy may define:

```text
maximum context budget
source allow/deny rules
sensitivity
PII handling
secret handling
cloud-sharing rules
retention
recovery requirements
provenance requirements
agent-role permissions
```

Forks inherit policy constraints by default.

A child must not silently become less restrictive.

## 7.5 Package dependency state

The workspace may depend on `.ctxpkg` artifacts.

Existing LeanCTX functionality already has:

```text
ctxpkg.lock
```

with exact:

```text
package
version
artifact hash
registry
```

This is perfect for reproducibility.

A workspace should therefore be able to answer:

> “Which packaged context contributed to my current state?”

## 7.6 Derived view index

The workspace tracks derived context representations.

Example:

```text
source revision:
src/auth.rs@abc123

views:
full           hash: ...
signatures     hash: ...
relevant/OAuth hash: ...
```

Derived views are not permanent truth.

They are cached artifacts.

They may be invalidated when:

- source revision changes;
- policy changes;
- representation implementation changes;
- task relevance changes.

## 7.7 Recovery store references

Compact context should preserve paths to exact context.

The workspace therefore tracks:

```text
RecoveryRef
→ exact source revision
→ exact region/blob
→ transformation lineage
```

This should remain one of LeanCTX's strongest invariants.

## 7.8 Session summaries / deltas

Workspace history should retain deliberate session state, not raw conversation history.

Potential stored artifacts:

```text
task
outcome
findings
decisions
changed context
accepted knowledge
files/sources touched
receipt
```

## 7.9 Handoffs

Created and received handoffs live in workspace lineage.

A handoff can later become a Cloud-synchronized object.

## 7.10 Receipts

Receipts provide evidence of:

```text
selected sources
views used
token counts
reuse
recovery
policy actions
latency
cost
outcome
```

These power Cloud performance analytics.

---

# 8. What a workspace explicitly does NOT contain

This boundary is as important as what it contains.

A workspace should **not automatically store**:

- raw chat transcripts;
- model hidden reasoning;
- secrets;
- API credentials;
- complete copies of every external source;
- running processes;
- VM state;
- agent scheduler state;
- arbitrary customer data without policy.

The principle should be:

> **Store deliberate context state, not everything the agent ever touched.**

This is a significant differentiator.

---

# 9. Generalize the current Git-centric snapshot model

The current `ContextSnapshotV1` is Git-anchored.

That made perfect sense for coding agents.

The production SDK must generalize this.

A workspace can contain multiple heterogeneous sources.

Therefore a future checkpoint should use **source anchors**, not a single Git anchor.

Conceptually:

```json
{
  "sources": [
    {
      "source_id": "src_repo",
      "kind": "git",
      "revision": "9f21a...",
      "dirty": false
    },
    {
      "source_id": "src_docs",
      "kind": "filesystem",
      "revision": "sha256:..."
    },
    {
      "source_id": "src_jira",
      "kind": "api",
      "revision": "etag:..."
    },
    {
      "source_id": "src_schema",
      "kind": "database_schema",
      "revision": "sha256:..."
    }
  ]
}
```

Git remains a first-class source anchor.

It simply stops being the only possible anchor.

This is critical if LeanCTX wants to be the Context SDK for **all agents**, not merely coding agents.

---

# 10. ContextCheckpoint V2

The existing snapshot implementation should be treated as the foundation.

The SDK can expose a higher-level `ContextCheckpoint`.

A future checkpoint format should likely evolve in several important ways.

## 10.1 Separate event identity from state identity

A stronger model separates:

```text
checkpoint_id
```

which identifies the historical event, from:

```text
state_digest
```

which identifies canonical logical state.

Example:

```json
{
  "checkpoint_id": "chk_01J...",
  "state_digest": "blake3:93fa...",
  "created_at": "...",
  "parents": ["chk_parent"]
}
```

Two checkpoints may occur at different times but represent the same state.

Then:

```text
state_digest identical
→ backing state can be deduplicated
```

This is exactly the kind of optimization that makes cheap forks possible.

## 10.2 Parent list, not only parent ID

The current snapshot model forms a linear chain:

```text
parent_id
```

A true branching/merging model needs a DAG.

Future model:

```text
parents: []
```

Normal checkpoint:

```text
parents: [A]
```

Merge checkpoint:

```text
parents: [A, B]
```

This gives LeanCTX proper context lineage.

## 10.3 Reference immutable state segments

A checkpoint should avoid becoming one huge repeated blob.

Instead:

```text
Checkpoint
│
├── source catalog ref
├── ProjectContext ref
├── policy ref
├── package lock ref
├── session-delta ref
├── receipt ref
├── recovery-index ref
└── optional derived-view refs
```

Each can be content-addressed.

Unchanged segments are shared across checkpoints and forks.

---

# 11. Content-addressed state and cheap forks

Box makes snapshots efficient by storing incremental, deduplicated state.

LeanCTX should apply the same principle at the context layer.

Existing LeanCTX systems already use:

- SHA-256 package integrity;
- BLAKE3 snapshot identities;
- content hashes;
- content-addressed recovery handles;
- signed package/snapshot artifacts.

A future workspace object store could logically look like:

```text
objects/
  03/03e91...
  17/17a20...
  8f/8fa99...

checkpoints/
  chk_001.json
  chk_002.json

refs/
  main
  reviewer
  oauth-experiment
```

The physical layout is an implementation detail.

The invariant matters:

> **A fork should share immutable backing objects and only write new state.**

Not:

> copy the entire knowledge graph, indexes, archive and cache directory.

Conceptual fork complexity should approach metadata cost rather than workspace-size cost where practical.

---

# 12. Fork semantics

`fork()` is potentially one of the strongest LeanCTX operations.

Definition:

> **Fork creates a new independent ContextWorkspace starting from an immutable checkpoint of another workspace.**

Example:

```python
base = lean.workspace("acme/payment")

review = await base.fork("payment-review")
experiment = await base.fork("retry-experiment")
```

Both children begin with the same deliberate project understanding.

They then diverge independently.

## 12.1 What a fork inherits

By default:

- source bindings;
- source revisions;
- ProjectContext;
- installed `.ctxpkg` dependencies;
- policy constraints;
- planner configuration;
- reusable immutable views;
- recovery references;
- lineage root.

## 12.2 What a fork should NOT inherit blindly

Do not copy:

- credentials;
- access tokens;
- transient process state;
- active model connection;
- open network connections;
- ephemeral agent runtime state.

Credentials should be resolved again from the runtime environment / secret provider.

This mirrors an important infrastructure rule:

> **State and authorization are different things.**

---

# 13. Forking does not mean LeanCTX forks the codebase

This responsibility boundary must stay clear.

If a coding agent needs an isolated repository branch or VM, another system should provide it.

Examples:

- Git branch/worktree;
- Box;
- E2B;
- Docker;
- Kubernetes;
- customer sandbox.

LeanCTX can expose hooks or bindings.

Conceptually:

```text
Execution environment fork
        +
ContextWorkspace fork
        =
new independent agent worker
```

Possible integration:

```python
box_child = await box.fork(parent_box)

ctx_child = await workspace.fork(
    "reviewer",
    execution_ref=box_child.id
)
```

But LeanCTX should not itself become the VM/sandbox provider.

The distinction is:

```text
Execution fork
copies where the agent works.

Context fork
copies what the agent knows.
```

---

# 14. Context Delta — the semantic diff

The existing `session_diff` mechanism is an excellent starting point.

The SDK should elevate this into:

> **ContextDelta**

A delta should compare two workspace/checkpoint states.

Not merely bytes.

It should answer:

```text
What became newly relevant?
What became stale?
What new facts exist?
What decisions were added?
What was contradicted?
Which sources changed?
Which views changed?
Which policies changed?
What was recovered?
What package dependencies changed?
What performance changed?
```

Example:

```text
Context Delta
payment-review ← payment-base

Sources
+ tests/retry.rs
~ src/payment.rs            9f21a → ad332

Project Context
+ Decision: use exponential retry
+ Finding: timeout occurs after gateway ack
! Conflict: previous retry limit = 3, new evidence = 5

Views
~ src/payment.rs
  signatures → relevant_sections

Packages
  unchanged

Policy
  unchanged

Performance
  context tokens: 24.3k → 17.1k
  reuse: 42% → 68%
```

This is significantly more useful than a plain session diff.

---

# 15. Context Merge

Forking is easy.

Merging context correctly is much harder.

LeanCTX should **not** treat merge as “concatenate two memory stores”.

The existing `.ctxpkg` graph composition already contains useful foundations:

- node union;
- edge merge;
- contradiction detection;
- supersedes semantics;
- confidence propagation;
- activation merging.

That is excellent.

But production workspace merge should evolve toward a **three-way semantic merge**.

## 15.1 Three-way merge

Given:

```text
        BASE
       /    \
      A      B
```

LeanCTX should compare:

```text
BASE → A
BASE → B
```

rather than simply combining A and B.

This distinguishes:

- independently added facts;
- conflicting changes;
- superseded knowledge;
- source divergence;
- policy divergence.

## 15.2 Merge modes

Do not provide only:

```python
workspace.merge(other)
```

Recommended modes:

### `handoff`

Safest default.

Only imports deliberate handoff content.

### `knowledge`

Merge approved ProjectContext nodes / relationships.

### `decisions`

Merge explicit decisions.

### `state`

Advanced full workspace-state merge.

### `policy`

Never automatic across trust boundaries.

Requires explicit authorization.

## 15.3 Never “merge the cache” as truth

Derived views are rebuildable.

When source revisions match, their content-addressed cache entries can be reused.

But cache state is not semantic truth.

The merge algorithm should merge durable state and reference compatible cached artifacts opportunistically.

---

# 16. Handoff vs merge

These concepts should remain different.

## Handoff

> Transfer exactly what the next agent needs.

Curated.

Narrow.

Safe.

## Merge

> Reconcile two independently evolved workspace states.

Broader.

Potentially conflicting.

More advanced.

For many multi-agent workflows, **handoff is preferable to merge**.

The product should encourage that.

---

# 17. Restore and resume

The current Time Machine already supports restore/resume.

This should map naturally to workspaces.

## Restore

```python
await workspace.restore(checkpoint)
```

For auditability, restore should normally create a new lineage event derived from the historical checkpoint rather than destroying history.

## Resume

A new agent process can simply reopen:

```python
workspace = lean.workspace.open("acme/payment")
```

The workspace reconstructs its state from its head + durable objects.

---

# 18. Automatic checkpointing

Box uses frequent automatic machine snapshots.

LeanCTX should borrow the concept but **not the exact timer model**.

Context changes are semantic.

Better automatic triggers:

```text
session completed
important decision accepted
handoff created
merge completed
source revision changed
policy changed
package dependency changed
before destructive restore
manual checkpoint
```

A long-running agent may additionally checkpoint periodically.

Example policy:

```python
CheckpointPolicy(
    on_session_complete=True,
    on_handoff=True,
    on_decision=True,
    interval=None,
)
```

This avoids hundreds of meaningless time-based frames.

---

# 19. Incremental checkpointing

The existing Playbook already follows an important principle:

> do not repeatedly rewrite the entire context summary.

Workspace checkpoints should follow the same philosophy.

A checkpoint should mostly contain:

```text
new references
new deltas
new object hashes
new parent link
```

rather than a monolithic re-serialized knowledge universe.

This improves:

- fidelity;
- storage;
- deduplication;
- diffability;
- signing;
- debugging.

---

# 20. `.ctxpkg` becomes much more important under this model

The workspace concept gives `.ctxpkg` a much clearer role.

Current positioning in the spec:

> `.ctxpkg is to AI context what npm packages are to code.`

That remains strong.

Under the new model:

> **A `.ctxpkg` is a sealed, portable unit of context that can seed or extend a ContextWorkspace.**

---

# 21. Workspace ↔ `.ctxpkg` operations

## Install package into workspace

```python
workspace.install("@acme/base-architecture@2")
```

Existing graph composition and package dependencies are reused.

## Create workspace from package

```python
workspace = lean.workspace.from_package(
    "@acme/support-agent@1.4"
)
```

## Seal workspace as package

```python
pkg = await workspace.seal(
    name="@acme/payment-context",
    version="4.2.0"
)
```

Sealing exports a deliberate projection according to package policy, not a blind dump.

## Export checkpoint

Potential future:

```python
pkg = checkpoint.export()
```

A checkpoint package can preserve:

- state references;
- lineage;
- selected ProjectContext;
- required package dependencies;
- policy metadata;
- source anchors.

---

# 22. `.ctxpkg` should remain an open format

This is strategically important.

Even though the new SDK is BSL/commercial, the portable Context Package format should remain:

> **open and implementable without the commercial SDK.**

Reasons:

1. It reduces lock-in anxiety.
2. It encourages ecosystem integrations.
3. It gives LeanCTX a chance to establish a context portability standard.
4. It separates the value of the SDK from file-format secrecy.
5. Competitors implementing the package format do not automatically replicate the Context Planner or workspace semantics.

The commercial value is:

```text
how the workspace behaves
how context is planned
how context evolves
how state is reconciled
how production systems integrate
```

not the file syntax itself.

---

# 23. Evolving `.ctxpkg` without rewriting it

Do **not** immediately create `.ctxpkg v3` just because the workspace model exists.

Recommended progression:

## Phase 1

Use `.ctxpkg v2` exactly where it already fits:

- context dependencies;
- ProjectContext bundles;
- templates;
- signed export/import.

## Phase 2

Add SDK-level metadata around package usage.

## Phase 3

Only when real use cases require it, extend the specification to represent:

- checkpoint transport;
- multi-source anchors;
- workspace templates;
- content-addressed object references.

The existing format is already substantial.

Avoid a speculative format rewrite.

---

# 24. ContextKit becomes a product-level template

Define:

> **A ContextKit is a reusable workspace seed built from one or more `.ctxpkg` packages plus planner/policy configuration.**

Examples:

```text
industrial-maintenance
customer-support
coding-review
security-audit
research-agent
```

A kit may specify:

```text
required context packages
recommended source types
default policy
context budget strategy
planner profile
handoff template
evaluation suite
```

It does **not** need its own new portable file format initially.

---

# 25. Templates and credentials must stay separate

A ContextKit / `.ctxpkg` may contain:

```text
knowledge
policies without secrets
source descriptors
planner strategy
context structures
```

It must not package:

```text
Jira token
database password
GitHub token
API key
customer secret
```

Instead:

```text
package/template
      +
runtime credential provider
      =
usable workspace
```

This is critical for safe package sharing and forking.

---

# 26. Reproducible Context Workspaces

Because `.ctxpkg` already supports versioning, dependencies and `ctxpkg.lock`, LeanCTX can provide:

> **Reproducible context environments.**

Combined with source anchors and planner version:

```text
Engine version
SDK version
package lock
source revisions
policy hash
planner profile
```

LeanCTX can reconstruct:

> **the context environment used for a production agent run.**

That is valuable for:

- debugging;
- audits;
- incident reconstruction;
- evaluation;
- compliance;
- scientific reproducibility.

---

# 27. Workspace warming

Box records startup file-access patterns so restored machines can prioritize useful files.

LeanCTX can apply a context-specific version of the same idea.

Call it conceptually:

> **Workspace Warm Set**

or:

> **Preparation Profile**

Do not reuse “Playbook” as the product term because LeanCTX already has a session Playbook with different semantics.

The system can learn:

```text
for support escalation tasks:
  architecture package is almost always needed
  payment API schema is usually needed
  old deployment logs are rarely needed
  signatures view works for service files
  full view is needed for config
```

When creating or forking a workspace:

- metadata becomes available immediately;
- frequently useful source indexes warm first;
- common ContextViews may be prepared;
- heavier indexes rebuild in the background.

This is the **context equivalent of warm restore**.

---

# 28. Lazy workspace materialization

A restored/forked workspace should not block until every index or cache is rebuilt.

Desired behavior:

```text
Workspace created
      ↓
METADATA_READY
      ↓
usable for basic operations
      ↓
indexes warming
      ↓
FULLY_WARM
```

Possible status:

```text
READY
WARMING
DEGRADED
BLOCKED
```

The SDK should orchestrate graceful degradation.

---

# 29. The Context Workspace is not a data lake

Production agent systems may attach huge sources.

LeanCTX should not automatically ingest and duplicate all of them.

The workspace stores:

```text
identity
revision
derived context
references
selected durable knowledge
lineage
```

Source content remains in source systems unless policy explicitly allows materialization.

The principle is:

> **Reference first. Materialize only what creates context value.**

---

# 30. Context views become workspace artifacts

A source may yield multiple views:

```text
src/auth.rs@commitA
│
├── full
├── signatures
├── outline
├── relevant/oauth
└── lines/100-180
```

Each view should carry:

```text
source revision
view type
task/context selector
transform version
content hash
token count
recovery reference
```

If another fork needs the same view against the same source revision:

> reuse it.

This gives workspace forks real efficiency.

---

# 31. Context Planner and workspace

The Context Planner should always operate **inside a workspace**.

Input:

```text
Workspace state
+
Session task
+
Budget
+
Model constraints
+
Policy
```

Output:

```text
ContextPlan
```

The workspace provides:

- sources;
- durable project context;
- reusable prior views;
- package dependencies;
- policy;
- lineage.

Without a workspace, the Planner is largely stateless retrieval.

With a workspace, planning can improve over time.

---

# 32. A concrete planning example

Workspace:

```text
acme/payment-platform
```

Task:

```text
"Investigate retry failures after gateway timeout"
```

The Planner may produce:

```text
ContextPlan

1. Project decision:
   payment retries use idempotency keys
   450 tokens

2. src/payment/retry.rs
   relevant_sections
   1,900 tokens

3. gateway timeout incident
   summarized evidence
   1,200 tokens

4. payment configuration
   signatures
   600 tokens

5. tests/retry.rs
   full
   3,100 tokens

6. @acme/base-architecture
   selected graph nodes
   900 tokens

Recovery references attached to all derived views.
```

The task gets a deliberate model context.

The entire workspace is not dumped into the model.

---

# 33. Workspace branch model

Internally:

```text
main workspace lineage

A ── B ── C
          │
          ├── D ── E   reviewer
          │
          └── F ── G   experiment
```

A “fork” creates an independent workspace.

Internally, checkpoints form a DAG.

This gives Cloud a powerful visualization later.

---

# 34. Cloud as the Workspace Remote

The Cloud becomes dramatically clearer under this model.

Instead of:

> “LeanCTX Cloud stores memory.”

Think:

> **LeanCTX Cloud is the remote for your Context Workspaces.**

Conceptually:

```text
local workspace
      │
      ├── push state
      ├── pull shared state
      ├── publish checkpoints
      ├── receive handoffs
      └── sync receipts
      │
      ▼
LeanCTX Cloud
```

This gives the Cloud a coherent scope.

---

# 35. What Cloud stores

Depending on policy:

## Metadata mode

- workspace IDs;
- source IDs/hashes;
- checkpoint DAG;
- receipts;
- performance;
- package manifests.

No raw source.

## Derived-context mode

Additionally:

- decisions;
- findings;
- ContextViews;
- ProjectContext nodes;
- handoffs.

## Managed-context mode

With explicit organization approval:

- selected source objects;
- full portable packages;
- synchronized context artifacts.

---

# 36. Workspace sync

Sync should operate on immutable objects and state references where practical.

Conceptually:

```text
local object store
       │
       │ missing hashes only
       ▼
Cloud object store
```

This produces:

- efficient sync;
- dedup across forks;
- verifiable artifacts;
- better offline support.

A workspace can continue locally when Cloud is unavailable.

---

# 37. Cloud fork

A production system may ask Cloud:

```python
child = await cloud.workspace.fork(
    workspace_id,
    checkpoint=checkpoint_id
)
```

Cloud creates new lineage metadata.

Actual local source access still occurs where policy allows.

This allows distributed agent factories to create context branches without duplicating the entire context corpus.

---

# 38. Cloud merge and review

Cloud can provide a review UI:

```text
Merge Context Branch

Base:
chk_102

Incoming:
reviewer / chk_118

Knowledge
+ 4 facts
+ 2 decisions
! 1 contradiction

Sources
~ 3 revisions

Policies
unchanged

Receipts
3 sessions

[Merge handoff only]
[Merge approved knowledge]
[Review conflict]
```

This is a much more interesting product than a generic AI memory dashboard.

---

# 39. Performance Board becomes workspace-native

The current Performance Board should organize information around workspaces.

Example:

```text
ACME / Payment Platform
────────────────────────────────

Workspace Health
Sources                     18
Project Context nodes      624
Checkpoints                 92
Active forks                 3
Open handoffs                2

Performance
Avg context/task          18.4k
Baseline                  62.8k
Reuse                       71%
Recovery                     9%
Successful outcomes          96%
Cost / accepted outcome   $0.84

Branches
main
retry-investigation
gateway-review
sdk-v2-evaluation
```

This makes the Cloud legible.

---

# 40. Workspace timeline / Time Machine

The existing Time Machine becomes:

> **Workspace History**

The timeline should show events such as:

```text
21:04  checkpoint
       retry failure identified

20:51  decision
       idempotency strategy accepted

20:32  source revision
       retry.rs changed

20:15  fork
       reviewer created from chk_103

19:58  session completed
       gateway timeout investigation

19:42  handoff
       planner → implementation
```

Click a checkpoint:

```text
Sources
Context selected
Decisions
Lineage
ROI
Policy
Receipt
Parent(s)
Children
```

This is one of the most powerful visualizations LeanCTX can own.

---

# 41. `.ctxpkg` registry and Cloud

`ctxpkg.com` becomes a natural part of Cloud / ecosystem.

Potential roles:

## Public registry

```text
@community/...
@verified/...
```

## Private organization registry

```text
@acme/base-architecture
@acme/support-domain
@acme/security-context
```

## Workspace templates

Teams can start:

```text
new workspace
from
@acme/support-agent-template
```

Existing package signing and lockfile primitives give this a strong foundation.

---

# 42. Package dependency composition as workspace layering

A workspace could conceptually be assembled from layered packages:

```text
@official/python-agent-basics
        +
@acme/base-architecture
        +
@acme/payment-domain
        +
local project context
        =
payment workspace
```

Existing graph merge / contradiction detection is already relevant here.

This could become an extremely powerful enterprise capability.

---

# 43. Context inheritance

Forks and templates imply context inheritance.

A child may add:

```text
new decisions
new source bindings
new package
```

but should not silently mutate the parent.

This is normal copy-on-write lineage.

---

# 44. Policy inheritance

Policy inheritance should be monotonic by default.

Parent:

```text
cloud_raw_source = false
secret_paths = denied
retention = 30d
```

Child must not silently become:

```text
cloud_raw_source = true
```

unless an authorized policy override explicitly permits it.

This prevents context forking from becoming a security escape hatch.

---

# 45. Package trust inheritance

If a workspace contains packages with trust states such as:

```text
signed
unsigned
private
public
verified
```

those trust properties should survive:

- fork;
- checkpoint;
- seal;
- sync;
- handoff.

A receipt should be able to show whether model context ultimately depended on an unverified package.

---

# 46. Provenance as lineage graph

A final agent output may trace:

```text
Outcome
  ← Decision
      ← Finding
          ← ContextView
              ← SourceRevision
                  ← Source
```

Another input may come from:

```text
Outcome
  ← ContextView
      ← ProjectContext node
          ← .ctxpkg package
              ← package signature
```

This is compelling for debugging and regulated systems.

---

# 47. Context Receipt as the execution record

Every session should create a receipt referencing workspace lineage.

Receipt:

```text
workspace_id
checkpoint_before
checkpoint_after
session_id
task
plan
sources/views
reused objects
recovery operations
policy decisions
tokens
cost
latency
outcome
```

Cloud can aggregate receipts without necessarily storing raw source context.

---

# 48. Checkpoint vs receipt

Do not conflate them.

## Receipt

What happened during one run/session.

## Checkpoint

What durable workspace state existed after/before a point.

A receipt may reference two checkpoints:

```text
before
after
```

This gives LeanCTX excellent causality.

---

# 49. ContextWorkspace status

A simple status API:

```python
status = await workspace.status()
```

Example:

```text
Workspace: acme/payment

Head:
chk_118

Sources:
18 attached
2 stale
1 unavailable

ProjectContext:
624 nodes
3 contradictions

Packages:
4 locked
all verified

Warm state:
92%

Open sessions:
2

Cloud:
synced

Policy:
compliant
```

---

# 50. Workspace preflight

Before a production agent call:

```python
result = await workspace.preflight(task)
```

Potential result:

```text
READY

or

STALE_SOURCE
MISSING_SOURCE
POLICY_BLOCK
PACKAGE_DRIFT
CONTRADICTION
OVER_BUDGET
RECOVERY_UNAVAILABLE
CLOUD_POLICY_MISMATCH
```

This makes context a production-grade dependency rather than invisible prompt assembly.

---

# 51. Workspace invariants

These should become formal contracts.

## Invariant 1 — source fidelity

A derived view must identify the source revision it came from.

## Invariant 2 — recoverability

If a view claims recoverability, the exact recovery path must be verifiable.

## Invariant 3 — policy inheritance

Forking must not silently weaken security policy.

## Invariant 4 — immutable checkpoints

A checkpoint never changes after publication.

## Invariant 5 — reproducible package dependencies

Locked packages resolve to exact artifact hashes.

## Invariant 6 — no hidden transcript dependency

Workspace state must not require replaying an opaque chat transcript to be useful.

## Invariant 7 — Cloud optionality

Local workspace operation must not require Cloud.

## Invariant 8 — deterministic identity where promised

Content-addressed state must be derived from canonical content, not nondeterministic ordering.

## Invariant 9 — explicit conflict

Contradictory durable context is surfaced, not silently merged.

## Invariant 10 — provenance preservation

Fork, merge, seal and handoff preserve origin metadata.

---

# 52. Engine / SDK / Cloud ownership under the workspace model

## 52.1 Engine — Apache 2.0

Engine owns mechanisms naturally open:

```text
source reads
search
AST parsing
indexing
graph primitives
tokenization
compression
cache
archive
recovery
hashing
redaction
package parsing
package verification
package import/export
local package registry
low-level snapshot persistence
content-addressed object primitives
```

Existing `.ctxpkg` code remains open.

Existing snapshot mechanisms remain open.

This strengthens the ecosystem.

## 52.2 SDK — BSL 1.1 + Commercial

SDK owns the valuable behavior:

```text
ContextWorkspace
workspace lifecycle
ContextSession
ContextPlanner
ContextPlan
Workspace Checkpoint semantics
fork semantics
ContextDelta
three-way semantic merge
ProjectContext lifecycle
ContextPolicy
package-to-workspace materialization
workspace sealing policy
handoffs
receipt lifecycle
framework adapters
evaluation
preflight
workspace providers
```

## 52.3 Cloud — proprietary

Cloud owns:

```text
Workspace Remote
shared workspace registry
checkpoint DAG service
workspace sync
organization package registry
team/project state
Performance Board
shared handoffs
RBAC
SSO
policy distribution
audit
fleet observability
organization-level context intelligence
adaptive learning
billing
```

---

# 53. Why the open `.ctxpkg` implementation does not undermine the SDK

A competitor can already:

```text
read a package
write a package
merge package graphs
verify signatures
```

That does **not** automatically give them:

```text
a production context workspace model
task-aware context planning
fork semantics
semantic workspace diff
safe three-way merge
context policy lifecycle
framework adapters
evaluation
Cloud sync
organization intelligence
```

The value moves upward.

That is the correct commercial architecture.

---

# 54. Do not move existing Apache code just for optics

If a function is already Apache, moving the same implementation into a BSL repo does not erase the public version.

Instead:

> leave mechanism implementations where they naturally belong.

Build the next abstraction in SDK.

Example:

Existing:

```text
Engine merge_graphs()
```

Open.

New SDK:

```text
workspace.merge(
    other,
    mode="knowledge",
    base=common_ancestor,
    policy=...
)
```

Commercial semantic logic can call open merge primitives where appropriate.

---

# 55. Multi-agent workflows become much clearer

Instead of:

```text
Agent Bus
Shared Memory
Task Manager
```

the product model becomes:

```text
Shared / branched Context Workspaces
```

Example:

```text
Base Workspace
     │
     ├──── fork ──── Planner Workspace
     │
     ├──── fork ──── Implementation Workspace
     │
     └──── fork ──── Reviewer Workspace
```

Agents can have independent context branches.

They exchange deliberate handoffs.

Approved context can merge back.

This is more powerful and easier to explain than “multi-agent memory”.

---

# 56. A complete multi-agent example

## Step 1 — base

```python
base = lean.workspace.open("acme/auth")
```

Head:

```text
chk_A
```

## Step 2 — planner fork

```python
planner = await base.fork("oauth-plan")
```

Planner creates:

```text
Decision:
use PKCE

Finding:
callback config lives in auth_config.rs
```

Checkpoint:

```text
chk_P
```

## Step 3 — implementation fork

Implementation receives a curated handoff from planner.

It does not receive the entire planner transcript.

It recovers exact source ranges locally.

Checkpoint:

```text
chk_I
```

## Step 4 — reviewer

Reviewer forks from the implementation checkpoint.

It sees:

```text
changed source refs
accepted planner decisions
test evidence
implementation receipt
```

It adds:

```text
Finding:
refresh rotation missing
```

## Step 5 — merge

Main workspace does **not** blindly merge all reviewer state.

It merges:

```text
approved decision
verified finding
source refs
test evidence
```

New checkpoint:

```text
chk_M
parents = [chk_A, chk_R]
```

Cloud shows lineage.

This is a compelling product demonstration.

---

# 57. Workspace + sandbox integrations

LeanCTX becomes highly complementary with agent sandbox platforms.

Potential integrations:

```text
Box
E2B
Daytona
Docker
Kubernetes
customer VM
local machine
```

A possible interface:

```text
ExecutionRef
```

A workspace records:

```text
execution provider
execution instance ID
optional code revision binding
```

but does not own execution lifecycle.

Example:

```python
execution = box.fork(parent)

ctx = workspace.fork(
    "reviewer",
    execution_ref=execution.id
)
```

This creates a strong ecosystem story:

> Bring your agent framework.  
> Bring your sandbox.  
> LeanCTX manages context.

---

# 58. Context and execution should have matching lineage where useful

For coding agents:

```text
Execution branch
Git branch
Context branch
```

should ideally remain correlated.

Example:

```text
execution:
box bx_812

git:
feature/oauth

context:
workspace ws_oauth / chk_192
```

Receipt captures all three references.

This enables excellent replay/debug capabilities.

---

# 59. General production-agent example

Customer support agent:

```text
ContextWorkspace
acme/customer-support

Sources:
product docs
CRM case data
policy docs
service status
prior verified customer facts

ProjectContext:
business rules
escalation decisions
known service incidents

Session:
"Resolve customer ticket 4812"

Checkpoint:
post-resolution context

Handoff:
support → fraud review
```

No Git required.

This validates why multi-source anchors matter.

---

# 60. Industrial-agent example

```text
ContextWorkspace:
robot-cell-17

Sources:
PLC docs
maintenance manuals
sensor schema
equipment configuration
work orders
service history

ProjectContext:
known faults
approved maintenance decisions
machine constraints

Policy:
raw production data stays on-prem
Cloud gets receipts + hashes only

Agent session:
diagnose intermittent positioning fault

Handoff:
diagnostic agent → maintenance planner
```

This fits LeanCTX's industrial GTM well.

---

# 61. Evaluation becomes branch comparison

The workspace model makes evaluation elegant.

Instead of abstract A/B configuration:

```text
Base checkpoint
      │
      ├── fork strategy-A
      └── fork strategy-B
```

Run the same task.

Compare:

```text
quality
context tokens
latency
cost
recovery
source usage
reuse
policy compliance
```

This is a natural Context Engineering experiment model.

---

# 62. Shadow mode becomes a workspace branch

Existing Shadow Mode can conceptually map to:

```text
live workspace
      │
      └── shadow evaluation branch
```

No production behavior changes.

The shadow branch can compare an alternative context strategy against the live strategy.

This can make existing value measurement more coherent.

---

# 63. Context Time Machine becomes a consequence, not a separate pillar

The current Time Machine remains valuable.

Under this model it becomes:

> **the visualization of workspace checkpoint history.**

```text
ContextWorkspace
     │
     └── checkpoint DAG
             │
             └── Time Machine UI
```

The underlying capability remains powerful.

The mental model becomes simpler.

---

# 64. `.ctxpkg` and Time Machine become two axes of the same state system

A useful conceptual distinction:

```text
Checkpoint / Time Machine
= temporal axis

.ctxpkg
= portability/composition axis
```

Workspace sits at the center.

```text
                 TIME
                  │
             checkpoints
                  │
                  ▼
PACKAGES ───► ContextWorkspace ◄─── SOURCES
                  │
                  ▼
               sessions
```

This is a better systems picture than treating Time Machine and Packages as unrelated features.

---

# 65. Package as template

One valuable operation:

```python
template = workspace.seal(
    role="template",
    name="@acme/support-agent",
    version="3.0.0"
)
```

Then:

```python
workspace = lean.workspace.create(
    from_="@acme/support-agent@3"
)
```

This gives companies repeatable agent context setup.

---

# 66. What a template should capture

Recommended:

```text
ProjectContext baseline
package dependencies
policy baseline
planner configuration
source-type requirements
ContextKit settings
evaluation profile
```

Not:

```text
credentials
active sessions
personal data
ephemeral cache
current agent identity
```

Derived source views may optionally be included if safe and revision-pinned.

---

# 67. Context package roles

Conceptually context packages may serve:

```text
LIBRARY
Reusable domain context.

TEMPLATE
Seed for new workspace.

CHECKPOINT_EXPORT
Portable historical state.

HANDOFF
Small scoped transfer.

KIT
Reusable context behavior/configuration.
```

All can share the same base package/integrity infrastructure.

The SDK can distinguish roles before the open `.ctxpkg` specification needs to.

---

# 68. Workspace source revisions

A major requirement for correct reuse is source versioning.

Each source adapter must expose a revision identity when possible.

Examples:

## Git

```text
remote identity
commit
dirty hash
```

## File tree

```text
manifest hash
```

## HTTP/API

```text
ETag
Last-Modified
query fingerprint
```

## Database schema

```text
schema digest
migration version
```

## Ticket

```text
ticket ID
updated timestamp/version
```

Without a revision:

```text
source considered volatile
```

and reuse policies become conservative.

---

# 69. Staleness propagation

If a source changes:

```text
Source revision
A → B
```

LeanCTX should determine which dependent artifacts become stale:

```text
views
facts
decisions?
recovery refs
planner assumptions
indexes
```

Not everything necessarily invalidates.

This dependency graph can become a major SDK intelligence capability.

---

# 70. Semantic invalidation

Long-term LeanCTX can distinguish:

```text
byte change
semantic change
context-relevant change
```

This helps preserve reuse.

The SDK can initially use deterministic rules.

Later Cloud can help learn invalidation behavior across workloads.

---

# 71. Context merge conflict types

A mature merge system should distinguish:

```text
KNOWLEDGE_CONTRADICTION
SOURCE_DIVERGENCE
POLICY_CONFLICT
PACKAGE_CONFLICT
DECISION_CONFLICT
TRUST_CONFLICT
SCHEMA_CONFLICT
STALE_REFERENCE
```

Each requires different handling.

---

# 72. Merge report

Example:

```text
Context Merge Report

Base:
chk_A

Incoming:
chk_B

Applied:
+ 8 new facts
+ 2 decisions
+ 4 relationships

Skipped:
- 17 cached views (rebuildable)
- 2 transient sessions

Conflicts:
! Decision conflict: retry limit
! Package conflict: @acme/payment-rules
! Policy conflict: Cloud sharing

Requires review:
3 items
```

---

# 73. Workspace garbage collection

Persistent/forkable state requires lifecycle management.

Objects may be retained if referenced by:

```text
workspace head
checkpoint
package
handoff
Cloud sync
retention policy
```

Unreferenced objects can be garbage-collected.

This is a natural fit for content-addressed storage.

---

# 74. Fork retention

A fork may be:

```text
ephemeral
persistent
evaluation
production
```

Example:

```python
workspace.fork(
    "strategy-test",
    retention="24h"
)
```

Cloud can later manage retention.

---

# 75. Context Workspace URI

A stable resource identifier could become valuable.

Conceptual examples:

```text
ctx://local/acme/payment
ctx://acme/payment
ctx://acme/payment/checkpoints/chk_118
ctx://acme/payment/sources/src_repo
```

Do not commit prematurely to exact URI syntax.

But canonical resource addressing would improve:

- Cloud;
- handoffs;
- receipts;
- tooling;
- IDE links.

---

# 76. Context object IDs

Use explicit IDs:

```text
ws_
ses_
chk_
src_
view_
pkg_
hand_
rcpt_
```

This makes logs, APIs, dashboards and debugging easier.

---

# 77. SDK provider model under Workspace

Recommended provider architecture:

```text
EngineProvider
StateStore
PackageProvider
SyncProvider
CredentialProvider
PolicyProvider
ReceiptProvider
ExecutionBinding
```

Local defaults:

```text
EngineProvider    LocalEngine
StateStore        LocalStore
PackageProvider   LocalRegistry
SyncProvider      None
CredentialProvider Environment/host
ReceiptProvider   Local
```

Cloud:

```text
SyncProvider      LeanCTXCloud
PackageProvider   CloudRegistry + local cache
ReceiptProvider   Cloud
PolicyProvider    OrganizationPolicy
```

---

# 78. Local-first invariant

This remains non-negotiable:

```text
ContextWorkspace
+
LeanCTX SDK
+
LeanCTX Engine
```

must work without:

```text
LeanCTX Cloud
```

Cloud adds:

```text
sharing
sync
aggregation
governance
organization intelligence
```

---

# 79. Data-residency modes

Workspace sync should allow:

```text
LOCAL_ONLY

METADATA_ONLY

DERIVED_CONTEXT

FULL_MANAGED
```

Example regulated customer:

```text
Source contents:
local

ProjectContext:
local

Cloud:
receipt metadata
hashes
performance
workspace lineage
```

---

# 80. Performance + workspace lineage = unique observability

Most AI observability systems focus on:

```text
request
response
trace
```

LeanCTX can focus on:

```text
context state
context lineage
context decisions
context reuse
context branch
context outcome
```

This gives it a distinct observability angle.

---

# 81. Context blame

A future operation:

```bash
leanctx blame decision:retry-policy
```

Result:

```text
introduced:
session ses_...
checkpoint chk_...
agent reviewer-02

source:
payment-runbook@rev4
lines 110-128

confirmed:
4 later sessions

used by:
17 receipts
```

This is “git blame” carefully applied to context provenance.

---

# 82. Context log

```bash
leanctx log
```

Example:

```text
chk_118  reviewer confirmed retry constraint
chk_116  source payment.rs changed
chk_112  handoff planner → implementation
chk_109  OAuth policy package updated
```

---

# 83. Context inspect

```bash
leanctx inspect chk_118
```

Could show:

```text
parents
sources
packages
ProjectContext delta
sessions
receipts
policy hash
performance
signature
```

---

# 84. Proposed CLI design

Do not let the SDK CLI reproduce today's tool complexity.

A clean conceptual CLI:

```bash
leanctx new
leanctx attach .
leanctx status

leanctx prepare "Implement OAuth"

leanctx checkpoint -m "OAuth plan complete"
leanctx history

leanctx fork reviewer
leanctx diff reviewer
leanctx handoff reviewer
leanctx merge reviewer --knowledge

leanctx seal @acme/auth-context@1.2.0
leanctx install @acme/base-architecture@2

leanctx push
leanctx pull

leanctx inspect
leanctx restore chk_...
```

Exact naming can change.

The principle should not.

---

# 85. CLI vs Engine CLI

The open Engine may continue to expose its lower-level operational interfaces.

The commercial SDK should offer the **high-level lifecycle CLI**.

Do not force the Engine CLI to become the SDK product interface.

---

# 86. Public developer API should have few nouns

Primary SDK nouns:

```text
LeanCTX
ContextWorkspace
ContextSession
ContextSource
ContextPlan
ContextView
ContextCheckpoint
ContextDelta
ContextHandoff
ContextPolicy
ContextReceipt
ContextPackage
```

Resist adding public nouns casually.

---

# 87. The strongest developer sentence

> **Create a context workspace for your agent. LeanCTX keeps the project understanding, sources, reuse, recovery and task history coherent while each session gets only the context it needs.**

Then:

> **Fork the workspace when agents work in parallel. Diff their context, hand off verified state, and merge only what should survive.**

---

# 88. The strongest enterprise sentence

> **LeanCTX Cloud gives every production agent a governed Context Workspace and gives your organization one place to see how context is created, reused, shared and changed.**

---

# 89. The strongest Box comparison

Do not market LeanCTX as “Box for context”.

That is useful internally and in conversations.

Publicly:

```text
Box:
persistent execution environment

LeanCTX:
persistent context environment
```

The products are complementary.

---

# 90. Killer demo #1 — parallel coding agents

Start:

```bash
leanctx new
leanctx attach .
```

Agent understands repo.

Checkpoint:

```bash
leanctx checkpoint -m "baseline"
```

Fork:

```bash
leanctx fork implementation
leanctx fork reviewer
```

Implementation works.

Reviewer starts with baseline context without rereading everything.

Then:

```bash
leanctx diff implementation reviewer
```

Show:

```text
different decisions
different source views
different findings
same underlying project context
```

Handoff implementation → reviewer.

Merge verified findings.

This visually communicates the category.

---

# 91. Killer demo #2 — portable `.ctxpkg`

Create project context:

```bash
leanctx seal @acme/auth-service@1.0
```

On another machine:

```bash
leanctx new --from @acme/auth-service@1.0
```

New agent immediately has:

```text
verified architecture
decisions
gotchas
source references
package dependencies
```

but can recover exact local source from the new checkout.

That is a strong portability story.

---

# 92. Killer demo #3 — production incident

Production agent fails.

Cloud shows receipt:

```text
Agent used:
stale payment policy
```

Click workspace history.

Find checkpoint where stale package entered.

Diff:

```text
@acme/payment-policy
2.3 → 2.2
```

Fix package lock.

Re-run evaluation branch.

Verify outcome.

This demonstrates enterprise value.

---

# 93. Killer demo #4 — strategy evaluation

Fork workspace:

```text
A = default context plan
B = aggressive reuse
C = full raw context
```

Run same eval set.

Performance Board:

```text
A: 97% quality / $0.83
B: 96% quality / $0.49
C: 97% quality / $2.11
```

The product answers:

> Which context strategy should we deploy?

---

# 94. SDK roadmap built around Workspace

## Phase W0 — contract

Define:

```text
ContextWorkspace
ContextCheckpoint
ContextDelta
source anchors
workspace identity
provider interfaces
```

## Phase W1 — local workspace

Build:

```text
create/open
attach source
session
prepare
status
ProjectContext
receipt
```

## Phase W2 — checkpoint

Wrap/adapt existing Context Snapshot foundation.

Build:

```text
checkpoint
history
restore
immutable state segments
```

## Phase W3 — fork

Build:

```text
fork
lineage
copy-on-write state refs
policy inheritance
```

## Phase W4 — diff

Generalize existing session diff.

Build:

```text
WorkspaceDelta
checkpoint diff
source diff
knowledge diff
policy diff
package diff
performance diff
```

## Phase W5 — package integration

Build:

```text
workspace.install(ctxpkg)
workspace.seal()
workspace.from_package()
package lock integration
```

## Phase W6 — handoff

Build:

```text
handoff
receive
apply
audit
```

## Phase W7 — merge

Start narrow:

```text
knowledge-only three-way merge
```

Then carefully add:

```text
decision merge
handoff merge
advanced state merge
```

## Phase W8 — Cloud remote

Build:

```text
push
pull
remote lineage
receipts
Performance Board
```

## Phase W9 — shared context

Build:

```text
Cloud ProjectContext
handoff delivery
team access
workspace branches
```

## Phase W10 — adaptive intelligence

Build:

```text
warm sets
organization strategy learning
planner recommendations
context health
```

---

# 95. What should be built first

The highest-risk mistake would be starting with `fork()` because it sounds exciting.

The correct order is:

1. define Workspace state precisely;
2. create/open workspace;
3. make Session use Workspace;
4. make Checkpoint deterministic;
5. then Fork.

Otherwise fork semantics will remain undefined.

The first commercial SDK milestone should therefore be:

> **One persistent ContextWorkspace that can run multiple ContextSessions and checkpoint its durable state.**

Once that is correct, everything else compounds naturally.

---

# 96. Migration from current code

Existing capabilities should map rather than be rewritten wholesale.

| Existing LeanCTX | Workspace future |
|---|---|
| Project hash | Source identity / legacy project binding |
| SessionState | ContextSession state |
| ProjectKnowledge | ProjectContext backend seed |
| Knowledge relations | ProjectContext graph |
| Session Playbook | Durable session delta input |
| SessionDiff | ContextDelta foundation |
| Context Snapshot | ContextCheckpoint foundation |
| Time Machine | Workspace history UI |
| `.ctxpkg` | ContextPackage / template / dependency |
| `ctxpkg.lock` | Workspace package lock |
| Local package registry | PackageProvider |
| `ctx_handoff` | ContextHandoff foundation |
| `ctx_share` | legacy local transfer / future provider |
| Context Bus | legacy local coordination / Cloud sync inspiration |
| Context IR | receipt / lineage source |
| Context Ledger | ContextPlan / receipt evidence |
| Savings ledger | performance receipt input |
| Recovery archive | RecoveryRef backend |

This is a favorable starting point.

---

# 97. Do not make the SDK depend on historical names

The implementation can reuse current modules.

The public SDK should not expose internal historical terminology merely for convenience.

Bad:

```python
workspace.ctx_knowledge(...)
workspace.context_os_bus(...)
```

Good:

```python
workspace.context
workspace.handoff(...)
workspace.checkpoint(...)
```

The new product surface is an opportunity to simplify.

---

# 98. Open-source Engine evolution

The Engine should increasingly become:

> **the context state machine's execution substrate.**

Good future Engine work:

```text
faster content-addressed store
better recovery
multi-source revision helpers
stronger package verification
better local indexes
stable Engine API
better deterministic serialization
safe snapshot primitives
source adapters at mechanism level
```

The Engine does not need to contain high-level Workspace business logic.

---

# 99. Open contracts to extract

Potential Apache protocol package:

```text
ContextSourceRef
SourceRevision
RecoveryRef
PackageManifest
Receipt schema
Checkpoint envelope
Handoff envelope
Workspace event schema
```

Open contracts create interoperability.

Commercial SDK owns behavior.

---

# 100. Licensing implications

This architecture is well suited to the agreed three-product strategy.

## Engine

Apache 2.0.

The already-open package/snapshot implementations remain open.

No community rights are removed.

## SDK

BSL 1.1 + commercial production license.

The new `ContextWorkspace` product is born under these terms from the first commit.

No surprise relicensing.

## Cloud

Proprietary.

## `.ctxpkg`

Open specification / implementation.

This is a strong balance between:

```text
community trust
ecosystem
commercial protection
developer adoption
enterprise monetization
```

---

# 101. Competitive moat

The workspace model improves the moat.

## Engine moat

- adoption;
- performance;
- source mechanisms;
- community.

## SDK moat

- Workspace semantics;
- Planner;
- fork/diff/merge quality;
- ProjectContext lifecycle;
- context invalidation;
- policies;
- framework integrations;
- developer experience.

## Cloud moat

- workspace lineage;
- organization graph;
- performance history;
- context strategy data;
- shared context;
- governance;
- adaptive optimization.

## Format moat

`.ctxpkg` can become an ecosystem standard even if the implementation format itself is open.

That is strategically desirable.

---

# 102. The key commercial insight

The product should not sell:

> “Access to our context file format.”

It should sell:

> **Reliable management of live context state inside production agents.**

That is much harder to reproduce.

---

# 103. What not to build

Do not let Workspace become an excuse for scope creep.

LeanCTX still should not build:

```text
VMs
containers
agent scheduler
generic task board
generic Git hosting
generic secrets manager
generic observability
generic vector database
full workflow orchestration
```

Integrate with those.

Own context state.

---

# 104. Naming evaluation

## `ContextWorkspace`

Strengths:

- immediately understandable;
- implies persistent working state;
- natural parent of Session;
- works for coding and non-coding;
- fork/diff/checkpoint verbs feel natural.

Weakness:

- “workspace” is widely used in developer products;
- must be qualified as Context Workspace.

Recommendation:

> **Use `ContextWorkspace` as the canonical SDK object.**

Public marketing can often shorten it to:

> **workspace**

once context is obvious.

Alternatives are weaker:

- `ContextSpace` — too abstract.
- `ContextRepo` — too Git-centric.
- `ContextEnvironment` — conflicts with execution/config environments.
- `ContextState` — technically accurate but poor product noun.
- `ContextProject` — too narrow.

---

# 105. Naming hierarchy recommendation

```text
LeanCTX
  product family

LeanCTX Engine
  open mechanisms

LeanCTX SDK
  commercial SDK

ContextWorkspace
  central SDK resource

ContextSession
  one task

ContextCheckpoint
  immutable state point

ContextDelta
  difference

ContextHandoff
  scoped transfer

ContextPackage (.ctxpkg)
  sealed portable artifact

LeanCTX Cloud
  workspace remote/control plane
```

This is coherent.

---

# 106. Proposed one-page SDK docs mental model

```markdown
# LeanCTX SDK

The Context SDK for AI Agents.

A LeanCTX Workspace keeps the context state behind your agent persistent,
inspectable and reusable across tasks.

Create a workspace:

    workspace = leanctx.workspace("./project")

Run a task:

    session = workspace.session("Implement OAuth")
    context = await session.prepare()

Checkpoint useful state:

    checkpoint = await workspace.checkpoint()

Fork for another agent:

    reviewer = await workspace.fork("reviewer")

Share only what matters:

    await workspace.handoff(reviewer)

Package reusable context:

    await workspace.seal("@acme/auth-context")
```

This is dramatically easier to understand than starting with dozens of tools.

---

# 107. Proposed public narrative

## Problem

Agents repeatedly rebuild context:

```text
same repository
same architecture
same decisions
same failed attempts
same source discovery
```

## Product

> **Give the agent a persistent Context Workspace.**

Each task gets only the context it needs.

Useful project understanding survives.

Exact source remains recoverable.

Parallel agents can fork the same context state.

## Proof

Less repeated context.

Better continuity.

Explicit lineage.

Measurable receipts.

---

# 108. Proposed strategic tagline extensions

Keep:

> **Give every agent a context system.**

Developer explanation:

> **Give your agent a context workspace.**

Architecture:

> **Your framework runs the agent. LeanCTX runs its context.**

State thesis:

> **Agents can have different jobs. They should not have to rediscover the same project.**

Fork thesis:

> **Branch the work without rebuilding the context.**

Package thesis:

> **Context you can version, move and verify.**

---

# 109. Workspace vs memory positioning

Memory asks:

> “What should the agent remember?”

Workspace asks:

> “What is the current context state of this body of work?”

That includes:

```text
memory
sources
source versions
derived views
policy
packages
lineage
receipts
handoffs
recovery
```

Memory becomes one component.

---

# 110. Workspace vs RAG

RAG asks:

> “What documents match this query?”

Workspace asks:

> “What context should this agent receive now, given its task, project state, prior work, policies and source revisions?”

Broader and more deliberate.

---

# 111. Workspace vs agent framework

Framework:

```text
who acts next?
what tool runs?
what transition occurs?
```

Workspace:

```text
what does that actor know?
what can be reused?
what must be recovered?
what survives afterward?
```

Clean boundary.

---

# 112. Workspace vs sandbox

Sandbox:

```text
where can the agent execute safely?
```

Workspace:

```text
what context state does the agent operate with?
```

Complementary.

---

# 113. Why this could define the category

Context Engineering today is often described as a collection of techniques:

```text
retrieval
memory
summarization
tool design
prompt assembly
compression
```

LeanCTX can turn it into an infrastructure object:

> **Context is state. State needs lifecycle management.**

That means:

```text
identity
versioning
branching
diff
provenance
policy
recovery
portability
observability
```

This is a durable category thesis.

---

# 114. The deeper strategic statement

The real product thesis may ultimately be:

> **AI agents should not manage context as disposable prompt text. Context should be treated as a versioned, policy-aware state resource.**

LeanCTX is the system that provides that resource.

That is much bigger than token compression.

Token efficiency remains an immediate measurable benefit.

---

# 115. North-star architecture

```text
                           ORGANIZATION
                               │
                               ▼
                        LEANCTX CLOUD
                remote · policy · performance
                        sync · governance
                               │
                               ▼
                    ┌─────────────────────┐
                    │  ContextWorkspace   │
                    │                     │
                    │ durable state       │
                    │ lineage             │
                    │ packages            │
                    │ sources             │
                    │ policies            │
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
        ContextSession   ContextSession   ContextSession
          Planner          Builder          Reviewer
              │                │                │
              └────────────────┼────────────────┘
                               │
                               ▼
                         LEANCTX SDK
                    planning · lifecycle
                               │
                               ▼
                        LEANCTX ENGINE
                read · search · cache · recover
                               │
              ┌────────────────┼────────────────┐
              ▼                ▼                ▼
             Git             Jira              DB
                               │
                               ▼
                        EXECUTION LAYER
                  Box / E2B / local / customer
                               │
                               ▼
                             MODEL
```

---

# 116. North-star state model

```text
Workspace Head
     │
     ▼
Checkpoint C ──────────────┐
     │                     │
     │ fork                │ fork
     ▼                     ▼
Checkpoint D          Checkpoint E
     │                     │
     ▼                     ▼
Session impl          Session review
     │                     │
     ▼                     ▼
Checkpoint F          Checkpoint G
     │                     │
     └──────── merge ──────┘
               │
               ▼
          Checkpoint H
          parents=[F,G]
               │
               ▼
        seal / publish
               │
               ▼
        @acme/context
          .ctxpkg
```

Cloud visualizes this.

---

# 117. Key data-model recommendation

A future Workspace Checkpoint should likely contain:

```text
schema_version
checkpoint_id
state_digest
workspace_id
parents[]
created_at
sdk_version
engine_protocol_version

source_anchors[]
project_context_ref
policy_ref
package_lock_ref
session_delta_refs[]
receipt_refs[]
handoff_refs[]
derived_view_manifest_ref
recovery_manifest_ref

signature
```

Do not implement this blindly.

It is the target conceptual contract to validate.

---

# 118. Key storage recommendation

State segments should be:

```text
immutable
content-addressed
deduplicated
signed where transported
```

Mutable workspace state should primarily be:

```text
refs + head + working delta
```

This architecture makes:

```text
checkpoint
fork
sync
restore
package export
```

cheap and coherent.

---

# 119. Key privacy recommendation

Source content should not be implicitly embedded in every checkpoint.

Prefer:

```text
SourceAnchor
+
RecoveryRef
+
optional protected blob
```

This keeps checkpoints small and safer.

For offline portability, explicit `seal(include_blobs=...)` can package required content.

---

# 120. Key Cloud recommendation

Do not start Cloud by implementing every workspace feature.

Start with:

```text
receipts
workspace IDs
checkpoint lineage
performance
```

Then add:

```text
packages
handoffs
shared ProjectContext
```

Then:

```text
governance
organization intelligence
```

This reduces implementation risk.

---

# 121. Key SDK recommendation

Do not start SDK v1 with:

```text
fork
merge
cloud
```

Start with:

```text
ContextWorkspace
ContextSession
ContextPlan
ContextCheckpoint
```

If these are excellent, the rest follows.

---

# 122. Key Engine recommendation

The Engine should expose stable mechanisms needed by the SDK:

```text
Source read
Source revision
View create
Search
Recover
Hash
Package verify/materialize
Object store
Snapshot primitive
```

The SDK should stop reaching into arbitrary Engine internals.

This is essential for separate repositories.

---

# 123. Inter-repository contract

Target dependency:

```text
Cloud
   ↓
SDK
   ↓
Engine Protocol
   ↓
Engine
```

Protocol must be versioned.

Example:

```text
Engine Protocol 1.x
SDK 1.x
Cloud API 1.x
```

Avoid requiring matching Git commits.

---

# 124. First architecture RFCs to write

Before implementation:

## RFC 001 — ContextWorkspace

Define:

```text
identity
lifecycle
state
invariants
local storage boundary
```

## RFC 002 — SourceAnchor

Generalize Git anchor.

## RFC 003 — ContextCheckpoint V2

Define:

```text
DAG
state digest
state refs
```

## RFC 004 — Engine Contract

Define SDK ↔ Engine interface.

## RFC 005 — `.ctxpkg` Workspace Integration

Define:

```text
install
seed
seal
lock
```

## RFC 006 — Fork / Diff Semantics

Before implementing merge.

---

# 125. Implementation discipline

For every feature ask:

> Is this necessary for the Workspace resource lifecycle?

If not:

> probably not SDK priority.

This prevents the next generation of LeanCTX from again accumulating disconnected features.

---

# 126. Product priority ranking

## Tier 1 — must exist

```text
Workspace
Session
Plan
Checkpoint
SourceAnchor
Receipt
Package integration
```

## Tier 2 — makes it differentiated

```text
Fork
Delta
Handoff
Policy
Recovery
ProjectContext
```

## Tier 3 — makes it enterprise-grade

```text
Cloud remote
shared context
governance
performance
package registry
```

## Tier 4 — long-term moat

```text
semantic merge
adaptive planner
warm sets
organization learning
context blame
context health
```

---

# 127. The biggest technical risks

## Risk 1 — mutable state complexity

Mitigation:

immutable segments + explicit working delta.

## Risk 2 — merge becomes impossible to reason about

Mitigation:

handoff-first, narrow merge modes, three-way merge.

## Risk 3 — source revisions are inconsistent

Mitigation:

adapter-level revision contracts and conservative volatile handling.

## Risk 4 — Cloud becomes mandatory

Mitigation:

provider abstraction + local-first invariant.

## Risk 5 — `.ctxpkg` becomes overloaded

Mitigation:

do not redesign format prematurely; keep package role separate from live state.

## Risk 6 — workspace becomes a disguised agent framework

Mitigation:

never own scheduling/task orchestration.

## Risk 7 — too many public concepts

Mitigation:

Workspace is the primary noun; everything else lives under it.

---

# 128. The biggest product risk

The product could still be explained technically:

> “We have versioned context workspaces, graph-native packages and checkpoint DAGs.”

That would miss the point.

The user value is:

> **Your agents stop rebuilding project understanding from scratch.**

And:

> **You can finally treat context as durable infrastructure instead of disposable prompt text.**

Everything technical supports that.

---

# 129. The one sentence to test every SDK feature

Ask:

> **Does this make it easier for an agent to start with, maintain or transfer the right project understanding without rebuilding it from scratch?**

If no:

probably not core LeanCTX SDK.

---

# 130. Final category thesis

LeanCTX started by making context **leaner**.

The next step is making context **stateful**.

The category can evolve from:

```text
context optimization
```

to:

```text
context infrastructure
```

without abandoning the efficiency story.

The final thesis:

> **Context is not prompt text. It is a versioned state resource.**

And the product manifestation:

> **Give every agent a Context Workspace.**

---

# 131. Canonical final definitions

## LeanCTX

> **LeanCTX is context infrastructure for AI agents.**

## LeanCTX Engine

> **The open-source engine that reads, searches, shapes, caches and recovers context locally.**

## LeanCTX SDK

> **The Context SDK for AI Agents. It gives every agent a persistent Context Workspace and manages how context is selected, reused, recovered, versioned and transferred across its work.**

## ContextWorkspace

> **A persistent, forkable, inspectable and portable context environment for an agent or project.**

## ContextSession

> **A bounded unit of agent work inside a Context Workspace.**

## ContextCheckpoint

> **An immutable point-in-time state of a Context Workspace that can be inspected, restored, forked and compared.**

## ContextDelta

> **A semantic description of how two context states differ.**

## ContextHandoff

> **A deliberate, scoped transfer of decisions, evidence and source references between sessions or agents.**

## `.ctxpkg`

> **An open, signed, versioned and composable package for moving reusable context between workspaces and systems.**

## LeanCTX Cloud

> **The control plane and remote for synchronizing, observing and governing Context Workspaces across production agents and organizations.**

---

# 132. Final product model

```text
USING AN AGENT?
────────────────────────────────────────
LeanCTX Engine
Open source
Make your existing AI tools more context-efficient.


BUILDING AN AGENT?
────────────────────────────────────────
LeanCTX SDK
ContextWorkspace
Stop building context infrastructure yourself.


RUNNING AGENTS IN PRODUCTION?
────────────────────────────────────────
LeanCTX Cloud
Share, observe and govern Context Workspaces.
```

---

# 133. The final conceptual loop

```text
Create a workspace.
Attach the project.
Run a task.
Keep what remains useful.
Checkpoint the state.
Fork when work diverges.
Hand off what matters.
Diff what changed.
Merge only what should survive.
Seal reusable context.
Sync when the organization needs to share it.
```

That is a product lifecycle.

Not a feature list.

---

# 134. The strongest strategic synthesis

Box demonstrates that a powerful infrastructure product becomes easy to understand when the user can point to **the resource being managed**.

For Box:

> the machine.

For Git:

> the repository.

For LeanCTX:

> **the Context Workspace.**

The existing LeanCTX codebase already contains unusually many pieces required to make this real:

```text
ctxpkg
package registry
package dependencies
package lockfile
signatures
graph composition
contradiction detection
context snapshots
snapshot parent lineage
restore
publish/import
session state
session diff
playbook deltas
recovery references
context IR
context ledger
receipts
```

The opportunity is therefore not to add another major subsystem.

It is to **make these subsystems converge around one coherent resource**.

If done correctly, LeanCTX can move from:

> “a very powerful collection of context-engineering capabilities”

to:

> **“the infrastructure layer that gives an agent durable context state.”**

That is significantly easier to explain.

It is significantly easier to build an SDK around.

It gives `.ctxpkg` a natural role.

It gives Cloud a natural role.

It clarifies multi-agent collaboration.

It creates a foundation for branching, evaluation, recovery, governance and performance.

And most importantly:

> **It makes the category tangible.**

---

# Appendix A — Evidence from the current LeanCTX repository

The recommendations in this concept intentionally build on existing capabilities rather than assuming a greenfield rewrite.

Relevant current implementation areas:

```text
docs/specs/context-package-v2.md
rust/src/core/context_package/
rust/src/core/context_package/content.rs
rust/src/core/context_package/builder.rs
rust/src/core/context_package/composition.rs
rust/src/core/context_package/registry.rs
rust/src/core/context_package/lockfile.rs

docs/concepts/context-time-machine.md
rust/src/core/context_snapshot/
rust/src/core/context_snapshot/types.rs

rust/src/core/session/playbook.rs
rust/src/core/session_diff.rs

docs/reference/08-multi-agent.md
rust/src/tools/ctx_handoff.rs
rust/src/core/context_os/
```

Current `.ctxpkg` concepts already include:

```text
version
scope
dependencies
conflicts
integrity
provenance
signatures
graph-native context
knowledge/session/gotcha layers
composition
local registry
auto-load
lockfile
```

Current snapshot concepts already include:

```text
snapshot identity
parent
git anchor
project identity
lineage
ledger
session
ROI
signature
restore
publish/import
timeline
```

These should be treated as foundations.

---

# Appendix B — Box references and extracted product-design principles

References:

- https://box.ascii.dev/
- https://docs.ascii.dev/box/snapshots
- https://docs.ascii.dev/box/api/v1
- https://docs.ascii.dev/box/sdks/overview

Useful principles, not product features to copy blindly:

1. **One primary resource**
   - Box → machine
   - LeanCTX → ContextWorkspace

2. **Lifecycle verbs instead of subsystem jargon**
   - create, fork, stop/resume, snapshot
   - create, checkpoint, fork, diff, handoff, restore, seal

3. **Immutable snapshot backing**
   - efficient persistence and reproducibility.

4. **Cheap forks through shared backing state**
   - apply content-addressed structural sharing to context.

5. **Templates separate from credentials/environment**
   - `.ctxpkg` / ContextKit separate from runtime credentials.

6. **Fast restore with background warming**
   - workspace metadata immediately usable, heavier indexes warm lazily.

7. **Programmatic API first**
   - high-level SDK resource model, not only CLI commands.

LeanCTX should borrow these design principles while remaining firmly scoped to context infrastructure.

---

# Appendix C — Public API strawman

```python
from leanctx import LeanCTX, RepoSource

lean = LeanCTX()

workspace = lean.workspace.create(
    "acme/payment"
)

workspace.attach(
    RepoSource("./payment-service")
)

session = workspace.session(
    "Investigate retry failures",
    budget=24_000
)

plan = await session.plan()
prepared = await session.prepare(plan)

result = await agent.run(prepared.context)

receipt = await session.complete(result)

checkpoint = await workspace.checkpoint(
    "retry root cause identified"
)

review = await workspace.fork(
    "review",
    from_=checkpoint
)

delta = await review.diff(workspace)

handoff = await workspace.handoff(
    review,
    include=["decisions", "evidence", "sources"]
)

pkg = await workspace.seal(
    "@acme/payment-context",
    version="2.0.0"
)

await workspace.push()
```

The precise syntax is subject to RFC design.

The shape is the important part.

---

# Appendix D — CLI strawman

```bash
# Workspace lifecycle
leanctx new acme/payment
leanctx attach .
leanctx status

# Agent work
leanctx prepare "Investigate retry failures"

# State lifecycle
leanctx checkpoint -m "root cause found"
leanctx history
leanctx inspect chk_118
leanctx restore chk_118

# Parallel context
leanctx fork reviewer
leanctx diff reviewer
leanctx handoff reviewer
leanctx merge reviewer --knowledge

# Portable context
leanctx install @acme/base-architecture@2
leanctx seal @acme/payment-context@2.0.0

# Cloud
leanctx push
leanctx pull
```

---

# Appendix E — Architecture review checklist

Before a Workspace-related feature is approved:

- [ ] Does it belong to Engine, SDK or Cloud?
- [ ] Is it a mechanism or context lifecycle semantic?
- [ ] Does it strengthen the ContextWorkspace abstraction?
- [ ] Is the durable state explicitly defined?
- [ ] Is transient state excluded?
- [ ] Is source revision identity defined?
- [ ] Does provenance survive?
- [ ] Is recoverability preserved?
- [ ] Is Cloud optional?
- [ ] Are credentials kept outside packages/checkpoints?
- [ ] Are forks copy-on-write / structurally shared where practical?
- [ ] Are checkpoints immutable?
- [ ] Are package dependencies reproducible?
- [ ] Are contradictions surfaced?
- [ ] Is merge narrower than blind state concatenation?
- [ ] Could handoff solve the problem more safely than merge?
- [ ] Is the public API simpler than the internal implementation?
- [ ] Are we accidentally building orchestration or compute infrastructure?
- [ ] Can the capability be demonstrated in a production-agent workflow?
- [ ] Does it create measurable context value?

---

# Appendix F — Immediate decision list

The following decisions should now be made explicitly before major SDK implementation:

1. Approve `ContextWorkspace` as the canonical SDK parent resource.
2. Keep `.ctxpkg` open and treat it as the portable/sealed artifact layer.
3. Define `ContextCheckpoint` as the SDK-level immutable state concept.
4. Generalize Git anchors into multi-source `SourceAnchor`s.
5. Separate `checkpoint_id` from `state_digest`.
6. Design checkpoint lineage as a DAG to make future merging possible.
7. Keep current Engine snapshot/package code as foundation.
8. Freeze/de-emphasize the legacy Apache in-process SDK as Engine embedding.
9. Define a stable Engine Protocol consumed by the new BSL SDK.
10. Build Workspace + Session + Checkpoint before Fork.
11. Build Fork before sophisticated Merge.
12. Keep Handoff the default multi-agent transfer mechanism.
13. Make Cloud the workspace remote/control plane.
14. Start Cloud with receipts + lineage + Performance Board.
15. Use existing `.ctxpkg` lockfile/versioning for reproducible Context Kits/Templates.
16. Do not create `.ctxpkg v3` until concrete Workspace requirements justify it.
17. Keep secrets/credentials outside workspace packages and checkpoint transport.
18. Preserve local-first operation.
19. Treat source content as referenced external truth by default.
20. Make “Context is versioned state, not disposable prompt text” the long-term product thesis.

---

**End of master concept**
