ch hab grad noch mit joel gesprochen. er hat gesagt, was wir eigentlich hier bauen ist ein SDK, welcher unternehmen in ihre ai agents integrieren können und somit die volle power von leanctx nutzen können. also dass quasi leanctx wie der toolkasten ist mit allen funktionen die wir haben. ich kann es nicht richitg wiedergeben. aber er meinte es nennt sich sdk, also so wie anthropic und openai. er hat auch gesagt vielleicht können wir das auch wrappen. und wir haben doch sowas schon in diese richtung bei leanctx eingebaut? ich habe bereits schon einen custom agent gebaut und damit rumexperimentiert. ich glaube das könnte die zukunft von leanctx sein. wir müssen uns nur überlegen wo wir die linie zwischen OSS und paid machen. weill ich möchte nicht alles gratis rausgeben!

hier ist der report von dem was ich gemacht habe:

Report: Real-World Evidence System + Agent-Orchestrierung
1. Was wir gebaut haben
Einen neuen CLI-Befehl lean-ctx evidence realworld, der beweist, dass LeanCTX echte Kosteneinsparungen bei AI-Agent-Workflows erzielt — mit echten API-Calls, nicht simuliert.

2. Wie der Evidence-Test funktioniert (technisch)
Architektur: Ein A/B-Test mit 10 echten OpenAI API-Calls.

ARM A (Baseline): 5 sequentielle API-Calls OHNE lean-ctx Kompression
ARM B (Treatment): 5 sequentielle API-Calls MIT lean-ctx Kompression
Jeder Call baut auf dem vorherigen auf (Multi-Turn Konversation).
Die 5 Turns pro Arm simulieren einen echten Agent-Coding-Workflow:

Turn	Was passiert	Baseline (roh)	Treatment (komprimiert)
1
Projekt-Struktur erkunden
Volles find . -name "*.rs" Listing
Komprimierter Verzeichnisbaum
2
Quelldateien lesen (3 grösste)
Voller Quellcode aller 3 Dateien
outline Mode: nur Signaturen + Struktur
3
Symbole suchen (rg)
Volles ripgrep-Ergebnis
Shell-Kompression (Pattern-basiert)
4
Tests ausführen (cargo test)
Volle Test-Ausgabe (gecapped auf 500 Zeilen)
Shell-Kompression (nur Zusammenfassung)
5
Final Analysis Request
Gleiche Frage an beide
Gleiche Frage an beide
Kritisch: Kontext akkumuliert. Turn 3 enthält alles von Turn 1+2+3. Turn 5 enthält den gesamten bisherigen Kontext. Das bildet exakt ab, wie ein echter AI-Agent arbeitet (Chat-History wächst mit jedem Schritt).

3. Provider-Cache-Tracking (der ehrliche Teil)
OpenAI cached automatisch repetitive Prompt-Segmente (System-Prompt, vorherige Turns). In der API-Response steht:

{
  "usage": {
    "prompt_tokens": 30934,
    "prompt_tokens_details": {
      "cached_tokens": 20480  // <-- DAS lesen wir aus
    },
    "completion_tokens": 445
  }
}
Unsere Kostenformel berücksichtigt das korrekt:

Kosten = (prompt - cached) × input_preis 
       + cached × cache_read_preis (50% Discount bei OpenAI)
       + output × output_preis
Das macht den Test KONSERVATIV — denn Provider-Caching hilft der Baseline mehr (mehr repetitiver Content = mehr Cache-Hits). Trotzdem gewinnt lean-ctx deutlich.

4. Echte Ergebnisse (3 Szenarien, 30 API-Calls total)
Szenario	Target-Verzeichnis	Baseline Tokens	Treatment Tokens	Token-Einsparung	Kosten-Einsparung
Klein
src/core/gain (8 .rs Dateien)
99.203
14.857
85.0%
78.9% ($0.212)
Mittel
src/shell (27 .rs Dateien)
139.115
14.016
89.9%
84.3% ($0.312)
Gross
src/cli/dispatch (121 .rs Dateien)
132.637
11.897
91.0%
86.0% ($0.305)
Provider-Cache-Effekte (Baseline bevorteilt!):

Baseline: 68.864 – 99.072 Tokens gecached (OpenAI cached die repetitiven Turns)
Treatment: 6.656 – 9.856 Tokens gecached (weniger repetitiver Content = weniger Cache)
Trotzdem 79-86% günstiger — weil lean-ctx den Content VOR dem Senden komprimiert
Modell: gpt-4o-mini, Endpoint: https://api.openai.com/v1/chat/completions

5. Agent-Orchestrierung (Codex CLI Agents)
Nach dem Evidence-Test habe ich 5 parallele Codex CLI Agents gestartet um die nächsten Sprint-Tasks umzusetzen:

Befehlsformat pro Agent:

cd /path/to/project && codex exec --approve-for-me "
<Aufgabe detailliert beschrieben>
" </dev/null 2>&1
Jeder Agent läuft als eigener Prozess mit block_until_ms: 0 (Cursor backgrounded ihn). lean-ctx bleibt aktiv für Kompression + Savings-Tracking.

Ergebnisse der 5 Agents:

Agent	Aufgabe	Dauer	Ergebnis
Agent 1
HTML Evidence Report Generator
17 Min
lean-ctx evidence report --input <json> --output <html> — 15KB standalone HTML mit Thinkery-Branding, CSS-Bar-Charts, Print-ready
Agent 2
Enterprise Pilot-Setup Script
8 Min
scripts/pilot-setup.sh — 550 Zeilen, idempotent, --uninstall, GitHub-Release-Download, SHA-256-Verify, Cursor MCP-Setup
Agent 3
Fix Integration Tests
16 Min
Bestätigt: 7/7 Tests bestehen (waren durch vorherigen Commit bereits gefixt)
Agent 4
Context Kit Code-Review
23 Min
lean-ctx kit load code-review — Kit-Format (TOML), Loader mit Prioritäts-Kette, 4 Tests, CLI-Commands
Agent 5
Sprint Tracker + One-Pager
4 Min
Tracker aktualisiert, Customer One-Pager auf Deutsch erstellt
6. Was das beweist
LeanCTX spart echtes Geld — 79-86% weniger API-Kosten, verifiziert durch OpenAI's eigene Usage-Metriken
Der Vorteil wächst mit Projekt-Grösse — je grösser das Projekt, desto mehr Kompression (85% → 91%)
Konservativ gemessen — Provider-Caching hilft der Baseline massiv, trotzdem gewinnt lean-ctx
Reproduzierbar — jeder mit einem OpenAI API-Key kann lean-ctx evidence realworld --target <dir> ausführen
Hochrechnung: Bei 100 Agent-Workflows/Tag spart ein Entwickler ~$636/Monat
7. Technischer Stack
Sprache: Rust (Modul evidence_realworld.rs, ~550 LOC)
HTTP-Client: ureq v3 (synchron, TLS)
Token-Counting: tiktoken (lokal, kein API-Call)
Kompression: Tree-sitter AST (outline/signatures Mode), Shell-Pattern-Engine (95+ Patterns)
Pricing: Embedded ModelPricing mit allen Provider-Tarifen (Anthropic, OpenAI, Gemini)
Retry: Exponentielles Backoff bei 429 Rate-Limits (30s, 60s, 90s)


Ja. Ich glaube, Joel hat hier etwas ausgesprochen, das wir in den letzten Tagen eigentlich schon gespürt haben, aber noch nicht sauber benannt hatten.

Ich würde es allerdings leicht anders formulieren:

LeanCTX ist nicht einfach ein SDK.

LeanCTX ist eine Context Runtime, die über SDKs, Wrapper, Proxy und MCP in bestehende AI-Agents integriert wird.

Das ist ein wichtiger Unterschied.

Ein SDK ist die Entwicklerschnittstelle.

Die Runtime ist das eigentliche Produkt.

Und Thinkery ist die kommerzielle Organisationsschicht darüber.

Für mich sieht das inzwischen so aus:

Custom Agent
OpenAI Agents SDK
Claude Agent SDK
LangGraph
CrewAI
Vercel AI SDK
Eigener Agent
        │
        ▼
   LeanCTX SDK / Wrapper
        │
        ▼
   LeanCTX Runtime
(Context, Kits, Memory,
Compression, Evidence,
Routing ...)
        │
        ▼
LLM Provider


             optional
                │
                ▼
        Thinkery Platform
(Control, Teams,
Governance, Billing,
Private Kits ...)

Das ist brutal verständlich.

Und das Wichtigste:

Niemand muss seine Agenten neu schreiben.

Joel hat vermutlich genau das gemeint

Ein Unternehmen baut heute beispielsweise einen eigenen Coding Agent.

Heute sieht das ungefähr so aus:

agent = OpenAIAgent(...)
agent.run(task)

Mit LeanCTX sollte das irgendwann so aussehen:

agent = OpenAIAgent(...)


agent = LeanCTX.wrap(agent)


agent.run(task)

Oder:

ctx = LeanCTX(project=".")


result = ctx.run(agent, task)

Oder:

client = LeanCTX.wrap(OpenAI())

Der Entwickler benutzt weiterhin "sein" Agent Framework.

LeanCTX liefert:

Context Selection
Compression
Memory
Context Kits
Evidence
Cost Tracking
Context Reuse

Das ist ein extrem einfacher Mental Model.

Und weißt du, was das Verrückte ist?

Du hast das bereits gebaut.

Nicht komplett.

Aber überraschend viel.

Ich habe mir gerade nochmals den aktuellen Stand angeschaut.

Im Repository existiert inzwischen tatsächlich ein eigenes lean-ctx-sdk, ein separates lean-ctx-protocol sowie eine akzeptierte SDK-Embedding-RFC. Die Rust-SDK beschreibt LeanCTX ausdrücklich als in-process embedding façade, damit Anwendungen den Context Engine direkt einbetten können, anstatt über CLI oder MCP zu gehen.

Das ist kein Zukunftsdokument mehr.

Das existiert.

Und ihr habt bereits Wrapper gebaut

Das war mir ehrlich gesagt vorher nicht bewusst.

Im aktuellen Guide gibt es bereits:

Python SDK
TypeScript SDK
Vercel AI SDK Middleware
LiteLLM Callback
LangChain Integration
Proxy Mode

Das ist genau diese Richtung.

Sogar der Vercel-Adapter ist bereits als Wrapper gedacht:

withLeanCtx(openai(...))

und LiteLLM kann LeanCTX als Compression Sidecar verwenden.

Joel beschreibt also nicht irgendeinen Pivot.

Er beschreibt die Produktisierung dessen, was bereits da ist.

Und genau DAS gefällt mir

Weil plötzlich alles Sinn ergibt.

Früher

LeanCTX war:

CLI mit 79 MCP Tools.

Das ist technisch geil.

Aber kein Mensch versteht das.

Heute

LeanCTX wird:

The Context SDK for AI Agents.

Jeder Entwickler versteht sofort:

"Ich kann LeanCTX in meinen Agent integrieren."

Das ist tausendmal einfacher.

Ich glaube sogar, dass das eure Website komplett verändert

Heute könnte dort stehen:

LeanCTX

The Context SDK for AI Agents.

Integrate LeanCTX into any custom AI agent to add:

Context Selection
Context Compression
Reusable Context Kits
Cost Measurement
Verified Evidence

Works with:

OpenAI Agents
Claude Agents
LangGraph
Vercel AI SDK
LiteLLM
your own agents

Jeder versteht das.

Und das ist auch viel näher

Das ist keine Science Fiction.

Das ist:

"Hier ist ein SDK."

Das kennt jeder Entwickler.

Aber jetzt kommt der wichtige Teil

LeanCTX darf NICHT zum Agent SDK werden.

Das wäre falsch.

OpenAI baut Agent SDK.

Anthropic baut Agent SDK.

LangGraph ist Agent Runtime.

CrewAI ist Agent Runtime.

Das brauchen wir nicht nochmals.

Unser SDK muss immer beantworten:

Wie bekommt der Agent den richtigen Context?

Nicht:

Wie startet der Agent?

Deshalb würde ich den Scope brutal klein halten

Der LeanCTX SDK sollte am Anfang nur fünf Dinge versprechen.

1. Context
ctx.prepare(...)

Der Agent bekommt den richtigen Context.

2. Kits
ctx.load_kit(...)

Der Agent bekommt Domain Knowledge.

3. Evidence
ctx.receipt(...)

Der Run wird dokumentiert.

4. Measurement
ctx.compare(...)

Baseline gegen Treatment.

5. Wrapping
agent = ctx.wrap(agent)

Mehr nicht.

Das reicht.

Und das passt PERFEKT zu eurem Pilot PDF

Eigentlich erzählt euer PDF bereits genau diese Geschichte.

Nur ohne das Wort SDK.

Auf Seite 3 steht:

LeanCTX wird in einen bestehenden AI-Workflow integriert.

Für Nutzer und Fachprozess ändert sich nichts.

Die bestehende Architektur, Daten und Fachlogik bleiben bestehen.

LeanCTX misst, reduziert, verwendet wieder und weist Einsparungen aus.

Das IST die Business-Übersetzung eines SDK.

Der Business-Mensch muss nie das Wort SDK hören.

Er versteht:

"Wir integrieren uns in Ihren bestehenden Workflow."

Der Entwickler versteht:

"Ich importiere ein SDK."

Das ist dieselbe Geschichte.

Jetzt zu deinem Report

Den finde ich ehrlich gesagt ziemlich wichtig.

Nicht wegen der 86%.

Sondern wegen der Methodik.

Ihr macht jetzt:

Baseline

↓

Treatment

↓

echte Provider Calls

↓

Provider Cache

↓

Provider Usage

↓

Kosten

Das ist richtig.

Und genau das wird später der Kern des SDK.

Was ich extrem gut finde

Du misst:

echte API Calls
echten Multi-Turn Context
Provider Cache
Provider Prompt Tokens
Completion Tokens
echte Kostenberechnung

Das ist kein chars/4 Benchmark mehr.

Das ist wesentlich stärker.

Aber ich würde drei Dinge sofort verbessern
1. Qualität muss Teil des Realworld Commands werden

Momentan liefert evidence realworld echte Providerkosten und den Vergleich der beiden Arme.

Aber im eigentlichen Ergebnisobjekt steckt kein Quality Signal.

Ihr habt bereits einen zweiten Workflow, der LLM-gestützte Qualitätsprüfung durchführt und Baseline/Treatment vergleicht.

Diese beiden Welten müssen zusammen.

Das wäre meine erste technische Priorität.

Nicht zwei Commands.

Ein Receipt.

2. Synthetic Fallback raus

Mir ist beim Lesen etwas aufgefallen.

Wenn cargo test und cargo check scheitern,

verwendet evidence_realworld

synthetic_test_output()

als Ersatz.

Das würde ich ändern.

Nicht:

synthetic

Sondern:

FAIL

oder:

REAL DATA NOT AVAILABLE

Denn sonst verwässerst du genau die Ehrlichkeit, die das Produkt so stark macht.

3. Receipt statt Benchmark

Der Output sollte irgendwann nicht heißen:

Realworld Result

Sondern:

Execution Receipt

Das ist viel stärker.

Dann steht dort:

Task

Model

Provider

Context

Kit

Quality

Cost

Savings

Signatur

Das wird später der eigentliche Thinkery Primitive.

Jetzt zum spannendsten Teil
OSS vs Paid

Hier glaube ich inzwischen, dass wir eine extrem saubere Linie ziehen können.

OSS

Alles, was ein einzelner Entwickler lokal braucht.

Also:

LeanCTX Runtime
SDK
Wrapper
Context Selection
Compression
lokale Memory
Context Kits (Spec + Loader)
lokales Evidence Receipt
lokales Benchmarking

Der einzelne Entwickler muss LeanCTX komplett erleben können.

Sonst verliert ihr Adoption.

Paid

Alles, was entsteht,

wenn mehrere Menschen zusammenarbeiten.

Also:

Team Dashboard
Private Registry
Premium Kits
Enterprise Policies
RBAC
SSO
Governance
zentrale Evidence
Fleet
Billing
Budgets
private Connectors
SLA
Self-hosted Enterprise

Das fühlt sich für mich völlig natürlich an.

Die Regel wäre:

Single developer → OSS.

Organization → Thinkery.

Das ist eine wunderschöne Grenze.

Und noch etwas gefällt mir

Dein Report zeigt eigentlich,

dass LeanCTX heute schon viel mehr ist als ein Compressor.

Du hast:

Evidence
Reports
Kit Loader
Agent Experimente
HTML Reports
Pilot Setup
Cost Tracking

Das Problem ist nur,

dass der Entwickler das alles noch nicht als

ein SDK

wahrnimmt.

Sondern als viele einzelne Features.

Deshalb würde ich jetzt alles um den SDK herum organisieren

Nicht:

79 MCP Tools

Sondern:

LeanCTX SDK


Context


Kits


Evidence


Integrations


Examples

Die 79 Tools verschwinden nicht.

Sie werden nur intern.

Der Entwickler benutzt:

ctx.prepare()


ctx.wrap()


ctx.load_kit()


ctx.receipt()

Der Rest ist Engine.

Und genau deshalb glaube ich, dass Joel einen extrem wichtigen Punkt getroffen hat

Nicht,

weil "SDK"

ein cooles Buzzword ist.

Sondern,

weil plötzlich jeder versteht,

was LeanCTX eigentlich ist.

Ich würde den Satz sogar auf die Website schreiben:

LeanCTX is the Context SDK for AI agents.

Und Thinkery wäre dann:

The commercial platform for operating LeanCTX at organizational scale.

Das ist für mich die bislang klarste, fokussierteste und am wenigsten futuristische Formulierung eurer gesamten Strategie.

Und das Beste daran ist:

Ihr müsst dafür keinen Pivot machen.

Ihr müsst nur das, was ihr bereits gebaut habt, konsequent als SDK + Runtime produktisieren und Thinkery sauber als die kommerzielle Ebene darüber aufbauen.

heute 22:16
alter gefällt mir richtig geil! vorallem "The context SDK for AI agents". aber hiernochmals die ganze info. ich möchte dass du wirklich ein richtig geiles konzept erstellst und wirklich tief analysierst!

ich hab grad noch mit joel gesprochen. er hat gesagt, was wir eigentlich hier bauen ist ein SDK, welcher unternehmen in ihre ai agents integrieren können und somit die volle power von leanctx nutzen können. also dass quasi leanctx wie der toolkasten ist mit allen funktionen die wir haben. ich kann es nicht richitg wiedergeben. aber er meinte es nennt sich sdk, also so wie anthropic und openai. er hat auch gesagt vielleicht können wir das auch wrappen. und wir haben doch sowas schon in diese richtung bei leanctx eingebaut? ich habe bereits schon einen custom agent gebaut und damit rumexperimentiert. ich glaube das könnte die zukunft von leanctx sein. wir müssen uns nur überlegen wo wir die linie zwischen OSS und paid machen. weill ich möchte nicht alles gratis rausgeben!

hier ist der report von dem was ich gemacht habe:

Report: Real-World Evidence System + Agent-Orchestrierung
1. Was wir gebaut haben
Einen neuen CLI-Befehl lean-ctx evidence realworld, der beweist, dass LeanCTX echte Kosteneinsparungen bei AI-Agent-Workflows erzielt — mit echten API-Calls, nicht simuliert.

2. Wie der Evidence-Test funktioniert (technisch)
Architektur: Ein A/B-Test mit 10 echten OpenAI API-Calls.

ARM A (Baseline): 5 sequentielle API-Calls OHNE lean-ctx Kompression
ARM B (Treatment): 5 sequentielle API-Calls MIT lean-ctx Kompression
Jeder Call baut auf dem vorherigen auf (Multi-Turn Konversation).
Die 5 Turns pro Arm simulieren einen echten Agent-Coding-Workflow:

Turn	Was passiert	Baseline (roh)	Treatment (komprimiert)
1
Projekt-Struktur erkunden
Volles find . -name "*.rs" Listing
Komprimierter Verzeichnisbaum
2
Quelldateien lesen (3 grösste)
Voller Quellcode aller 3 Dateien
outline Mode: nur Signaturen + Struktur
3
Symbole suchen (rg)
Volles ripgrep-Ergebnis
Shell-Kompression (Pattern-basiert)
4
Tests ausführen (cargo test)
Volle Test-Ausgabe (gecapped auf 500 Zeilen)
Shell-Kompression (nur Zusammenfassung)
5
Final Analysis Request
Gleiche Frage an beide
Gleiche Frage an beide
Kritisch: Kontext akkumuliert. Turn 3 enthält alles von Turn 1+2+3. Turn 5 enthält den gesamten bisherigen Kontext. Das bildet exakt ab, wie ein echter AI-Agent arbeitet (Chat-History wächst mit jedem Schritt).

3. Provider-Cache-Tracking (der ehrliche Teil)
OpenAI cached automatisch repetitive Prompt-Segmente (System-Prompt, vorherige Turns). In der API-Response steht:

{
  "usage": {
    "prompt_tokens": 30934,
    "prompt_tokens_details": {
      "cached_tokens": 20480  // <-- DAS lesen wir aus
    },
    "completion_tokens": 445
  }
}
Unsere Kostenformel berücksichtigt das korrekt:

Kosten = (prompt - cached) × input_preis 
       + cached × cache_read_preis (50% Discount bei OpenAI)
       + output × output_preis
Das macht den Test KONSERVATIV — denn Provider-Caching hilft der Baseline mehr (mehr repetitiver Content = mehr Cache-Hits). Trotzdem gewinnt lean-ctx deutlich.

4. Echte Ergebnisse (3 Szenarien, 30 API-Calls total)
Szenario	Target-Verzeichnis	Baseline Tokens	Treatment Tokens	Token-Einsparung	Kosten-Einsparung
Klein
src/core/gain (8 .rs Dateien)
99.203
14.857
85.0%
78.9% ($0.212)
Mittel
src/shell (27 .rs Dateien)
139.115
14.016
89.9%
84.3% ($0.312)
Gross
src/cli/dispatch (121 .rs Dateien)
132.637
11.897
91.0%
86.0% ($0.305)
Provider-Cache-Effekte (Baseline bevorteilt!):

Baseline: 68.864 – 99.072 Tokens gecached (OpenAI cached die repetitiven Turns)
Treatment: 6.656 – 9.856 Tokens gecached (weniger repetitiver Content = weniger Cache)
Trotzdem 79-86% günstiger — weil lean-ctx den Content VOR dem Senden komprimiert
Modell: gpt-4o-mini, Endpoint: https://api.openai.com/v1/chat/completions

5. Agent-Orchestrierung (Codex CLI Agents)
Nach dem Evidence-Test habe ich 5 parallele Codex CLI Agents gestartet um die nächsten Sprint-Tasks umzusetzen:

Befehlsformat pro Agent:

cd /path/to/project && codex exec --approve-for-me "
<Aufgabe detailliert beschrieben>
" </dev/null 2>&1
Jeder Agent läuft als eigener Prozess mit block_until_ms: 0 (Cursor backgrounded ihn). lean-ctx bleibt aktiv für Kompression + Savings-Tracking.

Ergebnisse der 5 Agents:

Agent	Aufgabe	Dauer	Ergebnis
Agent 1
HTML Evidence Report Generator
17 Min
lean-ctx evidence report --input <json> --output <html> — 15KB standalone HTML mit Thinkery-Branding, CSS-Bar-Charts, Print-ready
Agent 2
Enterprise Pilot-Setup Script
8 Min
scripts/pilot-setup.sh — 550 Zeilen, idempotent, --uninstall, GitHub-Release-Download, SHA-256-Verify, Cursor MCP-Setup
Agent 3
Fix Integration Tests
16 Min
Bestätigt: 7/7 Tests bestehen (waren durch vorherigen Commit bereits gefixt)
Agent 4
Context Kit Code-Review
23 Min
lean-ctx kit load code-review — Kit-Format (TOML), Loader mit Prioritäts-Kette, 4 Tests, CLI-Commands
Agent 5
Sprint Tracker + One-Pager
4 Min
Tracker aktualisiert, Customer One-Pager auf Deutsch erstellt
6. Was das beweist
LeanCTX spart echtes Geld — 79-86% weniger API-Kosten, verifiziert durch OpenAI's eigene Usage-Metriken
Der Vorteil wächst mit Projekt-Grösse — je grösser das Projekt, desto mehr Kompression (85% → 91%)
Konservativ gemessen — Provider-Caching hilft der Baseline massiv, trotzdem gewinnt lean-ctx
Reproduzierbar — jeder mit einem OpenAI API-Key kann lean-ctx evidence realworld --target <dir> ausführen
Hochrechnung: Bei 100 Agent-Workflows/Tag spart ein Entwickler ~$636/Monat
7. Technischer Stack
Sprache: Rust (Modul evidence_realworld.rs, ~550 LOC)
HTTP-Client: ureq v3 (synchron, TLS)
Token-Counting: tiktoken (lokal, kein API-Call)
Kompression: Tree-sitter AST (outline/signatures Mode), Shell-Pattern-Engine (95+ Patterns)
Pricing: Embedded ModelPricing mit allen Provider-Tarifen (Anthropic, OpenAI, Gemini)
Retry: Exponentielles Backoff bei 429 Rate-Limits (30s, 60s, 90s)


weil was ich festgesellt habe ist, wenn man ein agent / tool baut und direkt die leanctx sachen einbaut, dann ist das ganze absolut hypereffizient.

Ja. Das ist für mich gerade der klarste Product Shape, den LeanCTX bisher hatte. Und vor allem ist es kein neuer Pivot. Es ist eine Vereinfachung dessen, was bereits da ist.

Ich würde die Idee aber um einen entscheidenden Satz präzisieren:

LeanCTX is the Context SDK for AI Agents.
Underneath, it runs a local Context Runtime.
Around it, adapters and wrappers connect existing agents.
Thinkery commercializes operating that context layer at organizational scale.

Oder noch einfacher:

The Engine is the toolbox. The SDK is how developers use it. Wrappers are how existing agents plug into it. Thinkery is how organizations operate it.

Das ist für mich gerade richtig stark.

1. Was Joel eigentlich erkannt hat

Bisher haben wir LeanCTX häufig von seiner Implementierung her betrachtet:

Compression
MCP
Read Modes
Memory
Context Packages
Agent Bus
Savings Ledger
Evidence
Proxy
Routing
Knowledge
...

Das Problem daran: Ein Entwickler sieht einen riesigen Werkzeugkasten und muss selbst verstehen, wann er welches Werkzeug benutzen soll.

Ein gutes SDK dreht das um.

Der Entwickler sagt nicht mehr:

„Soll mein Agent jetzt ctx_read im outline mode aufrufen, danach ctx_search, danach cached knowledge prüfen und später savings erfassen?“

Sondern beispielsweise konzeptionell:

ctx = LeanCTX(project=".")


agent = ctx.wrap(my_agent)


result = agent.run("Review this pull request")

Und LeanCTX entscheidet im Hintergrund:

Was braucht dieser Agent?
Was kennt er bereits?
Was muss exakt bleiben?
Was kann strukturell reduziert werden?
Was kann wiederverwendet werden?
Was darf ausgelassen werden?
Was muss bei Bedarf recoverable bleiben?
Was kostet der Run?
Was war das Ergebnis?

Das ist der Unterschied zwischen einem Werkzeugkasten und einem Produkt.

2. Und technisch ist diese Richtung bereits real

Das ist wichtig: Wir fantasieren das nicht einfach.

Die Codebase-Analyse beschreibt bereits ein embeddable lean-ctx-sdk: EngineBuilder konfiguriert Project Root, Data Directory, Write-/Exec-Berechtigungen und Worker Threads; über die Engine sind read, search, symbol, outline, tree und optionale Execution-Funktionen verfügbar. Tests decken unter anderem wiederholte Reads, PathJail, Symbol Search und explizites Execution Opt-in ab.

Auch die übergeordnete Architektur sieht SDKs bereits als eigene API-Surface vor. Python-, TypeScript- und Go-SDKs bzw. Clients sind als shipped/partial erfasst; gleichzeitig soll die Sprachebene möglichst dünn bleiben und dieselben versionierten Contracts wie die Runtime verwenden.

Und genau das ist architektonisch richtig:

Python / TypeScript / Go / Rust
             │
             │ LeanCTX SDK
             ▼
      LeanCTX Runtime
          (Rust)
             │
   ┌─────────┼─────────┐
   │         │         │
 Context   Memory    Evidence
 Engine     Kits      Cost
   │         │         │
   └─────────┼─────────┘
             │
             ▼
           Agent
             │
             ▼
         LLM Provider

Wir sollten nicht dieselbe Context-Engine viermal in vier Sprachen implementieren.

Die Sprach-SDKs sind die ergonomische Developer Surface.

Die Rust Runtime ist die Maschine darunter.

3. Damit wird auch klar, was LeanCTX NICHT ist

LeanCTX sollte kein Agent SDK im Sinne von OpenAI oder Anthropic werden.

Das ist eine wichtige Grenze.

OpenAI beschreibt sein Agents SDK aktuell als Runtime rund um Agents, Tools, Handoffs, Guardrails, Sessions und Tracing; der Runner übernimmt dabei auch Agent Loop und Tool Execution. Anthropic trennt heute ebenfalls zwischen allgemeinen Client-SDKs, Integrations-/Compatibility Layers und eigenen Managed-Agent-Angeboten.

Das sollten wir nicht nachbauen.

OpenAI fragt:

Wie baue und orchestriere ich einen Agent?

Anthropic fragt:

Wie baue oder betreibe ich einen Claude Agent?

LeanCTX fragt:

Wie bekommt irgendein Agent den effizientesten, relevantesten und überprüfbaren Context?

Deshalb:

OpenAI Agents SDK ─────┐
Claude Agent SDK ──────┤
LangGraph ─────────────┤
Custom Agent ──────────┼──► LeanCTX Context SDK
Vercel AI SDK ─────────┤
Eigene Runtime ────────┘

LeanCTX sollte unter bzw. neben Agent Frameworks liegen, nicht gegen sie antreten.

Das ist eine deutlich bessere Position.

4. Warum deine Beobachtung mit dem Custom Agent so wichtig ist

Du hast gesagt:

Wenn man einen Agent direkt baut und die LeanCTX-Sachen direkt integriert, wird das Ding hypereffizient.

Ich halte das für eine sehr plausible und extrem wichtige Hypothese.

Denn je näher LeanCTX am Agent Loop sitzt, desto früher kann es eingreifen.

Ein reiner Proxy sieht im Wesentlichen:

fertigen Request
↓
LLM

Da wurde bereits entschieden, welche Files gelesen wurden, welche Tool-Ausgaben in der History liegen und welche Informationen mehrfach akkumuliert wurden.

MCP ist besser, weil LeanCTX Tool-Aufrufe und Tool-Responses beeinflussen kann.

Aber ein nativ integrierter Context SDK kann noch früher arbeiten:

Task
 ↓
Intent / Context Need
 ↓
LeanCTX decides what to retrieve
 ↓
LeanCTX chooses representation
 ↓
LeanCTX reuses known information
 ↓
LeanCTX applies budget
 ↓
Agent sees compact context
 ↓
Model call
 ↓
Usage + result observed
 ↓
Receipt

Das ist konzeptionell viel mächtiger.

5. Der eigentliche Unterschied ist „compress after selection“ vs „control selection“

Nimm dein Beispiel.

Der naive Agent macht:

find .
 ↓
alles in History


read file A
read file B
read file C
 ↓
alles in History


ripgrep
 ↓
alles in History


cargo test
 ↓
alles in History

LeanCTX als nachgelagerter Compressor versucht:

„Okay, ich mache diese riesigen Payloads kleiner.“

Das hilft.

LeanCTX im Agent selbst kann dagegen sagen:

Für diese Aufgabe brauche ich nicht alle 121 Files.

Dann:

tree()
        ↓
relevante Module


outline()
        ↓
relevante Symbole


search()
        ↓
relevante Stellen


exact read()
        ↓
nur notwendige Implementierung


test summary
        ↓
Fehler + relevante Details

Das ist nicht einfach bessere Compression.

Das ist:

Context Planning.

Und ich glaube, hier liegt das langfristig Spannende an LeanCTX.

6. Das SDK sollte deshalb nicht „80 Tools als Python Functions“ sein

Das wäre ein Fehler.

Wir müssen die Komplexität verbergen.

Intern darf LeanCTX hundert Capabilities besitzen.

Extern würde ich vielleicht fünf zentrale Primitives anstreben:

ContextSession


prepare()
retrieve()
reuse()
recover()
receipt()

Plus:

load_kit()

Nicht exakt diese Methodennamen — das müsste technisch sauber designt werden.

Aber das mentale Modell sollte so klein sein.

OpenAI selbst beschreibt als SDK-Designprinzip, wenige Primitives zu haben, die trotzdem genügend Power bieten.

Genau diese Product Discipline braucht LeanCTX.

7. Ich würde einen zentralen Primitive definieren: ContextSession

Nicht Agent.

Nicht Workflow.

Nicht Prompt.

Sondern:

ContextSession = der Context Lifecycle eines Agent Tasks.

Konzeptionell:

ctx = LeanCTX(project=".")


session = ctx.session(
    task="Review PR #482",
    budget="balanced"
)


...

Die Session weiß:

Task
Agent
Context already seen
Context currently relevant
Context references
Loaded Kits
Token budget
Provider
Cost
Recoveries
Outcome

Dadurch kann LeanCTX über mehrere Tool Calls hinweg optimieren.

Und genau das passt perfekt zu deinem Evidence-Test, weil dort Context über fünf Turns akkumuliert.

8. Danach wird wrap() die magische Developer Experience

Für bestehende Systeme sollte der Einstieg aber noch einfacher sein.

North-Star-Ergonomie, nicht aktueller API-Vorschlag:

from leanctx import LeanCTX


ctx = LeanCTX(project=".")


agent = ctx.wrap(existing_agent)


result = agent.run("Analyse this repository")

Oder provider-näher:

client = leanctx.wrap(openai_client)

Oder Framework Adapter:

agent = with_leanctx(agent)

Aber technisch sollten wir kein magisches wrap(anything) versprechen.

Dafür unterscheiden sich Agent Frameworks zu stark.

Wir bauen gezielte Adapter.

9. Deshalb sehe ich drei Integrationsstufen
Integration	Aufwand	LeanCTX sieht	Potential
Proxy / MCP	sehr gering	Requests / Tools	gut
Wrapper / Framework Adapter	wenige Codezeilen	Agent-/Tool-Lifecycle	sehr gut
Native Context SDK	echte Integration	vollständigen Context Lifecycle	maximal

Und alle drei verwenden dieselbe Runtime.

Das ist wunderschön, weil ein Unternehmen klein anfangen kann:

Install LeanCTX
      ↓
Proxy / MCP
      ↓
Proof
      ↓
Wrapper
      ↓
Native SDK integration

Kein Plattformwechsel.

Kein Rewrite.

10. Und hier wird euer heutiger Pilot plötzlich noch besser

Auf Seite 3 deines aktuellen Pilot-Dokuments steht bereits genau die Business-Version dieser Architektur:

LeanCTX wird in einen bestehenden AI-Workflow integriert, der Fachprozess bleibt bestehen, und LeanCTX misst, reduziert, verwendet wieder und steuert den dahinterliegenden Aufwand.

Das bedeutet:

Developer Message

LeanCTX — The Context SDK for AI Agents.

Business Message

LeanCTX is an efficiency layer for your existing AI workflows.

Es ist dasselbe Produkt.

Nur unterschiedliche Sprache für unterschiedliche Buyer.

Das finde ich extrem wichtig.

11. Dein Real-World Evidence Experiment bekommt dadurch eine ganz neue Bedeutung

Die Zahlen sind stark:

Small       78.9% cost reduction
Medium      84.3%
Large       86.0%

Aber die eigentlich wichtige Erkenntnis ist nicht „86 %“.

Die wichtigere Erkenntnis ist:

Wenn wir die Context-Produktion des Agents kontrollieren, können wir verhindern, dass unnötiger Context überhaupt erst in die Conversation gelangt.

Dein Experiment baut genau einen Agent-artigen Lifecycle nach:

discover
→ read
→ search
→ test
→ reason

und lässt History akkumulieren.

Das ist genau das Problem, das ein Context SDK kontrollieren kann.

12. Der Evidence-Test ist gut – aber wir müssen ihn jetzt wissenschaftlich härter machen

Ich würde die Resultate nicht als universellen „LeanCTX spart 79–86 %“ Claim verwenden.

Sie belegen:

Auf drei definierten, fünfstufigen Coding-Agent-Szenarien mit diesem Modell, dieser Methodik und diesen Context Transformations wurden 79–86 % berechnete API-Kosten eingespart.

Das ist stark genug.

Drei Dinge fehlen für einen wirklich unangreifbaren SDK Proof.

Erstens muss Quality gleichberechtigt in den Run. Gleiche Final Question allein beweist nicht, dass beide Agenten dasselbe erfolgreiche Ergebnis erzeugen.

Zweitens sollten die Kosten als provider-reported usage × versioned pricing beschrieben werden, solange ihr nicht tatsächlich Provider-Rechnungspositionen gegen den Run matched. Provider-Usage ist sehr gute Evidence, aber methodisch etwas anderes als ein Rechnungsbeleg.

Drittens ist „Savings steigen mit Projektgröße“ derzeit eine Beobachtung über drei Szenarien, keine bewiesene Skalierungsregel.

Das macht euren Test nicht schlechter.

Es macht die Kommunikation professioneller.

13. Und jetzt kommt meines Erachtens das wichtigste Experiment überhaupt

Nicht עוד Features bauen.

Sondern diese Hypothese testen:

Native LeanCTX integration produces more value than sidecar-only LeanCTX.

Ich würde dafür einen Integration Depth Benchmark bauen.

                    SAME TASK
                    SAME MODEL
                    SAME REPO
                    SAME AGENT LOOP
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼


       ARM A           ARM B          ARM C


       RAW          LeanCTX         LeanCTX
       AGENT         Proxy/         Native SDK
                     MCP

Dann messen:

Provider input tokens
Cached tokens
Output tokens
Provider cost


Tool calls
Files/content read
Context recovered


Latency
Task completion
Tests
Quality score
Human correction

Wenn herauskommt:

Baseline      $1.00
Proxy         $0.45
Native SDK    $0.18


Quality       equivalent

dann habt ihr etwas viel Wertvolleres als eine Meinung darüber, was LeanCTX werden sollte.

Dann habt ihr bewiesen:

The deeper LeanCTX is integrated into the agent, the more efficiently the agent can operate.

Das könnte eine zentrale Product Thesis werden.

14. Und daraus würde ich euren ersten Referenz-Agent bauen

Nicht als neues Produkt.

Als SDK Demonstrator.

Ein kleiner realer Coding Agent:

Task
 ↓
plan
 ↓
search
 ↓
read
 ↓
test
 ↓
answer

Version A:

normal agent

Version B:

same agent + LeanCTX SDK

Der Codeunterschied sollte im Idealfall lächerlich klein sein.

Dann kann die Website zeigen:

Before LeanCTX


139,115 tokens
$X
quality Y




After adding LeanCTX


14,016 tokens
$Z
quality Y

Und daneben:

ctx = LeanCTX(...)
agent = ctx.wrap(agent)

Das versteht jeder Entwickler.

15. Damit bekommt auch Context Kit endlich seinen natürlichen Platz

Ein Kit ist dann keine abstrakte Plattformidee.

Es ist einfach etwas, das ich einem Agenten über den SDK gebe:

ctx.load_kit("code-review")

Der Agent bekommt dadurch beispielsweise:

Review Rules
Architecture Knowledge
Security Rules
Known Patterns
Gotchas
Evaluation Criteria

Und eure technische Basis dafür ist bereits ungewöhnlich weit: Package Manifest, Versionierung, Dependencies, Integrity, Provenance, Signatures, Compatibility, Composition, Registry und Auto-load existieren bereits in der Context-Package-Schicht.

Dann wird:

Context Kit

plötzlich ebenfalls extrem verständlich.

16. Jetzt zur heiklen Frage: Was bleibt OSS?

Hier würde ich nicht aus Angst anfangen, LeanCTX kaputt zu paywallen.

Denn der SDK ist euer Distribution Wedge.

Ein Entwickler sollte lokal erleben können:

„Fuck. Ich habe drei Zeilen integriert und mein Agent verarbeitet massiv weniger Context.“

Diesen Aha-Moment müssen wir verschenken.

Aber wir müssen nicht die organisatorische Ebene verschenken.

Mein bevorzugtes Modell wäre:

LeanCTX OSS	Thinkery Paid
Local Context Runtime	Shared organization workspace
Core SDKs	Central Control Plane
Framework adapters	Fleet management
Compression / selection	Organization policies
Local memory	Central policy distribution
Local Context Kits	Private Kit Registry
Kit format + verifier	Premium / managed Kits
Local Evidence Receipt	Organization-wide Evidence
Local savings measurement	Aggregated economics
Local proxy / MCP	SSO / RBAC
Local recoverability	Audit / retention controls
Provider neutrality	Enterprise integrations
One machine / local workflows	Multi-team operations
Open contracts	SLA / support / self-hosted Enterprise

Die Grenze ist also nicht künstlich „Free compression = bad, paid compression = good“.

Die Grenze lautet:

LeanCTX makes one agent context-efficient.
Thinkery makes an organization operate context-efficient agents.

Das ist für mich eine sehr belastbare OSS/Commercial Boundary.

17. Du gibst damit definitiv nicht „alles gratis“ raus

Was Unternehmen irgendwann wirklich bezahlen, ist nicht eine einzelne Tree-sitter-Funktion.

Sie bezahlen dafür, dass sie sagen können:

We have 83 agents.


These are their approved Context Kits.


These agents may access source X.


This team has CHF 20k/month budget.


These workflows saved CHF 146k.


These runs passed quality.


These 4 policy decisions blocked execution.


This evidence can be independently verified.

Das ist Thinkery.

Und genau deshalb kann die lokale Runtime frei und sehr leistungsfähig bleiben.

Die Architektur sieht bereits ausdrücklich vor, dass Enterprise und Cloud nicht in die öffentliche Engine hineinleaken und dass die Plattform Evidence Bundles verarbeiten kann, ohne Roh-Prompts lesen zu müssen.

Das ist eine starke kommerzielle Architektur.

18. Ich würde sogar bewusst NICHT „LeanCTX Pro“ machen

Nicht:

LeanCTX Free
LeanCTX Pro
LeanCTX Enterprise

Langfristig sauberer:

                         THINKERY
                            │
              ┌─────────────┴─────────────┐
              │                           │
           LeanCTX                 Thinkery Platform
             OSS                       PAID
              │                           │
        Context SDK                Organization
        + Runtime                  Operations
              │                           │
        ┌─────┼─────┐          ┌─────────┼─────────┐
        │     │     │          │         │         │
       SDK   MCP   Proxy      Policy   Evidence   Registry
       Kits  CLI   Memory     Fleet    Economics  Teams

Das ist unglaublich sauber.

19. Was bezahlt werden könnte, ohne den OSS-Trust zu zerstören

Besonders attraktiv finde ich drei Commercial Assets.

Private Context Infrastructure wäre der erste große Block: Team Sync, Private Kits, Registry, Enterprise Connectors, Retention und Shared Evidence.

Control wäre der zweite: zentrale Policies, Budgets, SSO/RBAC, Agent Inventory, Audit, approvals und Fleet Economics.

Organization Intelligence wäre später vielleicht der stärkste: Thinkery lernt innerhalb eines Unternehmens, welche Context Strategy für welche Task-Klasse Cost/Quality optimiert. Das ist dann nicht einfach „ein besserer Compressor“, sondern organisationsspezifische Optimierung aus realen Outcomes.

Das kann sehr wertvoll und proprietär werden.

20. Und ja: Wir könnten später sogar proprietäre Optimizer haben

Die Engine kann ein offenes Provider-/Optimizer-Interface besitzen.

Dann beispielsweise:

CompressionProvider
├── LeanCTX OSS
├── Native Provider Compaction
├── External Optimizer
└── Thinkery Enterprise Optimizer

Aber ich würde heute nicht darauf das Geschäftsmodell bauen.

Die erste Paid Value sitzt viel klarer in Shared Evidence, Control, Private Kits und Organization Operations.

21. Was aus CLI, MCP und Proxy wird

Die verschwinden nicht.

Sie bekommen nur endlich ihren richtigen Platz.

CLI
= operator/developer interface


MCP
= universal agent compatibility interface


Proxy
= zero-code provider integration


SDK
= deep custom-agent integration

Das ist eine große Verbesserung gegenüber:

„LeanCTX hat X Tools und einen Proxy und MCP und SDKs und…“

Jetzt lautet die Story:

Choose how deeply you want to integrate LeanCTX.

Das ist ein Produkt.

22. Ich glaube sogar, dass die SDK-Positionierung unsere ganze bisherige Verwirrung löst

Wir hatten immer wieder die Frage:

Ist LeanCTX ein Coding Tool?

Ist es ein Compressor?

Ist es ein Gateway?

Ist es ein Agent Runtime?

Ist es ein Control Plane?

Ist Thinkery ein Agent Platform?

Die Antwort wird viel einfacher:

LeanCTX is the Context SDK for AI Agents.

Darunter steckt die Runtime.

Darüber kann Thinkery organisatorische Operations anbieten.

Alles andere muss sich daran messen lassen.

23. Der SDK Scope kann sogar unser neuer Focus Filter werden

Wenn jemand mit einem Feature kommt, stellen wir eine Frage:

Does this make an agent's context lifecycle better?

Wenn ja:

LeanCTX-Kandidat.

Wenn nicht:

wahrscheinlich nicht LeanCTX.

Beispiele:

Better context selection          YES
Reusable context                  YES
Context recovery                  YES
Context budgeting                 YES
Context evidence                  YES
Context Kit                       YES


Generic CRM automation            NO
Generic workflow builder          NO
Voice agent platform              NO
Email campaign agent              NO
Generic agent scheduler           PROBABLY NO

Das verhindert genau die Scope Explosion, vor der wir Angst hatten.

24. Es gibt aber noch einen zweiten Filter für OSS

Dann fragen wir:

Is this required for a developer to build a great context-efficient agent locally?

Wenn ja:

wahrscheinlich OSS.

Dann:

Is this primarily required to operate many agents across an organization?

Wenn ja:

wahrscheinlich Thinkery.

Das ist eine erstaunlich klare Product Governance.

25. Dein Pilot-Modell passt weiterhin

Das bestehende Pilot-PDF sagt:

Ein Workflow, vier Wochen, Baseline → Paralleltest → Optimierung → Vergleich.

Und aktuell ist das Modell: Pilot CHF 0; bei erfolgreichem Proof und gewünschter Weiterführung gehen 10 % der verifizierten Einsparungen an Thinkery.

SDK verändert diese Story nicht.

Es macht sie besser.

Denn jetzt könntest du zu einer Firma sagen:

„Zeigt uns euren bestehenden Agent. Wir integrieren LeanCTX über SDK, Wrapper oder Proxy. Dann messen wir denselben Workflow vorher und nachher.“

Das ist extrem konkret.

26. Und daraus ergibt sich langfristig ein sehr schönes Land-and-expand
CUSTOM AGENT
     │
     │ integrate LeanCTX
     ▼
CONTEXT SDK
     │
     │ proven savings
     ▼
VERIFIED EFFICIENCY
     │
     │ team wants shared view
     ▼
THINKERY TEAM
     │
     │ more agents
     ▼
CONTROL + EVIDENCE
     │
     │ reusable expertise
     ▼
PRIVATE CONTEXT KITS
     │
     │ organization scale
     ▼
THINKERY PLATFORM

Keine Sci-Fi.

Jede Stufe entsteht aus einem Problem der vorherigen.

27. Unser North Star Outcome verändert sich dadurch leicht

Nicht:

Tokens saved.

Und auch nicht:

Compression ratio.

Sondern:

Cost per successful agent task.

Oder noch besser als interner Metric:

Verified Cost
──────────────
Successful Outcome

LeanCTX soll diesen Wert senken.

Dann werden auch größere Models, Cache, Routing, Kits, Memory und Quality Teil derselben Gleichung.

Das schützt euch davor, nur ein Token Tool zu sein.

28. Der Realworld Command sollte deshalb irgendwann so enden

Nicht nur:

Tokens saved: 89.9%
Cost saved: 84.3%

Sondern:

TASK
Repository analysis


BASELINE
Cost             $0.370
Input tokens     139,115
Quality          PASS
Duration         42.4s


LEANCTX
Cost             $0.058
Input tokens      14,016
Quality          PASS
Duration         39.7s


VERIFIED
Cost reduction    84.3%
Quality delta      0
Receipt          verified

Das verkauft.

29. Und dann kommt der eigentliche Killer

Wenn dieses Receipt automatisch aus dem SDK entsteht:

result = agent.run(...)


result.leanctx.receipt()

dann hat jeder mit LeanCTX gebaute Agent automatisch:

Context economics
Quality evidence
Provenance
Recoverability

Das wäre eine richtig starke Developer Experience.

30. Was ich jetzt ausdrücklich NICHT machen würde

Ich würde nicht sofort zehn Framework Adapter bauen.

Nicht sofort einen Agent Builder.

Nicht sofort Hosted Agents.

Nicht sofort Marketplace.

Nicht sofort das komplette Enterprise Dashboard finishen.

Und auch nicht drei Wochen lang das SDK theoretisch redesignen.

Wir haben gerade eine konkrete Hypothese.

Die muss jetzt bewiesen werden.

Mein konkreter nächster Plan
The Context SDK for AI Agents vorläufig als Product Thesis einfrieren. Nicht zwingend morgen schon jede Website ändern, aber intern wird dagegen entschieden.
Ein einziges SDK Contract Document schreiben. Darin stehen Scope, ContextSession, Kits, Receipts, Recovery, Runtime Boundary, Adapter Contract und explizite Non-goals. Maximal zehn Seiten.
Einen Reference Custom Agent auswählen. Ein kleiner realer Coding-Agent-Loop; keine zehn Agenten, kein Showcase-Theater.
Den Integration Depth Benchmark bauen: Raw vs Proxy/MCP vs Native SDK. Gleicher Agent, gleicher Task, gleicher Provider, gleiche Quality Gates. Das beantwortet deine zentrale Beobachtung empirisch.
Quality direkt in evidence realworld integrieren. Kein Cost Claim ohne Outcome-Gate. Pricing versionieren und Provider Usage separat von berechneten Kosten ausweisen.
North-Star SDK-Ergonomie definieren. Ein Entwickler soll innerhalb weniger Minuten von existing_agent zu existing_agent + LeanCTX kommen und danach ein Receipt sehen.
OSS/Commercial Boundary einfrieren: Local Context SDK + Runtime stark und offen; Organisation, Shared Control, private Kits, zentrale Evidence, Fleet, SSO/RBAC und Enterprise Operations bezahlt.
Erst danach Website, Docs und Pilotmaterial um diese Story herum konvergieren. Für Entwickler „Context SDK“, für Business „AI Efficiency Layer“, für Enterprise später „Thinkery Platform“.
Mein Urteil

Ich glaube wirklich, dass das eine der wichtigsten Erkenntnisse der letzten Wochen ist.

Nicht weil „SDK“ sexy klingt.

Sondern weil es drei Probleme gleichzeitig löst.

Es gibt LeanCTX endlich eine sofort verständliche Kategorie.

Es erklärt, warum die vielen bestehenden Fähigkeiten keine Feature-Wüste, sondern die Engine hinter einem einfachen Developer Interface sind.

Und es gibt Thinkery eine natürliche kommerzielle Grenze, ohne LeanCTX als Open-Source-Projekt kastrieren zu müssen.

Die Positionierung würde ich deshalb aktuell so einfrieren:

LeanCTX

The Context SDK for AI Agents.

Embed LeanCTX into existing agents to select, compress, reuse and measure context before it reaches the model.

Thinkery adds the organizational layer for teams that need shared evidence, policies, private context assets and control.

Das ist nah genug, dass wir es heute bauen können.

Und groß genug, dass daraus später sehr viel mehr entstehen kann.

okay und wie können wir das nun ultimativ monetarisieren, sodass wir so schnell wie es geht geld damit machen können? wie können wir B2C und B2B angreifen? wie können wir leuten einen playground geben um das live auszuprobieren oder sogar auf unserer infrastruktur laufen zu lassen? wie können wir den fokus behalten? und wie können wir uns von unserer konkurrenz absichern und abheben? ich seh uns als chiptuner für agents. ich möchte dass du absolut crazy gehst aber alles fundiert! wie können wir leanctx zur ultimativen tuning plattform machen, aber codex, cursor, claude code usw nicht verlieren! geh wirklich absolut crazy!

Ja. Ich glaube, aus „Chiptuner für Agents“ kann man tatsächlich eine sehr starke Produktarchitektur bauen — solange wir eine Sache sauber trennen:

„The Context SDK for AI Agents“ ist die verständliche Produktkategorie.
Der eigentliche Moat ist der Tuning Loop dahinter.

Das SDK allein schützt euch nicht. Headroom hat inzwischen ebenfalls Python/TypeScript-SDKs, Proxy-Modus und sogar wrap claude / wrap codex; Shared Context lässt sich unter anderem mit LangGraph und dem OpenAI Agents SDK integrieren.

Also darf unser Ziel nicht sein: „Wir haben auch einen Wrapper.“

Unser Ziel sollte sein:

LeanCTX — The Context SDK for AI Agents
Tune any agent. Prove every gain.

Und darunter steckt etwas viel Größeres:

Measure → Tune → Benchmark → Deploy → Monitor → Retune.

Das ist der Chiptuner.

1. Die Analogie ist überraschend exakt

Ich würde intern wirklich mit diesem Modell arbeiten:

AUTOMOTIVE                         AI AGENTS


Car                               Agent
Engine                            Foundation model
ECU                               Context strategy
Fuel                              Tokens / Compute
Sensor telemetry                  Usage / traces / quality
Dyno                              Benchmark / A-B test
ECU map                           Tuning Profile
Chip tuner                        LeanCTX
Fleet management                  Thinkery Enterprise

Ein Chiptuner baut nicht den Motor neu.

Er sagt nicht:

„Werf deinen BMW weg und nimm meinen Motor.“

Er nimmt das bestehende System und holt mehr Leistung pro Ressource heraus.

Genau das sollte LeanCTX tun:

Codex
Claude Code
Cursor
OpenAI Agent
Claude Agent
LangGraph Agent
Custom Agent
        │
        ▼
      LeanCTX
        │
        ▼
same capability
less waste
measured outcome

Das ist eine fantastische Position.

2. Aber wir sollten nicht nur „Context Compression“ tunen

Das wäre zu klein.

Der eigentliche Gegenstand, den LeanCTX optimiert, ist:

The context strategy of an agent.

Das kann umfassen:

what to retrieve
what to read
how much to read
what representation to use
what to retain
what to reuse
what to cache
what to compress
what to recover
which kit to load
which model to use
how large the context budget is

Das ist viel mehr als:

big prompt
    ↓
compress
    ↓
smaller prompt

Deshalb finde ich Context SDK so stark.

3. Das ultimative LeanCTX-Produktmodell

Ich würde vier Integrationsstufen anbieten.

                         LeanCTX Runtime
                               │
            ┌──────────────────┼──────────────────┐
            │                  │                  │
         ATTACH              WRAP               EMBED
            │                  │                  │
         Proxy/MCP          Adapter             SDK
            │                  │                  │
      Claude Code         OpenAI SDK       Custom Agents
      Codex               LangGraph        Internal Agents
      Cursor              Claude SDK       Product Agents
            │                  │                  │
            └──────────────────┼──────────────────┘
                               │
                          same tuning
                           same evidence
                           same profiles

Und irgendwann kommt optional:

RUN
│
Thinkery-managed execution

Aber erst später.

Das Schöne daran: Wir verlieren keinen einzigen aktuellen LeanCTX-Use-Case.

4. ATTACH: Coding Agents bleiben ein First-Class Product

Das ist extrem wichtig.

Wir dürfen Cursor-, Claude-Code- und Codex-Nutzer auf keinen Fall zurücklassen, nur weil Custom Agents wirtschaftlich spannender werden.

Und die Anbieter geben uns inzwischen sehr brauchbare Extension Points.

Codex unterstützt MCP, einen eigenen App Server für tiefere Integrationen sowie Hooks; OpenAI beschreibt den App Server mittlerweile als bevorzugte Integrationsmethode für Clients. Hooks können unter anderem Prompts prüfen, Validators ausführen, Conversations loggen oder Memory erzeugen.

Claude Code unterstützt MCP und programmatische Ausführung; Anthropic dokumentiert außerdem explizit LLM-Gateway-Konfiguration über einen alternativen Base URL, einschließlich Usage Tracking und Budget Controls.

Cursor unterstützt MCP sowohl im IDE Agent als auch in der CLI und verfügt außerdem über eine Background Agents API.

Das bedeutet:

Wir müssen diese Agents nicht besitzen, um sie zu tunen.

Perfekt.

5. Daraus würde ich drei extrem einfache Commands machen

Langfristige UX-Idee:

lean-ctx connect codex
lean-ctx connect claude
lean-ctx connect cursor

Danach:

lean-ctx dyno

Und du bekommst:

Agent                  Claude Code
Project                payments-api
Workload               12 tasks


BEFORE
Input context           4.8M tokens
Cost                    $18.42
Task success            91.7%


AFTER LEANCTX
Input context           1.3M tokens
Cost                    $7.91
Task success            91.7%


VERIFIED IMPROVEMENT
Cost                    -57.1%
Context                 -72.9%
Quality                 unchanged

Das ist B2C/B2D Gold.

6. WRAP: ein paar Zeilen für bestehende Agent Frameworks

Für Entwickler, die einen eigenen Agent mit bestehenden Libraries bauen:

agent = OpenAIAgent(...)


agent = leanctx.wrap(agent)

oder:

client = leanctx.wrap(openai_client)

Frameworks bekommen gezielte Adapter.

Nicht:

wrap(any_object_in_the_universe).

Sondern sauber getestete Integrationen.

Zum Beispiel später:

OpenAI Agents SDK
Claude Agent SDK
LangGraph
Vercel AI SDK
LiteLLM

Der Wrapper ist Distribution.

Noch nicht der Moat.

7. EMBED: hier liegt das richtig große B2B-Geschäft

Bei Unternehmen mit Custom Agents sollte LeanCTX tief in den Agent Loop.

Genau hier passt deine Beobachtung:

Wenn der Agent LeanCTX direkt verwendet, wird er massiv effizienter.

Das ergibt architektonisch Sinn.

Denn dann optimieren wir nicht erst:

„Hier ist eine riesige Tool Response — mach sie kleiner.“

Sondern vorher:

„Braucht der Agent diese Tool Response überhaupt?“

Das ist ein fundamentaler Unterschied.

8. Aus Compression wird Context Planning

Naiver Agent:

Task
 ↓
find everything
 ↓
read everything
 ↓
grep everything
 ↓
keep everything
 ↓
LLM

LeanCTX-native Agent:

Task
 ↓
understand context need
 ↓
select relevant sources
 ↓
choose representation
 ↓
reuse existing state
 ↓
apply context budget
 ↓
retain references
 ↓
LLM

Das zweite System kann strukturell viel effizienter sein.

Das müssen wir jetzt empirisch beweisen.

9. Dafür würde ich den „LeanCTX Dyno“ bauen

Das ist für mich vielleicht die geilste Product-Idee aus diesem ganzen Gespräch.

Nicht als Gimmick.

Als echte Infrastruktur.

LeanCTX Dyno

Der Dyno nimmt denselben Agent, denselben Task, dasselbe Modell und dieselben Quality Gates.

Dann fährt er verschiedene Tuning-Konfigurationen dagegen.

                    SAME WORKLOAD
                         │
            ┌────────────┼────────────┐
            ▼            ▼            ▼


          STOCK        STAGE 1      STAGE 2


          Raw          Proxy         Native
          Agent        LeanCTX       LeanCTX SDK
            │            │            │
            └────────────┼────────────┘
                         ▼


                   COST / QUALITY
                   TOKEN / LATENCY
                   TOOL CALLS
                   SUCCESS

Wir übernehmen sogar die Chiptuning-Sprache teilweise.

Intern könnte es Profile geben wie:

safe
balanced
aggressive
quality-first
cost-first

Extern würde ich „Stage 1/2“ vielleicht nicht unbedingt verwenden; das könnte zu gimmicky werden.

Aber der Mechanismus ist genial.

10. Daraus entsteht TuningProfile

Das wird ein richtig wichtiges LeanCTX-Artefakt.

Beispiel:

agent: code-reviewer
runtime: openai-agents
model: gpt-5


profile:
  context_budget: 64000
  code_read_mode: outline-first
  search_limit: 12
  reuse_threshold: 0.85
  compression: balanced
  recovery: enabled


kits:
  - secure-code-review@1.4


quality:
  test_required: true
  min_score: 0.92

Das ist das ECU Mapping des Agents.

11. Und jetzt kommt der echte Moat: Profile-Guided Optimization

Das ist ein Konzept aus Compiler-/Systems Engineering, das perfekt hierher passt:

Profile-Guided Optimization for AI Agents.

Nicht einfach eine feste Compression Policy.

Sondern:

real workload
      ↓
measure
      ↓
generate tuning candidates
      ↓
replay
      ↓
quality evaluation
      ↓
cost / latency evaluation
      ↓
select Pareto-optimal profile
      ↓
deploy
      ↓
observe new workload
      ↓
retune

Das ist der eigentliche LeanCTX AutoTune.

Dann wird euer Optimierungsziel etwa:

minimize:
    agent cost
    + latency penalty


subject to:
    quality >= accepted threshold
    policy == pass

Das ist sehr viel stärker als:

„Wir komprimieren Text.“

12. Genau DORT würde ich die OSS/Paid-Grenze ziehen

Das ist wahrscheinlich die wichtigste Monetarisierungsentscheidung.

Meine Regel wäre:

OSS gives developers the engine.

Paid Thinkery automates and operates the tuning loop.

Der Developer darf LeanCTX lokal richtig geil finden.

Nicht crippled OSS.

Nicht:

„Gratis spart 20 %, zahlend spart 80 %.“

Das zerstört Vertrauen.

Sondern:

OSS / local	Paid / Thinkery
Context Runtime	Continuous AutoTune
SDK	Hosted tuning runs
MCP / Proxy	Tuning history
Core compression	Fleet optimization
Context selection	Org-wide recommendations
Local memory	Shared/team state
Context Kit format	Private Kit Registry
Local Kits	Managed/Premium Kits
Local Dyno	Large-scale replay
Local Receipt	Central evidence
Manual profiles	Auto-generated profiles
Local metrics	Team economics
Local provider use	Unified billing
Provider neutral	SSO / RBAC / policies
One developer	Organization

Der entscheidende Satz:

Manual tuning is open. Continuous tuning is commercial.

Das gefällt mir sehr.

13. Damit haben wir zwei Growth Engines
Distribution Engine
LeanCTX OSS
+
Codex
Claude Code
Cursor
+
Free Dyno

Das bringt Entwickler.

Revenue Engine
Custom Agents
+
AutoTune
+
Team / Enterprise
+
Verified Economics

Das bringt Geld.

Und beide verstärken sich.

Das ist viel besser als B2C und B2B als zwei getrennte Produkte zu behandeln.

14. B2C ist eigentlich B2D: Developer / Power User

Ich würde keinen klassischen Consumer-Markt angreifen.

Unser B2C-Kunde ist:

der Entwickler, der jeden Tag Codex, Claude Code oder Cursor nutzt.

Seine Journey:

GitHub / Post
    ↓
lean-ctx install
    ↓
lean-ctx connect claude
    ↓
local savings
    ↓
Try Dyno
    ↓
"holy shit"
    ↓
LeanCTX Pro

Das muss extrem frictionless sein.

15. LeanCTX Pro

Launch-Hypothese, nicht finaler Preis:

Free

CHF 0

Local Runtime.

Coding-Agent Integration.

Local Dyno.

Local reports.

Basic Profiles.

Community Kits.

Pro

CHF 29/month

Cloud Dyno history.

Private Profiles.

Multi-device sync.

Scheduled benchmarks.

Private-project hosted experiments.

Longer evidence history.

AutoTune runs.

Priority new model/profile updates.

Das ist ein Produkt, für das ich mir vorstellen kann, dass Power User zahlen.

16. Der Playground kann brutal gut werden

Landing Page:

See what LeanCTX does to an agent.

Dann direkt:

Choose your agent:


[ Claude Code ]
[ Codex ]
[ Cursor ]
[ Custom Agent ]

Danach drei Möglichkeiten:

Try demo workload
Connect GitHub repository
Upload agent trace

Für den ersten Release reicht:

Try demo workload.

Kein Login.

17. Der Browser zeigt live beide Arms

Links:

Stock agent
READ
14,421 tokens


SEARCH
8,822 tokens


TEST
21,425 tokens


HISTORY
64,110 tokens

Rechts:

LeanCTX tuned
OUTLINE
1,822 tokens


SEARCH
1,104 tokens


TEST SUMMARY
3,120 tokens


REUSED
7,233 avoided

Und unten:

SAME TASK


Baseline             $0.42
LeanCTX              $0.08


Quality              PASS / PASS
Cost                 -81%
Context              -88%

Dann der CTA:

Tune my agent.

Das ist wesentlich besser als eine Marketingseite, die 90 % Savings behauptet.

Der User sieht es.

18. Private Repos: BYOK zuerst

Für den nächsten Playground-Level würde ich nicht sofort Providerkosten subventionieren.

Der User bringt:

OpenAI Key
Anthropic Key

Key nur für diesen Run / idealerweise client-side oder ephemeral handling.

Thinkery berechnet:

tuning
measurement
report

Der Provider berechnet:

inference

Das spart euch Cash und reduziert Billing-Komplexität.

19. Dann kommt „Run through LeanCTX“

Später:

Base URL:


https://api.leanctx.com/v1

User setzt:

OPENAI_BASE_URL
ANTHROPIC_BASE_URL

und bekommt automatisch:

optimization
measurement
receipts
profiles
routing

Das wäre euer Managed Tuning Relay.

Aber wichtig:

Das ist noch nicht Agent Hosting.

Wir hosten zunächst den Tuning-/Context Layer.

Das ist viel fokussierter.

20. Unified Billing kann danach kommen

Wenn jemand keine Provider Keys mehr verwalten will:

Thinkery Credits
         │
    ┌────┼─────┐
    ▼    ▼     ▼
 OpenAI Claude Gemini

Cloudflare macht bei seinem aktuellen Unified Billing etwas sehr Ähnliches: Providerpreise werden durchgereicht und auf gekaufte Credits wird eine 5%-Gebühr erhoben.

Das zeigt zumindest, dass das Modell technisch und kommerziell gut nachvollziehbar ist.

Ich würde für Thinkery später ebenfalls über:

provider cost + transparent infrastructure fee

nachdenken.

Aber nicht als wichtigste Marge.

Unsere Marge kommt aus Tuning.

21. Agent Hosting: ja — aber sehr kontrolliert

Du hattest gefragt:

Können die Agents irgendwann auch bei uns laufen?

Ja.

Aber bitte nicht:

Build any agent
drag nodes
connect Gmail
connect CRM
voice agent
sales agent
workflow builder

Das wäre Scope-Suizid.

Stattdessen:

Run your existing agent on a LeanCTX-tuned runtime.

Das ist etwas völlig anderes.

22. Managed Execution wäre nur die vierte Integrationsstufe
ATTACH
existing agent + LeanCTX


WRAP
framework + LeanCTX adapter


EMBED
custom agent + LeanCTX SDK


RUN
custom agent on Thinkery infrastructure

Das ist eine wunderschöne Progression.

Jede Stufe geht tiefer.

Aber alles bleibt:

Agent tuning.

23. B2B: Hier würde ich JETZT Geld holen

Wenn schnelle Einnahmen das Ziel sind, würde ich nicht auf CHF 29 Pro warten.

Der Revenue Shortcut heißt:

Agent Tuning Sprint

Nicht „Consulting“.

Nicht „AI Strategy“.

Nicht offene Exploration.

Eine definierte Productized Service.

24. Agent Tuning Sprint

Ich würde etwa sagen:

Give us one production AI agent.
We benchmark it, tune it with LeanCTX, validate quality and deliver the optimized configuration plus verified savings evidence.

Scope:

1 agent
1 workflow
1–2 weeks
baseline
native/sidecar treatments
quality gate
tuning profile
integration
report

Preis-Hypothese:

CHF 7'500–15'000.

Und die Gebühr kann teilweise auf einen Annual Contract angerechnet werden.

Eure eigene Roadmap hatte bereits $5k–15k für einen Verified Savings Pilot vorgesehen.

Das würde ich inzwischen lieber Tuning Sprint nennen.

Viel produktnäher.

25. Eure kostenlosen Piloten würde ich begrenzen

Aktuell sagt das Pilotmaterial klar:

CHF 0 für vier Wochen und danach 10 % der verifizierten Einsparung.

Für die ersten Lighthouse-Kunden ist das okay.

Aber wenn du jetzt Geld brauchst, würde ich daraus machen:

3 Founding Design Partner slots: CHF 0.

Danach:

Paid Tuning Sprint.

Sonst ziehst du Unternehmen an, die gerne experimentieren, aber nie kaufen.

26. B2B Recurring Pricing

Ich würde nicht nur pro Seat abrechnen.

Bei Agent Infrastructure korreliert Wert eher mit:

workflows
agents
context volume
tuning runs
organization controls

Mein Modell wäre:

Platform Fee
+
Tuning Usage
+
Enterprise Controls
+
optional Performance Fee
27. Launch-Preise als Hypothese

Nicht in Stein gemeißelt:

Tier	Preisidee	Buyer
OSS	CHF 0	Developer
Pro	CHF 29/mo	Power User
Team	CHF 299–499/mo	kleines AI Team
Business	CHF 1.5k–3k/mo	mehrere Agents
Enterprise	CHF 25k–100k+/year	AI Platform / Enterprise
Tuning Sprint	CHF 7.5k–15k	erster B2B Einstieg

Langfuse zeigt im aktuellen Markt ebenfalls ein Modell, bei dem offene/self-service Basisfunktionen in bezahlte Team- und Enterprise-Funktionen übergehen; aktuelle Team-/Enterprise-Angebote monetarisieren unter anderem SSO, Audit/Retention und organisatorische Funktionen.

Das heißt nicht, dass deren Preis eurer sein sollte.

Aber die open developer layer → paid organization layer ist ein etablierter Infrastruktur-Pattern.

28. 10% Savings Share: behalten — aber als Waffe

Ich würde Performance Pricing nicht als einzige Monetarisierung benutzen.

Warum?

Weil ihr sonst monatelang diskutiert:

Was ist die Baseline?

Welches Provider Pricing gilt?

Ist der Workload identisch?

Was ist durch LeanCTX verursacht?

Das verzögert Cash.

Besser:

Platform contract
+
optional 10% of verified savings

oder:

minimum annual fee
credited against gain share

Beispiel:

CHF 24k annual platform minimum


10% verified savings:
CHF 41k


customer pays:
CHF 41k total

Nicht:

CHF 24k + CHF 41k

Das wäre am Anfang schwer verkäuflich.

So bleibt euer Alignment-Argument bestehen und ihr bekommt trotzdem planbaren Revenue.

29. Der große Commercial Moat: AutoTune

Hier würde ich proprietären Wert aufbauen.

OSS User:

„Hier sind die Tuning-Knobs.“

Paid User:

„Find the optimal settings for me.“

Thinkery AutoTune könnte beispielsweise automatisch hunderte Varianten testen:

compression depth
read mode
retrieval depth
context budget
memory reuse
tool result transforms
model
kit
routing

Und daraus eine Pareto Frontier erzeugen:

                  HIGH QUALITY


                     ● A
                   ●
                 ● B


              ● C


LOW COST -------------------- HIGH COST

Dann:

Recommended profile: B

Warum?

82% lower input cost
same task pass rate
13% lower latency
zero evidence violations

Dafür bezahlen Unternehmen.

30. Und genau hier entsteht ein Daten-Moat

Nicht indem wir Kundencode klauen oder zentralisieren.

Sondern durch Performance Metadata:

task class
agent type
model
context strategy
compression profile
tool mix
context volume
quality outcome
latency
cost

Über Zeit lernt Thinkery:

Für Repo-Agenten mit diesem Workload und Modell funktioniert Strategy X meistens besser als Y.

Das ist wertvoll.

Und es kann privacy-preserving passieren.

Eure Zielarchitektur fordert bereits, dass Cloud lokalen Source Code nicht ohne explizites Feature und Consent lesen darf und dass lokale Compression nicht von einem Hosted Service abhängig werden darf.

Diese Grenze würde ich niemals aufgeben.

Local-first kann ein Teil des Moats werden.

31. Tuning Profiles werden ebenfalls ein Moat

Stell dir vor, in zwei Jahren existieren:

@thinkery/codex-large-monorepo
@thinkery/claude-financial-analysis
@thinkery/code-review-security
@siemens/internal-engineering
@customer/payment-agent-v7

Ein Profil enthält nicht den Agent.

Es enthält:

How this agent should consume context.

Das ist hochgradig wiederverwendbar.

Und kann über .ctxpkg / Context Kits verteilt werden.

Die technische Basis für Packages, Compatibility, Signatures, Composition und Registry ist bereits im LeanCTX-Code angelegt.

32. Aber Marketplace: später

Ganz wichtig.

Wir bauen jetzt keinen Marketplace.

Wir bauen:

Tuning Profile

Dann:

Private Profiles

Dann:

Team Profile Registry

Wenn irgendwann viele Profiles geteilt werden:

Marketplace

Customer Pull bestimmt das.

33. Das Produkt bekommt dadurch einen extrem einfachen Loop

Ich würde diese sechs Wörter intern überall hinschreiben:

Connect → Measure → Tune → Prove → Deploy → Repeat

Alles, was LeanCTX baut, muss in einen dieser Schritte passen.

Connect

SDK / MCP / Proxy / Adapter.

Measure

Tokens / cost / tools / quality.

Tune

Context strategy.

Prove

A/B + Receipt.

Deploy

Tuning Profile.

Repeat

Continuous AutoTune.

Wenn ein Feature nirgendwo reinpasst:

Parken.

Damit bleiben wir fokussiert.

34. Unser North-Star-Metric

Nicht GitHub Stars.

Nicht Tokens saved.

Nicht Compression Ratio.

Ich würde intern einen einzigen technischen/business North Star verwenden:

Verified cost per successful task

Also:

Total agent cost
─────────────────────
Successful outcomes

mit Quality Gate.

Dann dürfen wir ruhig:

mehr Tokens verwenden,
ein teureres Modell wählen,
eine zusätzliche Tool-Abfrage machen,

wenn der erfolgreiche Outcome am Ende effizienter wird.

Das macht euch viel intelligenter als einen bloßen Compressor.

35. Dadurch verlieren wir Coding Agents nicht

Im Gegenteil.

Cursor/Codex/Claude Code werden unsere massive Distribution Layer.

Der Developer benutzt LeanCTX kostenlos:

Claude Code + LeanCTX
Codex + LeanCTX
Cursor + LeanCTX

Später baut seine Firma einen Custom Agent.

Und er sagt intern:

„Wir benutzen bei Claude Code bereits LeanCTX. Lasst uns die Runtime doch auch in unseren Agent integrieren.“

Das ist der PLG Funnel.

Das könnte extrem stark werden.

36. Deshalb würde ich Coding-Agent-Support sogar obsessiv gut machen

Nicht 17 Framework Adapter gleichzeitig.

Die ersten vier Targets:

Claude Code
Codex
Cursor
Custom Python/TS Agent

Das reicht.

Für jedes Ziel muss es geben:

one-command setup
doctor
benchmark
receipt
uninstall

Das ist die Developer Experience.

37. Was die Konkurrenz betrifft: SDK ist nicht unser Schutz

Das müssen wir uns glasklar sagen.

Ein SDK kann kopiert werden.

Wrapper können kopiert werden.

Compression kann kopiert werden.

Die aktuelle Headroom-Produktoberfläche beweist genau das: SDK, Proxy, Coding-Agent-Wrapping und Shared Context sind heute bereits Teil dieses Wettbewerbsfelds.

Der Schutz muss tiefer liegen.

38. Fünf Dinge, die ich als Moat bauen würde

Erstens: Tuning Methodology. Unser Benchmark muss der glaubwürdigste Weg werden, Agent Efficiency zu messen.

Zweitens: Tuning Profiles. Portable, versionierte, reproduzierbare Performance-Konfiguration.

Drittens: AutoTune. Die Cloud findet automatisch bessere Profile.

Viertens: Verified Evidence. Nicht „trust our dashboard“, sondern nachvollziehbare Baseline, Treatment, Quality und Evidence.

Fünftens: Cross-agent portability. Ein Unternehmen optimiert Codex, Claude Code und eigene Agents über dieselbe Context Infrastructure.

Das ist deutlich schwerer zu replizieren als ein Compressor.

39. Dein Real-World Evidence Command wird dadurch ein Kernprodukt

Den würde ich jetzt nicht als Nebenfeature behandeln.

Er ist der Anfang von:

LeanCTX Dyno

Dein aktueller Test hat bereits eine sehr starke Struktur:

same workflow
same model
same final question


baseline
vs
LeanCTX


real OpenAI calls
provider cache accounting
real provider-reported token usage

Was jetzt fehlt, ist vor allem ein wirklich gleichwertiges Quality Gate.

Sobald das sauber drin ist:

Cost ↓
Quality =

wird das die Grundlage des ganzen Commercial Motions.

40. Der Playground sollte auf genau demselben Engine Path laufen

Keine Fake-Webdemo.

Kein hartcodiertes Diagramm.

Playground
     ↓
Dyno Service
     ↓
same LeanCTX Runtime
     ↓
real provider
     ↓
real Receipt

Der User muss dieselbe Technologie sehen, die später sein Agent benutzt.

Dann ist der Playground gleichzeitig:

demo
benchmark
lead generator
technical proof
onboarding

Sehr effizient.

41. Und wir brauchen dafür noch nicht die komplette Cloud

Das ist wichtig.

Der letzte Audit zeigte, dass eure Cloud zwar Checkout, Portal, Webhooks, Entitlements und Registry-Code besitzt, aber unter anderem noch keinen vollständigen öffentlichen Signup/Login-Flow und keinen nachgewiesenen live Stripe/Postgres-End-to-End-Flow hatte.

Ich würde deshalb nicht drei Wochen Cloud-Platform reparieren, bevor wir einen Playground haben.

Der Dyno kann zunächst ein kleiner separater Service sein.

web
 ↓
ephemeral job
 ↓
LeanCTX binary
 ↓
provider
 ↓
result JSON

Fertig.

42. Ich würde die Brand für jetzt ebenfalls brutal vereinfachen

Extern:

LeanCTX

The Context SDK for AI Agents.

Thinkery bleibt:

Built by Thinkery AG, Switzerland.

Nicht jetzt noch zehn Subbrands.

„Thinkery Platform“ kann irgendwann auftauchen, wenn Enterprise Control wirklich ein eigenständiges Produkt geworden ist.

Bis dahin:

LeanCTX
├── OSS
├── Cloud
└── Enterprise

als mentale Produktfamilie reicht.

43. Website

Ich würde sie perspektivisch ungefähr so eröffnen:

The Context SDK for AI Agents.

Tune Codex, Claude Code, Cursor or your own agent to use less context, cost less and preserve quality.

[Try the Dyno] [Install LeanCTX]

Darunter:

Same agent. Same task. Less context. Proven outcome.

Dann Live Benchmark.

Danach Integration Modes:

Attach
Wrap
Embed

Fertig.

Nicht 82 Features.

44. Das ultimative Geschäftsmodell

Wenn das funktioniert, habt ihr langfristig vier Revenue Streams, aber eine einzige Product Thesis:

Developer subscription
        +
Tuning usage
        +
Enterprise control
        +
Managed infrastructure

Und später als Upside:

premium profiles / kits
performance fee
marketplace

Das ist sehr venture-scale-fähig, ohne heute alles bauen zu müssen.

45. Mein Fokusplan für die nächsten 8 Wochen
Product Thesis einfrieren: LeanCTX — The Context SDK for AI Agents. Der SDK ist die Surface, der Tuning Loop der Moat. Keine neuen Produktkategorien.
LeanCTX Dyno aus evidence realworld machen: Raw vs Sidecar vs Native SDK, echte Provider Usage, echtes Quality Gate, versioniertes Receipt.
Einen Reference Custom Agent bauen: möglichst klein. Zwei Implementierungen desselben Agents: stock und LeanCTX-native. Das ist das zentrale SDK-Demo.
Claude Code, Codex und Cursor als First-Class Adapters behandeln: connect, doctor, dyno, uninstall. Nicht jedes Framework der Welt.
Playground shippen: zuerst Sample Workload ohne Login; anschließend BYOK. Live-Dyno, keine Marketing-Simulation.
Den ersten Revenue Motion umbenennen: Agent Tuning Sprint, CHF 7.5k–15k als Hypothese. Maximal drei klar ausgewiesene kostenlose Founding Design Partners.
OSS/Paid Boundary einfrieren: lokale Runtime, SDK, Core Tuning und Local Dyno offen; Continuous AutoTune, hosted experiments, private profiles, team evidence und organizational control kommerziell.
Erst nach Nachfrage Managed Relay bauen: Provider-compatible Endpoint. Unified Billing und Managed Agent Execution danach, nicht davor.
Der Satz, der für mich gerade alles zusammenführt

LeanCTX doesn't build the agent. It tunes the agent.

Und technisch etwas präziser:

LeanCTX is the Context SDK for AI Agents — a tuning layer that measures how an agent uses context, finds a more efficient strategy, proves the result, and deploys that strategy back into the agent.

Das kann ich mir als große Firma vorstellen.

Nicht, weil „Chiptuner“ ein lustiges Bild ist.

Sondern weil dahinter ein sehr reales Infrastructure-Modell steckt:

Agent
 ↓
Profile
 ↓
Context Runtime
 ↓
Execution
 ↓
Receipt
 ↓
Dyno
 ↓
AutoTune
 ↓
better Profile

Wenn wir diesen Loop besitzen, können Codex, Claude Code, Cursor und die nächste Generation von Agent Frameworks machen, was sie wollen.

Sie werden nicht zu unseren Gegnern. Sie werden zu den Motoren, die LeanCTX tunen kann.

richtig geil! dann gib mir nun auch die komplett neue website und branding aus! wieder absolut crazy gehen!

Ja. Jetzt würde ich die komplette Marke um genau diesen Gedanken neu aufbauen. Nicht als Auto-Gimmick, sondern als Performance-Engineering-Brand für AI Agents.

Der „Chiptuner“-Gedanke ist intern extrem stark, weil er jede Product-Entscheidung erklärt:

Wir bauen nicht den Agent.
Wir bauen nicht das Model.
Wir holen mehr Performance aus dem bestehenden System heraus.

Und nach außen übersetzen wir das erwachsen:

LeanCTX
The Context SDK for AI Agents.
Tune any agent. Prove every gain.

Das wäre ab jetzt mein Fundament.

1. Die neue Brand-Idee

Ich würde die Marke auf drei Begriffe reduzieren:

PERFORMANCE. CONTROL. PROOF.

LeanCTX soll sich anfühlen wie die Software eines Performance-Labs.

Nicht wie:

generisches AI SaaS,
Cyberpunk,
LLM Dashboard,
bunte Agent-Avatare,
Roboter,
Glowing Brain,
Gradient-Hölle.

Sondern wie:

präzise technische Instrumentierung.

Wenn jemand LeanCTX sieht, soll er denken:

„Das Ding sitzt tief im System.“

Nicht:

„Da hat jemand noch ein AI Dashboard gebaut.“

2. Der zentrale Brand Claim

Ich würde drei Ebenen sauber trennen.

Category

The Context SDK for AI Agents.

Das ist die Antwort auf:

What is LeanCTX?

Product Promise

Tune any agent. Prove every gain.

Das ist die Antwort auf:

Why should I care?

Deeper thesis

Context is performance.

Das ist die philosophische Brand Line.

Diese drei reichen.

Nicht 17 unterschiedliche Claims.

3. Warum „Context is performance“ geil ist

Denn der Agent ist nicht automatisch besser, nur weil er ein besseres Model bekommt.

Seine Performance hängt auch davon ab:

was er liest,
wann er es liest,
wie viel davon,
was er wiederverwendet,
was er vergisst,
was komprimiert wird,
was exakt bleiben muss,
welcher Context über mehrere Turns akkumuliert.

Deshalb:

Context is not payload. Context is a performance surface.

Das ist im Kern sogar das, was deine frühere Arbeit bereits formuliert hat: LeanCTX sollte als dünne, kontrollierbare Context-Schicht unter bestehenden Tools sitzen und entscheiden, was überhaupt zum Modell gelangt.

4. Das visuelle Konzept: THE PERFORMANCE LAB

Ich würde NICHT mit Autos arbeiten.

Keine Turbos.

Keine Tachometer.

Keine Carbonfaser.

Keine Rennflaggen.

Das wäre nach drei Wochen cringe.

Wir nehmen stattdessen die Ästhetik eines technischen Prüfstands:

Kalibrierungsmarkierungen
Messkurven
Referenzlinien
Koordinaten
Seriennummern
technische Labels
Before/After-Traces
Explosionszeichnungen
Querschnitte
präzise Tabellen
Hashes
Run IDs
Timestamps
Verification Stamps

Das Auto-Tuning ist das mentale Modell.

Metrology / Performance Engineering ist die visuelle Sprache.

5. Die Farbwelt

Ich würde LeanCTX fast vollständig monochrom machen.

Carbon

#0A0A0A

Hauptfarbe.

Bone

#F2F0E9

Kein klinisches Weiß.

Ein leicht warmes technisches Papier.

Steel

#9A9A94

Metadata, Diagramme, sekundäre Informationen.

Signal Orange

ungefähr:

#FF4B00

Nur für:

aktive Tuning-Parameter,
Gains,
CTAs,
ausgewählte Linien,
Fokus.

Das wird euer Wiedererkennungsmerkmal.

Und zusätzlich nur semantisch:

Verified Green

für:

VERIFIED / PASS

Nicht als Brandfarbe.

6. Kein Gradient

Wirklich.

LeanCTX sollte aussehen, als könnte es 2026 oder 2040 entstanden sein.

Schwarz.

Bone.

Linien.

Daten.

Typographie.

Signal.

Das gibt euch diesen industriellen Premium-Look, den wir sowieso gesucht haben.

7. Typographie

Ich würde zwei Schriften verwenden.

Primary

Eine sehr präzise Neo-Grotesk.

Richtung:

ABC Diatype
Söhne
Suisse
alternativ eine sehr hochwertige Open-Font-Lösung wie Instrument Sans

Nicht weich.

Nicht verspielt.

Technical

Mono.

Für:

run_01f8a
-84.3%
14,016 tokens
VERIFIED

Richtung IBM Plex Mono / ähnlich.

8. Logo

Den Namen würde ich nicht ändern.

LeanCTX hat Brand Equity.

Ich würde auch das Camel Case behalten:

LeanCTX

Der neue Logo-Mark könnte aus einer extrem einfachen Compression-Geometrie entstehen.

Zum Beispiel konzeptionell:

──────────┐
──────────┼─────
──────────┘

Mehrere Informationspfade laufen in einen fokussierten Pfad zusammen.

Oder:

████████████      ███
████████████  →   ███
████████████      ███

Natürlich abstrakter und viel eleganter umgesetzt.

Das Symbol steht für:

More signal. Less context.

Und es lässt sich perfekt animieren.

9. Thinkery verschwindet nicht

Brand Architecture:

THINKERY
Company


        │
        ▼


LEANCTX
Product
The Context SDK for AI Agents

Website:

LeanCTX
by Thinkery

Verträge:

Thinkery AG

GitHub:

LeanCTX

Developer Experience:

LeanCTX

Kein unnötiges Doppelleben.

10. Die Website-Struktur

Ich würde leanctx.com drastisch vereinfachen.

/
├── Dyno
├── Integrations
│   ├── Claude Code
│   ├── Codex
│   ├── Cursor
│   └── Custom Agents
├── SDK
├── Benchmarks
├── Enterprise
├── Pricing
├── Docs
└── GitHub

Mehr braucht es zunächst nicht.

11. DIE KOMPLETTE HOMEPAGE

Jetzt würde ich sie so schreiben.

NAVIGATION

Links:

LeanCTX

Mitte:

Product
Dyno
Integrations
Enterprise
Docs

Rechts:

GitHub

Try Dyno →

HERO

Kleine technische Eyebrow:

LEANCTX / CONTEXT PERFORMANCE ENGINEERING

Dann riesig:

The Context SDK for AI Agents.

Darunter:

Tune Codex, Claude Code, Cursor or your own AI agent to use context more efficiently — without rebuilding the agent.

Dann:

Measure it. Tune it. Prove it.

CTAs:

Try the Dyno

Install LeanCTX →

Darunter klein:

Open source. Local-first. Provider-neutral.

12. Der Hero darf NICHT statisch sein

Rechts vom Hero oder darunter läuft ein echtes kleines Dyno-Modul.

STOCK
RUN / 001


INPUT
139,115 tokens


CACHED
87,040 tokens


COST
$0.370


QUALITY
PASS

Dann verschiebt sich ein Tuning Regler.

LEANCTX
RUN / 002


INPUT
14,016 tokens


CACHED
8,192 tokens


COST
$0.058


QUALITY
PASS


GAIN
-84.3%

Und unten:

VERIFIED

Das wird euer visuelles Signature Element.

13. Direkt danach: der wichtigste Satz der Website

Groß über ganze Breite:

Don't replace your agent. Tune it.

Text:

LeanCTX sits inside or alongside the agents you already use. It controls how context is selected, represented, reused and measured before inference.

Darunter:

CODEx       CLAUDE CODE       CURSOR       CUSTOM AGENT


  │              │              │                │
  └──────────────┴──────┬───────┴────────────────┘
                        ↓
                     LeanCTX
                        ↓
                   MODEL / TOOLS

Das erklärt die gesamte Firma in einer Grafik.

14. Dann die drei Integrationstiefen

Headline:

One engine. Three ways in.
01 / ATTACH

No code changes.

MCP, proxy or native tool integration.

Ideal für:

Claude Code
Codex
Cursor

CTA:

Connect an agent →

02 / WRAP

A few lines of code.

Add LeanCTX to an existing framework or model client.

Ideal für:

OpenAI Agents
Claude Agent SDK
LangGraph
Vercel AI SDK

03 / EMBED

Full context control.

Use the LeanCTX SDK directly inside your own agent loop.

Ideal für:

Custom enterprise agents.

Unterhalb:

The deeper LeanCTX integrates, the more of the context lifecycle it can optimize.

Das ist eure Product Thesis.

15. Danach: THE DYNO

Schwarzer Block.

Kleine Beschriftung:

LEANCTX DYNO / AGENT BENCHMARKING

Headline:

You wouldn't tune an engine without a dyno.

Darunter:

So why tune an AI agent by looking at a token counter?

Dann:

LeanCTX Dyno runs the same workload under different context strategies and measures the result.

UI:

WORKLOAD
payment-agent / code-review / run-042


──────────────────────────────────────


                COST     QUALITY


STOCK           $1.00     94
PROXY           $0.54     94
SDK             $0.31     95


──────────────────────────────────────


RECOMMENDED
balanced-v7


↓ 69% COST
↑ 1% QUALITY


VERIFIED

CTA:

Run my agent on the Dyno →
16. Genau dort kommt der Playground

Das darf kein Fake Calculator sein.

User wählt:

What do you want to tune?

Buttons:

Claude Code
Codex
Cursor
Custom Agent

Danach:

Option A

Run a demo workload

Kein Login.

Option B

Bring my API key

Real Provider Run.

Option C

Connect my local agent

CLI-Anleitung:

lean-ctx connect codex
lean-ctx dyno

Und später:

Option D

Run on Thinkery

Managed Infrastructure.

17. Playground Landing Copy
Put an agent on the Dyno.

Run the same task stock and tuned. Compare context, provider usage, cost and outcome.

Buttons:

Start with demo

Connect my agent

Darunter:

Nothing is hidden behind a benchmark score. Every run produces a receipt.

Sehr wichtig.

18. Der nächste Website-Bereich
Context is performance.

Fünf Module.

SELECT

Give the agent what matters.

LeanCTX decides which information should become active context.

COMPRESS

Keep structure. Remove waste.

Represent large source and tool outputs at the right fidelity.

REUSE

Stop paying for the same information twice.

Reuse context already seen by the agent or its peers.

RECOVER

Compression without amnesia.

Preserve references to exact source when the agent needs more detail.

MEASURE

Every optimization needs a baseline.

Track provider usage, cost and outcome.

Das ist die ganze Engine.

Nicht 82 Tools.

19. Dann kommt der große Performance-Loop

Volle Breite.

CONNECT
   ↓
MEASURE
   ↓
TUNE
   ↓
PROVE
   ↓
DEPLOY
   ↓
REPEAT
   ↺

Darunter:

Agent tuning is a loop, not a setting.

Und hier erzählen wir die eigentliche Zukunft.

20. AUTO TUNE TEASER

Nicht als riesiges Produktversprechen.

Kleine Preview.

COMING TO LEANCTX CLOUD

AutoTune

Run multiple context strategies against representative workloads and find the best cost/quality profile automatically.

Visual:

QUALITY
  │
  │               ● quality-first
  │            ●
  │        ● balanced  ← RECOMMENDED
  │     ●
  │  ● cost-first
  └──────────────────────── COST

Und darunter:

Deploy the winning profile back into your agent.

Das ist die kommerzielle Zukunft.

21. Dann: TUNING PROFILES

Headline:

Performance you can version.

Beispielkarte:

LEANCTX PROFILE


payments-review
v1.4.2


MODEL
gpt-5


CONTEXT BUDGET
64k


READ STRATEGY
outline-first


REUSE
enabled


RECOVERY
enabled


KIT
payments-security@2.1


─────────────────


BASELINE COST
$0.82


TUNED COST
$0.31


QUALITY
PASS


SIGNED

Text:

Every tuning decision can become a reproducible profile — versioned alongside the agent.

Das ist ein richtig gutes Produktobjekt.

22. Danach: PROOF

Bone background.

Headline:

No savings claim without a baseline.

Das ist eine fantastische Brand Line.

Dann:

TASK
MODEL
PROVIDER
BASELINE
TREATMENT
TOKEN USAGE
CACHE USAGE
COST
QUALITY
PROFILE
SIGNATURE

Und:

LeanCTX Receipts make agent performance reproducible instead of anecdotal.

Das differenziert euch brutal.

23. Euer Benchmark darf gezeigt werden — aber sauber

Nicht Hero:

86% cheaper AI agents!

Sondern unter:

BENCHMARK / 2026-08

Controlled five-turn coding-agent workloads using real OpenAI API calls.

Dann:

SMALL
85.0% fewer input tokens
78.9% lower calculated API cost


MEDIUM
89.9%
84.3%


LARGE
91.0%
86.0%

Und direkt darunter:

Results are workload-specific. Provider usage was measured from API responses. Pricing was calculated from the declared model pricing. These numbers are not a universal savings promise.

Das wirkt viel seriöser als 99 % der AI-Websites.

24. Danach Social Proof

Keine riesigen Logos falls nicht erlaubt.

Headline:

Built in the open. Tested in real work.

Wavect:

64.1%
less context


92.7%
less MCP traffic


56.6%
estimated token-cost reduction

Und direkt:

Measured by Wavect in its own engineering workflows. Results are not transferred to other workloads.

Genau dieselbe Disziplin wie im aktuellen Pilotmaterial.

25. Coding Agents bekommen einen eigenen Block

Das ist essenziell.

Headline:

Your coding agent stays your coding agent.

Cards:

Claude Code

lean-ctx connect claude

Codex

lean-ctx connect codex

Cursor

lean-ctx connect cursor

Darunter:

Keep your existing workflow. Add LeanCTX underneath it.

Damit sieht kein heutiger User:

„Oh, jetzt macht Yves nur noch Enterprise SDK.“

26. Dann Custom Agents

Schwarzer Hintergrund.

Eyebrow:

LEANCTX SDK

Headline:

Building your own agent? Go deeper.

Copy:

Embed the LeanCTX Context Runtime directly into your agent and control context before it becomes model input.

Code:

from leanctx import LeanCTX


ctx = LeanCTX(project=".")


agent = ctx.wrap(agent)


result = agent.run(
    "Review the payment service"
)


print(result.leanctx.receipt())

Darunter:

Python / TypeScript / Rust

Nicht 500 Zeilen.

Vier Zeilen.

27. Enterprise kommt erst danach

Headline:

**One agent is tuning.

One hundred agents is infrastructure.**

Das ist richtig stark.

Copy:

Thinkery extends LeanCTX from local agent performance to organizational control.

Drei Kategorien:

CONTROL

Policies
Budgets
Access
SSO / RBAC

EVIDENCE

Shared receipts
Audit
Economics
Quality

DISTRIBUTION

Private Profiles
Private Context Kits
Team standards

CTA:

Tune an enterprise agent →

Nicht:

Book Enterprise Platform Demo.

Der Verkauf beginnt weiterhin beim Agent.

28. Der OSS-Bereich

Das muss eine starke Statement Section werden.

The engine stays open.

Developers should be able to build and tune great agents without asking Thinkery for permission.

Links:

View source →

Read the SDK docs →

Dann:

Thinkery earns revenue when teams need continuous tuning, shared control and organizational infrastructure.

Das ist extrem vertrauensbildend.

29. PRICING PAGE

Ich würde sie komplett nach dem Tuning-Modell strukturieren.

FREE
Developer

$0

For tuning agents locally.

LeanCTX Runtime
Context SDK
Claude Code / Codex / Cursor
Local Dyno
Local Profiles
Local Receipts
Community Kits
Local metrics

CTA:

Install

PRO
Tuner

$29 / month

For developers who continuously tune their agents.

everything in Free
Dyno history
cloud benchmark runs
AutoTune credits
private Profiles
cross-device sync
scheduled benchmarks
extended evidence history

CTA:

Start tuning

TEAM
Team

Vielleicht:

from $399 / month

shared agents
shared profiles
private kits
team economics
centralized receipts
team AutoTune
access controls
priority support

CTA:

Start a Team

ENTERPRISE

Custom.

self-hosted
SSO / SCIM
RBAC
policies
audit
retention
fleet economics
private registry
enterprise connectors
SLAs
support

CTA:

Tune one production agent

Das CTA ist wichtig.

Nicht:

Contact sales.

30. B2B SERVICE PAGE

Das wird euer schnellstes Geld.

URL:

/tuning-sprint

Headline:

Put one production agent on the Dyno.

Subline:

We baseline it, integrate LeanCTX, tune the context strategy and verify the result against the same workload.

Dann:

01 CONNECT
02 BASELINE
03 TUNE
04 VALIDATE
05 DEPLOY

Output:

baseline
optimized integration
Tuning Profile
evidence report
rollout recommendation

Preis:

Agent Tuning Sprint — from CHF 7,500

Wirklich.

Das macht euch viel mehr zu einem Produktunternehmen als „Free Pilot“.

31. Der Business Outcome

Nicht:

„Token compression.“

Sondern:

Lower cost per successful agent task.

Das sollte überall vorkommen.

COST
────────────
SUCCESS

Damit seid ihr unabhängig davon, ob morgen Tokens wieder 70 % günstiger werden.

32. Die neue Sprache

Ich würde einen Brand Vocabulary definieren.

Wir sagen

Tune
Baseline
Tuned
Run
Dyno
Profile
Receipt
Gain
Context Budget
Quality Gate
Verified
Stock
Deploy
Retune

Wir sagen möglichst nicht

AI magic
Transformative AI
Revolutionary
Context orchestration fabric
Next-generation intelligence layer
Cognitive architecture
AI operating system

Das klingt alles sofort nach Startup-Suppe.

33. Ein paar Brand Lines, die ich verwenden würde

Nicht gleichzeitig. Aber als Campaign Library:

Tune any agent. Prove every gain.

Context is performance.

Don't replace your agent. Tune it.

No savings claim without a baseline.

One agent is tuning. One hundred agents is infrastructure.

Performance you can version.

Less waste. Same job. Proven.

Every agent has a context strategy. Most just don't know it yet.

Der letzte ist richtig stark für Content.

34. Social Content bekommt dadurch ebenfalls eine klare Identität

LinkedIn Post:

Every AI agent has a context strategy.


Most teams just never designed one.


The agent reads.
Searches.
Adds tool output.
Keeps history.
Reads again.


And the context window quietly becomes the architecture.


That's what I'm working on with LeanCTX.


The Context SDK for AI Agents.

Das ist eine echte Category Story.

35. Visual Social Posts

Immer derselbe Grid.

Zum Beispiel:

LEANCTX DYNO / RUN 0042


STOCK                   TUNED


139,115                 14,016
TOKENS                   TOKENS


$0.370                   $0.058
COST                     COST


─────────────────────────────


GAIN
-84.3%


REAL OPENAI API USAGE

Ein Blick.

Man weiß:

LeanCTX.

36. GitHub README

Der muss ebenfalls komplett geändert werden.

Ganz oben:

LeanCTX
The Context SDK for AI Agents.


Tune Codex, Claude Code, Cursor
or your own agent.

Dann:

curl ...
lean-ctx connect codex
lean-ctx dyno

Dann echte Ausgabe.

Dann:

Attach
Wrap
Embed

Dann Features.

Nicht Features zuerst.

37. Docs

Auch nicht mehr:

Getting Started
CLI
Tools
MCP
82 commands
...

Sondern:

GET STARTED


Tune a Coding Agent
Build with the SDK
Run a Dyno Benchmark


INTEGRATE


Claude Code
Codex
Cursor
Python
TypeScript
Rust


UNDERSTAND


Context Sessions
Tuning Profiles
Receipts
Context Kits
Recovery

Das ist ein Mental Model.

Genau das war ohnehin immer eines deiner stärkeren Prinzipien: gute Developer Experience braucht einen verständlichen Pfad statt Feature-Wüste.

38. Dyno wird der Mittelpunkt der kompletten Marketingmaschine

Das liebe ich besonders.

Denn Dyno ist gleichzeitig:

Demo

Schau, was passiert.

Acquisition

Probier deinen Agent.

Evidence

Beweise den Unterschied.

Monetization

Mehr Runs → Pro.

Enterprise lead gen

Der Kunde sieht plötzlich $200k Optimierungspotential.

Product

AutoTune baut auf demselben Benchmark-System.

Ein Feature erzeugt fünf Business-Funktionen.

Das ist Fokus.

39. Wie Thinkery später sichtbar wird

Noch nicht auf jedem Screen.

Vielleicht Footer:

LeanCTX is built by Thinkery AG in Switzerland.

Enterprise:

LeanCTX Enterprise by Thinkery

Thinkery selbst steht langfristig für:

Performance infrastructure for AI systems.

Aber LeanCTX ist der Star.

40. Die Marke sollte außerdem extrem transparent sein

Jeder Benchmark bekommt:

MODEL
DATE
METHOD
WORKLOAD
PROVIDER
PRICING VERSION
CACHE
QUALITY METHOD
RUN ID

Das ist Branding.

Nicht nur Methodik.

Wenn andere AI Companies sagen:

„Up to 90% savings.“

sagt LeanCTX:

Here is the run.

Das wird ein Trust Signal.

41. Das VERIFIED Badge

Sehr sparsam einsetzen.

Zum Beispiel:

┌────────────────────┐
│ LEANCTX VERIFIED   │
│ RUN / A3F120       │
└────────────────────┘

Es bedeutet nicht:

sicher / korrekt / compliant.

Es bedeutet exakt:

Receipt passed declared verification.

Das muss dokumentiert werden.

Aber visuell könnte das sehr stark werden.

42. Der ganze Funnel

Das ist der Teil, den ich am wichtigsten finde.

LINKEDIN / GITHUB
        ↓
LEANCTX WEBSITE
        ↓
TRY DYNO
        ↓
"holy shit"
        ↓
INSTALL
        ↓
CONNECT CLAUDE/CODEX/CURSOR
        ↓
LOCAL SAVINGS
        ↓
PRO
        ↓
DEVELOPER BRINGS LEANCTX TO WORK
        ↓
CUSTOM AGENT TUNING SPRINT
        ↓
TEAM
        ↓
ENTERPRISE
        ↓
AUTOTUNE / CONTROL / PRIVATE PROFILES

Eine Acquisition Story.

Nicht B2C und B2B als zwei Unternehmen.

43. Und das schützt gleichzeitig den Fokus

Jedes neue Produkt muss durch diesen Satz:

Does it help us connect, measure, tune, prove, deploy or repeat an agent context strategy?

Wenn nein:

Parken.

Marketplace?

Später, unter Deploy.

Agent Builder?

Nein.

Generic workflow automation?

Nein.

Voice?

Nein.

CRM?

Nein.

Model hosting?

Nur wenn für Tune/Deploy nötig.

Perfekt.

44. Und es schützt gegen Konkurrenz

Nicht weil niemand „Context SDK“ kopieren kann.

Sondern weil LeanCTX beginnt, ein eigenes Tuning System zu besitzen:

Runtime
    +
Dyno
    +
Profiles
    +
Receipts
    +
AutoTune
    +
Context Kits
    +
Cross-agent integrations

Einzelne Teile sind kopierbar.

Der Feedback Loop ist das Produkt.

45. Das könnte eure Category langfristig werden

Nicht nur:

Context Optimization.

Sondern:

Agent Performance Engineering

und LeanCTX ist:

The Context SDK for AI Agents.

Das ist eine wichtige Unterscheidung.

Die Kategorie, in der Kunden euch finden:

Context SDK.

Die größere Company Story:

Agent Performance Engineering.

Das finde ich richtig mächtig.

46. Mein finaler Hero

Wenn ich leanctx.com morgen neu launchen müsste:

LEANCTX / CONTEXT PERFORMANCE

The Context SDK for AI Agents.

Tune Codex, Claude Code, Cursor or your own agent to use context more efficiently — without rebuilding the agent.

Tune any agent. Prove every gain.

[ Try the Dyno ]    Install LeanCTX →

Open source · Local-first · Provider-neutral

Und rechts läuft ein echter Stock-vs-Tuned Dyno Run.

Das ist LeanCTX.

Keine abstrakte Zukunft.

Kein Headroom-Gegenentwurf.

Keine Agent-Platform-Fantasie.

Ein Produkt, das heute erklärbar ist, heute ausprobiert werden kann, heute verkauft werden kann — und gleichzeitig eine sehr große Architektur unter sich entwickeln kann.