#!/usr/bin/env python3
"""Build deterministic non-archive LeanCTX internal documentation inventory."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DOCS = ROOT / "docs" / "internal"
OUTPUT = DOCS / "DOCS-INVENTORY.md"

AUTHORITIES = {
    "README.md",
    "vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md",
    "execution/SDK-PRODUCTION-DECISION-RECORD.md",
    "vision/06-ENGINE-SDK-CLOUD-PLAN.md",
    "vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md",
    "vision/05-CONTEXT-SDK-POSITIONING.md",
    "execution/MASTER-EXECUTION-PLAN.md",
    "execution/ANTI-ROADMAP.md",
    "execution/PROOF-DOCTRINE.md",
}

# README is navigation authority; the linked sources are product authority.
AUTHORITY_PATH_COUNT = len(AUTHORITIES) - 1

EXECUTION_TRACKERS = {
    "execution/COMPLETE-VISION-DELIVERY-PLAN.md",
    "execution/GITLAB-ISSUES.md",
    "execution/NEXT-STEPS.md",
    "execution/OSS-VISION-DELIVERY-PLAN.md",
    "execution/PRIORITY-MATRIX.md",
    "execution/WEBSITE-IMPLEMENTATION-PLAN.md",
}


def title(text: str) -> str:
    for line in text.splitlines():
        if line.startswith("# "):
            return line[2:].strip().replace("|", "\\|")
    return "(no H1)"


def classify(rel: str, text: str) -> str:
    head = "\n".join(text.splitlines()[:30]).lower()
    if rel in AUTHORITIES:
        return "Canonical"
    if rel.startswith("DOCS-"):
        return "Reference"
    if rel in EXECUTION_TRACKERS:
        return "Execution tracker"
    if rel.startswith("skills/"):
        return "Operational guidance"
    if "classification:** active" in head or "classification:** canonical support" in head:
        return "Active support"
    if "status:** active" in head:
        return "Active support"
    if "research" in head:
        return "Research"
    if rel.startswith("reference/") or rel.startswith("execution/"):
        return "Reference"
    return "Research"


def purpose(rel: str, category: str) -> str:
    if rel == "DOCS-INVENTORY.md":
        return "Deterministic file classification"
    if rel == "DOCS-CONVERGENCE-REPORT.md":
        return "Convergence evidence and blockers"
    if rel == "DOCS-MOVE-MAP.md":
        return "Archived-path recovery"
    return {
        "Canonical": "Authority path",
        "Execution tracker": "Progress only; no architecture authority",
        "Active support": "Current supporting product guidance",
        "Operational guidance": "Agent/document workflow instructions",
        "Research": "Unpromoted direction; no product promise",
        "Reference": "Background, audit, or technical evidence",
    }[category]


def main() -> None:
    rows = []
    counts: dict[str, int] = {}
    paths = sorted(
        path
        for path in DOCS.rglob("*.md")
        if "_archive" not in path.relative_to(DOCS).parts
    )
    for path in paths:
        rel = path.relative_to(DOCS).as_posix()
        text = path.read_text(encoding="utf-8")
        category = classify(rel, text)
        counts[category] = counts.get(category, 0) + 1
        evidence = "self-generated" if path == OUTPUT else "sha256:" + hashlib.sha256(
            text.encode("utf-8")
        ).hexdigest()[:12]
        rows.append((rel, title(text), category, purpose(rel, category), evidence))

    active = sum(counts.get(name, 0) for name in ("Canonical", "Execution tracker", "Active support"))
    archived = sum(
        1
        for path in (DOCS / "_archive" / "sdk-first-convergence-2026-08-24").rglob("*.md")
        if path.is_file()
    )
    lines = [
        "# LeanCTX Internal Documentation Inventory",
        "",
        "> **Classification:** Reference",
        ">",
        "> **Scope:** Every non-archive Markdown document under `docs/internal/**`.",
        "> Generated deterministically by `checks/build-docs-inventory.py`.",
        "",
        "## Counts",
        "",
        f"- Non-archive Markdown documents: **{len(rows)}**",
        f"- Active product/support/tracker documents: **{active}**",
        f"- Canonical authority-path entries: **{AUTHORITY_PATH_COUNT}**",
        f"- Archived in final SDK-first pass: **{archived}**",
        "",
        "A document is active for this count only when classified Canonical, Active",
        "support, or Execution tracker. Operational guidance, Research, and Reference",
        "are non-authoritative. Archived files are excluded.",
        "",
        "## Classification",
        "",
        "| Path | Title | Class | Unique job | Evidence |",
        "| --- | --- | --- | --- | --- |",
    ]
    lines.extend(
        f"| `{rel}` | {name} | {category} | {job} | `{evidence}` |"
        for rel, name, category, job, evidence in rows
    )
    lines.extend(
        [
            "",
            "Historical and superseded material is recoverable through",
            "[DOCS-MOVE-MAP.md](DOCS-MOVE-MAP.md). Classification never overrides the",
            "authority order in [README.md](README.md).",
            "",
        ]
    )
    OUTPUT.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
