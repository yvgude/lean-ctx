#!/usr/bin/env python3
"""Validate final SDK-first internal documentation convergence."""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
DOCS = ROOT / "docs" / "internal"
INVENTORY = DOCS / "DOCS-INVENTORY.md"
CANONICAL = DOCS / "vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md"
DECISIONS = DOCS / "execution/SDK-PRODUCTION-DECISION-RECORD.md"
MOVE_MAP = DOCS / "DOCS-MOVE-MAP.md"
ARCHIVE_ROOT = DOCS / "_archive/sdk-first-convergence-2026-08-24"
ACTIVE_CLASSES = {"Canonical", "Active support", "Execution tracker"}
ALL_CLASSES = ACTIVE_CLASSES | {
    "Operational guidance",
    "Research",
    "Reference",
}

PROHIBITED = {
    r"\bSDK remains OSS\b": "SDK described as OSS",
    r"\bcore SDK remains open\b": "core SDK described as open",
    r"\bopen Runtime \+ SDK\b": "Runtime and SDK openness conflated",
    r"\bSDK license (?:is )?pending\b": "SDK license decision described as pending",
    r"\bProduction SDK license remains pending\b": "Production SDK license described as pending",
    r"\bSDK may be Apache\b": "SDK described as possibly Apache",
    r"\bproposed BSL\b": "BSL described as merely proposed",
    r"\bSingle developer\s*=\s*free,?\s*organization\s*=\s*paid\b": "obsolete headcount doctrine",
    r"\bRevenue comes from intelligence and operations, not SDK licensing\b": "Cloud-only monetization doctrine",
}
NEGATED_CONTEXT = {
    "do not",
    "must not",
    "never",
    "historical",
    "superseded",
    "obsolete",
    "old ",
    "prohibited",
    "cannot",
}

AUTHORITY_FILES = (
    "vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md",
    "execution/SDK-PRODUCTION-DECISION-RECORD.md",
    "vision/06-ENGINE-SDK-CLOUD-PLAN.md",
    "vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md",
    "vision/05-CONTEXT-SDK-POSITIONING.md",
    "execution/MASTER-EXECUTION-PLAN.md",
    "execution/ANTI-ROADMAP.md",
    "execution/PROOF-DOCTRINE.md",
)


def markdown_paths() -> set[str]:
    return {
        path.relative_to(DOCS).as_posix()
        for path in DOCS.rglob("*.md")
        if "_archive" not in path.relative_to(DOCS).parts
    }


def inventory_classes() -> dict[str, str]:
    classes: dict[str, str] = {}
    row = re.compile(
        r"^\| `([^`]+\.md)` \| .*? \| "
        r"(Canonical|Active support|Execution tracker|Operational guidance|Research|Reference) \|"
    )
    for line in INVENTORY.read_text(encoding="utf-8").splitlines():
        match = row.match(line)
        if match:
            classes[match.group(1)] = match.group(2)
    return classes


def check_inventory(errors: list[str], classes: dict[str, str]) -> None:
    actual = markdown_paths()
    listed = set(classes)
    for path in sorted(actual - listed):
        errors.append(f"inventory missing: {path}")
    for path in sorted(listed - actual):
        errors.append(f"inventory stale path: {path}")
    for path, category in classes.items():
        if category not in ALL_CLASSES:
            errors.append(f"invalid class {category}: {path}")
    text = INVENTORY.read_text(encoding="utf-8")
    if "<br>" in text or "\\|" in text:
        errors.append("inventory contains recursive/malformed table content")
    if "Non-archive Markdown documents: **" + str(len(actual)) + "**" not in text:
        errors.append("inventory document count is stale")


def check_claims(errors: list[str], classes: dict[str, str]) -> None:
    for rel, category in classes.items():
        if category not in ACTIVE_CLASSES and rel != "DOCS-CONVERGENCE-REPORT.md":
            continue
        path = DOCS / rel
        text = path.read_text(encoding="utf-8")
        normalized = re.sub(r"\s+", " ", text)
        for pattern, message in PROHIBITED.items():
            for match in re.finditer(pattern, normalized, re.IGNORECASE):
                context = normalized[max(0, match.start() - 180) : match.end() + 180].lower()
                if not any(marker in context for marker in NEGATED_CONTEXT):
                    errors.append(f"{rel}: {message}")
        if "/Users/" in text:
            errors.append(f"{rel}: absolute local path in active document")


def check_links(errors: list[str], classes: dict[str, str]) -> None:
    link_pattern = re.compile(r"\[[^]]*\]\(([^)]+)\)")
    for rel, category in classes.items():
        if category not in ACTIVE_CLASSES:
            continue
        path = DOCS / rel
        for raw in link_pattern.findall(path.read_text(encoding="utf-8")):
            target = raw.strip().split()[0].strip("<>")
            if target.startswith(("http://", "https://", "mailto:", "#", "/")):
                continue
            target = unquote(target.split("#", 1)[0].split("?", 1)[0])
            if target and not (path.parent / target).resolve().exists():
                errors.append(f"{rel}: dead link {raw}")
        for target in re.findall(r"`(docs/internal/[^`]+\.md)`", path.read_text(encoding="utf-8")):
            if not (ROOT / target).exists():
                errors.append(f"{rel}: stale inline path {target}")


def check_archive(errors: list[str]) -> None:
    if not MOVE_MAP.exists():
        errors.append("documentation move map missing")
        return
    mappings = re.findall(
        r"^\| `([^`]+\.md)` \| `([^`]+\.md)` \|",
        MOVE_MAP.read_text(encoding="utf-8"),
        re.MULTILINE,
    )
    archived = {
        path.relative_to(DOCS).as_posix()
        for path in ARCHIVE_ROOT.rglob("*.md")
        if path.is_file()
    }
    destinations = {destination for _, destination in mappings}
    if destinations != archived:
        for path in sorted(archived - destinations):
            errors.append(f"archive file missing move mapping: {path}")
        for path in sorted(destinations - archived):
            errors.append(f"move mapping missing destination: {path}")
    for source, destination in mappings:
        if (DOCS / source).exists():
            errors.append(f"archived source still active: {source}")
        if not (DOCS / destination).exists():
            errors.append(f"archived destination missing: {destination}")


def require(errors: list[str], text: str, phrase: str, label: str) -> None:
    if phrase.lower() not in text.lower():
        errors.append(f"{label} missing: {phrase}")


def check_authority(errors: list[str]) -> None:
    canonical = CANONICAL.read_text(encoding="utf-8")
    for phrase in (
        "Apache-2.0 LeanCTX Engine",
        "BSL 1.1 LeanCTX Production SDK",
        "primary product",
        "separate repository",
        "Cloud is optional",
        "Why the SDK exists",
        "Why buy the SDK instead of building on the Engine?",
        "Engine versus SDK boundary",
        "SDK quality bar",
        "Embedded product distribution",
        "SDK product-market-fit test",
        "We could build this ourselves. We chose LeanCTX instead.",
        "Do not rebuild paid product semantics inside the Apache Engine.",
    ):
        require(errors, canonical, phrase, "canonical architecture")

    order = [
        canonical.find("Apache-2.0 LeanCTX Engine"),
        canonical.find("BSL 1.1 LeanCTX Production SDK"),
        canonical.find("Customer-owned agent / AI-native product"),
        canonical.find("Optional LeanCTX Cloud"),
    ]
    if any(position < 0 for position in order) or order != sorted(order):
        errors.append("canonical SDK-first dependency direction is missing or reordered")

    decisions = DECISIONS.read_text(encoding="utf-8")
    for phrase in (
        "Separate Production SDK repository",
        "Primary Thinkery product",
        "Business Source License 1.1 (BSL 1.1)",
        "Engine license",
        "Cloud relationship",
        "BSL Change Date",
        "BSL Change License",
        "BSL Additional Use Grant",
        "OEM redistribution/commercial terms",
        "Pricing and enterprise exceptions",
        "Contributor DCO/CLA process",
        "Security reporting and release policy",
    ):
        require(errors, decisions, phrase, "SDK decision record")
    if decisions.count("**DECIDED**") < 6:
        errors.append("SDK decision record does not mark fixed strategy DECIDED")

    readme = (DOCS / "README.md").read_text(encoding="utf-8")
    for rel in AUTHORITY_FILES:
        if rel not in readme:
            errors.append(f"README authority path missing: {rel}")
    require(errors, readme, "This path has eight authorities", "README")
    require(errors, readme, "Production SDK license family: **BSL 1.1**", "README")

    historical = []
    for path in markdown_paths():
        head = "\n".join((DOCS / path).read_text(encoding="utf-8").splitlines()[:30])
        if re.search(
            r"\*\*(?:Classification|Status).*?(?:Historical|Superseded)",
            head,
            re.I,
        ):
            historical.append(path)
    if historical:
        errors.append("historical/superseded files remain non-archive: " + ", ".join(sorted(historical)))

    ignored = subprocess.run(
        ["git", "check-ignore", "-q", "docs/internal/README.md"],
        cwd=ROOT,
        check=False,
    )
    if ignored.returncode != 0:
        errors.append("docs/internal public ignore protection is missing")


def main() -> int:
    errors: list[str] = []
    if not INVENTORY.exists():
        print("FAIL: docs/internal/DOCS-INVENTORY.md is missing")
        return 1
    classes = inventory_classes()
    check_inventory(errors, classes)
    check_claims(errors, classes)
    check_links(errors, classes)
    check_archive(errors)
    check_authority(errors)
    if errors:
        print("FAIL")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"PASS: {len(classes)} documents classified; SDK-first claims, authority, archive, and links valid")
    return 0


if __name__ == "__main__":
    sys.exit(main())
