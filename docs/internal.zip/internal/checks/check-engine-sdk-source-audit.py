#!/usr/bin/env python3
"""Fail closed when the documentation-only source extraction audit is incomplete."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
INTERNAL = ROOT / "docs" / "internal"
HEAD = "2c7d0044302d50af8d218a041b45726ad710757c"

REQUIRED = {
    "report": INTERNAL / "ENGINE-SDK-SOURCE-AUDIT-REPORT.md",
    "matrix": INTERNAL / "reference" / "ENGINE-SDK-SOURCE-OWNERSHIP-MATRIX.md",
    "provenance": INTERNAL / "reference" / "APACHE-TO-BSL-PROVENANCE-REVIEW.md",
    "oss": INTERNAL / "execution" / "OSS-PRESERVATION-CONTRACT.md",
    "sdk": INTERNAL / "execution" / "PRODUCTION-SDK-VALUE-CONTRACT.md",
    "migration": INTERNAL / "execution" / "SDK-EXTRACTION-MIGRATION-PLAN.md",
    "decommission": INTERNAL / "reference" / "ENGINE-DECOMMISSION-CANDIDATES.md",
}

CLASSES = {
    "ENGINE_CORE",
    "ENGINE_PROTOCOL",
    "OSS_PRODUCT_SURFACE",
    "OSS_ATTACH_COMPAT",
    "OPEN_FORMAT_OR_SPEC",
    "SPLIT_REQUIRED",
    "SDK_MIGRATION_INPUT",
    "SDK_BSL_TARGET",
    "CLOUD_PRIVATE_TARGET",
    "RESEARCH_FREEZE",
    "LEGACY_DEPRECATE",
}


def require(text: str, needles: set[str], label: str) -> None:
    missing = sorted(needle for needle in needles if needle not in text)
    if missing:
        raise SystemExit(f"FAIL {label}: missing {', '.join(missing)}")


def main() -> None:
    missing = [str(path.relative_to(ROOT)) for path in REQUIRED.values() if not path.is_file()]
    if missing:
        raise SystemExit("FAIL required artifacts: " + ", ".join(missing))

    docs = {name: path.read_text(encoding="utf-8") for name, path in REQUIRED.items()}
    for name, text in docs.items():
        require(text, {HEAD}, name)

    require(docs["matrix"], CLASSES, "matrix classes")
    require(
        docs["matrix"],
        {
            "OSS_CORE_CONTRACT",
            "OSS_TRANSITION_COMPAT",
            "OSS_NOT_PRESERVED",
            "OPEN_INTEROP_CONTRACT",
            "Two-axis decision register",
            "Total: **86**",
        },
        "matrix preservation axis",
    )
    require(
        docs["matrix"],
        {
            "packages/python-lean-ctx",
            "packages/node-lean-ctx",
            "rust/crates/lean-ctx-sdk",
            "lean-ctx-protocol",
            "context_kernel/types.rs",
            "context_compiler.rs",
            "context_field.rs",
            "core/session",
            "profiles/types.rs",
            "kits/mod.rs",
            "server/context_gate.rs",
            "rust/src/lib.rs",
            "rust/Cargo.toml",
        },
        "matrix coverage",
    )
    require(
        docs["oss"],
        {"OSS_BEFORE_SPLIT", "pathjail_negative", "secret_negative", "offline_verify"},
        "OSS parity",
    )
    require(
        docs["sdk"],
        {"Select → Shape → Reuse → Recover", "ContextSession", "LeanCTX Inside", "thin wrappers"},
        "SDK value",
    )
    require(
        docs["provenance"],
        {
            "LEGAL/PROVENANCE REVIEW REQUIRED",
            "future canonical product ownership",
            "external-author",
            "Future Engine inclusion is a different decision",
        },
        "provenance",
    )
    require(
        docs["migration"],
        {f"Wave {letter}" for letter in "ABCDEFG"},
        "migration waves",
    )
    require(
        docs["report"],
        {
            "No product/runtime code changed.",
            "No repository created.",
            "No license changed.",
            "No source files moved.",
            "KEEP IN ENGINE",
            "MIGRATE TO BSL SDK",
            "MOVE TO CLOUD LATER",
        },
        "audit report",
    )
    require(
        docs["decommission"],
        {
            "Preserve the supported OSS coding-agent product",
            "Historical Apache rights remain",
            "Candidate register",
            "protocol `auto_routing`",
            "Accidental root `pub mod core`",
        },
        "decommission map",
    )

    register_rows = [
        line
        for line in docs["matrix"].splitlines()
        if re.match(r"^\| (?:P|R|PR|K|S|E)\d{2} \|", line)
    ]
    if len(register_rows) != 86:
        raise SystemExit(f"FAIL matrix preservation rows: expected 86, got {len(register_rows)}")

    decommission_rows = [
        line
        for line in docs["decommission"].splitlines()
        if line.startswith("| ")
        and not line.startswith("| ---")
        and "| Source group |" not in line
    ]
    if len(decommission_rows) != 31:
        raise SystemExit(
            f"FAIL decommission rows: expected 31, got {len(decommission_rows)}"
        )

    changed = subprocess.run(
        ["git", "diff", "HEAD", "--name-only"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
    runtime_changes = [path for path in changed if not path.startswith("docs/internal/")]
    if runtime_changes:
        raise SystemExit("FAIL runtime changes detected: " + ", ".join(runtime_changes))

    untracked_runtime = subprocess.run(
        [
            "git",
            "ls-files",
            "--others",
            "--exclude-standard",
            "--",
            "packages/python-lean-ctx",
            "packages/node-lean-ctx",
            "rust",
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
    if untracked_runtime:
        raise SystemExit(
            "FAIL untracked runtime files detected: " + ", ".join(untracked_runtime)
        )

    print("PASS: Engine/SDK source audit artifacts, coverage, and no-code scope valid")


if __name__ == "__main__":
    main()
