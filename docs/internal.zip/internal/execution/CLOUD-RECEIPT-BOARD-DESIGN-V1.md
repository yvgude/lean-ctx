# Cloud Receipt Board — Design v1

> **Status:** Research design. It is not an OSS-runtime feature, public API, or
> authority to provision Cloud infrastructure. Local Engine and SDK behavior
> must remain fully useful during Cloud denial, outage, deletion, or retirement.
>
> **Objective:** the smallest credible organization feature is an opt-in,
> metadata-first board of integrity-aware context receipts and evaluations. It
> shows declared local behavior without uploading raw source or becoming an
> agent scheduler, project filesystem, or general telemetry sink.

## Non-negotiable boundaries

- Engine executes local operations; SDK decides within a host-owned loop; Cloud
  consumes released artifacts downstream.
- The server derives `tenant_id` and actor identity from authentication. Request
  bodies never choose their own tenant.
- `metadata_only` is the default and stores no prompts, source text, tool output,
  transcript, unredacted path, secret, or arbitrary JSON extension.
- Every raw or derived-context mode requires explicit project policy, redaction
  classification, retention, and user-visible opt-in. Mode is never upgraded
  silently.
- A board projection reports measured, estimated, and accepted outcome fields
  separately; it never recalculates a savings claim from incomplete evidence.

## Identity and authorization

| Principal | Minimum permission | Permitted action |
| --- | --- | --- |
| Writer | `receipt:write` in a project | Ingest one verified receipt |
| Reader | `receipt:read` in a project | List and inspect redacted projections |
| Auditor | `audit:read` in a tenant | Inspect immutable audit events |
| Tenant administrator | `tenant:admin` | Configure retention, signer trust, deletion and export |

Tokens are short-lived, audience-bound and project-scoped. Service-to-service
identity uses the same tenant/project claims. The server rejects a missing,
ambiguous, expired, or scope-mismatched identity before parsing stored data.

## Receipt ingestion contract

`POST /v1/receipt-board/ingest` accepts a strict `ReceiptUploadV1` envelope:

```text
schema_version, project_id, receipt_id, canonical_receipt_bytes,
receipt_sha256, signature, signer_key_id, data_mode, retention_policy_id
```

The server must:

1. derive tenant and actor from authentication;
2. enforce request size, rate, project scope, supported schema and `metadata_only`;
3. reject unknown/duplicate fields and any payload field disallowed by the mode;
4. recompute receipt digest from canonical bytes;
5. verify signature encoding, algorithm, tenant-owned active signer key, receipt
   identity, timestamp/replay window and chain link;
6. persist an immutable receipt record plus a separately hash-linked audit event;
7. return only a server receipt reference and immutable digest.

An ingest retry is idempotent for the same `(tenant, project, receipt_id,
receipt_sha256)` and conflicts for the same ID with different bytes. `422`
means schema/signature/policy failure; `403` means authorization or scope
failure; `409` means identity conflict; `429` means quota/rate limit.

## Data, retention, and deletion

Metadata storage contains IDs, digests, signer/key status, Engine/SDK identity,
operation class, declared limits, measured/estimated/outcome labels, timestamps,
retention policy, and redaction class. Projections index only approved fields.

The server computes `expires_at` from the active retention policy at ingest.
Expiry and administrator deletion are asynchronous, idempotent jobs that remove
receipt projections, search indexes, chain edges, cache entries, and linked
rollups. They append a non-content audit tombstone. Retries cannot resurrect
expired/deleted data. Export is authorization-scoped, redacted, auditable, and
uses a short-lived download reference.

## Read and audit APIs

- `GET /v1/receipt-board/projects/{project}/runs`: cursor-paginated redacted
  list, filterable only by approved metadata.
- `GET /v1/receipt-board/receipts/{id}`: redacted immutable receipt projection.
- `GET /v1/receipt-board/audit`: tenant-scoped, hash-linked redacted events.
- `DELETE /v1/receipt-board/receipts/{id}`: administrator request returning a
  deletion operation reference; never a synchronous destructive success claim.

All responses carry project scope, schema version, server-generated audit
reference, and a no-store policy where an artifact contains sensitive metadata.

## Threat model and controls

| Threat | Required control |
| --- | --- |
| Cross-tenant/project access | Server-derived claims, row-level tenant/project predicates, negative authorization tests |
| Forged or replayed receipt | Canonical digest, trusted signer key, timestamp/replay window, idempotency/conflict rules |
| Raw-source exfiltration | Metadata-only allowlist, unknown-field rejection, content scanners, explicit data-mode policy |
| Aggregation disclosure | Minimum cohort thresholds, redacted dimensions, scoped query limits, export audit |
| Compromised local agent | Least-privilege write token, key revocation, anomaly limits, immutable audit trail |
| Deletion failure | Idempotent tombstoned jobs, retry budget, observability, backup-erasure policy |
| Control-plane outage | Local receipt persistence and verification continue; upload is bounded, explicit, and retryable |

## Required operational design before implementation

- Tenant/project isolation model, database migration owner, encryption/key
  custody, backups and recovery objectives.
- Retention catalogue, legal hold/conflict semantics, deletion/export SLOs, and
  data-processing review.
- Auth provider, key rotation/revocation, incident response owner, abuse/rate
  controls, on-call/SLO/error budget, and cost/quota methodology.
- Independent security review of canonical parsing, signature verification,
  authorization, tenant isolation, redaction, deletion, and downgrade paths.

## Promotion test matrix

1. Valid metadata-only receipt ingests once and its digest/signature/audit link
   verify independently.
2. Cross-tenant, cross-project, expired-token, revoked-key, forged-byte,
   duplicate-key and replay attempts fail closed.
3. Raw prompt/source/transcript/unknown field attempts are rejected in
   metadata-only mode.
4. Retention expiry and admin deletion remove projections and indexes without
   erasing the necessary non-content audit tombstone.
5. Local Engine/SDK continue and produce verifiable receipts when auth, upload,
   storage, queue, or Cloud DNS is unavailable.
6. Reader, writer, auditor and administrator actions are least-privileged and
   auditable; pagination, quota, export and aggregation boundaries are tested.

## Delivery gates

G1 design approval requires product, security, privacy, operations and legal
sign-off on this contract plus the required operational design. G2 starts with
authenticated metadata-only ingestion and immutable inventory; tenant isolation,
retention/deletion, and audit follow before any derived-context data mode.
Cloud synchronization of `ContextWorkspace`, policy distribution, billing, and
fleet controls are separate contracts after local workspace invariants prove
safe.
