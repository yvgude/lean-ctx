# H18 — LeanCTX SDK Developer Experience

**Author:** Agent H18 — Developer Experience

**Date:** 2026-08-20

**Status:** Product and documentation design

**Audience:** SDK, Runtime, product, docs, developer relations, and solutions engineering

---

## 0. Executive decision

LeanCTX should feel like a performance tool a developer can trust in one sitting.

The journey is not “learn a new agent framework.”

The journey is “keep my agent, run the same task, and see measured context savings without losing quality.”

The canonical loop is:

```text
CONNECT → MEASURE → TUNE → PROVE → DEPLOY → REPEAT
```

The first-session outcome is:

```text
Install in minutes
→ connect an existing agent or application
→ run a real task
→ receive a readable result
→ compare a baseline and a tuned run
→ save the winning Profile or keep stock
```

The product must not require knowledge of every reader, cache, graph, proxy, or MCP tool before this outcome.

> **The Context SDK for AI Agents. Tune any agent. Prove every gain.**

DX rule:

> **Show the measured before/after before asking the developer to learn tuning.**

---

## 1. Scope, terminology, and API truthfulness

### 1.1 Integration depths

| Depth | Developer intent | LeanCTX role | First action |
|---|---|---|---|
| Attach | Improve an existing coding agent. | MCP, hooks, or proxy alongside it. | `lean-ctx wrap codex` |
| Wrap | Compress existing model calls. | A small client/framework adapter. | `compress(messages, model=...)` |
| Embed | Control context in a custom loop. | Sessions, Profiles, Kits, and receipts. | `LeanCTX(...).session(...)` |

Attach is the easiest path for Codex, Claude Code, and Cursor users.

Wrap is the shortest path for an existing application.

Embed is for agent builders who need deliberate, testable context strategy.

### 1.2 Current versus target surface

This blueprint separates repository reality from the strategy’s target SDK.

| Capability | Shipping now | Target contract |
|---|---|---|
| Python package | `lean-ctx-sdk` 0.3.0, imported as `lean_ctx` | Canonical `leanctx` SDK namespace or explicit alias |
| Simplest compression | `compress(messages, model=...)` | Kept stable forever |
| Compression stats | `ProxyClient().compress(...)` | Typed execution/result records |
| Runtime activation | Local daemon plus `lean-ctx proxy enable` | A discoverable, idempotent Runtime command |
| Kits | `lean-ctx kit load code-review` and TOML | Typed SDK load and pinning |
| Context profiles | `lean-ctx profile ...` presets | Versioned `TuningProfile` contract |
| Receipts | Signed savings batches and evidence verifier | `ExecutionReceipt`, `SavingsReceipt`, `EvidenceBundle` |
| Comparison | Evidence commands | Canonical Dyno API and CLI |

Code labelled **SHIPPING** is supported by the current repository.

Code labelled **TARGET CONTRACT** is the exact proposed API shape, not a runnable claim until released.

This label distinction is mandatory across README, website, docs, and generated reference.

### 1.3 Product terms

| Term | Meaning | Never conflate with |
|---|---|---|
| Context session | One bounded task lifecycle. | A chat or generic trace. |
| Tuning Profile | Versioned context configuration. | A model or tool profile. |
| Context Kit | Reusable workflow context capability. | A prompt pack. |
| Execution receipt | Accounting/outcome record for one run. | A savings claim. |
| Savings receipt | Controlled baseline/treatment comparison. | A provider invoice. |
| Evidence bundle | Portable, independently verifiable archive. | A dashboard export. |
| Dyno | Controlled benchmark and tuner. | A superficial benchmark widget. |

Always separate provider-reported usage, calculated provider cost, and reconciled invoice cost.

Always show quality beside a savings number.

Never publish a percentage without workload, baseline, method, and quality result.

---

## 2. Discovery: how developers find LeanCTX

### 2.1 Discovery paths

| Channel | Trigger | Landing promise | Primary action |
|---|---|---|---|
| GitHub | Agent rereads files or huge logs. | Local-first context performance for existing agents. | 60-second quickstart |
| Search | “reduce LLM prompt tokens” or “Codex context.” | Tune context without rebuilding the agent. | Choose the agent/framework |
| Blog | “Are these savings real?” | Same workload, same model, declared quality, receipt. | Reproduce the experiment |
| Word of mouth | “This made our coding agent cheaper.” | No savings claim without a baseline. | Run local Dyno |
| Framework docs | Existing LiteLLM, LangChain, or custom loop. | Drop-in deterministic compression. | Copy framework code |
| Consultancy | Production agent with a budget. | Baseline, tune, validate, deliver Profile and evidence. | Scope a Tuning Sprint |

### 2.2 GitHub README above the fold

Recommended copy:

```text
LEANCTX
The Context SDK for AI Agents.

Tune Codex, Claude Code, Cursor, or your own agent to use context more efficiently.
Keep the agent. Measure the result. Prove the gain.

[ Install LeanCTX ] [ 5-minute quickstart ] [ View a verified receipt ]
```

Immediately show one reproducible, workload-specific result card.

```text
SAME WORKLOAD · SAME MODEL · SAME QUALITY GATE

STOCK                    LEANCTX
139,115 input tokens     14,016 input tokens
$0.370 calculated cost  $0.058 calculated cost
PASS                     PASS

WORKLOAD-SPECIFIC GAIN: 84.3% lower calculated cost
METHOD: linked receipt / reproduce locally
```

The card links to workload manifest, quality result, receipt, price-table version, and reproduction command.

Do not lead with a universal savings percentage.

### 2.3 Blog and social proof

Every article must include:

1. The agent and workload.

2. Fixed revision, model, timeout, and budget.

3. Baseline and treatment context strategies.

4. Provider usage and calculated cost separately.

5. Declared quality gate and result.

6. Receipt/evidence link.

7. A short local reproduction path.

Good titles:

- “Why the same code-review agent spent 10× more context than it needed.”

- “A reproducible baseline for Codex context cost.”

- “Prompt caching is not enough: measure context before the model sees it.”

- “How to review an AI savings claim from a signed receipt.”

Avoid “revolutionary,” “magical,” and generic universal-savings claims.

### 2.4 Landing-page decision fork

Ask one question, not an architecture questionnaire:

```text
What are you tuning?

[ Codex ] [ Claude Code ] [ Cursor ] [ My Python agent ] [ Team / production agent ]
```

| Choice | First destination | 15-minute success |
|---|---|---|
| Codex | Attach quickstart | Connected agent, `gain`, and receipt. |
| Claude Code | Attach quickstart | Connected agent, `gain`, and receipt. |
| Cursor | Attach quickstart | Connected agent, `gain`, and receipt. |
| Python agent | Wrap quickstart | Compressed messages and stats. |
| Team / production | Dyno overview | Workload contract is drafted. |

### 2.5 Shareable word-of-mouth object

The shareable object is a privacy-preserving evidence card, not a percentage screenshot.

```text
LEANCTX SAVINGS RECEIPT
payment-review-v1 · 32 controlled tasks

Calculated provider cost:  $1.82 → $0.61
Quality contract:          32/32 PASS
Profile:                   payments-review@1.4.2
Evidence:                  VERIFIED

[ View receipt ] [ Reproduce ] [ Verify offline ]
```

It must disclose calculated versus invoice-reconciled cost.

It must not include source, paths, prompts, secrets, or raw model responses by default.

---

## 3. Install: `pip install lean-ctx` and what happens

### 3.1 Packaging decision

The current Python package is `lean-ctx-sdk` and imports as `lean_ctx`.

The requested `pip install lean-ctx` command should become canonical only as an intentional distribution contract.

Recommended packaging model:

```text
pip install lean-ctx
        │
        ├── leanctx Python SDK and typed contracts
        ├── version-compatible LeanCTX Runtime acquisition
        ├── compatibility checker
        └── no provider credentials, project scan, or telemetry by default
```

The old package/import stays supported through a published migration window:

```text
pip install lean-ctx-sdk
from lean_ctx import compress
```

Choose one canonical import before GA; an alias is allowed, ambiguity is not.

### 3.2 Install contract

```bash
python -m pip install lean-ctx
```

The installer may:

1. Install SDK and typed contracts.

2. Install or acquire a compatible local Runtime.

3. Report exact version compatibility.

4. Print the next command for each supported route.

The installer must not:

1. Rewrite any coding-agent, shell, or provider configuration.

2. Scan the repository or upload content.

3. Enable a provider proxy.

4. Create a cloud account.

5. Start telemetry without opt-in.

6. Display a vague success message with no verification route.

### 3.3 Target install transcript

```console
$ python -m pip install lean-ctx
Collecting lean-ctx
Installing collected packages: lean-ctx-runtime, lean-ctx
Successfully installed lean-ctx-1.0.0 lean-ctx-runtime-1.0.0

LeanCTX 1.0.0 is ready locally.
  Runtime:    installed, not started
  Telemetry:  off
  Project:    untouched

Next:
  Custom Python agent  →  lean-ctx quickstart python
  Codex                →  lean-ctx connect codex
  Claude Code          →  lean-ctx connect claude
  Cursor               →  lean-ctx connect cursor
```

This transcript is a UX contract; detected routes can vary but safety assertions cannot.

### 3.4 Version mismatch transcript

```console
$ python -m pip install lean-ctx
Requirement already satisfied: lean-ctx==1.0.0

LeanCTX Runtime 0.9.4 is running locally.
SDK 1.0.0 requires Runtime >=1.0.0,<2.0.0.

Run: lean-ctx update
No agent or provider configuration was changed.
```

Never allow an undisclosed version mismatch to first surface inside a model request.

### 3.5 Current shipping route

Until the package contract changes, publish the current route truthfully:

```bash
python -m pip install lean-ctx-sdk
lean-ctx proxy enable
```

The current SDK talks to the daemon’s `/v1/compress` endpoint.

It auto-discovers URL and session token but accepts explicit configuration for CI or remote proxies.

### 3.6 Doctor after install

Every onboarding flow ends with a non-mutating diagnosis command.

```bash
lean-ctx doctor
```

Target output:

```text
LeanCTX doctor

✓ Runtime reachable
✓ SDK / Runtime contract: 1.0
✓ Local project access: bounded to current workspace
○ No provider proxy enabled
○ No coding agent connected

Ready for: lean-ctx quickstart python
```

`✓` is healthy, `○` is intentionally absent, and `!` is actionable failure.

Optional integrations must never appear as red errors.

## 4. Five-minute Python quickstart

### 4.1 The success criterion

The first tutorial has one outcome:

> A developer sends normal messages through LeanCTX once and sees exactly how much context changed before their existing provider call.

Prerequisites:

- Python 3.9 or later.

- Working LeanCTX Runtime/proxy.

- OpenAI- or Anthropic-style chat messages.

- No provider key for the first compression-only step.

The tutorial uses a readable generated payload to ensure a visible non-zero reduction.

### 4.2 Minute 0–1: install and start

**TARGET CONTRACT**

```bash
python -m pip install lean-ctx
lean-ctx runtime start
lean-ctx doctor
```

**SHIPPING API ROUTE**

```bash
python -m pip install lean-ctx-sdk
lean-ctx proxy enable
lean-ctx doctor
```

The expected outcome is a reachable local Runtime; no provider call has been made.

### 4.3 Minute 1–2: create `quickstart.py`

**SHIPPING API — complete example**

```python
from lean_ctx import ProxyClient

large_log = "\n".join(
    "INFO worker=api request_id=demo-001 status=200 elapsed_ms=12 detail=unchanged"
    for _ in range(500)
)

messages = [
    {"role": "system", "content": "Answer with one concise sentence."},
    {"role": "user", "content": large_log},
]

result = ProxyClient().compress(messages, model="gpt-4o")

print(f"original_tokens={result.original_tokens}")
print(f"compressed_tokens={result.compressed_tokens}")
print(f"saved_tokens={result.saved_tokens}")
print(f"saved_pct={result.saved_pct:.1f}")
print(result.messages[1]["content"])
```

The SDK accepts normal message dictionaries.

Only text blocks are transformed; images, tool calls, and identifiers pass through untouched.

### 4.4 Minute 2–3: run it

```bash
python quickstart.py
```

Exact token values depend on text and tokenizer, so docs must not promise fixed local counts.

The output shape is stable:

```text
original_tokens=12014
compressed_tokens=112
saved_tokens=11902
saved_pct=99.1
[lean-ctx: repeated log lines collapsed; reference=ref_…]
INFO worker=api request_id=demo-001 status=200 elapsed_ms=12 detail=unchanged
```

Explain that `ref_…` is a recovery reference, not deletion.

The real reference ID is intentionally not a stable documentation literal.

### 4.5 Minute 3–4: call the normal provider

The developer replaces their existing messages at the call boundary.

**SHIPPING API — simplest possible integration (three lines)**

```python
from lean_ctx import compress
messages = compress(messages, model="gpt-4o")
response = client.chat.completions.create(model="gpt-4o", messages=messages)
```

This assumes `client` and `messages` already exist in the application.

LeanCTX does not own provider invocation or application response handling.

### 4.6 Minute 4–5: expose the immediate result

**SHIPPING API**

```python
from lean_ctx import ProxyClient

result = ProxyClient().compress(messages, model="gpt-4o")
print(f"LeanCTX prepared {result.compressed_tokens:,} tokens "
      f"from {result.original_tokens:,} ({result.saved_pct:.1f}% removed).")
messages = result.messages
```

Target output:

```text
LeanCTX prepared 3,782 tokens from 12,014 (68.5% removed).
```

This is an immediate context-reduction measurement.

It is not a verified savings claim because it has no baseline, provider usage record, or accepted quality result.

The next CTA is:

```text
Good: LeanCTX changed your context boundary.
Next: run a controlled comparison before claiming savings.

[ Compare this task ] [ Learn about receipts ]
```

### 4.7 Error experience

The shipping SDK raises `LeanCtxConnectionError` when its daemon is unavailable.

The message must include one repair command:

```text
LeanCtxConnectionError: could not reach the LeanCTX proxy.
Run: lean-ctx proxy enable
```

For failed authorization, raise `LeanCtxAuthError` and name `LEAN_CTX_PROXY_TOKEN` or explicit `token=`.

Framework adapters may expose fail-open behavior only when clearly configured and observable.

No silent fallback from a direct SDK compression call is acceptable.

---

## 5. First wow moment: a controlled comparison

### 5.1 Desired result

The wow moment is not a shorter string.

It is the same useful task passing under the same constraints with materially less context.

Render the comparison like this:

```text
SAME TASK · SAME SOURCE REVISION · SAME MODEL · SAME QUALITY GATE

                     STOCK                 LEANCTX / balanced@1.0.0
Input tokens         139,115               14,016
Cached input tokens  87,040                8,192
Output tokens        4,381                 4,246
Calculated cost      $0.370                $0.058
Latency              31.4 s                18.6 s
Quality              PASS                  PASS

CALCULATED COST CHANGE: -84.3%
EVIDENCE: VERIFIED · receipt shr_01H… · methodology v1
```

The numeric values are an illustrative strategy example; production UI uses the current receipt values.

### 5.2 Mandatory result hierarchy

1. Same-task controls appear first.

2. Quality appears beside cost.

3. Provider usage appears before calculated cost.

4. Percentage appears last and names its denominator.

5. Receipt and methodology are part of the result itself.

Never show a green gain if treatment quality failed, was skipped, or is incomparable.

### 5.3 Baseline selector

```text
What is the baseline?

(•) Stock: current agent behavior with LeanCTX disabled
( ) Attach: LeanCTX connection only
( ) Named Profile: __________________
```

The resulting receipt records this baseline declaration.

A baseline is not the previous dashboard number; it is a controlled arm.

### 5.4 Quality templates

| Workload | Default quality template | Required evidence |
|---|---|---|
| Code generation | Build and tests. | Exit status and test summary. |
| Code review | Evaluator or acceptance. | Reviewer report digest. |
| Research | Factual/citation evaluator. | Score and evaluator version. |
| Support | Resolution acceptance. | Resolution and escalation count. |
| Custom agent | Command or callback. | Declared result schema. |

The product never infers quality from token metrics.

### 5.5 Result actions

After a passing comparison:

```text
[ Save winning Profile ] [ Inspect receipt ] [ Share evidence ]
```

After quality failure:

```text
[ Inspect quality failure ] [ Try another Profile ] [ Keep stock ]
```

Keeping stock is an honest successful outcome.

---

## 6. Going deeper: Kits, Profiles, and custom configuration

### 6.1 Mental model

```text
Tuning Profile
  Broad behavior: budget, compression, reuse, recovery, and read strategy.

Context Kit
  Workflow capability: ordered reads, priority, shell evidence, quality bar,
  and a focused instruction.
```

A Profile works without a Kit.

A Kit can be paired with several Profiles.

A receipt pins both version and content digest.

### 6.2 Current Kit journey

The repository already includes a built-in `code-review` Kit.

**SHIPPING COMMANDS**

```bash
lean-ctx kit list
lean-ctx kit show code-review
lean-ctx kit load code-review
```

The shipped Kit prioritizes changed files, uses outline/signature-first Rust reads, preserves full TOML reads, focuses test/clippy output, and asks for actionable findings.

`kit show` must display source, version, read plan, quality criteria, and prompt in copyable form.

### 6.3 Code-review agent with a Kit

**TARGET CONTRACT — exact SDK example**

```python
from leanctx import LeanCTX
from my_review_agent import ReviewAgent

ctx = LeanCTX(project=".")
agent = ctx.wrap(
    ReviewAgent(),
    kit="code-review@1.0.0",
    profile="review@1.0.0",
)
result = agent.run(task="Review pull request #482")

print(result.output)
print(result.leanctx.receipt.receipt_id)
```

Target semantics:

- `wrap()` observes task, model, tool, usage, and outcome events.

- `kit=` resolves and pins a Kit version/content digest.

- `profile=` resolves a Tuning Profile version.

- The customer agent remains the source of review conclusions.

- Every completed observed run has `result.leanctx.receipt`.

Target output:

```text
Review complete: 2 actionable findings
LeanCTX receipt: exe_01J9E9YH1J5RDR3WDVKF5H2Q7B
Context: 44,218 → 9,604 delivered tokens
Quality: PASS (review-output-v1)
```

The standard output contains no implementation prompt text.

### 6.4 Custom TuningProfile

**TARGET CONTRACT — exact Python example**

```python
from leanctx import ContextPolicy, QualityGate, TuningProfile

payments_review = TuningProfile(
    name="payments-review",
    version="1.4.2",
    context=ContextPolicy(
        budget_tokens=64_000,
        read_strategy="outline-first",
        search_limit=12,
        reuse_threshold=0.85,
        compression="balanced",
        recovery="enabled",
    ),
    kits=["payments-security@2.1"],
    quality=[
        QualityGate.command("pytest -q", name="tests-pass"),
        QualityGate.threshold("review-score", minimum=0.92),
    ],
)

payments_review.write(".leanctx/profiles/payments-review@1.4.2.yaml")
```

Expected serialized file:

```yaml
api_version: leanctx/v1
kind: TuningProfile

metadata:
  name: payments-review
  version: 1.4.2

context:
  budget_tokens: 64000
  read_strategy: outline-first
  search_limit: 12
  reuse_threshold: 0.85
  compression: balanced
  recovery: enabled

kits:
  - payments-security@2.1

quality:
  gates:
    - tests-pass
    - review-score>=0.92
```

Construction does not write to disk or mutate Runtime state.

Writing is explicit and returns the artifact path plus digest.

### 6.5 Validate, compare, and activate a Profile

**TARGET CONTRACT**

```bash
lean-ctx profile validate .leanctx/profiles/payments-review@1.4.2.yaml
lean-ctx profile diff balanced@1.0.0 payments-review@1.4.2
lean-ctx profile activate payments-review@1.4.2 --scope project
```

Target output:

```text
Profile valid: payments-review@1.4.2
  Context budget: 64,000 tokens
  Read strategy: outline-first
  Kits: payments-security@2.1 (digest sha256:…)
  Quality gates: tests-pass, review-score>=0.92
  Scope: project (.leanctx/)
```

Activation always names exact scope and path.

It never changes a global profile when the developer intended project scope.

### 6.6 Existing context profile journey

**SHIPPING COMMANDS**

```bash
lean-ctx profile list
lean-ctx profile show review
lean-ctx profile diff balanced review
lean-ctx profile create payments-review --from balanced
lean-ctx profile set payments-review
```

Current context profiles are broad read/compression presets.

Tool profiles are a separate concept that control how many MCP tools appear to an agent.

| Intent | Command family | Example |
|---|---|---|
| Control tool surface | `lean-ctx tools` | `lean-ctx tools standard` |
| Control context behavior | `lean-ctx profile` | `lean-ctx profile set review` |
| Add workflow capability | `lean-ctx kit` | `lean-ctx kit load code-review` |

### 6.7 Custom Kit authoring

The first Kit guide begins with a small inspectable file, not a marketplace.

```toml
format_version = 1

[kit]
name = "api-review"
description = "Focused context plan for reviewing API changes."
version = "0.1.0"

[read]
default_modes = ["map", "signatures"]

[[read.rules]]
glob = "**/openapi/**/*.yaml"
modes = ["full"]

[priority]
strategy = "git_changed"
description = "Review changed API contracts before implementation files."

[shell]
default_mode = "compressed"

[quality]
criteria = ["Name breaking API changes and the affected consumer."]

[system_prompt]
template = """Review API changes. Verify every breaking-change claim against the diff."""
```

The authoring guide explains:

1. The first matching read rule wins.

2. A Kit guides context selection but cannot expand filesystem permission.

3. Shell commands remain subject to Runtime allowlists and policy.

4. Quality criteria describe evaluation intent; they do not prove a gate ran.

5. Published Kits pin immutable version and content digest.

### 6.8 Advanced configuration drawer

Place advanced settings behind “Configure” and group by outcome.

| Goal | Controls | Safe default |
|---|---|---|
| Spend less context | Budget, compression, output density | balanced |
| Preserve detail | Recovery, fidelity floor, exact-read allowance | recovery enabled |
| Reuse more | Reuse threshold, cache scope | local project |
| Find more | Search limit, read strategy | bounded / outline-first |
| Guard quality | Command, evaluator, threshold | explicit for Dyno |
| Control data | Endpoint, retention, telemetry | local / telemetry off |

Each field must list plain-language purpose, default, unit, scope, restart requirement, and receipt impact.

---

## 7. Evidence: receipts a developer can understand

### 7.1 Receipt hierarchy

```text
ContextEnvelope
      ↓
ExecutionReceipt
      ↓ quality result
SavingsReceipt
      ↓
EvidenceBundle
      ↓
Independent verifier
```

An execution receipt records one run.

A savings receipt compares controlled arms.

An evidence bundle packages linked proof for independent verification.

### 7.2 First receipt presentation

Show a fact table before raw JSON.

```text
EXECUTION RECEIPT exe_01J9…

Task               Review pull request #482
Agent              review-agent@0.8.1
Provider / model   openai / gpt-4o
Profile            review@1.0.0
Kit                code-review@1.0.0 (sha256:…)

Input              44,218 fresh + 7,931 cached tokens
Output             1,204 tokens
Calculated cost    $0.073 (pricing table openai-2026-08-01)
Quality            PASS (review-output-v1)
Evidence           3 referenced artifacts · signature verified
```

“Show JSON” reveals method, source digests, event references, and all schema fields.

### 7.3 Reading order for savings receipts

1. Are task, revision, model, budget, and quality contract comparable?

2. Did both arms pass the declared quality contract?

3. What provider-reported usage was observed?

4. Which price table produced calculated cost?

5. Which Profile and Kit versions changed?

6. Is the artifact signed, and by which trusted key?

7. Is raw evidence private, redacted, or included?

The receipt must explain what it proves and what it does not prove in the same view.

### 7.4 Reading and verifying a receipt

**TARGET CONTRACT — exact Python example**

```python
from leanctx import SavingsReceipt

receipt = SavingsReceipt.read("artifacts/payment-review.savings.json")
verification = receipt.verify(
    public_key="4e6f7a0d3c5b9f0a1e2d3c4b5a69788766554433221100ffeeddccbbaa998877"
)

print(verification.status)
print(receipt.quality_preserved)
print(receipt.calculated_cost_change_pct)
```

Target output:

```text
VALID
True
-84.3
```

`verify()` validates canonical bytes and an Ed25519 signature offline.

The trusted public key normally comes from an out-of-band organizational channel, not the artifact alone.

### 7.5 Current offline verification routes

**SHIPPING COMMAND — signed aggregate savings batch**

```bash
lean-ctx savings verify-batch ./sprint-savings.json
```

**SHIPPING COMMAND — standalone evidence bundle**

```bash
leanctx-verify ./evidence.zip --pubkey <hex-ed25519-public-key>
```

The standalone verifier checks the manifest, listed file hashes, audit chain, manifest signature, and per-entry proofs.

It exits `0` only for a valid bundle.

### 7.6 Verification output contract

```text
Evidence bundle: VALID
  Manifest:       PASS
  File hashes:    PASS (6 files)
  Audit chain:    PASS (412 entries)
  Signature:      PASS (trusted out-of-band public key)
  Entry proofs:   PASS

This proves integrity and declared provenance after recording.
It does not prove that unrecorded events never existed.
```

The limitation sentence is a product requirement, not a footnote.

### 7.7 Receipt privacy modes

| Mode | Contains | Good for |
|---|---|---|
| Local execution receipt | Local refs and accounting. | Debugging/tuning. |
| Shareable savings receipt | Aggregates, hashes, versions, signatures. | Finance/client review. |
| Evidence bundle | Declared proof plus cryptographic integrity. | Audit/procurement. |
| Restricted bundle | Protected raw evidence under policy. | Regulated internal review. |

Default sharing must not upload code, paths, prompts, or secrets.

### 7.8 Comparing baseline versus tuned

**TARGET CONTRACT — exact Python example**

```python
from leanctx import Dyno, QualityGate
from my_agent import PaymentReviewAgent

result = Dyno(project=".").compare(
    workload="workloads/payment-review-v1.yaml",
    agent=PaymentReviewAgent(),
    baseline="stock",
    treatment="payments-review@1.4.2",
    quality=QualityGate.command("pytest -q", name="tests-pass"),
)

print(result.render_table())
result.write("artifacts/payment-review.savings.json")
```

Target output:

```text
SAME WORKLOAD · SAME REVISION · SAME MODEL

ARM                     INPUT      COST       QUALITY
stock                   139,115    $0.370     PASS
payments-review@1.4.2    14,016    $0.058     PASS

Calculated cost change: -84.3%
Savings receipt: artifacts/payment-review.savings.json
```

The comparator rejects different controls or missing quality with `INCOMPARABLE`, not a manufactured percentage.

---

## 8. Team adoption: share results and obtain budget

### 8.1 Developer-to-team handoff

Offer an evidence-backed decision memo immediately after a passing comparison.

```text
LeanCTX tuning result

Workflow:             payment-review-v1
Observation window:   32 controlled tasks
Change:               stock → payments-review@1.4.2
Quality:              32/32 PASS
Calculated API cost:  $1.82 → $0.61 per 32 tasks
Method:               same revision/model/budget; baseline/treatment
Evidence:             signed receipt + offline verifier

Recommendation: pilot on 10% of production traffic with the same quality gate.
```

This is a decision artifact, not a marketing deck.

### 8.2 Adoption ladder

```text
Developer local result
      ↓
Saved Profile + receipt
      ↓
Team methodology review
      ↓
Time-bounded pilot with rollback
      ↓
Shared Profiles, Kits, and receipts
      ↓
Scheduled Dyno and organization economics
```

No account is necessary before a useful local result.

### 8.3 Team view questions

The Team view answers, in this order:

1. Which workflow is measured?

2. Which Profile is deployed, where, and who changed it?

3. Does quality still pass as cost changes?

4. Can another party verify the evidence?

Recommended cards:

```text
ACTIVE PROFILES
payments-review@1.4.2 · prod · promoted by A. Chen

QUALITY
99.4% accepted tasks · threshold 98.0% · PASS

ECONOMICS
Calculated cost/task: $0.019 → $0.008

EVIDENCE
28 recent receipts · 28 signed · 0 incomparable runs
```

Every card links to source receipts and declared inputs.

### 8.4 Budget request template

```markdown
# Agent context-performance pilot

## Decision requested
Approve a 30-day LeanCTX pilot for <workflow>.

## Baseline
<task count>, <model>, <revision>, <quality contract>, <calculated cost/task>.

## Treatment
<Profile>, <Kit>, <integration depth>, <calculated cost/task>.

## Evidence
<receipt URI>, <public-key trust channel>, <verification command>.

## Guardrails
<quality threshold>, <budget cap>, <rollback command>, <data handling>.

## Decision at day 30
Promote, retune, or revert against the declared quality and economics.
```

Never annualize savings without workload-frequency and price assumptions.

### 8.5 Explicit roles

| Role | Local capability | Team capability |
|---|---|---|
| Developer | Tune, run local Dyno, inspect receipts. | Propose promotion. |
| Reviewer | Verify evidence and compare Profiles. | Approve promotion. |
| Platform owner | Set integration bounds. | Set defaults/retention. |
| Finance | Inspect aggregates. | Verify artifacts without code. |
| Security | Inspect data path. | Approve policy/Kits. |

Profile promotion must be an explicit auditable event with a rollback path.

## 9. Documentation structure

### 9.1 Top navigation

```text
Getting started | Concepts | SDK reference | Integrations | Kits | Profiles |
Dyno & evidence | Guides | Security & data | CLI reference | Changelog
```

Evidence is not hidden under “analytics.”

SDK reference is not the first stop for a new developer.

### 9.2 Getting started

Order pages by first value:

1. **Choose your path** — Codex, Claude Code, Cursor, Python, or custom agent.

2. **Install LeanCTX** — package/runtime behavior and no-surprises guarantees.

3. **Five-minute Python quickstart** — compression boundary and stats.

4. **Connect a coding agent** — connect, doctor, test, receipt, uninstall.

5. **Run your first comparison** — stock versus tuned with a quality gate.

6. **Read your first receipt** — facts, caveats, and verification command.

Each page ends with exactly one obvious next action.

### 9.3 Concepts

Required pages:

| Page | Required answer |
|---|---|
| Context is performance | Why selection, representation, reuse, and recovery matter. |
| Context lifecycle | Task through receipt, including data flow. |
| Attach / Wrap / Embed | Which depth to choose and what is observed/controlled. |
| Context sessions | Scope, identity, lifecycle, errors. |
| Tuning Profiles | Version, comparison, deployment, rollback. |
| Context Kits | Capability package, provenance, activation, permission. |
| Determinism and recovery | Byte stability and reference retrieval. |
| Quality gates | Why savings requires accepted outcomes. |
| Cost vocabulary | Usage, calculated cost, invoice reconciliation. |
| Privacy and local-first | What stays local, shared, and opt-in. |

### 9.4 SDK reference

Generate reference from stable contracts, grouped by developer job.

```text
leanctx
├── LeanCTX
├── ContextSession
├── ContextEnvelope
├── TuningProfile
├── ContextKit
├── ExecutionReceipt
├── SavingsReceipt
├── EvidenceBundle
├── Dyno
├── adapters
│   ├── OpenAI
│   ├── LiteLLM
│   ├── LangChain
│   ├── LlamaIndex
│   └── framework-independent compression
└── errors
```

Every API page contains:

1. One-sentence job description.

2. Minimal runnable example.

3. Inputs and output type.

4. Runtime/network/data behavior.

5. Exceptions or structured error result.

6. Version compatibility information.

7. Receipt/evidence effect.

### 9.5 Kits section

Required pages:

1. Use a built-in Kit.

2. Inspect a Kit before loading it.

3. Author a minimum Kit.

4. Test a Kit against fixtures.

5. Version and publish a Kit.

6. Pin, verify, and revoke a Kit.

7. Kit provenance, permissions, and security.

Document every TOML field, precedence rule, and distinction between a quality criterion and an executed gate.

### 9.6 Profiles section

Required pages:

1. Choose a starting Profile.

2. Create a Profile from baseline.

3. Validate and diff Profiles.

4. Run a controlled Profile comparison.

5. Promote and roll back a Profile.

6. Project, user, and organization scope.

7. Drift/scheduled evaluation, clearly marked commercial when applicable.

Publish schema, compatibility policy, examples, and migration guidance for every version.

### 9.7 Dyno and evidence section

This is a top-level documentation section, not an advanced appendix.

Required pages:

1. What LeanCTX measures.

2. Run a baseline and treatment.

3. Define a quality gate.

4. Read an execution receipt.

5. Read a savings receipt.

6. Verify a receipt offline.

7. Create and verify an evidence bundle.

8. Methodology and anti-cheating controls.

9. Share safely without code or prompts.

10. Auditor guide: what validation proves and cannot prove.

The standalone verifier receives its own dependency-light installation and verification page.

### 9.8 Integration page template

Every supported agent/framework page follows this fixed structure:

```text
1. What changes / what does not change
2. Prerequisites
3. Install
4. Connect or add the code delta
5. Doctor output
6. Smoke test
7. First gain result
8. Controlled comparison
9. Uninstall / rollback
10. Known limitations
11. Data path and privacy
```

An integration is not “supported” until all eleven parts exist and are tested.

### 9.9 Documentation state labels

| Label | Meaning |
|---|---|
| **Available now** | Released and supported in the named version. |
| **Preview** | Implemented with documented compatibility terms. |
| **Target contract** | Proposed and not yet runnable. |
| **Conceptual** | Architecture only; no implementation promise. |
| **Deprecated** | Works for stated window; migration path exists. |

These labels are a trust feature, not editorial decoration.

---

## 10. End-to-end journey storyboard

### Step 1 — Discover

Developer sees a credible workload-specific result with evidence.

Success measure: “reproduce” or “install,” not an empty page view.

### Step 2 — Install

Developer gets a local SDK/runtime without changes to agent or provider configuration.

Success measure: `lean-ctx doctor` is healthy in under two minutes.

### Step 3 — Connect

Developer chooses Attach, Wrap, or Embed without architecture overload.

Success measure: smoke test names the active integration.

### Step 4 — Observe

Developer sees deterministic compression stats around normal model input.

Success measure: understands this is context reduction, not a verified savings claim.

### Step 5 — Compare

Developer runs stock/tuned arms under a declared quality gate.

Success measure: result is PASS, FAIL, or INCOMPARABLE, never merely a percentage.

### Step 6 — Tune

Developer selects/writes Profile and optionally adds a Kit before repeating workload.

Success measure: exact Profile/Kit versions appear in receipt.

### Step 7 — Prove

Developer opens and verifies a signed receipt offline.

Success measure: another engineer can verify without source access.

### Step 8 — Share

Developer sends an evidence-backed decision memo.

Success measure: team can approve bounded pilot with rollback condition.

### Step 9 — Deploy

Team promotes a pinned Profile with scope, owner, and evidence link.

Success measure: active version and rollback path are visible.

### Step 10 — Repeat

Team reruns Dyno when code, workload, model, or provider pricing changes.

Success measure: stale evidence is detected rather than treated as current performance.

---

## 11. Acceptance criteria

### 11.1 First-session criteria

1. Route selection is one click or command.

2. Installation changes no agent/provider configuration without explicit action.

3. `doctor` separates healthy, optional, and failed states.

4. Quickstart passes from clean virtual environment.

5. Simplest integration changes no more than three lines.

6. Output shows original, compressed, saved, and percentage fields.

7. Tutorial explains that compression stats are not controlled savings proof.

8. Comparison guide is reachable without search.

9. Attach pages include uninstall/rollback.

10. Every failure names a repair action or doc link.

### 11.2 Evidence criteria

1. “Verified” never renders without passed quality gate.

2. Comparator rejects mismatched task/revision/model/budget controls.

3. Calculated cost names price-table version.

4. Provider usage and calculated cost are separate fields.

5. Receipt verification runs offline.

6. Trust-key mode is explicit: embedded versus out-of-band key.

7. Default sharing omits code, paths, prompts, and secrets.

8. Receipt pins Profile and Kit identity/version/digest.

9. Raw evidence access requires explicit privacy mode.

10. Invalid artifact returns unambiguous status and non-zero exit code.

### 11.3 Documentation criteria

1. README, website, CLI, and SDK names agree.

2. Shipping and target APIs are visually distinct.

3. Quickstarts run in CI against clean environments.

4. Stable output blocks have snapshot/contract tests.

5. Reference pages document data path and errors.

6. Support claims require connect/doctor/smoke/Dyno/receipt/uninstall flows.

7. Deprecated imports/packages include migration deadline.

8. Receipt docs include limitations beside positive claims.

### 11.4 Consent-based DX telemetry

If explicitly enabled, collect only journey events without source, prompt, or receipt contents:

```text
install_completed
doctor_completed
integration_connected
quickstart_compressed
comparison_started
comparison_completed
comparison_quality_failed
profile_saved
receipt_verified
evidence_shared
team_pilot_created
```

Document identifiers, retention, use, and opt-out in the same page that enables telemetry.

---

## 12. Launch sequence

### Phase 1 — Make the current journey coherent

1. Publish the shipping `compress()` quickstart.

2. Publish `proxy enable` behavior and failure modes beside it.

3. Publish current Kit and profile CLI journeys.

4. Publish savings-batch and standalone-verifier guides.

5. Resolve `lean-ctx-sdk` versus `lean-ctx` package naming before paid acquisition.

6. Publish a “shipping versus target SDK” status page.

### Phase 2 — Ship the complete developer loop

1. Stabilize sessions, Profiles, Kit load, and typed receipts.

2. Add canonical local Dyno CLI/API.

3. Enforce quality gates and comparison controls.

4. Emit receipts from one canonical measurement path.

5. Add clean-room quickstart fixture tests.

6. Move target snippets in this document to “Available now” only after release.

### Phase 3 — Add team evidence

1. Add Profile promotion and rollback records.

2. Add private registries only after local paths are excellent.

3. Add shared receipt index and decision-memo export.

4. Add scheduled Dyno and drift detection as clearly commercial capability.

5. Keep local Runtime, tuning, receipts, and offline verification useful without an account.

---

## 13. Final DX principle

LeanCTX wins trust when every claim traces to an observed run, declared method, accepted outcome, and portable artifact.

The developer should feel this progression:

```text
“It fits in my code.”
        ↓
“I can see what it changed.”
        ↓
“I can test a better strategy.”
        ↓
“I can prove the result to someone else.”
        ↓
“My team can safely use and improve it.”
```

That is the complete LeanCTX SDK developer experience.

## 14. Future: Capability Extension

**Status:** **Conceptual** — architecture direction only; not a Phase A or SDK v1 feature.

### 14.1 Progressive disclosure

Capability composition extends LeanCTX without making ordinary agent integration more complex.

| Level | Developer intent | Future interaction |
|---|---|---|
| Simple | Improve an existing agent. | Use the existing two-line setup; no capability terms or registry knowledge required. |
| Advanced | Use a measured configuration. | Select a pinned Profile that declares the required capabilities. |
| Expert | Bring an internal system. | Explicitly register a custom capability in the application or Runtime. |
| Community | Publish a reusable provider. | Implement the capability contract, package it locally, and install it without forking LeanCTX. |

**Simple — unchanged**

```python
ctx = LeanCTX(project='.')
agent = ctx.wrap(agent)
```

This remains the default experience. LeanCTX must not require an application developer to know which compressors, knowledge sources, or execution modes are active.

**Advanced — choose a Profile**

```python
ctx = LeanCTX(profile='payments-review@7')
```

A Profile is the progressive-disclosure boundary: it selects a tested, pinned capability configuration while keeping provider choice and composition out of the everyday call site.

**Expert — register a company capability**

```python
ctx.capabilities.register(MyCompanyKnowledgeProvider(...))
```

Registration is explicit. The Runtime validates the provider manifest and policy before it can participate in a task; it is never silently discovered from application dependencies.

**Community — build or install a capability**

```rust
impl CompressionProvider for MyCompressor {
    fn capabilities(&self) -> CapabilityManifest { ... }

    fn compress(&self, request: CompressionRequest)
        -> Result<CompressionResult> { ... }
}
```

```text
lean-ctx capability install ./my-provider
```

These examples define the intended direction, not a released API. The exact language bindings, transport, and package format remain future design work.

### 14.2 Future user personas

| Persona | Primary goal | Starting point |
|---|---|---|
| Agent developer | Improve an existing agent without changing its architecture. | The unchanged `LeanCTX(...).wrap(...)` route. |
| Performance owner | Reuse a quality-gated configuration for a workload. | A pinned Profile such as `payments-review@7`. |
| **Capability developer** | Build, test, package, and maintain a bounded context-performance provider. | A manifest plus one supported provider contract. |

A capability developer may be an internal platform team, a domain-software vendor, or an open-source maintainer. Their work must not require a LeanCTX core fork or expose their implementation details to simple users.

### 14.3 Extension points

Every future capability is a bounded provider plus a machine-readable `CapabilityManifest`. The manifest lets the Runtime validate whether the provider can run; the planner separately decides whether it should run for a task.

| Extension point | Provider responsibility | Required future declaration |
|---|---|---|
| `CompressionProvider` | Transform a supported domain format into a context-efficient representation. | `capabilities()` and `compress(request) -> result`. |
| `KnowledgeProvider` | Supply attributable knowledge candidates from a graph, vault, or enterprise source. | Capability manifest and a candidate-retrieval operation. |
| `RetrievalProvider` | Supply task-relevant candidates from a search or retrieval system. | Capability manifest, input constraints, and ranked candidate metadata. |
| `ResponseOptimizer` | Optimize a bounded tool or model-output representation. | Supported operations, fidelity, and recovery behavior. |
| `EvaluationProvider`, `OutcomeTracker`, `PolicyDecisionProvider`, `EvidenceProvider` | Measure quality, record outcomes, constrain selection, or link evidence. | Inputs, trust boundary, and evidence semantics. |

The capability name alone is insufficient. A future `CapabilityManifest` declares at least:

- identity: id, publisher, version, license, and compatibility;
- scope: capability type, operations, accepted content types, and input limits;
- behavior: fidelity/lossiness, recoverability, determinism, cache safety, and streaming;
- execution: in-process, local-process, MCP/tool-mediated, or remote-service mode plus network requirements;
- trust: whether raw content leaves the environment and supported classifications;
- measurement: latency/resource expectations and whether the provider emits receipt-linkable metrics.

Capabilities supply candidates or transformations; they do not independently decide what reaches the agent. LeanCTX preserves one task-specific selection point so it can enforce policy, quality, latency, cost, recovery, and composition constraints.

### 14.4 Profiles compose capabilities without exposing plumbing

A future Profile may pin native, customer, and third-party providers as one measured configuration:

```yaml
capabilities:
  - id: leanctx.code-context
    operation: structural_plan
  - id: company.architecture-graph
    operation: retrieve
  - id: company.support-log-compressor
    operation: compress
```

The Profile records identity and configuration, not an implicit best-effort plugin scan. Its benchmark and receipt record the selected capability versions and measured outcome so a team can compare, promote, or roll back the complete composition.

### 14.5 Knowledge graph capabilities

Obsidian, Neo4j, and customer knowledge services integrate through `KnowledgeProvider`; none becomes a hard-coded LeanCTX dependency.

- **Obsidian:** a local provider indexes a vault and returns an ADR, note, or graph link as a candidate with source path, digest/version, timestamp, confidence, and classification.
- **Neo4j:** a provider queries a customer graph through its declared local or remote trust boundary and returns attributable graph candidates with the same metadata.
- **Custom graph:** an internal documentation graph or Knowledge Hub implements the same candidate contract, preserving its own schema behind the provider boundary.

```text
Agent task
  → LeanCTX planner
  → source-code search + project memory + KnowledgeProvider
  → attributed candidates (for example, ADR-029 / retries)
  → LeanCTX selects the current implementation, verified decision summary,
    and relevant test evidence
  → Context Envelope
```

The graph supplies candidates; LeanCTX owns task-specific context selection. A result must therefore carry enough provenance for a receipt to identify the source and version used without automatically exposing the raw graph or private note contents.

### 14.6 Customer compression engines

A customer may publish a `CompressionProvider` for a format where generic text compression is insufficient, such as:

- SAP event logs;
- industrial telemetry;
- an internal DSL; or
- customer-support transcripts.

The provider declares its supported input, fidelity and recovery semantics, deterministic/cache behavior, latency expectation, data boundary, and receipt metrics. The planner can then select it only when its manifest, policy, workload constraints, and measured quality support that choice.

Local packaging keeps the initial installation route simple:

```text
lean-ctx capability install ./my-provider
lean-ctx capability doctor <id>
```

A future registry begins as a local execution catalog with inspect, enable, disable, and doctor operations. Marketplace behavior, remote execution, organizational allowlists, and signed publisher trust remain later work rather than requirements for the current sprint.

### 14.7 Scope and safety guardrails

1. Phase A and SDK v1 keep their exact documented API and behavior. This section adds no capability registry, provider interface, profile schema field, or installation command to the current implementation scope.

2. Existing simple setup, shipping `compress()` workflows, Kits, current Profile commands, sessions, and receipt contracts remain unchanged.

3. Future capability documentation must be labelled **Conceptual** until a versioned contract, compatibility policy, validation path, and tests are released.

4. A capability cannot expand filesystem permissions, bypass Runtime allowlists, send content remotely, or alter policy without an explicit declaration and the Runtime's approval.

5. Capability promotion is quality-gated. Token reduction alone never proves that a provider or composition is suitable for a workload.

**DX principle:** simple usage stays simple; advanced extensibility exists when needed.
