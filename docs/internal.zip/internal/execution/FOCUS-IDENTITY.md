# Thinkery / LeanCTX — Focus and Identity

> **Status:** Active execution guardrail. [Context SDK Positioning](../vision/05-CONTEXT-SDK-POSITIONING.md)
> controls the product story; [Product Architecture](../vision/PRODUCT-ARCHITECTURE.md)
> controls product status.

## Identity

**LeanCTX is The Context SDK for AI Agents.**

> **Give every agent a context system.**

LeanCTX selects, shapes, reuses, and recovers task-fit context inside an agent
loop the customer already owns. The agent host owns the task, model, tools,
prompts, retries, permissions, and orchestration.

> **Your framework runs the agent. LeanCTX manages its context path.**

## Message hierarchy

1. **Thinkery:** Systems for the context agents need to work.
2. **LeanCTX:** The Context SDK for AI Agents.
3. **Hero:** Give every agent a context system.
4. **Mechanism:** Select → Shape → Reuse → Recover.
5. **Proof:** Name the affected measure; compare baseline and treatment; declare
   the quality threshold and methodology.

## What to say

- An agent can access everything. That does not mean it should load everything.
- Return a task-fit source view now; recover exact source material when needed.
- Reuse valid project context rather than rediscovering it.
- Hand off decisions and evidence, not a whole transcript.
- LeanCTX works inside or alongside an existing agent loop.

## What not to say

- Agent platform, agent swarm, agent operating system, or generic orchestrator.
- Generic “performance,” “innovation,” or “intelligence” claims without naming
  the affected dimension and mechanism.
- Universal savings, quality, reliability, or hallucination claims.
- Shared enterprise brain, Agent Bus, or a general agent-to-agent product.
- Any Research or Preview surface as installable or generally available.

## Status guardrail

| Surface | Status | External boundary |
| --- | --- | --- |
| Local Runtime, coding-agent CLI/MCP/proxy paths | Available | A local context system for supported coding agents. |
| Python SDK v1 and declared OpenAI Agents wrapper | Preview | Narrow documented reference-wrapper scope. |
| Native custom-agent use | Preview | Host keeps full agent-loop ownership. |
| Shared Project Context and handoffs across agents | Research | Local substrate exists; no public coordination contract. |
| Benchmark, Profiles, Kits, AutoTune, cloud/enterprise operation | Research | Direction only until contracts and proof are earned. |

## Decision gate

Before approving copy, a proposal, or implementation, confirm:

1. Does it reinforce the Context SDK and its four-step lifecycle?
2. Does it preserve the host-versus-LeanCTX responsibility split?
3. Is every capability marked Available, Preview, or Research?
4. Does each outcome claim state its measure, baseline, quality threshold, and
   methodology?
5. Does it avoid unearned multi-agent, cloud, and orchestration promises?

## Delivery focus

1. Keep Attach reliable for the available coding-agent path.
2. Converge the Preview Python SDK and reference wrapper on explicit contracts.
3. Build the canonical custom-agent demonstration: task-fit views, reuse,
   recovery, bounded handoff, and a Receipt.
4. Productize Shared Project Context only after privacy, freshness, conflict,
   interoperability, support, and status gates are explicit.
