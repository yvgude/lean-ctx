# E2 — GitLab Issue Manifest

## Issue status — 2026-08-21

Synced to GitLab project ID 5 (`gitlab.pounce.ch/root/lean-ctx`).

| Issue | Title | GitLab state (2026-08-21) |
|---|---|---|
| #1242–#1244 | WS-1 waves 1–3 | **closed**; milestone WS-1 closed |
| #1245–#1253 | WS-2 SDK implementation + PyPI | **closed** |
| #1254 | Run first paid pilot (WS-2.10) | **open** — **in progress** |
| #1255–#1259 | WS-3 design system + v2 pages | **closed** (`deploy`; website **ON HOLD**) |
| #1260 | Remove old pages / nav / footer / SEO | **open** — **ON HOLD** |
| #1261 | Deploy to production | **open** — **ON HOLD** |
| #1262–#1266 | WS-4 OCLA | **closed** — engineering landed (`634dedc0f7`, `6e2270801c`); public claims wait for #1254 |
| #1267–#1268 | WS-5 partnership | **closed** — cancelled; monopoly strategy, no partnership work |

When creating new work, still use the label taxonomy and templates below. Do not re-open closed WS-1/WS-2 implementation issues unless the shipped artifact regressed.

Source: `docs/internal/execution/MASTER-EXECUTION-PLAN.md` (read in full on
2026-08-20). Target: `gitlab.pounce.ch/root/lean-ctx` (project ID `5`).

This manifest contains the 27 delivery issues requested. Multi-step plan items
are grouped only under the requested issue titles; every master-plan task is
represented in an issue scope or acceptance criterion.

## Label taxonomy

- `status: ready`
- `priority: high` or `priority: medium`
- One relevant `area: …` label

New labels needed before creation: `status: ready`, `priority: high`,
`priority: medium`, `area: cleanup`, and `area: sdk`. Existing relevant area
labels are reused where available.

## WS-1 Codebase Cleanup

### Wave 1 — Archive duplicate Python SDKs

Labels: `status: ready`, `priority: high`, `area: cleanup`

Scope: Archive `py-sdk/`, `python-sdk/`, and `clients/python/`, preserving
their history and leaving one clearly defined active Python SDK path.

Acceptance criteria:

- The three duplicate SDK directories are archived or removed from active code.
- The canonical Python SDK location is unambiguous and documented.
- No active build, test, packaging, or documentation path imports a duplicate SDK.
- Repository gates pass: release build, library tests, clippy, and formatting.

### Wave 2 — Archive unused directories

Labels: `status: ready`, `priority: high`, `area: cleanup`

Scope: Archive `marketing/`, `email-templates/`, `demo/`, `lab/`, `blog/`, and
`lean/` from the active repository surface.

Acceptance criteria:

- Each listed directory is archived or removed from active source control.
- Any still-needed material has a deliberate archival location and README note.
- CI, documentation links, and build scripts contain no stale references.
- Repository gates pass.

### Wave 3 — Consolidate benchmark dirs

Labels: `status: ready`, `priority: high`, `area: benchmark`

Scope: Consolidate `bench/` and `benchmark/` into `benchmarks/`; remove
`test-results/` and `tmp/` from tracking; update README links.

Acceptance criteria:

- `benchmarks/` is the sole canonical benchmark directory.
- Benchmark commands and docs reference only the canonical path.
- Generated `test-results/` and `tmp/` content is untracked and ignored without
  deleting useful local working data.
- README links are valid after the move.
- Repository gates pass.

## WS-2 SDK v1 + Evidence

### Consolidate Python types

Labels: `status: ready`, `priority: high`, `area: sdk`

Scope: Move and reconcile Python types from `py-sdk/` and `clients/python/`
into `packages/python-lean-ctx/`.

Acceptance criteria:

- One public type surface lives in `packages/python-lean-ctx/`.
- Duplicate definitions, imports, and packaging metadata are eliminated.
- Type compatibility and package tests cover the consolidated API.
- Migration notes identify the supported import path.

### Implement ctx.wrap()

Labels: `status: ready`, `priority: high`, `area: proxy`

Scope: Implement the OpenAI Agents SDK adapter that routes a wrapped workload
through the LeanCTX proxy.

Acceptance criteria:

- `ctx.wrap()` accepts the documented OpenAI Agents SDK workload shape.
- Wrapped execution uses the proxy while retaining the workload result contract.
- Configuration, failures, and opt-out behavior are documented and tested.
- Every successful wrapped call enters the evidence/receipt path.

### Implement ContextSession

Labels: `status: ready`, `priority: high`, `area: sdk`

Scope: Provide `ContextSession` with a correlated task identity across wrapped
work, profiles, and receipts.

Acceptance criteria:

- A session exposes a stable, documented correlated task identity.
- `ctx.wrap()` can create or use a session without breaking normal execution.
- Receipt and benchmark records link to the same session identity.
- Unit tests cover identity propagation and concurrent-session isolation.

### Implement Receipt generation

Labels: `status: ready`, `priority: high`, `area: artifacts`

Scope: Generate a receipt for every `ctx.wrap()` call.

Acceptance criteria:

- Each completed wrapped call emits a versioned receipt with required execution,
  quality, and provenance fields.
- Receipt contents identify the session and profile without exposing secrets.
- Receipt generation has deterministic tests and a documented local location.
- Failure cases are explicit and never silently claim a verified receipt.

### Implement Performance Benchmark

Labels: `status: ready`, `priority: high`, `area: benchmark`

Scope: Build a reproducible local baseline-versus-treatment benchmark.

Acceptance criteria:

- The same workload runs in baseline and LeanCTX treatment modes.
- Results record real comparable performance and quality inputs, not synthetic
  success metrics.
- The benchmark produces a Performance Profile consumable by receipt creation.
- A documented command reproduces the run locally.

### Implement Quality Gate

Labels: `status: ready`, `priority: high`, `area: verification`

Scope: Add automated assertions and an explicit human quality gate to evidence.

Acceptance criteria:

- Automated quality assertions have declared thresholds and test coverage.
- A human approval/rejection outcome is recorded where required.
- Failed or missing quality evidence prevents a favorable verified outcome.
- Gate decisions are represented in the receipt/profile evidence chain.

### Implement offline verification

Labels: `status: ready`, `priority: high`, `area: verification`

Scope: Verify generated receipts locally with no network dependency.

Acceptance criteria:

- A documented CLI/API verifies receipt structure, integrity, and required
  evidence offline.
- Tampering, missing evidence, and incompatible versions fail closed.
- Verification has positive and negative test fixtures.
- Quickstart-compatible local output reports the verification result clearly.

### Write Quickstart docs

Labels: `status: ready`, `priority: high`, `area: docs`

Scope: Document the shortest complete SDK v1 workflow.

Acceptance criteria:

- A new user can install the package, wrap a workload, inspect a receipt, and
  verify it offline from the Quickstart alone.
- Examples are executable, use current terminology, and avoid hosted-platform
  claims.
- Prerequisites, expected output, and troubleshooting are included.
- Docs link to benchmark and quality-gate concepts where needed.

### Publish v1.0 on PyPI

Labels: `status: ready`, `priority: high`, `area: sdk`

Scope: Release the validated `python-lean-ctx` v1.0 package to PyPI.

Acceptance criteria:

- Version, build metadata, changelog, and package contents match the v1 API.
- Release artifacts install successfully from PyPI in a clean environment.
- `ctx.wrap()`, `ContextSession`, receipt generation, and offline verification
  work from the published package.
- Release provenance and rollback/patch-release process are documented.

### Run first paid pilot

Labels: `status: ready`, `priority: high`, `area: benchmark`

Scope: Run the first Thinkery Agent Tuning Sprint paid pilot (target CHF 7,500)
using the SDK v1 evidence workflow.

Acceptance criteria:

- A signed, paid pilot has a defined workload and success criteria.
- The engagement produces a reproducible receipt verified offline by the
  customer or jointly with the customer.
- Baseline/treatment evidence and quality-gate result are retained with consent.
- Learnings result in prioritized follow-up issues without publishing customer
  data or unsupported claims.

## WS-3 Website Rebuild

**Status (2026-08-21): ON HOLD.** Do not change or deploy website work while
WS-2.10 is in progress.

### Design system implementation

Labels: `status: ready`, `priority: medium`, `area: website`

Scope: Implement the Visual Brand Guidelines in the existing Astro site.

Acceptance criteria:

- Colors, Aeonik/Mono typography, grid, spacing, and components follow the
  approved visual guidelines.
- Black ground and minimal orange intervention are applied accessibly.
- Shared primitives cover routing lines, data panels, and receipt visualizations.
- Components work responsively and meet keyboard/contrast requirements.

### Homepage rebuild

Labels: `status: ready`, `priority: medium`, `area: website`

Scope: Rebuild the homepage around Hero, Problem, SDK, Integration, Evidence,
and Enterprise sections.

Acceptance criteria:

- Every listed narrative section is implemented using the design system.
- Messaging reflects local-first, model-agnostic context performance
infrastructure.
- Evidence shown is real or clearly labeled as illustration; no fake metrics.
- Responsive, accessible page passes the production build.

### /sdk page

Labels: `status: ready`, `priority: medium`, `area: website`

Scope: Create a developer-focused `/sdk` page with code examples and
progressive disclosure.

Acceptance criteria:

- The page explains installation, `ctx.wrap()`, sessions, receipts, and offline
  verification at an appropriate level of detail.
- Code examples match the published SDK/Quickstart.
- Progressive disclosure keeps primary developer actions easy to find.
- Links to documentation and source are valid.

### /enterprise page

Labels: `status: ready`, `priority: medium`, `area: website`

Scope: Create a performance-first enterprise narrative at `/enterprise`.

Acceptance criteria:

- The page explains evidence, verification, governance, and deployment posture
  without unsupported hosted-platform claims.
- Product status labels use Available, Preview, or Research consistently.
- Claims are traceable to actual product capability or marked as future research.
- Page is responsive, accessible, and integrated into navigation.

### /benchmark page

Labels: `status: ready`, `priority: medium`, `area: benchmark`

Scope: Create `/benchmark` and replace obsolete Dyno terminology.

Acceptance criteria:

- The page explains workload, baseline/treatment, quality gate, profile, and
  receipt methodology.
- Old Dyno language is removed from the benchmark experience.
- Visualized data is real or explicitly illustrative.
- Page links to reproducible benchmark and verification documentation.

### Remove old pages

Labels: `status: ready`, `priority: medium`, `area: website`

Scope: Remove misaligned old pricing/cloud pages; restructure `/docs`; update
navigation, footer, and SEO for the new terminology.

Acceptance criteria:

- Old pricing and cloud references that conflict with the narrative are removed
  or redirected deliberately.
- `/docs` information architecture aligns with the new terminology.
- Navigation is LeanCTX, SDK, Enterprise, Benchmark, Docs, and GitHub.
- Footer states Open source, Local-first, and Model-agnostic.
- Meta titles/descriptions match the new messaging; internal links and redirects
  have no broken destinations.

### Deploy

Labels: `status: ready`, `priority: medium`, `area: website`

Scope: Deploy the rebuilt Astro website to production through GitLab CI on
`origin` only.

Acceptance criteria:

- Production build, preview/validation, and deploy stages pass in GitLab CI.
- Deployment uses the `deploy` branch workflow and does not push to GitHub.
- Live routes, redirects, metadata, and key responsive layouts are smoke-tested.
- Rollback instructions and the deployed revision are recorded.

## WS-4 OCLA Composable

### CapabilityManifest v0 schema

Labels: `status: ready`, `priority: medium`, `area: ocla`

Scope: Define the v0 `CapabilityManifest` schema in `lean-ctx-protocol`.

Acceptance criteria:

- Schema declares capability identity, version, interface, compatibility, and
  validation requirements.
- Serialization/deserialization and invalid-manifest tests are present.
- The schema is versioned and documented for external implementers.
- The definition respects the completed OCLA audit constraints.

### Normalize CompressionProvider

Labels: `status: ready`, `priority: medium`, `area: ocla`

Scope: Make `CompressionProvider` the first normalized v0 capability and add
its conformance test.

Acceptance criteria:

- `CompressionProvider` implements the CapabilityManifest v0 contract.
- Compatibility/version negotiation and error behavior are explicit.
- A `compression_provider` conformance test passes against the native provider.
- Existing compression behavior remains correct through the normalized API.

### Capability in Profile + Receipt

Labels: `status: ready`, `priority: medium`, `area: artifacts`

Scope: Add capability ID and version to Performance Profile and Receipt schemas.

Acceptance criteria:

- Both schema formats carry the exact capability ID and version used.
- Generation, parsing, and offline verification preserve and validate the fields.
- Older inputs have a documented compatibility or rejection policy.
- Fixture tests prove capability provenance survives the evidence chain.

### Benchmark through capability path

Labels: `status: ready`, `priority: medium`, `area: benchmark`

Scope: Run the existing benchmark through the capability path with unchanged
semantic results and new plumbing.

Acceptance criteria:

- Baseline/treatment benchmark uses the capability dispatch path.
- Results are equivalent to the native path within declared deterministic
  tolerances.
- Profile and receipt identify the selected capability/version.
- Regression tests cover the path and prevent bypassing the contract.

### Sample external capability

Labels: `status: ready`, `priority: medium`, `area: ocla`

Scope: Build a trivial external local-process capability sample.

Acceptance criteria:

- An external process implements the documented manifest and contract.
- LeanCTX discovers, validates, invokes, and reports the sample capability.
- The sample is intentionally minimal, runnable locally, and documented.
- Integration tests cover success, invalid manifest, and process failure paths.

## WS-5 Partnership (CANCELLED — issues #1267–#1268 closed)

### OptimizationProvider contract

Labels: `status: ready`, `priority: medium`, `area: ocla`

Scope: Define the `OptimizationProvider` interoperability contract, including a
path for a customer-developed Knowledge Graph capability example.

Acceptance criteria:

- Contract defines input/output, identity, versioning, evidence, and failure
  semantics compatible with OCLA v0.
- Contract documentation explains composition with CompressionProvider.
- A documented Knowledge Graph capability example demonstrates customer
  implementability without productizing a new package format.
- Conformance and compatibility tests cover the contract boundary.

### RTK joint benchmark proposal

Labels: `status: ready`, `priority: medium`, `area: benchmark`

Scope: Propose and, if agreed, execute a joint RTK benchmark experiment.

Acceptance criteria:

- A written proposal defines governance, datasets/workloads, quality metrics,
  confidentiality, and publication approval.
- If RTK agrees, RTK is implemented as an external capability provider under the
  OptimizationProvider contract.
- The agreed study runs four arms: Stock, RTK, LeanCTX, and RTK+LeanCTX.
- Results are reproducible, reviewed by partners, and published only with
  approval (blog/community); no result is implied before agreement.

## Milestone assignment

| Milestone | Issues |
|---|---:|
| WS-1 Codebase Cleanup | 3 |
| WS-2 SDK v1 + Evidence | 10 |
| WS-3 Website Rebuild | 7 |
| WS-4 OCLA Composable | 5 |
| WS-5 Partnership | 2 |
| **Total** | **27** |
