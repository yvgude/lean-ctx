# LeanCTX / Thinkery AG — SDK-First Investor Narrative

> **Classification:** Active support narrative
>
> **Authority:** The canonical architecture controls product, license,
> repository, availability, and Cloud status.

## Company and product

Thinkery AG is building **LeanCTX Production SDK**, a premium BSL 1.1 Context
SDK for AI agents and AI-native products, on top of the public Apache-2.0
LeanCTX Engine.

> **Give every agent a production context system.**

LeanCTX is an SDK company with a strong OSS distribution and trust substrate.
It is not an agent framework, benchmark consultancy, or Cloud-first wrapper.

## Product architecture

```text
Apache-2.0 Engine
      ↓
BSL 1.1 Production SDK — primary product
      ↓
customer-owned agent / AI-native product
      ↓
optional private Cloud and optimization later
```

The Engine provides deterministic context mechanisms. The SDK turns them into a
maintained production lifecycle: Select → Shape → Reuse → Recover.

The customer retains its agent, models, tools, orchestration, business logic,
UX, and customer relationship. LeanCTX provides the context system.

## Why customers buy

A capable customer can build on the Engine. Doing so makes that company the
permanent owner of lifecycle semantics, freshness and recovery policy, budgets,
evidence projection, framework adapters, security defaults, compatibility,
migrations, tests, documentation, and production support.

The BSL 1.1 SDK packages those responsibilities into one premium product.

> **The Engine makes it possible. The SDK makes it practical to depend on in
> production.**

The strongest market signal is:

> **“We could build this ourselves. We chose LeanCTX instead.”**

## Product value

The Production SDK owns:

- `ContextSession`, `ContextSource`, `ContextView`, `ContextPlan`, and
  `ContextReceipt` as coherent product semantics;
- bounded budgets, explicit source identity, freshness, trust, reuse, recovery,
  and degradation rules;
- factual evidence lineage and quality-gated comparison hooks;
- maintained framework/host integrations with streaming and retry semantics;
- Engine×SDK compatibility, migrations, deprecation windows, fixtures,
  provenance, and stable errors;
- clean installation, excellent documentation, support, and OEM readiness.

It must make sophisticated context engineering feel boringly simple. Its moat is
execution quality and responsibility removed from customers, not a crippled
Engine or hidden protocol.

## Distribution

The public Engine creates trust, independent utility, developer awareness, and a
low-friction path to experience LeanCTX mechanisms.

The commercial motion is **LeanCTX Inside**:

```text
AI-native product
      ↓
its agent/runtime
      ↓
LeanCTX Production SDK
      ↓
LeanCTX Engine
      ↓
its data, tools and models
```

One integration can reach many downstream deployments. Internal-agent adoption,
then embedded AI-native products and OEM relationships, create compounding
distribution without requiring LeanCTX to own the agent.

## Product-market-fit proof

SDK PMF is not GitHub stars or token savings alone. Evidence is:

- hours/days from install to a useful Receipt and existing-agent integration;
- low integration code/configuration and declining founder assistance;
- quality-preserving context improvement, correct reuse/recovery, and complete
  evidence;
- a customer choosing LeanCTX after an explicit build-vs-buy evaluation;
- retention across an Engine/SDK upgrade;
- reuse in a second workflow or agent;
- downstream embedded deployment, paid production license, or OEM commitment.

The first design partners should already operate real context-heavy agents and
have engineers capable of building their own layer. Their decision not to own
that infrastructure validates the product.

## Business model

- **Primary:** BSL 1.1 Production SDK licenses and production support.
- **Expansion:** embedded/OEM agreements and broader SDK adoption.
- **Later optional:** private Cloud for organization-scale history, governance,
  Continuous Optimization, and Selection Intelligence.

Cloud extends the SDK business; it is not required to justify it. Pricing, OEM
terms, evaluation/free-use boundaries, and exact BSL parameters remain pending
until approved. The BSL 1.1 license family does not.

## Delivery discipline

```text
Engine contract and evidence
        ↓
Production SDK vertical slice
        ↓
real customer and embedded adoption
        ↓
SDK hardening and repeatability
        ↓
optional Cloud / optimization
```

The first Production SDK proves one lifecycle, one supported framework path, one
native Embed path, one Engine Protocol, one Receipt, excellent docs, clean
installation, and real compatibility policy. No mock Runtime, founder-only
setup, or broad adapter catalogue.

## Risks and answers

| Risk | Answer |
| --- | --- |
| Customers can build on the Apache Engine. | Yes. Win on lower permanent ownership cost and better maintained product quality. |
| SDK becomes a thin wrapper. | Keep lifecycle, policy, adapters, compatibility, migrations, DX, and OEM semantics in the SDK. |
| Commercial strategy weakens OSS trust. | Keep Engine useful, Apache-2.0, documented, and protocol-driven. |
| Cloud distracts before PMF. | Gate it behind repeat SDK adoption and customer evidence. |
| Product scope expands into agents/orchestration. | Host retains execution; LeanCTX owns context only. |

## Investor thesis

Context becomes infrastructure as agents grow longer-lived, more tool-heavy,
and embedded in products. LeanCTX owns the production context lifecycle while
remaining model- and framework-compatible. An open Engine accelerates trust and
adoption; the premium SDK captures value; embedded distribution compounds reach;
later production evidence can support proprietary optimization.

> **Engine is open. SDK is BSL 1.1. SDK is the product. Cloud comes later.**
