# LeanCTX OSS Preservation Contract

> **Classification:** Binding extraction guardrail
>
> **Audited source:** `github/main@2c7d0044302d50af8d218a041b45726ad710757c`
>
> **Remote state:** **VERIFIED** by fetch on 2026-08-24. The task-local
> documentation and P2 candidate still require their own gates.

## Purpose

The future Engine/Production SDK split must preserve the supported Apache-2.0
product experience. Product ownership moves to the SDK through maintained
lifecycle responsibility, never by degrading useful Engine mechanisms or
safety.

> **This contract protects supported user-visible behavior, security and
> explicit compatibility commitments. It does not guarantee indefinite
> retention of every Apache module, experimental surface, internal abstraction
> or unused feature.**

> **Implementation may be replaced or removed when the protected user
> experience remains equivalent or better and applicable compatibility or
> deprecation obligations are satisfied.**

> **No user should reasonably conclude that Thinkery made the Apache product
> worse to force purchase of the Production SDK.**

This contract applies to every extraction wave. A protected capability may
change only through an explicit compatibility or deprecation decision with a
replacement, behavioral fixtures, release notes, and rollback. Internal module
identity is never a fixture requirement.

Canonical scope rule: **preserve the OSS product contract, not the historical
monolith.** Already-published Apache rights remain. Future Engine releases may
remove unused, redundant, experimental, unsupported or SDK-oriented
implementation when no protected journey or explicit compatibility commitment
is materially regressed.

## Non-negotiable invariants

- Engine remains independently installable and useful without SDK, account, or
  Cloud.
- Existing Apache-2.0 rights and published source remain unchanged.
- Path containment, secret protection, bounded IO/process execution, artifact
  integrity, and safe defaults never move behind BSL.
- Explicit user requests such as `full`, `lines`, `diff`, and recovery retain
  their meaning; automatic shaping may not silently override them.
- Derived output retains an exact recovery path whenever source remains
  available.
- Deterministic output stays a function of content, mode, task, and declared
  configuration; cacheable bodies contain no incidental dynamic data.
- Local CLI, MCP, proxy, hooks, and Rust embedding remain local-first.
- Existing Attach heuristics may remain as OSS compatibility behavior, but do
  not become the canonical cross-product SDK lifecycle.

## Preservation tiers

- `OSS_CORE_CONTRACT`: protected coding-agent behavior, security or local
  Engine mechanism; replacement requires equivalent-or-better behavior.
- `OSS_TRANSITION_COMPAT`: current supported journey depends on the behavior,
  but not the implementation; remove only after replacement parity and any
  applicable deprecation.
- `OSS_NOT_PRESERVED`: no continuing OSS product promise; reachability and
  SemVer still determine safe removal mechanics.
- `OPEN_INTEROP_CONTRACT`: intentionally open portable protocol, format or
  verifier whose compatibility is governed by its versioned contract.

## Preserved supported surface

| Capability | Supported entry point | Before-split observable contract | Security invariant | Compatibility expectation | Golden fixture | Allowed tolerance |
| --- | --- | --- | --- | --- | --- | --- |
| Install/setup | documented installer; `lean-ctx setup` | Installs local binary/config and supported agent integration without Cloud | no secret export; bounded file changes; idempotent rerun | same clean-machine path or documented additive migration | `install_clean`, `setup_repeat` | exact exit semantics; no unexplained new network dependency |
| Uninstall | `lean-ctx uninstall` | Removes LeanCTX-managed integration while preserving user-owned files | target ownership proven before removal | no user-data loss; rollback documented | `uninstall_owned_files` | zero safety tolerance |
| Doctor/status | `lean-ctx doctor`, `lean-ctx status` | Reports actionable local health and integration state | redacts secrets and avoids broad traversal | existing healthy/broken states remain diagnosable | `doctor_healthy`, `doctor_broken`, `status_local` | normalized semantic equality |
| Claude Code Attach | setup/hooks/MCP path | Existing Claude coding workflow can use supported context tools | scoped project root; explicit permissions | no SDK purchase or Cloud required | `attach_claude_smoke` | same accepted tool result and exit state |
| Codex Attach | setup/hooks/MCP path | Existing Codex workflow receives supported context tools and session continuity | same containment and redaction | no SDK purchase or Cloud required | `attach_codex_smoke` | same accepted tool result and exit state |
| Cursor Attach | setup/hooks/MCP path | Existing Cursor workflow can invoke supported local tools | no cross-project leakage | supported attach path remains available | `attach_cursor_smoke` | same accepted tool result and exit state |
| Local MCP startup | MCP stdio server | Starts locally, advertises the configured bounded registry, handles shutdown | no unsolicited remote dependency; bounded messages | protocol changes are additive/versioned or migrated | `mcp_initialize`, `mcp_tools_list`, `mcp_shutdown` | exact schema/required fields; ordering deterministic |
| Local proxy | local proxy/setup path | Preserves supported request/response and tool-output shaping behavior | loopback/default-local; secret redaction; bounded payloads | no conversion into required managed relay | `proxy_roundtrip`, `proxy_failure` | native response semantics exact; p95 overhead bound below |
| `ctx_read full` | MCP/CLI/Engine embedding | Returns exact requested source subject to policy and bounds | PathJail, symlink/reparse containment, secret policy | explicit full remains explicit full | `read_full` | byte equality after declared framing |
| `ctx_read lines` | MCP/CLI/Engine embedding | Returns requested valid windows with stable line identity | same containment and bounds | accepted range syntax retained or migrated | `read_lines`, `read_lines_multi` | byte/line equality |
| `ctx_read signatures` | MCP/CLI/Engine embedding | Returns stable language-aware structural signatures | parser input bounded; recovery retained | no silent replacement with product planner | `read_signatures` | normalized structural equality |
| `ctx_read map` | MCP/CLI/Engine embedding | Returns bounded structural/dependency view | no out-of-root expansion | stable semantic fields and recovery | `read_map` | normalized semantic equality; size may improve |
| `ctx_read diff` | MCP/CLI/Engine embedding | Returns declared prior/current delta and exact recovery reference | cache/project isolation | repeat behavior remains explicit | `read_diff` | semantic delta equality |
| Repeat read/cache | repeated read in one local scope | Reuses valid unchanged material and invalidates stale source | cache keys include project/content/config scope | no cross-project hits; stale content never served as current | `repeat_read_cache`, `cache_invalidate` | hit/miss may change only with equal output and recorded reason |
| Search | `ctx_search`, CLI search | Bounded lexical/semantic/symbol retrieval over admitted project data | scope isolation; bounded indexing/query | query semantics remain documented | `search_regex`, `search_semantic` | expected set/rank contract; no unexplained omissions |
| Symbol/call structure | `ctx_symbol`, related structure tools | Resolves supported symbols and source locations | PathJail and parser bounds | stable exact references or versioned migration | `symbol`, `callgraph` | exact source locations for deterministic fixture |
| Shell/tool-output compression | `ctx_shell`, shell hook, embedding helper | Executes admitted local command and returns truthful bounded output/artifact reference | allowlist/admission, timeout, redaction, bounded capture | native exit status and failures preserved | `shell_compression`, `shell_timeout`, `shell_reject` | exit/status exact; shaped text semantically equivalent |
| Reference/recovery | context references and `ctx_expand`/recovery paths | Resolves compact output back to exact retained artifact/source | digest verification; scoped reference | no dangling accepted references | `recover_source`, `recover_artifact`, `recover_missing` | exact recovered bytes; fail closed on mismatch |
| Local evidence artifacts | Engine invocation/observation/receipt-linked paths | Records factual local operations without inventing quality claims | canonical bytes, integrity, bounded metadata | historical schemas remain verifiable or explicitly migrated | `evidence_emit`, `evidence_chain` | canonical bytes/digests exact |
| Offline verification | verifier CLI/library path | Verifies without producer, account, or Cloud and rejects tampering | fail closed; explicit trust state | supported historical fixtures keep their declared status | `offline_verify`, negative tamper/key/schema cases | zero false-accept tolerance |
| Rust in-process Engine embedding | `rust/crates/lean-ctx-sdk` façade | Embeds real Engine read/search/compression with isolated cache and safe builder defaults | PathJail on; throwaway state; write/exec opt-in | preserve as OSS Engine façade; naming may migrate | `engine_embed_read`, `engine_embed_repeat` | API migration documented; behavior parity exact |
| PathJail/source containment | Engine read/index/artifact paths | Rejects traversal, symlink/reparse escape and unsafe roots | fail closed on every platform | never commercialized or weakened | `pathjail_negative`, swap/relocation fixtures | zero escape tolerance |
| Secret protection | detection/redaction/input filters | Blocks or redacts declared secrets without exposing raw secret in diagnostics | no secret in logs, artifacts, cache, or error body | safety may strengthen; relaxation needs security approval | `secret_negative`, `redaction_output` | zero known-secret leakage tolerance |
| Bounded IO/process behavior | IO boundary, process guard, shell admission | Enforces declared size/time/process bounds and truthful failure | fail closed and no partial trusted publication | bounds may tighten only with compatibility evidence | `bounded_read`, `bounded_output`, `process_timeout` | zero bound bypass; explicit error changes only |
| Local hooks/session continuity | hooks and current `core/session/**` | Preserves coding-agent task/findings/decision/file continuity | project scope, safe persistence, bounded state | remains OSS Attach compatibility, not Product `ContextSession` | `session_restart`, `session_project_isolation` | semantic equality; storage migration reversible |

## Parity fixture suite

The extraction program must create a versioned fixture root conceptually named:

```text
OSS_BEFORE_SPLIT/
  manifest.json
  environment.json
  inputs/
  expected/
  security-negative/
  performance/
```

Minimum cases are the fixture IDs in the table plus:

```text
read_full read_lines read_map read_signatures read_diff
search symbol repeat_read_cache cache_invalidate
shell_compression recover_source recover_artifact
evidence_emit offline_verify
pathjail_negative secret_negative bounded_read process_timeout
attach_claude_smoke attach_codex_smoke attach_cursor_smoke
mcp_initialize proxy_roundtrip engine_embed_read session_restart
```

Each fixture pins Engine commit/version, OS, configuration, source digest,
request, normalized observable output, exit/failure class, artifact digests, and
security expectation. Secrets use synthetic canaries only. Fixtures must be
provider-free unless the case explicitly declares a local fake transport; a
mock cannot establish production SDK parity.

## Comparison protocol

For every extraction wave compare the last accepted pre-split Engine against
the Engine-only candidate on the same fixture and environment:

1. verify fixture and binary provenance;
2. run correctness and negative-security cases independently;
3. compare canonical bytes where deterministic and normalized semantics where
   platform framing differs;
4. compare artifact and recovery digests;
5. run warm/cold performance trials with declared count and aggregation;
6. classify every delta as intended, regression, or **UNVERIFIED**;
7. block integration on unexplained regression.

Correctness and security have no statistical tolerance. Deterministic output,
digests, explicit-mode behavior, exit state, and recovered bytes must match.
Performance gates on pinned fixtures are:

- deterministic read/search/cache: no p50 regression and at most 5% p95
  latency regression, with no added network/provider round trip;
- protocol encode/decode and artifact manifests up to 64 KiB: at most 10% p95
  regression; larger payloads remain out of band;
- inactive Context Kernel Attach hook: at most 2 ms and 1% CPU p95 per tool
  call;
- unspecified performance-only metrics: review at `max(10%, 5 ms)` p95 or 10%
  peak-memory/output-volume regression.

Exceeding a threshold requires a written cause, owner, accepted budget and
rollback. A threshold is a review trigger, not permission to degrade or relax
safety limits.

## Change and deprecation policy

- No extraction change removes a protected supported entry point in the same
  wave.
- A replacement ships first with dual fixtures and a documented rollback.
- Deprecation names affected users, notice window, telemetry/evidence source,
  successor, security impact, and last compatible release.
- Existing OSS Attach semantics may be frozen and maintained without accepting
  new SDK product semantics.
- A failing parity or security fixture blocks cleanup even if the SDK slice
  passes.
- `OSS_NOT_PRESERVED` implementation may be removed without a replacement when
  reachability is absent, public compatibility is not promised, SemVer is
  satisfied and safe-removal prerequisites pass.
- Fixtures assert observable behavior, security and versioned wire contracts;
  they never pin private module paths, type names or internal architecture.

## Exit gate

An extraction wave exits only when the Engine-only suite passes, the SDK slice
passes independently, every intentional difference is documented, and no
license, source-history, repository, or Cloud dependency was changed implicitly.
