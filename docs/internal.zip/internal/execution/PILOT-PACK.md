# Pilot Pack — Agent Tuning Sprint

Parent: GitLab #1254. Live rehearsal (#1270) stays open; this pack does not wait on it.

Completes the missing customer-pilot artifacts from CONTRADICTIONS.md #4
and v1.0: qualification, data boundary, SOW, acceptance, report, no-go.

| Artifact | Path |
|---|---|
| Offer / SOW | [SPRINT-ONE-PAGER.md](SPRINT-ONE-PAGER.md) |
| Qualification + outreach | [SPRINT-OUTREACH.md](SPRINT-OUTREACH.md) |
| Operator runbook | `examples/sprint-poc/RUNBOOK.md` |
| Human scorecard | `examples/sprint-poc/quality-scorecard.md` |
| Report template | [PILOT-REPORT-TEMPLATE.md](PILOT-REPORT-TEMPLATE.md) |
| Harness | `examples/sprint-poc/` |

## Data boundary (default)

- Workload: approved fixture or non-production commit in the manifest.
- Artifacts: hashes, IDs, summaries. No raw prompts or full source in the shareable bundle unless the customer opts in locally.
- BYOK: customer provider key never typed in a shared terminal, never written into receipts.
- Stop if redaction or data class is not approved.

## Acceptance

A Sprint is accepted only when all are true:

1. Same agent, same pinned manifest, two arms.
2. Automated quality gate recorded for both arms.
3. Named human reviewer completed the scorecard.
4. Treatment cheaper **only if** both arms passed automated + human gates.
5. Customer or joint operator ran offline verify on the bundle.
6. Written continuation: continue / narrower retry / no-go.

## No-go (any one is enough)

- Quality fail on either arm
- Missing provider usage
- Manifest/model/agent hash mismatch between arms
- Data class violated
- Customer cannot verify the bundle without Thinkery
- No named continuation owner or date

## Integrity

No synthetic cost, cache, or quality. Money fields: `provider-reported`, `estimated`, or `unavailable`.
