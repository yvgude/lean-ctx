# Pilot report — Agent Tuning Sprint

Fill after both arms and human review. Do not invent numbers.

## Identifiers

| Field | Value |
|---|---|
| Customer | |
| Workload / manifest hash | |
| Agent / version hash | |
| Model, provider | |
| Kit / profile | |
| Baseline run dir | |
| Treatment run dir | |
| Report date | |

## Quality

| Gate | Baseline | Treatment |
|---|---|---|
| Automated expected-findings | PASS / FAIL | PASS / FAIL |
| Human scorecard (relevance, correctness, actionable) | | |
| Reviewer | | |

Savings claim allowed? **yes / no** (yes only if both columns passed)

## Measured usage (copy from receipts; label provenance)

| | Baseline | Treatment | Provenance |
|---|---|---|---|
| Provider input tokens | | | provider-reported / unavailable |
| Provider output tokens | | | |
| Cached tokens | | | |
| Cost | | | provider-reported / estimated / unavailable |

## Verification

- Offline verify of treatment receipt: pass / fail
- Tamper copy rejected: pass / fail / not run

## Recommendation

Continue / narrower retry / no-go

Limitations (required):

## Sign-off

| Role | Name | Date |
|---|---|---|
| Customer technical owner | | |
| Thinkery operator | | |
