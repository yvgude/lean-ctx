# LeanCTX Production SDK Value Contract

> **Classification:** Binding product-value and extraction acceptance contract
>
> **Audited source:** `github/main@2c7d0044302d50af8d218a041b45726ad710757c`

## Product promise

The BSL 1.1 Production SDK turns explicit Apache Engine mechanisms into a
maintained context system inside a customer-owned agent or AI-native product.

```text
customer host → Production SDK → public Engine Protocol → Apache Engine
```

The host owns task execution, model, prompts, tools, retries, orchestration,
permissions, business logic, UX, and customer relationship. The SDK owns what
context should reach the next step and how that context evolves.

> **The Engine makes context mechanisms possible. The SDK makes them practical
> to depend on in production.**

## Stable lifecycle and primitives

The supported lifecycle is:

```text
Select → Shape → Reuse → Recover
```

The initial public product surface contains only:

| Primitive | Maintained responsibility |
| --- | --- |
| `ContextSession` | Scoped lifecycle/state machine for one task or run, including restart, abort, degradation, freshness, and compatibility state. |
| `ContextSource` | Source identity, scope, trust/freshness metadata, snapshot/recovery relationship, and host-facing source contract. |
| `ContextView` | Bounded task-fit representation linked to exact source and declared shaping operation. |
| `ContextPlan` | Explicit, deterministic record of SDK selection/shaping intent, budgets, exclusions, policy and degradation—not an Engine optimizer return type. |
| `ContextReceipt` | Canonical SDK evidence projection linking lifecycle intent to factual Engine observations without inventing quality. |

Serialization alone does not satisfy these primitives. The SDK must own their
state transitions, invariants, error behavior, compatibility, fixtures,
migrations, and documentation.

## Maintained product responsibility

### Lifecycle

- maps host events into Select → Shape → Reuse → Recover;
- keeps source/view identity and lineage coherent across a session;
- applies explicit budget, trust, freshness, reuse, recovery, and degradation
  policy;
- invalidates stale views and makes recovery state observable;
- preserves streaming, retry, cancellation, abort, and restart semantics;
- never requires Cloud for correctness.

### Developer experience

- clean install and one obvious entry path;
- small conceptual surface with typed IDs and stable errors;
- useful defaults without founder-only configuration;
- progressive configuration rather than a policy maze;
- reference application, API documentation, troubleshooting, and deterministic
  local fixtures;
- install-to-first-useful-Receipt measured in hours or days, not weeks.

### Host/framework integration

- one supported framework adapter and one native custom-host Embed path for the
  first production release;
- explicit lifecycle mapping rather than intercepting unrelated host control;
- native output, exceptions, tool results, streaming, retries, cancellation,
  and tracing preserved;
- adapter versions and capability limits declared;
- unsupported frameworks use the same Embed contract, not bespoke internal
  Engine imports.

### Evidence

- one canonical SDK `ContextReceipt` linked to Engine invocation,
  observation, measurement, failure, artifact, and recovery references;
- measured, calculated, estimated, reconciled, unavailable, and accepted
  outcome states remain distinct;
- quality comparison hooks require a declared baseline and threshold;
- offline verification and factual Engine evidence remain usable without SDK
  or Cloud lock-in;
- receipts never imply universal quality or savings.

### Compatibility and release

- published Engine×SDK support matrix;
- versioned public Engine Protocol fixtures and SDK contract fixtures;
- additive migration where possible, explicit deprecation windows otherwise;
- stable error taxonomy with retry/degradation guidance;
- reproducible build/release provenance, dependency policy, vulnerability
  ownership, security reporting, and rollback;
- no reliance on unpublished root-crate internals.

### OEM and LeanCTX Inside

- stable embeddable API beneath the customer's product-owned agent/runtime;
- documented downstream packaging and update responsibility;
- customer retains product, UX, telemetry choices, data boundary, and customer
  relationship;
- redistribution follows approved BSL/OEM terms and never makes Cloud required;
- SDK upgrades do not force adoption of unrelated LeanCTX products.

## Buy-versus-build burden removed

A customer can build on the Apache Engine. Choosing not to buy means becoming
the permanent owner of:

- session/source/view/plan/receipt semantics and state machines;
- candidate construction and context strategy;
- freshness, reuse, recovery, trust, budgets, and degradation policy;
- adapters, streaming, retries, cancellation, and error preservation;
- evidence projection and quality-comparison linkage;
- Engine compatibility, migrations, release provenance, and security updates;
- integration fixtures, documentation, on-call ownership, and production
  support.

The SDK wins by reliably removing that burden, not by hiding safe reads,
search, compression, cache, recovery, or evidence facts.

## Engine boundary

The SDK consumes explicit versioned mechanisms. Engine retains secure source
resolution, bounded views/search, compression, token/cost primitives, local
cache, exact recovery, capability execution, content-addressed artifacts,
factual invocation/observation/measurement/failure, and local security.

The SDK must not depend on:

- private `lean_ctx::core::*` types;
- current OSS coding-session internals as Product `ContextSession`;
- process-global learned context weights;
- CLI/MCP presentation heuristics as canonical planning;
- Cloud identity, tenant, fleet, rollout, billing, or cross-customer learning.

## Hard product tests

> **After unused or historical SDK-like implementation leaves the Engine, the
> BSL SDK must still represent genuine maintained lifecycle responsibility,
> not artificial scarcity.**

Required answer: **yes**. SDK value remains lifecycle, planning semantics,
freshness/reuse, recovery policy, adapters, host/framework correctness,
evidence projection, compatibility, migrations, stable errors, premium DX,
OEM/embedded contracts and supported release responsibility. It does not come
from merely moving existing functions behind another license.

> **A few thin wrappers over the Engine must not reproduce the complete
> supported Production SDK experience.**

The difference must be genuine maintained product responsibility, not
artificial Engine degradation.

The SDK fails this contract if any of these are true:

- a customer can reproduce the supported lifecycle with trivial call-through
  wrappers and no durable state/policy/compatibility ownership;
- the SDK merely renames existing Apache structs;
- Product `ContextPlan` delegates strategy to hidden Engine globals;
- the adapter loses native streaming, retry, exception, or tool semantics;
- compatibility depends on root internals rather than Engine Protocol;
- evidence cannot link intent to factual Engine observations;
- production correctness requires Cloud;
- safe Engine mechanisms are removed to manufacture scarcity.

## First-release acceptance

The Production SDK is releasable only when all are true:

1. one real Engine-backed vertical slice, not a mock Runtime;
2. all five primitives and lifecycle transitions have contract fixtures;
3. one maintained framework path and one native Embed path pass clean-machine
   integration;
4. streaming, retry, error, abort, restart, degradation, freshness, reuse, and
   recovery cases pass;
5. canonical Receipt links SDK intent to Engine facts and verifies offline;
6. Engine×SDK matrix, migration, deprecation and rollback are published;
7. OSS Preservation Contract passes independently;
8. security/dependency/license/provenance/release gates pass;
9. repository, namespace, BSL parameters, OEM, contributor, security, and
   release owners are approved;
10. at least one capable design partner chooses this maintained product over a
    self-build and can integrate without founder-only setup.

## Success evidence

- install-to-first-useful-Receipt;
- integration code/configuration and founder assistance;
- accepted quality under declared context/budget changes;
- reuse, recovery, lineage, and evidence coverage;
- clean upgrade across supported Engine/SDK versions;
- explicit buy-versus-build decision won;
- retention, second workflow/agent, or downstream embedded deployment;
- production license or OEM commitment.

Cloud usage, raw token reduction, repository stars, and wrapper count do not by
themselves satisfy this contract.
