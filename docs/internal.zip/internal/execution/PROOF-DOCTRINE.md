# LeanCTX Proof Doctrine

> **Classification:** Canonical evidence doctrine

## Measure. Compare. Verify.

**Status:** Canonical internal doctrine

**Audience:** Product, engineering, sales, customer success, benchmark partners,
and any team publishing a LeanCTX performance or quality claim.

**Purpose:** Establish the conditions under which LeanCTX may describe an
efficiency result as observed, compared, or verified.

---

## 1. The commitment

LeanCTX is a context-performance layer for existing agents.

It makes context decisions explicit, measurable, reusable, and versionable.

That position creates a proof obligation.

We do not ask customers to accept an efficiency claim because a dashboard is
attractive, a benchmark is persuasive, or a result was repeated in a demo.

We show what the agent consumed.

We compare like with like.

We verify that the result remained useful and that its evidence is authentic.

This is the LeanCTX Proof Doctrine:

> **Measure. Compare. Verify.**

The doctrine is our formal method for turning context-efficiency work into a
defensible result.

It is designed to be more rigorous than a compression counter.

It is also designed to be useful to advanced teams that already operate their
own agent harnesses.

The result is not merely a lower number.

The result is a scoped, reproducible, reviewable claim with a receipt chain.

---

## 2. Why LeanCTX needs a proof doctrine

Raw compression is not performance proof.

A smaller prompt may be cheaper while producing a worse answer.

A lower token count may reflect a changed task, a different repository state,
a missing tool call, a cache hit, or a lower-quality model response.

An impressive percentage can therefore be true as arithmetic and false as a
decision-quality claim.

LeanCTX must prove the whole performance path:

1. what the agent actually received and used;
2. what changed between the baseline and the treatment;
3. whether task quality held at the declared floor; and
4. whether another party can inspect and validate the evidence.

The doctrine protects customers from misleading optimization.

It protects benchmark partners from invalid comparisons.

It protects LeanCTX from claims that cannot withstand procurement, engineering,
or security review.

It supports the product promise to reduce context overhead, preserve quality,
and version context performance across workloads.

---

## 3. The three verbs

### 3.1 MEASURE

Measure what the agent actually consumed and what the run actually produced.

Do not substitute a prompt-size estimate for provider usage when provider usage
is available.

Do not substitute a requested tool plan for a tool-execution record.

Do not substitute an assumed cache hit for an observed cache result.

For every recorded run, measurement captures the applicable facts below.

#### Provider usage

- Provider and endpoint.
- Model identifier and, where available, model revision.
- Input, output, reasoning, cached, and billed usage units.
- Provider-reported cost or the declared price schedule used to calculate cost.
- Request count, retry count, and failure count.
- Latency measurements when latency is within the claim scope.
- Provider-side cache behavior when the provider exposes it.

#### Context and cache behavior

- Context bytes and tokens sent on each request.
- Context source or retrieval path.
- Reused, newly sent, omitted, and deduplicated context where measurable.
- Cache policy, cache key scope, and cache-hit or cache-miss outcome.
- Compression or representation policy applied by LeanCTX.
- Any fallback, truncation, budget enforcement, or context rejection.

#### Tool behavior

- Tools available to the agent.
- Tools actually invoked.
- Tool input and output digests or permitted redacted equivalents.
- Tool-call count, errors, timeouts, and retries.
- Tool policy, permissions, and sandbox configuration.
- Any human intervention or out-of-band action.

#### Workload and outcome

- Task identifier and immutable task definition.
- Repository, data, and dependency snapshot identifiers.
- Starting commit and resulting change set.
- System instructions, agent configuration, and runtime version.
- Timeout, budget, and execution constraints.
- Automated checks and their results.
- Human-review decision and reviewer rubric when required.
- Declared quality contract and final pass or fail state.

Measurement records facts.

Measurement alone does not establish that LeanCTX caused an improvement.

### 3.2 COMPARE

Compare a baseline and treatment under the same declared workload.

The baseline is the control context path.

The treatment is the LeanCTX context path being evaluated.

The comparison must answer one narrow question:

> Under the same task and constraints, what changed when the declared
> LeanCTX treatment replaced the declared baseline?

The comparison is invalid when material differences are not controlled,
declared, or justified.

#### Matched workload rule

Baseline and treatment must use the same, or demonstrably equivalent:

- task specification and acceptance criteria;
- starting commit and repository snapshot;
- fixture, input data, and dependency state;
- model, provider, and model revision where available;
- system prompt, agent policy, and role instructions;
- tool set, tool versions, permissions, and environment;
- timeout, budget, retry policy, and concurrency policy;
- quality contract and evaluation rubric; and
- execution protocol, including trial selection and stopping rules.

If an item cannot be matched, the result must name the difference.

If that difference can affect the outcome, the result cannot be called a
matched comparison.

#### Fair comparison rule

The treatment may change only the context strategy and its explicitly declared
dependencies.

Changing the model, task, tool permissions, quality bar, or evaluation method
at the same time creates a confounded result.

A confounded result may be useful for product exploration.

It may not be presented as an attributable LeanCTX saving.

#### Repetition rule

When a workload is stochastic, one favorable run is insufficient.

The protocol must declare the trial count, seed policy where available,
aggregation method, excluded-run rule, and stopping rule before promotion.

Report the distribution or each trial when it materially changes the reading of
the result.

Never select only the best treatment run or worst baseline run.

### 3.3 VERIFY

Verify two independent properties:

1. the treatment preserved the declared quality threshold; and
2. the evidence and methodology support the claimed result.

Verification is stronger than observing an outcome and stronger than running a
side-by-side benchmark.

It asks whether a skeptical reviewer can reach the same conclusion without
trusting the presenter.

#### Quality verification

Every comparison declares a quality floor before execution.

The floor contains the automated gate, human gate, or both that the workload
requires.

Examples of automated gates include:

- required test suite passes;
- build, lint, format, type, or static-analysis checks pass;
- security or policy checks pass;
- acceptance assertions pass; and
- no declared critical regression occurs.

Examples of human gates include:

- change correctness against a written rubric;
- code-review approval;
- task-completion review;
- safety, usability, or policy review; and
- comparative assessment when automated checks cannot observe the outcome.

The floor is not satisfied by a treatment that costs less but fails the task.

The floor is not satisfied by a human reviewer who does not have the declared
rubric or evidence required for the review.

#### Evidence verification

The evidence must show provenance, integrity, and linkage.

Receipts must be canonical, complete for their claim scope, signed by the
declared signer, and verifiable with the corresponding public key.

The receipt chain must bind execution facts to the resulting savings claim.

The evidence bundle must preserve file digests, receipt references, method
declaration, quality results, and verification material.

An offline verifier must be able to reject altered, incomplete, malformed, or
wrongly signed evidence.

Verification must fail closed.

An unverifiable receipt is not evidence of a verified result.

#### Methodology verification

The methodology must be known, not implied.

It must declare:

- the hypothesis and claim scope;
- baseline and treatment definitions;
- workload identity and matching constraints;
- model, tools, cache policy, budget, and timeout;
- measurements and calculation formulas;
- quality floor and evaluation procedure;
- trial, aggregation, exclusion, and stopping rules;
- redaction policy and its effect on reproducibility; and
- evidence-bundle and verifier version.

Another qualified party must be able to reproduce the protocol from the
declaration, subject to access-controlled data and valid redaction boundaries.

---

## 4. The proof ladder

LeanCTX uses three claim states.

The state describes the strength of the evidence, not the desirability of the
number.

| State | Meaning | Permitted statement | Not yet established |
| --- | --- | --- | --- |
| **Observed** | A run directly recorded a measurement. | “This run observed X units/cost/time.” | Attribution, fairness, or general applicability. |
| **Compared** | A declared baseline and treatment were evaluated on a matched workload. | “In this matched workload, treatment used X% less than baseline.” | Cryptographic evidence validity and full independent verification. |
| **Verified** | A matched comparison passed the quality floor and a valid, reproducible evidence chain. | “This scoped saving is verified under the declared method.” | Universal or future savings beyond the stated scope. |

The ladder is directional:

> **observed → compared → verified**

Each promotion preserves the lower-level evidence and adds new requirements.

No claim may skip a rung.

No presentation may use a higher rung’s language for a lower rung’s evidence.

### 4.1 Observed

An observed result is a measurement from a specific execution.

It requires an execution record with enough context to interpret the number.

It may reveal a promising optimization.

It does not prove that the optimization caused the number.

It does not prove that quality held.

It does not prove that another workload will show the same behavior.

Observed claims must name the run scope.

Example:

> Observed: on run `R`, the treatment sent fewer context tokens than the
> baseline estimate under the recorded configuration.

### 4.2 Compared

A compared result has a declared baseline and treatment with a matched workload.

It requires measurement on both sides and a comparison method that identifies
material differences.

It may state the measured delta for the stated task, model, tools, and
constraints.

Compared does not mean independently auditable or cryptographically proven.

Compared does not waive the quality requirement for promotion to verified.

Example:

> Compared: across the declared five-turn workload and matched constraints,
> the treatment calculated lower API cost than the baseline.

### 4.3 Verified

A verified result is the only state permitted to use the phrase
“verified saving” or equivalent proof language.

It requires all of the following:

1. complete measurement records for baseline and treatment;
2. a matched workload declaration and comparison record;
3. a quality contract declared before result promotion;
4. successful automated and human gates required by that contract;
5. canonical execution and savings receipts linked in a receipt chain;
6. valid signatures under the declared signing policy;
7. an evidence bundle with integrity digests and required artifacts;
8. successful fail-closed verification by the declared verifier; and
9. a reproducible methodology declaration that names the scope and limits.

If any required condition is missing, the result is not verified.

It may still be observed or compared if it satisfies the lower standard.

Example:

> Verified: under methodology `M`, on workload `W` at commit `C`, the LeanCTX
> treatment reduced calculated API cost by `S%` while meeting quality contract
> `Q`; receipt bundle `B` passes verifier `V`.

---

## 5. What qualifies as a verified saving

A verified saving is a scoped, positive delta between the declared baseline
and treatment that has completed the proof ladder.

It is never a generic product attribute.

For a cost claim, the default calculation is:

```text
saving_pct = (baseline_cost - treatment_cost) / baseline_cost × 100
```

The calculation must declare what `cost` includes.

Examples include provider-billed cost, calculated API cost under a named price
schedule, or total execution cost including tools.

Do not combine these denominators without saying so.

For a context claim, declare the unit precisely:

- provider-reported input tokens;
- serialized context bytes;
- uncached prompt tokens;
- billed tokens;
- context assembly time; or
- another explicitly defined unit.

“Token savings” is ambiguous unless the token category is named.

For a latency claim, distinguish wall-clock execution time, provider latency,
context-assembly latency, and time-to-accepted-output.

A verified saving must satisfy all of these conditions:

- The baseline denominator is non-zero and measured.
- Baseline and treatment use the declared matched workload.
- The treatment outcome satisfies the declared quality floor.
- The metric is measured or calculated from declared source data.
- The formula, rounding rule, and aggregation method are declared.
- Negative trials, failures, retries, and exclusions are handled by the
  predeclared protocol.
- The evidence bundle covers the result being reported.
- The receipt signatures and chain validate successfully.
- The result names its task, scope, model, configuration, and methodology.

When a saving is reported as a range, the range must follow the declared
aggregation method.

When a saving is reported as an average, report the trial count and treatment
of failures.

When a saving is reported from a single deterministic workload, say so.

When only calculated API cost is available, call it calculated API cost.

Do not relabel calculated API cost as customer invoice savings.

---

## 6. Quality is a gate, not a footnote

LeanCTX optimizes the context path.

It does not optimize away the task.

Every verified comparison therefore has a quality contract.

The quality contract answers five questions:

1. What must be true for the task to count as complete?
2. Which checks are automated?
3. Which checks require a human decision?
4. What result fails the workload even if the savings metric improves?
5. Who may approve an exception, and how is it disclosed?

Baseline and treatment must satisfy the same quality contract.

A stricter treatment gate is allowed only when it is declared and does not hide
a lower baseline standard.

A change in quality contract creates a new comparison cohort.

Quality is not inferred from shorter output, green logs alone, or reviewer
enthusiasm.

Quality is verified by the declared gates.

If the quality signal is incomplete, the claim remains observed or compared.

---

## 7. Receipts are proof objects

LeanCTX evidence is not a screenshot archive.

It is a linked record designed for verification.

The existing evidence architecture supplies the proof objects below.

| Evidence object | Doctrine role | Required for verified saving |
| --- | --- | --- |
| `ExecutionReceipt` | Records a concrete execution, its configuration, provenance, usage, and outcome. | One or more for each baseline and treatment execution. |
| `SavingsReceipt` | States the calculation that relates measured baseline and treatment results. | One for each promoted savings claim. |
| Receipt chain | Links executions, savings calculation, and checkpoints in order. | Must be complete across the claim scope. |
| `EvidenceBundle` | Packages receipts, artifacts, file digests, chain anchors, and signing material. | Must cover the claim and validate as a bundle. |
| Local signing key and public key | Establish signer identity and receipt integrity. | Signature must validate under the declared policy. |
| Offline verifier | Independently validates canonical form, digests, signatures, and linkage. | Must pass; invalid evidence fails closed. |

The receipt architecture is the mechanism.

The Proof Doctrine is the rule for interpreting the mechanism.

Receipts without matched comparison are execution evidence, not a verified
saving.

A savings calculation without a passing quality gate is an economic observation,
not a verified saving.

A passing quality gate without valid receipts is a quality result, not a
verified saving.

### 7.1 Receipt requirements

For doctrine purposes, a receipt used in a verified claim must be:

- canonically encoded according to the receipt specification;
- complete for the fields required by its schema and claim scope;
- uniquely identified without duplicate or ambiguous identifiers;
- linked to its predecessor or declared anchor where a chain applies;
- signed with the declared algorithm, key identifier, and encoding;
- verifiable with the recorded public key or trusted key reference; and
- preserved with content digests in the corresponding evidence bundle.

Unknown required fields, invalid encodings, non-canonical forms, duplicate IDs,
or signature ambiguity are verification failures.

The verifier must not silently repair, guess, or accept a fallback format for a
verified claim.

### 7.2 Evidence-bundle requirements

The evidence bundle must include, directly or by immutable reference:

- the methodology declaration;
- workload manifest and task definition;
- baseline and treatment configuration manifests;
- execution receipts;
- savings receipt;
- quality-gate outputs and human-review record where applicable;
- relevant source, result, and artifact digests;
- receipt-chain anchors;
- signing metadata and public-key material; and
- verifier identity, version, and result.

Redaction is permitted when it is declared and preserves the ability to validate
the claim’s non-sensitive facts.

If redaction prevents validation of a material matching constraint, the result
cannot be promoted to verified for external audiences.

---

## 8. Methodology is part of the result

The benchmark number is not complete without its method.

Every public or customer-facing comparison must carry a methodology statement.

The short form must identify:

- result state: observed, compared, or verified;
- metric and unit;
- workload and commit or immutable snapshot;
- baseline and treatment;
- model and tool constraints;
- quality floor;
- trial and aggregation rule; and
- evidence-bundle or report reference.

The full form must contain the protocol necessary for reproduction.

The full form must include material limitations.

Material limitations include unavailable provider usage, changed model revisions,
redacted inputs, non-deterministic tools, limited trial counts, and exclusions.

No limitation may be hidden in an appendix when it can change the interpretation
of the main claim.

This directly supports versioned performance.

A context configuration is not merely “better.”

It is better, worse, or unchanged under a named method and workload version.

---

## 9. What LeanCTX never claims

The following claims are prohibited unless a narrower, fully supported form is
used instead.

### 9.1 No universal savings claims

We never claim that LeanCTX saves a fixed percentage for every customer, model,
agent, repository, task, or workload.

We do not turn a benchmark range into a product guarantee.

We do not extrapolate one workload’s percentage to an organization’s total
spend without an explicit workload model and validation.

### 9.2 No quality-improvement claim without proof

We never claim that compression improves answer quality, coding quality, safety,
or task success merely because a treatment used less context.

We only claim a quality outcome that the declared quality contract measured and
verified for the stated scope.

### 9.3 No attribution without a fair comparison

We never attribute a lower cost or token count to LeanCTX when model, task,
tools, constraints, cache behavior, or quality bar changed materially and the
effect cannot be separated.

### 9.4 No “verified” label for unverified evidence

We never call a result verified because it appears in a dashboard, a CSV, a
presentation, a manually edited report, or an unsigned log.

We never call a signed result verified if canonical validation, chain linkage,
or fail-closed offline verification has not passed.

### 9.5 No silent denominator changes

We never compare provider cost to total cost, cached tokens to all input tokens,
or an aggregate treatment result to a single baseline run without disclosure.

### 9.6 No cherry-picking

We never select favorable runs after observing results while omitting failures,
retries, rejected outputs, or negative trials contrary to the declared protocol.

### 9.7 No durability claim beyond the evidence

We never imply that a verified result persists after a model revision, agent
change, repository change, tool-policy change, or workload change unless it has
been re-measured and re-verified in that new scope.

### 9.8 No false independence

We never describe an internal review as independent third-party validation.

We name the reviewer role, evidence access, and review method honestly.

---

## 10. Claim language

Use language that matches the proof state.

| Proof state | Approved language | Disallowed shortcut |
| --- | --- | --- |
| Observed | “Observed in this recorded run …” | “LeanCTX saves …” |
| Compared | “In the declared matched workload …” | “LeanCTX consistently saves …” |
| Verified | “Verified under methodology … and quality contract …” | “Proven for all workloads …” |

Every quantitative statement must attach its scope nearby.

Preferred form:

> In the declared matched workload, using real provider calls and the recorded
> model, tools, and five-turn protocol, the LeanCTX treatment reduced
> calculated API cost by `X–Y%` while meeting the stated quality contract.

Verified form:

> This saving is verified for the declared workload and methodology: matched
> baseline and treatment receipts, quality gates, and evidence bundle passed the
> named offline verifier.

Do not remove “calculated,” “declared,” “matched,” or “scoped” when those words
are necessary for truthfulness.

---

## 11. Reporting protocol

Before publishing, selling, or using a result as product proof, complete this
checklist.

### Measure checklist

- [ ] Provider usage source is recorded.
- [ ] Model and available revision identifier are recorded.
- [ ] Context and cache behavior are recorded.
- [ ] Tools available and tools invoked are recorded.
- [ ] Task, commit, fixtures, configuration, and constraints are recorded.
- [ ] Outcome and quality-gate inputs are recorded.

### Compare checklist

- [ ] Baseline and treatment are declared.
- [ ] Task and acceptance criteria match.
- [ ] Commit, repository state, data, and dependencies match.
- [ ] Model, instructions, tools, and permissions match.
- [ ] Budget, timeout, retries, and cache policy are matched or disclosed.
- [ ] Trial and aggregation protocol is declared before promotion.
- [ ] Material differences are either absent or explicitly scoped out.

### Verify checklist

- [ ] Quality contract was declared.
- [ ] Required automated gates passed.
- [ ] Required human gate passed with the declared rubric.
- [ ] `ExecutionReceipt` records cover both sides.
- [ ] `SavingsReceipt` uses declared inputs and formula.
- [ ] Receipt chain is complete and anchored.
- [ ] Signatures, canonical encoding, and file digests validate.
- [ ] `EvidenceBundle` contains required proof artifacts.
- [ ] The declared offline verifier passed fail closed.
- [ ] Public wording matches the earned proof state.

If any verified checklist item is unchecked, remove “verified” from the claim.

---

## 12. Mapping to the LeanCTX evidence system

The doctrine maps product evidence into one promotion path.

```text
Execution activity
    ↓
ExecutionReceipt + usage/context/tool facts
    ↓
Matched workload declaration
    ↓
Baseline/treatment comparison + SavingsReceipt
    ↓
Quality contract: automated gate + human gate
    ↓
Receipt chain + EvidenceBundle + signatures
    ↓
Offline verifier passes fail closed
    ↓
Verified saving, scoped to the declared methodology
```

This mapping also defines what each product layer must do.

| Product/evidence layer | Responsibility under the doctrine |
| --- | --- |
| Runtime and wrapper | Emit reliable execution facts without inventing unobserved values. |
| Context profile and cache layer | Identify the declared treatment and the context policy actually applied. |
| Benchmark harness | Enforce matched workloads and preserve baseline/treatment manifests. |
| Quality evaluator | Apply declared automated and human quality gates. |
| Receipt subsystem | Produce canonical, linked execution and savings receipts. |
| Bundle subsystem | Package artifacts, digests, chain anchors, and signing material. |
| Offline verifier | Reject malformed, altered, incomplete, or untrusted evidence. |
| Reporting surface | Show only the proof state actually earned and retain methodology limits. |

The V-ZUG validation makes this capability strategically important.

Advanced teams may build a local harness.

LeanCTX must provide portability, versioned performance, evidence, continuous
tuning, and maintenance economics that a one-off harness does not reliably
provide.

This doctrine makes evidence a product capability rather than a sales artifact.

---

## 13. Governance and change control

Proof is versioned because the system being measured is versioned.

A new model version, provider behavior, repository commit, tool version, cache
policy, prompt, task, quality rubric, or verifier version may change the result.

Each material change requires a new comparison cohort.

Prior verified results remain historically valid only for their recorded scope.

They do not automatically promote a successor configuration.

Methodology changes must be explicit, reviewed, and linked to new evidence.

Evidence-schema, signing-policy, and verifier changes must preserve a clear
compatibility statement.

If an older evidence bundle cannot pass the current verifier, report its status
according to the verifier and schema that actually validated it.

Never silently upgrade an old result to verified under a newer policy.

When evidence is corrected, preserve the correction trail.

Do not overwrite a published result without recording what changed, why it
changed, and whether the proof state changed.

---

## 14. Decision rule

Use this rule whenever a LeanCTX result is discussed:

1. **Did we measure the actual run?**
   - If no, do not make a quantitative performance claim.
2. **Did we compare a matched baseline and treatment?**
   - If no, the result can be observed but not compared.
3. **Did the same declared quality floor hold?**
   - If no, do not promote the result to verified.
4. **Do canonical receipts, signatures, bundle, and offline verification pass?**
   - If no, do not call the result verified.
5. **Is the methodology declared and reproducible?**
   - If no, reduce the claim to the highest state the evidence supports.

When uncertain, choose the lower proof state.

Precision is more valuable than a larger claim.

---

## 15. Canonical doctrine statement

LeanCTX does not sell a promise that every agent will become cheaper.

LeanCTX provides the context-performance layer that lets teams find, test, and
prove efficiency improvements in their own agent workloads.

We measure what the agent consumed.

We compare the same task under the same constraints.

We verify that quality held and that the evidence is valid.

> **Measure. Compare. Verify.**

That is how LeanCTX turns context efficiency into defensible performance.
