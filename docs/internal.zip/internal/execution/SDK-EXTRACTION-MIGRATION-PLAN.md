# LeanCTX SDK Extraction Migration Plan

> **Classification:** Incremental execution plan; no code move authorized
>
> **Audit baseline:** `github/main@2c7d0044302d50af8d218a041b45726ad710757c`
>
> **Current state:** Wave A revalidated; P2 closure is the sole runtime gate in
> this task. Remote default-branch SHA is verified; candidate gates are local.

## Governing cut line

```text
optional private Cloud
  org governance, fleet history, learned cross-deployment decisions
                  ↓ published SDK contracts only
separate BSL 1.1 Production SDK
  ContextSession/Source/View/Plan/Receipt, lifecycle, adapters,
  freshness/reuse/recovery policy, compatibility, migrations, DX, OEM
                  ↓ public versioned Engine Protocol
Apache-2.0 Engine
  safe source/search/view/compression/cache/recovery/capability mechanisms,
  factual invocation/observation/measurement/failure and OSS Attach surfaces
```

Dependency direction is one way. Cloud is never a local correctness dependency.

## Global safety rules

- No Big Bang rewrite or repository move.
- Historical Apache rights remain; removal from a future Engine and source
  reuse in BSL are separate decisions.
- Only accepted default-branch state is migration input.
- One owner per file/worktree; every wave has rollback.
- Engine-only parity and SDK vertical-slice gates are independent and both
  required.
- Product lifecycle semantics stop growing in Engine after the protocol freeze;
  existing OSS Attach behavior remains compatible.
- Safety mechanisms remain Apache.
- Cleanup and renaming follow the Engine Decommission Candidates authority,
  after measured reachability, applicable deprecation and behavioral parity.

## Wave A — Ownership truth

**Deliverables**

- `ENGINE-SDK-SOURCE-OWNERSHIP-MATRIX.md`;
- `OSS-PRESERVATION-CONTRACT.md` and fixture plan;
- `PRODUCTION-SDK-VALUE-CONTRACT.md`;
- `APACHE-TO-BSL-PROVENANCE-REVIEW.md`;
- `ENGINE-SDK-SOURCE-AUDIT-REPORT.md`.

**Exit**

- every required active source family has one primary target class;
- high-risk mixed modules have explicit seams and consumers;
- the exact audited commit is recorded;
- Legal/provenance uncertainty is named;
- no runtime code, repository, source location, or license changed.

**Rollback:** remove documentation-only artifacts; product behavior is
unchanged.

## Wave B — Real vertical slice before split

**Objective:** prove the dependency boundary through the real Engine.

1. complete the integrated canonical evidence gate;
2. choose one Preview host path and one native Embed path;
3. make Python Preview call a versioned local Runtime/Engine operation rather
   than mock lifecycle routes;
4. preserve native streaming/retry/error behavior;
5. link one Preview lifecycle intent to factual Engine observation and offline
   verification;
6. run OSS parity fixtures unchanged.

**Entry:** P2 evidence chain accepted on default branch.

**Exit:** clean-machine `ContextSession → Source/View → Plan → Engine →
Receipt → Recover` succeeds with no Cloud and no internal test adapter as the
primary proof.

This is the real P3 dependency proof. Physical SDK extraction and repository
creation remain blocked until it passes; P2 completion alone does not authorize
either.

**Rollback:** retain current Preview compatibility path and disable the new
adapter; no public Engine contract removed.

## Wave C — Freeze minimal public Engine Protocol

**Objective:** publish the smallest credible mechanism/fact contract derived
from the accepted P1/P2 path.

Protocol families:

```text
identity/version
source resolve/snapshot/identity
explicit bounded view/shape
bounded search/retrieval
explicit local cache primitives
exact source/artifact recovery
bounded capability execution
EngineInvocation / EngineObservation / EngineMeasurement / EngineFailure
artifact/source/output digest and recovery reference
```

Explicitly exclude future canonical ownership of Product `ContextSession`,
integration depth, performance policy, Kit activation, Workspace/Tenant/org,
host adapter lifecycle, quality strategy, rollout, billing, and Cloud
governance.

Existing Apache protocol structs are not deleted merely because they are
outside the new family. The integrated non-v1 freeze classifies the current
`auto_routing`, `control_plane`, `fleet_control`, `rollout` and `value_share`
surfaces as experimental and prevents new consumers. Define migration and
deprecation first; removal may follow no earlier than the manifest's declared
release gate.

**Exit:** version, canonical fixtures, unknown-field behavior, error/failure
semantics, support matrix, deprecation policy, and Engine implementation pass.

**Rollback:** keep prior protocol version and dispatch; new version remains
additive until consumers pass.

## Wave D — Create BSL 1.1 Production SDK repository

No repository is created until all entry gates are approved:

- repository visibility/access/admin owner;
- registry namespace and recovery owner;
- BSL Change Date, Change License, Additional Use Grant, and permitted-use
  boundary;
- OEM/redistribution and pricing terms;
- contributor DCO/CLA policy;
- security reporting, vulnerability ownership, release signing/provenance and
  incident owner;
- Apache-to-BSL provenance disposition for every reused source group.

Create only repository controls, contract fixtures, build/release skeleton and
the minimal vertical slice. Do not copy the monolith.

**Exit:** independent build, license review, branch/release controls, security
ownership, package namespace, Engine compatibility test, and no private Engine
imports.

**Rollback:** repository remains unpublished/private and Engine unchanged.

## Wave E — Migrate canonical product semantics incrementally

Order:

1. Product typed IDs and stable error taxonomy;
2. `ContextSource` and `ContextView` with Engine source/recovery links;
3. clean Product `ContextSession` state machine—not `core/session/**` renamed;
4. Product `ContextPlan` intent/policy—not Engine compiler return type renamed;
5. SDK `ContextReceipt` projection over factual Engine observations;
6. freshness/reuse/recovery/budget/degradation policy;
7. one framework adapter and native Embed;
8. Profile/Kit product semantics only after open mechanism/format seams exist;
9. compatibility, migrations, docs and OEM APIs.

For each semantic unit choose one provenance disposition: approved reuse,
clean reimplementation behind the contract, or continued Apache compatibility
input. Dual-run fixtures compare behavior before canonical ownership changes.

**Exit:** SDK Value Contract and real design-partner path pass; Engine parity
still passes.

**Rollback:** route the Preview adapter to the last accepted SDK version; no
Engine mechanism is removed.

## Wave F — Preserve and freeze OSS compatibility

- keep current CLI/MCP/proxy/hooks and Rust Engine embedding;
- retain coding-agent session journal, context gate, and read heuristics where
  required for accepted Attach behavior;
- label them OSS Attach compatibility, not Product SDK primitives;
- reject new Product lifecycle dependencies from these modules;
- keep open formats/parsers/verifiers where interoperability benefits the
  ecosystem;
- quarantine Cloud, fleet, billing, marketplace, remote relay, broad A2A and
  autonomous-learning growth.

**Exit:** pre/post OSS fixture comparison passes on supported platforms;
compatibility labels and owners are published; no deliberate degradation.

## Wave G — Cleanup only after proof

Allowed only after:

- Engine-only OSS parity and security-negative suites pass;
- Production SDK vertical slice and compatibility matrix pass;
- at least one design-partner integration works without founder-only setup;
- reachability report identifies unused compatibility surfaces;
- deprecation notice, successor, rollback and Legal/provenance disposition are
  approved.

Then, and only then:

- narrow misleading root exports/default features;
- conceptually rename Rust `lean-ctx-sdk` to an Engine embedding name;
- deprecate/freeze historical protocol/control-plane models;
- split mixed mechanism/lifecycle modules at their declared seams;
- remove unreachable legacy code through separate reviewed changes.

The decommission map is the cleanup authority. It protects supported behavior,
not historical module identity; `OSS_NOT_PRESERVED` code needs no behavioral
replacement when reachability, SemVer, security and removal prerequisites are
satisfied.

## Source-family migration prerequisites

| Source family | Before any canonical move |
| --- | --- |
| Python Preview | Real Engine transport, public-semantic inventory, fixture parity, provenance disposition, supported adapter decision. |
| Node Research package | Preserve MIT/import compatibility, usage/reachability evidence, deprecation notice and Legal review before any source reuse. |
| Rust Engine façade | Preserve Apache embedding users, public API migration/rename plan, Engine Protocol dependency instead of root internals. |
| Protocol crate | New narrow Engine family, golden fixtures, historical-contract support/deprecation map. |
| Context Kernel | Separate deterministic mechanisms and OSS Attach bridges from plan/session/policy/learning semantics; stop process-global strategy state. |
| Compiler/field | Pure explicit-input optimizer contract and tests; SDK owns candidate construction, weights/strategy and lifecycle meaning. |
| Session | Preserve coding-agent journal/storage; build Product `ContextSession` cleanly with separate IDs/state machine. |
| Profiles | Extract Engine configuration schema from SDK performance/context policy; retain safety defaults open. |
| Kits/packages | Open format/parser/integrity decision; SDK activation/composition/session lifecycle contract; freeze remote registry. |
| Evidence | Engine facts and offline verifier remain open; SDK projection/version/support defined. |
| Cloud/research | No new public consumer; private owner/data/tenant/operations gate before later migration. |

## Completion gate

Physical extraction is complete only when a later agent can execute the source
matrix without re-deciding product architecture, all applicable parity/value/
provenance gates pass, and the Apache Engine is at least as useful and safe as
the accepted pre-split baseline.
