# Production SDK Decision Record

> **Classification:** Canonical product and release decision gate
>
> **Status:** Product strategy DECIDED; named implementation/legal parameters
> remain PENDING. This record does not itself create a repository or publish a
> package.

## Decided product strategy

| Decision | Status | Approved value |
| --- | --- | --- |
| Separate Production SDK repository | **DECIDED** | Required; independently built and released downstream of public Engine Protocol. |
| Primary Thinkery product | **DECIDED** | LeanCTX Production SDK. |
| Production SDK license family | **DECIDED** | Business Source License 1.1 (BSL 1.1). |
| Engine license | **DECIDED** | Apache-2.0; public, strong, and independently useful. |
| Cloud relationship | **DECIDED** | Separate private/commercial, optional, and later. |
| Product boundary | **DECIDED** | Engine mechanisms; SDK customer-facing lifecycle and production semantics. |

These decisions must not be reopened through a blanket “commercial scope
pending” statement.

## Pending parameters

| Parameter | Status | Required evidence |
| --- | --- | --- |
| Repository visibility/access and administrative owner | **PENDING** | Repository URL, visibility, admins, branch/provenance rules. |
| Package namespace and registry owner | **PENDING** | Distribution/import names, registry account, recovery owner. |
| BSL Change Date | **PENDING** | Approved date in license text. |
| BSL Change License | **PENDING** | Approved post-change license. |
| BSL Additional Use Grant | **PENDING** | Exact grant or explicit none. |
| Evaluation/development and production/free-use boundary | **PENDING** | Exact permitted use and threshold, if any. |
| OEM redistribution/commercial terms | **PENDING** | Contract and support boundary. |
| Pricing and enterprise exceptions | **PENDING** | Approved commercial schedule. |
| Contributor DCO/CLA process | **PENDING** | Written contribution policy. |
| Security reporting and release policy | **PENDING** | Reporting channel, response policy, provenance and vulnerability ownership. |

All applicable pending parameters require Product/Legal/Release/Security
approval before production publication or commercial commitments. They do not
delay documentation of BSL 1.1 as the decided license family.

## Fixed product boundary

1. Keep the Engine Apache-2.0 and independently useful.
2. Create the BSL 1.1 SDK in a separate repository.
3. Keep `ContextSession`, `ContextSource`, `ContextView`, `ContextPlan`,
   `ContextReceipt`, lifecycle policy, adapters, compatibility, and migrations
   in the Production SDK.
4. Share only versioned public Engine Protocol schemas and golden fixtures.
5. Keep Cloud optional and absent from local SDK correctness.
6. Do not move SDK product semantics into Engine for implementation convenience.

## First release exits

- One coherent Select → Shape → Reuse → Recover lifecycle.
- One supported host/framework path and one native Embed path.
- One public Engine Protocol and one canonical Receipt.
- Engine×SDK compatibility matrix, migrations, deprecation window, stable
  errors, release provenance, and deterministic verification.
- Clean-machine install and end-to-end integration without a mock Runtime or
  founder-only setup.
- Security, dependency, secret, provenance, license, and vulnerability checks.
- Product, Legal, Release, and Security approve every applicable pending value.

## Preview migration boundary

`packages/python-lean-ctx` remains Preview/migration input. The existing Rust
`lean-ctx-sdk` remains an Engine embedding facade. Neither becomes the
Production SDK merely through renaming or license text; contracts graduate only
after real Runtime parity, compatibility, security, and release exits pass.

## Sign-off

| Function | Strategy decision | Pending-parameter completion |
| --- | --- | --- |
| Product | SDK-first and separate repository: **DECIDED** | `PENDING` |
| Legal | BSL 1.1 license family: **DECIDED** | BSL parameters: `PENDING` |
| Release | Independent SDK release required: **DECIDED** | Namespace/policy: `PENDING` |
| Security | Separate security ownership required: **DECIDED** | Process/SLA: `PENDING` |
