# E1 — Website implementation plan

## Execution status — 2026-08-21

v2 Homepage / SDK / Enterprise / Benchmark pages are implemented on `deploy` (GitLab #1255–#1259 closed). Still open: #1260 (old pages, navigation, footer, SEO, docs IA) and #1261 (production deploy). Never push `deploy` to GitHub.


## 0. Decision record

- Target ref: GitLab-only `deploy` branch.
- Do not create, push, fetch, or compare against a GitHub branch.
- Runtime baseline: Node `>=22.12.0`.
- Framework baseline: Astro `^6.0.8`.
- This is a rebuild of the public product narrative, not an incremental reskin.
- The source of truth for product wording is `docs/internal/execution/WEBSITE-REDESIGN.md`.
- The source of truth for visual decisions is `docs/internal/reference/VISUAL-BRAND-GUIDELINES.md`.
- Preserve Astro’s existing localization, canonical URL, RTL, validation, and journey tooling.
- Do not add a CSS framework, component framework, chart library, or runtime animation dependency.
- Use semantic HTML and CSS before adding client-side JavaScript.

## 1. Evidence collected from `deploy`

- `website/package.json` declares Node `>=22.12.0`.
- `website/package.json` uses Astro `^6.0.8`.
- Package scripts include `build`, `validate`, `validate:i18n`, `validate:manifest`, and `validate:positioning`.
- `website/src/pages` contains 464 tracked route files, mostly locale-generated variants.
- `website/src/components` contains 48 tracked files.
- `website/src/layouts` contains four tracked files.
- `website/src/page-templates` contains 73 tracked files.
- Root `website/src/pages/index.astro` imports and renders `IndexPageV2`.
- `website/src/pages/enterprise/index.astro` imports and renders `EnterprisePage`.
- `website/src/pages/docs/index.astro` is the existing documentation hub.
- `website/src/pages/docs/getting-started.astro` renders `DocsGettingStartedPage`.
- `BaseLayout.astro` owns locale handling, localization helpers, positioning, and page chrome.
- `DocsLayout.astro` already exists and must remain the documentation shell.
- Existing global styling lives at `website/src/styles/global.css`.
- Existing shared chrome includes `website/src/components/Header.astro` and `Footer.astro`.
- Existing `/pricing` has root plus 17 locale route files.
- Existing old cloud route is `website/src/pages/account/cloud.astro`.
- Its template is `website/src/page-templates/AccountCloudPage.astro`.
- No tracked website-source text currently matches `Dyno`, `Chiptuner`, `AutoTune`, or `Auto-Tune`.
- Therefore do not fabricate a deletion for those names; add a release gate that prevents their return.

## 2. Copy contract

- Transcribe product copy literally; do not summarize, translate, optimize, or make up claims.
- Preserve capitalization, em dashes, percentage ranges, CTA labels, and qualifying language.
- Preserve the evidence qualifier: results are workload-specific and methodology-dependent.
- Keep the terms `context`, `evidence`, `receipt`, `baseline`, `treatment`, and `verified` consistent.
- Do not use the retired vehicle-tuning narrative in headings, metadata, URLs, image alt text, or structured data.
- Keep product names as `LeanCTX`, `LeanCTX SDK`, `LeanCTX Benchmark`, and `LeanCTX Profiles` where specified.
- Treat copy changes after transcription as content-review changes, not implementation changes.

### 2.1 Exact source ranges to transcribe

| Destination | Exact source range | Handling |
| --- | --- | --- |
| Homepage navigation through final CTA | `WEBSITE-REDESIGN.md:21-323` | Literal source order; see section 7. |
| Homepage footer copy | `WEBSITE-REDESIGN.md:324-334` | Merge with current legal/i18n footer only where no conflict. |
| `/sdk` full page | `WEBSITE-REDESIGN.md:335-469` | Literal source order; see section 8. |
| `/enterprise` full page | `WEBSITE-REDESIGN.md:470-579` | Literal source order; see section 9. |
| `/benchmark` full page | `WEBSITE-REDESIGN.md:580-703` | Literal source order; see section 10. |
| Developer campaign material | `WEBSITE-REDESIGN.md:704-839` | Do not put on the four primary routes without content approval. |
| `/docs` | No dedicated page-copy block in redesign document | Reorganize existing documentation; do not invent product claims. |

### 2.2 Verbatim evidence copy that must remain intact

> In controlled five-turn coding-agent workloads using real OpenAI API calls, a tested LeanCTX treatment reduced calculated API cost by approximately 79–86% under the declared methodology. Results are workload-specific; read the methodology before applying them to your system.

- Use that sentence in the homepage evidence section and benchmark published-result framing.
- Do not turn `79–86%` into a universal promise.
- Link `declared methodology` or the surrounding evidence CTA to the benchmark methodology section.
- Keep `calculated API cost`, `treatment`, `workload-specific`, and `methodology` as written.

## 3. Visual system to implement

### 3.1 Token files

- Create `website/src/styles/redesign-tokens.css`.
- Create `website/src/styles/marketing-grid.css`.
- Import both once from `website/src/styles/global.css` after existing reset/font declarations.
- Do not duplicate raw color literals in page templates or component-scoped CSS.
- Use custom properties with semantic aliases, not one-off visual names in component code.

### 3.2 Color tokens

```css
:root {
  --color-carbon: #0A0A0A;
  --color-bone: #F2F0E9;
  --color-signal-orange: #FF4B00;
  --color-graphite: #171718;
  --color-steel: #2A2A2D;
  --color-reference-gray: #8B9099;
  --color-concrete: #B8BDC3;
  --color-ice-blue: #A8B8C7;
  --color-verified: <muted-green-approved-by-brand>;
  --color-failed: <muted-red-approved-by-brand>;
}
```

- `--color-carbon` is the primary black/background token.
- `--color-bone` is the primary paper/light-background token.
- `--color-signal-orange` is intervention, action, selected-path, and primary-CTA color.
- `--color-verified` is reserved for verified pass, receipt verification, and passed quality gates.
- `--color-reference-gray` is reference data, baseline data, secondary labels, and quiet rules.
- `--color-ice-blue` is technical reference only, never a competing CTA color.
- Keep green and red semantic-only; neither is a primary brand accent.
- Do not use an unapproved green hex from memory: obtain the muted-green approval before setting `--color-verified`.
- Until approved, use the existing accessible verification value through one semantic alias only.
- Do not use pure white as the default light surface; use bone.
- Do not use orange for decorative borders, noninteractive illustrations, or all chart series.
- Pair every color-only status with text, iconography, or pattern.

### 3.3 Typography tokens

```css
:root {
  --font-display: "Aeonik", Arial, sans-serif;
  --font-sans: "Aeonik", Arial, sans-serif;
  --font-mono: ui-monospace, "SFMono-Regular", Menlo, Monaco, Consolas, monospace;
  --tracking-eyebrow: 0.08em;
  --leading-display: 0.96;
  --leading-body: 1.5;
  --leading-mono: 1.45;
}
```

- Use Aeonik for display headings, section headings, navigation, and editorial body text.
- Use mono only for code, data labels, receipts, metric labels, commands, and technical annotations.
- Do not use monospace for multi-paragraph marketing body copy.
- Load Aeonik only from an existing licensed asset path or approved font delivery mechanism.
- If no licensed webfont asset exists, retain the fallback stack and create a licensing follow-up; do not silently add a third-party font CDN.
- Define fluid display sizes with `clamp()` and explicit minimum/maximum values.
- Define a distinct, smaller uppercase or tracked eyebrow style.
- Keep navigation/body type readable at 200% browser zoom.

### 3.4 Engineering grid

```css
:root {
  --grid-columns: 12;
  --grid-gutter: clamp(1rem, 1.5vw, 1.5rem);
  --grid-margin: clamp(1rem, 4vw, 5rem);
  --content-max: 90rem;
  --space-unit: 0.5rem;
}
```

- Use a 12-column CSS Grid at desktop widths.
- Align headings, charts, cards, CTAs, and rules to the same named column lines.
- Collapse deliberately to six/eight columns at tablet and four columns at mobile.
- Preserve the same left and right visual rails across all marketing pages.
- Use multiples of the spacing unit for gaps, padding, and vertical rhythm.
- Avoid arbitrary pixel positioning, transform-based layout correction, and unequal near-miss gutters.
- Give full-bleed bands an inner `.marketing-grid` rather than placing content directly in a viewport-width element.
- Make code/evidence modules span exact whole-column ranges.

### 3.5 Surface, line, and motion rules

- Use tight radii or square corners according to existing brand components; do not introduce soft SaaS cards.
- Use fine graphite/concrete rules for structure and orange only for active/selected state.
- Use framed/bracket treatments to mark systems, evidence, and receipts.
- Prefer data-like labels and deliberate whitespace over decorative illustrations.
- Respect `prefers-reduced-motion`; static diagrams must carry all information.
- Limit motion to progressive reveal, path progression, or count-free state changes.
- Do not autoplay a large video, 3D hero, or canvas animation.

## 4. Exact file-change manifest

### 4.1 Create

- `website/src/styles/redesign-tokens.css` — semantic color, type, spacing, z-index, and motion tokens.
- `website/src/styles/marketing-grid.css` — 12-column container, named spans, responsive grid collapse.
- `website/src/layouts/MarketingLayout.astro` — shared metadata, marketing body wrapper, header/footer composition.
- `website/src/content/marketing-copy.ts` — typed literal transcription of the four route copy blocks.
- `website/src/components/marketing/Hero.astro` — semantic hero title, lead, proof slot, CTAs, optional visual slot.
- `website/src/components/marketing/Section.astro` — eyebrow, heading, accent phrase, lead, grid span props.
- `website/src/components/marketing/EvidencePanel.astro` — methodology-aware evidence statement and receipt/benchmark slots.
- `website/src/components/marketing/ReceiptCard.astro` — stable receipt metadata, result, quality, and verification status.
- `website/src/components/marketing/CodeBlock.astro` — accessible pre/code wrapper, filename/language label, copy-free rendering.
- `website/src/components/marketing/Cta.astro` — primary/secondary CTA semantics and arrow treatment.
- `website/src/components/marketing/ReceiptVisualization.astro` — visual receipt timeline/record used by homepage and benchmark.
- `website/src/components/marketing/BenchmarkComparison.astro` — baseline/treatment/reference comparison with accessible table fallback.
- `website/src/components/marketing/IntegrationDepthDiagram.astro` — attach/wrap/embed diagram with textual equivalent.
- `website/src/components/marketing/CapabilityPipeline.astro` — select/compress/reuse/recover/observe pipeline; feature-flagged/not mounted initially.
- `website/src/page-templates/SdkPage.astro` — `/sdk` composition.
- `website/src/page-templates/BenchmarkPage.astro` — `/benchmark` composition.
- `website/src/page-templates/DocsHubPage.astro` — simplified docs information architecture.
- `website/src/pages/sdk.astro` — stable `/sdk` route entry.
- `website/src/pages/benchmark.astro` — stable `/benchmark` route entry.

### 4.2 Modify

- `website/src/styles/global.css` — import token/grid files and remove conflicting page-global marketing styles only.
- `website/src/layouts/BaseLayout.astro` — register any approved font preload and keep locale/canonical/RTL behavior intact.
- `website/src/components/Header.astro` — replace primary marketing navigation labels/targets with the new route set.
- `website/src/components/Footer.astro` — replace product links, retain legal/licensing/locale behavior, add benchmark/evidence route.
- `website/src/page-templates/IndexPageV2.astro` — replace current internal composition with redesigned homepage sections.
- `website/src/page-templates/EnterprisePage.astro` — replace legacy content composition with the new enterprise narrative.
- `website/src/pages/enterprise/index.astro` — keep the thin route entry; change only if template import path changes.
- `website/src/pages/docs/index.astro` — render `DocsHubPage` while retaining existing docs metadata and locale helpers.
- `website/src/pages/docs/getting-started.astro` — ensure its first CTA and breadcrumb remain reachable from the new docs hub.
- `website/src/i18n/*` relevant marketing dictionaries — add literal new strings or explicit English-only policy.
- `website/src/lib/*` route/navigation/manifest data that currently mentions pricing or cloud — remove stale entries.
- `website/public/*` only for approved Aeonik files or static diagram assets; no raster art is required for phase one.

### 4.3 Delete after inbound-link audit

- `website/src/pages/pricing.astro`.
- `website/src/pages/ar/pricing.astro`.
- `website/src/pages/bn/pricing.astro`.
- `website/src/pages/de/pricing.astro`.
- `website/src/pages/es/pricing.astro`.
- `website/src/pages/fr/pricing.astro`.
- `website/src/pages/hi/pricing.astro`.
- `website/src/pages/id/pricing.astro`.
- `website/src/pages/it/pricing.astro`.
- `website/src/pages/ja/pricing.astro`.
- `website/src/pages/ko/pricing.astro`.
- `website/src/pages/pl/pricing.astro`.
- `website/src/pages/pt/pricing.astro`.
- `website/src/pages/ru/pricing.astro`.
- `website/src/pages/tr/pricing.astro`.
- `website/src/pages/uk/pricing.astro`.
- `website/src/pages/vi/pricing.astro`.
- `website/src/pages/zh/pricing.astro`.
- `website/src/pages/account/cloud.astro`.
- `website/src/page-templates/AccountCloudPage.astro` when no remaining route imports it.

### 4.4 Do not delete blindly

- Do not delete documentation pages, docs journeys, integrations, or API reference pages during this redesign.
- Do not delete locale infrastructure to remove pricing routes.
- Do not delete `BaseLayout.astro`, `DocsLayout.astro`, Header, Footer, or i18n utilities.
- Do not delete a Dyno/Chiptuner/AutoTune file because none is present in deploy source today.
- Remove those terms only if the pre-deploy content audit finds an actual inbound content, redirect, or generated artifact.

## 5. Shared component contracts

### 5.1 `Hero.astro`

- Props: `eyebrow`, `title`, `accent?`, `lead`, `primaryCta?`, `secondaryCta?`, `visual?`, `proof?`.
- Render one `<h1>` only.
- Render CTAs as real links, never clickable `<div>` elements.
- Place copy on named grid spans; visual occupies a complementary, not overlapping span.
- Use `aria-describedby` when proof text qualifies the title claim.
- Allow a compact variant for `/sdk`, `/enterprise`, and `/benchmark`.

### 5.2 `Section.astro`

- Props: `id`, `eyebrow?`, `heading`, `lead?`, `tone`, `children`, `headingSpan?`, `bodySpan?`.
- Render a native `<section aria-labelledby>`.
- Generate no heading level implicitly; the caller supplies `h2`/`h3` hierarchy.
- Support bone, carbon, and transparent surfaces only.
- Align top/bottom rules to grid columns.

### 5.3 `EvidencePanel.astro`

- Props: `label`, `statement`, `methodologyHref`, `status`, `children`.
- Render the methodology link adjacent to, not hidden behind, the claim.
- Use orange for the treatment/active trace, gray for baseline/reference, green only for a verified outcome.
- Include a screen-reader summary before decorative data treatments.
- Never hard-code unqualified savings claims in the component.

### 5.4 `ReceiptCard.astro`

- Props: `workload`, `baseline`, `treatment`, `costDelta`, `qualityResult`, `receiptId?`, `verifiedAt?`.
- Show field labels in mono and values in readable type.
- Show verification status in text (`Verified`, `Reference`, `Failed`) plus color.
- Do not show a live timestamp unless it is part of real receipt data.
- Keep receipt identity deterministic and privacy-safe.

### 5.5 `CodeBlock.astro`

- Props: `language`, `filename?`, `code`, `caption?`.
- Escape code content; do not inject it as raw HTML.
- Preserve whitespace, wrapping policy, and keyboard scroll access.
- Add a copy button only if it can be built accessibly without a heavy client bundle.
- Do not use a code block to simulate an image or a data chart.

### 5.6 `Cta.astro`

- Props: `href`, `label`, `variant`, `external?`, `icon?`, `analyticsName?`.
- Variants: `primary`, `secondary`, `quiet`.
- Only `primary` gets signal orange fill or strong orange line treatment.
- Supply clear focus-visible styling and a minimum usable target size.
- Mark external destinations in accessible text if applicable.

## 6. New data visualizations and diagrams

### 6.1 `ReceiptVisualization.astro`

- Purpose: show an auditable benchmark receipt rather than a marketing dashboard.
- Structure: workload → baseline → treatment → quality result → verification record.
- Use HTML, inline SVG only where semantic labels are mirrored in DOM, and CSS grid.
- Pair visual path with an ordered list that carries the same sequence.
- Mount on homepage evidence and `/benchmark` receipt section.

### 6.2 `BenchmarkComparison.astro`

- Purpose: compare baseline, LeanCTX treatment, and optional reference with no deceptive scale.
- Required legend: orange = treatment; gray = reference/baseline; green = verified pass.
- Required fields: workload, run count if published, calculated API cost, quality outcome, methodology link.
- Include a visually available data table on narrow viewports and a screen-reader table at all widths.
- Do not infer values that the benchmark source does not publish.
- Mount on `/benchmark` and use a compact summary on the homepage.

### 6.3 `IntegrationDepthDiagram.astro`

- Purpose: explain Attach, Wrap, and Embed integration depths.
- Each depth has audience, insertion point, responsibility boundary, and next CTA.
- Use three aligned grid panels connected by a restrained rule/path, not a funnel graphic.
- Provide headings and body copy before any connector SVG.
- Mount on homepage and `/sdk`.

### 6.4 `CapabilityPipeline.astro`

- Purpose: visualize Select → Compress → Reuse → Recover → Observe.
- Create now for stable API and tokens.
- Do not mount until copy/design review confirms the illustration is needed.
- Provide a static ordered-list fallback.
- Keep this component free of runtime state and remote data.

## 7. Homepage `/`

### 7.1 Route and template

- Keep `website/src/pages/index.astro` as the thin root entry.
- Keep the entry’s `IndexPageV2` import if retaining the filename avoids unrelated route churn.
- Rebuild `website/src/page-templates/IndexPageV2.astro` around `MarketingLayout` and the new shared components.
- Source all visible text from `marketing-copy.ts`; no literal marketing sentence remains in template markup.
- Preserve current localized path helpers at CTA boundaries.

### 7.2 Navigation

- Replace old primary-product links with `/sdk`, `/enterprise`, `/benchmark`, and `/docs`.
- Use the exact navigation labels in `WEBSITE-REDESIGN.md`.
- Make the current page state visually and semantically apparent.
- Retain locale selector and accessible mobile navigation behavior.
- Remove pricing and cloud-dashboard links from all desktop/mobile/footer menus.

### 7.3 Hero

- Transcribe `WEBSITE-REDESIGN.md` homepage `Hero` block exactly.
- Use `Hero.astro` with a product/engineering visual, not a generic product screenshot.
- Pair the primary CTA with the exact secondary CTA from the source.
- Put any performance proof in the hero only if it appears in the source block.
- Keep the hero readable without the visual.

### 7.4 Six editorial sections

1. **The problem** — render `Read less noise`, `Carry forward useful state`, and `Recover with intent` exactly as sourced.
2. **What LeanCTX controls** — render Select, Compress, Reuse, Recover, Observe in source order.
3. **Integration depths** — render Attach, Wrap, Embed with `IntegrationDepthDiagram`.
4. **Evidence** — render Measure, Compare, Verify with `EvidencePanel` and compact `BenchmarkComparison`.
5. **Context profiles** — render the source block as the profile/operational-memory section, without unsupported feature embellishment.
6. **Product status and scale** — render LeanCTX SDK, LeanCTX Benchmark, LeanCTX Profiles, then the Scale close as one commercial closing band.

### 7.5 Evidence and product close

- Use the verbatim qualified benchmark statement in section four.
- Make `Explore the SDK` route to `/sdk`.
- Make `Explore Enterprise` route to `/enterprise`.
- Link benchmark proof to `/benchmark`.
- Preserve the source final homepage CTA and footer wording.
- Do not add logos, testimonials, customer counts, pricing, or dashboard promises that the copy source does not contain.

### 7.6 Homepage acceptance criteria

- One H1, six H2 section groups, and no skipped heading levels.
- All major edges align to named 12-column grid lines at desktop.
- The full page works with CSS and JavaScript disabled except nonessential motion.
- CTA destinations return 200 in the production build.
- Evidence wording matches the source byte-for-byte after normal Markdown/HTML whitespace normalization.
- No `/pricing` or `/account/cloud` link is emitted.

## 8. SDK page `/sdk`

### 8.1 Files

- Add `website/src/pages/sdk.astro`.
- Add `website/src/page-templates/SdkPage.astro`.
- Add an i18n route entry only through the repository’s existing generator/configuration pattern.
- Do not hand-copy 17 localized Astro route files.

### 8.2 Content order

1. Page hero.
2. The SDK’s job.
3. Core primitives: Select relevant context.
4. Core primitives: Compress without losing the task.
5. Core primitives: Reuse work already validated.
6. Core primitives: Recover original detail.
7. Core primitives: Inspect the path.
8. Choose an integration depth: Attach to a coding agent.
9. Choose an integration depth: Wrap a runtime loop.
10. Choose an integration depth: Embed in a custom system.
11. Local-first by design.
12. From SDK to evidence.
13. SDK final CTA.

### 8.3 Composition

- Use `Hero.astro` in compact technical mode.
- Use `CodeBlock.astro` for source-provided commands/examples only.
- Use `CapabilityPipeline.astro` only after the copy-review gate; otherwise use an ordered primitive list.
- Use `IntegrationDepthDiagram.astro` as the central page diagram.
- Use `EvidencePanel.astro` for the source `From SDK to evidence` transition.
- Point the final CTA to the literal source destination.
- Do not turn the SDK page into generated API reference; `/docs` owns reference navigation.

### 8.4 SDK acceptance criteria

- Every copy block is transcribed from source range `335-469`.
- All three integration depths appear in both visual and text form.
- Code examples retain selectable text and contrast.
- Page works at 320 CSS pixels with no horizontal scrolling.
- No claims about closed-source cloud operation, auto-tuning, or pricing appear.

## 9. Enterprise page `/enterprise`

### 9.1 Files

- Keep `website/src/pages/enterprise/index.astro` as the route entry.
- Rebuild `website/src/page-templates/EnterprisePage.astro` with new sections/components.
- Remove legacy translation keys only after the new strings are wired and validation is green.

### 9.2 Content order

1. Page hero.
2. The enterprise problem.
3. A common performance layer.
4. Give builders useful controls.
5. Give platform teams shared evidence.
6. Give leadership an adoption path.
7. Govern with evidence.
8. Adoption path, step 1: Start with one agent.
9. Adoption path, step 2: Establish a baseline.
10. Adoption path, step 3: Compare a treatment.
11. Adoption path, step 4: Reuse what works.
12. Enterprise final CTA.

### 9.3 Composition

- Make performance, repeatability, and governed adoption the visual priority.
- Use a four-step numbered adoption path, not a sales funnel.
- Reuse `ReceiptCard` and compact `BenchmarkComparison` to ground governance in evidence.
- Keep platform/leadership claims explicitly connected to source wording.
- Do not add unsupported SSO, fleet, compliance, air-gap, onboarding, success, or FAQ promises from the old template.
- Retain only technical/legal infrastructure required by BaseLayout and i18n.

### 9.4 Enterprise acceptance criteria

- Copy matches source range `470-579`.
- Adoption steps are keyboard readable in order without visual connectors.
- Evidence hierarchy never implies a guaranteed savings result.
- Final CTA is source-accurate and passes link validation.

## 10. Benchmark page `/benchmark`

### 10.1 Route replacement

- Add `website/src/pages/benchmark.astro` and `BenchmarkPage.astro`.
- `/benchmark` is the public evidence route and replaces the old `dyno` positioning concept.
- No current deploy source file or string uses Dyno; no Dyno route deletion is scheduled from unverified assumptions.
- If deployment has an external Dyno redirect, migrate it at the hosting/redirect layer after route audit.

### 10.2 Content order

1. Page hero.
2. Evidence process.
3. Measure.
4. Compare.
5. Verify.
6. What a benchmark records.
7. Workload.
8. Baseline.
9. Treatment.
10. Receipt.
11. Quality result.
12. Published result framing.
13. Who it is for: Developers.
14. Who it is for: Platform teams.
15. Who it is for: Engineering leaders.
16. Benchmark final CTA.

### 10.3 Composition

- Put methodology and quality evidence before the `79–86%` result sentence.
- Use `BenchmarkComparison` for baseline/treatment comparison.
- Use `ReceiptVisualization` and `ReceiptCard` for recorded evidence.
- Use `Section` for the three audiences; avoid persona illustrations.
- Expose a methodology anchor/route that can be cited from the homepage and enterprise page.
- State data scope and constraints alongside the result.
- Make all chart values available in DOM text/table form.

### 10.4 Benchmark acceptance criteria

- Copy matches source range `580-703`.
- Baseline, treatment, receipt, and quality result cannot be confused by color alone.
- Primary result is qualified in both visual and text presentation.
- Desktop and mobile table/diagram layouts retain the same data order.

## 11. Docs restructure `/docs`

### 11.1 Scope

- Keep `/docs` a learning and reference hub, not another marketing landing page.
- Preserve current content tree, journeys, integration content, and deep links.
- Replace hub emphasis with task-led paths aligned to Select, Compress, Reuse, Recover, and Observe.
- Keep `DocsLayout` as the documentation shell.

### 11.2 New hub order

1. Start here.
2. Install and connect.
3. Choose an integration depth.
4. Context primitives.
5. Evidence and benchmark methodology.
6. Profiles and sessions.
7. Tools and commands.
8. Journeys by task.
9. API/reference.

### 11.3 Implementation details

- Create `DocsHubPage.astro` using existing `docsTree`, tracks, facts, and localization helpers.
- Make `website/src/pages/docs/index.astro` a thin renderer of the new hub component.
- Retain the existing `/docs/getting-started/` destination for onboarding.
- Add a visible benchmark methodology entry point to `/benchmark` or its stable methodology anchor.
- Change card labels/descriptions only after content review; do not invent technical capability claims.
- Use plain cards/rules with the same token/grid system, but lower visual intensity than marketing pages.
- Ensure the docs search/navigation semantics remain unchanged if currently present.

### 11.4 Docs acceptance criteria

- Existing documentation URLs and locale paths continue to build.
- The hub provides a first action without hiding deep reference content.
- Marketing claims are not duplicated without qualification.
- Existing docs validation and coverage scripts pass.

## 12. Legacy narrative removal

### 12.1 Required removals

- Remove all pricing route files listed in section 4.3.
- Remove the account/cloud route and its template after link/import audit.
- Remove pricing/cloud navigation entries, sitemap entries, manifest entries, translation keys, and test expectations.
- Supply redirects only after the product owner selects a destination; likely options are `/enterprise`, `/benchmark`, or 410.
- Do not choose redirects silently because URL status has SEO and user-expectation consequences.

### 12.2 Required searches before merge

```sh
git grep -inE 'Dyno|Chiptuner|AutoTune|Auto-Tune' deploy -- website
git grep -inE 'pricing|account/cloud|cloud dashboard' deploy -- website
git grep -inE 'Dyno|Chiptuner|AutoTune|Auto-Tune|pricing|account/cloud|cloud dashboard' -- website
```

- The first command documents current baseline: no Dyno/Chiptuner/AutoTune source matches.
- The second inventories old narratives before the change.
- The third must return no unintended public-copy, route, navigation, or sitemap match after the change.
- Exclude historical changelog material only with an explicit comment explaining why it is non-public.

## 13. Implementation sequence

### Step 1 — Design tokens and base layout

- Create `redesign-tokens.css` and `marketing-grid.css`.
- Add imports to `global.css`.
- Add `MarketingLayout.astro`.
- Update `BaseLayout.astro` only for safe shared font/head behavior.
- Build Header/Footer navigation with new route targets.
- Build Hero, Section, EvidencePanel, ReceiptCard, CodeBlock, and Cta.
- Test one static fixture page before migrating copy.
- Exit criteria: tokens render, grid aligns, reduced-motion/focus styles work, no route breakage.

### Step 2 — Homepage

- Create typed homepage copy object by literal transcription.
- Rebuild `IndexPageV2.astro` in the six-section composition.
- Add ReceiptVisualization, BenchmarkComparison compact mode, and IntegrationDepthDiagram.
- Wire `/sdk`, `/enterprise`, `/benchmark`, and `/docs` CTAs.
- Visual-check desktop, tablet, and mobile.
- Exit criteria: homepage copy source audit and accessibility checks pass.

### Step 3 — `/sdk`

- Add route and `SdkPage.astro`.
- Transcribe source range `335-469`.
- Add technical primitive/integration composition.
- Confirm docs/getting-started routes remain the onboarding destination where source requires it.
- Exit criteria: integration diagram and code blocks have textual equivalents.

### Step 4 — `/enterprise` and `/benchmark`

- Rebuild existing `EnterprisePage.astro` from source range `470-579`.
- Add `/benchmark` and `BenchmarkPage.astro` from source range `580-703`.
- Share evidence/receipt components rather than duplicate chart logic.
- Add methodology anchors and cross-page links.
- Exit criteria: evidence claims are qualified and charts have data-table fallbacks.

### Step 5 — `/docs` and old-page removal

- Build DocsHubPage from existing docs data structures.
- Audit all inbound links to pricing/cloud before deletion.
- Obtain explicit redirect/410 decision for removed public URLs.
- Delete pricing locales and cloud route/template.
- Delete stale nav, sitemap, manifest, i18n, and test entries.
- Run legacy-term search gate.
- Exit criteria: no broken generated routes, no stale public links, redirect decision recorded.

### Step 6 — Verification and GitLab deploy

- Run the website build and all package validation scripts relevant to changed areas.
- Run accessibility smoke tests at 320px, 768px, 1024px, and wide desktop.
- Verify keyboard navigation, focus visibility, reduced motion, and color-independent statuses.
- Verify canonical/localized URLs, sitemap/manifest, and intended redirects.
- Review deployed preview on GitLab only.
- Merge/deploy through the GitLab deployment pipeline; never push a website branch to GitHub.

## 14. Parallel-work split

- Agent A: tokens, `MarketingLayout`, Header/Footer, shared component primitives.
- Agent B: homepage copy transcription and `IndexPageV2` composition.
- Agent C: SDK, Enterprise, Benchmark templates plus data diagrams.
- Agent D: docs hub, link inventory, i18n/manifest/sitemap cleanup, deleted-route redirect proposal.
- Integrator: resolves shared component APIs first, then performs final copy/visual/a11y/deploy checks.
- Do not let parallel agents independently alter `global.css`, Header, Footer, or `marketing-copy.ts` without ownership boundaries.

## 15. Test and review checklist

- `npm run build` succeeds under Node `>=22.12.0`.
- `npm run validate` succeeds.
- `npm run validate:i18n` succeeds.
- `npm run validate:manifest` succeeds.
- `npm run validate:positioning` succeeds.
- Run any existing docs-coverage and journey validation touched by `/docs` changes.
- Confirm generated locale routes do not reference deleted pricing pages.
- Confirm `Header.astro` and `Footer.astro` have no old pricing/cloud link.
- Confirm each new page has unique title, description, canonical URL, and one H1.
- Confirm source-copy diff contains no paraphrasing.
- Confirm all CTAs have meaningful accessible names.
- Confirm cards/diagrams expose information without color, hover, or animation.
- Confirm reduced-motion view has no missing content.
- Confirm 200% zoom and keyboard focus preserve layout/readability.
- Confirm no build artifact, development URL, or secret enters the branch.

## 16. Open decisions requiring owner approval

- Approved muted-green hex and failed-state red token.
- Aeonik webfont license/source, if not already shipped in deploy assets.
- Public redirect destination versus 410 for each removed pricing and cloud URL.
- Whether existing non-English marketing routes receive approved translations at launch or deliberately canonical English fallback.
- Exact benchmark methodology URL/anchor if it is not part of the initial `/benchmark` page.
- Whether `CapabilityPipeline` ships in phase one or remains implemented-but-unmounted.

## 17. Completion definition

- Four primary routes exist: `/`, `/sdk`, `/enterprise`, `/benchmark`.
- `/docs` is restructured without breaking existing documentation routes.
- Marketing copy is verbatim from the declared source ranges.
- Brand tokens/grid/components are shared rather than page-specific clones.
- Evidence presentation is qualified, accessible, and data-legible.
- Pricing/cloud old narrative is removed only after redirect authority and inbound-link audit.
- No public deploy artifact contains Dyno, Chiptuner, AutoTune, pricing, or cloud-dashboard language unless explicitly retained as non-public history.
- The GitLab deploy pipeline is green and no GitHub remote has been used.
