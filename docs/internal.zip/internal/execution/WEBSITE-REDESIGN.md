# LeanCTX Website Copy

**Status:** Internal target copy. It does not make a product surface available.  
**Audience:** Developers, AI platform teams, and enterprise engineering leaders  
**Brand hierarchy:** Context SDK → Select / Shape / Reuse / Recover → Evidence → Shared project context (Preview)

**Availability authority:** [Internal README](../README.md) and
[Product Architecture](../vision/PRODUCT-ARCHITECTURE.md). Any surface not marked
**Available** there must be labelled **Preview** or **Research** in public copy;
it must not appear as a purchasable or deployed product.

---

## Non-negotiable language rules

- Lead with concrete context behaviour, not undefined performance language, token
  savings, or model replacement.
- Describe LeanCTX as the Context SDK for AI agents.
- Keep the model and the agent framework in place; LeanCTX manages the context
  path routed through it.
- Name the four core actions: select, shape, reuse, and recover. Describe
  compression as one shaping operation, never as the product category.
- Present shared project context and handoffs as **Research** until a public
  contract earns **Preview** status; do not
  market the Agent Bus as orchestration.
- Use evidence-qualified language: measured, declared methodology, comparable workload, and quality held to the same task.
- Use product-status labels exactly: **Available**, **Preview**, and **Research**.
- Keep the evidence section headline exactly: **Measure. Compare. Verify.**
- Reserve the developer-campaign line in this document’s final section for campaign work only; it is not homepage copy.

---

# Homepage `/`

## Navigation

**Logo:** LeanCTX

**Primary navigation:** SDK · Docs · Research

**Utility link:** GitHub

**Primary navigation CTA:** Install LeanCTX

---

## Hero

**Eyebrow**

THE CONTEXT SDK FOR AI AGENTS

**Headline**

Give every agent a context system.

**Body**

LeanCTX selects, shapes, reuses, and recovers the project context your agent
needs—inside the agent loop you already own.

**Proof line**

Compare context overhead, cost, latency, and quality only on the same task with a
declared quality gate.

**Primary CTA**

Install LeanCTX

**Secondary CTA**

Build with LeanCTX — Preview

**Trust line beneath CTAs**

Apache-2.0 Engine · BSL 1.1 Production SDK · Local-first

**Hero visual labels**

Sources → select → shape → reuse → recover → model

**Hero visual caption**

Your framework runs the agent. LeanCTX manages its context path.

---

## Section: The problem

**Eyebrow**

THE CONTEXT PATH

**Headline**

Your agent can access everything. That does not mean it should load everything.

**Body**

Before an agent produces its next answer, it works from a constructed view of
files, tool output, history, decisions, and prior work. Most stacks let that
view accumulate by accident.

LeanCTX makes the context path explicit. It gives teams a place to control the information that reaches the model—and a way to see the effect of those decisions.

**Supporting cards**

### Read less noise

Reduce tool output and source material to the decision-critical signal.

### Carry forward useful state

Reuse validated context instead of rebuilding it on every turn.

### Recover with intent

Bring back the right detail when the task needs it, without returning to an unbounded prompt.

**CTA**

See how the SDK works

---

## Section: What LeanCTX controls

**Eyebrow**

THE CONTEXT SDK

**Headline**

Control the context path.

**Body**

LeanCTX sits between your agent’s work and the model call. It provides the primitives to select relevant material, compress it safely, reuse useful artifacts and recover source detail when needed.

**Capability list**

### Select

Set the retrieval and inclusion rules for the task at hand.

### Compress

Preserve decision-critical signal while removing repeated and irrelevant context.

### Reuse

Carry forward durable context artifacts across turns and workloads.

### Recover

Return to source material when a compressed representation is not enough.

### Observe

Record what entered the context path so performance decisions can be inspected and improved.

**CTA**

Explore the SDK

---

## Section: Integration depths

**Eyebrow**

ONE ENGINE. THREE WAYS IN.

**Headline**

Add context performance at the depth your agent needs.

**Body**

Start with the integration that fits today. Move deeper when you need more control; your agent and model choices remain yours.

### Attach

**For:** Existing coding agents

Add LeanCTX around the context your agent already reads and produces.

**CTA:** Integrate with your agent

### Wrap

**For:** Agent runtimes and tool loops

Place context controls around retrieval, tool output and model handoffs.

**CTA:** See runtime patterns

### Embed

**For:** Custom agent systems

Build context policy directly into the architecture with SDK primitives.

**CTA:** Build with the SDK

---

## Section: Evidence

**Eyebrow**

EVIDENCE, NOT ASSUMPTION

**Headline**

Measure. Compare. Verify.

**Body**

Context performance is only useful when it survives comparison. LeanCTX Benchmark runs a declared baseline and treatment against the same task, records the context and cost deltas, and keeps quality in the evaluation.

**Evidence steps**

### Measure

Capture the baseline: workload, model configuration, context overhead, cost and task outcome.

### Compare

Run the same task with a declared LeanCTX treatment. Keep the workload and evaluation criteria comparable.

### Verify

Inspect the receipt, methodology and quality result before you claim a gain.

**Benchmark proof block**

In controlled five-turn coding-agent workloads using real OpenAI API calls, a tested LeanCTX treatment reduced calculated API cost by approximately 79–86% under the declared methodology. Results are workload-specific; read the methodology before applying them to your system.

**Primary CTA**

Benchmark your agent

**Secondary CTA**

Read the methodology

---

## Section: Context profiles

**Eyebrow**

PERFORMANCE YOU CAN REUSE

**Headline**

Turn a measured context strategy into a profile.

**Body**

The best context path is not a one-off prompt trick. LeanCTX Profiles capture a tested configuration so a team can reuse, review and evolve it across comparable workloads.

**Status:** Research

**CTA:** Follow profile research

---

## Section: Product status

**Eyebrow**

PRODUCT STATUS

**Headline**

Build now. Measure next. Standardize over time.

### LeanCTX Engine

**Status:** Available · Apache-2.0

Use local context mechanisms through supported CLI, MCP, hooks and proxy paths.

**CTA:** Install the Engine

### LeanCTX Production SDK

**Status:** Preview / target · BSL 1.1

Build toward the maintained Select → Shape → Reuse → Recover lifecycle in a
customer-owned agent. Do not present the current Python Preview as a production
release.

**CTA:** Explore the SDK Preview

### LeanCTX Benchmark

**Status:** Preview

Compare a declared baseline and treatment on the same workload.

**CTA:** Benchmark your agent

### LeanCTX Profiles

**Status:** Research

Reuse tested context configurations across workloads.

**CTA:** Follow profile research

---

## Section: Scale

**Eyebrow**

FROM INDIVIDUAL AGENTS TO PLATFORM CAPABILITY

**Headline**

Make context performance an infrastructure capability.

**Body**

As agent use grows, context behavior becomes a systems concern. LeanCTX gives platform teams a common performance layer: controls developers can use, evidence teams can review and patterns organizations can standardize.

**CTA:** Explore Enterprise

---

## Final homepage CTA

**Headline**

Start where performance starts.

**Body**

Install the Context SDK, establish a baseline and improve the context path with evidence.

**Primary CTA:** Explore the Production SDK  
**Secondary CTA:** Install the Apache-2.0 Engine

---

## Footer

**Product:** SDK · Benchmark · Enterprise · Changelog  
**Developers:** Documentation · GitHub · Installation · Community  
**Company:** Thinkery AG · About · Contact  
**Legal:** Privacy · Terms · Imprint

Footer note: Apache-2.0 Engine · BSL 1.1 Production SDK · Local-first

---

# SDK `/sdk`

## Page hero

**Status:** Preview / target Production SDK contract

**Eyebrow**

LEANCTX SDK

**Headline**

Put context performance in your agent architecture.

**Body**

The LeanCTX SDK gives AI agents explicit control over the context that reaches the model. Select useful material, compress repeated output, reuse validated artifacts and recover source detail when the task demands it.

**Primary CTA:** Explore the SDK Preview  
**Secondary CTA:** Install the Engine

**Trust line:** Apache-2.0 Engine · BSL 1.1 Production SDK · Cloud optional

---

## Section: The SDK’s job

**Headline**

Your agent decides. LeanCTX makes the context decision observable.

**Body**

LeanCTX does not replace your model, tools or agent framework. It provides the context-performance layer around them, so the material entering inference can be governed as an engineering concern.

**Diagram labels**

Sources and tools → LeanCTX context controls → agent/model call → task result

---

## Section: Core primitives

### Select relevant context

Express what belongs in the next model call and what does not.

### Compress without losing the task

Reduce context overhead while retaining the details needed for the current decision.

### Reuse work already validated

Keep durable summaries, artifacts and task state available across turns.

### Recover original detail

Trace a compact representation back to its source when the agent needs more evidence.

### Inspect the path

See what was selected, transformed and sent so behavior can be evaluated rather than guessed.

---

## Section: Choose an integration depth

**Headline**

Adopt the SDK without replacing the agent you have.

### Attach to a coding agent

Add LeanCTX at the file, tool-output and session boundaries of an existing coding workflow.

### Wrap a runtime loop

Control the context handoff between retrieval, tools and model calls.

### Embed in a custom system

Use LeanCTX primitives as part of your own agent architecture and context policy.

**CTA:** View integration guides

---

## Section: Local-first by design

**Headline**

Keep context control close to the work.

**Body**

LeanCTX is designed for teams that want a context-performance layer without surrendering the architecture of their agent system. Use it with the models, tools and environments your work requires.

**CTA:** Read the architecture notes

---

## Section: From SDK to evidence

**Eyebrow**

THE NEXT QUESTION

**Headline**

Did the context path improve the task?

**Body**

Install is the start, not the proof. Establish a comparable baseline and verify changes against the same workload before you scale a configuration.

**Primary CTA:** Benchmark your agent  
**Secondary CTA:** Read methodology

---

## SDK final CTA

**Headline**

Build the context path deliberately.

**Body**

Install LeanCTX and make context performance part of how your agents are built.

**Primary CTA:** Install LeanCTX  
**Secondary CTA:** View GitHub

---

# Enterprise `/enterprise`

## Page hero

**Status:** Preview

**Eyebrow**

LEANCTX ENTERPRISE

**Headline**

Context performance belongs in the platform.

**Body**

When many teams build agents, context behavior cannot remain an invisible implementation detail. LeanCTX gives organizations a shared layer to govern context decisions, compare outcomes and carry proven practices across systems.

**Primary CTA:** Talk to us  
**Secondary CTA:** Read the enterprise overview

---

## Section: The enterprise problem

**Headline**

More agents create more unmeasured context paths.

**Body**

Every agent can retrieve differently, repeat different history and carry different assumptions into inference. Without a common performance layer, teams cannot reliably inspect where context overhead comes from or compare the effect of a change.

---

## Section: A common context layer

### Give builders useful controls

Provide SDK primitives and integration patterns teams can apply without replacing their chosen agent stack.

### Give platform teams shared evidence

Standardize how baselines, treatments, receipts and quality checks are recorded and reviewed.

### Give leadership an adoption path

Move from one agent’s measured improvement to reusable context practices across comparable workloads.

**CTA:** Discuss your platform

---

## Section: Govern with evidence

**Eyebrow**

MEASURE. COMPARE. VERIFY.

**Headline**

Make performance claims reviewable.

**Body**

Enterprise context performance is not a dashboard number in isolation. A credible result identifies the workload, baseline, treatment, model configuration, cost measurement and quality criteria used to reach it.

**Checklist labels**

Declared workload · Comparable baseline · Explicit treatment · Context and cost receipt · Quality evaluation

**CTA:** See the benchmark methodology

---

## Section: Adoption path

### 1. Start with one agent

Add the SDK where a context-heavy workflow already matters.

### 2. Establish a baseline

Measure the task before treating an optimization as a gain.

### 3. Compare a treatment

Use the same workload and quality bar to understand the actual trade-off.

### 4. Reuse what works

Carry validated context patterns into similar systems with the evidence attached.

---

## Enterprise final CTA

**Headline**

Turn context performance into a repeatable capability.

**Body**

Tell us where your agents spend context today. We will start with the workload, the architecture and the evidence you need to make a decision.

**Primary CTA:** Talk to us  
**Secondary CTA:** Install the SDK

---

# Benchmark `/benchmark`

## Page hero

**Status:** Preview

**Eyebrow**

LEANCTX BENCHMARK

**Headline**

Prove the context path on the task that matters.

**Body**

LeanCTX Benchmark compares a declared baseline and context treatment on the same agent workload. It helps you see the trade-off between context overhead, calculated cost and task quality before you scale a change.

**Primary CTA:** Benchmark your agent  
**Secondary CTA:** Read the methodology

---

## Section: Evidence process

**Headline**

Measure. Compare. Verify.

### Measure

Capture a baseline for a declared workload: model configuration, context overhead, calculated cost and task outcome.

### Compare

Run the identical workload with an explicit context treatment. Do not change the task to make a result look better.

### Verify

Review the receipt and the task-quality evaluation. A lower cost is not a result if the task no longer meets the bar.

---

## Section: What a benchmark records

**Headline**

Every number needs its conditions.

**Record fields**

### Workload

Task definition, turn count, source material and evaluation criteria.

### Baseline

The unmodified context path and its measured outcome.

### Treatment

The declared LeanCTX configuration used in comparison.

### Receipt

Context, token and calculated-cost deltas with the model configuration used.

### Quality result

The same-task evaluation that qualifies whether the treatment remains useful.

---

## Section: Published result framing

**Eyebrow**

EXAMPLE, NOT A PROMISE

**Headline**

Read results with the workload attached.

**Body**

In controlled five-turn coding-agent workloads using real OpenAI API calls, a tested LeanCTX treatment reduced calculated API cost by approximately 79–86% under the declared methodology.

This result is specific to those workloads and settings. It is evidence that context performance can be measured—not a guarantee for every agent, model or task.

**CTA:** Read the full methodology

---

## Section: Who it is for

### Developers

Find out whether a context change improves your agent’s task economics without hiding a quality loss.

### Platform teams

Give teams a consistent way to compare contexts and share evidence.

### Engineering leaders

Decide where a context-performance investment is justified by results, not intuition.

---

## Benchmark final CTA

**Headline**

Bring a real workload.

**Body**

Start with the agent behavior you need to improve. Compare it on the same task, inspect the evidence and decide from there.

**Primary CTA:** Benchmark your agent  
**Secondary CTA:** Install LeanCTX

---

# Developer campaign

## Campaign role

This campaign introduces developers to the SDK through their existing agent workflow. It may use a more direct, energetic voice than the product pages, while keeping the proof doctrine intact.

## Campaign platform

**Campaign line**

Tune any agent.

**Support line**

Control the context path before inference. Lower unnecessary overhead, then prove the result on the same task.

**Primary CTA:** Install LeanCTX  
**Secondary CTA:** Benchmark your agent

**Required footer:** Apache-2.0 Engine · BSL 1.1 Production SDK · Local-first

---

## Developer landing page

**Eyebrow**

CONTEXT PERFORMANCE FOR DEVELOPERS

**Headline**

Your agent can keep its stack. Give it a better context path.

**Body**

LeanCTX plugs into coding agents, runtime loops and custom systems. Select what matters, compress what repeats, reuse what is validated and recover source detail when the task needs it.

**Proof line**

Baseline first. Treatment second. Same task throughout.

**Primary CTA:** Install LeanCTX  
**Secondary CTA:** See integration guides

---

## Paid and organic social

### Concept 1: Before inference

**Primary text**

Your agent can access everything. It should not load everything. LeanCTX makes
the context path explicit: select, shape, reuse, and recover.

**Headline**

Give every agent a context system.

**CTA:** Install LeanCTX

### Concept 2: Keep the agent

**Primary text**

The problem is not always the model. It is often what the agent keeps sending to it. Keep your agent stack. Make the context path measurable.

**Headline**

Control context. Keep your stack.

**CTA:** Build with LeanCTX — Preview

### Concept 3: Evidence

**Primary text**

An optimization is not a result until it is compared on the same task. Baseline the workload, run the treatment, inspect the receipt and check quality.

**Headline**

Measure. Compare. Verify.

**CTA:** See the proof method

---

## Launch email

**Subject:** Give every agent a context system

**Preheader:** Install the LeanCTX Context SDK and measure the task before you tune it.

**Headline:** Give every agent a context system.

**Body:**

Every agent decides what to retrieve, read, repeat, reuse and send to the model. LeanCTX gives that path explicit controls—without asking you to replace your agent framework or model.

Install LeanCTX for a supported coding agent, or build with the Preview SDK path.
Use the proof method only with the same task and declared quality bar.

**Primary CTA:** Install LeanCTX  
**Secondary CTA:** Build with LeanCTX — Preview

---

## Documentation-site banner

**Copy**

An agent needs a task-fit context view, not every available source. Install
LeanCTX, then inspect the evidence method before making a performance claim.

**CTA:** See the proof method

---

## Conference or community talk

**Title**

Give every agent a context system: engineering the context path for AI agents

**Abstract**

An agent can access more information than it should load into the next call. It
depends on what the agent retrieves, reads, repeats, reuses, and carries
forward. This talk shows how to give an existing agent a context system: add
explicit selection, shaping, reuse, and recovery controls; preserve task-critical
signal; and verify changes against the same workload and quality bar.

**Closing CTA:** Install LeanCTX. Build with LeanCTX — Preview.

---

## Campaign proof guardrails

- Say “lower context overhead” unless a result includes its workload and methodology.
- Say “calculated API cost” when referring to benchmark cost results.
- Pair any performance claim with the same-task quality condition.
- Do not imply that a benchmark result generalizes to every model, agent or workload.
- Direct developers from campaign material to the SDK for implementation and the Benchmark page for evidence.
