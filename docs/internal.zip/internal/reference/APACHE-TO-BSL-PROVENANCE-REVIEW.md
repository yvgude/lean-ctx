# Apache-to-BSL Provenance Review

> **Classification:** Source-history and Legal review input; not legal advice
>
> **Audited source/history:** `github/main@2c7d0044302d50af8d218a041b45726ad710757c`
>
> **Remote registry, CLA/DCO, employment-assignment and complete copyright
> chain:** **UNVERIFIED** unless explicitly stated below.

## Governing distinction

This review separates:

```text
future canonical product ownership
```

from:

```text
license and rights in already-published source/history
```

Moving, renaming, or depending on Apache-2.0 code does not erase existing
Apache rights for already-published source and artifacts. Prior Apache
publication neither authorizes nor categorically forbids Thinkery's future BSL
reuse: that separate decision depends on copyright ownership, contribution
provenance, applicable assignments/agreements, third-party terms and Legal
approval.

Future Engine inclusion is a different decision. A later Apache Engine release
may remove implementation that is not required by the supported OSS product or
an explicit compatibility commitment. Removal does not revoke historical
Apache rights and does not itself relicense the removed source.

> **Historical Apache rights remain. Future BSL source reuse requires
> sufficient rights and provenance. Where rights are unclear, reimplement the
> product semantics behind the public contract.**

## Evidence inspected

- repository and package license declarations;
- local Git author metadata for likely migration paths;
- public package metadata present in source;
- implementations, exports, tests, and current canonical product decisions.

The root `LICENSE` and Python package `LICENSE` contain Apache License 2.0.
`packages/python-lean-ctx/pyproject.toml` declares Apache-2.0 and version
`1.0.0`. Both Rust crates declare Apache-2.0. The audited history does not prove
copyright ownership, contributor authorization, CLA/DCO status, or whether
every published artifact exactly matched the audited commit.

## Contributor signals from local history

| Path | Distinct author signals observed | Review consequence |
| --- | --- | --- |
| `packages/python-lean-ctx/**` | Yves Gugger identities | Founder-only author metadata observed; rights still require formal confirmation before BSL source reuse. |
| `rust/crates/lean-ctx-sdk/**` | Yves Gugger identities | Keep Apache as Engine façade; no reason to relicense it. |
| `rust/crates/lean-ctx-protocol/**` | Yves Gugger GitHub identity | Keep public Engine contracts Apache; SDK-like schemas remain historically Apache. |
| `rust/src/core/context_kernel/**` | Yves Gugger; `andig <cpuidle@gmail.com>` | External-author signal exists: **LEGAL/PROVENANCE REVIEW REQUIRED** before copying any implementation into BSL. |
| `rust/src/core/context_compiler.rs` | Yves Gugger identities | Split mechanism and semantics; formal rights review still required for BSL code reuse. |
| `rust/src/core/context_field.rs` | Yves Gugger local identity | Same; prefer explicit new SDK policy implementation rather than relocating global strategy state. |
| `rust/src/core/session/**` | Yves Gugger; andig; Cedric Stephan; Devin; Oleksii Usatov | Multiple external-author signals: preserve as Apache OSS Attach compatibility; do not copy into BSL without file/commit-level Legal review. |
| `rust/src/core/profiles/**` | Yves Gugger GitHub identity | Split future semantics; rights review required before direct reuse. |
| `rust/src/kits/**` | Yves Gugger GitHub identity | Keep open-format/parser candidates Apache; build new SDK activation lifecycle behind the public format. |
| `packages/node-lean-ctx/**` | Local history not fully attributed in this audit | Package declares MIT; keep separate and do not copy into BSL without a license/provenance dossier. |

Author names/emails are attribution signals, not legal conclusions. A commit may
be mechanical, co-authored, employer-owned, generated, or based on prior work.

## Migration disposition

| Existing source group | Current/historical license signal | Public semantics already exposed | Recommended future disposition | Legal/provenance status |
| --- | --- | --- | --- | --- |
| Python `core.py`, `session.py`, `agents_model.py` | Apache-2.0 package | `ContextSession`, source/view/plan-like models and lifecycle vocabulary | Treat behavior and tests as migration input; design clean BSL state machine and types against public Engine Protocol | Rights chain and publication mapping **UNVERIFIED**; direct reuse requires approval |
| Python `wrap.py`, `agents.py` | Apache-2.0 package | wrapper/lifecycle, streaming/error behavior and OpenAI Agents integration | Preserve Preview compatibility; reimplement supported BSL adapter around final SDK contract, retaining native host behavior | **LEGAL/PROVENANCE REVIEW REQUIRED** before copied code |
| Python `receipt.py` | Apache-2.0 package | receipt/sign/verify behavior and schema | Keep historical verification compatibility open; create SDK Receipt projection as a new versioned product contract | Existing receipt semantics cannot be made exclusive; source reuse needs approval |
| Python `profile.py`, `kit.py` | Apache-2.0 package | Profile/Kit API and formats | Preserve readable historical/open formats; reimplement product policy, composition and activation in SDK | Format rights remain Apache; BSL implementation review required |
| Python transport/discovery/proxy/client and optional adapters | Apache-2.0 package | transport and adapter imports | Keep only supported Preview compatibility; use as behavior fixtures, not canonical SDK core | Per-module publication/support **UNVERIFIED** |
| Rust `lean-ctx-sdk` façade | Apache-2.0 crate, `publish=false` in audited manifest | `Engine`, read modes, compression/tokens/hash helpers | Keep Apache; evolve into clear in-process Engine embedding façade with migration/possible rename | Do not migrate/relicense into BSL |
| Protocol `engine_interface`, `capability`, common identity, execution/evidence/usage facts | Apache-2.0 crate | low-level mechanism/fact contracts | Preserve the versioned interoperability contract; implementation may evolve behind it | Historical Apache rights and current open-contract continuity apply |
| Protocol `context_session` and exported session/profile/kit/integration-depth models | Apache-2.0 crate | SDK-like lifecycle and pins already public | Freeze as historical/compatibility input; define new BSL SDK contracts without pretending exclusivity over the old schema | Direct source reuse requires approval; behavior reimplementation preferred |
| Protocol `knowledge_routing::ContextReceiptV1` and bundle/candidate models | Apache-2.0 crate | context candidate/bundle/receipt semantics | Separate Engine observation/artifact facts from new SDK Receipt/Plan semantics; keep old verifier/fixtures open | **LEGAL/PROVENANCE REVIEW REQUIRED** for BSL copying |
| Protocol control-plane/fleet/rollout/auto-routing/value-share/outcome-engine | Apache-2.0 crate | broad historical contracts | Freeze/deprecate or keep compatibility; do not copy into SDK v1 or reactivate Cloud scope | No BSL migration need established |
| Context Kernel object/plan/receipt types, orchestrator, policy, invalidation, degradation | Root Apache-2.0; external-author signal in folder | internal/public-root Rust surface and OSS behavior | Preserve only required OSS behavior during transition; later remove or replace non-contract implementation; build clean SDK lifecycle semantics | **LEGAL/PROVENANCE REVIEW REQUIRED** before any BSL source reuse |
| Context Kernel feedback/learning/adaptive/provider strategy | Root Apache-2.0; external-author signal in folder | learning behavior in open source | Freeze as Research or keep local compatibility; future private intelligence must be independently justified/implemented | Do not assume exclusive rights or data permission |
| Context Kernel bridges/evidence/receipts | Root Apache-2.0 | MCP/proxy/evidence integration | Keep Engine facts and Attach bridge open; SDK owns new projection/adapter contract | Reuse only after exact file/commit review |
| `context_compiler.rs` pure explicit-input selection core | Root Apache-2.0 | deterministic optimizer behavior | Keep a narrow stateless Engine primitive Apache | No BSL move needed |
| `context_compiler.rs` lifecycle/view/strategy coupling | Root Apache-2.0 | algorithm and result shapes visible in source | SDK constructs candidates and owns meaning; implement against narrow optimizer rather than copy mixed code | Review if any direct reuse proposed |
| `context_field.rs` IDs/view costs/token math | Root Apache-2.0 | low-level types/functions | Keep/refactor open mechanism | No BSL move needed |
| `context_field.rs` presets, process-global active weights, bandit/feedback choice | Root Apache-2.0 | strategy implementation | Remove from future Engine hot-path ownership; clean SDK policy or later private intelligence implementation | Behavior remains historically Apache |
| `core/session/**` | Root Apache-2.0; multiple external-author signals | coding-agent persistence/compaction/handoff behavior | Preserve the minimum supported continuity behavior; historical playbook/research state may be removed; Product `ContextSession` is a clean model | **LEGAL/PROVENANCE REVIEW REQUIRED**; direct BSL copy strongly discouraged |
| `core/profiles/**` | Root Apache-2.0 | mixed Engine and product configuration | Keep EngineConfig/safety/output-mechanism fields open; create SDK performance/context policy contract cleanly | Review schema/code reuse separately |
| `kits/mod.rs` and related local format behavior | Root Apache-2.0 | local kit read/activation behavior | Keep format/parser/integrity open; SDK owns maintained activation/composition/session binding | Open historical behavior remains available |
| `server/context_gate.rs` | Root Apache-2.0 | accepted OSS Attach heuristics | Preserve/freeze as OSS compatibility; never copy wholesale as SDK Planner | No BSL migration needed |
| Node proxy/compress/Vercel middleware package | MIT package signal | public `lean-ctx-sdk`-named compatibility surface | Freeze/deprecate with migration notice; do not merge into Production SDK | **LEGAL/PROVENANCE REVIEW REQUIRED** for any source reuse |

## Required Legal dossier before Wave D/E

For every proposed reused file or function, produce:

1. exact path, blob digest and introducing/modifying commits;
2. author, committer, co-author and signed-off metadata;
3. applicable CLA/DCO/employment/assignment evidence;
4. published artifact/version mapping;
5. third-party/generated/source-derived notices;
6. intended BSL use and whether separation/reimplementation is feasible;
7. Product/Legal approval recorded against that exact material.

Absent this dossier, the default is:

- leave historical Apache rights and source untouched;
- retain current Engine implementation only while the OSS product contract or
  an explicit transition commitment requires it;
- use public behavior/contracts/fixtures as interoperability input;
- independently implement the new SDK product semantics;
- retain all applicable notices and do not change historical headers.

## Explicit non-conclusions

This review does not conclude that Thinkery can or cannot dual-license any
specific contribution. It does not establish authors' employment rights,
waivers, patent rights, registry publication history, or contributor consent.
Those are **LEGAL/PROVENANCE REVIEW REQUIRED** items.

It also does not conclude that every Apache implementation must remain in
future Engine versions. Product preservation, source reuse and historical
license rights are three distinct determinations.
