# Benchmark & Calibrator — Codebase Gap Analysis

> Evidence-based mapping of the [Calibration & Performance Platform Vision](../vision/14-LEANCTX-CALIBRATION-PERFORMANCE-PLATFORM-VISION.md) against the current codebase.
> Generated 2026-08-21 from parallel agent analysis of the full `rust/` and `packages/` trees.

---

## 1. Existing benchmark infrastructure

Six independent benchmark engines exist today. None share a unified `BenchmarkSpec` type.

| Engine | Entry point | What it measures |
|---|---|---|
| Project compression | `rust/src/core/benchmark.rs` L527–857 | All read modes per language; simulated 20-turn session |
| Quality A/B replay | `rust/src/core/quality_benchmark.rs` L105–351 | With/without compression from recorded sessions; Wilson CIs |
| Task-score | `rust/src/core/task_benchmark/runner.rs` L121 | Fixed coding-task fixtures × stock/standard/aggressive profiles |
| E-Bench 4-arm study | `rust/src/core/benchmark_study/runner.rs` L18–312 | Control/Compress/Route/Combined on HumanEval/MBPP/SWE-bench |
| Competitor compare | `rust/src/core/benchmark_compare/` | Search latency, disk footprint, cold start vs competitors |
| Proxy pipeline | `rust/src/proxy/pipeline_bench.rs` L131 | Synthetic multi-turn messages through compression pipeline |

### CLI commands

| Command | Handler | Purpose |
|---|---|---|
| `benchmark --real` | `benchmark_cmd.rs` | Proxy pipeline bench |
| `benchmark run [path]` | `config_cmd.rs` L711 | Project compression |
| `benchmark tasks` | `benchmark_tasks_cmd.rs` | Task-score fixtures |
| `benchmark study` | `benchmark_study_cmd.rs` | E-Bench 4-arm |
| `benchmark replay <json>` | `config_cmd.rs` L726 | Quality A/B |
| `benchmark compare` | `config_cmd.rs` L752 | Competitor head-to-head |
| `eval testbench` | `eval_cmd.rs` L407 | Multi-repo paired testbench |

### Fixture and eval data

- `rust/src/core/task_benchmark/fixtures.rs` — 5 canonical task fixtures
- `rust/eval/testbench/testbench.lock.json` — pinned local repos (no remote URLs yet)
- `scripts/benchmark/` — lightweight 10-op shell harness (chars/4 token proxy)

### Key types (fragmented naming)

| Concept | Current type | Location |
|---|---|---|
| Session replay suite | `ReplaySuite` | `quality_benchmark.rs` L18 |
| Task fixture suite | `canonical_suite() -> Vec<TaskFixture>` | `task_benchmark/fixtures.rs` L107 |
| Project scan result | `ProjectBenchmark` | `benchmark.rs` L71 |
| Study config | `StudyConfig` | `benchmark_study/experiment.rs` L55 |
| Testbench lock | `TestbenchLock` | `eval_ab/testbench/lockfile.rs` |
| Proxy bench report | `BenchmarkReport` | `pipeline_bench.rs` L46 |
| Benchmark profile mode | `ProfileMode` (Stock/Standard/Aggressive) | `task_benchmark/config.rs` L13 |
| Profile result | `ProfileResult` | `task_benchmark/runner.rs` L24 |

---

## 2. Existing profile system

### Runtime profiles (`rust/src/core/profiles/`)

| Component | File | Purpose |
|---|---|---|
| Root struct | `types.rs` L5 `Profile` | Read, compression, translation, layout, memory, budget, pipeline, routing, degradation, autonomy, output hints |
| Built-ins | `builtins.rs` | 7 profiles: `coder`, `exploration`, `bugfix`, `hotfix`, `ci-debug`, `review`, `passthrough` |
| Loading | `loading.rs` L38 `load_profile()` | 3-tier: project → user → built-in, with `extends` inheritance |
| Suggestion | `profile_suggest.rs` L86 `analyze()` | Repo analysis → recommended profile + settings |
| CLI | `cli/profile_cmd.rs` | `list`, `show`, `active`, `diff`, `create`, `set`, `suggest` |
| Active resolution | `loading.rs` L400 | In-process → `LEAN_CTX_PROFILE` → config → `"coder"` |
| Config integration | `config/model.rs` L192 | `profile: Option<String>` in config TOML |

### Profile fields today

```text
read:          default_mode, max_tokens_per_file, prefer_cache
compression:   crp_mode, output_density, entropy_threshold, terse, adaptive
translation:   enabled, ruleset
layout:        enabled, min_lines
routing:       max_model_tier, degrade_under_pressure
degradation:   enforce, throttle_ms
budget:        max_context_tokens, max_shell_invocations, max_cost_usd
pipeline:      intent, relevance, compression, translation layers
autonomy:      preload, dedup, prefetch, checkpoint, ...
output_hints:  compressed, archive, verify_footer, related, semantic, ...
```

### Python SDK

- `lean_ctx/profile.py` L16: `TuningProfile` — frozen dataclass for receipt pinning
- Fields: `id`, `version`, `content_hash`, `source_ref`, optional budget/compression/recovery
- Used in `ExecutionReceipt.profile` and `Session` validation

### Profile identity in receipts

- `rust/src/core/context_proof.rs` L44: `ProfileIdentity { name, policy_md5 }` — recorded in proofs

---

## 3. Existing OCLA substrate

### Live production layer

| Component | Location | Status |
|---|---|---|
| 15 service traits | `lean-ctx-ocla/src/traits.rs` | **Live** — OSS crate |
| `OclaRegistry` (15 Arc<dyn Trait>) | `rust/src/core/ocla/registry.rs` | **Live** — global singleton, wired across proxy/tools/CLI |
| 15 builtin implementations | `rust/src/core/ocla/builtin/` | **Live** |
| `CapabilityManifestV1` | `lean-ctx-protocol/src/capability.rs` | **Live** — 20+ fields, JSON schema |
| 3 sample manifests | `docs/contracts/ocla/capability-manifests/` | Context, Passthrough, RTK Shell |
| Conformance checker | `rust/src/core/conformance.rs` | **Live** — manifest + invocation checks |

### Scaffold (designed, not production-wired)

| Component | Location | Status |
|---|---|---|
| `CapabilityAdapter` trait | `rust/src/core/ocla/adapters/mod.rs` | Types used, adapters test-only |
| `AdapterRegistry` | `rust/src/core/ocla/adapters/registry.rs` | `BTreeMap<AdapterKey, Arc<dyn CapabilityAdapter>>` — no global instance |
| `ReferenceScheduler` / `SchedulerService` | `rust/src/core/ocla/scheduler/` | Contract + tests, no production hook |
| `NativeContextAdapter`, `PassthroughAdapter`, `RtkShellAdapter` | `rust/src/core/ocla/adapters/` | Implemented, test-only |
| v0 `CapabilityRegistry` | `rust/src/ocla/registry.rs` | Different schema, test-only, not connected |

### Dead code in OCLA crate

- `lean-ctx-ocla/src/manifest.rs` — `validate_manifest()`, `PolicyFilter` (not in `lib.rs`)
- `lean-ctx-ocla/src/failure.rs` — `CapabilityFailure` (empty enum)
- `lean-ctx-ocla/src/observation.rs` — superseded by `invocation.rs`

---

## 4. Existing receipt and evidence chain

### Protocol receipt types

| Type | Location | Signing |
|---|---|---|
| `ExecutionReceiptV1` | `lean-ctx-protocol/src/execution.rs` L103 | Ed25519 (`canonical.rs`) + BLAKE3 (`receipt_builder.rs`) |
| `SavingsReceiptV1` | `lean-ctx-protocol/src/savings.rs` L34 | Ed25519 (via `evidence_flow.rs`) |
| `ContextReceiptV1` (routing) | `lean-ctx-protocol/src/knowledge_routing.rs` L97 | N/A |

### Supporting types

- `EvidenceRefV1` (`evidence.rs` L5): kind, uri, digest, signature_status
- `AcceptedOutcomeV1` (`outcome.rs` L48): accepted/rejected/unknown, quality_score, signals
- `ContextBalanceV1` (`execution.rs` L73): 4-stage token balance

### Quality gates (6 independent)

| Gate | Location | Mechanism |
|---|---|---|
| Real-world evidence | `cli/dispatch/evidence_realworld.rs` L165 | savings > 0, all turns complete, quality baseline met |
| Eligibility policy | `proxy/eligibility.rs` L56 | `quality >= quality_floor` (default 0.99) |
| OCLA comparison | `ocla/reference_adapters/comparison_receipt.rs` L8 | Score >= 90, 10-point gap tolerance |
| Compression density | `core/quality.rs` L130 | Structure composite threshold → full fallback |
| Eval A/B CI | `eval_ab/report.rs` L83 | Fails only on `Verdict::Regressed` |
| Settlement evidence | `billing/settlement_evidence/mod.rs` L933 | `passed: false` → ineligible |

### Python receipt

- `ExecutionReceipt` (`receipt.py` L93): SHA-256 canonical hash + optional Ed25519
- `verify()` L121: sealed check → hash match → Ed25519 or server verify → conservative `False`

---

## 5. Existing agent detection and integration

### Detection layer

- `editor_registry/detect.rs`: `build_targets()` returns ~35 `EditorTarget` entries
- Detection = filesystem checks (`detect_path.exists()`), not process sniffing
- Used by: `status`, `setup`, `onboard`, `doctor`, `wrap`

### Wrap targets (proxy integration)

| Agent | Proxy env | Config |
|---|---|---|
| Claude | `ANTHROPIC_BASE_URL` | `~/.claude/settings.json` |
| Codex | `OPENAI_BASE_URL` | `~/.codex/config.toml` |
| Cursor | Manual (printed instructions) | Cursor Settings → Models |
| Windsurf | `OPENAI_BASE_URL` + `ANTHROPIC_BASE_URL` | Shell exports |
| Cline | Same as Windsurf | Shell exports |
| Grok | `GROK_MODELS_BASE_URL` | Shell exports |
| Aider | `OPENAI_API_BASE` + `ANTHROPIC_BASE_URL` | Shell exports |
| Copilot | `COPILOT_PROVIDER_BASE_URL` | Shell exports |

### Hook modes

- **Replace** (native tools denied): cursor, claude, codex, windsurf, opencode, gemini
- **Hybrid** (MCP + shell hooks): 20+ agents
- **MCP-only**: everything else

### Agent identity bus

- `agent_registry.rs`: `lean-ctx agent register/list`
- `agents/bridge.rs`: merges identity + MCP presence into `UnifiedAgent`

---

## 6. Gaps — Vision vs Codebase

### Gap 1: PerformanceProfileV1

**Vision:** A composable config with `capabilities`, `quality_floor`, `max_cost_usd`, `max_latency_ms`, and versioned identity.

**Current:** `Profile` has context-behavior fields (read_mode, compression, budget) but no `capabilities` field, no quality constraints, no capability-provider mapping.

**Bridge path:**
1. Add `constraints: ProfileConstraints` to `Profile` (quality_floor, max_cost_usd, max_latency_ms)
2. Add `capabilities: BTreeMap<String, CapabilityRef>` mapping surface → provider
3. Extend `TuningProfile` in Python SDK with matching fields
4. Create `docs/contracts/performance-profile-v1.schema.json`

**Prerequisite:** OCLA `AdapterRegistry` must be production-wired first (WS-4).

### Gap 2: Calibrator

**Vision:** Automated candidate generation, benchmark sweep across profiles, Pareto frontier analysis, recommendation engine.

**Current:** Nothing. The `task_benchmark` tests 3 fixed compression modes (stock/standard/aggressive) — no parametric sweep, no Pareto.

**Build path:**
1. Define `CalibratorConfig` (parameter ranges, capability combinations, quality floor)
2. Implement `generate_candidates()` — cartesian product or heuristic
3. Wire each candidate through unified benchmark runner
4. Implement Pareto frontier (cost × quality × latency)
5. `lean-ctx calibrate [agent]` CLI command
6. Record each run as `ExecutionReceiptV1` for evidence

**Prerequisite:** Unified `BenchmarkSpec` (Gap 3) and `PerformanceProfileV1` (Gap 1).

### Gap 3: Unified BenchmarkSpec

**Vision:** `BenchmarkSpec`, `BenchmarkSuite`, `LeanBench` — versioned, signed, deterministic.

**Current:** 6 fragmented engines with different type names (`ReplaySuite`, `TaskFixture`, `StudyConfig`, etc.).

**Build path:**
1. Define `BenchmarkSpecV1` protocol type (workload ID, version, task list, controls)
2. Define `BenchmarkSuiteV1` (collection of specs, versioned)
3. Consolidate existing `TaskFixture` as the reference implementation
4. `lean-ctx benchmark run --spec <suite>` CLI
5. Migrate `task_benchmark` fixtures to `BenchmarkSuiteV1` format

### Gap 4: Agent Invocation Harness

**Vision:** Programmatically invoke Codex (App Server JSON-RPC), Claude Code (`claude -p`), Cursor (ACP/CLI) for benchmark runs.

**Current:** Detection exists (40+ agents), proxy wrapping exists (9 agents), but **no programmatic agent invocation**. The proxy intercepts API calls — it does not start or control agent processes.

**Build path:**
1. Define `AgentConnector` trait: `start(workload) -> AgentHandle`, `observe()`, `stop()`
2. Implement `CodexConnector` using Codex App Server JSON-RPC
3. Implement `ClaudeCodeConnector` using `claude -p --output-format json`
4. Implement `CursorConnector` using Cursor ACP stdio/JSON-RPC or Cloud Agents API
5. `lean-ctx benchmark connect --agent codex` CLI
6. Each connector creates isolated worktree, invokes agent, observes execution

**Risk:** Agent vendor APIs are not stable. Codex App Server and Cursor ACP are early.

### Gap 5: Pair/Connect Protocol

**Vision:** `lean-ctx pair LCTX-A9F2` — WebSocket to Thinkery, browser shows live benchmark progress.

**Current:** `wrapped_publish.rs` has basic pairing codes for the gain/leaderboard dashboard. No WebSocket to external Thinkery infrastructure.

**Build path:**
1. Define `PairingProtocol` (code exchange, session binding, capability advertisement)
2. WebSocket client in lean-ctx CLI (`lean-ctx pair <code>`)
3. Thinkery backend: pairing service, BenchmarkSpec dispatch, result collection
4. Browser UI: live progress, result rendering

**Prerequisite:** Thinkery Cloud infrastructure (not OSS scope).

### Gap 6: Performance Registry

**Vision:** Centralized store learning from workload × agent × model × profile × capabilities × outcome.

**Current:** Local receipts and evidence bundles. No aggregation, no cross-run learning.

**Build path:**
1. Define `PerformanceRecordV1` (workload fingerprint, profile hash, capabilities, outcome metrics)
2. Local SQLite for personal history
3. Thinkery API for anonymous contribution (opt-in)
4. Recommendation engine consuming historical records

**OSS scope:** Local history only. Learned ranking is commercial.

### Gap 7: Profile Distribution

**Vision:** `lean-ctx profile install codex-large-monorepo` — community profiles, forking, private/public.

**Current:** `lean-ctx profile create` from base, `profile list/show/set`. No remote registry, no install from URL/name.

**Build path:**
1. Profile registry API (Thinkery-operated)
2. `lean-ctx profile install <name>` → download + validate + store in `~/.config/lean-ctx/profiles/`
3. `lean-ctx profile publish` → upload with receipt evidence
4. Private/public visibility flag
5. Fork tracking (parent profile reference)

**OSS scope:** Manual profile TOML files remain OSS. Registry is commercial.

---

## 7. V1 Build Sequence (mapped to real code)

From Vision section 50, mapped to existing infrastructure:

| Step | Vision | Existing foundation | New work |
|---|---|---|---|
| 1. Benchmark | One canonical benchmark with workload, Receipt, quality | `task_benchmark` (5 fixtures, 3 profiles) | Unify under `BenchmarkSpecV1`; add Receipt output |
| 2. Profile | `PerformanceProfileV1` for current settings | `Profile` in `profiles/types.rs` | Add `constraints` + `capabilities` fields |
| 3. Manual Calibration | User changes Profile, re-runs | `profile create/set` + `benchmark tasks` | Wire them together: `benchmark --profile <name>` |
| 4. Calibrator v0 | Test fixed small candidate set | `task_benchmark/config.rs` `ProfileMode` | Expand to parametric sweep + Pareto selection |
| 5. Local Runner / Pairing | Connect browser to local LeanCTX | `wrapped_publish.rs` pairing codes | WebSocket protocol, BenchmarkSpec dispatch |
| 6. Result page | Profile, cost, quality, latency, Receipt | `benchmark_cmd.rs` `--share` flag | Web result rendering |
| 7. Verified ranking | Simple table of verified results | Dashboard leaderboard routes | Community vs Official distinction |
| 8. Capability identity | Record provider/version in Profile + Receipt | `CapabilityManifestV1` exists | Wire manifest ID into Profile and Receipt |
| 9. External Capability | One sample provider, then partner | `RtkShellAdapter` exists as scaffold | Production-wire `AdapterRegistry` |

---

## 8. Dependency graph

```text
WS-4 OCLA (AdapterRegistry production-wired)
    │
    ├── Gap 1: PerformanceProfileV1 (capabilities field)
    │       │
    │       ├── Gap 3: Unified BenchmarkSpec
    │       │       │
    │       │       ├── Gap 2: Calibrator v0
    │       │       │       │
    │       │       │       └── Gap 5: Pair/Connect (Thinkery Cloud)
    │       │       │               │
    │       │       │               └── Gap 7: Profile Distribution
    │       │       │
    │       │       └── Gap 4: Agent Invocation Harness
    │       │
    │       └── Gap 6: Performance Registry (local history first)
    │
    └── Step 8-9: Capability identity in Profile/Receipt + external adapter
```

Steps 1-4 can begin with existing code. Steps 5-7 require Thinkery Cloud.
Steps 8-9 require WS-4 OCLA adapter production wiring.
