# LeanCTX / Thinkery — Brand Narrative

> **Classification:** Active support narrative. Canonical product/repository
> boundaries, licensing and availability always prevail.

**Status:** Canonical brand narrative  
**Date:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX

---

# 1. Strategic thesis

> # **Give every agent a context system.**

This is the primary LeanCTX narrative. LeanCTX is the Context SDK that makes an
agent's context path explicit inside the agent loop its customer already owns.

An agent's work is already shaped before the model begins to reason:

- what the agent retrieves,
- what it reads,
- what it keeps,
- what it repeats,
- what it reuses,
- what it compresses,
- what it sends to the model.

LeanCTX operates at that layer. It selects, shapes, reuses, and recovers the
context that reaches the next step.

The brand must communicate concrete context behaviour, not undefined claims
about performance, innovation, or generic intelligence. Context performance is
a supporting technical and enterprise framing only when the affected dimension
is named: context sent, repeated reads, recovery, latency, calculated cost, or
accepted task outcome.

---

# 2. Brand architecture

## Thinkery

**Role:** Company / commercial operator / system builder.

**Primary line:**

> **Systems for the context agents need to work.**

Alternative corporate line:

> **Context systems for AI agents.**

Thinkery should feel:

- architectural,
- industrial,
- strategic,
- durable,
- organization-scale.

Thinkery is not the developer product. It is the company that builds and commercializes the systems around LeanCTX.

---

## LeanCTX

**Role:** Product / technology / developer-facing brand.

**Public category:**

> **The Context SDK for AI Agents.**

**Broader enterprise category:**

> **Context Infrastructure for AI Agents**

**Primary concept:**

> **Give every agent a context system.**

**Architecture line:**

> **Your framework runs the agent. LeanCTX manages its context path.**

**Developer campaign line:**

> **Your agent can access everything. That does not mean it should load everything.**

**Proof doctrine:**

> **Measure. Compare. Verify.**

---

# 3. Narrative hierarchy

The hierarchy must remain stable across website, decks, product, docs and sales.

## Level 1 — The problem

> **Your agent can access everything. That does not mean it should load everything.**

An agent works from a constructed view of files, tools, history, facts, and
prior work. The product question is: what should it see now?

## Level 2 — What

> **LeanCTX is the Context SDK for AI Agents.**

A developer-facing SDK and Runtime for the context path inside existing coding
agents and custom agent systems.

## Level 3 — How

> **Select → Shape → Reuse → Recover**

Core mechanisms:

- Select
- Shape
- Reuse
- Recover

Compression is one shaping operation. Memory, retrieval, and project knowledge
are sources within the broader context system.

## Level 4 — Proof

> **Measure. Compare. Verify.**

A gain counts only when:

- the workload is comparable,
- the baseline is known,
- the treatment is known,
- quality remains within the declared threshold,
- methodology is visible.

## Level 5 — Shared project context

> **Agents can have different jobs. They should not have to rediscover the same project.**

This is a Research direction, not a public orchestration promise.
The host keeps responsibility for scheduling, agent assignment, retries, and
workflow control; LeanCTX prepares bounded context and handoffs for the agents
the host orchestrates.

LeanCTX can eventually span:

- Codex,
- Claude Code,
- Cursor,
- OpenAI Agents,
- Claude Agent SDK,
- LangGraph,
- custom agents.

## Level 6 — Enterprise

> **Make context behavior an explicit engineering capability.**

At organization scale, LeanCTX expands into:

- versioned Performance Profiles,
- private Context Kits,
- shared evidence,
- policy,
- budgets,
- organization economics,
- private deployment.

---

# 4. Problem narrative

The problem is not simply that tokens are expensive.

The stronger problem is:

> # **AI agents spend before they reason.**

Every agent task can trigger:

- repository scans,
- tool outputs,
- source reads,
- search results,
- previous turns,
- memory,
- retries,
- system instructions.

All of this can become model input.

The agent can therefore become inefficient long before provider routing or model pricing is optimized.

The problem is **context behavior**.

---

# 5. Market insight

> **Every serious agent system develops a context strategy.**

At low maturity:
- context behavior is implicit.

At medium maturity:
- teams add trimming, caching, routing, evals and custom logic.

At high maturity:
- teams build internal harnesses.

LeanCTX exists to standardize that evolution.

```text
Implicit context behavior
        ↓
manual optimization
        ↓
custom harness
        ↓
reusable Context SDK
        ↓
evidence-gated context optimization (Research)
```

The advanced-enterprise case is not:

> "You cannot build this."

It is:

> **"You should not have to keep rebuilding and maintaining it independently."**

---

# 6. Core product narrative

## Short

> LeanCTX is the Context SDK for AI agents. It controls how agents select, compress, reuse and recover context before inference, then measures the result against the same task and quality threshold.

## Medium

> LeanCTX sits inside or alongside existing AI agents and optimizes the context path before inference. Instead of allowing every file read, tool response and previous turn to accumulate unchecked, LeanCTX helps the agent use the context it actually needs, preserve access to exact source when required and measure the economic effect against an accepted baseline.

## Long

> AI agent performance is not determined only by the model. It is also determined by the context strategy around the model: which information is retrieved, how it is represented, what is repeated, what is reused and what is sent again. LeanCTX is a Context SDK and Runtime that makes those decisions explicit, measurable and reusable. It integrates with existing coding agents and custom agent systems, allowing teams to reduce context overhead, preserve quality and version the resulting performance configuration across workloads.

---

# 7. Performance model

```text
TASK
 ↓
CONTEXT NEED
 ↓
SELECTION
 ↓
REPRESENTATION
 ↓
REUSE
 ↓
COMPRESSION
 ↓
RECOVERY
 ↓
EXECUTION
 ↓
OUTCOME
 ↓
RECEIPT
```

This is the LeanCTX performance loop.

---

# 8. Five core capabilities

## SELECT

> **Give the agent what matters.**

Choose which information should become active context.

## COMPRESS

> **Keep structure. Remove waste.**

Represent large payloads at the fidelity the task actually requires.

## REUSE

> **Stop processing the same information repeatedly.**

Reuse context already known to the agent or project.

## RECOVER

> **Keep exact source available when detail is required.**

Optimization should not mean irreversible information loss.

## MEASURE

> **Every optimization needs a baseline.**

Connect context behavior to provider usage, cost and outcome.

---

# 9. Proof doctrine

LeanCTX should become known for unusually disciplined performance claims.

# **Measure. Compare. Verify.**

## MEASURE

Measure what the agent actually consumed:

- input tokens,
- cached tokens,
- output tokens,
- tool activity,
- context volume,
- latency,
- provider usage.

## COMPARE

Compare:

- same task,
- same source revision,
- same model/provider unless intentionally varied,
- same quality requirements,
- baseline vs treatment.

## VERIFY

The optimization counts only if:

- quality remains within threshold,
- the receipt is valid,
- methodology is declared,
- the result is reproducible.

---

# 10. Primary product promise

> **Lower context overhead. Lower execution cost. Quality measured against the same task.**

This is stronger than vague claims such as:

- maximize intelligence,
- supercharge your agents,
- dramatically smarter AI,
- revolutionary optimization.

LeanCTX should be confident but measurable.

---

# 11. Category language

## Product category

> **The Context SDK for AI Agents**

Why:

- names the developer-facing product without inventing an agent platform;
- makes the integration boundary clear: existing agent loop, explicit context;
- leaves measurable outcomes—context sent, repeated work, latency, cost, and
  accepted task outcome—to their stated evidence.

## Product descriptor

> **The Context SDK for AI Agents.**

Why:

- understandable to developers,
- compatible with existing agents,
- avoids generic Agent Platform positioning,
- defines a concrete developer surface.

## Thinkery-level category

> **Agent Performance Infrastructure**

Use selectively at corporate/enterprise level.

Do not make "Agent Performance Engineering" a formal category yet.

---

# 12. Internal chiptuner analogy

The analogy remains useful internally:

```text
Agent               = machine
Foundation model    = engine
Context strategy    = calibration
Tokens / compute    = fuel
Usage / quality     = telemetry
Benchmark           = test bench
Performance Profile = calibrated configuration
LeanCTX              = performance system
```

Do not expose the full metaphor externally.

Allowed public vocabulary:

- tune,
- performance,
- benchmark,
- profile,
- calibration,
- optimization.

Avoid turning the brand into:

- Dyno as a major subbrand,
- Stage 1 / Stage 2,
- turbo,
- ECU,
- horsepower,
- racing aesthetics.

---

# 13. Product naming

The public landscape should stay small.

## LeanCTX Runtime
Open-source local engine.

## LeanCTX SDK
Developer integration surface.

## Performance Benchmark
Baseline/treatment performance test.

Internal codename may remain "Dyno".

## Performance Profile
Versioned context-performance configuration.

Prefer externally over "Tuning Profile."

## Context Kit
Reusable context capability.

## Receipt
Verifiable evidence artifact.

## LeanCTX Enterprise
Organization-scale operation.

Do not create unnecessary subbrands for every capability.

---

# 14. Homepage narrative

## Hero

**Eyebrow**

> THE CONTEXT SDK FOR AI AGENTS

**Headline**

> # **Give every agent a context system.**

**Body**

> LeanCTX selects, shapes, reuses, and recovers the project context an agent
> needs—inside the agent loop you already own.

**Proof line**

> Lower context overhead. Lower cost. Quality measured against the same task.

**CTA**

> **Benchmark your agent**

Secondary:

> `Install LeanCTX`

Trust line:

> Open source · Local-first · Model-agnostic

---

## Section 2

# **AI agents spend before they reason.**

Explain file reads, tool output, search, history and repeated context.

---

## Section 3

# **LeanCTX controls the context path.**

```text
AGENT
 ↓
LeanCTX
 ↓
MODEL / TOOLS
```

---

## Section 4

# **One engine. Three ways in.**

### ATTACH
Existing coding agents.

### WRAP
Existing frameworks.

### EMBED
Custom agents.

---

## Section 5

# **Measure. Compare. Verify.**

Show a real benchmark.

---

## Section 6

# **The context path determines what an agent sees next.**

Select / Compress / Reuse / Recover / Measure.

---

## Section 7

# **Context policy you can version.**

Introduce Performance Profiles.

---

## Section 8

# **Your coding agent stays your coding agent.**

Claude Code / Codex / Cursor.

---

## Section 9

# **Build agents with a context system.**

SDK for custom agents.

---

## Section 10

# **Standardize context behavior across agents.**

Enterprise.

---

## Section 11

# **The engine stays open.**

OSS / trust.

---

# 15. Developer narrative

> # **Build context-efficient agents by default.**

Supporting copy:

> LeanCTX gives your agent a structured Runtime for context selection, reuse, compression, recovery and measurement.

Developer communication should be direct and technical.

Do not lead developers with:

- governance,
- enterprise-control diagrams,
- abstract platform language.

---

# 16. Coding-agent narrative

For Claude Code / Codex / Cursor users:

> # **Your coding agent stays your coding agent.**

Support:

> Keep the workflow you already use. LeanCTX optimizes the context underneath it.

Campaign alternative:

> **Don't replace your agent. Tune it.**

---

# 17. Advanced-team narrative

For teams already operating internal context infrastructure:

> # **Already built your own context layer? Good.**

Support:

> LeanCTX is designed for teams that have moved beyond one-off prompt optimization. Benchmark your existing context strategy against versioned LeanCTX Performance Profiles and keep the winning approach.

Core question:

> **Why should every agent team rebuild its own context system?**

This is a build-vs-buy narrative, not a token-savings pitch.

---

# 18. Enterprise narrative

**Hero**

> # **Standardize context behavior across agents.**

**Body**

> Standardize how AI agents consume context across teams, frameworks and model providers. Measure each workload against an accepted baseline and deploy versioned performance policies without rebuilding the agent.

Enterprise pillars:

## PERFORMANCE
- cost,
- quality,
- latency,
- benchmarks.

## CONTROL
- Profiles,
- budgets,
- policy.

## EVIDENCE
- Receipts,
- history,
- audit.

## DEPLOYMENT
- local,
- VPC,
- on-prem.

---

# 19. Thinkery narrative

Thinkery should not compete with LeanCTX for attention.

## Primary

> **Systems for the context agents need to work.**

## Supporting

> Thinkery builds and operates the infrastructure that makes AI systems more efficient, measurable and controllable at organizational scale.

Thinkery is:

- the company,
- the commercial operator,
- the enterprise partner.

LeanCTX remains the product engineers interact with.

---

# 20. Tone of voice

The voice should be:

- precise,
- measured,
- confident,
- technically literate,
- minimal,
- evidence-led.

It should not be:

- breathless,
- futuristic,
- cute,
- combative,
- excessively metaphorical,
- filled with startup superlatives.

## Good

> Give every agent a context system.

> The same workload. A different context strategy.

> 139,115 input tokens → 14,016.

> Quality threshold: passed.

> Every result includes the methodology.

## Bad

> Unleash limitless AI intelligence.

> Supercharge your agents.

> The ultimate AI operating system.

> Revolutionary context orchestration.

> 10x smarter agents.

---

# 21. Vocabulary

## Preferred

- Performance
- Context
- Runtime
- SDK
- Baseline
- Benchmark
- Profile
- Receipt
- Quality
- Evidence
- Select
- Reuse
- Recover
- Measure
- Deploy
- Optimize
- Verify
- Workload

## Use carefully

- Tune
- AutoTune
- intelligence
- orchestration
- control plane
- optimization platform

## Avoid

- magical
- revolutionary
- cognitive
- fabric
- brain
- AI OS
- superpower
- agent army
- next-gen
- hyperintelligent

---

# 22. Benchmark narrative

Every public benchmark should include:

- benchmark name,
- date,
- model,
- provider,
- workload,
- source revision,
- methodology,
- baseline,
- treatment,
- provider usage,
- calculated cost,
- quality,
- sample size,
- limitations.

Example:

> In three controlled five-turn coding-agent workloads using real OpenAI API calls, the tested LeanCTX treatment reduced calculated API cost by approximately 79–86% under the declared methodology.

Required qualifier:

> Workload-specific result. Not a universal savings promise.

---

# 23. Founder narrative

Founder communication can be more personal than corporate copy.

Good:

> I built LeanCTX because I kept seeing agents consume far more context than the task actually needed.

> The more I work on this, the clearer the problem becomes: agent performance starts before the model call.

Avoid:

> I am building the operating system for all AI.

Ambition should remain grounded in product evidence.

---

# 24. Investor narrative

> Agent systems increasingly develop custom context logic around models. Advanced
> teams already build internal harnesses for routing, caching, evaluation, and
> reduction. LeanCTX standardizes the context path through an Apache-2.0 Engine
> and a separate premium BSL 1.1 Production SDK. The SDK is Thinkery's primary
> product; capable teams choose it instead of permanently maintaining equivalent
> infrastructure. Cloud, continuous optimization, and organization-scale
> operation remain optional later Research until they earn a product contract.

Category expansion:

```text
ad-hoc context utilities
        ↓
internal context harness
        ↓
Context SDK with evidence-gated Research directions
```

Do not lead with Marketplace, Managed Agents or generic orchestration.

---

# 25. Narrative guardrail

Whenever new copy is written, ask:

1. Does it begin with a concrete context behavior rather than a generic outcome?
2. Is the mechanism concrete?
3. Can the claim be measured?
4. Does it preserve the Context category?
5. Does it avoid generic AI-platform language?
6. Would an advanced engineering team take it seriously?
7. Is future capability clearly separated from what ships today?

If not, rewrite it.

---

# 26. Canonical message stack

## Thinkery

> **Systems for the context agents need to work.**

## LeanCTX category

> **The Context SDK for AI Agents**

## Primary hero

> **Give every agent a context system.**

## Technical thesis

> **The context path determines what an agent sees next.**

## Proof doctrine

> **Measure. Compare. Verify.**

## Developer campaign

> **Your framework runs the agent. LeanCTX manages its context path.**

This stack should remain stable across the brand.
