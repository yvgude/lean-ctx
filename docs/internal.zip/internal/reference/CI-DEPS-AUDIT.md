# D5 — Dependency, CI, and Build-System Audit

Date: 2026-08-20

Scope: GitHub Actions, Rust dependencies/workspace, published packages,
scripts/binaries/build entry points, tests, and benchmark/result directories.

Method: repository metadata, workflow trigger parsing, static dependency-use
heuristics, Cargo metadata, cargo-deny advisories, and textual reference scans.

Important limitation: \`cargo-udeps\` and \`cargo-outdated\` are not installed.

The dependency-use conclusion below is therefore a conservative static audit,
not a proof equivalent to a successful nightly \`cargo udeps\` run.

## Executive summary

- The repository has 17 workflow files; none is disabled.
- Nine workflows are automatic on push/PR, schedule, or issue activity.
- Eight workflows are manual/tag/release operations and remain active when invoked.
- \`ci.yml\` is intentionally broad and has a final aggregate \`CI Green\` gate.
- No stale first-party workflow path was found in the explicit action/path checks.
- \`rust/Cargo.toml\` declares 103 direct and 8 development dependencies.
- The Rust workspace contains 6 members, with only the engine as a default member.
- No unused direct Rust dependency was confirmed by the static audit.
- Two dependency-management debts deserve tracked follow-up: vendored \`rmcp\`
  and exact pre-release \`ort = 2.0.0-rc.12\`.
- The project publishes through crates.io, npm, PyPI, GitHub Releases,
  Homebrew, VS Code marketplaces, and two AUR package locations.
- The AUR source package has a nested Git repository with uncommitted edits;
  the parent repository does not surface those edits in its own status.
- \`scripts/\` mixes executable automation with 22 committed benchmark-result
  artifacts; that is the clearest repository-structure cleanup opportunity.
- \`bench/\`, \`benchmark/\`, and \`benchmarks/\` serve different purposes but
  their names are too similar to make ownership/self-service obvious.

## Vision used for assessment

The repository presents lean-ctx as a reliable, privacy-first context engine
with deterministic outputs, broad cross-platform support, public SDKs, and
auditable release provenance.

An item aligns when it preserves deterministic local development, protects
release integrity, or supports a clearly owned distribution channel.

An item needs cleanup when its role is ambiguous, it can silently drift, or
its directory name makes generated evidence look like source code.

## Workflow inventory

### 1. addon-versions.yml — Addon Registry Freshness

Current state: Active weekly Monday schedule, manual dispatch, and selective PR paths.

Build/test: Resolves pinned addon registry versions across upstream registries.

Aligns with vision: Yes; it prevents silent stale supply-chain pins.

Action needed: Keep; document its warn-on-PR versus strict-on-schedule behavior.

Risk level: Low.

Dependencies on it: \`rust/data/addon_registry.json\` and
\`scripts/check-addon-versions.py\`.

### 2. benchmark-study.yml — Benchmark Study

Current state: Active only through \`workflow_dispatch\`; it is not disabled.

Build/test: Runs model-backed benchmark suites with selectable arms and repeats.

Aligns with vision: Yes, as a deliberate non-PR research/evaluation workflow.

Action needed: Keep manual; add a short owner/retention note for uploaded studies.

Risk level: Low.

Dependencies on it: Python, Rust toolchain, benchmark harnesses, and model secrets.

### 3. ci.yml — CI

Current state: Active on pushes and pull requests to \`main\`, plus manual dispatch.

Build/test: Matrix test, clippy, minimal builds, formatting, cookbook/Pi/Rust/Python
SDKs, Hermes plugin, contract conformance, coverage, deny, adversarial tests,
benchmarks, quality gates, docs, and aggregate \`CI Green\`.

Aligns with vision: Yes; it is the core quality and portability control plane.

Action needed: Do not remove jobs wholesale; split its job catalogue into
documented tiers so required checks, release-only checks, and advisory checks
remain comprehensible.

Risk level: Medium, because job removal can weaken branch protection or platform support.

Dependencies on it: Rust engine, 62 Rust integration-test targets, all public SDKs,
the Hermes integration, documentation generators, security and release assumptions.

### 4. cla.yml — CLA Assistant

Current state: Active on issue comments and pull-request-target lifecycle events.

Build/test: Enforces contributor signature handling on the dedicated signatures branch.

Aligns with vision: Yes; it supports auditable public contribution flow.

Action needed: Keep; periodically validate the required PAT/secret and pinned action.

Risk level: Medium, because a token or action change can block external contributions.

Dependencies on it: \`CLA_SIGNATURES_TOKEN\`, \`cla-signatures\`, and contributor events.

### 5. codeql.yml — CodeQL

Current state: Active on main push/PR and weekly Monday schedule.

Build/test: Runs CodeQL analysis, including a Rust-specific analysis job.

Aligns with vision: Yes; security scanning is appropriate for a local proxy and daemon.

Action needed: Keep; pin/update the CodeQL action on the normal dependency cadence.

Risk level: Low.

Dependencies on it: GitHub Advanced Security/CodeQL availability and source buildability.

### 6. dep-update.yml — Dependency Auto-Update

Current state: Active only through manual dispatch.

Build/test: Performs compatible Cargo dependency maintenance and opens a PR.

Aligns with vision: Yes; major upgrades remain deliberately reviewed.

Action needed: Retain manual activation, but add a monthly calendar/issue reminder or
scheduled report-only mode so the workflow is not forgotten between advisories.

Risk level: Medium, because a default \`GITHUB_TOKEN\`-created PR does not trigger
the full CI suite; the workflow documents its optional PAT mitigation.

Dependencies on it: \`DEP_UPDATE_TOKEN\`, Cargo.lock, GitHub CLI, and CI workflow.

### 7. go-conformance.yml — Go SDK Conformance

Current state: Active on main push and PRs limited to Go SDK/OCLa wire schema paths.

Build/test: Installs Go and runs Go SDK conformance.

Aligns with vision: Yes; it protects the published wire contract without taxing all PRs.

Action needed: Keep; ensure any future contract location move updates both path filters.

Risk level: Low.

Dependencies on it: \`go-sdk/\` and \`docs/contracts/ocla-wire-v1.schema.json\`.

### 8. grammar-addons.yml — Grammar Addons

Current state: Active only through manual dispatch; it is a deliberate publish workflow.

Build/test: Discovers grammar cdylibs, builds platform matrix artifacts, publishes the
rolling grammar release, and regenerates the trusted registry through a PR.

Aligns with vision: Yes; publication is intentionally reviewed rather than per-commit.

Action needed: Keep; add an operator runbook and artifact-retention policy.

Risk level: Medium, because it mutates a release and opens a registry-update PR.

Dependencies on it: grammar workspace members, \`grammar-dlopen-host\`,
\`rust/data/grammar_registry.json\`, GitHub Release, and \`DEP_UPDATE_TOKEN\`.

### 9. history-audit.yml — Full History Audit

Current state: Active weekly Monday schedule and manual dispatch.

Build/test: Runs history-policy verification and produces an audit report.

Aligns with vision: Yes; it supports public-history and open-core boundary controls.

Action needed: Keep; ensure report retention is long enough for the security process.

Risk level: Low.

Dependencies on it: \`scripts/history-policy-gate.py\` and
\`scripts/generate-audit-report.py\`.

### 10. issue-reopen.yml — Issue reopen command

Current state: Active on issue-comment creation.

Build/test: Reopens an eligible issue when its original author uses \`/reopen\`.

Aligns with vision: Yes; it improves contributor support with bounded permissions.

Action needed: Keep; no build-system cleanup action.

Risk level: Low.

Dependencies on it: GitHub issue-comment events and issues-write token scope.

### 11. jetbrains-plugin.yml — JetBrains Plugin

Current state: Active for main pushes and PRs that touch plugin source or workflow.

Build/test: Actionlint, validation, Gradle build, and plugin tests.

Aligns with vision: Yes; it keeps editor integration independently verifiable.

Action needed: Keep; use the same pinned-action policy as the Rust CI where feasible.

Risk level: Low.

Dependencies on it: \`packages/jetbrains-lean-ctx/\`, Java, Gradle, and plugin tests.

### 12. publish-clients.yml — Publish /v1 clients

Current state: Active on \`client-v[0-9]*\` tags and manual dispatch.

Build/test: Publishes independent contract clients to npm, PyPI, and crates.io.

Aligns with vision: Yes; client versions intentionally do not follow engine releases.

Action needed: Keep; make the source directory for each of the three clients explicit
in a shared publication matrix or operator document.

Risk level: Medium, because public registry publication is irreversible.

Dependencies on it: \`NPM_TOKEN\`, \`PYPI_TOKEN\`, \`CARGO_REGISTRY_TOKEN\`,
and client package manifests.

### 13. publish-sdk.yml — Publish SDK

Current state: Active on \`sdk-v[0-9]*\` tags and manual dispatch.

Build/test: Publishes \`lean-ctx-sdk\` to npm and PyPI idempotently.

Aligns with vision: Yes; it supports a separately versioned drop-in SDK.

Action needed: Keep; assert npm and PyPI versions match before tag publication.

Risk level: Medium, because the two registries can partially succeed.

Dependencies on it: \`packages/node-lean-ctx/\`, \`packages/python-lean-ctx/\`,
\`NPM_TOKEN\`, and \`PYPI_TOKEN\`.

### 14. publish-vscode.yml — Publish VS Code Extension

Current state: Active on \`vscode-v*\` tags and manual dispatch.

Build/test: Packages a VSIX, optionally publishes to VS Code/Open VSX, uploads an
artifact, and creates a non-latest GitHub release for the extension.

Aligns with vision: Yes; it avoids editor releases hijacking binary-release latest.

Action needed: Keep; periodically test the token-absent packaging-only path.

Risk level: Medium, because marketplace releases are public and separately credentialed.

Dependencies on it: extension package, npm/npx, \`VSCE_PAT\`, and \`OVSX_PAT\`.

### 15. release.yml — Release

Current state: Active on true semver \`v[0-9]*\` tags.

Build/test: SDK gate, cross-platform binary builds, checksums/SBOM/provenance,
GitHub Release, JetBrains asset, crates/npm publish, Homebrew update, and announcements.

Aligns with vision: Yes; this is the release-integrity backbone.

Action needed: Keep; isolate its distribution-channel subjobs in a release runbook,
including failure/retry semantics and secret ownership.

Risk level: High, because it changes several public registries and release artifacts.

Dependencies on it: Cargo workspace, cross-compilers, GitHub Releases, cosign,
Homebrew tap, registry tokens, and announcement integrations.

### 16. secret-rotation-check.yml — Secret Rotation Check

Current state: Active monthly on the first day and manual dispatch.

Build/test: Checks secret-expiry policy and uploads an artifact.

Aligns with vision: Yes; release and publication channels require secret hygiene.

Action needed: Keep; route a failed run to a named maintainer escalation path.

Risk level: Low.

Dependencies on it: \`scripts/check-secret-expiry.py\`, GitHub token, and secret policy.

### 17. security-check.yml — Security Check

Current state: Active on main push and pull requests to main.

Build/test: Checks network libraries, unsafe code, environment manipulation,
secret patterns, injection vectors, unwrap policy, and public-boundary policy.

Aligns with vision: Yes; it enforces the repository's security and open-core posture.

Action needed: Keep; move complex shell checks into versioned Python/Rust helpers only
when doing so makes the policy easier to test, not merely for stylistic uniformity.

Risk level: Medium.

Dependencies on it: \`scripts/history-policy-gate.py\`, project path policy,
and shell-based security checks.

## Workflow cleanup findings

### WF-1 — No disabled workflow files

Current state: All 17 workflows have a reachable trigger.

Aligns with vision: Yes; manual-only workflows are intentional operational controls.

Action needed: No deletion; label manual-only workflows as \`operational\` in docs.

Risk level: Low.

Dependencies on it: Release, benchmark, grammar, and dependency-maintenance operations.

### WF-2 — CI complexity is a maintainability cost, not dead coverage

Current state: \`ci.yml\` has 19 jobs and a single \`CI Green\` aggregate gate.

Aligns with vision: Yes; the gate prevents silently missing required checks.

Action needed: Add a short job-tier map near the workflow or in contributor docs.

Risk level: Medium.

Dependencies on it: Branch protection configuration and every PR to \`main\`.

### WF-3 — First-party workflow paths appear live

Current state: The local composite action and sampled workflow paths exist.

Aligns with vision: Yes; no obvious dead directory reference was found.

Action needed: Keep a lightweight path-existence lint for local actions and path filters.

Risk level: Low.

Dependencies on it: \`.github/actions/windows-jemalloc\`, SDK/package directories,
Go schema paths, and release assets.

### WF-4 — Relative eval paths require working-directory context

Current state: CI comments reference \`eval/testbench\`; the material lives under
\`rust/eval/\`, so the path is valid only when the Rust working directory is active.

Aligns with vision: Mostly; this is correct but easy to misread during refactors.

Action needed: Make the relevant step's working directory explicit in its comment or
use a repository-root-qualified path.

Risk level: Low.

Dependencies on it: Quality-gate recordings and testbench lock files.

## Rust dependency audit

### Dependency inventory

Current state: \`rust/Cargo.toml\` has 103 direct dependencies and 8 dev dependencies.

Current state: Dev dependencies are criterion, filetime, insta, jsonschema,
proptest, serial_test, tempfile, and wat.

Current state: There are 22 named feature flags, including optional backends,
tree-sitter, neural/ORT, HTTP server, shape translation, and WASM.

Aligns with vision: Mostly; the feature matrix supports a broad engine surface.

Action needed: Treat dependency count as a budgeted architecture metric, not a mandate
to reduce it without measuring feature/user impact.

Risk level: Medium.

Dependencies on it: Core engine, optional remote/vector stores, parser support,
CLI, proxy/server, and all shipped platforms.

### DEP-1 — No confirmed unused direct dependency

Current state: \`cargo udeps\` is unavailable in this checkout.

Current state: A static source-and-feature reference heuristic initially flagged
\`md-5\` and \`yaml_serde\` only because their crate/import names differ.

Current state: \`md-5\` is imported as \`md5::{Digest, Md5}\`.

Current state: \`yaml_serde\` is referenced by Rust sources including YAML handling.

Aligns with vision: Yes; declared dependencies inspected have a concrete role.

Action needed: Do not remove a dependency from this audit alone.

Action needed: Add a periodic non-blocking dependency-use job when a stable,
reproducible tool choice is approved; make removals only after target/feature tests.

Risk level: Medium, because false positives from feature gates and crate aliases are easy.

Dependencies on it: All Cargo features and test targets.

### DEP-2 — \`ort\` is intentionally pinned to a release candidate

Current state: \`ort = "=2.0.0-rc.12"\` is optional and uses runtime dynamic loading.

Current state: The manifest explains the pin and advises revisiting it at stable 2.0.0.

Aligns with vision: Partly; exact pinning preserves reproducibility but RC retention
becomes technical debt when stable upstream releases.

Action needed: Create/retain a tracked review item for stable \`ort 2.0\` migration,
including Windows-GNU and runtime dylib verification.

Risk level: Medium.

Dependencies on it: Embeddings/neural features, Homebrew/AUR ONNX Runtime, and
cross-platform release builds.

### DEP-3 — Vendored \`rmcp\` patch has explicit removal debt

Current state: \`[patch.crates-io]\` redirects \`rmcp\` and \`rmcp-macros\`
to vendored workspace paths.

Current state: The manifest cites an upstream response-send task memory-growth issue
and a package-verification compile limitation.

Aligns with vision: Yes short term; the patch protects long-lived MCP sessions.

Action needed: Track upstream resolution and test removal on every deliberate rmcp bump.

Risk level: Medium.

Dependencies on it: MCP protocol implementation, publishing verification, and daemon RSS.

### DEP-4 — Advisory checking is present and clean

Current state: \`cargo deny 0.19.6\` is installed and \`cargo deny check advisories\`
completed successfully during this audit.

Aligns with vision: Yes; advisory checking belongs in release hygiene.

Action needed: Keep the existing \`deny\` CI job; do not treat a clean advisory scan
as evidence that pre-release or vendored maintenance debt disappeared.

Risk level: Low.

Dependencies on it: Cargo.lock and the advisory database configuration.

### DEP-5 — Dependency freshness tooling is not installed locally

Current state: \`cargo outdated\` is unavailable; \`dep-update.yml\` is the project
mechanism for patch/minor updates.

Aligns with vision: Mostly; manual update PRs reduce surprise churn.

Action needed: Use the workflow on a declared cadence or add report-only freshness output.

Risk level: Low.

Dependencies on it: Maintainer time, Cargo ecosystem update metadata, and DEP_UPDATE_TOKEN.

## Cargo workspace and publication

### WS-1 — Six-member workspace with one default member

Current state: Cargo metadata reports 6 workspace members and 1 default member.

Current state: The default member is the engine; SDK/addon/experiment members are opt-in.

Aligns with vision: Yes; ordinary engine commands remain predictable and fast.

Action needed: Keep the default-member boundary; document explicit commands for each
opt-in member next to the contributor workflow.

Risk level: Low.

Dependencies on it: Local developer commands, CI job scoping, and release jobs.

### WS-2 — Publication boundaries are explicit but distributed

Current state: \`lean-ctx\`, \`lean-ctx-ocla\`, and \`lean-ctx-protocol\` have
\`publish = null\` in metadata, meaning they are eligible for crates.io publication.

Current state: \`lean-ctx-sdk\`, grammar Lua, and grammar-dlopen-host have
\`publish = []\`, meaning publishing is forbidden.

Aligns with vision: Yes; release workflow publishes internal crates in dependency order.

Action needed: Keep the explicit \`publish = []\` boundaries and include them in
release review checks.

Risk level: Medium.

Dependencies on it: \`release.yml\`, crates.io tokens, and workspace version order.

### WS-3 — No workspace dependency table

Current state: The root manifest manages most versions directly rather than using
\`[workspace.dependencies]\`.

Aligns with vision: Mixed; only a few workspace crates reduce immediate duplication.

Action needed: Do not perform a blanket conversion; centralize only dependencies shared
by two or more owned crates when a future edit already touches them.

Risk level: Low.

Dependencies on it: Internal crates and future version synchronization.

## Package-manager and publication audit

### PKG-1 — Python SDK is PyPI-publishable

Current state: \`packages/python-lean-ctx/pyproject.toml\` defines
\`lean-ctx-sdk\` version 0.3.0, MIT, Python >=3.9.

Current state: It provides optional LangChain, LlamaIndex, and LiteLLM integrations.

Current state: \`publish-sdk.yml\` publishes it to PyPI using \`PYPI_TOKEN\`.

Aligns with vision: Yes; integrations remain optional rather than inflating base install.

Action needed: Keep Python and Node version synchronization as a release assertion.

Risk level: Medium.

Dependencies on it: Hatch/build configuration, PyPI token, and optional integrations.

### PKG-2 — Node SDK is npm-publishable

Current state: \`packages/node-lean-ctx/package.json\` defines public
\`lean-ctx-sdk\` version 0.3.0.

Current state: It has zero runtime dependencies, an optional \`ai >=3.0.0\` peer,
and TypeScript/Vitest development tooling.

Current state: \`prepublishOnly\` builds the distributable before registry upload.

Aligns with vision: Yes; a thin SDK with optional framework coupling is appropriate.

Action needed: Keep; pin or periodically refresh dev-tool major versions through the
manual dependency update process.

Risk level: Low.

Dependencies on it: npm, TypeScript, Vitest, and optional Vercel AI SDK consumers.

### PKG-3 — Additional npm channels are release-coupled

Current state: \`packages/lean-ctx-bin\` packages the binary launcher at engine 3.9.19.

Current state: \`packages/pi-lean-ctx\` is also version 3.9.19 and vendors its bundle
at prepack/pretest time.

Current state: \`release.yml\` publishes both after release gating.

Aligns with vision: Yes; the wrappers must follow the engine release.

Action needed: Retain the existing CI version-drift check and make its expected mapping
visible in package release documentation.

Risk level: Medium.

Dependencies on it: npm, engine GitHub Release assets, and Pi extension consumers.

### PKG-4 — crates.io publishing is active

Current state: The release workflow publishes OCLA, protocol, and engine crates.

Current state: The /v1 client workflow separately publishes \`lean-ctx-client\`.

Aligns with vision: Yes; independent client cadence is clearly separated.

Action needed: Keep idempotency checks; add a release dry-run checklist covering package
order and the vendored-rmcp package verification exception.

Risk level: High.

Dependencies on it: crates.io, CARGO_REGISTRY_TOKEN, Cargo package contents, and tags.

### PKG-5 — AUR source package has nested-repository drift risk

Current state: \`aur/lean-ctx\` contains tracked PKGBUILD and .SRCINFO files but also
contains its own \`.git\` directory connected to the AUR remote.

Current state: Its nested Git status reports modified \`.SRCINFO\` and \`PKGBUILD\`.

Current state: The parent repository's \`git status\` does not show those modifications
because the nested repository boundary hides them.

Aligns with vision: No; release metadata can drift invisibly from the parent audit trail.

Action needed: Decide the source of truth: make this a real submodule like the binary
package, or remove the nested \`.git\` directory and manage source PKGBUILD files in
the parent repository.

Risk level: High.

Dependencies on it: Arch source-package users, release versioning, checksums, and AUR push flow.

### PKG-6 — AUR binary package is an explicit submodule

Current state: \`aur/lean-ctx-bin\` is a Gitlink at commit
\`12993b161b6a75963df380d5bc31d52555e46a0d\`.

Current state: \`.gitmodules\` points to the AUR \`lean-ctx-bin.git\` remote.

Aligns with vision: Partly; submodule state is visible in the parent, but release
updates require a two-repository commit process.

Action needed: Keep only if the submodule workflow is documented and release-owned;
otherwise generate/push its PKGBUILD from the release pipeline.

Risk level: Medium.

Dependencies on it: Arch binary-package users, AUR remote, and release checksums.

## Scripts, binaries, and build entry points

### SCR-1 — Script directory mixes source automation and results

Current state: \`scripts/\` contains 71 files: 22 shell, 23 Python, 2 JSON, 2 Markdown,
1 extensionless helper, and 22 benchmark-result artifacts.

Current state: 30 files are executable.

Aligns with vision: Mixed; executable helpers are useful, committed run results under
the same tree are confusing and inflate ownership ambiguity.

Action needed: Move committed script-benchmark evidence to a clearly named
\`benchmarks/evidence/\` or \`artifacts/benchmark/\` location, preserving provenance.

Risk level: Low.

Dependencies on it: Benchmark reporting, repository navigation, and any docs that link results.

### SCR-2 — Only a minority of scripts are CI-referenced

Current state: 9 executable/helper scripts have direct workflow references.

Current state: CI-referenced scripts include addon/package/SDK version checks,
SDK conformance, history policy/audit, LOC gate, release helper, and secret expiry.

Aligns with vision: Yes; CI uses purpose-specific small helpers.

Action needed: Mark remaining scripts as developer, benchmark, pilot, or retired
in a \`scripts/README.md\`; do not delete based solely on a textual-reference scan.

Risk level: Low.

Dependencies on it: Local maintainer workflows, benchmark studies, and pilot operations.

### SCR-3 — Unreferenced scripts need ownership review, not blind deletion

Current state: A textual scan found several unreferenced pilot, agent-monitoring,
benchmark, demo, and report-generation scripts.

Current state: Examples include multi-IDE benchmarking, pilot setup, agent-start/monitor
variants, chaos restart, benchmark generators, and outcome-pricing demo helpers.

Aligns with vision: Unknown until an owner/retention decision is recorded.

Action needed: Inventory each under \`scripts/README.md\` with owner, invocation,
input/output location, and planned removal date where experimental.

Risk level: Medium.

Dependencies on it: Maintainer operations and historical benchmark reproducibility.

### SCR-4 — Makefile is a local developer entry point

Current state: A Makefile exists; no justfile exists.

Current state: Its phony targets are setup-hooks, install, dev, test, preflight,
preflight-fast, enterprise-ci-check, and help.

Aligns with vision: Yes; it gives contributors a compact local workflow.

Action needed: Keep; add \`make preflight\` to contributor documentation as the
supported local equivalent of deterministic CI checks.

Risk level: Low.

Dependencies on it: Rust toolchain, hooks, and optional enterprise checkout.

### SCR-5 — bin/lctx is a standalone agent launcher

Current state: \`bin/lctx\` is the only top-level binary helper.

Current state: It locates lean-ctx and launches/configures supported coding agents.

Aligns with vision: Yes; it supports multi-agent onboarding without changing the engine.

Action needed: Keep; clarify whether it is a supported public interface or developer
convenience, then test its documented agent choices accordingly.

Risk level: Low.

Dependencies on it: Installed/release lean-ctx binary and external agent CLIs.

## Test and benchmark infrastructure

### TEST-1 — Rust integration tests are intentionally numerous

Current state: Cargo metadata reports 62 Rust integration-test targets.

Current state: The root package also has 3 Criterion benchmark targets,
11 example targets, one binary, one library, and a build script.

Aligns with vision: Yes; the tests cover contracts, installation, security,
provenance, workflow behavior, and end-to-end agent scenarios.

Action needed: Do not consolidate merely to reduce file count; use CI timing data to
merge only test binaries whose isolation adds no diagnostic value.

Risk level: Medium.

Dependencies on it: \`ci.yml\` test matrix, linker/disk pressure controls, and coverage.

### TEST-2 — Root Python tests serve delivery/security policy

Current state: \`tests/\` contains Python tests in delivery, security, and OCLA contract
suite areas.

Aligns with vision: Yes; these validate repository and release policy outside the Rust
runtime test surface.

Action needed: Keep; add a short tests README identifying which workflow invokes each area.

Risk level: Low.

Dependencies on it: Delivery verification scripts, branch protection policy,
secret-expiry controls, and OCLA contract artifacts.

### TEST-3 — test-results is a local run marker

Current state: \`test-results/\` contains only \`.last-run.json\` (45 bytes),
currently recording \`status: failed\` with an empty failed-test list.

Aligns with vision: Mixed; a local marker is fine, but its status is ambiguous and it
should not be confused with authoritative CI evidence.

Action needed: Either gitignore and document it as transient local state, or rename it
to \`.local-test-state/\` and record timestamp/tool/version/exit-code semantics.

Risk level: Low.

Dependencies on it: Local test runner/UI only; no workflow dependency was identified.

### BENCH-1 — Three similarly named benchmark trees have distinct roles

Current state: \`bench/\` contains active harnesses and research material:
agent-task, compression, lifecycle, and research.

Current state: \`benchmark/\` contains a legacy-style runner, LOCOMO material, and
named JSON result files.

Current state: \`benchmarks/\` contains dated benchmark evidence, reports, and
efficiency/task-spine material.

Aligns with vision: Partly; roles are real but directory names conceal the distinction.

Action needed: Choose one naming scheme, preferably:
\`bench/harnesses/\`, \`bench/fixtures/\`, and \`benchmarks/results/\`.

Risk level: Medium.

Dependencies on it: Benchmark Study workflow, Rust Criterion benches,
LOCOMO smoke tests, reproducibility reports, and documentation links.

### BENCH-2 — Result retention policy is missing from the tree layout

Current state: Committed benchmark results exist in \`scripts/benchmark/results/\`,
\`benchmark/results/\`, \`benchmark/locomo/results/\`, and \`benchmarks/\`.

Aligns with vision: Mixed; committed evidence is valuable, but multiple result roots
make it unclear which are baselines, latest snapshots, or disposable runs.

Action needed: Define a retention policy with one canonical result root, a stable
baseline naming convention, and explicit generated/local ignores.

Risk level: Low.

Dependencies on it: Performance regression evaluation, release evidence, and docs.

## Prioritized cleanup plan

1. Resolve AUR source-package nested Git ownership before the next release.

2. Add a short workflow catalogue that labels CI, scheduled audit, manual operation,
tag publication, and issue automation workflows.

3. Separate benchmark evidence from \`scripts/\` and define one results retention policy.

4. Add \`scripts/README.md\` with owner/status for pilot, benchmark, demo, and agent
operations helpers; decide retain/archive/delete from that review.

5. Document the purpose of the three benchmark trees and migrate only under a
compatibility plan that updates CI/docs links.

6. Track \`ort\` stable migration and vendored \`rmcp\` removal against upstream.

7. Add a recurring dependency freshness review or report-only automation, preserving
manual review for incompatible versions.

8. Consider a non-blocking dependency-use check after selecting a reproducible,
maintained tool; do not add a nightly-only gate casually.

## Non-actions

- Do not delete manual workflows merely because they lack push/PR triggers.

- Do not collapse CI jobs without checking branch-protection and release dependencies.

- Do not remove optional Cargo dependencies from name-based static heuristics alone.

- Do not flatten the Cargo workspace default-member boundary; it protects common
engine developer commands from unrelated SDK/addon work.

- Do not delete benchmark artifacts before classifying baseline versus generated evidence.

## Audit conclusion

The system is actively maintained rather than burdened by abandoned CI files.

The strongest cleanup gains are structural and operational: make workflow ownership
visible, turn script/benchmark retention into an explicit policy, and eliminate the
invisible nested-Git drift risk in \`aur/lean-ctx\`.

The dependency surface is large but largely justified by feature breadth. The safer
path is managed reduction and tracked upstream debt, not speculative dependency removal.
