# D2 — Non-Rust Package Audit

## Execution status — 2026-08-21

**This audit is historical.** The recommended archive/delete actions were executed on 2026-08-20 (`8ea700f`, `6ff1e48`, `235d135`). Do not treat KEEP rows for `go-sdk/`, `vscode-extension/`, `packages/jetbrains-lean-ctx/`, or `benchmarks/` as current policy — those trees now live under `_archive/`.

Current active non-Rust surfaces:
- `packages/python-lean-ctx/` — canonical Python SDK
- `packages/node-lean-ctx/` — canonical Node SDK
- `clients/rust/lean-ctx-client/` — stable HTTP client crate
- `cookbook/sdk/` — documented TypeScript HTTP SDK (examples)
- `docs/contracts/` — wire contracts (includes merged OCLA proto/manifests)
- `scripts/benchmark/` — canonical benchmark entry
- Editor plugins (VS Code, JetBrains, Chrome, Emacs, Neovim, Sublime, Pi) and `go-sdk/` are **archived**, not currently supported product surfaces

See `_archive/README.md` and [`MASTER-EXECUTION-PLAN.md`](../execution/MASTER-EXECUTION-PLAN.md).

## Scope

This audit covers every directory named in the D2 brief.

It intentionally does not modify or delete repository content.

The target is one coherent product: lean-ctx core, supported integrations,
and a small, explicitly-versioned public client surface.

The target is not to erase historical work or silently strand installed users.

## Evidence collected

The inventory was taken from the current worktree on 2026-08-20.

Counts exclude generated `node_modules`, `target`, `.venv`, and `__pycache__`.

`tracked` means files in the current Git index, not files merely present locally.

Untracked/ignored directories require extra care: they can be local operator data.

Workflow references are stronger evidence of a supported surface than README links.

An absence of an in-repo workflow is not proof that no user installed a package.

Registry ownership, download history, and external deployment configuration were
not changed or queried by this audit and are mandatory removal gates.

## Decision vocabulary

**KEEP** means retain at its current path as a supported product surface.

**CONSOLIDATE** means migrate code, tests, and users to one destination first.

**ARCHIVE** means remove from the active tree only after preserving a tagged,
read-only source snapshot and publishing a migration/deprecation notice.

**DELETE** means remove only disposable residue after the stated verification.

No action below authorizes an immediate recursive deletion command.

## Executive decision

Keep six active surfaces: canonical Python SDK, canonical Node SDK, Go SDK,
VS Code, JetBrains, the active benchmark suite, and protocol contracts.

Consolidate four duplicate SDK/design surfaces: old Python client, OCLA Python
SDK, standalone TypeScript SDK, and task specifications.

Archive editor adapters without release/test automation, launch collateral,
research material, legacy benchmarks, community bots/workflows, and historical
blog material after a compatibility window.

Delete only clearly disposable residue: `cloud/`'s lone `.DS_Store`, stale
`pi-lean-ctx` references if any are found, and regenerated ignored bench output.

The sharpest duplication is Python: four distributions expose overlapping
lean-ctx/OCLA clients with four names and two import namespaces.

The second duplication is TypeScript: `packages/node-lean-ctx` and `ts-sdk`
both implement a JavaScript/TypeScript client, but only the former is published.

## Confirmed release and CI edges

`publish-sdk.yml` publishes `packages/node-lean-ctx` to npm as `lean-ctx-sdk`.

`publish-sdk.yml` publishes `packages/python-lean-ctx` to PyPI as `lean-ctx-sdk`.

`publish-clients.yml` publishes `clients/python` to PyPI as `lean-ctx-client`.

`ci.yml` explicitly includes `clients/python` and `python-sdk` checks.

`publish-vscode.yml` packages and publishes `vscode-extension` to Marketplace
and Open VSX.

`jetbrains-plugin.yml` builds and tests `packages/jetbrains-lean-ctx`.

`release.yml` also builds the JetBrains plugin during a binary release.

`go-conformance.yml` exercises `go-sdk` against the contracts.

`ci.yml` executes `python benchmarks/run.py`; `benchmarks/` is active.

`contracts/` is referenced by Go conformance, security checks, and the
proprietary pre-push guard.

## Recommended destination map

`packages/python-lean-ctx` remains the only maintained Python SDK source.

`packages/node-lean-ctx` remains the only maintained TypeScript/Node SDK source.

`go-sdk` remains the sole Go SDK until a deliberate multi-language policy says
otherwise.

`vscode-extension` and `packages/jetbrains-lean-ctx` are the supported editor
matrix.

`contracts/ocla` remains the wire-contract authority, not a copy in any SDK.

`benchmarks/` remains the executable benchmark authority.

Historical material moves to an external `lean-ctx-archive` repository or a
versioned release asset, never an unannounced deletion.

## Python SDKs

### `packages/python-lean-ctx/`

**Action: KEEP.**

Inventory: 20 files present; 13 Python-code files; 15 files tracked.

Manifest: `pyproject.toml` declares `lean-ctx-sdk` version `0.3.0`.

Description: “SDK for lean-ctx — context compression for AI agents”.

Contains: `lean_ctx/client.py`, `discovery.py`, `errors.py`, and `proxy.py`.

Contains integration modules for LangChain, LiteLLM, and LlamaIndex.

Contains focused tests for discovery, proxy, LiteLLM, and LangChain compression.

Real code status: real implementation with tests, not a stub.

Product fit: exact fit for a product-facing, drop-in Python integration SDK.

Dependency signal: `publish-sdk.yml` publishes this directory to PyPI.

Deletion risk: critical; deleting breaks the current SDK release pipeline and
future source releases for existing PyPI users.

Safe strategy: retain path, package name, import namespace, and release tag
scheme as the canonical Python contract.

Safe strategy: absorb unique capabilities from the other Python attempts here.

Safe strategy: add contract/conformance tests before retiring a legacy client.

### `clients/python/`

**Action: CONSOLIDATE.**

Inventory: 35 files present; 21 Python-code files; 25 files tracked.

Manifest: `pyproject.toml` declares `lean-ctx-client` version `0.1.0`.

Description: thin, dependency-free Python client for the lean-ctx HTTP `/v1`
contract.

Contains `leanctx/`, tests, README, and an `leanctx.egg-info` artifact.

Real code status: a substantive tested HTTP/OCLA client, not an empty attempt.

Product fit: overlaps the canonical Python SDK but can serve compatibility users.

Dependency signal: `ci.yml` tests it and `publish-clients.yml` publishes it.

Deletion risk: high; PyPI users may import `leanctx` and depend on the thinner
HTTP behavior, and a client release workflow would fail.

Safe strategy: declare `lean-ctx-client` deprecated, with a documented mapping
from `leanctx` imports and APIs to canonical `lean_ctx` APIs.

Safe strategy: maintain a compatibility wheel/shim for at least two release
cycles after the canonical SDK gains every supported HTTP feature.

Safe strategy: remove its publish job only after registry download analysis,
consumer notice, migration tests, and a final security-fixes policy are agreed.

### `py-sdk/`

**Action: ARCHIVE.**

Inventory: 10 files present; 4 Python-code files; 5 files tracked.

Manifest: `pyproject.toml` declares `leanctx` version `0.1.0`.

Description: Python SDK for the lean-ctx OCLA wire API.

Contains `leanctx/client.py`, `types.py`, package initializer, and one client
test suite.

Real code status: small real client, but materially smaller than the canonical
SDK and duplicate clients.

Product fit: OCLA is aligned; this third Python package name is not.

Dependency signal: no direct CI, publish-workflow, README, Makefile, or
contributing-guide path reference was found.

Deletion risk: moderate externally because the unscoped PyPI name may have
users even though the repository currently has no release automation for it.

Safe strategy: tag the final source, preserve it in an archive repository, and
publish a PyPI deprecation message pointing to `lean-ctx-sdk`.

Safe strategy: first port any distinct types/client behavior to the canonical
SDK and add wire-compatibility tests.

Safe strategy: do not delete or yank the published artifact without package
ownership, download, and dependency checks.

### `python-sdk/`

**Action: CONSOLIDATE.**

Inventory: 11 files present; 5 Python-code files; 6 files tracked.

Manifest: `pyproject.toml` declares `lean-ctx-ocla` version `0.1.0`.

Description: async Python client for the lean-ctx OCLA Wire API.

Contains `lean_ctx/client.py`, `models.py`, `streaming.py`, and client tests.

Real code status: small but real implementation; async SSE streaming is a
capability worth preserving.

Product fit: protocol support fits, but a fourth Python distribution does not.

Dependency signal: `ci.yml` references this path; no dedicated publishing
workflow was found.

Deletion risk: medium; CI currently depends on it and consumers may use async
streaming that the canonical package has not yet matched.

Safe strategy: port `models.py` and async streaming behavior into
`packages/python-lean-ctx`, with behavior-level compatibility tests.

Safe strategy: replace the CI path with canonical-package tests only after
imports, errors, streaming semantics, and examples have a migration guide.

Safe strategy: then archive the source and leave a read-only compatibility tag.

## Editor extensions

### `packages/chrome-lean-ctx/`

**Action: ARCHIVE.**

Inventory: 14 tracked files; 4 JavaScript-code files; browser manifest present.

Contains extension manifest, background/content/popup code, CSS, icons, and a
native-host bridge implemented with `bridge.py`, `bridge.sh`, and `install.sh`.

Contains a `managed_schema.json` for managed extension configuration.

Real code status: real extension implementation, not a scaffold.

Product fit: adjacent to browser-based agent workflows, but not a core editor
or SDK surface in the present release model.

Dependency signal: no dedicated CI, test, or publishing workflow path was found.

Deletion risk: medium; side-loaded enterprise installations may use the native
host and managed schema even without a repository release workflow.

Safe strategy: make a final signed/tagged browser-extension release and retain
the native-host installer in an archive/release asset.

Safe strategy: publish an explicit support-status page before removing source
from the primary tree.

Safe strategy: delete only after managed-policy customers confirm a migration
or formal end-of-life date.

### `packages/emacs-lean-ctx/`

**Action: ARCHIVE.**

Inventory: 1 tracked file; 1 Emacs Lisp implementation file.

Contains only `lean-ctx.el`.

Real code status: a minimal adapter, not an empty directory.

Product fit: the editor concept fits, but one untested single-file adapter does
not justify an equal supported-product tier.

Dependency signal: no CI, packaging, or release workflow path was found.

Deletion risk: low in-repo and unknown externally for manual Emacs users.

Safe strategy: preserve the file in the archive repository and publish install
instructions that point to the immutable tag.

Safe strategy: announce “community-maintained / archived” rather than silently
removing an existing Elisp integration.

Safe strategy: remove it from the active checkout only after docs stop calling
it supported.

### `packages/jetbrains-lean-ctx/`

**Action: KEEP.**

Inventory: 86 tracked files; 74 Java/Kotlin-code files; Gradle Kotlin build.

Contains Gradle wrapper/build metadata plus `src/main` and `src/test` trees.

Real code status: substantial tested IDE plugin, not a prototype.

Product fit: strong; it is a direct IDE integration for core lean-ctx users.

Dependency signal: `jetbrains-plugin.yml` triggers on its changes, runs checks,
builds the plugin, and uploads test reports.

Dependency signal: `release.yml` builds the plugin as part of binary release.

Deletion risk: critical; current CI/release automation and installed JetBrains
users depend on it.

Safe strategy: retain it as one of only two first-party supported editor targets.

Safe strategy: define ownership, compatibility matrix, and release cadence
alongside VS Code rather than adding more editors by default.

Safe strategy: only reconsider after product telemetry and a replacement support
policy exist.

### `packages/neovim-lean-ctx/`

**Action: ARCHIVE.**

Inventory: 4 tracked files; 3 Lua/Vim-code files.

Contains a Lua `lean-ctx` module and `plugin/lean-ctx.vim` loader.

Real code status: small working adapter, not an empty placeholder.

Product fit: editor integration fits broadly, but no active support signal
distinguishes it from an abandoned community adapter.

Dependency signal: no CI, test, package, or release workflow path was found.

Deletion risk: low in-repo; unknown for users installing directly from Git.

Safe strategy: transfer to or create a community-maintained repository with a
final compatibility tag and README migration notice.

Safe strategy: keep a small archived index entry; do not retain a full release
burden in the core product repository.

Safe strategy: remove active-tree source after the repository URL and support
status are communicated.

### `packages/sublime-lean-ctx/`

**Action: ARCHIVE.**

Inventory: 3 tracked files; 1 Python plugin file.

Contains `lean_ctx.py`, command definitions, and a main menu definition.

Real code status: minimal but real Sublime Text plugin.

Product fit: peripheral; it has no evidence of a maintained release path.

Dependency signal: no CI, package-control publishing, or release workflow path
was found.

Deletion risk: low in-repo and unknown for users with a manual install.

Safe strategy: archive the three files with an immutable version tag and clear
community-support status.

Safe strategy: retain an installation pointer in documentation for one release
cycle.

Safe strategy: then remove this top-level package from the active product tree.

### `vscode-extension/`

**Action: KEEP.**

Inventory: 63 source/artifact files present after excluding `node_modules`;
31 TypeScript/JavaScript source files; 25 files tracked.

Contains TypeScript source, resources, packaging metadata, README, changelog,
and a locally present `.vsix` plus generated `out/` output.

Real code status: substantial extension implementation with active packaging.

Product fit: strongest editor surface; VS Code is the release-automated IDE
integration.

Dependency signal: `publish-vscode.yml` packages for Marketplace and Open VSX.

Deletion risk: critical; published-extension users and release automation break.

Safe strategy: retain source at this path until a deliberate repository layout
migration preserves extension identifiers and Marketplace continuity.

Safe strategy: separately delete ignored/generated `node_modules`, `out/`, and
old local `.vsix` artifacts only after confirming they are reproducible.

Safe strategy: ensure build output and package artifacts remain ignored, not
committed as another product source tree.

## Other SDKs

### `packages/node-lean-ctx/`

**Action: KEEP.**

Inventory: 13 tracked files; 9 TypeScript-code files; npm manifest present.

Manifest: `lean-ctx-sdk` version `0.3.0` with product-facing description.

Contains client, discovery, error, proxy, and Vercel AI integration modules.

Contains tests for discovery, proxy, and Vercel AI behavior.

Real code status: real tested SDK, not a skeleton.

Product fit: exact canonical Node/TypeScript SDK for the product vision.

Dependency signal: `publish-sdk.yml` publishes this exact directory to npm.

Deletion risk: critical; it is a current package source and release dependency.

Safe strategy: make this the only TypeScript SDK implementation.

Safe strategy: absorb any unique OCLA streaming code from `ts-sdk` here.

Safe strategy: preserve package name and public exports while consolidating.

### `go-sdk/`

**Action: KEEP.**

Inventory: 6 tracked files; 5 Go-code files; `go.mod` module declared.

Module: `github.com/yvgude/lean-ctx/go-sdk`, targeting Go 1.21.

Contains client, streaming, types, unit tests, and conformance tests.

Real code status: concise real SDK with an explicit conformance layer.

Product fit: aligned if multi-language OCLA clients remain a product promise.

Dependency signal: `go-conformance.yml` references this SDK and contracts.

Deletion risk: high; conformance coverage and any Go consumers would break.

Safe strategy: retain while it satisfies an explicit maintained-language policy.

Safe strategy: centralize protocol fixtures under `contracts/`, never duplicate
wire types as separate specifications.

Safe strategy: if Go is later dropped, deprecate module releases before archive.

### `ts-sdk/`

**Action: CONSOLIDATE.**

Inventory: 16 files present; 13 TypeScript/JavaScript files; 7 files tracked.

Manifest: `@lean-ctx/ocla-sdk` version `0.1.0`.

Description: standalone TypeScript client for the OCLA Wire API.

Contains source, tests, generated `dist/`, package lock, and TypeScript config.

Real code status: real small SDK with client, types, and streaming modules.

Product fit: protocol capability fits; a second TypeScript package conflicts with
the canonical published Node SDK.

Dependency signal: no dedicated CI or publish workflow path was found.

Deletion risk: medium externally because npm users may import the scoped OCLA
package, despite no active in-repo release automation.

Safe strategy: merge useful streaming/types behavior into `packages/node-lean-ctx`.

Safe strategy: publish a deprecated final `@lean-ctx/ocla-sdk` release that
points to `lean-ctx-sdk`, with an API migration guide.

Safe strategy: archive source after tests are moved and registry consumers have
a documented transition window.

## Community, operations, and collateral

### `discord-bot/`

**Action: ARCHIVE.**

Inventory: 16 local files; 3 Python-code files; 0 files tracked.

Contains `docs_index.py`, `llm.py`, `spam_filter.py`, and a 11-topic knowledge
base covering setup, MCP tools, configuration, troubleshooting, and Windows.

Real code status: real local bot code, but intentionally absent from Git.

Product fit: support operations, not the core product distributable.

Dependency signal: last history says the private bot was untracked; the security
workflow mention is a guard, not a build or deploy dependency.

Deletion risk: high for operators if this worktree is their live private bot.

Safe strategy: move it to its private deployment repository with secrets and
deployment documentation; do not delete it from a developer checkout blindly.

Safe strategy: consume the knowledge articles from `docs/` or a docs build,
then delete duplicated local copies only in that private repository.

Safe strategy: keep the public repository free of untracked operational code.

### `discord-faq/`

**Action: CONSOLIDATE.**

Inventory: 11 tracked Markdown files; no executable code.

Contains the same 11 support topics represented in `discord-bot/knowledge`.

Real code status: documentation only; it is a content duplication, not a stub.

Product fit: support documentation fits, but a standalone top-level FAQ does not.

Dependency signal: root `README.md` references this directory.

Deletion risk: low technically; broken README links and Discord support links are
the primary risk.

Safe strategy: move canonical FAQ pages under the main documentation tree.

Safe strategy: repoint README, Discord, and bot index links in the same change.

Safe strategy: retain a redirect/index page for one release before removal.

### `n8n-workflows/`

**Action: ARCHIVE.**

Inventory: 5 local files; one JavaScript/CJS workflow helper; 0 files tracked.

Contains `daily-tweets.json`, release tweet JSON, README, and tweet generators.

Real code status: local automation, not an empty legacy folder.

Product fit: social-media operations, not product runtime or SDK surface.

Dependency signal: history explicitly records removal from the repository; the
security workflow mention is a guard rather than an execution dependency.

Deletion risk: medium operationally if an n8n instance imports these workflows.

Safe strategy: export/import them into the operations repository with a named
owner and external secret configuration.

Safe strategy: record n8n workflow IDs and a final export before removal.

Safe strategy: do not recreate the folder in public Git after it is archived.

### `cloud/`

**Action: DELETE.**

Inventory: one local `.DS_Store`; zero code and zero tracked files.

Real code status: no cloud implementation is present in this worktree.

Product fit: none in its current state; it is filesystem residue, not a package.

Dependency signal: README/security textual references exist, but no source path
or workflow build dependency was found.

Deletion risk: negligible if the directory is confirmed not to be a mount point
or a placeholder for a separately deployed cloud repository.

Safe strategy: inspect any cloud deployment repository/remote first.

Safe strategy: remove only the local `.DS_Store` directory after that check.

Safe strategy: repair any README link that falsely implies source lives here.

### `marketing/`

**Action: ARCHIVE.**

Inventory: 15 local files; 14 tracked; no executable code.

Contains launch copy, Product Hunt/Show HN/community submissions, sponsor tiers,
funding documents, terminal tapes, GIF, MP4, and gallery images.

Real code status: content assets only, not a product component.

Product fit: useful company collateral but dilutes the product source tree.

Dependency signal: no dedicated CI, build, or root-doc reference was found.

Deletion risk: low for product runtime; moderate for marketing history and media
links outside the repository.

Safe strategy: move to a marketing/content repository or release archive with
permalink-preserving assets.

Safe strategy: inventory externally embedded image/video URLs before moving.

Safe strategy: remove the top-level directory only after redirects are live.

### `email-templates/`

**Action: CONSOLIDATE.**

Inventory: 3 tracked text files; no executable code.

Contains overview, password-reset, and verification email templates.

Real code status: operational content, not a code stub.

Product fit: valid account-service collateral, but it lacks a consuming service
in this repository.

Dependency signal: templates only reference each other through `OVERVIEW.txt`;
no external in-repo consumer was found.

Deletion risk: medium outside Git if a deployed auth service copies these files.

Safe strategy: place templates with the service that renders them, or under
`docs/operations/email/` if they are canonical human-maintained templates.

Safe strategy: add a rendered-template test in the destination before removal.

Safe strategy: preserve subject/body variables and support-address policy.

### `demo/`

**Action: CONSOLIDATE.**

Inventory: 4 tracked terminal tape files; no executable code.

Contains `benchmark.tape`, `gain.tape`, `leanctx.tape`, and `pr-pack.tape`.

Real code status: reproducible demonstration inputs, not a package.

Product fit: strongly aligned as documentation/demo material.

Dependency signal: root `README.md` references the tape files.

Deletion risk: low runtime risk but direct documentation links will break.

Safe strategy: move tapes under `docs/demos/` or the documentation asset tree.

Safe strategy: update README links atomically and include generated media only
when reproducible from the tapes.

Safe strategy: do not delete until the recorded commands still run on a release.

### `lab/`

**Action: ARCHIVE.**

Inventory: 18 local files; 15 Python-code files; 0 tracked files.

Contains corpus collection/transforms, experiments, attention maps, tokenizer
benchmarks, distillation/training code, results, and `requirements.txt`.

Real code status: substantive experimental/research code, not a stub.

Product fit: valuable research, but it is not a releaseable core component.

Dependency signal: textual references occur in templates and docs; no tracked
source, package manifest integration, or release path owns it.

Deletion risk: high for an individual researcher; low for the committed product.

Safe strategy: establish a separate private or public research repository with
environment lockfile, datasets policy, and reproducibility instructions.

Safe strategy: snapshot results and dataset provenance before moving it.

Safe strategy: remove ignored worktree copies only after their owner confirms.

### `blog/`

**Action: ARCHIVE.**

Inventory: one tracked Markdown file, `twir-lean-ctx.md`; no code.

Real code status: historical written content only.

Product fit: company communications, not the core source distribution.

Dependency signal: no CI or root-document path reference was found.

Deletion risk: low runtime; possible broken external canonical URLs.

Safe strategy: move to the website/content repository with a stable permalink.

Safe strategy: retain Git history or a release-archive copy for citation.

Safe strategy: remove only after external links are redirected or accepted as
historical URLs.

### `lean/`

**Action: ARCHIVE.**

Inventory: 143 local files; 12 Lean-code files; 19 files tracked.

Contains a standalone Lean project: `lakefile.toml`, toolchain, proofs, paper,
and generated `.lake/build` output.

Contains proof areas for basic properties, compression, handoff, and policy.

Real code status: real formal-methods/research project, not a placeholder.

Product fit: intellectually aligned but disconnected from the release/runtime
pipeline and does not belong in the lean core product checkout.

Dependency signal: no CI, release workflow, or root documentation path reference
was found.

Deletion risk: low for product runtime; medium for research claims and paper
reproducibility.

Safe strategy: relocate intact to a `lean-ctx-formal` repository preserving
toolchain and lockfile, with a tag referenced by any product claims.

Safe strategy: remove generated `.lake/build` before archival commit if it is
reproducible; retain source, paper, and pinned toolchain.

Safe strategy: do not delete proofs until public documentation no longer cites
unarchived paths.

### `pi-lean-ctx/`

**Action: DELETE (stale reference only).**

Inventory: directory is absent from the current worktree; no files or manifest
could be inspected.

Real code status: none present.

Product fit: cannot be evaluated without source; it should not appear in an
active product inventory as a phantom package.

Dependency signal: no reliable tracked source or workflow dependency was found.

Deletion risk: none for the current checkout; the only risk is a stale external
link or an unmounted local checkout.

Safe strategy: search documentation, release scripts, and external automation
for the exact string before removing references.

Safe strategy: if it is an intended Raspberry Pi integration, restore it only
as a separately owned, versioned integration project.

Safe strategy: otherwise delete stale index entries rather than creating another
placeholder directory.

## Benchmark, specifications, and contracts

### `benchmark/`

**Action: ARCHIVE.**

Inventory: 8 local files; no executable source; 7 files tracked.

Contains benchmark Markdown, LoCoMo material, stored result JSON, and
`run_benchmark.sh`.

Real code status: legacy study data/scripts rather than maintained benchmark
implementation.

Product fit: evidence and historical claims are useful, but the singular folder
duplicates the active `benchmarks/` naming and confuses ownership.

Dependency signal: README and generic benchmark workflow text mention it; no
exact `benchmark/` path reference was found in GitHub workflows.

Deletion risk: low runtime; medium for links and reproducibility of published
benchmark claims.

Safe strategy: tag/archive it as a dated study, including raw inputs, command,
environment notes, and result provenance.

Safe strategy: update README references to a stable archive URL.

Safe strategy: do not merge historical result JSON into active test fixtures.

### `benchmarks/`

**Action: KEEP.**

Inventory: 126 tracked files; one Python entrypoint plus benchmark corpus/data.

Real code status: active benchmark suite and fixtures, not just checked-in output.

Product fit: strong; performance/context-quality validation belongs with core.

Dependency signal: `ci.yml` runs `python benchmarks/run.py` with controlled
turns, needles, context length, and base URL.

Deletion risk: high; CI coverage and performance regression visibility break.

Safe strategy: make `benchmarks/` the single authoritative executable benchmark
location.

Safe strategy: move only reusable harness source from `bench/` here after
ensuring CI remains deterministic.

Safe strategy: retain data licenses, expected results, and command-line contract.

### `bench/`

**Action: CONSOLIDATE.**

Inventory: 26,111 local files; 10,287 code-like files before generated exclusion;
only 36 files are tracked.

The size disparity is strong evidence of ignored/generated dependencies or build
output dominating a small tracked harness.

Real code status: a real local benchmark/evaluation harness surrounded by a very
large amount of non-source residue.

Product fit: evaluation tooling fits only if it has an owner and a reproducible
relationship to `benchmarks/`.

Dependency signal: workflow hits for `bench/` are actually `eval/testbench`
references; no exact active `bench/` workflow path was found.

Deletion risk: low for the committed release, but potentially high for local
researchers relying on untracked datasets/environments.

Safe strategy: identify the 36 tracked files, move the maintained harness into
`benchmarks/` or a dedicated external evaluation repository.

Safe strategy: regenerate or remove ignored dependencies, caches, virtualenvs,
and reports after a reproducible setup command is documented.

Safe strategy: never bulk-delete the directory until its untracked data owner
confirms an archive/checksum.

### `specs/`

**Action: CONSOLIDATE.**

Inventory: 16 tracked Markdown files; no executable code.

Contains issue-scoped plans/specs/tasks for 899, 907, 1008, and 1253 plus a
template.

Real code status: maintained design records, not stubs.

Product fit: design history is useful; a root-level parallel documentation tree
is not a lasting product surface.

Dependency signal: contributing and dependency-update workflow documentation
refer to it.

Deletion risk: low runtime; medium for contributor process and historical
decision context.

Safe strategy: move completed records to `docs/decisions/` or
`docs/internal/specs/`, retaining issue IDs and links.

Safe strategy: move the template to the contributor workflow destination and
update all templates/docs atomically.

Safe strategy: use redirects/index links for one release rather than hard
deleting project history.

### `contracts/`

**Action: KEEP.**

Inventory: 4 tracked files; no implementation language source.

Contains `contracts/ocla/v1/ocla.proto`.

Contains capability manifests for leanctx passthrough/context optimization and
the RTK shell.

Real code status: authoritative protocol schema/manifests, not a stub.

Product fit: central; contracts enable one interoperable core across SDKs.

Dependency signal: Go conformance, security checks, and proprietary guard all
reference this path.

Deletion risk: critical; wire conformance, consumers, and policy checks break.

Safe strategy: keep one canonical contract directory with explicit versioning.

Safe strategy: generate or validate SDK types from it where feasible; do not
maintain divergent handwritten copies as another contract source.

Safe strategy: require compatibility review for every contract change.

## Safe execution order

1. Publish a supported-surface policy: core, SDKs, VS Code, JetBrains, Go, OCLA.

2. Record actual package registry owners, downloads, reverse dependencies, and
extension install bases for every package proposed for retirement.

3. Add a contract conformance matrix covering canonical Python, Node, and Go.

4. Port `python-sdk` async streaming/models and `ts-sdk` capabilities first.

5. Deprecate, do not remove, `clients/python`, `py-sdk`, `python-sdk`, and
`ts-sdk` package releases with migration guides.

6. Remove obsolete CI/publish jobs only after the compatibility window closes.

7. Tag and transfer archive candidates to purpose-specific repositories.

8. Move documentation/demo/spec assets with redirects and link checks.

9. Inspect ignored operational/research directories with their owners before
any local deletion.

10. Delete only regenerated residue and the verified `.DS_Store`-only cloud
directory in a final, separately reviewed cleanup change.

## Final trim outcome

**Superseded 2026-08-20.** The tree actually kept is narrower than the audit's
KEEP list:

- `rust/` (core; out of WS-1 scope)
- `packages/python-lean-ctx/`, `packages/node-lean-ctx/`, `packages/ocla-grpc/`, `packages/leanctx-verify/`, `packages/lean-ctx-bin/`
- `clients/rust/`, `cookbook/`, `docs/` (contracts live here, including OCLA)
- `scripts/` (including `scripts/benchmark/`), `tests/`, `security/`, `kits/`, `skills/`, `assets/`, `aur/`, `bin/`
- `_archive/` for historical SDKs, editors, Go SDK, integrations, specs, benchmarks

`go-sdk/`, `vscode-extension/`, and `packages/jetbrains-lean-ctx/` were archived,
not kept as supported surfaces. Re-opening them requires a product decision, not
this audit.
