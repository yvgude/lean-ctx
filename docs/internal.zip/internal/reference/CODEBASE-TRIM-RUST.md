# D1 — Rust Codebase Audit Against the Composable Vision

Status: completed audit

Scope: Rust workspace only

Repository: lean-ctx

Audit date: 2026-08-20

Audit rule: preserve the current OSS engine, CLI, MCP server, and proxy.

Removal rule: no production removal is recommended in this report.

Migration rule: Phase B changes are additive traits, adapters, and dual paths.

Physical-move rule: any later move occurs only after compatibility shims and tests.

## Execution status — 2026-08-21

Rust-core policy unchanged: **`rust/` is out of scope for WS-1 deletion.** This audit still governs how to classify Rust modules for later OCLA normalization (WS-4). Package/editor/SDK cleanup described in CODEBASE-TRIM-PACKAGES is complete; do not start Wave-4 refactors until GitLab #1254 (paid pilot) is done.

## 1. Sources reviewed

- docs/internal/vision/COMPOSABLE-VISION.md
- docs/internal/reference/TECHNICAL-CONVERGENCE.md
- docs/internal/reference/CODEBASE-MAP.md
- rust/Cargo.toml
- rust/src/
- rust/crates/
- rust/src/core/
- rust/src/tools/
- rust/src/proxy/

## 2. Vision target used for classification

Vision section 51 explicitly calls its tree a conceptual ownership target.

It explicitly says not to create folders blindly.

It requires an audit that maps existing Cargo-workspace code to responsibilities.

The desired ownership is:

- leanctx-protocol: task, context, receipt, profile, and capability vocabulary.
- leanctx-ocla: manifest, registry, traits, adapters, and conformance.
- leanctx-runtime: planner, context, execution, and evidence coordination.
- leanctx-capabilities: native code, compression, shell, memory, retrieval, evidence.
- leanctx-sdk: session, profiles, kits, and capability-facing developer surfaces.
- CLI: capability, profile, and benchmark commands.

The technical-convergence document adds a layering rule.

Outer surfaces are SDK bindings, CLI, MCP, and Proxy.

Those surfaces should call a product facade.

The facade should coordinate ContextSession.

The session owns or composes kernel, profiles, kits, execution ledger, and evidence flow.

The protocol crate owns portable serializable vocabulary.

## 3. Classification vocabulary

| Label | Meaning in this audit |
|---|---|
| KEEP | Directly supports the target; retain its current public and internal behavior. |
| NORMALIZE | Good implementation; add an OCLA capability trait or protocol boundary in Phase B. |
| CONSOLIDATE | Two or more live implementations overlap; converge behind one owner without deleting callers. |
| ARCHIVE | Experimental or manual-verification scope; retain only behind an explicit non-default feature or separate workspace. |
| DELETE | Confirmed unreachable and superseded code; none is recommended from this static audit. |

## 4. Phase vocabulary

| Phase | Safe scope |
|---|---|
| A — now | Document ownership, add tests, and retain current module paths. |
| B — normalize | Add protocol/OCLA traits, adapters, manifests, and dual registration. |
| C — consolidate | Migrate implementations behind stable facades after conformance coverage. |
| D — optional cleanup | Separate branch only; feature-gated deprecation and removal after downstream notice. |

## 5. Measurement method

Rust LOC means lines in .rs files recursively under the stated directory.

This includes inline unit tests in those .rs files.

It excludes non-Rust assets, generated build output, and Cargo metadata.

Directory LOC is a sizing signal, not a quality or deletion score.

The audit observed 368,924 Rust LOC under rust/src/core.

It observed 73,954 Rust LOC under rust/src/tools.

It observed 37,236 Rust LOC under rust/src/proxy.

It observed 143,494 Rust LOC in direct .rs files in rust/src/core.

The large direct-file set must be grouped by responsibility before a physical crate split.

## 6. Cargo workspace reality

| Workspace member | Observed role | Vision fit | Phase | Action |
|---|---|---|---|---|
| rust/. | Existing engine, CLI, MCP, proxy, setup, hooks | Partial | A | Keep as the compatibility runtime facade. |
| rust/crates/lean-ctx-ocla | OCLA public vocabulary and traits | Direct | B | Expand by extraction through compatibility adapters. |
| rust/crates/lean-ctx-protocol | Portable protocol vocabulary | Direct | A/B | Keep; normalize physical modules to target nouns. |
| rust/crates/lean-ctx-sdk | Opt-in SDK package | Direct | B | Keep; expose stable session/profile/kit entrypoints. |
| rust/crates/grammar-addons/lua | Dynamic grammar extension | Direct capability extension | A/B | Keep; describe as Code capability addon. |
| rust/experiments/grammar-dlopen-spike/host | Manual Phase-0 grammar experiment | Experimental | C/D | Archive from default workspace after reproducer coverage. |

Cargo default-members remains only the engine crate.

That is a compatibility advantage.

It avoids silently changing current cargo build, test, clippy, or publish behavior.

The SDK is explicitly opt-in today.

Do not make all members default-members as part of this programme.

## 7. Crate audit

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/crates/lean-ctx-ocla | 1,508 | Yes; required OCLA ownership seed | B | NORMALIZE | Move shared traits/types into this crate only through re-exports and adapters. |
| rust/crates/lean-ctx-ocla/src/manifest.rs | included | Yes; target manifest owner | B | KEEP | Make it the canonical manifest schema with backward-compatible conversion. |
| rust/crates/lean-ctx-ocla/src/traits.rs | included | Yes; target trait owner | B | KEEP | Add capability traits here before moving native implementations. |
| rust/crates/lean-ctx-ocla/src/types.rs | included | Yes; portable OCLA types | B | NORMALIZE | Reconcile with similarly named engine OCLA types via aliases first. |
| rust/crates/lean-ctx-ocla/src/observation.rs | included | Yes; evidence/observation substrate | B | KEEP | Feed receipts and execution evidence without changing current sinks. |
| rust/crates/lean-ctx-ocla/src/failure.rs | included | Yes; conformance failure model | B | KEEP | Use for adapter/conformance errors; retain existing errors at boundaries. |
| rust/crates/lean-ctx-protocol | 3,906 | Yes; target portable vocabulary | A/B | NORMALIZE | Keep crate stable and group exports under target responsibility modules. |
| rust/crates/lean-ctx-sdk | 969 | Yes; target public SDK | B | NORMALIZE | Add façade methods; do not make engine internals public wholesale. |
| rust/crates/grammar-addons | 16 | Yes; optional language extension model | A/B | KEEP | Register addon metadata as native Code capabilities. |
| rust/crates/vendor/rmcp | 45,156 | Yes; MCP transport dependency | A | KEEP | Treat as third-party vendored infrastructure, not a composable product capability. |
| rust/crates/vendor/rmcp-macros | 2,017 | Yes; MCP macro support | A | KEEP | Keep pinned with upstream provenance and existing patch process. |

The protocol crate already contains the right vocabulary families.

Current protocol files include capability, task, evidence, execution, policy, outcome, usage, and savings.

It also contains rollout, eligibility, circuit-breaker, auto-routing, and control-plane language.

This breadth is useful but its flat physical layout is not yet the target task/context/receipt/profile/capability ownership tree.

The correct Phase-B operation is module re-export and conversion layering.

It is not a breaking rename of protocol paths.

The SDK contains engine.rs, addon.rs, read.rs, compress.rs, output.rs, error.rs, hash.rs, and tokens.rs.

This is a viable SDK seed.

It is too small to be the primary home of the current runtime, which is appropriate.

It should become a typed client facade over the compatibility runtime rather than absorb core implementation.

## 8. Evidence of incomplete OCLA convergence

The engine depends on rust/crates/lean-ctx-ocla.

Only three Rust source files currently reference lean_ctx_ocla directly.

Those references are concentrated in rust/src/core/ocla and delivery registry behavior.

The engine contains a separate 20,732-LOC rust/src/core/ocla implementation.

The dedicated crate contains only 1,508 LOC.

This is not a deletion signal.

It is clear evidence that the canonical OCLA crate is a seed while engine-local OCLA remains the de facto implementation.

The correct action is controlled convergence from engine-local code toward crate-owned vocabulary.

The protocol crate has broad existing engine use.

Thirty-nine Rust source files reference lean_ctx_protocol directly.

Protocol adoption is therefore ahead of OCLA adoption.

Preserve that adoption and use protocol conversions as the migration seam.

No rust/src source file references lean_ctx_sdk directly.

That is consistent with an opt-in external SDK.

It means SDK adoption must be additive and cannot justify moving engine logic into the SDK today.

## 9. Main source-root audit

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/bin | 1,519 | CLI entrypoints | A | KEEP | Keep command compatibility; route future capability/profile commands through façades. |
| rust/src/cli | 40,772 | CLI surface required by vision | B | NORMALIZE | Consolidate command dispatch around capability, profile, benchmark, and legacy adapters. |
| rust/src/core | 368,924 | Runtime and native capabilities | A/B | NORMALIZE | Retain code; express ownership through runtime/capability adapters before physical splits. |
| rust/src/dashboard | 9,868 | Operational surface | A | KEEP | Preserve as an operational consumer of receipts, profiles, and evidence. |
| rust/src/doctor | 9,048 | Deploy/diagnostic surface | A/B | NORMALIZE | Make diagnostics capability/profile-conformance aware. |
| rust/src/engine | 134 | Runtime façade seed | B | NORMALIZE | Expand only as a stable façade over existing core paths. |
| rust/src/hook_handlers | 8,646 | Attach integration | A | KEEP | Retain integration behavior; later call capability façades. |
| rust/src/hooks | 10,187 | Attach integration | A | KEEP | Preserve hook protocol and performance behavior. |
| rust/src/http_server | 1,926 | Gateway/transport | B | NORMALIZE | Keep as a surface adapter, not a capability owner. |
| rust/src/instructions | 56 | Product instructions | A | KEEP | Keep as small delivery asset. |
| rust/src/ipc | 1,002 | Local gateway transport | A/B | NORMALIZE | Define protocol-bound request/receipt envelopes incrementally. |
| rust/src/kits | 414 | Direct target concept | B | NORMALIZE | Promote to typed kit manifests while retaining current selection behavior. |
| rust/src/lsp | 3,673 | Code integration surface | A/B | NORMALIZE | Represent LSP features as code-capability consumers. |
| rust/src/proxy | 37,236 | Gateway/Proxy surface | A/B | NORMALIZE | Retain as a policy/evidence-aware adapter, not capability business logic owner. |
| rust/src/proxy_setup | 3,261 | Deploy integration | A | KEEP | Preserve installation path and runtime behavior. |
| rust/src/rules_inject | 1,683 | Attach integration | A | KEEP | Keep; later attach profile declarations to injected rules. |
| rust/src/server | 13,751 | MCP/server surface | B | NORMALIZE | Keep public registrations stable; make registrations derive from capability metadata. |
| rust/src/setup | 2,734 | Deploy lifecycle | A | KEEP | Retain installation and setup compatibility. |
| rust/src/shell | 9,062 | Native Shell capability substrate | A/B | NORMALIZE | Keep enforcement; expose a Shell capability adapter. |
| rust/src/tool_defs | 572 | Tool metadata seed | B | CONSOLIDATE | Make this the single bridge from OCLA manifest to MCP registration. |
| rust/src/tools | 73,954 | MCP capability adapter surface | A/B | CONSOLIDATE | Keep tool names; converge registration and implementations around manifests. |
| rust/src/tui | 1,280 | Operational surface | A | KEEP | Keep as a consumer, not an ownership layer. |
| rust/src/uninstall | 3,449 | Deploy lifecycle | A | KEEP | Preserve cleanup compatibility and install receipts. |
| rust/src/wrap | 706 | Attach/wrapper integration | A | KEEP | Keep wrapper behavior as a compatibility adapter. |

Directories assets and templates currently have no Rust LOC.

They are not classified as dead solely because they are non-Rust resources.

## 10. Core: native compression and representation

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/compressor.rs | 579 | Yes; native compression | A | KEEP | Preserve implementation; later register CompressionCapability adapter. |
| rust/src/core/compression_safety.rs | 273 | Yes; compression safety | A | KEEP | Keep mandatory safety checks outside optional profile choices. |
| rust/src/core/compress_preview.rs | 214 | Yes; explain/preview surface | A/B | NORMALIZE | Return protocol receipt/estimate fields without changing preview behavior. |
| rust/src/core/terse | 2,308 | Yes; format transform | A/B | NORMALIZE | Register as a profile-selectable compression strategy. |
| rust/src/core/verbosity | 604 | Yes; profile substrate | A/B | NORMALIZE | Bind current controls to TuningProfile declarations. |
| rust/src/core/extractive | 797 | Yes; context reduction | A/B | NORMALIZE | Register as a native extraction capability. |
| rust/src/core/extractors | 662 | Yes; context reduction | A/B | NORMALIZE | Keep extractors; declare supported inputs and evidence. |
| rust/src/core/patterns | 17,874 | Yes; compression/recognition substrate | A/B | NORMALIZE | Keep, then split capability-facing API from internal patterns. |
| rust/src/core/triage | 1,915 | Yes; input selection | A/B | NORMALIZE | Express selected policies through profile and receipt fields. |
| rust/src/core/value_gate | 785 | Yes; quality protection | A/B | NORMALIZE | Keep as safety gate; expose verdict/evidence, not bypass controls. |
| rust/src/core/sensitivity | 597 | Yes; safe selection | A/B | NORMALIZE | Carry decisions into profile and receipt metadata. |

Format-specific direct core files named in CODEBASE-MAP are already strategically aligned.

They include markdown, HTML, JSON, YAML, tabular, structural, structured-read, and transcript transforms.

Keep their current paths in Phase A.

Add a profile-selected adapter layer in Phase B.

Do not collapse algorithms into a single large compressor module.

## 11. Core: session, context, runtime, and evidence

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/context_kernel | 19,232 | Direct ContextSession substrate | B | NORMALIZE | Make it the internal coordinator behind a stable ContextSession façade. |
| rust/src/core/context_os | 1,678 | Context runtime coordination | B | CONSOLIDATE | Merge responsibility with kernel through façade, not immediate file move. |
| rust/src/core/contextops | 1,219 | Context operations | B | CONSOLIDATE | Route operations through the session planner interface. |
| rust/src/core/context_package | 6,773 | Context packaging | B | NORMALIZE | Model outputs as portable context/evidence envelopes. |
| rust/src/core/context_ledger | 1,504 | Receipt/ledger substrate | B | NORMALIZE | Convert to protocol receipt semantics with compatibility serialization. |
| rust/src/core/context_snapshot | 1,660 | Session state | B | NORMALIZE | Make snapshot lifecycle explicit in ContextSession. |
| rust/src/core/context_prefetch | 212 | Context planning optimization | B | NORMALIZE | Keep optional; profile-gate and record its use in evidence. |
| rust/src/core/session | 2,957 | Direct target ContextSession | B | CONSOLIDATE | Make this the public coordinator façade over kernel and snapshots. |
| rust/src/core/session_summary | 625 | Session evidence | B | NORMALIZE | Map summary to receipt/evidence objects. |
| rust/src/core/execution_ledger | 1,092 | Direct execution/evidence target | B | NORMALIZE | Use protocol execution and receipt vocabulary. |
| rust/src/core/savings_ledger | 4,849 | Measure/evidence target | B | NORMALIZE | Preserve calculations; publish portable savings receipts. |
| rust/src/core/provenance | 875 | Prove/evidence target | A/B | KEEP | Retain provenance controls and make conformance visible. |
| rust/src/core/outcome | 1,551 | Outcome measurement | B | NORMALIZE | Connect to protocol outcome types and session receipt completion. |
| rust/src/core/measurement | 533 | Measurement substrate | B | NORMALIZE | Consolidate event schema with usage, savings, and evidence sinks. |
| rust/src/core/stats | 3,425 | Measurement substrate | B | NORMALIZE | Keep computation; surface stable metrics through receipts. |
| rust/src/core/scorecard | 914 | Evidence consumer | B | NORMALIZE | Consume canonical receipts, not internal ad hoc aggregates. |
| rust/src/core/shadow | 825 | Safe rollout/evaluation | B | NORMALIZE | Keep as an experiment adapter with explicit non-authoritative receipts. |

The context family is the largest ownership overlap in the repository.

It has separate kernel, OS, operations, package, ledger, snapshot, prefetch, and session modules.

These are live architectural parts, not candidates for deletion.

The consolidation target is one ContextSession public façade with internal components retained.

The implementation should first add an ownership map and adapter traits.

Physical consolidation comes only after callers depend on the façade.

## 12. Core: retrieval, memory, graph, and code understanding

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/bm25_index | 2,966 | Native Retrieval capability | A/B | KEEP | Keep index behavior; register retrieval manifest metadata. |
| rust/src/core/cache | 2,647 | Deterministic reuse | A/B | KEEP | Preserve cache invariants and add capability observability. |
| rust/src/core/embeddings | 2,698 | Retrieval substrate | B | NORMALIZE | Declare deterministic fallback and profile requirements. |
| rust/src/core/knowledge | 5,681 | Memory/retrieval capability | B | NORMALIZE | Put public data vocabulary in protocol, retain engine implementation. |
| rust/src/core/knowledge_router | 1,420 | Routing capability | B | CONSOLIDATE | Converge routing policy with provider and retrieval planners. |
| rust/src/core/memory_scheduler | 347 | Memory optimization | B | NORMALIZE | Bind scheduling decisions to session and profile receipts. |
| rust/src/core/property_graph | 2,790 | Graph retrieval substrate | B | NORMALIZE | Keep optional and non-blocking for v1 activation. |
| rust/src/core/graph_index | 3,234 | Graph retrieval substrate | B | NORMALIZE | Preserve storage; expose through retrieval capability boundary. |
| rust/src/core/graph_analysis | 799 | Graph planning | B | NORMALIZE | Keep as optional planner input. |
| rust/src/core/graph_expand | 315 | Graph planning | B | NORMALIZE | Keep as optional planner input. |
| rust/src/core/repomap | 696 | Native Code capability | A/B | KEEP | Retain high-value code map generation; add code-capability receipt metadata. |
| rust/src/core/deep_queries | 3,574 | Native Code capability | A/B | KEEP | Preserve query API; add ContextSession planning adapter. |
| rust/src/core/signatures_ts | 2,964 | Native Code capability | A/B | KEEP | Keep Tree-sitter integration and describe language addon requirements. |
| rust/src/core/import | 730 | Ingestion/index lifecycle | B | NORMALIZE | Make source ingestion a session-managed capability input. |
| rust/src/core/import_resolver | 2,092 | Ingestion/index lifecycle | B | NORMALIZE | Preserve resolver behavior and emit provenance. |
| rust/src/core/providers | 6,250 | External provider bridge | B | NORMALIZE | Express providers as capability adapters with protocol result envelopes. |
| rust/src/core/mcp_catalog | 3,294 | Capability discovery substrate | B | CONSOLIDATE | Merge logical ownership with OCLA registry, not transport implementation. |

CODEBASE-MAP identifies retrieval, graph, repomap, deep queries, extractors, signatures, and TypeScript handlers as high-value code understanding.

That alignment is strong.

The vision does not require a retrieval crate immediately.

It requires a capability boundary and profile disclosure before portability claims.

## 13. Core: configuration, policy, safety, and operational integrity

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/config | 14,999 | Profile/config substrate | A/B | KEEP | Preserve schema and migration behavior; add versioned TuningProfile projection. |
| rust/src/core/profiles | 1,474 | Direct Performance Profile substrate | A | KEEP | Keep as canonical in-engine profile implementation. |
| rust/src/core/policy | 2,572 | Profile compatibility and deploy safety | A/B | KEEP | Keep enforcement; add declarative compatibility information. |
| rust/src/core/shell_allowlist | 5,592 | Native Shell capability safety | A | KEEP | Retain non-bypassable allowlist and sandbox policy. |
| rust/src/core/input_filters | 886 | Safety/data hygiene | A | KEEP | Preserve before any plugin/capability dispatch. |
| rust/src/core/trust | 1,164 | Deploy/prove integrity | A/B | KEEP | Keep trust decisions and bind them to evidence. |
| rust/src/core/anti_interrupt | 399 | Continuity safety | A | KEEP | Preserve bounded-failure semantics. |
| rust/src/core/workflow | 450 | Kit/workflow substrate | B | NORMALIZE | Model transitions explicitly; retain current workflow API. |
| rust/src/core/a2a | 3,312 | External agent gateway | B | NORMALIZE | Treat as adapter to protocol/OCLA capability contracts. |
| rust/src/core/sidecar_transport | 211 | Gateway transport | B | NORMALIZE | Keep narrow transport implementation behind adapter. |
| rust/src/core/editor_registry | 5,879 | Attach integration registry | B | CONSOLIDATE | Converge metadata ownership with MCP catalog and OCLA registry. |
| rust/src/core/plugins | 1,582 | Capability/plugin substrate | B | CONSOLIDATE | Keep runtime loading; make registry metadata canonical in OCLA. |
| rust/src/core/skillify | 741 | Capability packaging seed | B | NORMALIZE | Relate skills to kit/capability manifests without changing current skill behavior. |
| rust/src/core/compliance_report | 1,567 | Prove/deploy evidence | B | NORMALIZE | Consume canonical evidence/receipt types. |

Safety paths must not become optional capabilities that an integration can omit.

The capability boundary should expose compatibility and evidence.

It must leave the enforcement point where it is today.

## 14. Core: experiments, benchmarks, and advanced optimisation

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/benchmark_compare | 1,136 | Benchmark evidence | B | NORMALIZE | Keep; emit comparable receipt/evaluation schema. |
| rust/src/core/benchmark_study | 2,077 | Benchmark evidence | B | NORMALIZE | Keep; place behind benchmark command surface. |
| rust/src/core/eval_ab | 4,913 | Experiment controller seed | B | NORMALIZE | Keep as gated evaluator; do not make default planner dependency. |
| rust/src/core/quality_benchmark | 170 | Evaluation support | B | NORMALIZE | Keep and join canonical benchmark reports. |
| rust/src/core/quality_lab | 1,380 | Evaluation support | B | NORMALIZE | Keep isolated from request hot path. |
| rust/src/core/task_benchmark | 2,060 | Evaluation support | B | NORMALIZE | Keep and tie to task/receipt vocabulary. |
| rust/src/core/cognitive | 463 | Advanced optimization research | C | ARCHIVE | Keep source, gate behind explicit experimental feature until measured benefit. |
| rust/src/core/neural | 1,548 | Advanced optimization research | C | ARCHIVE | Keep source, gate behind explicit experimental feature until measured benefit. |
| rust/src/core/ib | 394 | Information-bottleneck research | C | ARCHIVE | Keep source, gate behind explicit experimental feature until measured benefit. |
| rust/src/core/locomo | 477 | Advanced optimization research | C | ARCHIVE | Keep source, gate behind explicit experimental feature until measured benefit. |
| rust/src/core/wasserstein | 353 | Advanced optimization research | C | ARCHIVE | Keep source, gate behind explicit experimental feature until measured benefit. |
| rust/src/core/gain | 2,837 | Optimization/economic model | C | ARCHIVE | Retain while benchmarked; keep out of default capability contract. |
| rust/src/core/free_energy_budget.rs | direct-file family | Advanced optimisation | C | ARCHIVE | Treat as experimental until an evaluated profile promotes it. |
| rust/src/core/qubo_select.rs | direct-file family | Advanced optimisation | C | ARCHIVE | Treat as experimental until an evaluated profile promotes it. |

TECHNICAL-CONVERGENCE and CODEBASE-MAP label cognitive, neural, information-bottleneck, locomotion, and Wasserstein work as scaffolded and park.

That is not proof of unreachable code.

The modules have internal references.

ARCHIVE here means isolate from normal product ownership and feature-gate it.

It does not mean delete it.

## 15. Core: remaining first-level directories

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/agents | 1,844 | Agent integration | B | NORMALIZE | Expose agent interactions through protocol/OCLA adapters. |
| rust/src/core/addons | 8,323 | Extension substrate | B | NORMALIZE | Consolidate addon metadata with capability manifest registry. |
| rust/src/core/billing | 2,724 | Measure/receipt consumer | B | NORMALIZE | Consume usage and savings receipts. |
| rust/src/core/buddy | 1,888 | Product feature | C | ARCHIVE | Keep behind product/experimental scope until it has capability ownership. |
| rust/src/core/code_health | 2,291 | Code/evidence feature | B | NORMALIZE | Consume code capability outputs and evidence. |
| rust/src/core/codesign | 386 | Product/research feature | C | ARCHIVE | Keep separate from default runtime until evaluated and owned. |
| rust/src/core/community | 1,289 | Product/community feature | C | ARCHIVE | Keep out of core capability model pending product contract. |
| rust/src/core/finops_export | 1,093 | Measure/export adapter | B | NORMALIZE | Use canonical usage/savings receipts. |
| rust/src/core/git | 950 | Code/provenance substrate | A/B | KEEP | Preserve repository awareness and expose provenance. |
| rust/src/core/godot | 128 | Language-specific code extraction | A/B | KEEP | Retain small graph-index helper; describe as optional Code addon. |
| rust/src/core/gotcha_tracker | 2,660 | Product/research feature | C | ARCHIVE | Isolate behind feature until metrics prove utility. |
| rust/src/core/mdl_mode | 422 | Tuning/mode selection | B | NORMALIZE | Make profile selection and evidence explicit. |
| rust/src/core/outcome | 1,551 | Outcome/evidence substrate | B | NORMALIZE | Use protocol outcome types and receipt correlation. |
| rust/src/core/quality_benchmark | 170 | Evaluation support | B | NORMALIZE | Retain as evaluation adapter. |
| rust/src/core/web | 3,998 | External retrieval/integration | B | NORMALIZE | Make provider policy and provenance explicit. |
| rust/src/core/stigmergy | 103 | Research coordination | C | ARCHIVE | Keep only behind experimental feature pending evidence. |

The Phase-C archive classifications above are not removal candidates.

They are requests for explicit boundaries and non-default feature ownership.

No static evidence supports deleting them today.

## 16. Direct core-file families needing ownership mapping

| Family | Observed size/context | Vision fit | Classification | Action |
|---|---|---|---|---|
| context_{ir,field,column,artifacts,handles,overlay,policies,overhead,deficit,radar,lint,proof,proof_v2,compiler} | Direct core-file family named in CODEBASE-MAP | Strong | CONSOLIDATE | Keep files; put public plan/context/receipt types in protocol and expose via ContextSession. |
| search_index.rs | 1,408 LOC | Strong retrieval substrate | NORMALIZE | Retain implementation and place behind Retrieval capability adapter. |
| index_orchestrator.rs | 1,233 LOC | Strong ingestion/retrieval substrate | NORMALIZE | Let ContextSession own lifecycle decisions. |
| memory_lifecycle.rs | 1,196 LOC | Strong session/memory substrate | NORMALIZE | Include state transitions in session contract. |
| call_graph.rs | 1,322 LOC | Strong Code capability substrate | KEEP | Keep graph extraction; make result/evidence portable. |
| graph_provider.rs | 1,040 LOC | Strong retrieval provider substrate | NORMALIZE | Make it an optional retrieval adapter. |
| rules_canonical.rs | 1,389 LOC | Deploy/rule contract substrate | NORMALIZE | Consolidate with workflow/kit contracts. |
| pathjail.rs | 1,354 LOC | Critical security control | KEEP | Retain mandatory enforcement; never delegate safety away. |
| pathutil.rs | 1,048 LOC | Safety/path substrate | KEEP | Retain as shared internal primitive. |
| updater.rs | 1,356 LOC | Deploy lifecycle | KEEP | Preserve installer/update compatibility. |
| html_crush.rs | 1,320 LOC | Compression capability | NORMALIZE | Register with profile/receipt metadata. |
| auto_mode_resolver.rs | 1,239 LOC | Tuning substrate | NORMALIZE | Gate selection through evaluated profiles. |
| intent_engine.rs | 1,163 LOC | Tuning substrate | NORMALIZE | Keep, then publish evaluated knobs only. |
| cognition_loop.rs | 1,130 LOC | Advanced optimization | ARCHIVE | Feature-gate with cognitive research family. |
| knowledge_embedding.rs | 1,101 LOC | Retrieval substrate | NORMALIZE | Declare deterministic fallback and provider provenance. |
| benchmark.rs | 1,091 LOC | Measure/prove substrate | NORMALIZE | Converge evaluation output on receipt schema. |
| loop_detection.rs | 1,011 LOC | Safety/continuity | KEEP | Retain as runtime protection. |
| science_benchmark.rs | 959 LOC | Research benchmark | ARCHIVE | Keep outside default hot path pending product benchmark contract. |
| task_relevance.rs | 956 LOC | Tuning/selective context | NORMALIZE | Bind decisions to profile and receipt fields. |
| signatures.rs | 925 LOC | Code capability substrate | KEEP | Preserve structural extraction compatibility. |

The direct-file inventory is too large for a safe mechanical crate move.

The first deliverable must be a responsibility map and façade tests.

## 17. Engine-local OCLA audit

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/core/ocla | 20,732 | Yes, but split ownership | B/C | CONSOLIDATE | Keep current module path as façade while canonical traits/types move to lean-ctx-ocla. |
| rust/src/core/ocla/adapters | included | Direct target adapters role | B | NORMALIZE | Implement conversions to crate-owned traits, preserving native adapters. |
| rust/src/core/ocla/builtin | included | Native capability implementations | B | NORMALIZE | Register existing providers behind OCLA traits and manifests. |
| rust/src/core/ocla/reference_adapters | included | Conformance/reference adapters | B | KEEP | Use as compatibility/conformance fixtures. |
| rust/src/core/ocla/registry.rs | included | Direct target registry role | B/C | CONSOLIDATE | Make crate registry types canonical; retain engine storage/lookup adapter. |
| rust/src/core/ocla/catalogue.rs | included | Registry/catalogue overlap | B/C | CONSOLIDATE | Define one logical catalog API and preserve legacy query paths. |
| rust/src/core/ocla/policy_bundle.rs | included | Policy compatibility | B | NORMALIZE | Bind to profile compatibility declarations. |
| rust/src/core/ocla/policy_constraints.rs | included | Policy compatibility | B | NORMALIZE | Retain enforcement semantics and return conformance evidence. |
| rust/src/core/ocla/cache_{coordinator,delivery,tiers,types}.rs | included | Capability internals | B | NORMALIZE | Leave storage internal; expose portable capability outcome/receipt. |
| rust/src/core/ocla/builtin/compression_provider.rs | included | Direct native compression provider | B | KEEP | Make it the bridge to existing compressor modules. |
| rust/src/core/ocla/builtin/usage_sink.rs | included | Measure/receipt provider | B | NORMALIZE | Convert to protocol usage/receipt types. |
| rust/src/core/ocla/builtin/savings_ledger.rs | included | Measure/receipt provider | B | NORMALIZE | Reuse current ledger calculations through adapter. |
| rust/src/core/ocla/builtin/model_router.rs | included | Tuning/provider adapter | B | NORMALIZE | Keep routing implementation behind profile selection. |
| rust/src/core/ocla/builtin/experiment_{executor,runner}.rs | included | Evaluation provider | B | NORMALIZE | Keep non-default and emit benchmark evidence. |

The engine-local OCLA directory is active, not dead.

The small dedicated OCLA crate and large engine-local OCLA directory are the clearest consolidation pair.

Consolidation sequence:

1. Add missing traits and neutral DTOs to lean-ctx-ocla.

2. Implement conversions in rust/src/core/ocla/adapters.

3. Register existing builtin providers using those traits.

4. Add conformance tests against the existing engine behavior.

5. Change callers one boundary at a time to the crate trait.

6. Retain rust/src/core/ocla re-exports until a documented compatibility window ends.

## 18. MCP tool audit

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/tools | 73,954 | Required capability adapter surface | A/B | CONSOLIDATE | Keep all public tool names; derive registration metadata from one capability catalog. |
| rust/src/tools/ctx_read | 7,388 | Native Code/Retrieval capability | A/B | KEEP | Preserve behavior and tool contract; publish capability metadata and receipts. |
| rust/src/tools/ctx_search | 1,453 | Native Retrieval capability | A/B | KEEP | Preserve behavior; attach profile and evidence data. |
| rust/src/tools/ctx_semantic_search | 2,087 | Native Retrieval capability | B | NORMALIZE | Declare backend/fallback/provenance in profile and receipt. |
| rust/src/tools/ctx_knowledge | 3,914 | Native Memory capability | B | NORMALIZE | Route typed vocabulary through protocol. |
| rust/src/tools/ctx_edit | 1,504 | Code capability surface | A/B | NORMALIZE | Keep safety behavior; capability proof must record patches/constraints. |
| rust/src/tools/ctx_patch | 2,742 | Code capability surface | A/B | NORMALIZE | Keep safety behavior; use canonical patch evidence. |
| rust/src/tools/ctx_refactor | 3,741 | Code capability surface | B | NORMALIZE | Bind transformations to conformance/evaluation evidence. |
| rust/src/tools/ctx_impact | 1,470 | Code/graph capability surface | B | NORMALIZE | Use graph result and evidence envelopes. |
| rust/src/tools/ctx_outline | 634 | Code understanding surface | A/B | KEEP | Register as native Code capability. |
| rust/src/tools/ctx_cognitive | 187 | Research capability surface | C | ARCHIVE | Keep tool non-default and behind explicit experimental feature. |
| rust/src/tools/ctx_multi_repo | 548 | Multi-project integration | B | NORMALIZE | Model workspace scope and provenance in protocol. |
| rust/src/tools/registered | 18,855 | MCP registration adapter layer | B/C | CONSOLIDATE | Maintain names; make it consume the single manifest/catalog bridge. |
| rust/src/tools/registered/ctx_read.rs | 1,490 | Registration wrapper | B/C | CONSOLIDATE | Keep wrapper while sharing metadata and validation with implementation. |
| rust/src/tools/registered/ctx_crush.rs | 1,418 | Compression registration wrapper | B/C | CONSOLIDATE | Map to Compression capability manifest. |
| rust/src/tools/registered/ctx_shell.rs | 1,381 | Shell registration wrapper | B/C | CONSOLIDATE | Map to Shell capability manifest while preserving allowlist enforcement. |
| rust/src/tools/registered/ctx_search.rs | 1,063 | Search registration wrapper | B/C | CONSOLIDATE | Share manifest and receipt builder with search implementation. |
| rust/src/tools/registered/ctx_patch.rs | 818 | Patch registration wrapper | B/C | CONSOLIDATE | Share policy/evidence adapters with patch implementation. |
| rust/src/tools/registered/ctx_compose.rs | 791 | Session/planner façade | B | NORMALIZE | Make it a thin ContextSession capability consumer. |
| rust/src/tools/registered/ctx_handoff.rs | 675 | Session/kit lifecycle | B | NORMALIZE | Use explicit session transition and receipt types. |
| rust/src/tools/registered/ctx_optimize.rs | 587 | Tuning surface | B | NORMALIZE | Restrict to evaluated profile controls. |

The tools tree contains both rich implementations and registered wrappers.

That separation can be valid.

The overlap becomes harmful only if names, schemas, safety checks, or receipts diverge.

Phase B should introduce a manifest-derived registration descriptor.

The descriptor should feed both registered tool wrappers and OCLA catalog lookup.

It must not rename MCP tools or change clients in the first migration.

## 19. Proxy and gateway audit

| Module | Rust LOC | Aligns with vision? | Phase | Classification | Action |
|---|---:|---|---|---|---|
| rust/src/proxy | 37,236 | Required Proxy/gateway surface | A/B | NORMALIZE | Keep public provider behavior; make it consume session/profile/policy/evidence façades. |
| rust/src/proxy/forward | 3,015 | Gateway forwarding | A/B | KEEP | Preserve provider forwarding and attach canonical receipts. |
| rust/src/proxy/web_app | 1,065 | Web gateway surface | A | KEEP | Retain as consumer of proxy façade. |
| rust/src/proxy/mod.rs | 1,413 | Gateway composition root | B | CONSOLIDATE | Centralize façade calls; do not move provider behavior into OCLA. |
| rust/src/proxy/dedup.rs | 1,057 | Reuse/performance capability | B | NORMALIZE | Tie decisions to session/cache receipt metadata. |
| rust/src/proxy/bedrock.rs | 1,026 | Provider adapter | A/B | KEEP | Preserve provider adapter and declare provider capability metadata. |
| rust/src/proxy/usage.rs | 911 | Measurement surface | B | NORMALIZE | Emit protocol usage and receipt data. |
| rust/src/proxy/introspect.rs | 908 | Evidence/diagnostic surface | B | NORMALIZE | Consume canonical receipt/evidence schema. |
| rust/src/proxy/shape_xlat.rs | 905 | Provider translation | A/B | KEEP | Retain translations as adapter internals. |
| rust/src/proxy/usage_meter.rs | 892 | Measurement surface | B | NORMALIZE | Consolidate event semantics with savings and ledger modules. |
| rust/src/proxy/policy_gate.rs | 810 | Critical policy safety | A | KEEP | Keep enforcement in proxy path; expose compatibility outcome only. |

The proxy is not a candidate to become the runtime owner.

It is a high-value adapter that must stay backward compatible with providers and clients.

Move only request planning, profile selection, and receipt construction behind a shared façade.

## 20. Consolidation candidates

| Candidate | Evidence | Safe target | First safe move |
|---|---|---|---|
| rust/src/core/ocla and rust/crates/lean-ctx-ocla | 20,732 LOC engine-local versus 1,508 LOC crate; only three direct crate consumers | lean-ctx-ocla owns contracts; core owns implementations | Add trait/type adapters and re-export current engine behavior. |
| rust/src/core/context_{kernel,os,ops,package,ledger,snapshot,prefetch} and session | Multiple session/context owners | ContextSession façade with internal components | Define façade state transitions and adapters. |
| rust/src/core/mcp_catalog, plugins, editor_registry and core/ocla registry/catalogue | Several discovery/registry concepts | OCLA registry/capability catalog vocabulary | Define a single logical catalog API, retain each backing store. |
| rust/src/tools implementations and tools/registered wrappers | Parallel implementation/wrapper trees | Manifest-derived MCP registration descriptor | Share schemas, metadata, policy declaration, and receipt builder. |
| core measurement, savings_ledger, execution_ledger, outcome, stats, proxy usage | Several evidence and economic paths | Protocol receipt/usage/outcome vocabulary | Add conversion functions and correlation identifiers. |
| core config/profiles/policy/mdl_mode/auto_mode | Multiple profile/tuning carriers | Versioned TuningProfile projection | Read existing config first; write no new default behavior. |
| core providers, web, proxy adapters, a2a, sidecar transport | Provider and transport concern spread across folders | Capability adapters under runtime façade | Standardize envelope and provenance, not provider implementation. |

## 21. Archive candidates

| Path | Evidence | Action |
|---|---|---|
| rust/experiments/grammar-dlopen-spike/host | Cargo comments call it standalone manual verification, Phase-0 spike, not release pipeline | Move out of default workspace only after grammar-addon regression coverage; retain source. |
| rust/src/core/cognitive | CODEBASE-MAP classifies advanced optimization as scaffolded/park | Feature-gate and make benchmark-required; do not delete. |
| rust/src/core/neural | Same advanced optimization classification | Feature-gate and make benchmark-required; do not delete. |
| rust/src/core/ib | Same advanced optimization classification | Feature-gate and make benchmark-required; do not delete. |
| rust/src/core/locomo | Same advanced optimization classification | Feature-gate and make benchmark-required; do not delete. |
| rust/src/core/wasserstein | Same advanced optimization classification | Feature-gate and make benchmark-required; do not delete. |
| rust/src/core/gain, buddy, codesign, community, gotcha_tracker, stigmergy | No direct target ownership in the reviewed vision; retain internal references | Put under explicit experimental/product scope before considering a workspace move. |

## 22. Delete candidates

No DELETE recommendation is justified by this audit.

Reason one: static references show the considered experimental modules are not simply unreachable files.

Reason two: the vision asks for responsibility mapping before physical refactoring.

Reason three: current OSS behavior must remain functional.

Reason four: line count is never sufficient evidence for deletion.

Any future deletion candidate needs all of the following:

- no production or test references after feature-gate removal;
- an explicit replacement with contract/conformance coverage;
- a separately reviewed branch;
- a deprecation notice where externally reachable;
- passing workspace, default-member, and compatibility tests.

## 23. Recommended Phase-A work

1. Add an ownership matrix to the repository, generated or maintained from this audit.

2. Treat rust/src/engine as the compatibility façade seed.

3. Define a ContextSession façade without moving current context modules.

4. Record the current state transitions for session, package, execution ledger, and snapshots.

5. Add a protocol-to-engine conversion test suite for task, evidence, execution, outcome, usage, and savings.

6. Add an OCLA conformance test suite that uses existing core OCLA builtin providers.

7. Build one capability descriptor for existing Read, Search, Compress, Shell, Memory, and Code surfaces.

8. Have registered MCP wrappers read the descriptor in shadow mode first.

9. Record profile compatibility alongside existing config and policy selection.

10. Keep all existing module paths and MCP names unchanged.

11. Add receipt fields behind optional protocol values or versioned envelopes.

12. Keep policy, path jail, input filters, and shell allowlist enforcement exactly where it is.

13. Keep proxy provider translations unchanged.

14. Keep vendored rmcp independent from product capability ownership.

15. Add benchmark gates before enabling an archived optimizer by default.

## 24. Recommended Phase-B work

1. Expand lean-ctx-ocla traits, manifests, adapters, and conformance modules.

2. Re-export compatibility types from rust/src/core/ocla.

3. Add adapters for compressor, search, read, shell, knowledge, repomap, and code signatures.

4. Add a ContextSession constructor that delegates to existing kernel/session implementation.

5. Add a TuningProfile projection from the existing config/profiles/policy stack.

6. Add kit metadata around existing rust/src/kits behavior.

7. Add protocol receipt conversions for execution ledger, savings ledger, usage, outcome, and provenance.

8. Add manifest-derived metadata to registered MCP tool wrappers.

9. Add adapter-level conformance tests that compare old and new outputs.

10. Keep direct engine entrypoints operational during all of the above.

## 25. Recommended Phase-C work

1. Migrate one capability implementation at a time behind the established OCLA trait.

2. Migrate context ownership only after ContextSession façade coverage is complete.

3. Merge logical registry ownership while preserving existing MCP catalog, plugin, and editor queries.

4. Make experimental optimizer paths opt-in by explicit feature or non-default kit.

5. Remove the grammar-dlopen spike from workspace membership only after CI proves addon coverage.

6. Publish deprecation notes before changing public SDK or MCP behavior.

7. Do not use a Phase-C move to bundle an algorithm rewrite.

## 26. Compatibility gates for every future move

- Default rust crate builds unchanged.

- Default rust crate tests unchanged.

- Workspace build is explicitly tested when a shared crate changes.

- Cargo clippy remains warning-free.

- Cargo fmt remains clean.

- Existing MCP method names and schemas remain accepted.

- Existing CLI command paths remain accepted.

- Existing proxy provider request/response shapes remain accepted.

- Policy and path-safety checks execute before and after capability dispatch as they do today.

- A receipt/profile addition must be optional or versioned until consumers migrate.

- Old and new OCLA paths must have conformance tests covering the same native provider.

## 27. Bottom line

The repository already contains the composable architecture's most important seeds.

lean-ctx-protocol is a real portable vocabulary crate with existing engine adoption.

lean-ctx-ocla is a real but under-adopted contract crate.

lean-ctx-sdk is a viable opt-in external façade seed.

The main engine has strong native capability implementations for compression, retrieval, code understanding, shell, memory, safety, measurement, and proxy integration.

The main deficiency is ownership convergence, not absence of capability code.

The highest-value work is to normalize and consolidate through adapters.

The highest-risk mistake would be a bulk directory move or deletion campaign.

No production module should be removed as part of the initial composable-vision implementation.

