# H16 — ContextSession design

## Decision

`ContextSession` is the runtime-owned, task-scoped aggregate for one agent or
workflow run.  It is the only object allowed to join:

- a task and its lineage;
- one pinned `TuningProfile` and the resolved Context Kits;
- every selection, materialization, compression, reuse, recovery, and model call;
- observed token/cost/latency data and quality signals; and
- immutable execution receipts and their evidence.

It is not a synonym for a process, a browser connection, an MCP server, a
workspace-wide memory store, or a provider conversation.  Those things can
feed one or more sessions.  A session has exactly one root task, although it
may record child-task spans when an agent delegates within that root task.

The public primitive is `ContextSession`; `SessionState` becomes a legacy
continuity projection owned by it, not the SDK's product model.

### Workspace boundary

An optional `workspace_id` or Context OS workspace/channel label is attribution
or stream partitioning only. It is **not** a current public
`ContextWorkspace`, workspace-wide memory store, checkpoint head, or
cross-session authority.

A future local-first ContextWorkspace may become a semantic parent for bounded
sessions only after the Session contract, source freshness, checkpoint,
policy, package and migration boundaries have separate versioned evidence. It
must compose this task-scoped aggregate; it must not create a competing
session/receipt/cache model or take ownership of agent execution. See
[Context Workspace & `.ctxpkg` Plan](../vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md).

## Goals and non-goals

Goals:

- Make a tuning choice reproducible by pinning profile, Kit and policy inputs.
- Make context cost and quality attributable to the same task lineage.
- Work for Embed, Wrap, and the weaker Attach integration depth.
- Keep local use, offline persistence, and evidence verification first class.
- Let a caller recover safely after a runtime or agent restart.
- Avoid holding locks across filesystem, network, provider, or agent work.

Non-goals:

- Do not become a generic agent framework or execute arbitrary agent code.
- Do not force a model/provider choice when the host agent owns routing.
- Do not persist raw prompts, raw provider bodies, credentials, or secrets merely
  to produce a receipt.
- Do not claim full causal quality attribution in Attach mode.
- Do not change already-shipped `ExecutionReceiptV1` fields in place.

## Core invariants

1. `session_id`, `task_id`, `run_id`, `agent_id`, and `project_id` are set at
   creation and never changed.
2. A profile is resolved to an immutable `(id, version, content_hash)` before
   any context is prepared; the mutable "active profile" is not receipt input.
3. Every resolved Kit records `(id, version, package_hash, activation_ref)`.
4. Every context action carries a monotonically increasing sequence number and
   a source/provenance reference.  Derived aggregates never replace that record.
5. Token accounting distinguishes original, materialized, delivered, provider
   billed, provider cached, output, and reasoning tokens.  "saved" is derived,
   never supplied as an unverified headline number.
6. A final receipt is immutable and content-addressed.  Late evaluator or human
   feedback creates a signed amendment/reference, not an edited receipt.
7. Reopening a durable session verifies its pinned profile and Kit hashes before
   execution can resume.  A mismatch yields degraded read-only inspection or an
   explicit new continuation session, never silent substitution.
8. All externally supplied IDs are bounded opaque identifiers and are accepted
   for cross-boundary attribution only after the appropriate authentication
   boundary has established trust.

## Lifecycle

| Phase | Entry | Allowed work | Exit |
| --- | --- | --- | --- |
| `Created` | `LeanCTX.session(...)` / runtime `create` | identity, task envelope, root safety checks | `configure` or `abort` |
| `Configured` | profile/Kits/policy resolved and frozen | inspect configuration, attach to agent | `prepare`, `resume`, or `abort` |
| `Executing` | first `prepare`, context/tool/model event, or recovered active run | plan, select, materialize, compress, reuse, recover, record usage and quality | `complete`, `fail`, or `abort` |
| `ReceiptReady` | terminal outcome accepted by the session | build and verify final receipts and evidence | `close` |
| `Closed` | receipt/checkpoint durably committed | inspection, export, receipt verification only | none |
| `Aborted` | explicit cancel or unrecoverable setup failure | produce an incomplete receipt if any execution occurred | `close` |

### Create

`create` receives `task`, `agent_id`, project/workspace identity, optional parent
task, requested profile, requested Kit references, integration depth, and caller
capabilities.  It creates a root `TaskEnvelopeV1` and a UUID/opaque session ID.
`run_id` identifies the particular agent invocation; a resumed session retains
`session_id` and `task_id` but gets a new `run_id` span.

Creation must reject an empty task, unsafe project root, invalid identities, or
a profile request that cannot be resolved.  It may persist the creation event
immediately, so a crash before preparation remains explainable.

### Configure

`configure` resolves and validates the profile, loads and verifies Kits, chooses
the Runtime capability set, establishes budgets and quality gates, and records
the integration coverage.  It writes a `ConfigurationSnapshot`; it does not
retain a pointer to a mutable global active profile.

Configuration is single-assignment.  A user who wants another profile starts a
new continuation session linked through `parent_session_id`; this prevents one
receipt from mixing treatment arms.  An implementation may permit adding a
late Kit only by opening a new explicit `configuration_revision`, recording a
new plan boundary and making that revision visible in the receipt.

### Execute

`prepare(request)` invokes Context Kernel planning and returns a typed
`ContextEnvelope`, not an unbounded blob.  The envelope contains selected items,
their selected views, token estimates, source/recovery references, and the plan
ID.  The host agent runs normally and reports or permits interception of:

- `retrieve` and `select` decisions;
- `materialize` and `compress` results;
- cache/reuse/dedup decisions;
- tool calls and their digest evidence;
- provider request/response usage; and
- recovery, retry, evaluator, test, and human-acceptance signals.

Every reporting call is idempotent on a caller-generated event ID.  This is
important because provider callbacks and proxy retries are at-least-once.

### Receipt

`complete(outcome)` validates terminal-state and budget invariants, seals the
event sequence, builds evidence bundles, and emits a final receipt.  `receipt()`
before completion returns a clearly labelled non-authoritative preview; it must
never be confused with proof.  `receipt()` after sealing is idempotent and
returns the same receipt ID and bytes.

`close()` flushes the checkpoint and releases process-local resources.  It does
not delete evidence or make the session unavailable for inspection.  A
best-effort shutdown creates an `Aborted` receipt only when sufficient execution
events exist; it must state that no terminal quality outcome was observed.

## Internal state

### Immutable identity and configuration

```text
SessionIdentityV1
  session_id, task_id, run_id, trace_id, parent_task_id?
  agent_id, project_id, workspace_id?, tenant_id?
  project_root_ref, project_revision_ref?, created_at

ConfigurationSnapshotV1
  tuning_profile: { id, version, content_hash, source_ref }
  kits: [{ id, version, package_hash, activation_ref }]
  budget: { context_tokens, cost_micros?, latency_ms?, retries }
  quality_contract: { gates, evaluator_ref?, threshold? }
  policy_refs, provider_preferences, integration_depth, coverage
```

`project_root_ref` should be a protected local URI or digest, not a public path
when privacy/export policy requires redaction.  `project_revision_ref` is a VCS
revision or content snapshot digest and is required for a replayable receipt.

### Mutable execution projection

```text
SessionProjectionV1
  phase, revision, current_run_span, sealed_at?
  plans: BTreeMap<PlanId, PlanRecord>
  selections: Vec<SelectionRecord>
  transformations: Vec<TransformationRecord>
  reuse: Vec<ReuseRecord>
  recovery: Vec<RecoveryRecord>
  tool_calls: Vec<ToolObservation>
  model_calls: Vec<ModelObservation>
  usage: SessionUsageTotals
  quality: QualityState
  evidence: EvidenceIndex
  legacy_continuity: LegacyContinuityProjection
```

The projection is a cache derived from the append-only event stream.  It may
retain bounded detail for hot access, but its totals and receipt references must
be reproducible from durable events.  Bounded hot lists are not an excuse to
discard evidence needed for a final receipt.

### Event categories

| Category | Required record |
| --- | --- |
| selection | candidate ID, selected view, reason, estimated tokens, plan ID |
| transformation | source ID/digest, mode, original/materialized/delivered tokens, output digest |
| reuse | cache/reuse key, hit/miss, freshness and invalidation reason |
| tool | tool name/action, input/output digests, duration, task/session lineage |
| model | provider/model route, request/response usage, latency, retry, raw-body digest ref |
| recovery | trigger, reference recovered, scope, success/failure, extra token cost |
| quality | source (test/evaluator/human), gate, value, pass/fail/unknown, evidence ref |
| lifecycle | create/configure/prepare/complete/abort/close and actor |

Use source digests, canonical reference IDs, bounded metadata, and classification
labels.  Store content only when the user-selected retention policy explicitly
allows it and the storage is encrypted/protected.

### Token and quality accounting

`SessionUsageTotals` maintains four monotonic context stages already modelled by
`ContextBalanceV1`:

```text
original >= materialized >= delivered
provider_billed may differ from delivered because of provider tokenization/cache
fresh_input + cached_input + output + reasoning are provider observations
```

It separately tracks estimated versus provider-reported tokens, unpriced versus
priced cost, cache reads/writes, retries, tool tokens, and unknown values.  An
unknown provider value remains unknown in session events; only legacy fixed-width
receipt projections use zero where their current schema requires it.

`QualityState` tracks declared gates, observations, their provenance, whether
each is pending/pass/fail/unknown, and the terminal decision.  First-pass or
retry inference is a low-confidence observation, never equivalent to a test or
human acceptance.

## Rust object design

### Public handle and runtime boundary

```rust
#[derive(Clone)]
pub struct ContextSession {
    inner: Arc<ContextSessionInner>,
}

struct ContextSessionInner {
    identity: SessionIdentityV1,
    state: tokio::sync::RwLock<SessionProjectionV1>,
    next_event_seq: AtomicU64,
    event_ids: EventDeduplicator,
    store: Arc<dyn ContextSessionStore>,
    runtime: Arc<dyn ContextRuntime>,
    clock: Arc<dyn Clock>,
}

pub struct CreateSessionRequest {
    pub task: TaskEnvelopeV1,
    pub requested_profile: ProfileSelector,
    pub requested_kits: Vec<KitSelector>,
    pub integration: IntegrationDescriptor,
}

impl ContextSession {
    pub async fn create(
        runtime: Arc<dyn ContextRuntime>,
        store: Arc<dyn ContextSessionStore>,
        request: CreateSessionRequest,
    ) -> Result<Self, SessionError>;

    pub async fn configure(&self, request: ConfigureSessionRequest)
        -> Result<ConfigurationSnapshotV1, SessionError>;

    pub async fn prepare(&self, request: ContextRequestV1)
        -> Result<ContextEnvelopeV1, SessionError>;

    pub async fn observe(&self, event: SessionEventV1)
        -> Result<ObservationAck, SessionError>;

    pub async fn complete(&self, outcome: OutcomeInputV1)
        -> Result<SessionReceiptV1, SessionError>;

    pub async fn receipt(&self) -> Result<SessionReceiptViewV1, SessionError>;
    pub async fn close(&self) -> Result<(), SessionError>;
    pub async fn checkpoint(&self) -> Result<CheckpointRef, SessionError>;
}
```

`ContextRuntime` is the narrow bridge to selection, compression, Kit loading,
policy, provider normalization, and evidence ledger services.  `ContextSession`
does not duplicate Context Kernel algorithms.  It supplies immutable
configuration and lineage, calls the runtime, then records the resulting facts.

### Configuration and state types

```rust
pub enum SessionPhase {
    Created,
    Configured,
    Executing,
    ReceiptReady,
    Closed,
    Aborted { reason: AbortReason },
}

pub struct ContextSessionState {
    pub phase: SessionPhase,
    pub configuration: Option<ConfigurationSnapshotV1>,
    pub active_plan: Option<PlanId>,
    pub projection: SessionProjectionV1,
    pub receipt_ref: Option<ReceiptRefV1>,
    pub last_checkpoint: Option<CheckpointRef>,
}

pub enum SessionEventV1 {
    Created { event_id: EventId, identity: SessionIdentityV1 },
    Configured { event_id: EventId, config: ConfigurationSnapshotV1 },
    ContextPlanned { event_id: EventId, plan: ContextPlanV1 },
    ContextDelivered { event_id: EventId, delivery: ContextDeliveryV1 },
    ToolObserved { event_id: EventId, observation: ToolObservation },
    ModelObserved { event_id: EventId, observation: ModelObservation },
    QualityObserved { event_id: EventId, observation: QualityObservation },
    RecoveryObserved { event_id: EventId, observation: RecoveryRecord },
    Completed { event_id: EventId, outcome: OutcomeInputV1 },
    Aborted { event_id: EventId, reason: AbortReason },
}
```

The real types should use validated protocol newtypes (`TaskId`, `SessionId`,
`PlanId`, `ReceiptId`, `AgentId`, and `ProjectId`) rather than unvalidated
`String`s.  `BTreeMap` and sorted reference sets are preferred wherever data is
included in a canonical receipt.

### State transition rules

```text
Created      + configure             -> Configured
Configured   + prepare/observe        -> Executing
Executing    + observe                -> Executing
Executing    + complete               -> ReceiptReady
Created|Configured|Executing + abort  -> Aborted
ReceiptReady|Aborted + close           -> Closed
Closed       + any mutating operation  -> SessionClosed error
```

`prepare` is forbidden before configuration.  `complete` is forbidden if a
required quality gate is still pending unless the supplied outcome explicitly
records `quality_status = unknown` or the caller has the configured authority
to waive it.  A failure in receipt storage leaves the session in `Executing`
with a durable `complete_requested` event, so retrying completion cannot invent
a second result.

### Legacy compatibility

`SessionState` remains useful as `LegacyContinuityProjection`:

- task, findings, decisions, files touched, test snapshot, progress, and next
  steps become selected event-derived convenience views;
- its compaction snapshot and resume block remain agent-facing recovery aids;
- its existing `playbook`, handoff knowledge, LITM manifest, and live-zone state
  stay runtime services referenced by the new session; and
- `SessionState::save` is replaced gradually by session checkpoint persistence.

Do not embed a `tokio::RwLock<SessionState>` inside a new session and call that
the design.  It has neither frozen configuration, per-event lineage, profile/
Kit provenance, quality state, nor a final receipt seal.

## Python API surface

The Python package should lead with a high-level `LeanCTX` client while retaining
`LeanCtxClient`, `ProxyClient`, and `compress()` as compatibility utilities.

```python
from lean_ctx import LeanCTX, QualityOutcome

ctx = LeanCTX(project=".", agent_id="review-bot")

async with ctx.session(
    task="Review PR #482",
    profile="payments-review@1.4.2",
    kits=["payments-security@2.1"],
    workspace_id="payments",
) as session:
    envelope = await session.prepare()
    result = await agent.run(task=session.task, context=envelope)

    await session.observe_tool_result(result.tool_events)
    await session.observe_model_result(result.model_usage)
    await session.observe_quality(QualityOutcome.accepted("reviewer-approval"))
    receipt = await session.complete(result.outcome)

print(receipt.receipt_id)
```

Convenience synchronous methods can be provided separately (`LeanCTXSync`), not
by calling `asyncio.run()` inside a running event loop.  The asynchronous client
should use the Runtime handshake/API, not spawn the CLI for every operation.

```python
class LeanCTX:
    def __init__(self, project: str | Path, *, agent_id: str | None = None,
                 endpoint: str | None = None, token: str | None = None): ...
    def session(self, *, task: str | TaskSpec, profile: ProfileSelector,
                kits: Sequence[KitSelector] = (), workspace_id: str | None = None,
                parent: SessionRef | None = None) -> ContextSession: ...
    async def resume(self, session_id: str, *, run_id: str | None = None)
        -> ContextSession: ...
    async def load_profile(self, selector: ProfileSelector) -> TuningProfile: ...
    async def load_kit(self, selector: KitSelector) -> ContextKit: ...

class ContextSession:
    id: str
    task: TaskSpec
    profile: ResolvedTuningProfile
    kits: tuple[ResolvedContextKit, ...]
    async def prepare(self, request: ContextRequest | None = None) -> ContextEnvelope: ...
    async def observe(self, event: SessionEvent) -> ObservationAck: ...
    async def complete(self, outcome: Outcome) -> SessionReceipt: ...
    async def receipt(self, *, preview: bool = False) -> SessionReceipt | ReceiptPreview: ...
    async def checkpoint(self) -> CheckpointRef: ...
    async def close(self) -> None: ...
```

`ContextEnvelope` exposes selected references, text payloads where materialized,
estimated tokens, plan ID, recovery handles, and metadata.  It must not require
Python callers to understand Context Kernel's individual tool implementations.

`SessionReceipt` exposes `execution_receipts`, profile and Kit references,
quality result, evidence bundle, integrity status, and an exportable canonical
JSON form.  It should not return raw evidence content by default.

### Wrap API

```python
agent = ctx.wrap(existing_agent, profile="balanced")
result = await agent.run("Review the payments module")
print(result.leanctx.receipt)
```

`wrap` creates the session before the first agent action, calls `prepare`,
injects the envelope according to the framework adapter, propagates session
lineage to tool/provider hooks, and finalizes on success/failure/cancellation.
The wrapper must preserve agent semantics: a telemetry or Runtime failure uses
the adapter's declared fail-open/fail-closed policy and records the degradation.

## Proxy interaction

### Attach mode

Attach is observational/transformational.  The proxy normally sees an outbound
provider request after the host agent chose its context, so it cannot honestly
claim it planned the first prompt.  A session created by an Attach handshake
therefore records `integration_depth = attach` and per-event coverage such as
`observed`, `compressed`, or `not_addressable`.

The connecting client binds the session to every request with trusted lineage:

```text
x-leanctx-session-id: <opaque session id>
x-leanctx-agent-id:   <opaque agent id>
x-leanctx-task-id:    <opaque task id>
x-leanctx-trace-id:   <opaque trace id>
```

The gateway accepts these fields for receipt attribution only after its auth
middleware marks the request as trusted.  Provider-key fallback and arbitrary
localhost callers remain unmanaged; they must not be allowed to write events to
someone else's session.  IDs are validated, bounded, and correlated with the
Runtime session identity.

For each proxy turn, the bridge records a `ModelObservation` with request/response
usage, compression balance, provider/model route, retry, latency, raw-request
digest reference, and coverage.  If usage is unavailable, that fact is recorded;
the proxy does not synthesize it from compression estimates.  Attach outcomes are
heuristics unless a connected evaluator/human/tool supplies a stronger signal.

### Wrap and Embed mode

Wrap creates and binds a session before the agent chooses context.  It can call
`prepare()` before an LLM request, feed the selected envelope to the agent, and
attach the same headers to every provider call.  It also observes framework tool
calls and explicit evaluator results.  It is eligible for `context_controlled`
or `full_inline` coverage, depending on whether the adapter can actually insert
and account for the planned envelope.

Embed performs the same lifecycle through the native Runtime client instead of
HTTP headers where possible.  The receipt still uses the same contracts; only
the transport/coverage differs.  This is essential for a fair Stock/Attach/
Embed benchmark.

### Existing proxy changes required

The current `/v1/compress` endpoint is intentionally a pure deterministic
`messages -> messages + stats` function.  Keep that property.  Add a separate
authenticated session-event endpoint or a request-scoped side channel; do not
make its response body depend on clocks, global counters, or mutable receipt
state.  The returned messages must stay byte-stable for provider caching.

The proxy currently carries trusted request/session/agent lineage in
`proxy/lineage.rs`, but no task ID.  Add task and trace propagation only after a
protocol versioned header contract and authenticated gateway verification exist.
The legacy local compression endpoint may report a standalone `CompressResult`
without pretending it belongs to a ContextSession.

## Receipt design

### Why a session receipt wraps rather than mutates `ExecutionReceiptV1`

The existing protocol `ExecutionReceiptV1` uses `deny_unknown_fields` and lacks
profile/Kit IDs, run/session identity, evaluator state, timestamps, and a list
of provider route observations.  Adding fields ad hoc would break conformance.

Keep it as the canonical per-execution accounting receipt.  Introduce a versioned
wrapper, `SessionReceiptV1`, and evolve an execution V2 only through the protocol
crate and conformance fixtures.

```text
SessionReceiptV1
  schema_version, receipt_id, session_id, task_id, run_id, trace_id
  identity: agent/project/workspace references
  configuration: profile reference + resolved Kit references + policy refs
  integration: declared depth + observed coverage summary
  execution_receipts: [ExecutionReceiptRefV1]
  context_summary: plans, selections, transforms, reuse, recovery totals
  quality: contract, observations, terminal outcome, outcome_ref
  economics: pricing-table ref, treatment/baseline refs when applicable
  evidence_bundle_ref, checkpoint_ref?, methodology_version
  canonical_hash, signature, signer_key_id, emitted_at
```

One session can contain multiple provider/model routes.  Do not collapse mixed
routes into a single `ExecutionReceiptV1` whose singular `provider` and
`selected_model` would be misleading.  Emit one receipt per compatible route or
execution plan, then reference all of them from the session receipt.

### Receipt assembly

1. Freeze the terminal event sequence and calculate a stable event-log root.
2. Build each `ExecutionReceiptV1` using the existing `ReceiptBuilder` from
   normalized provider usage, `ContextBalanceV1`, decision/knowledge refs, and
   typed evidence references.
3. Derive quality status only from recorded observations; include confidence and
   source but never upgrade an inference to a definitive test result.
4. Finalize the task-scoped `EvidenceBundle`; verify all evidence has the same
   task lineage and its bundle hash is valid.
5. Canonicalize sorted reference fields, hash the `SessionReceiptV1`, sign it
   with the agent/runtime key, atomically persist it, then mark the session
   `ReceiptReady`.

Receipts must distinguish `observed`, `estimated`, `declared`, and `unknown`.
Savings claims additionally require a compatible baseline/treatment method and
quality result; that comparison belongs in `SavingsReceipt`, not a fabricated
baseline field on every ordinary session.

## Thread and async safety

`ContextSession` is `Clone + Send + Sync`; cloned handles refer to the same
session identity and durable event stream.  Its state uses `tokio::sync::RwLock`
because MCP/runtime paths are asynchronous.  Lock scopes are short:

1. validate the transition and reserve an event sequence under write lock;
2. release the lock before Runtime, disk, proxy, or provider work;
3. append the durable event idempotently;
4. reacquire write lock, apply the event only once, and enqueue a checkpoint.

Use a per-session async mutex or optimistic `revision` compare-and-swap around
terminal transitions, so simultaneous `complete`, proxy callback, and shutdown
cannot emit two receipts.  A receipt's event-log root includes the final sealed
sequence, making a lost/late event detectable.

Never use the current process-global `OnceLock<Mutex<SessionUsage>>`, proxy
identity ledger, or receipt chain as a source of truth for a session receipt.
They remain dashboard aggregates.  Their process-local nature mixes unrelated
sessions and loses attribution across restart.

Background persistence receives serialized immutable event/checkpoint work over
a bounded channel.  Backpressure is explicit: critical lifecycle/model/quality
events wait or fail safely; low-value telemetry may be sampled only with a
recorded sampling decision.  Poisoned lock recovery should log and preserve the
event store, not silently reset session state.

## Persistence and restart recovery

Yes: a ContextSession can survive restart, but recovery has defined boundaries.

Suggested local layout:

```text
<lean-ctx-data>/context-sessions/<session-id>/
  meta.json                 # identity + immutable configuration snapshot
  events-000001.jsonl       # append-only canonical event segments
  checkpoint.json           # projection and last sealed event sequence
  receipts/<receipt-id>.json
  evidence/<bundle-hash>.json
  lock                      # advisory single-writer lease metadata
```

Use atomic temp-file-plus-rename for metadata, checkpoints, receipts, and
segments; restrict local files to owner read/write (`0600` on Unix); never trust
a path derived from an unchecked ID.  Write a checkpoint after creation,
configuration, terminal events, and a bounded interval/number of events.

On restart, load metadata, validate schema/version/signatures, replay events
after the checkpoint, recompute the projection, and compare the event-log root.
Then verify that the profile hash, Kit hashes, project revision, and policy are
available.  The resulting state is one of:

- `resumable`: all pinned assets and project identity match;
- `resumable_with_degradation`: nonessential caches/live zone are absent but
  context can be rebuilt and the recovery event is recorded;
- `inspect_only`: receipt/history is valid but configuration cannot be faithfully
  restored; or
- `corrupt`: integrity failure, no automatic execution resume.

Provider cache prefixes and sockets are explicitly process-local.  This agrees
with the current `LiveZoneSessionState`, which is skipped during persistence.
They are re-established after restart and never claimed as persistent cache hits.

The existing CCP session bundle can export/import a redacted continuity snapshot.
It should become one permitted export representation of ContextSession state,
but importing it must create a new continuation session with provenance to the
source bundle rather than overwrite a sealed receipt history.

## Mapping to the current codebase

| Existing code | What it does today | ContextSession disposition |
| --- | --- | --- |
| `rust/src/core/session/types.rs` | Durable task/findings/decisions/files/progress/evidence/stats | Retain as the legacy continuity projection; migrate fields to typed session events. |
| `rust/src/core/session/state.rs` | Mutates a bounded in-memory `SessionState`, tracks file access and simple counters | Keep convenience operations, but route mutations through ContextSession events. |
| `rust/src/core/session/persistence.rs` | Per-session JSON, latest pointer, atomic save, 0600 files, project-root matching | Reuse its atomic/safe storage practices; replace one mutable JSON with metadata, event segments, checkpoint, receipts. |
| `rust/src/core/session/compaction.rs` and `playbook.rs` | Resume blocks, compact snapshot, stable delta playbook | Preserve as recovery/read-model services referenced from session state. |
| `rust/src/tools/server.rs` | `LeanCtxServer` owns `Arc<RwLock<SessionState>>` for one MCP server | Replace with `Arc<ContextSession>` plus a legacy projection adapter; session registry needed for multiple bound sessions. |
| `rust/src/tools/server_lifecycle.rs` | Personal starts a fresh session; shared mode retrieves shared state; shutdown saves/records episode | Create/configure/bind/close ContextSession at these lifecycle boundaries. |
| `rust/src/tools/ctx_session.rs` | Commands for status/save/load/export/task/finding/decision/profile/snapshot | Preserve UX while mapping actions to session methods; `profile` becomes configure/create-continuation, not global mutation. |
| `context_kernel/types.rs` | Context objects, plans, lightweight `ContextReceiptV1` | Session owns their lineage and turns selected plans/deliveries into events. |
| `context_kernel/receipt_builder.rs` | Deterministic signed `ExecutionReceiptV1` builder | Reuse per execution route; add `SessionReceiptV1` as immutable parent. |
| `context_kernel/evidence_bundle.rs` | Task-scoped typed reference bundle with a hash | Use as final evidence input and require it before sealing a receipt. |
| `context_kernel/token_envelope.rs` | Provider-neutral request accounting | Convert every model observation into a session-scoped envelope. |
| `context_kernel/proxy_bridge.rs` | Process-global identity/ETPAO metrics for proxy requests | Keep for operational dashboards only; bind observations to sessions for evidence. |
| `context_kernel/usage_normalizer.rs` and `receipt_chain.rs` | Process-global totals and volatile chain entries | Do not use as receipt authority; refactor to accept `session_id` or derive from event store. |
| `context_kernel/recovery.rs` | Kernel snapshot of weights/plans/receipts | Incorporate as a Runtime dependency snapshot, not a substitute for session event recovery. |
| `proxy/compress_api.rs` | Pure deterministic request compression and token stats | Keep pure; report its outcome to session side-channel only when binding exists. |
| `proxy/lineage.rs` | Trusted request/session/agent headers, currently taskless | Extend in a versioned authenticated contract to carry task/trace and correlate a session. |
| `packages/python-lean-ctx/lean_ctx/client.py` | CLI subprocess convenience wrapper | Keep as backwards-compatible low-level utility; do not build the Session API on subprocess calls. |
| `packages/python-lean-ctx/lean_ctx/proxy.py` | `/v1/compress` client and `CompressResult` | Retain for Attach compression; add optional Session binding/observation client. |
| Python LiteLLM/LangChain/LlamaIndex adapters | Rewrite messages or invoke CLI reads/searches | Add Wrap hooks that create/bind/finalize ContextSession and observe provider/tool outcomes. |

## Important gaps in the current implementation

- `SessionState` identity has only its generated ID and optional project root;
  it lacks task/run/trace/agent/project/workspace identity as immutable contract.
- Task selection, profile selection, Kit loading, and receipt construction are
  not unified under one object or one transition system.
- The current active profile is global and mutable; receipts cannot prove which
  profile bytes controlled a run.
- Existing session evidence records tool digests but not all selection,
  transformation, recovery, model, quality, and Kit provenance required for a
  tuning receipt.
- The receipt protocol has strong canonical accounting but is not yet a complete
  session-level receipt and cannot safely accept arbitrary extension fields.
- Proxy/kernel usage and receipt-chain state are global/in-memory, so they can
  mix sessions and cannot survive a restart as authoritative evidence.
- Python exposes compression and CLI helpers, not runtime session, profile, Kit,
  receipt, recovery, or Wrap lifecycle APIs.

## Incremental implementation plan

1. Add versioned protocol types: `SessionIdentityV1`, configuration/Kit refs,
   `SessionEventV1`, `SessionReceiptV1`, and conformance fixtures.  Keep
   `ExecutionReceiptV1` unchanged.
2. Implement `ContextSessionStore` with local atomic metadata/event/checkpoint
   persistence and replay tests before modifying MCP behaviour.
3. Implement `ContextSession` transitions and use `ReceiptBuilder` plus
   `EvidenceBundle` for finalization.  Add idempotency and concurrent-complete
   tests.
4. Add an adapter that keeps existing `SessionState`/`ctx_session` UX working
   while writes become ContextSession events.
5. Replace `LeanCtxServer.session: Arc<RwLock<SessionState>>` with a session
   handle/registry and bind MCP `TaskEnvelopeV1` identity to it.
6. Implement Runtime handshake, profile/Kit resolution and frozen hashes.
7. Add proxy observation side-channel and trusted Attach headers without changing
   deterministic compression response bodies.
8. Add Python `LeanCTX` and `ContextSession`, then Wrap integrations for one
   reference agent before broad framework rollout.
9. Verify Stock/Attach/Embed conformance with the same task, revision, model,
   budget, quality contract, and receipt methodology.

## Acceptance criteria

- A developer can create, prepare, run, complete, export, verify, and resume a
  session through one language-native API in under the strategy's 15-minute
  reference integration target.
- A final receipt names exact profile and Kit hashes, execution receipt(s),
  coverage, quality evidence, provider observations, and evidence bundle hash.
- Two racing completion attempts return one final receipt.
- Restart replay does not duplicate events or claim a provider cache/live zone
  survived when it did not.
- Attach receipts state their limited coverage; Wrap/Embed receipts can show the
  stronger planning coverage only when the adapter actually exercised it.
- Existing `ctx_session` status/restore/export workflows retain a migration path.
- Canonical receipt bytes and proxy compression bodies are deterministic for the
  same sealed inputs; dynamic timestamps remain metadata outside cache-critical
  transformed prompt bodies.
