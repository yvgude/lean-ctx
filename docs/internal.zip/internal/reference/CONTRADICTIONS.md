# Contradictions, resolutions, and missing pieces

> **Classification:** Reference
>
> **Status:** Preserved conflict history plus current resolutions. It records
> decisions but cannot override the canonical architecture.

## 2026-08-24 convergence resolutions

| Contradiction | Resolution |
| --- | --- |
| Engine/SDK repository split | DECIDED: public Apache-2.0 Engine → versioned Engine Protocol → separate Production SDK repository. Implementation follows the P3/P4 gate. |
| Production SDK license | DECIDED: BSL 1.1. Only Change Date, Change License, Additional Use Grant, use threshold, OEM/pricing and release parameters remain pending. |
| “SDK open” versus “SDK BSL” | Resolved in favor of BSL 1.1 for the separate Production SDK. Existing Engine and published Apache rights remain intact. |
| Product priority | Production SDK is Thinkery's primary product. Engine is the OSS substrate; Cloud is optional later expansion. |
| Buy versus build | Customers may build on Engine. LeanCTX wins by removing permanent lifecycle, adapter, compatibility, evidence, security and upgrade ownership—not by weakening Engine. |
| Engine/SDK leakage | Deterministic local mechanisms belong in Engine; customer-facing lifecycle, policy, adapters, compatibility, migrations, DX and OEM APIs belong in SDK. |
| Investor Narrative authority | Active support narrative only; it cannot define architecture, licensing, availability or Cloud status. |
| ContextWorkspace priority | Post-v1 Research after the five-primitives Production SDK path; not a P3/P4 prerequisite. |
| Cloud availability | Research, optional, separate private service/repo. Start only with metadata-first Receipt/Performance Board after local proof and owners. |
| OCLA ecosystem versus mechanism | OCLA is a bounded Engine mechanism: identity/version, manifest, bounded IO, policy, deterministic observation and evidence linkage. No marketplace/plugin economy claim. |
| Coding-agent wedge versus embedded destination | Attach is the Available wedge; Wrap/Embed are Preview. AI-native product embedding and downstream distribution are strategic without LeanCTX owning the agent. |
| Calibrator status | Research. Manual evaluated comparison is useful; simulated candidates are not customer evidence; no autonomous rollout or learned Selection Intelligence. |
| Control Plane/Fleet surfaces | Historical experimental non-v1 surfaces remain frozen; implementation existence does not make them product architecture. |
| P0–P4 status | Verified public integration `github/main@50edc68dfc`: P0 complete, P1 complete, P2 active, P3 next/blocked on P2, P4 not entered. Isolated worktrees are not completion evidence. |
| Premium/lean engineering | Premium means reliable, secure, predictable, explicit and excellent to integrate. Lean means fewer concepts/states/contracts and divergent truths—not minimum LOC. Testing is proportional to risk; a real vertical slice outranks test-count theatre. |

### Deliberately pending

- Production SDK repository visibility/access and administrative owner.
- Distribution namespace and registry owner.
- BSL Change Date, Change License and Additional Use Grant.
- Evaluation/development and production/free-use boundary.
- OEM redistribution terms, pricing and enterprise exceptions.
- Contributor, release and security process.
- Promotion decisions for Workspace, Cloud, Calibrator, Continuous Optimization
  and Selection Intelligence.
- Approved durable private versioning target for `docs/internal/**`.


## Execution status — 2026-08-21

Several contradictions about multiple Python/TS SDK roots are **resolved in the tree** (duplicates archived). Remaining live contradiction: legacy GitLab milestones (Phase 0–5 / GTM / v1.0 2027) vs WS-1–WS-5. Delivery follows [`../execution/MASTER-EXECUTION-PLAN.md`](../execution/MASTER-EXECUTION-PLAN.md) only.

## Resolution rule

H1’s frozen product direction and H8’s anti-roadmap control scope. Technical reports describe implementation choices only after they pass that scope test. Anything not necessary for the first local, verifiable proof loop is deferred.

## Contradictions requiring a decision

| Topic | Tension | Resolution recommendation |
|---|---|---|
| Canonical receipts | H1/H2/H7 name ExecutionReceiptV1, SavingsReceiptV1, and EvidenceBundleV1. H3 adds Dyno-specific receipts; H6 proposes ReceiptDocumentV1 and evidence-bundle-v2; H16 proposes SessionReceiptV1. | Keep current ExecutionReceiptV1 immutable as a compatibility projection. Define a layered public model: SessionReceiptV1 for one task, Dyno arm/quality/comparison receipts for controlled proof, and SavingsReceiptV1 as a compatible comparison projection. Publish one logical EvidenceBundleV1; if its archive format must be v2, name that field separately and document migration. Do not ship competing top-level receipt families. |
| Integration taxonomy | Historical plans require Attach → Wrap → Embed → Run later. Current canonical docs use three depths, while installer commands sometimes reuse the same words. | Make **Attach → Wrap → Embed** normative. Attach is external local integration; Wrap is a bounded SDK/reference wrapper; Embed is native SDK integration. `Run later` is deferred managed execution / Cloud Research, not a fourth OSS depth. Installer commands are installers—not taxonomy definitions. |
| First POC scope | H12 proposes one Python/OpenAI Agents SDK code-review agent and one Kit. H5 proposes four built-in Kits and packaging commands. H19 starts a future control-plane foundation. | This quarter: one reference agent, one pinned workload, one code-review Kit, two arms, local bundle/verifier. The other three Kits, remote publication, registry, tenancy, and cloud work require proof/re-entry gates. |
| Metric language | H1/H7 define VCP-SAT; H14 also promotes CPAO; older surfaces center token savings. | Use VCP-SAT everywhere as the North Star. Cost per accepted outcome is explanatory prose only. A token reduction is a diagnostic, never the headline business result. |
| Profile format and CLI | H4 specifies TOML authoring, canonical JSON digest, and a new tuning-profile namespace. H18 shows YAML and reuses profile. | Freeze TOML authoring plus canonical JSON export. Use tuning-profile for TuningProfileV1; retain profile solely for legacy runtime presets during migration. A profile is not a free-form config overlay. |
| Profile timing | H4 provides a full Profile design now, while H15 makes Profile deployment conditional on a demonstrated reference/customer configuration. | Freeze the contract and local import path now, but do not make Profile lifecycle a P0 release blocker. Promote only controls shown to matter in the first controlled proof. |
| Python SDK ownership | H10/H15 choose packages/python-lean-ctx and lean_ctx. H17/H18 show leanctx or target package names, while three other Python trees have colliding namespaces and APIs. | Name packages/python-lean-ctx as the only v1 Python distribution root and lean_ctx as its primary import. Freeze py-sdk and python-sdk feature work; inventory and migrate tested public behaviour from clients/python before deleting anything. A leanctx compatibility shim is temporary and only inside the canonical distribution if evidence requires it. |
| Kit distribution | H1 requires .ctxpkg only. H5 correctly uses .ctxpkg but also includes remote publish/marketplace-like flows. H7/H8 explicitly defer marketplace. | Keep local source Kits and deterministic local .ctxpkg packing/verification. Defer remote discovery, public publishing, marketplace ranking, commerce, and registry UX. |
| Commercial price | H1 calls price points hypotheses; H13 forbids public numerical pricing; H12 says do not quote before scope; H17 states CHF 7,500 and CHF 7,500–15,000. | Do not publish monthly or enterprise numbers now. Internally use CHF 7,500 as a starting pilot hypothesis; quote a fixed Sprint only after qualified scope, data boundary, quality contract, and acceptance decision are agreed. Do not advertise credit or savings-share terms before contractual testing. |
| Product-truth copy | H13/H17/H18 show target SDK snippets such as LeanCTX.wrap, sessions, and profiles before those contracts ship. H18 labels some examples, but public pages can still mislead. | Every unreleased API is labelled Preview / Target Contract, never used as an installation instruction. Current CTAs lead to actual CLI/MCP/hook integrations. Build validation should fail public copy that marks a planned capability as available. |
| Context SDK positioning and shared context | The active Context SDK positioning introduces Select → Shape → Reuse → Recover and the future idea of shared project context, while local Agent Bus, task, message, handoff, and A2A substrate can look like a shipped orchestration product. | The four lifecycle verbs are the product mental model. Shared project context is Research/target until it has a bounded public contract, scope/privacy and freshness semantics, support ownership, and a status gate. LeanCTX never claims to schedule, assign, retry, or otherwise orchestrate agents. |
| Thinkery timing | H19 is a credible future control-plane blueprint. H8 bans control plane, central evidence, fleet management, SSO, and hosted scheduling before paid demand. | Treat H19 as a conditional post-proof architecture, not an approved roadmap. This week permits only a data-classification ADR and customer discovery—not control-plane implementation or sales claims. |
| Thinkery versus Cloud ownership | H19 calls Thinkery the future control plane; H10 assigns private cloud/control-plane code to lean-ctx-cloud and keeps Thinkery as brand/product narrative. | Thinkery AG is the company and commercial operator. LeanCTX is the product. Any future control-plane service is owned technically by lean-ctx-cloud, downstream of open contracts; never market Thinkery itself as a shipped cloud control plane. |
| Customer evidence | H17 contains exact reference-benchmark figures; H13 uses rounded 79–86%; H12 insists reference results are not customer proof. | Externally use either the exact verified benchmark artifact or the qualified rounded range, never both in the same asset. Always say controlled reference benchmark, calculated API cost, methodology, and not a customer guarantee. |
| ContextWorkspace versus current SDK v1 | The Workspace concept makes one durable resource central, while the current plan intentionally proves a small ContextSession/source/view/plan/receipt path before larger lifecycle semantics. | Treat ContextWorkspace as post-v1 Research target. Finish the deterministic local session proof first; then introduce Workspace as an additive SDK contract that reuses existing stores rather than a replacement API. |
| Checkpoint versus SnapshotV1 | The Workspace concept proposes immutable, multi-source state references and potentially a DAG; current snapshots are bounded, Git-anchored and linear. | Keep SnapshotV1 compatible and name the future object ContextCheckpointV2. Define source anchors, digest rules, parent semantics, migration fixtures and restore behavior before promotion. |
| `.ctxpkg` versus ContextKit | The concept frames packages as workspace templates; current Kit TOML and package/snapshot substrate are separate with no proven end-to-end mapping. | Keep the nouns and implementations separate. A future versioned ContextKitV1 may pin or seed a verified `.ctxpkg`; do not imply public package composition, a registry or a marketplace today. |
| Workspace remote versus Cloud status | The concept allows remote workspaces, sync and organization governance; current Cloud paths are experimental/research and local execution must remain independent. | Cloud begins only with metadata-first receipt/checkpoint lineage after local proof. Raw-source sync, shared project context, registry and governance are separate later decisions with tenant, retention, audit and local-degradation gates. |
| Historical SDK licensing proposals | Older concepts alternate between open SDK, proposed BSL and Cloud-only monetization. | BSL 1.1, primary SDK product and separate repository are decided. Do not publish until the named BSL/repository/release parameters are approved, but do not call the license family pending. |

## Tensions that are compatible once wording is precise

- H6’s receipt timestamps concern per-execution factual timing. H14’s privacy guardrail should prohibit raw event timelines in shareable aggregates by default, not erase required execution timing.
- H12’s Python/OpenAI Agents SDK POC and H1’s first-class Codex/Claude Code/Cursor support can coexist: the former is the first Wrap proof; the latter remain Attach compatibility/release gates.
- H5’s technical package substrate can remain in the repository. It must not be marketed as a marketplace or become a v1 adoption dependency.

## Missing pieces

### Missing reports

H9 and H11 were absent at finalization. Re-run this synthesis after they arrive if either proposes a material change to product scope, evidence contract, commercial packaging, or the first POC.

### Missing decisions or artifacts

1. A signed, versioned contract registry naming the one accepted Session/Dyno/receipt/bundle schema stack.
2. A minimal DynoRun workload manifest, quality-contract format, and run-plan test vectors.
3. An explicit capability matrix for Codex, Claude Code, and Cursor: supported version, integration depth, observability coverage, install/doctor/uninstall behavior.
4. A customer pilot pack: qualification checklist, data boundary, statement of work, acceptance criteria, report template, and no-go outcome.
5. A public claim ledger linked to source artifacts, methodology, qualifiers, owner, and release status.
6. A feature-admission template enforcing D-020: user, context problem, measurable result, loop step, OSS/commercial class, and displaced work.
7. A real packaging decision for Kit/Profile compatibility—not just proposed commands—and a migration path from legacy profiles/Kits.
8. A versioned Workspace RFC covering identity, local storage, source catalog, state transitions and Engine protocol boundary.
9. A ContextCheckpointV2 and SourceAnchor RFC with migration/restore fixtures from SnapshotV1.
10. A signed ContextKit↔`.ctxpkg` composition contract before package claims or SDK integration.

## Highest-risk unrealistic assumptions

1. Treating existing engine breadth as proof that the end-to-end customer product is shipped.
2. Building a marketplace, control plane, or dashboard before a second paid, repeatable evidence result.
3. Promising LeanCTX.wrap, Dyno, Profile deployment, or signed evidence in public before the first supported vertical slice works.
4. Selling raw token reduction as economic value without accepted-task quality.
5. Expanding to multiple frameworks before the reference Python Wrap path has passed an external 15-minute quickstart and tamper test.
