# Engine Decommission Candidates

> **Classification:** Future cleanup authority; no deletion or relicensing
> authorized
>
> **Audited tree:**
> `github/main@2c7d0044302d50af8d218a041b45726ad710757c`

## Governing rule

Preserve the supported OSS coding-agent product, not the historical monolith.
Every removal remains a separate reviewed change. Reachability, public
compatibility, security, provenance and behavioral parity decide when a row is
safe; current Apache visibility alone does not require indefinite retention.
Historical Apache rights remain after any future removal. BSL source reuse is a
separate Legal/provenance decision.

`OSS_TRANSITION_COMPAT` requires an equivalent-or-better successor and parity
fixtures. `OSS_NOT_PRESERVED` requires no behavioral successor when it is
unreachable and unpromised, but still requires SemVer/deprecation and security
review where external consumers may exist.

## Candidate register

| Source group | Why removable | Current reachability | Public commitment | Replacement / successor | Preservation tier | Deprecation needed? | Earliest safe wave | Provenance note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| protocol `auto_routing` and proxy re-export | Autonomous strategy is outside Engine v1 | Two manifest-approved consumers | Experimental non-v1 freeze; removal not before v2 | Explicit host/SDK policy if later needed | `OSS_NOT_PRESERVED` | Yes, public symbols | G after v2 gate | Historical A2 rights remain; no BSL copy assumed |
| protocol `control_plane` | Organization decision plane is not local Engine mechanism | `outcome_engine` is approved consumer | Experimental non-v1 freeze; removal not before v2 | Later private Cloud contract, if justified | `OSS_NOT_PRESERVED` | Yes | G after consumer removal and v2 gate | Rights/provenance review for any reuse |
| protocol `fleet_control` | Fleet governance is later Cloud scope | No approved production consumer | Experimental non-v1 freeze; removal not before v2 | Later private Cloud model | `OSS_NOT_PRESERVED` | Yes, exported symbols | G after v2 gate | Reimplement private semantics unless rights proven |
| protocol/proxy `rollout` | Rollout cohorts are not OSS coding-agent core | Proxy re-export only | Experimental non-v1 freeze; removal not before v2 | Host deployment system or later Cloud | `OSS_NOT_PRESERVED` | Yes | G after v2 gate | Historical contract remains Apache |
| protocol `value_share` | Settlement is outside Engine/SDK v1 | No approved production consumer | Experimental non-v1 freeze; removal not before v2 | None in current roadmap | `OSS_NOT_PRESERVED` | Yes | G after v2 gate | No BSL migration need established |
| protocol `outcome_engine` | Autonomous interpretation depends on frozen control plane | Protocol-internal consumer path | No v1 product promise found | Explicit evaluator/SDK quality projection | `OSS_NOT_PRESERVED` | Likely, public module | G after reachability audit | Do not copy quality inference into BSL |
| protocol `gap` lifecycle | Governance/coordination model is not local context mechanism | Public protocol exposure; runtime use unproven | No supported OSS journey found | Later Cloud only if validated | `OSS_NOT_PRESERVED` | Yes if external users exist | G | Rights review before later private implementation |
| protocol `experiment` | Evaluation Research is not runtime contract | Public type exposure; production path unproven | Experimental behavior only | Offline fixtures/evaluation tooling | `OSS_NOT_PRESERVED` | Yes if published API retained through v1 | G | Historical source remains available |
| Context Kernel Plan/Receipt product-like types | Duplicate future SDK lifecycle semantics | Kernel bridges and public root currently reach them | Attach behavior, not internal type identity, is protected | Product primitives in SDK plus Engine facts | `OSS_TRANSITION_COMPAT` | Yes for public root consumers | G after P3/SDK parity | External-author signals require Legal review for BSL reuse |
| Context Kernel orchestrator lifecycle strategy | Candidate construction and lifecycle planning are SDK responsibility | Current Attach bridges | Supported read behavior only | Explicit Engine mechanism plus SDK planner | `OSS_TRANSITION_COMPAT` | Internal seam first; public effects fixture | G after dual-run parity | Mixed folder; file-level dossier required |
| Kernel invalidation/degradation/recovery product semantics | Duplicates maintained SDK lifecycle | Current Kernel paths | Only observable recovery behavior is protected | Clean SDK state machine; open Engine recovery mechanism | `OSS_TRANSITION_COMPAT` | If observable behavior changes | G after P3/SDK parity | Clean implementation preferred |
| Kernel feedback/learning/adaptive/provider strategy | Global learned policy is Research and harms determinism | Some hot-path/feedback call sites | No supported OSS promise to learned strategy | Explicit deterministic policy or later governed intelligence | `OSS_NOT_PRESERVED` | Only for exposed config/behavior | G after callers removed | Do not migrate automatically to BSL |
| `core/session/playbook.rs` and historical playbook state | Durable heuristic learning exceeds minimum Attach continuity | Local session/learning path | No explicit user-facing promise found | None; retain minimal journal only | `OSS_NOT_PRESERVED` | Storage migration may be needed | G after field/reachability audit | Multiple external-author signals in session family |
| Nonessential session findings/decisions/research fields | Not all journal fields are required for restart continuity | Current session serialization and tools | Minimum continuity is protected; field set is not | Minimal versioned Attach journal | `OSS_TRANSITION_COMPAT` | Yes for persisted schema | G after migration fixture | External-author signals; avoid BSL copy |
| Profile routing/quality/model-tier/autonomy/prefetch fields | Product/Research policy is not Engine mechanism config | Config loaders and calibrator/hot path | Existing config parsing may need transition | SDK context/performance policy; Research fields removed | `OSS_TRANSITION_COMPAT` | Yes for accepted config | G after field-level migration | Schema/code reuse reviewed separately |
| Kit activation/composition/inheritance/session binding | Maintained lifecycle belongs SDK | CLI/context package/Profile call sites | Open format remains; activation implementation not permanent | SDK lifecycle over open format | `OSS_TRANSITION_COMPAT` | Yes for CLI workflow | G after SDK parity | Open parser stays Apache; BSL reuse separate |
| `context_package` activation/composition/session policy | Duplicates SDK lifecycle | Package consumers | Portable format/integrity is protected | SDK implementation over open manifest | `OSS_TRANSITION_COMPAT` | Yes for current CLI behavior | G after SDK parity | Mixed-folder source needs exact dossier |
| `context_package/remote`, registry and broad publish/export | Marketplace/remote distribution is outside product focus | CLI/tool candidates; exact support unproven | No core OSS promise found | Local package read/verify only | `OSS_NOT_PRESERVED` | Yes if command/API published | G after reachability report | Third-party/remote code review required |
| Snapshot publish/timeline and broad shared-context sync | Distributed state is later Research/Cloud | Research consumers | Local digest/restore only is protected | Local open snapshot mechanism | `OSS_NOT_PRESERVED` | Yes if commands exposed | G | No automatic Cloud reuse |
| HTTP A2A/handoff/coordination routes | Broad orchestration is not Engine product | Optional local HTTP consumers | No core coding-agent commitment found | None; local bus may remain Research separately | `OSS_NOT_PRESERVED` | Yes for enabled route users | G after route inventory | Preserve historical Apache source |
| Agent Bus/task/share/handoff/workflow public-product growth | Local development coordination is Research, not scheduler/product | Registered local tools and active development use | Research/local-only contract | Minimum local collaboration utility or removal | `OSS_NOT_PRESERVED` | Yes if advertised publicly | G after usage evidence | Bus improvements remain Apache/local unless promoted |
| Remote A2A relay/transport/DLQ/workflow/autonomy | Hosted agent-platform scope is rejected | Broad root/tool candidates | No protected OSS journey | None | `OSS_NOT_PRESERVED` | Yes where public | G after reachability/security audit | Do not reuse as private platform by default |
| `cloud_client`, `cloud_sync`, account/sync edges | Historical Cloud coupling is not local correctness | Public root/features and optional paths | Engine must work without Cloud | Optional future private Cloud client contract | `OSS_NOT_PRESERVED` | Yes for public APIs/features | G | Separate rights and product approval required |
| Billing/settlement/value-gate/commerce/finops paths | Premature commercial control surface | CLI/core/protocol candidates | Factual measurement may stay; settlement is unpromised | Open factual measurement only | `OSS_NOT_PRESERVED` | Yes for public commands/types | G after factual split | No BSL migration need established |
| Provider bandit/model router/neural selection/AutoTune | Autonomous selection is later governed intelligence | Research/hot-path/config call sites | No OSS promise to adaptive policy | Explicit local mechanisms; later intelligence only after gate | `OSS_NOT_PRESERVED` | Config deprecation where accepted | G | Customer-data permission and rights unverified |
| Dashboard team/enterprise, marketplace/catalog, web/skillify/buddy/godot | Unrelated platform expansion | Feature/root/CLI candidates | No core OSS coding-agent promise | Remove or separate project | `OSS_NOT_PRESERVED` | Yes where surfaced | G after reachability | Per-family provenance review |
| `packages/node-lean-ctx/**` Research SDK-named package | Duplicate/confusing package outside Production SDK architecture | Published-looking imports and middleware | MIT history/import compatibility may exist | Archive/deprecate with migration notice | `OSS_NOT_PRESERVED` | Yes | G after registry/usage evidence | MIT provenance dossier required before any reuse |
| Python optional LangChain/LlamaIndex/LiteLLM adapters | Unsupported adapter breadth | Importable optional modules; usage unproven | No maintained support matrix found | One maintained SDK adapter after P3 | `OSS_NOT_PRESERVED` | Yes if published imports | G after usage/registry evidence | A2 behavior may inform clean tests; reuse requires rights |
| Python Preview lifecycle/models after Production SDK migration | Historical product-like duplicate | Public Preview imports and wrapper tests | Compatibility during migration, not permanent Engine ownership | BSL SDK primitives and adapter | `OSS_TRANSITION_COMPAT` | Yes, with package migration | G after P3 and SDK release | Publication mapping and Legal approval required |
| Accidental root `pub mod core` and Cloud re-exports | Internal architecture escaped as broad API | Potential downstream Rust consumers | Explicit stable Engine façade is protected, internals are not | Narrow versioned Engine façade/protocol | `OSS_TRANSITION_COMPAT` | Yes, SemVer | G after downstream inventory | Removal differs from BSL reuse |
| Broad default features and root coupling | Build surface carries unrelated HTTP/embeddings/update breadth | Default Cargo build and Engine façade dependency | Supported build/use cases protected | Narrow feature graph behind Engine façade | `OSS_TRANSITION_COMPAT` | Yes for default behavior | G after matrix/parity | No license effect |

## Exit authority

A candidate leaves this map only through one of three recorded outcomes:

1. **removed** after its row's gates pass;
2. **retained and reclassified** because evidence proves a protected OSS or
   interoperability contract;
3. **replaced** with equivalent-or-better behavior and accepted parity.

No row authorizes source copying into the BSL repository, P3 implementation or
physical extraction.
