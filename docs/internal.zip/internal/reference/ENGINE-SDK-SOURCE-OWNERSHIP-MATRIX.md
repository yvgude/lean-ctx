# Engine–SDK Source Ownership Matrix

> **Classification:** Canonical source-extraction audit reference
>
> **Audited tree:** `github/main@2c7d0044302d50af8d218a041b45726ad710757c`
>
> **Action status:** Classification only; no code move or license change

## Reading the matrix

Future ownership classes are exactly: `ENGINE_CORE`, `ENGINE_PROTOCOL`,
`OSS_PRODUCT_SURFACE`, `OSS_ATTACH_COMPAT`, `OPEN_FORMAT_OR_SPEC`,
`SPLIT_REQUIRED`, `SDK_MIGRATION_INPUT`, `SDK_BSL_TARGET`,
`CLOUD_PRIVATE_TARGET`, `RESEARCH_FREEZE`, and `LEGACY_DEPRECATE`.

Every decision also receives exactly one independent OSS preservation tier:
`OSS_CORE_CONTRACT`, `OSS_TRANSITION_COMPAT`, `OSS_NOT_PRESERVED`, or
`OPEN_INTEROP_CONTRACT`. Ownership says where future responsibility belongs;
preservation says which behavior or compatibility commitment must survive.

`A2` means the audited package/repository declares Apache-2.0. `BSL-new`
means a future clean implementation in the separate Production SDK repository,
not a relicensing conclusion. `Legal` refers to the separate provenance review.

The inventory enumerated 1,675 files across the required source roots: Python
package 30, Rust Engine façade 12, protocol 29, core 1,223, server 37, tools
234, proxy 103, HTTP server 4, Kits 1, and root `lib.rs`/`Cargo.toml` 2.
High-risk areas below are classified below folder granularity; mechanically
similar tests/fixtures follow the production module they exercise unless a row
states otherwise.

The delta from the prior `a0585a0f...` audit to the integrated SHA contains 22
changed paths. It freezes five non-v1 protocol surfaces, tightens Evidence
Bundle v2 canonical signatures, restores exact `ctx_read`/triage fidelity and
hardens shell/hook behavior. No isolated worktree is integrated truth.

Required roots covered include `packages/python-lean-ctx/`,
`rust/crates/lean-ctx-sdk/`, `rust/crates/lean-ctx-protocol/`,
`rust/src/core/`, `rust/src/server/`, `rust/src/tools/`, `rust/src/proxy/`,
`rust/src/http_server/`, `rust/src/kits/`, `rust/src/lib.rs`, and
`rust/Cargo.toml`. The material adjacent public package
`packages/node-lean-ctx/` (13 files, MIT) is also classified.

## Python Preview

| Path/group | Exposure / consumers | Lic. | Current role | Primary target | Target repo / action | OSS impact / SDK value / risk | Prerequisite and rationale |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `lean_ctx/core.py` | public Python API; package tests | A2 | Source/View/Plan-like Preview models | `SDK_MIGRATION_INPUT` | BSL-new / reimplement behavior | Existing semantics stay usable; high thin-wrapper/confusion risk | Real Engine contract; Legal; do not copy types as final contract |
| `session.py` | public `ContextSession`; wrapper/tests | A2 | Preview lifecycle and `/v1/sessions/*` expectations | `SDK_MIGRATION_INPUT` | BSL-new / clean state machine | Strong SDK value; route promises may be false | P3 real transport, restart/abort fixtures, Legal |
| `agents_model.py` | public agent integration models | A2 | Host/session models | `SDK_MIGRATION_INPUT` | BSL-new / redesign | Preserve import compatibility; avoid host ownership creep | Final five-primitive contract |
| `wrap.py`, `agents.py` | public OpenAI Agents wrapper | A2 | Preview lifecycle adapter | `SDK_MIGRATION_INPUT` | BSL-new adapter; Apache compatibility retained | Streaming/retry/error regression risk; premium maintained adapter | Real Runtime/Engine slice and host-version fixture |
| `receipt.py` | public sign/verify/Receipt | A2 | Preview evidence projection | `SPLIT_REQUIRED` | Engine/open verifier + BSL SDK projection | Old receipts remain verifiable; canonical Receipt is product value | P2 evidence truth, schema migration, Legal |
| `profile.py` | public Preview API | A2 | mixed Engine config/product policy | `SPLIT_REQUIRED` | Engine config open; SDK policy BSL-new | Avoid moving safety/mechanism config; retain product policy value | Field-level schema map |
| `kit.py` | public Preview API | A2 | local Kit model/activation | `SPLIT_REQUIRED` | open format/parser; BSL activation | Interop retained; lifecycle/composition remains SDK value | open-format decision and fixtures |
| `client.py`, `proxy.py`, `discovery.py` | wrapper transport/runtime discovery | A2 | Preview compatibility transport | `OSS_ATTACH_COMPAT` | Engine repo / keep and freeze | Existing Preview works; not canonical SDK transport | Support matrix and real endpoint decision |
| `langchain.py`, `llamaindex.py`, `litellm.py` | optional public adapters | A2 | experimental integrations | `RESEARCH_FREEZE` | Engine history / no growth | Avoid unsupported adapter breadth | Usage evidence before migration |
| `errors.py`, `__init__.py` | public imports | A2 | Preview namespace/errors | `SDK_MIGRATION_INPUT` | BSL-new stable taxonomy; compatibility shim open | Import break risk; error taxonomy is SDK value | export inventory and deprecation map |
| Python tests/fixtures/README/metadata | published package contract | A2 | behavior/publication evidence | `SDK_MIGRATION_INPUT` | dual-run fixtures; retain history | Essential parity/provenance evidence | map package versions to blobs; Legal |

## Rust Engine embedding façade

| Path/group | Exposure / consumers | Lic. | Current role | Primary target | Target repo / action | OSS impact / SDK value / risk | Prerequisite and rationale |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `lean-ctx-sdk/src/engine.rs`, `read.rs`, `output.rs`, `error.rs` | public crate API; example/integration test | A2 | in-process real Engine façade | `OSS_PRODUCT_SURFACE` | Engine repo / keep; later clarify name | Preserves power-user embedding; must not be mistaken for Production SDK | decouple from root internals through Engine Protocol |
| `compress.rs`, `tokens.rs`, `hash.rs` | public pure helpers | A2 | Engine mechanisms | `ENGINE_CORE` | Engine repo / keep | Useful uncrippled OSS mechanisms | stable mechanism fixtures |
| crate manifest/lib/README/example/tests | public package/build surface; `publish=false` | A2 | façade distribution contract | `OSS_PRODUCT_SURFACE` | Engine repo / keep; migrate naming only later | Rename/API break risk | accepted replacement name and deprecation window |

## Public protocol crate

| Module | Exposure / consumers | Lic. | Current role | Primary target | Target repo / action | Risk and prerequisite |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `engine_interface` | re-exported; P1 Engine/runtime consumers | A2 | versioned invocation/admission/observation contract | `ENGINE_PROTOCOL` | Engine repo / keep+version | Golden JSON, unknown-field and failure fixtures |
| `capability`, `common`, `identity` | re-exported shared IDs/manifests | A2 | low-level identity/capability facts | `ENGINE_PROTOCOL` | Engine repo / keep | Remove Workspace/Kit-only IDs only through additive versioning |
| `execution`, `evidence`, `usage` | re-exported facts | A2 | Engine/evidence observation | `ENGINE_PROTOCOL` | Engine repo / keep | Facts stay open; quality meaning stays outside Engine |
| `policy`, `eligibility`, `circuit_breaker` | mixed public/indirect | A2 | low-level admission plus rollout semantics | `SPLIT_REQUIRED` | Engine admission open; rollout policy frozen | Separate safety admission from product/org policy |
| `context_session` | selected types re-exported | A2 | SDK session/config/profile/kit/integration depth | `SDK_MIGRATION_INPUT` | keep historical Apache; BSL-new contract | High SDK-value leakage; never delete old rights |
| `knowledge_routing` | candidate/bundle/receipt exports | A2 | context plan/receipt-like semantics | `SPLIT_REQUIRED` | Engine source/view facts open; SDK plan/receipt BSL-new | Exact extraction map/fixtures required |
| `knowledge`, `task`, `triage` | public task/knowledge/routing models | A2 | Attach/context strategy contracts | `OSS_ATTACH_COMPAT` | Engine repo / freeze compatibility | Do not make canonical Product session/planner |
| `money`, `savings`, factual `usage` models | public evidence encodings | A2 | factual units/cost/savings observations | `ENGINE_PROTOCOL` | Engine repo / keep open | Exclude settlement, accepted-quality and value-share meaning |
| `outcome` | public outcome models | A2 | facts mixed with acceptance meaning | `SPLIT_REQUIRED` | factual outcome record open; SDK owns acceptance/quality projection | Do not let Engine assert customer outcome |
| `decision` | public audit record | A2 | inspectable decision schema | `OPEN_FORMAT_OR_SPEC` | Engine repo / keep open format | SDK/Cloud owns strategy and interpretation |
| `experiment` | public experiment models | A2 | tuning/evaluation Research | `RESEARCH_FREEZE` | Engine repo / no new consumers | Offline evaluation only after evidence gate |
| `gap` | public evidence-gap lifecycle | A2 | coordination/governance model | `CLOUD_PRIVATE_TARGET` | historical Apache retained; later private clean model | Not Engine mechanism or SDK v1 responsibility |
| `auto_routing`, `outcome_engine` | public modules | A2 | autonomous strategy | `RESEARCH_FREEZE` | freeze | Product strategy/intelligence must not grow in Engine |
| `control_plane`, `fleet_control`, `rollout` | public modules and wildcard exports | A2 | org/fleet governance contracts | `CLOUD_PRIVATE_TARGET` | retain historical Apache; future private clean implementation | Public by accident/legacy; no deletion before reachability |
| `value_share` | public module/export | A2 | commercial settlement contract | `LEGACY_DEPRECATE` | freeze/deprecate | Outside SDK/Cloud-first scope; compatibility inventory first |
| crate `lib.rs`/manifest | exports broad families | A2 | package boundary | `SPLIT_REQUIRED` | narrow future Engine Protocol; compatibility modules versioned | Do not physically split before Wave C fixtures |

## Context Kernel and adjacent mixed planning

| Path/group | Exposure / consumers | Lic. | Current role | Primary target | Target repo / action | OSS impact / SDK value / risk | Prerequisite/rationale |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `context_kernel/types.rs` | public root module; orchestrator/bridges/tests | A2 | Object, Plan, Receipt product-like types | `SDK_MIGRATION_INPUT` | Apache compatibility; BSL-new primitives | High SDK-value leakage; public semantics already escaped | clean contract; Legal external-contributor signal |
| `orchestrator.rs` | bridge/hotpath/tests | A2 | gathers candidates, chooses signals, compiles plan, records receipt | `SPLIT_REQUIRED` | Engine gathering primitive + BSL lifecycle planner | Removing breaks Attach; leaving canonical makes SDK thin | explicit-input mechanism seam and dual-run fixtures |
| `bridge.rs`, `mcp_bridge.rs`, `proxy_bridge.rs`, `client_wiring.rs` | MCP/proxy/runtime call sites | A2 | OSS integration bridge | `OSS_ATTACH_COMPAT` | Engine repo / preserve+freeze | Direct OSS regression risk | parity fixtures before SDK consumes public protocol |
| `policy.rs`, `enforce.rs`, `policy_engine.rs` | orchestrator/bridge | A2 | sensitivity/source/budget policy | `SPLIT_REQUIRED` | security admission open; lifecycle policy BSL-new | Safety cannot move; maintained context policy is SDK value | field-level safety/lifecycle split |
| `invalidation.rs`, `degradation.rs`, `recovery.rs` | plan/receipt lifecycle and bridges | A2 | lifecycle state plus fallback/recovery | `SDK_MIGRATION_INPUT` | compatibility retained; BSL-new semantics | Core Product value; OSS path must remain | clean state machine, parity, Legal |
| `feedback.rs`, `learning.rs`, `adaptive_*`, `outcome_signal.rs` | hotpath/feedback tests | A2 | outcome-driven weight/strategy adaptation | `RESEARCH_FREEZE` | freeze current behavior; later private intelligence only after gate | Process-global/feedback state contaminates deterministic Engine | no SDK v1 migration; governed data/evidence decision |
| `receipt_builder.rs`, `receipt_chain.rs`, `mcp_receipt.rs`, `response_evidence.rs` | MCP/evidence paths | A2 | builds local receipt evidence | `SPLIT_REQUIRED` | Engine fact/chain open; SDK projection BSL-new | Must preserve offline history; canonical ownership collision | P2 one evidence truth and schema compatibility |
| `evidence_*`, `attribution.rs`, `usage_normalizer.rs`, `provider_*` | evidence/metrics bridges | A2 | factual normalization plus provider interpretation | `SPLIT_REQUIRED` | facts open; product quality/strategy outside | Avoid invented metrics and adapter leakage | Proof Doctrine and measured/estimated fixtures |
| `providers.rs`, `context_broker.rs`, `result_fusion.rs` | orchestrator candidates | A2 | candidate acquisition/fusion | `SPLIT_REQUIRED` | Engine explicit retrieval mechanisms; SDK candidate strategy | Candidate construction is core SDK value | explicit provider protocol, no hidden global state |
| `bounded.rs`, `token_envelope.rs`, `context_dedup.rs`, `ctx_read_dedup.rs` | hot path/bridges | A2 | bounded token/dedup mechanisms | `ENGINE_CORE` | Engine repo / keep | Useful deterministic mechanisms | explicit inputs, no lifecycle decisions |
| `identity.rs`, `identity_resolver.rs`, `capsule_wire.rs`, `envelope_*`, `schema_wiring.rs` | wire/bridge paths | A2 | identity/wire conversion | `ENGINE_PROTOCOL` | Engine repo / narrow mechanism schemas | Prevent Workspace/Tenant/Product semantics entering Engine identity |
| `health.rs`, `health_api.rs`, `provider_display.rs`, `tool_surface.rs`, `list_tools_opt.rs`, `mcp_schema_opt.rs` | local UX/MCP | A2 | operational/Attach presentation | `OSS_PRODUCT_SURFACE` | Engine repo / keep | Supported local UX; not SDK lifecycle | parity and deterministic output fixtures |
| `dashboard_report.rs`, `live_dashboard.rs` | dashboard consumers | A2 | broad local dashboard | `RESEARCH_FREEZE` | freeze/read-only evidence view only | Avoid team/control-plane product | reachability and evidence-only constraint |
| `a2a_fixes.rs`, `multi_agent_e2e.rs` | local coordination tests | A2 | A2A Research | `RESEARCH_FREEZE` | local Research only | Not SDK v1/Cloud excuse | no public promotion |
| `activation*`, `startup`, `hotpath_wiring`, `config_bridge`, `client_profile` | Engine startup/hot path | A2 | activates mixed Kernel | `SPLIT_REQUIRED` | preserve OSS wiring; SDK uses protocol externally | Coupling risk during extraction | dependency inversion and kill switch |
| Kernel `*_e2e`, conformance, bench, fail/smoke/quality tests | internal tests | A2 | compatibility/evidence | `OSS_ATTACH_COMPAT` | retain as pre-split fixtures | Critical behavioral baseline | reclassify test expectations before code moves |
| `context_compiler.rs` explicit candidates/costs/budget/deterministic selection | core callers, Kernel | A2 | bounded optimizer mechanism | `ENGINE_CORE` | Engine repo / retain narrow pure API | Strong OSS mechanism | remove candidate construction/lifecycle meaning from API |
| `context_compiler.rs` view choice/pins/mode/result semantics | Kernel/context consumers | A2 | strategy-coupled selection | `SPLIT_REQUIRED` | SDK owns strategy; Engine accepts explicit constraints | Thin-SDK risk if canonical strategy stays | split pure solver and product planner |
| `context_field.rs` IDs/kinds/view costs/token math/scoring functions | compiler/gate/Kernel | A2 | low-level primitives | `ENGINE_CORE` | Engine repo / keep | Useful explicit mechanisms | deterministic inputs and names decoupled from product primitives |
| `context_field.rs` presets, `ACTIVE_WEIGHTS`, bandit feedback, task signal construction | gate/learning | A2 | product/learned strategy | `SPLIT_REQUIRED` | SDK policy or later intelligence; remove from Engine hot-path authority | Global mutable state/determinism and value leakage risk | session-scoped explicit policy; no cross-customer state |
| `context_policies.rs` secret/path exclusion | context gate | A2 | safety policy | `ENGINE_CORE` | Engine repo / keep | Safety invariant | separate from seen-before/task logic |
| `context_policies.rs` seen-before→diff, agent/role/task view policy | context gate | A2 | Attach lifecycle heuristic | `OSS_ATTACH_COMPAT` | preserve/freeze; BSL planner clean | OSS UX preserved; not canonical SDK policy | fixtures and explicit label |

## Session, Profiles and Kits

| Path/group | Exposure / consumers | Lic. | Current role | Primary target | Target repo / action | Risk and prerequisite |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `core/session/types.rs`, `state.rs` | hooks/tools/session continuity | A2 | coding-agent journal, findings, decisions, files, evidence | `OSS_ATTACH_COMPAT` | Engine repo / preserve; conceptual `AttachSessionJournal` later | Multiple external contributors; never rename into Product `ContextSession` |
| `session/persistence.rs`, `paths.rs`, `heuristics.rs` | session tools/startup | A2 | safe scoped local persistence | `OSS_ATTACH_COMPAT` | preserve/migrate storage reversibly | Path/security and restart fixtures |
| `session/compaction.rs` | session hooks/resume | A2 | Attach context summary | `OSS_ATTACH_COMPAT` | preserve | deterministic bounded output parity |
| `session/playbook.rs` | local learning/session | A2 | heuristic durable playbook | `RESEARCH_FREEZE` | freeze local-only | not Product SDK session or shared intelligence |
| `profiles/types.rs` read/compression/layout/output safety config | config/loaders/tools | A2 | Engine mechanism configuration | `SPLIT_REQUIRED` | EngineConfig open | field-level extraction and config migration |
| `profiles/types.rs` routing, budgets, quality, capabilities, autonomy/prefetch | calibrator/hotpath | A2 | product performance/context policy | `SPLIT_REQUIRED` | SDK ContextPolicy/PerformanceProfile BSL-new; Research fields frozen | prevent model routing/autonomy leakage |
| `profiles/loading.rs`, `builtins.rs`, `mod.rs`, tests | CLI/config/runtime | A2 | mixed profile loading | `SPLIT_REQUIRED` | dual loaders during migration | schema-version and old-profile fixture |
| `kits/mod.rs` local parse/integrity/storage mechanics | CLI/tools | A2 | portable local Kit | `OPEN_FORMAT_OR_SPEC` | Engine/open format/parser | interop, lock-in reduction, integrity fixtures |
| Kit activation/composition/inheritance/policy/session binding call sites | CLI/context package/Profile | A2 | lifecycle application | `SDK_BSL_TARGET` | future SDK / new implementation | genuine maintained SDK value; open schema remains usable |

## Remaining Engine, OSS, Cloud and Research families

| Path/group | Exposure / consumers | Lic. | Current role | Primary target | Target repo / action | Rationale/risk |
| --- | --- | --- | --- | --- | --- | --- |
| parsing/AST/signatures/imports/language, `context_ir`, `context_artifacts`, `context_handles`, content/artifact/cache/search/index/token/compression families | CLI/MCP/tools/façade | A2 | deterministic context mechanisms | `ENGINE_CORE` | Engine repo / keep | Core independent OSS value |
| `pathjail`, `io_boundary`, `process_guard`, `shell_allowlist`, `secret_detection`, redaction/input filters, sandbox, atomic/artifact integrity | all local surfaces | A2 | safety | `ENGINE_CORE` | Engine repo / strengthen | Zero commercial relocation |
| execution/evidence ledgers and local invocation/measurement facts | Engine/evidence tools | A2 | factual proof mechanisms | `ENGINE_CORE` | Engine repo / keep | Product Receipt links to these facts |
| canonical evidence/artifact manifests, signatures, provenance and offline verifier | evidence CLI/tools | A2 | portable integrity and verification | `OPEN_FORMAT_OR_SPEC` | Engine/open spec / keep | Historical evidence stays independently verifiable |
| `server/context_gate.rs` | `ctx_read` dispatch, ledger/overlay/triage | A2 | pressure/task/graph/seen-before Attach decisions | `OSS_ATTACH_COMPAT` | Engine repo / preserve+freeze | Highest OSS-regression risk; never canonical SDK planner |
| other `server/**`, core `tools/**`, `proxy/**`, `proxy_setup`, hooks, daemon, CLI/setup/doctor/status/uninstall | public executable/MCP/Attach | A2 | supported OSS product | `OSS_PRODUCT_SURFACE` | Engine repo / keep | Parity contract governs |
| `http_server/**` local health/config/evidence/Engine-management routes | local HTTP consumers | A2 | optional local Engine surface | `OSS_PRODUCT_SURFACE` | Engine repo / preserve | No account or Cloud dependency; bounded local behavior |
| `http_server/**` A2A/handoff/coordination routes | opt-in local consumers | A2 | shared-context Research | `RESEARCH_FREEZE` | local-only / freeze | Do not turn into hosted orchestration or SDK v1 |
| `tools/registered/ctx_read`, search/symbol/shell/recovery/evidence tools | MCP public registry | A2 | primary OSS operations | `OSS_PRODUCT_SURFACE` | Engine repo / keep | Stable tool semantics; SDK may call protocol, not scrape text |
| Agent Bus/task/share/handoff/workflow registered tools | local development use | A2 | coordination Research | `RESEARCH_FREEZE` | Engine local-only / freeze public-product growth | Not scheduler or SDK v1 |
| `context_package` format/manifest/lock/sign/verify local pieces | CLI/tools | A2 | portable package mechanisms | `OPEN_FORMAT_OR_SPEC` | Engine/open spec | separate remote/activation rows |
| `context_package` activation/composition/session policy | package consumers | A2 | lifecycle semantics | `SDK_MIGRATION_INPUT` | compatibility retained; BSL-new semantics | do not copy mixed folder wholesale |
| `context_package/remote`, `registry`, broad publish/export; addons commerce/store/publish/revocation | public root/CLI candidates | A2 | marketplace/remote distribution | `LEGACY_DEPRECATE` | freeze/deprecate after reachability | outside product and security burden |
| `context_snapshot` local digest/restore | session/tools | A2 | recovery mechanism | `OPEN_FORMAT_OR_SPEC` | Engine/open | publish/timeline excluded below |
| snapshot publish/timeline, broad shared context/workspace sync | Research consumers | A2 | distributed/shared state | `RESEARCH_FREEZE` | freeze | post-SDK Research only |
| local `agents/**` registry/leases/presence/bus | agent tools/development | A2 | local coordination | `RESEARCH_FREEZE` | local-only | no hosted/generic agent product |
| `a2a/**`, remote relay/transport/DLQ/rate limits, workflow/autonomy | broad root/tool candidates | A2 | orchestration/remote agent platform | `LEGACY_DEPRECATE` | freeze; remove only after reachability | not SDK or near-term Cloud |
| `cloud_client`, `cloud_sync` and account/sync edges | public root exports/features | A2 | historical Cloud client/service surface | `CLOUD_PRIVATE_TARGET` | preserve compatibility; future private clean service | currently public leakage; Cloud optional |
| fleet analytics/control, org policy, shared org history, cross-customer learning | public root/core/protocol | A2 | organization learning/governance | `CLOUD_PRIVATE_TARGET` | later separate private repo | tenant/data/ops gates required |
| billing, value gate/share, settlement, savings-account/commerce, finops/compliance product paths | CLI/core/protocol | A2 | premature commercial/control surface | `LEGACY_DEPRECATE` | freeze/deprecate or factual measurement-only split | must not gate local Engine |
| provider bandit, model router, neural/learned selection, adaptive decision loops, AutoTune/calibrator automation | core/Research tools | A2 | autonomous selection intelligence | `RESEARCH_FREEZE` | freeze; later private only after evidence | no SDK v1 scope or customer-data learning |
| dashboard/team/enterprise UI, marketplace/plugins/catalog, broad web/skillify/buddy/godot | CLI/root features | A2 | unrelated/platform expansion | `LEGACY_DEPRECATE` | quarantine/reachability then deprecate | Anti-Roadmap |
| `packages/node-lean-ctx/**` | published-looking `lean-ctx-sdk` Node API; README labels Research/reference | MIT | proxy/compress/CLI/Vercel middleware compatibility | `LEGACY_DEPRECATE` | freeze, then deprecate/archive with notice | Do not merge MIT source into BSL without Legal review |
| `rust/src/lib.rs` Cloud modules and almost all core modules public | downstream Rust users | A2 | over-broad root API | `SPLIT_REQUIRED` | later narrow Engine façade; version/deprecate | public break risk; cleanup Wave G only |
| `rust/Cargo.toml` default `http-server`/embeddings/secure-update breadth and Engine-façade dependency needs | build/distribution | A2 | broad monolith feature surface | `SPLIT_REQUIRED` | narrow only after reachability/parity | default feature regressions and misleading Cloud coupling |

## Fitness-test resolution for every `SPLIT_REQUIRED` row

1. **Mechanism:** keep deterministic explicit-input execution in Engine.
2. **Lifecycle:** put canonical cross-task/session context intent in SDK.
3. **OSS preservation:** retain accepted Attach behavior until parity and
   deprecation gates pass.
4. **SDK value:** candidate construction, policy, compatibility, adapters and
   lifecycle cannot remain a trivial Engine wrapper.
5. **Security:** source containment, secrets, bounds and integrity stay open.
6. **Provenance:** already-Apache or externally contributed source follows the
   provenance review before any BSL reuse.

## OSS preservation evidence catalog

Each decision row below references one evidence record. The record supplies the
required journey/reachability/contract/replacement/parity/removal evidence; its
source-group cell narrows that evidence to the exact row above.

| Evidence | Decision evidence |
| --- | --- |
| `C-CTX` | Supported journey: local coding-agent read/search/shape/recover. Entry: CLI, MCP or Engine façade. Call path: public surface → registered tool/Engine façade → deterministic context mechanism. Contract: OSS Preservation Contract and public tool docs. Fixture: relevant `read_*`, `search`, `symbol`, cache/recovery fixture. Removal: product-level migration only with equivalent-or-better behavior. |
| `C-SAFE` | Supported journey: every safe local operation. Entry: all read/shell/artifact surfaces. Call path: surface → admission/PathJail/redaction/bounded IO → mechanism. Contract: open security invariant. Fixtures: PathJail, secret, timeout, bounds and artifact-integrity negatives. Removal: only behind an equally open stronger implementation. |
| `C-SURFACE` | Supported journey: install and attach LeanCTX to Claude Code, Codex or Cursor. Entry: setup/doctor/CLI/MCP/proxy/hooks/local HTTP. Call path: public executable/integration → local Engine. Contract: documented supported product. Fixtures: attach/setup/MCP/proxy/embedding suite. Removal: explicit product migration/deprecation with parity. |
| `C-EVID` | Supported journey: record factual local execution durably. Entry: Engine execution/evidence path. Call path: invocation → observation → verified ledger/artifact. Contract: local evidence and offline verification. Fixtures: evidence chain, replay, torn-write and tamper negatives. Removal: equivalent open factual mechanism required. |
| `T-PY` | Current journey: published Python Preview imports/wrapper. Entry: Python public API. Call path: wrapper/session → current transport/discovery → local runtime. Public commitment: package surface, bounded by support matrix. Successor: P3 real slice and BSL SDK compatibility. Fixtures: imports, streaming/errors/restart/abort. Removal: only after successor, migration notice and parity. |
| `T-ATT` | Current journey: OSS Attach context shaping/continuity. Entry: `ctx_read`, proxy/hooks or MCP. Call path: surface → gate/Kernel bridge → Engine mechanism. Commitment: observable current UX, not internal types. Successor: explicit Engine mechanism plus SDK lifecycle where applicable. Fixtures: Attach/read parity. Removal: after equal behavior and applicable deprecation. |
| `T-SESSION` | Current journey: coding-agent restart continuity. Entry: hooks and session tools. Call path: event → project journal → persistence/compaction. Commitment: minimum supported continuity only. Successor: minimal versioned Attach journal; Product Session is separate. Fixtures: restart/isolation/storage migration. Removal: field-by-field after parity and reversible migration. |
| `T-PROFILE` | Current journey: accepted local configuration. Entry: profile/config loaders. Call path: config → loader → Engine mechanism or current policy. Commitment: parse/behavior compatibility, not every field. Successor: EngineConfig plus SDK policy. Fixtures: old-profile and mechanism-output parity. Removal: field reachability, migration and notice. |
| `T-PACKAGE` | Current journey: local Kit/context-package activation. Entry: CLI/package APIs. Call path: manifest/parser → activation/composition → Attach. Commitment: current supported workflow. Successor: open format plus SDK lifecycle. Fixtures: old manifests, integrity and activation parity. Removal: after successor and migration. |
| `T-API` | Current journey: published/importable compatibility surface. Entry: crate/module/root export. Call path: external consumer → historical API → current implementation. Commitment: only established SemVer/deprecation obligations. Successor: narrow Engine façade/protocol. Fixture: downstream compile/golden contract. Removal: reachability inventory, successor and SemVer gate. |
| `I-ENGINE` | Interop purpose: public versioned Engine mechanism/fact contract. Entry: protocol crate/Engine façade. Contract: schema, canonical fixtures and unknown-field rules. Replacement: additive version. Fixture: golden JSON and cross-version verifier. Removal: versioned deprecation only. |
| `I-EVID` | Interop purpose: portable evidence/receipt/artifact schema and standalone verifier. Entry: producer/verifier CLI or library. Contract: canonical bytes, digest, signature and trust semantics. Fixture: canonical bundle plus tamper/key/linkage/duplicate/unknown negatives. Removal: historical verification retained or explicitly versioned. |
| `I-FORMAT` | Interop purpose: portable local Kit/package/snapshot/decision format. Entry: parser/verify/import. Contract: versioned format and integrity rules. Fixture: golden parse/round-trip/invalid cases. Removal: format-version migration; product activation implementation is not protected by this record. |
| `N-RESEARCH` | Not promised: experimental learning, dashboard or coordination Research is outside supported OSS journey. Reachability: internal/opt-in or unproven and must be measured. External consumers/SemVer: inventory public symbols/config first. Safe removal: eliminate callers, migrate persisted state if any, pass core/security fixtures. |
| `N-CLOUD` | Not promised: tenant/fleet/account/governance or cross-deployment behavior is outside local Engine correctness. Reachability: optional/public leakage must be inventoried. External consumers/SemVer: deprecate exposed APIs. Safe removal: prove no local dependency; any later private successor is a clean, separately approved contract. |
| `N-LEGACY` | Not promised: billing, marketplace, remote relay, platform breadth or duplicate package is outside current product. Reachability: candidate/public exposure requires measurement. External consumers/SemVer: migration notice where published. Safe removal: quarantine, remove consumers, pass OSS/security gates. |
| `N-SDK` | Not promised as permanent Engine implementation: product lifecycle/strategy belongs the SDK or is duplicate historical semantics. Reachability: current bridges/imports determine temporary compatibility. External consumers/SemVer: inventory and deprecate if public. Safe removal: P3/SDK successor where current journey exists; otherwise remove after no-reachability proof. BSL reuse remains provenance-gated. |

## Two-axis decision register

The register is one-to-one and ordered exactly like the 86 source rows above.

| ID | Source group | Future ownership | OSS preservation tier | Evidence |
| --- | --- | --- | --- | --- |
| P01 | Python `core.py` | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P02 | Python `session.py` | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P03 | Python `agents_model.py` | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P04 | Python `wrap.py`, `agents.py` | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P05 | Python `receipt.py` | `SPLIT_REQUIRED` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| P06 | Python `profile.py` | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P07 | Python `kit.py` | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-PACKAGE` |
| P08 | Python client/proxy/discovery | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P09 | Python optional adapters | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| P10 | Python errors/namespace | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| P11 | Python tests/fixtures/README/metadata | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PY` |
| R01 | Rust Engine façade API | `OSS_PRODUCT_SURFACE` | `OSS_CORE_CONTRACT` | `C-SURFACE` |
| R02 | Rust façade pure helpers | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-CTX` |
| R03 | Rust façade distribution surface | `OSS_PRODUCT_SURFACE` | `OSS_CORE_CONTRACT` | `C-SURFACE` |
| PR01 | protocol `engine_interface` | `ENGINE_PROTOCOL` | `OPEN_INTEROP_CONTRACT` | `I-ENGINE` |
| PR02 | protocol capability/common/identity | `ENGINE_PROTOCOL` | `OPEN_INTEROP_CONTRACT` | `I-ENGINE` |
| PR03 | protocol execution/evidence/usage | `ENGINE_PROTOCOL` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| PR04 | protocol policy/eligibility/circuit breaker | `SPLIT_REQUIRED` | `OPEN_INTEROP_CONTRACT` | `I-ENGINE` |
| PR05 | protocol `context_session` | `SDK_MIGRATION_INPUT` | `OSS_NOT_PRESERVED` | `N-SDK` |
| PR06 | protocol `knowledge_routing` | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-API` |
| PR07 | protocol knowledge/task/triage | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| PR08 | protocol money/savings/factual usage | `ENGINE_PROTOCOL` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| PR09 | protocol outcome | `SPLIT_REQUIRED` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| PR10 | protocol decision | `OPEN_FORMAT_OR_SPEC` | `OPEN_INTEROP_CONTRACT` | `I-FORMAT` |
| PR11 | protocol experiment | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| PR12 | protocol gap | `CLOUD_PRIVATE_TARGET` | `OSS_NOT_PRESERVED` | `N-CLOUD` |
| PR13 | protocol auto-routing/outcome-engine | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| PR14 | protocol control-plane/fleet/rollout | `CLOUD_PRIVATE_TARGET` | `OSS_NOT_PRESERVED` | `N-CLOUD` |
| PR15 | protocol value-share | `LEGACY_DEPRECATE` | `OSS_NOT_PRESERVED` | `N-LEGACY` |
| PR16 | protocol crate boundary | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-API` |
| K01 | Kernel product-like types | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K02 | Kernel orchestrator | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K03 | Kernel runtime bridges | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K04 | Kernel policy/enforcement | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K05 | Kernel invalidation/degradation/recovery | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K06 | Kernel feedback/learning/adaptive strategy | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| K07 | Kernel receipt builders/chain | `SPLIT_REQUIRED` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| K08 | Kernel evidence/attribution/provider normalization | `SPLIT_REQUIRED` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| K09 | Kernel provider broker/fusion | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K10 | bounded/token/dedup mechanisms | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-CTX` |
| K11 | Kernel identity/wire conversion | `ENGINE_PROTOCOL` | `OPEN_INTEROP_CONTRACT` | `I-ENGINE` |
| K12 | Kernel local health/tool surface | `OSS_PRODUCT_SURFACE` | `OSS_CORE_CONTRACT` | `C-SURFACE` |
| K13 | Kernel dashboards | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| K14 | Kernel A2A tests | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| K15 | Kernel activation/startup/hotpath wiring | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K16 | Kernel compatibility/e2e tests | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K17 | compiler explicit deterministic solver | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-CTX` |
| K18 | compiler strategy-coupled selection | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| K19 | context-field primitives/math | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-CTX` |
| K20 | context-field presets/global weights | `SPLIT_REQUIRED` | `OSS_NOT_PRESERVED` | `N-SDK` |
| K21 | context safety policies | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-SAFE` |
| K22 | seen-before/agent/task policy | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| S01 | session types/state | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-SESSION` |
| S02 | session persistence/paths/heuristics | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-SESSION` |
| S03 | session compaction | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-SESSION` |
| S04 | session playbook | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| S05 | profile mechanism configuration | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-PROFILE` |
| S06 | profile product/autonomy configuration | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-PROFILE` |
| S07 | profile loaders/builtins | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-PROFILE` |
| S08 | Kit format/parser/integrity | `OPEN_FORMAT_OR_SPEC` | `OPEN_INTEROP_CONTRACT` | `I-FORMAT` |
| S09 | Kit activation/composition/session binding | `SDK_BSL_TARGET` | `OSS_NOT_PRESERVED` | `N-SDK` |
| E01 | parsing/AST/search/cache/compression families | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-CTX` |
| E02 | PathJail/IO/process/shell/secrets/integrity | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-SAFE` |
| E03 | execution/evidence ledgers and facts | `ENGINE_CORE` | `OSS_CORE_CONTRACT` | `C-EVID` |
| E04 | canonical evidence manifests/verifier | `OPEN_FORMAT_OR_SPEC` | `OPEN_INTEROP_CONTRACT` | `I-EVID` |
| E05 | server context gate | `OSS_ATTACH_COMPAT` | `OSS_TRANSITION_COMPAT` | `T-ATT` |
| E06 | CLI/MCP/proxy/hooks/setup surface | `OSS_PRODUCT_SURFACE` | `OSS_CORE_CONTRACT` | `C-SURFACE` |
| E07 | local HTTP Engine surface | `OSS_PRODUCT_SURFACE` | `OSS_CORE_CONTRACT` | `C-SURFACE` |
| E08 | local HTTP A2A/coordination | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| E09 | primary registered context tools | `OSS_PRODUCT_SURFACE` | `OSS_CORE_CONTRACT` | `C-CTX` |
| E10 | Agent Bus/task/share/handoff/workflow | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| E11 | context-package format/sign/verify | `OPEN_FORMAT_OR_SPEC` | `OPEN_INTEROP_CONTRACT` | `I-FORMAT` |
| E12 | context-package lifecycle application | `SDK_MIGRATION_INPUT` | `OSS_TRANSITION_COMPAT` | `T-PACKAGE` |
| E13 | context-package remote/registry/commerce | `LEGACY_DEPRECATE` | `OSS_NOT_PRESERVED` | `N-LEGACY` |
| E14 | local snapshot digest/restore | `OPEN_FORMAT_OR_SPEC` | `OPEN_INTEROP_CONTRACT` | `I-FORMAT` |
| E15 | snapshot publish/timeline/shared sync | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| E16 | local agent registry/leases/presence/bus | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| E17 | remote A2A/relay/workflow/autonomy | `LEGACY_DEPRECATE` | `OSS_NOT_PRESERVED` | `N-LEGACY` |
| E18 | cloud client/sync/account edges | `CLOUD_PRIVATE_TARGET` | `OSS_NOT_PRESERVED` | `N-CLOUD` |
| E19 | fleet/org/cross-customer governance | `CLOUD_PRIVATE_TARGET` | `OSS_NOT_PRESERVED` | `N-CLOUD` |
| E20 | billing/value-share/settlement/finops | `LEGACY_DEPRECATE` | `OSS_NOT_PRESERVED` | `N-LEGACY` |
| E21 | bandit/router/neural/AutoTune | `RESEARCH_FREEZE` | `OSS_NOT_PRESERVED` | `N-RESEARCH` |
| E22 | dashboard/team/marketplace/platform breadth | `LEGACY_DEPRECATE` | `OSS_NOT_PRESERVED` | `N-LEGACY` |
| E23 | Node Research package | `LEGACY_DEPRECATE` | `OSS_NOT_PRESERVED` | `N-LEGACY` |
| E24 | broad root exports | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-API` |
| E25 | broad Cargo default features/coupling | `SPLIT_REQUIRED` | `OSS_TRANSITION_COMPAT` | `T-API` |

Preservation-tier counts: `OSS_CORE_CONTRACT` **14**,
`OSS_TRANSITION_COMPAT` **32**, `OSS_NOT_PRESERVED` **25**, and
`OPEN_INTEROP_CONTRACT` **15**. Total: **86**.

## Execution rule

`keep`, `split`, `freeze`, `migrate`, and `deprecate` are future migration
decisions. This matrix authorizes no source move, removal, license edit, or new
repository. The migration plan defines the gates and order.
