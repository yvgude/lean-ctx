# OCLA Capability Architecture

> **Classification:** Active support technical reference. OCLA is a bounded
> Engine mechanism. This document cannot establish a marketplace, ecosystem,
> plugin economy, SDK/Cloud ownership or product availability.

**Status:** Bounded Engine technical reference below the canonical product architecture<br>
**Scope:** Open capability contract for LeanCTX Context Performance<br>
**Supersedes:** Scattered OCLA capability, provider, adapter, and registry architecture references<br>
**Controlling strategy:** [Canonical SDK-First Architecture](../vision/00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md)

## 1. Purpose and boundary

**OCLA is the Open Context-performance Capability Layer.** It is the stable, open contract that lets LeanCTX discover, validate, invoke, measure, and compose bounded capabilities that influence an agent's context-performance path.

OCLA answers **what a component can do and under what constraints**. It defines capability identity, contracts, execution, permissions, trust, measurement, and compatibility. It does not decide that a particular capability is the best choice for a workload.

That decision belongs to the LeanCTX Performance Planner:

```text
OCLA capability plane (open)       Performance selection plane (policy/intelligence)
what can run, with which limits    whether it should run for this task
```

This separation is mandatory. An open contract allows native, community, customer, partner, and provider-native implementations. Workload-specific ranking, learned outcome prediction, fleet rollouts, and proprietary economic intelligence remain outside the contract.

OCLA is not a generic plugin API, agent-builder framework, or marketplace. A capability is executable code with access to sensitive context; registration and invocation are therefore governed runtime operations.

## 2. Capability model

A **Capability** is a bounded component that improves or influences one stage of context performance. A capability may be native to LeanCTX, locally installed, customer-developed, third-party supplied, or remote. Every capability has one primary type, one or more operations, a versioned input/output contract, declared effects, and measurable execution characteristics.

The following fourteen types are the OCLA v0 taxonomy. They turn the vision's categories into distinct, composable contract kinds; implementations may support more than one type only through separately declared operations.

| Type | Contract role | Typical implementation |
|---|---|---|
| `context_planner` | Selects candidate context, representation, budget, and recovery plan. | Structural code planner |
| `compression_provider` | Reduces a declared content representation. | Code, JSON, prose, or log compressor |
| `shell_output_optimizer` | Shapes command, compiler, test, or tool output. | Shell-output reducer |
| `response_optimizer` | Shapes an MCP, API, or other tool response. | Structured response optimizer |
| `retrieval_provider` | Supplies candidate information; it does not itself activate context. | Filesystem search, SQL, vector search |
| `knowledge_provider` | Supplies provenance-bearing knowledge or graph facts. | ADR graph, enterprise knowledge hub |
| `memory_provider` | Reads or writes task/session memory under freshness and policy controls. | Project or cross-agent memory |
| `context_cache` | Reuses safely scoped context material or derived artifacts. | Local semantic/content cache |
| `model_router` | Produces a model/provider route subject to policy. | Provider-neutral router |
| `evaluation_provider` | Assesses quality, correctness, or compliance. | Tests, build, verifier, review judge |
| `outcome_tracker` | Records the task outcome needed to close the optimization loop. | Outcome and attribution sink |
| `policy_decision_provider` | Evaluates trust, data, model, and transform policy. | Residency or no-lossy policy engine |
| `evidence_provider` | Emits receipts, provenance, and independently verifiable evidence. | Receipt/signing provider |
| `execution_provider` | Executes a bounded operation or delegates it to an approved runtime. | Local sidecar or enterprise runner |

`knowledge_provider` may expose graph queries, but the returned facts remain knowledge objects with provenance, authority, freshness, and classification. `shell_output_optimizer` is separate from the broader `response_optimizer` because its execution and cache constraints are materially different. `context_cache` is distinct from a runtime's incidental memoization: it declares reuse semantics that the planner can reason about.

## 3. CapabilityManifest v0

`CapabilityManifest v0` is the machine-readable declaration required before a capability can be registered. It is a contract proposal, not an authorization grant: the runtime validates it, then policy decides whether an installation or invocation is allowed.

```yaml
apiVersion: ocla.capability/v0
kind: CapabilityManifest

metadata:
  id: com.example.shell-optimizer
  version: 1.2.0                     # SemVer; immutable once published
  name: Example Shell Optimizer
  publisher:
    id: example
    identity: did:web:example.com
    signing_key_id: example-2026-01
  license: Apache-2.0
  artifact_digest: sha256:<digest>
  manifest_signature: <signature-over-canonical-manifest-and-digest>

spec:
  type: shell_output_optimizer
  operations: [optimize]

  execution:
    mode: local_process              # in_process | local_process | remote
    entrypoint: ./bin/example-shell-optimizer
    max_concurrency: 4

  input_contract:
    content_types: [text/x-shell-output]
    schema_ref: ocla://schemas/shell-output/v1
    max_bytes: 10000000
  output_contract:
    content_types: [text/x-shell-output]
    schema_ref: ocla://schemas/optimized-shell-output/v1
    preserves: [exit_status, protected_spans]

  fidelity:
    lossiness: lossless               # lossless | structural_lossy | semantic_lossy
    recoverability: original_ref      # none | original_ref | reversible
    deterministic: true

  permissions_required:
    - context:transform

  cache:
    cache_safe: true
    key_scope: content_and_contract
    preserves_provider_prefix: true
    invalidated_by: [capability_version, input_contract]

  performance:
    latency_budget_ms: 25
    resource_class: low

  trust_privacy:
    data_movement: local_only
    sends_raw_content_remote: false
    supported_classifications: [public, internal]
    network_endpoints: []

  telemetry:
    emits_invocation_metrics: true
    supports_receipt_linkage: true
    metrics: [input_bytes, output_bytes, input_tokens, output_tokens, latency_ms]
```

The required top-level contract fields are ID, version, type, execution mode, input and output contracts, lossiness, recoverability, permissions, cache behaviour, latency budget, trust/privacy boundary, and telemetry. Publisher, license, artifact integrity, and signature fields are also required for installable packages. A manifest MUST use a stable globally unique ID and a SemVer version; a registry MUST reject an ID/version pair whose signed manifest or artifact digest differs from the existing entry.

`input_contract` and `output_contract` name schemas and media types rather than embedding arbitrary payloads. The manifest MUST state protected fields or spans that an operation preserves when such fields exist. A capability MUST not claim `lossless`, `reversible`, `deterministic`, or `cache_safe` unless it can pass the corresponding conformance tests.

### Relationship to the current protocol manifest

The existing `lean-ctx-protocol::CapabilityManifestV1` is a valuable implementation substrate: it already declares ID, provider, kind, version, surfaces, local/remote support, reversibility, determinism, data movement, classifications, measurement support, schema references, and a conformance version. `CapabilityManifest v0` is the definitive architecture target that expands this into an explicit package identity, permission, cache, latency, and trust/privacy contract. The current protocol field set MUST evolve compatibly; it must not be silently reinterpreted.

## 4. Capability execution modes

| Mode | Invocation boundary | Appropriate use | Required controls |
|---|---|---|---|
| `in_process` | Rust/runtime trait call | LeanCTX built-ins and tightly trusted implementations | ABI/API compatibility, resource limits, crash containment where available |
| `local_process` | stdio, local socket, or loopback transport | Community and customer capabilities; language-neutral extensions | Process isolation, explicit executable digest, timeout, sandbox, bounded I/O |
| `remote` | Authenticated network request | Hosted optimizers, enterprise knowledge systems, remote evaluators | Data classification check, endpoint allowlist, region policy, timeout, cost accounting, explicit fallback |

MCP can carry a capability transport, but it is not a fourth execution mode. A tool-mediated implementation is declared as `local_process` or `remote` according to where it executes and how data moves. The narrow OCLA contract remains the authority for capability semantics.

Each manifest declares exactly the mode used for a registered implementation. A capability that supports multiple modes registers mode-specific artifacts or adapters; it does not leave locality ambiguous. Remote execution with unspecified data movement is invalid.

## 5. Permission and policy model

Capabilities receive no ambient runtime authority. A manifest requests permissions; the local or enterprise policy grants a least-privilege subset for an approved capability version and invocation scope. The runtime validates the grant before dispatch and records the decision in the receipt.

| Permission | Allows |
|---|---|
| `context:read` | Read active context or approved referenced content. |
| `context:transform` | Transform context supplied to the operation. |
| `context:recover` | Resolve retained originals or recovery references. |
| `filesystem:read` | Read policy-allowed workspace paths. |
| `filesystem:write` | Write policy-allowed generated artifacts or caches. |
| `network:outbound` | Connect only to approved endpoints under the declared data boundary. |
| `model:call` | Invoke policy-allowed model/provider routes. |
| `tool:execute` | Execute an allowlisted external tool or command. |
| `memory:read` | Read approved memory namespaces. |
| `memory:write` | Write approved memory namespaces. |
| `evidence:append` | Append invocation evidence to the active receipt lineage. |

Permissions are scoped further by path, namespace, endpoint, data classification, model allowlist, token/byte budget, and time. `context:transform` does not imply filesystem traversal; `network:outbound` does not imply the right to transmit protected context; and `model:call` does not bypass model policy. A policy engine may reject an otherwise valid manifest, require a local fallback, or require a lossless transform for protected sources.

Invocation failure policy is explicit: `fail_open`, `fail_closed`, `fallback_native`, `skip_capability`, or `abort_task`. Compliance redaction and verified evidence normally fail closed; an optional knowledge source can be skipped; optional optimization may fall back to an approved native capability.

## 6. Trust, identity, and privacy

An installed third-party capability is code execution and is treated as a supply-chain subject.

1. The publisher signs the canonical manifest and package/artifact digest.
2. The registry verifies the signature against a trusted publisher identity and records the key ID, digest, license, and installation source.
3. Policy evaluates the requested permissions, execution mode, data movement, supported classifications, network endpoints, and resource limits.
4. The runtime pins the exact ID, version, digest, and manifest signature for every promoted pipeline and receipt.
5. Operators retain a kill/disable switch that immediately prevents new invocation of a capability version.

Unsigned local development capabilities may be permitted only by explicit development policy and MUST be visibly marked untrusted. They cannot satisfy a signed or verified production profile. Enterprise policy can require organization-approved publishers, pinned versions, local-only processing, no raw-context egress, and no lossy transforms for designated classifications.

## 7. Conformance suite

The OCLA conformance suite is OSS and versioned independently from a capability. A capability declares the suite version it targets; registration checks that a passing result exists for the requested installation policy.

All capabilities MUST be tested for:

- manifest validity, schema compatibility, deterministic identity, and package integrity;
- declared input/output media types and schemas, empty and invalid input, protected fields, and output accounting;
- error taxonomy, timeout, cancellation, bounded resources, health checks, and declared fallback behaviour;
- permission declaration and denial behaviour; no undeclared filesystem, memory, network, model, tool, or evidence access;
- telemetry completeness: capability ID/version, operation, input/output size, latency, status, cost where applicable, recovery reference, and error classification;
- receipt linkage, version pinning, and reproducibility of any claimed deterministic behaviour.

Type suites add semantic checks. A `compression_provider` proves lossiness/recovery claims, determinism, protected-span preservation, and cache declarations. A `knowledge_provider` proves provenance, authority, freshness/staleness, classification, stable object identity, and request scope. A `context_cache` proves invalidation and isolation. An `execution_provider` proves sandbox, timeout, and cancellation handling. Passing conformance establishes contract behaviour, not business-quality superiority; performance promotion still requires benchmark evidence.

## 8. Performance Pipeline composition

`PerformancePipeline` is the ordered, version-pinned composition selected for a task. It is a part of the Performance Profile and is recorded in the Execution Plan and Receipt.

```text
Task Envelope
    │  task, quality floor, cost/latency budget, classification, policy
    ▼
Policy admission ──reject/limit──> fallback or task failure
    │
    ▼
Performance Planner / Runtime
    │  discovers compatible OCLA manifests and selects an ordered pipeline
    ▼
PerformancePipeline
    │  planner → retrieval/knowledge/memory → transform/cache → route/execute
    ▼
Context Envelope → Agent / Model / Tools → Evaluation / Outcome
    │                                     │
    └──────── telemetry + evidence ───────┴──> Receipt → Benchmark → Profile
```

The planner uses the manifest's declared properties and policy constraints to select only compatible candidates. The open OCLA layer exposes candidates, contracts, measurements, and deterministic reference scheduling; it MUST NOT embed proprietary workload ranking or learned selection weights.

Every pipeline step records its capability ID, exact version and artifact digest, operation, input/output references, policy decision, fallback behaviour, and invocation telemetry. A Receipt additionally pins LeanCTX runtime version, Performance Profile version, Context Kit versions where used, model/provider, and methodology version.

### Composition constraints

| Constraint | Required rule |
|---|---|
| Ordering | A step declares required predecessors and produced representations. For example, structural planning precedes destructive compression; a parser requiring exact text precedes a lossy transform. |
| Idempotency | A non-idempotent operation MUST not be scheduled twice for the same content lineage unless its contract explicitly permits it and the receipt records both invocations. |
| Fidelity | A downstream input contract and protected spans MUST be compatible with the upstream fidelity declaration. A semantic-lossy result cannot satisfy an exact-source requirement. |
| Recoverability | A consumer requiring an original or recovery reference MUST execute before retention expiry and only after a producer that declares a compatible recovery mode. |
| Cache safety | Reuse is allowed only when content lineage, capability version, contract version, policy scope, and relevant configuration match. A transform that changes stable provider prefixes cannot claim prefix-cache preservation. |
| Trust and permissions | The combined pipeline may not widen data movement or permissions beyond the task policy. A local upstream step does not authorize a remote downstream step. |
| Latency and failure | The aggregate latency budget includes dispatch and fallbacks. A step's declared failure mode controls whether the pipeline skips, falls back, or aborts. |

There is no implicit "stack all optimizers" behaviour. Each composition is a measured hypothesis: it is promoted only when the Quality Gate and benchmark show it meets the quality floor at acceptable cost and latency.

## 9. Mapping from the existing OCLA implementation

The codebase already contains substantial OCLA substrate. This document defines its destination; it does not claim that every target type is shipped today.

| Existing code | Current role | Target architecture mapping |
|---|---|---|
| `lean-ctx-protocol::CapabilityManifestV1` | Provider discovery and conformance metadata | Compatible predecessor of `CapabilityManifest v0`; extend rather than replace silently. |
| `core::ocla::invocation::CapabilityAdapter` and `CapabilityInvocation` | Common adapter call, policy constraints, result, and observation | Execution boundary for `in_process` adapters; evolve to contract-driven operation envelopes. |
| `core::ocla::adapters::AdapterRegistry` | Thread-safe ID/version adapter lookup and health checks | OSS Local Capability Registry implementation substrate. |
| `core::ocla::OclaRegistry` and `OclaService` | Built-in trait wiring and common discovery surface | Native capability catalog; current built-ins are reference implementations, not the closed universe of OCLA. |
| `CompressionProvider` | Compression request/result trait | `compression_provider`. |
| `ResponseOptimizer` and shell/reference adapters | Response and shell-output transformation | `response_optimizer` and `shell_output_optimizer`, separated by operation contract. |
| `ModelRouter` | Provider-neutral routing decision | `model_router`; open interface, while learned selection remains commercial. |
| `OutcomeTracker` | Outcome recording | `outcome_tracker`. |
| `ObservationHook`, `UsageSink`, `MetricsExporter`, `SavingsLedger` | Lifecycle, usage, metrics, and savings evidence | `evidence_provider` and required telemetry/receipt linkage. |
| `EfficiencyAnalyzer`, `ExperimentRunner`, `ConfigTuner` | Efficiency analysis, experiment, and configuration proposal | Evaluation/benchmark and profile-tuning substrate; neither independently promotes a pipeline. |
| `ConnectorScheduler`, `AgentGateway` | Connector scheduling and agent relay | `execution_provider` integration support. |
| `DeliveryRegistry`, cache modules, and content delivery adapters | Reuse/delivery accounting | `context_cache` and delivery/recovery substrate. |
| `ExecutionPlanV1`, `ExecutionReceiptV1`, task and evidence protocol types | Planned execution and auditable outcome | Canonical pipeline/receipt lineage and evidence destination. |

The current `OclaRegistry` wires fifteen built-in service traits, while the separate `lean-ctx-ocla` crate describes fourteen traits. Those implementation counts are not the new public taxonomy and must not define it accidentally. The v0 taxonomy above is the stable product contract; existing traits are mapped, adapted, split, or retired through compatible migrations.

## 10. Local Capability Registry — OSS

The Local Capability Registry is an execution catalog, not a marketplace. It stores, for every locally available capability:

- ID, version, immutable manifest, artifact digest/signature, publisher and license;
- execution adapter/endpoint, mode, health status, enabled state, and install source;
- approved local policy grant and supported classifications;
- conformance-suite result and runtime compatibility;
- local diagnostics and capability version pins used by profiles.

Registration validates the manifest before the executable is enabled. Lookups use exact ID and version and are deterministic. Enable/disable changes are auditable; disable prevents new invocations without mutating historical receipts. The reference operator interface is:

```bash
lean-ctx capability list
lean-ctx capability info <id>
lean-ctx capability enable <id>@<version>
lean-ctx capability disable <id>@<version>
lean-ctx capability doctor <id>@<version>
lean-ctx capability conformance <path-or-id>
```

The OSS registry includes local manifests, validation, install/health diagnostics, native and local-process adapters, signature verification, policy enforcement hooks, and conformance tooling. It does not require an account or a central marketplace.

## 11. Enterprise Capability Registry — Thinkery commercial

The Enterprise Capability Registry adds organization-wide controls over the same open manifest and conformance contract:

- approved publisher and signing-key trust stores;
- private capability distribution, organization namespaces, approval workflow, and license inventory;
- version pinning, rollout rings, rollback, revocation, and fleet-wide disable;
- policy packs for data classification, residency, network egress, sandboxing, and permission grants;
- audit trails, deployment evidence, and registry/profile compatibility reports.

It is commercial because it coordinates organizational trust, governance, and deployment. It must not fork the manifest or make a customer capability non-portable: an enterprise package still declares standard OCLA contracts and can be conformance-tested with the OSS suite.

## 12. Customer-developed capabilities

Customers can integrate their own context infrastructure without changing LeanCTX core. A customer may implement an in-process Rust trait/adaptor or package a language-neutral local process. The required path is:

```text
implement a typed operation → author manifest → run conformance → install in local/enterprise registry
    → grant scoped policy → benchmark in a pipeline → promote a pinned profile
```

Examples include a proprietary `knowledge_provider`, approved code index, internal graph, domain compressor, model router, policy engine, or evaluator. Customer knowledge remains candidate supply: the LeanCTX planner still decides task-specific activation, obeys classification and freshness metadata, and records provenance. Customer code is untrusted until its publisher, manifest, package, permissions, and conformance result pass the applicable registry policy.

## 13. OSS and Thinkery commercial boundary

| Open source: OCLA and LeanCTX Native | Thinkery commercial |
|---|---|
| Capability schema, manifest validators, typed contracts, reference adapters, and compatibility rules | Learned workload classification, capability ranking, and outcome prediction |
| Local registry, signature verification primitives, policy hooks, health checks, and conformance suite | Enterprise registry control plane: private distribution, approval, organization trust, fleet rollout, and audit operations |
| Native baseline capabilities, deterministic reference scheduling, local pipeline execution, and local fallback | Advanced candidate generation, optimization selection, drift detection, cross-customer intelligence, and economic optimization |
| Canonical task, plan, receipt, evidence, and profile compatibility contracts | Managed performance operations, governed profile rollout, and organization-level performance analytics |
| Customer capability portability and benchmarkability | Commercial support, governance, and managed service delivery |

Thinkery may provide commercial implementations of OCLA capabilities, but OCLA itself stays open and provider-neutral. Conversely, publishing an OCLA manifest does not expose Thinkery's selection intelligence or customer data. The durable product advantage is the ability to select, prove, and deploy the right composition for a workload—not ownership of every capability implementation.

## 14. Adoption rules

1. Make LeanCTX Native capabilities emit and consume the canonical manifest and invocation contracts first.
2. Ship one small external local-process reference capability and its conformance fixture before broad partner support.
3. Keep the Local Capability Registry and conformance suite ahead of marketplace work.
4. Treat all composition changes as benchmarked, version-pinned profile changes with explicit rollback.
5. Do not move proprietary selection intelligence into OCLA and do not weaken trust requirements for convenience.

This document is the definitive technical architecture for OCLA capability work. Historical design notes may remain as context, but new OCLA APIs, manifests, registries, adapters, conformance tests, and commercial boundaries MUST conform here.

## 15. Connection to Calibrator and Performance Benchmark (Research — 2026-08-21)

OCLA capabilities may later supply the Research Calibrator described in the
[archived platform vision](../_archive/sdk-first-convergence-2026-08-24/vision/14-LEANCTX-CALIBRATION-PERFORMANCE-PLATFORM-VISION.md). The relationship:

```text
OCLA Capability Registry       →  what is available
Performance Profile             →  which capabilities + settings to use
Benchmark                       →  how does this configuration perform
Calibrator                      →  which configuration is best
Performance Registry            →  what has worked historically
```

When the Calibrator generates candidate profiles, it draws from the Capability Registry to compose different capability stacks (e.g., LeanCTX-only vs. LeanCTX + RTK Shell vs. LeanCTX + Knowledge Graph). Each candidate is a `PerformanceProfileV1` with a different `capabilities` section.

### What OCLA must provide for the Calibrator to work

1. **Manifest-driven discovery** — `AdapterRegistry` must be production-wired (Gap 1 in [BENCHMARK-CALIBRATOR-GAP.md](BENCHMARK-CALIBRATOR-GAP.md))
2. **Capability invocation** — `CapabilityAdapter::invoke()` must work in the benchmark pipeline
3. **Measurement hooks** — `CapabilityManifestV1.measurement_support` fields (latency, tokens, quality) must produce real data
4. **Conformance** — each candidate capability must pass `check_manifest_conformance()` before benchmark inclusion

### What OCLA does NOT own

- Candidate generation logic (Calibrator's job)
- Pareto frontier analysis (Calibrator's job)
- Learned workload-capability ranking (Performance Registry / Thinkery commercial)
- Profile distribution and sharing (Profile Registry)

This separation is intentional: OCLA stays a bounded Engine mechanism. The BSL
1.1 Production SDK owns customer-facing lifecycle and selection policy; later
Cloud Selection Intelligence remains optional Research, not OCLA contract scope.
