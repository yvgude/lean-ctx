# OCLA Current-State Audit

**Audit role:** D4 — OCLA current-state audit  
**Scope:** `rust/crates/lean-ctx-ocla`, `lean-ctx-protocol`, `lean-ctx-sdk`, and OCLA use in the main crate  
**Purpose:** Phase B baseline for moving from the legacy service-trait registry to the canonical OCLA v0 capability architecture.

## Executive findings

1. `lean-ctx-ocla` exposes one base trait (`OclaService`) and **15** concrete capability traits.
2. The repository's old README, package description, and CLI status command still say **14** traits; they exclude `DeliveryRegistry`.
3. `OclaCapabilityKind::ALL`, `OclaRegistry`, and the passing crate test all confirm the actual count is **15**.
4. The compiled main crate re-exports the standalone traits and types through `core::ocla`; separately, it retains uncompiled duplicate/prototype source files that must not be mistaken for runtime API.
5. Every one of the 15 concrete traits has a production `Builtin*` implementation and is instantiated by `OclaRegistry::with_builtins()`.
6. Every concrete trait has at least one production invocation or production status inspection, although adoption depth varies.
7. The 15-service registry is separate from the manifest-based `CapabilityAdapter` / `AdapterRegistry` architecture.
8. The adapter registry has three implementations but its construction and registration are test-only; it is not the runtime path for the 15 built-ins.
9. `lean-ctx-protocol::CapabilityManifestV1` is a useful predecessor, but no `CapabilityManifestV0` Rust type exists.
10. The target OCLA v0 taxonomy contains 14 **different** capability types; it must not be inferred from the legacy 15 service traits.
11. `manifest.rs`, `observation.rs`, and `failure.rs` exist in `lean-ctx-ocla/src` but are not declared by its `lib.rs`; they are not compiled or public.
12. The orphan `manifest.rs` also imports `semver`, which is absent from that crate's dependencies; adding the module declaration without completing dependency and API work would fail.

## Audit method and boundary

- Read all source files in the standalone OCLA crate and its package manifest.
- Read the protocol and SDK package manifests plus their public library surfaces.
- Enumerated trait definitions and every direct trait implementation under `rust/`.
- Enumerated production accesses to the `OclaRegistry` fields in `rust/src/`.
- Distinguished production code from `#[cfg(test)]`, benchmark, and status-only references.
- Ran `cargo test -p lean-ctx-ocla` from `rust/`.
- Result: 8 unit tests passed, 0 failed; the test output explicitly names `contract_has_exactly_fifteen_discoverable_capabilities`.

## 1. Standalone `lean-ctx-ocla` crate

### Package and dependency direction

- Package: `lean-ctx-ocla` v1.0.0, library name `lean_ctx_ocla`.
- Declared purpose: stable provider-neutral boundary between lean-ctx core and enterprise code.
- Direct dependencies: `async-trait`, `blake3`, `getrandom`, `lean-ctx-protocol`, `serde`, `serde_json`, and `thiserror`.
- It depends on `lean-ctx-protocol`, never on the main `lean-ctx` engine.
- The root `lean-ctx` package directly depends on both `lean-ctx-ocla` and `lean-ctx-protocol`.
- `src/lib.rs` declares only `pub mod traits;` and `pub mod types;` and re-exports both modules.

### Complete Rust source inventory

| File | Lines | Compiled by `lib.rs` | Role |
|---|---:|---|---|
| `src/lib.rs` | 15 | Yes | Declares the public surface. |
| `src/traits.rs` | 128 | Yes | Base discovery trait and 15 service traits. |
| `src/types.rs` | 1,108 | Yes | Canonical request, token, capability, delivery, agent, and error types. |
| `src/manifest.rs` | 210 | No | Unexported manifest validator and policy filter. |
| `src/observation.rs` | 22 | No | Unexported capability observation record. |
| `src/failure.rs` | 25 | No | Unexported normalized failure record. |

### Public trait contract

`OclaService` is the shared supertrait. Each concrete trait requires `Send + Sync` through that supertrait and is object-safe.

| Trait | Method or methods | Async | Legacy kind |
|---|---|---:|---|
| `OclaService` | `capability() -> OclaCapability` | No | Common discovery surface. |
| `ObservationHook` | `observe(Observation)` | Yes | `ObservationHook`. |
| `UsageSink` | `record_usage(UsageRecord)` | Yes | `UsageSink`. |
| `MetricsExporter` | `export_metrics(Vec<MetricPoint>)` | Yes | `MetricsExporter`. |
| `SavingsLedger` | `record_savings(SavingsEvidence) -> String` | No | `SavingsLedger`. |
| `IntentClassifier` | `classify_intent(IntentRequest) -> IntentDecision` | No | `IntentClassifier`. |
| `OutcomeTracker` | `record_outcome(Outcome)` | No | `OutcomeTracker`. |
| `CompressionProvider` | `compress(CompressionRequest) -> CompressionResult` | No | `CompressionProvider`. |
| `ResponseOptimizer` | `optimize_response(ResponseOptimizationRequest)` | Yes | `ResponseOptimizer`. |
| `ModelRouter` | `route_model(ModelRouteRequest) -> RoutingDecision` | Yes | `ModelRouter`. |
| `EfficiencyAnalyzer` | `analyze_efficiency(EfficiencySample) -> EfficiencyAnalysis` | No | `EfficiencyAnalyzer`. |
| `ConfigTuner` | `propose_tuning(ConfigTuningRequest) -> ConfigProposal` | No | `ConfigTuner`. |
| `ExperimentRunner` | `run_experiment(ExperimentRequest) -> ExperimentResult` | No | `ExperimentRunner`. |
| `ConnectorScheduler` | `schedule_connector(ConnectorJob) -> ScheduledJob` | No | `ConnectorScheduler`. |
| `AgentGateway` | `relay_agent(AgentEnvelope)` and `route_message(...) -> String` | No | `AgentGateway`. |
| `DeliveryRegistry` | check, stub accounting, record, and stats methods | No | `DeliveryRegistry`. |

### Count discrepancy

- The leaf trait count is 15, not 14.
- `OclaCapabilityKind` has 15 variants and its `ALL` constant contains 15 entries.
- `OclaRegistry` has 15 `Arc<dyn Trait>` fields and its test is named `registry_exposes_all_fifteen_capabilities`.
- The OCLA crate test is named `contract_has_exactly_fifteen_discoverable_capabilities`.
- `README.md`, the package description, and `cli/ocla_cmd.rs::TRAITS` retain a 14-trait claim/list.
- The omitted trait is `DeliveryRegistry`.
- The v0 target taxonomy is also 14 types, but it is a different taxonomy and must not be used to preserve this stale count.

### Types relevant to capability normalization

- `OclaCapability` currently carries only `kind`, `api_version`, `status`, and numeric `limits`.
- `OclaRequestContext` provides request, session, agent, content, tenant, trace, and task lineage.
- `CanonicalTokenEnvelopeV1` and `TokenBalanceV1` provide payload-free token accounting.
- Request/result records exist for every legacy service trait.
- `AgentEnvelope`, `DeliveryEntry`, `DeliveryRecord`, and `DeliveryStats` cover agent relay and cross-agent delivery.
- `OclaError` and `OclaResult<T>` are the shared error boundary.
- Those types are reusable substrate, but they are not a package manifest, permission grant, or operation contract.

### Implementations in the standalone crate

- There are **no production implementations** of `OclaService` or any concrete capability trait inside `rust/crates/lean-ctx-ocla`.
- `types.rs` has inherent implementations and serialization/validation implementations only.
- `traits.rs` has one object-safety test; it creates no implementation.
- This is appropriate for a contract crate, but it means all runtime behavior lives in the main crate.

### Uncompiled source in the standalone crate

| File | What it contains | Current status |
|---|---|---|
| `manifest.rs` | `validate_manifest`, `ManifestValidationError`, `PolicyFilter` | Dead: not declared by `lib.rs`; no call sites. |
| `observation.rs` | `CapabilityObservationV1` | Dead: not declared by `lib.rs`; duplicates the core invocation observation family. |
| `failure.rs` | `CapabilityFailureKind`, `CapabilityFailure` | Dead: not declared by `lib.rs`; duplicates core/reference adapter failure shapes. |

`manifest.rs` attempts stronger data-movement and classification validation than `CapabilityManifestV1::validate`, but that code is dormant and currently lacks its `semver` dependency declaration.

## 2. Main-crate OCLA implementation

### Re-export and registry architecture

- `rust/src/core/ocla/mod.rs` defines `traits` and `types` modules that only re-export `lean_ctx_ocla`.
- Internal code continues to import `crate::core::ocla::*`; the standalone crate is therefore the source of truth for the compiled public trait/type names.
- `core/ocla/traits.rs` and `core/ocla/types.rs` are not selected: `mod.rs` defines inline re-export modules named `traits` and `types` instead.
- `core/ocla/agent_gateway.rs` and `core/ocla/scheduler_client.rs` are also not declared from `mod.rs`.
- `OclaRegistry::global()` lazily creates a singleton `OclaRegistry::with_builtins()`.
- The registry uses fixed named fields, not capability IDs, manifests, operations, or dynamic registration.
- Each field is an `Arc<dyn LegacyTrait>`.
- The root `core` module exposes OCLA as `pub mod ocla;`.

### Production implementors

Every legacy trait has exactly one normal built-in implementation wired by `OclaRegistry::with_builtins()`.

| Legacy trait | Production implementor | Source |
|---|---|---|
| `ObservationHook` | `BuiltinObservationHook` | `core/ocla/builtin/observation_hook.rs` |
| `UsageSink` | `BuiltinUsageSink` | `core/ocla/builtin/usage_sink.rs` |
| `MetricsExporter` | `BuiltinMetricsExporter` | `core/ocla/builtin/metrics_exporter.rs` |
| `SavingsLedger` | `BuiltinSavingsLedger` | `core/ocla/builtin/savings_ledger.rs` |
| `IntentClassifier` | `BuiltinIntentClassifier` | `core/ocla/builtin/intent_classifier.rs` |
| `OutcomeTracker` | `BuiltinOutcomeTracker` | `core/ocla/builtin/outcome_tracker.rs` |
| `CompressionProvider` | `BuiltinCompressionProvider` | `core/ocla/builtin/compression_provider.rs` |
| `ResponseOptimizer` | `BuiltinResponseOptimizer` | `core/ocla/builtin/response_optimizer.rs` |
| `ModelRouter` | `BuiltinModelRouter` | `core/ocla/builtin/model_router.rs` |
| `EfficiencyAnalyzer` | `BuiltinEfficiencyAnalyzer` | `core/ocla/builtin/efficiency_analyzer.rs` |
| `ConfigTuner` | `BuiltinConfigTuner` | `core/ocla/builtin/config_tuner.rs` |
| `ExperimentRunner` | `BuiltinExperimentExecutor` / alias `BuiltinExperimentRunner` | `core/ocla/builtin/experiment_executor.rs` |
| `ConnectorScheduler` | `BuiltinConnectorScheduler` | `core/ocla/builtin/connector_scheduler.rs` |
| `AgentGateway` | `BuiltinAgentGateway` | `core/ocla/builtin/agent_gateway.rs` |
| `DeliveryRegistry` | `BuiltinDeliveryRegistry` | `core/ocla/builtin/delivery_registry.rs` |

### Test-only implementors

| Implementor | Traits | Location |
|---|---|---|
| `SpyIntentClassifier` | `OclaService`, `IntentClassifier` | `proxy/forward/tests.rs` |
| `SpyEfficiency` | `OclaService`, `EfficiencyAnalyzer` | `core/ocla/registry.rs` tests |
| `SpySavings` | `OclaService`, `SavingsLedger` | `core/ocla/registry.rs` tests |
| `SpyObservation` | `OclaService`, `ObservationHook` | `core/ocla/registry.rs` tests |
| `SpyOutcome` | `OclaService`, `OutcomeTracker` | `core/ocla/registry.rs` tests |
| `SpyUsage` | `OclaService`, `UsageSink` | `core/ocla/registry.rs` tests |
| `SpyAnalyzer` | `EfficiencyAnalyzer` | `core/tool_lifecycle.rs` tests |
| `MockGateway` | Prototype `AgentGateway` | `core/ocla/agent_gateway.rs` tests; the entire file is uncompiled. |

### Production execution call sites

The table lists calls that execute a legacy capability in non-test `rust/src/` code. File/line locations are audit anchors, not a claim that every invocation succeeds; several projections are intentionally best-effort.

| Trait | Production call site(s) | Operational role |
|---|---|---|
| `ObservationHook` | `tools/server_metrics.rs:209` | Emits a tool-call observation. |
| `UsageSink` | `proxy/usage_meter.rs:291` | Projects finalized proxy usage into the OCLA sink. |
| `MetricsExporter` | `tools/server_metrics.rs:232` | Exports a bounded local tool-call metric batch. |
| `SavingsLedger` | `core/tool_lifecycle.rs:654` | Projects read savings evidence. |
| `IntentClassifier` | `tools/ctx_intent.rs:58`; `proxy/intent.rs:45` | Chooses a read-mode/intent classification. |
| `OutcomeTracker` | `tools/server_metrics.rs:224`; `core/tool_lifecycle.rs:330` | Records tool and read outcomes. |
| `CompressionProvider` | `core/tool_lifecycle.rs:625` | Projects aggressive read compression through the canonical provider. |
| `ResponseOptimizer` | `proxy/forward/transport.rs:157` | Records response token optimization after proxy forwarding. |
| `ModelRouter` | `proxy/routing.rs:137` | Chooses a provider/model alias route. |
| `EfficiencyAnalyzer` | `core/tool_lifecycle.rs:345` | Computes read density. |
| `ConfigTuner` | `core/auto_mode_resolver.rs:378` | Applies an adaptive read-mode proposal. |
| `ExperimentRunner` | `cli/eval_cmd.rs:249` | Runs the routing evaluation command. |
| `ConnectorScheduler` | `proxy/connector.rs:30` | Schedules a provider connector job. |
| `AgentGateway` | `tools/ctx_agent.rs:99`; `tools/ctx_agent.rs:238` | Routes messages and relays handoff envelopes. |
| `DeliveryRegistry` | `tools/ctx_read/dispatch.rs:802,821,837,879`; `http_server/handlers.rs:201` | Reuses, records, and reports cross-agent delivery. |

### Non-execution or test call sites

| Location | Reference | Meaning |
|---|---|---|
| `cli/ocla_cmd.rs:8-29,107` | `TRAITS` and `OclaService::capability()` | Status command inspects 14 legacy services; it omits `DeliveryRegistry`. |
| `proxy/routing.rs:110` | Replaces the router in a test registry | Test configuration only. |
| `proxy/response_optimizer.rs:740` | Registry path test | Test-only response optimization assertion. |
| `tools/registered/ctx_read_inline_tests.rs` | Delivery registry accesses | Inline test coverage only. |
| `bin/bench_cross_agent_cache.rs` | `BuiltinDeliveryRegistry` | Benchmark binary, not the standard production path. |
| `core/a2a/message.rs` | Re-exports `MessagePriority` and `PrivacyLevel` | Type reuse, not capability execution. |
| `core/ocla/builtin/delivery_registry.rs:269-311` | Explicit `lean_ctx_ocla::DeliveryRecordResult` | Direct type qualification only. |

### Used versus dormant status

| Area | Status | Evidence |
|---|---|---|
| Legacy trait/type API | Used | Main OCLA module re-exports the standalone crate and all built-ins implement it. |
| Fixed 15-field `OclaRegistry` | Used | Every production built-in is constructed and all traits have an invocation/status path. |
| `DeliveryRegistry` | Used but omitted from old status/docs | Main `ctx_read` dispatch and cache stats invoke it. |
| `OclaService` status discovery | Used but incomplete | CLI status table has 14 entries and hides `DeliveryRegistry`. |
| `lean_ctx_ocla` direct import usage | Minimal | Main code mainly reaches it through re-exports; direct qualifications are rare. |
| Standalone `manifest.rs` | Dead | Unexported and unreferenced. |
| Standalone `observation.rs` / `failure.rs` | Dead | Unexported and unreferenced. |
| `core/ocla/traits.rs` / `types.rs` | Dead duplicate/prototype source | Shadowed by the inline standalone-crate re-export modules in `core/ocla/mod.rs`. |
| `core/ocla/agent_gateway.rs` | Dead prototype source | Not declared by `core/ocla/mod.rs`; its incompatible two-method gateway trait is not the compiled public trait. |
| `core/ocla/scheduler_client.rs` | Dead prototype source | Not declared by `core/ocla/mod.rs`. |
| `CapabilityAdapter` implementations | Compiled and unit-tested | Passthrough, native context, and RTK adapters implement it. |
| `AdapterRegistry` runtime use | Dormant | Construction/registration is found only in tests. |
| `check_manifest_conformance` runtime use | Dormant | Called by `rust/tests/ocla_contract_suite_v1.rs`, not production code. |
| `SchedulerService` | Compiled reference implementation | `ReferenceScheduler` implements it; it is re-exported but is not integrated with the runtime adapter registry. |

## 3. Manifest-based adapter path

The codebase has a second, more v0-aligned architecture that has not yet been connected to the built-in trait registry.

| Component | Present behavior | Current limitation |
|---|---|---|
| `CapabilityAdapter` | Exposes `manifest`, `invoke`, and `health_check`. | Its operation envelope has only context, shell, and model input variants. |
| `CapabilityInvocation` | Carries task ID, capability ID/version, policy constraints, and timeout. | Does not carry manifest-derived permissions, content/media contracts, or receipt lineage. |
| `CapabilityObservationV1` | Captures tokens, latency, success, output reference, and metric map. | It is a core-local duplicate rather than the public standalone type. |
| `AdapterRegistry` | Thread-safe ID/version lookup, duplicate rejection, health listing. | Not populated by normal runtime startup. |
| `NativeContextAdapter` | Reads paths, compresses them, observes budgets, and loads a JSON manifest. | Not registered as the `CompressionProvider` or normal `ctx_read` runtime path. |
| `PassthroughAdapter` | Provides a baseline content-preserving adapter and JSON manifest. | Test-only registry coverage. |
| `RtkShellAdapter` | Uses a pinned external adapter manifest and optional native fallback. | Explicitly excluded from the production adapter registry. |

This split is the central Phase B issue: the legacy services are genuinely used, while the manifest/adapter path has the desired registration shape but no production coordinator.

## 4. `lean-ctx-protocol` audit

### What the protocol crate defines

`lean-ctx-protocol` is an independent, serializable wire-contract crate. Its public surface includes:

- capability discovery: `CapabilityManifestV1`, capability category, reversibility, determinism, data movement, surface support, and measurement support;
- common typed identifiers and schema-version validation;
- task envelopes, execution plans and receipts, decisions, outcomes, evidence, experiment assignments, and policy types;
- money, usage, savings observations/receipts, value-sharing, and billing-gap records;
- knowledge objects, routing candidates/receipts, classifications, validity, and source capabilities;
- auto-routing, eligibility, triage, circuit-breaker, control-plane, fleet-control, rollout, and outcome-engine contracts.

### Relationship to OCLA

- `lean-ctx-ocla` depends on the protocol crate, so protocol remains below OCLA in the dependency graph.
- The legacy OCLA service traits use standalone OCLA request/result types, not `CapabilityManifestV1`.
- The adapter subsystem, scheduler surface, catalogue, and conformance code use `CapabilityManifestV1` directly.
- `CapabilityManifestV1` already carries ID, provider, generic kind, version, surfaces, local/remote, reversibility, determinism, data movement, classifications, measurement support, schema refs, and conformance version.
- Its own `validate()` only checks schema version plus at least one execution locality.
- The uncompiled standalone validator would add checks for empty fields, duplicate surfaces, data movement, and classification compatibility, but it is not active.
- Protocol is therefore the correct compatibility substrate for v0, but it is not yet the canonical OCLA runtime contract.

## 5. `lean-ctx-sdk` audit

- The SDK is a thin in-process engine façade, not an OCLA SDK.
- It depends directly on `lean-ctx`, not on `lean-ctx-ocla` or `lean-ctx-protocol`.
- Its public API is `Engine`, `EngineBuilder`, read/search/symbol/tree/call helpers, output types, token/hash helpers, and addon authoring/audit types.
- `Engine::build()` constructs the normal engine `ToolRegistry`; it does not construct a local OCLA capability registry or expose capability discovery.
- A source search found no OCLA imports or direct OCLA usage in `rust/crates/lean-ctx-sdk`.
- SDK users may reach OCLA incidentally through engine tools, but cannot register, inspect, invoke, or receive typed OCLA capabilities through a stable SDK API.
- Phase B should keep that boundary explicit: do not present the SDK as a capability consumer until it can consume manifest/operation contracts safely.

## 6. Mapping legacy traits to the target 14 OCLA v0 types

The target taxonomy comes from `docs/internal/reference/OCLA-CAPABILITY-ARCHITECTURE.md`, not from the legacy registry count.

| Target v0 type | Current mapping | Audit assessment |
|---|---|---|
| `context_planner` | `IntentClassifier`, `ConfigTuner`, `EfficiencyAnalyzer` are partial inputs. | Missing a single operation that selects context, representation, budget, and recovery plan. |
| `compression_provider` | `CompressionProvider`; native context adapter. | Strong direct match. |
| `shell_output_optimizer` | `RtkShellAdapter` and shell-output code. | Partial; no legacy service trait and not registered in production. |
| `response_optimizer` | `ResponseOptimizer`. | Direct match, but operation contract is not manifest-driven. |
| `retrieval_provider` | Search, tree, and provider code elsewhere. | Missing OCLA capability contract/registration. |
| `knowledge_provider` | Knowledge graph/store/router code elsewhere. | Missing OCLA capability contract/registration. |
| `memory_provider` | Session, CCP, agent, and memory stores. | Missing OCLA capability contract/registration. |
| `context_cache` | `DeliveryRegistry`, cache modules, cache coordinator. | Partial; delivery accounting is not a declared reuse/invalidation contract. |
| `model_router` | `ModelRouter`. | Direct match. |
| `evaluation_provider` | `EfficiencyAnalyzer`, `ExperimentRunner`, tests/verifier. | Partial; no common quality/compliance operation or conformance binding. |
| `outcome_tracker` | `OutcomeTracker`. | Direct match. |
| `policy_decision_provider` | Policy constraints and config policies. | Missing first-class capability; policy is embedded in callers/adapters. |
| `evidence_provider` | `ObservationHook`, `UsageSink`, `MetricsExporter`, `SavingsLedger`, receipts. | Partial; telemetry is split and lacks one receipt/evidence capability. |
| `execution_provider` | `ConnectorScheduler`, `AgentGateway`, portions of `ExperimentRunner`. | Partial; no manifest-declared execution mode, entrypoint, or permission model. |

### Legacy traits that should not become v0 type names

- `OclaService` is a discovery mechanism, not a capability type.
- `IntentClassifier` is a planner signal, not the complete `context_planner` contract.
- `ConfigTuner` and `EfficiencyAnalyzer` are evaluation/planning substrate, not independently promotable pipeline types.
- `ObservationHook`, `UsageSink`, `MetricsExporter`, and `SavingsLedger` should converge behind evidence/receipt operations rather than retain four top-level taxonomy entries.
- `DeliveryRegistry` is a useful cache/delivery implementation detail; it should map to `context_cache` semantics rather than inflate the v0 taxonomy.

## 7. Gap analysis for `CapabilityManifest v0`

`CapabilityManifestV0` does not exist as a Rust type. The current `CapabilityManifestV1` must evolve compatibly rather than be silently reinterpreted.

| v0 requirement | Current state | Required Phase B work |
|---|---|---|
| Stable package identity | ID/version exist. | Add immutable package identity semantics and collision checks beyond in-memory ID/version duplication. |
| Publisher identity, license, digest, signature | Not in protocol manifest. | Add publisher, signing key, license, artifact digest, canonical manifest signature, and verification. |
| Primary v0 type and operations | Generic `CapabilityKind` exists. | Add exact v0 type plus declared operations; do not overload the legacy service enum. |
| Execution mode and entrypoint | Boolean local/remote only. | Declare exactly one mode, entrypoint/transport, concurrency, and bounded resources. |
| Input/output contracts | Optional schema references only. | Add content types, max bytes, protected fields/spans, and operation-level schemas. |
| Fidelity and recovery | Reversibility/determinism exist. | Add lossiness and recoverability explicitly; bind claims to conformance. |
| Permissions and grants | Invocation has generic allowlists. | Add requested permissions and a scoped runtime policy grant. |
| Cache declaration | No manifest cache contract. | Add safety, key scope, prefix preservation, invalidation, and retention/recovery declarations. |
| Performance declaration | Per-call timeout/metrics exist. | Add manifest latency budget, resource class, concurrency, and cost where applicable. |
| Trust/privacy | Data movement/classifications exist. | Add raw-content remote flag, endpoint allowlist, privacy commitments, and install trust. |
| Telemetry and receipts | Observations and evidence refs exist in several forms. | Standardize receipt linkage and required invocation metrics. |
| Local capability registry | `AdapterRegistry` is in-memory and test-populated. | Make an enabled-state, signed-manifest, health-checked local registry initialized at runtime. |
| Conformance | Protocol manifest carries a version; test suite exists. | Require compatible conformance evidence at registration and type-specific checks. |
| Canonical public records | Three standalone records are uncompiled; core has duplicates. | Choose one public owner for manifest, observation, and failure records; remove parallel definitions compatibly. |

## 8. Recommended first capability to normalize

**Normalize `CompressionProvider` first, targeting the v0 `compression_provider` type.**

Why this is the best starting point:

1. It has the clearest one-to-one mapping to a target v0 type.
2. It has a canonical non-test production call site in `core/tool_lifecycle.rs:625`.
3. It is synchronous, bounded, local, and does not require a remote provider, scheduler, or learned selection system.
4. `BuiltinCompressionProvider` already validates file references and token inputs, uses a bounded `CompressionContentPort`, produces a content-addressed output reference, and fails closed when no valid root exists.
5. It emits an OCLA bus event and has focused unit coverage for invalid inputs, resolve errors, empty content, output gain, and real-file operation.
6. `NativeContextAdapter` already proves that a manifest-backed native context optimization adapter can enforce input/output token policy and produce measured observations.

Recommended sequence:

1. Define a public v0-compatible manifest record by extending the protocol manifest additively.
2. Create one immutable manifest for `BuiltinCompressionProvider` with type `compression_provider`, operation `compress`, in-process execution, `context:transform`/`filesystem:read` permissions, local-only movement, lossiness/recovery claims, cache rules, limits, telemetry, and trust metadata.
3. Make the built-in expose that manifest and register it in the real local adapter registry during runtime construction.
4. Adapt the existing `CompressionRequest`/`CompressionResult` to an operation envelope without changing the current caller first.
5. Route the existing canonical call through the registry and preserve its current fail-closed semantics.
6. Add a compression-specific conformance fixture, then use the pattern for `response_optimizer`, `model_router`, and `outcome_tracker`.

## 9. Phase B decisions and guardrails

- Treat the 15 legacy services as migration inventory, not the future taxonomy.
- Correct the stale 14-count references separately; do not delete `DeliveryRegistry` to make documentation numerically match.
- Keep `CapabilityManifestV1` backward compatible while introducing v0-required fields.
- Do not activate orphan `lean-ctx-ocla` modules by merely adding `pub mod`; first consolidate their duplicate observation/failure ownership and make the manifest validator compile.
- Do not replace the fixed `OclaRegistry` wholesale before one native capability has a manifest-backed production path.
- Make runtime registration, policy admission, health, receipt evidence, and fallback behavior explicit before enabling third-party capabilities.
- Keep ranking, learned routing, fleet control, and proprietary economics outside the open capability contract.

## 10. Evidence summary

- `cargo test -p lean-ctx-ocla` passed: 8 passed, 0 failed.
- The standalone crate's own tests assert object safety and exactly 15 discoverable capability kinds.
- Direct source inspection shows all 15 built-ins are created by `OclaRegistry::with_builtins()`.
- Direct production-field search found invocation paths for all 15 traits.
- `AdapterRegistry::new()` and adapter registration occur only in tests.
- `check_manifest_conformance()` is invoked by the OCLA contract-suite test, not production runtime code.
- The protocol crate contains `CapabilityManifestV1`; a source search found no `CapabilityManifestV0` Rust type.
- The SDK contains no direct OCLA source imports or capability APIs.

## 11. Phase B starting point

The correct Phase B starting point is not to invent a second capability system. It is to converge the existing, working built-in `CompressionProvider` path with the already-present protocol manifest and adapter registry substrate, then generalize the same registration, policy, measurement, and receipt path to the remaining target types.
