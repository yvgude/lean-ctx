# C5 — Technical Convergence Plan

## Execution status — 2026-08-21

Contract-owner rules in this document still apply. Repository layout after WS-1:
one canonical Python SDK root, Rust workspace unchanged, and no separate
currently promoted Node SDK product. Implementation status:
[`MASTER-EXECUTION-PLAN.md`](../execution/MASTER-EXECUTION-PLAN.md).

This is a destination map, not proof that every listed module exists. Source
files and the [Codebase Map](CODEBASE-MAP.md) win when a planned path differs from
the current tree. Workspace target architecture and its gates are defined in
[Context Workspace & `.ctxpkg` Plan](../vision/07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md).

## Decision

LeanCTX v1.0 will keep the existing engines and stores, but introduce one
canonical product boundary above them.

The public product names are not aliases for arbitrary existing modules.

They are stable contracts with one designated owner, one wire shape, and one
lifecycle.

The six named product objects are:

1. LeanCTX.
2. ContextSession.
3. TuningProfile.
4. ContextKit.
5. ExecutionReceipt.
6. EvidenceBundle.

The vision exposes five top-level SDK operations.

TuningProfile is intentionally an explicit object, but is selected when
constructing LeanCTX or a session rather than becoming a sixth top-level verb.

The v1 rule is therefore:

> Existing modules remain implementation substrate; only the v1 contracts and
> facade define product semantics.

This avoids a destructive rename of mature compression, retrieval, proxy,
session, evidence, and configuration code.

It also prevents CLI, MCP, Proxy, and SDK surfaces from each inventing a
slightly different definition of a session, profile, kit, receipt, or bundle.

## ContextWorkspace placement

`ContextWorkspace` is a **post-v1 Research target**, not a seventh current
v1 contract and not a reason to rename current session, snapshot, package or
cache implementation. It is the future SDK semantic parent for source-backed
durable context state and bounded sessions.

Before it gains a module path or public API, the existing session/source/view/
plan/receipt reference path must pass its local contract fixtures. The
Workspace contract then composes the existing owners behind additive protocol
records; it must not create a competing session, receipt, cache or package
stack. ContextCheckpointV2, ContextDelta, fork and package composition each
need their own versioned migration and compatibility tests.

## Scope and source basis

This plan was derived from the required strategy and reality documents:

- docs/internal/reference/CODEBASE-MAP.md.
- docs/internal/reference/CODEBASE-MAP.md.
- docs/internal/vision/01-PRODUCT-ARCHITECTURE.md.

The architecture document requires one Context Engine, one kit format, one
session-ID format, and one Receipt schema at every integration depth.

The codebase map identifies the nearest current substrate for every object.

The reality audit is decisive where the strategy uses future-facing names:
Python SDK v1 now exposes `ContextSession` and a resolved profile surface as a
**Preview** contract, while no generally available cross-language
`TuningProfileV1` lifecycle or unified product boundary exists today.

The implementation plan must preserve that distinction.

## Non-goals for v1.0 convergence

- Do not market existing adaptive heuristics as AutoTune.
- Do not make cloud, fleet, team, billing, or marketplace code a dependency.
- Do not replace the proxy with an in-process SDK wrapper.
- Do not treat ContextBundleV1 as EvidenceBundleV1.
- Do not make the current process-global "active profile" the public profile
  lifecycle.
- Do not create a second receipt schema outside lean-ctx-protocol.
- Do not silently convert legacy session files into sealed product receipts.

## Architectural placement

The desired layering is:

~~~text
SDK bindings / CLI / MCP / Proxy
              |
        product facade
              |
  ContextSession coordinator
     |       |       |       |
 session   kernel  profiles  kits
     |       |       |       |
execution ledger  evidence flow
              |
       lean-ctx-protocol
~~~

The protocol crate owns portable, serializable vocabulary.

The main runtime crate owns lifecycle implementation and durable local state.

The SDK crate owns the safe developer-facing facade and task-local binding.

The CLI, MCP server, and proxy are integrations; they must call the lifecycle
boundary rather than define competing product records.

## Canonical module map

| Object | v1 wire contract | v1 runtime owner | v1 SDK owner |
| --- | --- | --- | --- |
| LeanCTX | no standalone persisted wire object | rust/src/core/context_runtime.rs | rust/crates/lean-ctx-sdk/src/leanctx.rs |
| ContextSession | rust/crates/lean-ctx-protocol/src/context_session.rs | rust/src/core/context_session.rs | rust/crates/lean-ctx-sdk/src/session.rs |
| TuningProfile | rust/crates/lean-ctx-protocol/src/tuning_profile.rs | rust/src/core/profiles/v1.rs | rust/crates/lean-ctx-sdk/src/tuning_profile.rs |
| ContextKit | rust/crates/lean-ctx-protocol/src/context_kit.rs | rust/src/kits/v1.rs | rust/crates/lean-ctx-sdk/src/context_kit.rs |
| ExecutionReceipt | rust/crates/lean-ctx-protocol/src/execution.rs | rust/src/core/receipt_assembler.rs | rust/crates/lean-ctx-sdk/src/receipt.rs |
| EvidenceBundle | rust/crates/lean-ctx-protocol/src/evidence_bundle.rs | rust/src/core/evidence_flow.rs | rust/crates/lean-ctx-sdk/src/evidence.rs |

The listed modules are the v1.0 destinations.

New modules may re-export legacy types during migration, but callers must not
depend on private legacy modules after the v1 public API ships.

## Shared identifiers and invariants

All v1 contracts need typed identifiers rather than unconstrained String
fields at the external boundary.

Add these wrappers in rust/crates/lean-ctx-protocol/src/common.rs, or a new
rust/crates/lean-ctx-protocol/src/identity.rs re-exported by common.rs:

- ContextSessionId.
- TuningProfileId.
- TuningProfileDigest.
- ContextKitId.
- ContextKitDigest.
- IntegrationId.
- EvidenceBundleId.
- EvidenceBundleDigest.
- ScenarioId.
- TraceId.

TaskId remains the execution-task identifier already provided by the protocol.

ContextSessionId is not interchangeable with TaskId.

One ContextSession can hold a task label, one or more execution attempts, and
the final receipt reference.

TaskId identifies the execution unit that a receipt and execution-ledger event
already use.

The initial v1 policy is one task per session, but retaining both identifiers
prevents a future nested session or retry model from breaking the receipt wire
contract.

Every content-addressed digest must declare its hash algorithm in the value,
for example blake3:<hex> or sha256:<hex>.

Canonical bytes must be generated only by the canonical serializer module.

No object may include a wall-clock value in bytes used to derive an immutable
object digest.

Observed timestamps belong in signed event metadata, not identity digests.

## 1. LeanCTX

### Current location in code

The current user-facing root is distributed across the main binary, CLI,
server, proxy, hooks, and configuration modules.

The most relevant in-process embedding surface is:

~~~text
rust/crates/lean-ctx-sdk/src/lib.rs
rust/crates/lean-ctx-sdk/src/engine.rs
~~~

That SDK exports Engine and EngineBuilder.

Engine intentionally dispatches real registered tools with a shared session
cache, but it exposes read, compression, token, hash, and addon capabilities.

It does not expose the strategy-shaped LeanCTX constructor, session lifecycle,
profile application, kit binding, wrap operation, or receipt lookup.

The current local command surface is rooted in rust/src/main.rs and
rust/src/cli, while the Attach runtime is primarily rust/src/server and
rust/src/tools.

The Wrap transport surface is rust/src/proxy and rust/src/cli/wrap_cmd.rs.

### What must change to match strategy naming

LeanCTX must become the one stable root facade, not a synonym for the binary,
the daemon, the proxy, or Engine.

The facade constructor validates project root, PathJail, selected integration,
profile compatibility, and protocol compatibility.

Construction must not create a task, mutate a prompt, start a provider call,
or write an evidence receipt.

Engine remains a useful low-level substrate and must not be renamed LeanCTX.

### New code required

Add rust/crates/lean-ctx-sdk/src/leanctx.rs with:

~~~rust
pub struct LeanCTX {
    runtime: Arc<ContextRuntime>,
    default_profile: TuningProfileHandle,
    integration: IntegrationDescriptorV1,
}

impl LeanCTX {
    pub fn builder(project: impl AsRef<Path>) -> LeanCTXBuilder;
    pub async fn session(&self, task: TaskSpecV1) -> Result<ContextSession, Error>;
    pub fn wrap<T>(&self, target: T, adapter: AdapterSelector) -> Result<Wrapped<T>, Error>;
    pub async fn load_kit(&self, request: ContextKitRequestV1) -> Result<KnowledgeKit, Error>;
    pub async fn receipt(&self, session: &ContextSession) -> Result<ExecutionReceiptV1, Error>;
}
~~~

Add rust/src/core/context_runtime.rs as the runtime-owned dependency container.

ContextRuntime owns validated project state, storage handles, protocol
capability negotiation, ContextKernel construction, profile repository, kit
repository, execution ledger, and evidence services.

ContextRuntime must be private to the main runtime crate except for narrowly
defined constructors needed by the SDK crate.

The existing SDK Engine becomes an internal field or adapter of ContextRuntime.

It must not become a second root object with its own session identity model.

### Exact Rust module path for v1.0

Public root:

~~~text
rust/crates/lean-ctx-sdk/src/leanctx.rs
lean_ctx_sdk::LeanCTX
~~~

Runtime root:

~~~text
rust/src/core/context_runtime.rs
crate::core::context_runtime::ContextRuntime
~~~

## 2. ContextSession

### Current location in code

The durable agent-work state lives in:

~~~text
rust/src/core/session/mod.rs
rust/src/core/session/types.rs
rust/src/core/session/state.rs
rust/src/core/session/persistence.rs
rust/src/core/session/paths.rs
rust/src/core/session/playbook.rs
~~~

The primary current record is core::session::SessionState.

SessionState stores an ID, project root, task, findings, decisions, touched
files, test results, progress, next steps, evidence, intents, stats,
compaction state, and playbook state.

It persists local working-session material and is used by CLI commands and
many context tools.

This makes core/session the authoritative backing-store owner for the
human/agent work-session record.

ContextSession does not live in context_kernel today.

The closest runtime behavior is in:

~~~text
rust/src/core/context_kernel/mod.rs
rust/src/core/context_kernel/orchestrator.rs
rust/src/core/context_kernel/bridge.rs
rust/src/core/context_kernel/proxy_bridge.rs
rust/src/core/context_kernel/mcp_bridge.rs
rust/src/core/context_kernel/recovery.rs
~~~

ContextKernel plans selected context and records context-level receipts.

Its proxy and MCP bridges collect request-local accounting, coverage, caller
identity, and inferred outcomes.

It has no canonical durable ContextSession object spanning a task lifecycle.

The append-only task trail lives separately in:

~~~text
rust/src/core/execution_ledger/mod.rs
rust/src/core/execution_ledger/event.rs
rust/src/core/execution_ledger/store.rs
rust/src/core/execution_ledger/projection.rs
~~~

Therefore the current implementation is split three ways:

- core/session owns persisted work state.
- core/context_kernel owns planning and per-channel measurement helpers.
- core/execution_ledger owns chained execution observations.

### What must change to match strategy naming

Do not rename SessionState to ContextSession.

SessionState contains implementation-specific mutable, user-facing work memory
and currently has timestamp-oriented persistence semantics.

ContextSession must be a lifecycle coordinator and public handle with explicit
states created, active, closing, sealed, and failed-to-seal.

It needs a durable ContextSessionId, TaskId, project identity, integration
descriptor, TuningProfile reference, mounted kit references, context-plan
references, execution-ledger trace, outcome reference, receipt reference, and
evidence-bundle reference.

The session public API owns prepare, retrieve, reuse, recover, use, and close.

Core/session remains an implementation store behind that API.

The ContextKernel remains the planner called by prepare and retrieve.

The execution ledger remains append-only evidence used when close seals the
receipt.

This resolves the current ambiguity without moving BM25, graph, cache, memory,
and selection code into core/session.

### New code required

Add rust/crates/lean-ctx-protocol/src/context_session.rs with the portable
records:

~~~rust
pub struct ContextSessionV1 {
    pub schema_version: u32,
    pub session_id: ContextSessionId,
    pub task_id: TaskId,
    pub project: ProjectRefV1,
    pub integration: IntegrationDescriptorV1,
    pub profile: ProfileRefV1,
    pub state: ContextSessionStatusV1,
    pub kit_refs: Vec<ContextKitRefV1>,
    pub plan_refs: Vec<PlanRefV1>,
    pub trace_id: TraceId,
    pub receipt_ref: Option<ReceiptId>,
    pub evidence_bundle_ref: Option<EvidenceBundleRefV1>,
}
~~~

Use a separate ContextSessionSnapshotV1 for serializable inspection output.

Do not serialize in-memory cache handles, locks, raw prompts, secret values,
or provider response bodies into ContextSessionV1.

Add rust/src/core/context_session.rs containing SessionCoordinator,
SessionHandle, and the state transition implementation.

SessionCoordinator composes:

- core::session::SessionState for local work memory and compatibility.
- core::context_kernel::ContextKernel for planning and retrieval.
- core::profiles::v1::ProfileRepository for resolved immutable profiles.
- kits::v1::ContextKitRepository for verified kit mounting.
- core::execution_ledger::ExecutionLedgerStore for chained events.
- core::receipt_assembler::ReceiptAssembler for close.
- core::evidence_flow::EvidenceBundleAssembler for evidence finalization.

Add rust/crates/lean-ctx-sdk/src/session.rs for the public Rust handle.

Use Tokio task-local storage in that SDK module for explicit session binding.

No global latest-session fallback is allowed in the public receipt API.

CLI compatibility commands may continue to use SessionState::load_latest.

They must not be used to satisfy LeanCTX::receipt() without an explicit
ContextSession handle or task-local session.

### Exact Rust module path for v1.0

Wire contract:

~~~text
rust/crates/lean-ctx-protocol/src/context_session.rs
lean_ctx_protocol::context_session::ContextSessionV1
~~~

Runtime lifecycle:

~~~text
rust/src/core/context_session.rs
crate::core::context_session::SessionCoordinator
~~~

Public handle:

~~~text
rust/crates/lean-ctx-sdk/src/session.rs
lean_ctx_sdk::ContextSession
~~~

### Required state transitions

Only these transitions are legal:

~~~text
created -> active -> closing -> sealed
created -> failed
active  -> failed
closing -> failed_to_seal
failed_to_seal -> sealed
~~~

prepare, retrieve, reuse, recover, and use require active.

close changes active to closing before receipt assembly begins.

After sealed, all mutating calls return SESSION_CLOSED.

A receipt retry is permitted only from failed_to_seal and must preserve the
same session ID, TaskId, trace ID, profile digest, and ordered event history.

## 3. TuningProfile

### Current location in code

The real configuration model lives in:

~~~text
rust/src/core/profiles/mod.rs
rust/src/core/profiles/types.rs
rust/src/core/profiles/loading.rs
rust/src/core/profiles/builtins.rs
~~~

The current core::profiles::Profile has sections for read, compression,
translation, layout, memory, verification, budget, pipeline, routing,
degradation, autonomy, and output hints.

The loading layer resolves a named TOML profile from project, user, or built-in
tiers and applies bounded inheritance.

The active profile is selected from an in-process override, LEAN_CTX_PROFILE,
config.toml, or the coder default.

The immediate configuration carrier is also distributed across:

~~~text
rust/src/core/config
rust/src/core/workspace_config.rs
rust/src/core/context_kernel/config_bridge.rs
rust/src/core/context_kernel/client_profile.rs
rust/src/core/tool_profiles.rs
~~~

ContextKit does not own profiles.

rust/src/kits/mod.rs owns task-specific TOML kits and their read, priority,
shell, quality, and system-prompt plans.

The separate core/context_package subsystem owns package artifacts, manifests,
lockfiles, signing, and verification, but is not the active Profile type.

### What must change to match strategy naming

The existing Profile is a mutable, name-resolved configuration document.

TuningProfileV1 must be an immutable, versioned, digest-addressed deployment
object with lifecycle state and compatibility information.

The public TuningProfile must include the resolved effective configuration, not
an unresolved inheritance chain whose behavior changes after a parent edit.

The v1 object needs:

- Schema version and profile ID.
- Semantic version or immutable revision.
- Canonical content digest.
- Parent/baseline lineage references.
- Target integration capabilities and protocol range.
- Normalized budget, selection, compression, cache, recovery, and policy
  fields that are supported by the v1 product.
- Evaluation evidence references.
- Lifecycle status draft, evaluated, promoted, deprecated, or revoked.
- Deployment metadata held separately from immutable content.

Do not export every experimental autonomy, research, and bandit field as a
stable profile knob.

Fields outside the evaluated v1 contract stay internal or experimental.

### New code required

Add rust/crates/lean-ctx-protocol/src/tuning_profile.rs with:

~~~rust
pub struct TuningProfileV1 {
    pub schema_version: u32,
    pub profile_id: TuningProfileId,
    pub revision: String,
    pub content_digest: TuningProfileDigest,
    pub lineage: ProfileLineageV1,
    pub compatibility: ProfileCompatibilityV1,
    pub operating_policy: OperatingPolicyV1,
    pub lifecycle: ProfileLifecycleV1,
    pub evaluation_refs: Vec<EvidenceRefV1>,
}
~~~

OperatingPolicyV1 should initially be a small evaluated projection from
core::profiles::Profile:

- context budget.
- read strategy and per-read bounds.
- search and reuse limits.
- compression mode and density.
- cache preference and threshold.
- verification requirements.
- degradation and recovery behavior.
- policy compatibility constraints.

Add rust/src/core/profiles/v1.rs.

This module owns ProfileRepository, resolve_to_v1, canonical_bytes,
content_digest, evaluate, promote, deprecate, and deployment lookup.

It adapts the current types::Profile and loading.rs resolver.

It must resolve inheritance before hashing and store the canonical resolved
result in a content-addressed profile store.

Do not put profile hashing in config or kits.

Add rust/crates/lean-ctx-sdk/src/tuning_profile.rs exposing an immutable
TuningProfileHandle and profile selection request types.

Add a profile-deployment record to ContextSessionV1 and ExecutionReceiptV1.

The deployment record identifies target integration, applied profile digest,
activation result, rollback reference, and conformance result.

### Exact Rust module path for v1.0

Wire contract:

~~~text
rust/crates/lean-ctx-protocol/src/tuning_profile.rs
lean_ctx_protocol::tuning_profile::TuningProfileV1
~~~

Runtime owner:

~~~text
rust/src/core/profiles/v1.rs
crate::core::profiles::v1::ProfileRepository
~~~

SDK owner:

~~~text
rust/crates/lean-ctx-sdk/src/tuning_profile.rs
lean_ctx_sdk::TuningProfileHandle
~~~

## 4. ContextKit

### Current location in code

The current active-kit implementation lives in:

~~~text
rust/src/kits/mod.rs
rust/src/cli/kit_cmd.rs
~~~

The current kits::ContextKit parses a strict TOML document with format version,
metadata, read plan, priority plan, shell plan, quality plan, and system
prompt.

It can load a named kit from project, user, or built-in locations.

It validates mode names and presently influences automatic read-mode choice
through kits::active_mode_for_path.

The more capable package substrate is distinct:

~~~text
rust/src/core/context_package/mod.rs
rust/src/core/context_package/manifest.rs
rust/src/core/context_package/lockfile.rs
rust/src/core/context_package/signing.rs
rust/src/core/context_package/verify.rs
~~~

That subsystem has manifest, package, signing, and verification primitives,
but it is not the runtime identity of a kits::ContextKit.

### What must change to match strategy naming

ContextKitV1 must be the only portable product contract for a kit.

It must bridge, not duplicate, TOML kit content and package integrity
capabilities.

The v1 object needs name, version, content digest, signer status, target
capabilities, compatible profile range, ordered plans, source reference,
installation result, and rollback information.

The runtime may initially materialize ContextKitV1 from legacy kit.toml.

It must not claim that every existing kit is a signed .ctxpkg artifact.

At v1, one loader resolves a pinned immutable kit and returns a handle.

Mounted kit references, not the entire kit prompt, go into session and receipt
records.

### New code required

Add rust/crates/lean-ctx-protocol/src/context_kit.rs with ContextKitV1,
ContextKitRefV1, ContextKitRequestV1, KitCompatibilityV1, and
KitIntegrityV1.

Add rust/src/kits/v1.rs.

This module owns ContextKitRepository, resolve_pinned, verify, materialize,
install, and rollback.

It converts legacy kits::ContextKit into a resolved ContextKitV1 only after
canonicalizing its content and calculating a digest.

It delegates package-signature verification to core::context_package when the
source is a package.

It retains source type explicitly, for example legacy_toml, local_package, or
approved_registry.

Add rust/crates/lean-ctx-sdk/src/context_kit.rs with KnowledgeKit, an
immutable application-facing handle.

ContextSession::use only accepts a verified KnowledgeKit handle.

### Exact Rust module path for v1.0

Wire contract:

~~~text
rust/crates/lean-ctx-protocol/src/context_kit.rs
lean_ctx_protocol::context_kit::ContextKitV1
~~~

Runtime owner:

~~~text
rust/src/kits/v1.rs
crate::kits::v1::ContextKitRepository
~~~

SDK owner:

~~~text
rust/crates/lean-ctx-sdk/src/context_kit.rs
lean_ctx_sdk::KnowledgeKit
~~~

## 5. ExecutionReceipt

### Current location in code

The canonical portable receipt schema already lives in:

~~~text
rust/crates/lean-ctx-protocol/src/execution.rs
lean_ctx_protocol::execution::ExecutionReceiptV1
~~~

ExecutionReceiptV1 already carries schema version, receipt ID, TaskId, PlanId,
context balance, token accounting, requested and selected model, provider,
model-call count, retries, latency, actual/baseline/avoided cost, ETPAO,
outcome reference, knowledge references, decision references, evidence
references, and signature.

SavingsReceiptV1 is separately and correctly owned by:

~~~text
rust/crates/lean-ctx-protocol/src/savings.rs
~~~

The closest general-purpose runtime constructor is:

~~~text
rust/src/core/context_kernel/receipt_builder.rs
~~~

ReceiptBuilder deterministically joins context balance, normalized provider
usage, model observations, knowledge references, decision references, and
evidence references into ExecutionReceiptV1.

It calculates a canonical receipt ID and BLAKE3 signature representation.

There are two other receipt construction paths:

~~~text
rust/src/core/execution_ledger/projection.rs
rust/src/core/evidence_flow.rs
~~~

execution_ledger::projection builds a receipt from chained events, but it uses
estimated model pricing when provider billing is unavailable.

evidence_flow::arm_to_receipt builds baseline and treatment receipts for a
matched provider run before creating SavingsReceiptV1 and evidence artifacts.

This is useful substrate, but it means receipt assembly is not yet singular.

### What must change to match strategy naming

ExecutionReceiptV1 remains the product name and protocol authority.

Do not introduce ReceiptV2 in the main crate or an SDK-specific receipt type.

Extend ExecutionReceiptV1 additively for the architecture-required fields:

- ContextSessionId.
- IntegrationDescriptorV1 and integration depth.
- SDK and runtime version references.
- input/output content digests and transformation summaries.
- TuningProfile reference and deployed profile digest.
- mounted ContextKit references.
- explicit CostBasisV1, such as provider_reported, calculated, reconciled,
  or unavailable.
- QualityEvaluationRefV1.
- recovery/degradation references.
- ordered event-manifest digest.
- cryptographic signature status and signer reference.

Signature bytes must retain explicit backwards-compatible versioning.

The current receipt builder's self-hash is not automatically an asymmetric
signature; the new contract must make algorithm and verification status clear.

### New code required

Keep the wire type in rust/crates/lean-ctx-protocol/src/execution.rs.

Add the additive fields there, with serde defaults where compatibility needs
them, and extend validation accordingly.

Add rust/src/core/receipt_assembler.rs as the only runtime receipt creation
entry point.

ReceiptAssembler accepts a sealed ContextSession lifecycle snapshot and gathers
the canonical data from ContextKernel, execution ledger, provider usage
normalization, profile repository, kit repository, and evidence ledger.

It delegates metric joining to the existing context_kernel::ReceiptBuilder.

It delegates event projection to execution_ledger only as an input source.

It delegates matched baseline/treatment calculations to SavingsReceiptV1.

ReceiptBuilder, execution_ledger::projection, and evidence_flow::arm_to_receipt
must be refactored to call ReceiptAssembler or narrower shared helper functions.

No integration may construct ExecutionReceiptV1 struct literals directly after
the migration is complete.

Add rust/crates/lean-ctx-sdk/src/receipt.rs with immutable receipt accessors
and verification-result types; it re-exports the protocol record rather than
copying it.

### Exact Rust module path for v1.0

Wire contract:

~~~text
rust/crates/lean-ctx-protocol/src/execution.rs
lean_ctx_protocol::execution::ExecutionReceiptV1
~~~

Runtime assembler:

~~~text
rust/src/core/receipt_assembler.rs
crate::core::receipt_assembler::ReceiptAssembler
~~~

Existing component retained as a dependency:

~~~text
rust/src/core/context_kernel/receipt_builder.rs
crate::core::context_kernel::receipt_builder::ReceiptBuilder
~~~

SDK access:

~~~text
rust/crates/lean-ctx-sdk/src/receipt.rs
lean_ctx_sdk::ReceiptHandle
~~~

## 6. EvidenceBundle

### Current location in code

EvidenceBundle does not have one current owner.

The strongest byte-level artifact implementation is:

~~~text
rust/src/core/evidence_bundle.rs
~~~

It builds deterministic ZIP evidence archives, sorts entries, uses stored ZIP
compression, fixed ZIP timestamps, canonical JSON, file hashes, and Ed25519
manifest signatures.

Its generate_artifact_bundle function is the correct low-level archive writer
to preserve.

The closest product-flow assembly is:

~~~text
rust/src/core/evidence_flow.rs
~~~

EvidenceFlow validates matched baseline/treatment provider arms, produces two
ExecutionReceiptV1 values, produces SavingsReceiptV1, includes a quality
comparison, writes artifacts, calls generate_artifact_bundle, and self-verifies
the result through the offline verifier.

Therefore evidence_flow is the correct existing integration point for the
future EvidenceBundle product pipeline.

There are two similarly named but different structures that must remain
separate:

~~~text
rust/src/core/context_kernel/evidence_bundle.rs
rust/crates/lean-ctx-protocol/src/knowledge_routing.rs
~~~

context_kernel::evidence_bundle::EvidenceBundle is a task-scoped list of
evidence references with a BLAKE3 bundle hash.

knowledge_routing::ContextBundleV1 is a selected context-candidate bundle.

Neither is the signed, portable EvidenceBundleV1 required by strategy.

### What must change to match strategy naming

EvidenceBundleV1 must become the one portable manifest for a signed,
content-addressed proof bundle.

It must identify scenario, commit, integration, profile, kits, baseline and
treatment receipts, quality result, methodology, artifacts, verification
manifest, signer, and bundle digest.

ContextBundleV1 must retain its selection-only meaning.

The small context-kernel evidence-reference set may be renamed internally to
TaskEvidenceSet or retained as an implementation-private module, but it must
not be exported as the product EvidenceBundle.

EvidenceFlow becomes the one product assembler.

The standalone archive writer remains a low-level deterministic serializer.

### New code required

Add rust/crates/lean-ctx-protocol/src/evidence_bundle.rs with:

~~~rust
pub struct EvidenceBundleV1 {
    pub schema_version: u32,
    pub bundle_id: EvidenceBundleId,
    pub content_digest: EvidenceBundleDigest,
    pub scenario: ScenarioRefV1,
    pub commit: CommitRefV1,
    pub integration: IntegrationDescriptorV1,
    pub profile: ProfileRefV1,
    pub kits: Vec<ContextKitRefV1>,
    pub baseline_receipt: ReceiptId,
    pub treatment_receipt: Option<ReceiptId>,
    pub savings_receipt: Option<String>,
    pub quality: QualityEvaluationRefV1,
    pub methodology: MethodologyRefV1,
    pub artifacts: Vec<EvidenceRefV1>,
    pub verification: VerificationManifestRefV1,
    pub signature: BundleSignatureV1,
}
~~~

EvidenceBundleV1 is the manifest model, not an instruction to embed all ZIP
entry bytes in the protocol struct.

Add EvidenceBundleAssembler to rust/src/core/evidence_flow.rs.

It receives a sealed ContextSession snapshot and optionally a matched
baseline/treatment evaluation.

It obtains receipts exclusively through ReceiptAssembler.

It creates the manifest, serializes required artifacts, calls
core::evidence_bundle::generate_artifact_bundle, then invokes the offline
verification API before returning success.

Keep core::evidence_bundle::generate_artifact_bundle as the byte archive
writer, but make it accept the canonical EvidenceBundleV1 manifest rather than
an untyped serde_json run_metadata value by the end of migration.

Extend rust/src/cli/dispatch/verify.rs to deserialize and validate the
EvidenceBundleV1 manifest as the source of the offline verification contract.

The independent packages/leanctx-verify implementation remains the oracle for
cross-implementation conformance.

Add rust/crates/lean-ctx-sdk/src/evidence.rs with EvidenceBundleHandle and
offline verification result accessors.

### Exact Rust module path for v1.0

Wire contract:

~~~text
rust/crates/lean-ctx-protocol/src/evidence_bundle.rs
lean_ctx_protocol::evidence_bundle::EvidenceBundleV1
~~~

Runtime product assembler:

~~~text
rust/src/core/evidence_flow.rs
crate::core::evidence_flow::EvidenceBundleAssembler
~~~

Archive writer retained below it:

~~~text
rust/src/core/evidence_bundle.rs
crate::core::evidence_bundle::generate_artifact_bundle
~~~

SDK access:

~~~text
rust/crates/lean-ctx-sdk/src/evidence.rs
lean_ctx_sdk::EvidenceBundleHandle
~~~

## 7. ctx.wrap()

### Current location in code

There is no implementation of the strategy's programmatic ctx.wrap(target,
adapter=...) API today.

The similarly named CLI operation lives in:

~~~text
rust/src/cli/wrap_cmd.rs
rust/src/wrap/mod.rs
rust/src/wrap/launch.rs
rust/src/wrap/snapshot.rs
rust/src/wrap/unwrap.rs
rust/src/wrap/verify.rs
~~~

That command configures supported coding agents to use a local proxy and MCP
server, snapshots configuration files, registers MCP, persists environment
variables, and supports restoration.

It is installation/Attach setup, not an in-process client wrapper.

The transport interception implementation lives in:

~~~text
rust/src/proxy/mod.rs
rust/src/proxy/openai.rs
rust/src/proxy/anthropic.rs
rust/src/proxy/forward/mod.rs
rust/src/proxy/forward/pipeline.rs
rust/src/proxy/forward/prepare.rs
~~~

Proxy handlers forward provider-shaped HTTP requests, transform allowed
context, and collect usage.

The context-kernel bridge at rust/src/core/context_kernel/proxy_bridge.rs
records identity, coverage, a broker budget, and inferred outcome signals.

This is Attach/sidecar substrate.

The OCLA adapter registry at:

~~~text
rust/src/core/ocla/adapters/registry.rs
rust/src/core/ocla/adapters/native_context.rs
rust/src/core/ocla/adapters/passthrough.rs
~~~

is a capability-invocation registry, not an adapter registry for wrapping
OpenAI, Anthropic, LangGraph, or another caller's SDK object.

### What must change to match strategy naming

The v1 ctx.wrap() must be a typed adapter API in the SDK crate.

It must resolve an exact supported adapter, bind an explicit or labelled
implicit ContextSession, prepare policy-approved context, invoke the native
target, observe success/failure/cancellation/stream close, and preserve the
caller-visible result and stream behavior.

Proxy traffic is one supported integration depth, not the general
implementation of wrap().

The current CLI wrap command must be renamed in documentation as
"install Attach integration" or "configure proxy wrap" where necessary.

Its CLI spelling can remain stable for backwards compatibility.

The new public SDK method is the only object-wrapper named wrap().

### New code required

Add rust/crates/lean-ctx-sdk/src/wrap/mod.rs.

Add rust/crates/lean-ctx-sdk/src/wrap/adapter.rs defining the typed adapter
trait and its request/response/stream observer hooks.

Add rust/crates/lean-ctx-sdk/src/wrap/registry.rs defining AdapterRegistry,
AdapterSelector, compatibility checks, and deterministic ambiguity handling.

Add rust/crates/lean-ctx-sdk/src/wrap/session_binding.rs for task-local
ContextSession propagation and labelled implicit session creation.

Add rust/crates/lean-ctx-sdk/src/wrap/openai.rs as the first supported adapter.

The first adapter should target one declared OpenAI SDK and operation version
range, not arbitrary look-alike objects.

Its normalizer maps request data into ContextInputV1, invokes
ContextSession::prepare, strips LeanCTX-only options, delegates to the native
client, and records events through SessionCoordinator.

Add rust/crates/lean-ctx-protocol/src/integration.rs with
IntegrationDescriptorV1, IntegrationDepthV1, AdapterManifestV1,
AdapterOperationV1, and IntegrationConformanceV1.

The runtime does not need a new proxy module for this work.

SessionCoordinator records the generic lifecycle events.

The existing proxy and CLI wrap modules become implementations of Attach
integration descriptors and emit the same session/receipt semantics.

### Exact Rust module path for v1.0

Public implementation:

~~~text
rust/crates/lean-ctx-sdk/src/wrap/mod.rs
lean_ctx_sdk::wrap::AdapterRegistry
lean_ctx_sdk::LeanCTX::wrap
~~~

First adapter:

~~~text
rust/crates/lean-ctx-sdk/src/wrap/openai.rs
lean_ctx_sdk::wrap::openai::OpenAIAdapter
~~~

Shared integration contract:

~~~text
rust/crates/lean-ctx-protocol/src/integration.rs
lean_ctx_protocol::integration::IntegrationDescriptorV1
~~~

Attach transport retained separately:

~~~text
rust/src/proxy
rust/src/cli/wrap_cmd.rs
~~~

## Object ownership rules

The following rules eliminate current duplication:

| Concern | v1 owner | Existing modules that become inputs/adapters |
| --- | --- | --- |
| Session lifecycle | core/context_session.rs | core/session, context_kernel, execution_ledger |
| Persisted work memory | core/session | CLI session commands, ctx_session tool |
| Context planning | core/context_kernel | BM25, graph, cache, retrieval providers |
| Profile canonicalization | core/profiles/v1.rs | core/profiles/types.rs and loading.rs |
| Kit canonicalization | kits/v1.rs | kits/mod.rs and core/context_package |
| Receipt assembly | core/receipt_assembler.rs | receipt_builder, execution_ledger projection, provider usage |
| Evidence assembly | core/evidence_flow.rs | evidence_bundle ZIP writer and quality components |
| Offline verification | CLI verifier plus leanctx-verify | ZIP manifest and signature primitives |
| Programmatic wrapping | SDK wrap module | proxy as Attach transport only |

No new top-level core module may own a parallel receipt, profile, kit, or
session record.

## Public API surface

The public Rust SDK should converge on this outline:

~~~rust
let ctx = LeanCTX::builder(".")
    .integration(IntegrationDescriptorV1::embed())
    .profile(ProfileSelector::pinned("coder", "1.0.0"))
    .build()
    .await?;

let kit = ctx.load_kit(ContextKitRequestV1::pinned("code-review", "2026.08")).await?;
let mut session = ctx.session(TaskSpecV1::new("Review PR #482")).await?;
session.use_kit(&kit).await?;
let prepared = session.prepare(ContextInputV1::text(prompt)).await?;
let result = agent.run(prepared).await?;
let receipt = session.close(OutcomeV1::succeeded(&result)).await?;
let bundle = ctx.evidence(&session).await?;
~~~

The `ctx.receipt(&session)` convenience method returns the sealed receipt.

The `ctx.evidence(&session)` extension is acceptable because it returns an
object rather than adding an incompatible lifecycle primitive.

If the public product is kept to exactly five top-level verbs, evidence is
exposed as session.evidence_bundle() or receipt.evidence_bundle_ref().

## Protocol changes

Update rust/crates/lean-ctx-protocol/src/lib.rs to export:

~~~text
pub mod context_session;
pub mod tuning_profile;
pub mod context_kit;
pub mod integration;
pub mod evidence_bundle;
~~~

Keep execution.rs, savings.rs, evidence.rs, and knowledge_routing.rs.

Do not move ContextBundleV1 out of knowledge_routing.rs in v1.

Its semantics are correctly context selection, not signed evidence.

Use deny_unknown_fields for finished v1 manifest records where forward
compatibility is managed by an outer envelope or schema version.

Use additive optional fields in ExecutionReceiptV1 where existing valid receipt
fixtures and verifier behavior require backwards compatibility.

Every protocol type needs:

- serde round-trip tests.
- explicit validation tests.
- canonical JSON fixture tests where the type is digest-addressed.
- backwards/forwards compatibility fixture tests.
- documentation of fields excluded from digests or signatures.

## Migration order

### Phase A — freeze vocabulary and contracts

1. Add identity wrappers and integration.rs to the protocol crate.
2. Add ContextSessionV1, TuningProfileV1, ContextKitV1, and EvidenceBundleV1.
3. Extend ExecutionReceiptV1 additively with session, profile, kit,
   integration, quality, cost-basis, and integrity references.
4. Publish JSON fixtures for every public object.
5. Freeze error-code names used by SDK lifecycle methods.

No SDK or CLI behavior changes before contract fixtures exist.

### Phase B — establish one runtime coordinator

1. Add ContextRuntime and SessionCoordinator.
2. Create ContextSessionV1 together with a legacy SessionState backing record.
3. Append TaskStarted and PlanCreated execution events when a v1 session
   starts and prepares context.
4. Make ContextKernel return plan references consumable by SessionCoordinator.
5. Bind resolved ProfileRefV1 and IntegrationDescriptorV1 at session creation.
6. Add explicit close and failed-to-seal handling.

The new coordinator initially supports Embed only.

### Phase C — canonicalize profile and kit

1. Add ProfileRepository and resolve legacy Profile into TuningProfileV1.
2. Add canonical serialization and content addressing after inheritance
   resolution.
3. Add ContextKitRepository and resolve legacy TOML kits into ContextKitV1.
4. Integrate core/context_package verification for package-backed kits.
5. Make session.use mount verified kit references only.
6. Record profile and kit digests in session events and receipts.

### Phase D — converge receipt and evidence assembly

1. Introduce ReceiptAssembler over the current ReceiptBuilder.
2. Route execution-ledger projection through common receipt field helpers.
3. Replace evidence_flow::arm_to_receipt literals with ReceiptAssembler input
   adapters.
4. Introduce EvidenceBundleAssembler in evidence_flow.
5. Replace untyped run metadata in archive creation with EvidenceBundleV1.
6. Make self-verification mandatory before bundle success is returned.

### Phase E — integrate depths

1. Add the typed OpenAI SDK wrap adapter.
2. Make proxy Attach supply IntegrationDescriptorV1 and session correlation.
3. Carry the session ID in the approved Attach header at the gateway boundary.
4. Make MCP tool dispatch consume and emit the same session identity.
5. Make CLI session and evidence commands call SessionCoordinator where a v1
   execution is requested.
6. Add an Embed reference agent to test the complete lifecycle.

### Phase F — retire ambiguous product ownership

1. Mark direct construction helpers private or deprecated.
2. Rename documentation for CLI wrap to installation/Attach terminology.
3. Make context_kernel/evidence_bundle non-public or rename it
   TaskEvidenceSet after downstream migration.
4. Keep ContextBundleV1 unchanged and document its selection-only purpose.
5. Reject customer-facing savings claims lacking an EvidenceBundleV1 that
   passes offline verification and quality policy.

## Compatibility strategy

Existing SessionState JSON files remain readable as legacy work-session files.

They do not become ContextSessionV1 merely because they have an id field.

A migration creates a fresh v1 ContextSession with provenance that references
the imported legacy session file and records which fields were mapped.

Existing TOML profiles remain supported as input documents.

The resolver produces an immutable TuningProfileV1 only after all inheritance
is materialized and policy validation succeeds.

Existing TOML kits remain supported as legacy sources.

Their ContextKitV1 signer status is NotSigned unless a verified package source
or signer record proves otherwise.

Existing ExecutionReceiptV1 JSON remains valid under its current schema.

New optional receipt fields must not invalidate old fixtures without a schema
or feature-gate transition plan.

Existing evidence ZIP verification continues to validate current manifest
version one archives.

EvidenceBundleV1 manifest validation must support old bundle manifests as an
explicit legacy profile, not by guessing missing scenario or profile fields.

## Conformance matrix

All depths must produce equivalent object references.

| Requirement | Embed | Wrap | Attach/MCP/Proxy |
| --- | --- | --- | --- |
| ContextSessionId | created directly | explicit or task-local implicit | header or gateway correlation |
| Profile digest | bound at session creation | bound before call | resolved at gateway admission |
| Kit digest | mounted by session | mounted by session | referenced when gateway supports it |
| Context plan ref | full planner output | full planner output | observable gateway plan/output |
| Execution events | host-owned full events | adapter observations | observable transit events only |
| Receipt schema | ExecutionReceiptV1 | ExecutionReceiptV1 | ExecutionReceiptV1 |
| Bundle schema | EvidenceBundleV1 | EvidenceBundleV1 | EvidenceBundleV1 |

An Attach receipt may declare limited observability.

It must never fabricate host-only details such as application retry decisions or
unobserved prompt context.

That difference is recorded by integration depth and coverage fields, not by
using a different receipt type.

## Test plan

### Protocol tests

- ContextSessionV1 validation rejects absent project, profile, integration, or
  invalid lifecycle references.
- TuningProfileV1 digest fixture is stable across process runs.
- TuningProfileV1 rejects unresolved inheritance in the immutable contract.
- ContextKitV1 rejects an incompatible profile or invalid digest.
- ExecutionReceiptV1 validates cost basis and quality reference consistency.
- EvidenceBundleV1 validates receipt, artifact, and verification references.
- ContextBundleV1 remains a context-selection fixture and is not accepted as
  EvidenceBundleV1.

### Runtime tests

- SessionCoordinator persists a ContextSessionId and maps safe work-state
  fields to its backing SessionState.
- prepare records a plan and stays within the bound profile budget.
- use rejects unverified and incompatible kit handles.
- recover records a bounded proposal but does not invoke user code retry.
- close seals exactly one receipt despite a retry after failed finalization.
- receipt assembly from a fixed event fixture is deterministic.
- evidence assembly from fixed artifacts creates byte-identical ZIP output.
- tampering with a receipt, quality record, or manifest fails offline verify.

### Integration tests

- Embed, Wrap, and Attach fixtures produce the same ContextSessionV1 schema.
- The OpenAI adapter preserves response type, error, cancellation, stream
  chunk order, and backpressure behavior.
- Adapter auto-selection rejects zero or multiple matching adapters.
- Proxy session header propagation does not overwrite a valid explicit session.
- MCP calls record only the supplied task session, never a process-global
  unrelated receipt.
- CLI install/wrap produces an integration descriptor rather than a fake
  programmatic wrapper receipt.

### Regression gates

- cargo test --lib.
- cargo clippy --all-features -- -D warnings.
- cargo fmt --check.
- Protocol fixture comparison in Rust, Python, Node, and verifier projects.
- Offline verifier tamper tests for every new EvidenceBundleV1 fixture.

## Acceptance criteria

v1.0 convergence is complete only when all of the following are true:

1. lean_ctx_sdk::LeanCTX is the documented root constructor.
2. A developer can create one explicit ContextSession and close it into an
   ExecutionReceiptV1 without using CLI global state.
3. The session records an immutable TuningProfileV1 digest.
4. The session can mount a verified, version-pinned ContextKitV1.
5. ReceiptAssembler is the sole production constructor for
   ExecutionReceiptV1.
6. EvidenceFlow emits an EvidenceBundleV1 that passes offline verification.
7. Wrap, Attach, and Embed emit the same session/profile/receipt identifiers.
8. ContextBundleV1 remains separate from EvidenceBundleV1 in code and docs.
9. The public SDK never reflects or wraps arbitrary foreign objects.
10. No savings claim passes the v1 proof gate without a matched baseline,
    quality result, cost-basis disclosure, and verified bundle.

## Decisions that should remain explicit

### ContextSession is not SessionState

SessionState is retained as the durable local work-memory substrate.

ContextSession is the lifecycle coordinator and external product contract.

### ContextSession is not ContextKernel

ContextKernel is the planning and context-selection subsystem.

It is invoked by a ContextSession, but does not own cross-integration identity,
profile binding, receipt sealing, or evidence finalization.

### Profile is not Kit

TuningProfile defines operating constraints and performance policy.

ContextKit defines pinned domain/workflow material and ordered plans.

A session binds both independently and records both digests.

### Receipt is not a report

ExecutionReceiptV1 is a canonical protocol record.

Human-readable reports are projections derived from receipts and bundles.

### EvidenceBundle is not ContextBundle

ContextBundleV1 describes selected retrieval candidates.

EvidenceBundleV1 proves an execution/evaluation artifact set.

### CLI wrap is not ctx.wrap()

CLI wrap configures an Attach-sidecar integration.

ctx.wrap() is a typed SDK adapter preserving an application's existing calling
convention and return behavior.

## Risks and controls

| Risk | Control |
| --- | --- |
| Public types duplicate internal types | Protocol owns serializable vocabulary; SDK re-exports it. |
| Receipt values diverge by path | ReceiptAssembler becomes the only production writer. |
| Legacy profile changes alter history | Hash resolved immutable profile content, not profile name alone. |
| Legacy kit is incorrectly called verified | Preserve explicit source and signature status. |
| Proxy over-claims observability | Integration depth and coverage constrain receipt facts. |
| Session global state leaks across tasks | Task-local binding and explicit handles; no public latest fallback. |
| Bundle bytes become nondeterministic | Keep sorted ZIP entries, fixed timestamps, canonical manifest bytes. |
| Migration breaks existing tools | Leave legacy substrate in place behind adapters and compatibility APIs. |

## First implementation ticket set

1. protocol: add identity wrappers, integration.rs, and context_session.rs.
2. protocol: add tuning_profile.rs, context_kit.rs, and evidence_bundle.rs.
3. protocol: add additive receipt references and frozen fixtures.
4. runtime: add ContextRuntime and SessionCoordinator skeleton with Embed.
5. runtime: add profiles::v1 canonical resolved-profile repository.
6. runtime: add kits::v1 pinned resolver over legacy TOML kit sources.
7. runtime: add ReceiptAssembler around ReceiptBuilder and execution ledger.
8. runtime: add EvidenceBundleAssembler around EvidenceFlow and archive writer.
9. SDK: add LeanCTX, ContextSession, profile, kit, receipt, and evidence
   modules.
10. SDK: add AdapterRegistry and one exact OpenAI adapter.
11. integrations: route proxy/MCP session correlation through coordinator.
12. tests: add cross-depth contract fixtures and offline verifier conformance.

## Final convergence answer

ContextSession lives today primarily in rust/src/core/session as SessionState;
context_kernel is the planner/measurement substrate it must call, not its home.

TuningProfile lives today primarily in rust/src/core/profiles as Profile;
config carries selection and kits are a separate workflow object.

ExecutionReceipt lives canonically in lean-ctx-protocol/execution.rs; the
closest builder is core/context_kernel/receipt_builder.rs, but ledger
projection and EvidenceFlow currently construct competing variants.

EvidenceBundle lives today as a split implementation: core/evidence_flow.rs is
the closest product assembler, while core/evidence_bundle.rs owns the signed
deterministic archive writer.

ctx.wrap() does not exist as a strategy-shaped programmatic API; CLI
wrap_cmd.rs configures proxy/MCP Attach and rust/src/proxy performs transport
interception. The v1 implementation belongs in the SDK wrap module, not in
proxy.

The exact v1 destinations in the canonical module map are the technical
boundary that turns those working substrates into one coherent product.
