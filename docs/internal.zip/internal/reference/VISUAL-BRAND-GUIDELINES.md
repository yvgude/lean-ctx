# LeanCTX / Thinkery — Visual Brand Guidelines

**Status:** Canonical visual direction  
**Date:** 2026-08-20  
**Brands:** Thinkery / LeanCTX

---

# 1. Visual objective

The identity must communicate:

- performance engineering,
- precision,
- infrastructure,
- technical authority,
- industrial durability,
- controlled complexity.

The brand should not look like a generic AI startup.

It should feel closer to:

- engineering instrumentation,
- systems software,
- compiler/runtime infrastructure,
- advanced industrial tooling,
- high-performance computing.

The visual system should make performance **visible**.

---

# 2. Shared visual DNA

Thinkery and LeanCTX share:

- geometric construction,
- strict grids,
- modular forms,
- black / off-white base,
- technical data language,
- restrained accent color,
- precise typography,
- structural diagrams,
- engineered whitespace.

They should clearly belong to the same company.

They should not look identical.

---

# 3. Brand distinction

## Thinkery

Visual role:

> **Architectural / organizational / enduring**

Thinkery represents:

- system building,
- ownership,
- commercial operation,
- organizational scale.

Thinkery should feel:

- heavier,
- more architectural,
- more physical,
- more material.

---

## LeanCTX

Visual role:

> **Technical / execution-level / performance**

LeanCTX represents:

- context flow,
- signal,
- precision,
- optimization,
- measurement.

LeanCTX should feel:

- more dynamic,
- more data-driven,
- more procedural,
- more performance-oriented.

---

# 4. Thinkery mark

The current architectural `T`-like mark is the recommended direction.

It communicates:

- structure,
- mass,
- negative-space passage,
- modular assembly,
- infrastructure.

Do not redesign it into a softer or more "AI" form.

The mark should remain:

- solid,
- geometric,
- directional,
- simple enough for signage and physical application.

---

# 5. LeanCTX mark

The current bracket-like mark with the central horizontal signal is the recommended direction.

Conceptually:

```text
<     >
context boundary

   —
signal / minimal state

<  —  >
controlled context
```

Possible associations:

- constrain,
- select,
- focus,
- compress,
- route,
- frame,
- deliver.

Do not over-explain the logo publicly.

It should feel self-evidently technical.

---

# 6. Logo hierarchy

## Thinkery

Primary lockup:
- mark + Thinkery wordmark.

Secondary:
- mark only.

Use for:
- corporate,
- contracts,
- enterprise,
- signage,
- company-level communication.

## LeanCTX

Primary lockup:
- mark + LeanCTX wordmark.

Secondary:
- compact mark.

Use for:
- product,
- SDK,
- docs,
- CLI,
- dashboards,
- benchmark reports,
- GitHub,
- developer communication.

---

# 7. Endorsement

Recommended relationship:

```text
LeanCTX
Built by Thinkery
```

or:

```text
LeanCTX
A Thinkery product
```

Use sparingly.

Thinkery should not visually overpower LeanCTX on developer surfaces.

---

# 8. Color system

The system should remain predominantly monochrome.

## Carbon

`#0A0A0A`

Primary dark background.

## Paper / Bone

`#F2F0E9`

Primary light background.

Use warm off-white rather than clinical white.

## Graphite

`#171718`

Secondary dark surface.

## Steel

`#2A2A2D`

Panels, borders, secondary modules.

## Cool Gray

`#8B9099`

Secondary labels / reference data.

## Concrete

`#B8BDC3`

Light structural secondary.

---

# 9. Primary accent

## Signal Orange

`#FF4B00`

Use very sparingly.

Semantic role:

> **intervention / optimized state / active focus**

Use for:

- tuned state,
- selected control,
- primary CTA,
- optimization delta,
- active Performance Profile,
- routing highlight.

Do not use orange as large decorative fill.

---

# 10. Secondary technical accent

## Ice Blue

`#A8B8C7`

Use only where a second technical state is required.

Possible role:

- secondary reference,
- baseline trace,
- informational state.

It must never compete with Signal Orange.

If only one accent is needed, use orange.

---

# 11. Verification colors

Use a muted green only for:

- PASS,
- VERIFIED,
- healthy.

Use red only for:

- failed quality gate,
- regression,
- error.

Neither green nor red is a primary brand color.

---

# 12. Semantic color model

```text
PAPER / WHITE
baseline / observed / neutral

ORANGE
LeanCTX intervention / tuned state / selected Profile

GRAY
infrastructure / reference / inactive

ICE BLUE
secondary comparison

GREEN
verified pass

RED
failed gate / regression
```

Color should carry meaning rather than decoration.

---

# 13. Typography

The supplied **Aeonik** direction is appropriate if licensing is secured.

## Primary sans

Aeonik or equivalent high-quality neo-grotesk.

Use for:

- headlines,
- body,
- UI,
- navigation,
- diagrams.

Desired qualities:

- neutral,
- engineered,
- precise,
- strong numerals,
- low personality noise.

## Technical mono

IBM Plex Mono or equivalent.

Use for:

- commands,
- run IDs,
- hashes,
- metrics,
- benchmark metadata,
- receipts,
- technical labels.

---

# 14. Type hierarchy

## Display

Large, clean, left aligned.

Example:

> Performance starts  
> before inference.

Avoid expressive oversized typography for its own sake.

## Section headings

Short, architectural, sentence case.

## Eyebrows

Uppercase / tracked technical labels.

Examples:

```text
CONTEXT PERFORMANCE INFRASTRUCTURE
BENCHMARK / RUN 0042
PERFORMANCE PROFILE / V1.4.2
RECEIPT / VERIFIED
```

## Body

Calm, readable, technically precise.

## Mono metadata

```text
MODEL        gpt-4o-mini
WORKLOAD     coding-agent-v1
RUN          rcpt_9843f2a1
STATUS       VERIFIED
```

---

# 15. Grid system

Recommended:

- 12-column responsive web grid,
- 8px base spacing unit,
- spacing in 8/16/24/32/48/64 multiples,
- strong vertical alignment,
- thin structural rules.

The grid may become visible in:

- diagrams,
- posters,
- reports,
- technical brand applications.

Do not show the grid everywhere.

It is an underlying discipline.

---

# 16. Composition

Preferred:

- strong left alignment,
- asymmetry,
- large negative space,
- modular panels,
- thin rules,
- data blocks,
- controlled density.

Avoid:

- centered SaaS hero stacks,
- floating gradient cards,
- excessive rounded cards,
- bubbly layouts.

---

# 17. Radius

Use radius sparingly.

## Brand / editorial
Mostly square or near-square geometry.

## UI
Small functional radius only.

## App icon
Rounded outer system container is acceptable.

Do not turn every panel into a rounded SaaS card.

---

# 18. Line language

Lines are a core shared primitive.

Use:

- solid signal lines,
- dotted references,
- routing paths,
- calibrated ticks,
- thin dividers.

Avoid neon glow.

A 1px digital stroke should be the default unless scale requires otherwise.

---

# 19. Routing graphics

LeanCTX routing lines should represent real concepts:

- input,
- branch,
- selection,
- convergence,
- state change,
- output.

They should not be random cyber-tech decoration.

Good:

```text
input sources
   ├── code
   ├── tools
   ├── memory
   └── history
        ↓
   selected context
        ↓
      model
```

Bad:

Decorative lines that imply technical meaning but encode nothing.

---

# 20. Compression graphics

Compression bars are a recognizable LeanCTX primitive.

Simple example:

```text
BASELINE
████████████████

LEANCTX
█████
```

Advanced versions may show:

- retained structure,
- removed regions,
- recovery references,
- context budget.

Do not make them look like generic progress bars.

---

# 21. Brackets and frames

Bracket structures should indicate:

- bounded context,
- selection,
- inspection,
- active module,
- focus.

They can appear as:

```text
[ CONTEXT ]
```

or more abstract geometric bracket systems derived from the LeanCTX mark.

Use consistently.

---

# 22. Data visualization

Data visualization should become part of the brand identity.

Primary chart types:

- baseline vs treatment,
- performance over time,
- cost / quality frontier,
- context distribution,
- routing flow,
- Performance Profile comparison.

Avoid:

- donut charts,
- 3D charts,
- generic KPI dashboards,
- decorative radar charts.

---

# 23. Chart semantics

### Baseline
Paper/white or neutral gray.

### LeanCTX treatment
Signal Orange.

### Secondary reference
Ice Blue.

### Pass threshold
Thin gray or muted green.

### Failed threshold
Red.

Always label:

- axes,
- units,
- methodology,
- baseline,
- treatment.

---

# 24. Canonical benchmark card

```text
BENCHMARK / RUN 0042

WORKLOAD
payment-review-v1

               BASELINE      LEANCTX
INPUT          139,115       14,016
CACHED          87,040        8,192
COST            $0.370        $0.058
QUALITY         PASS          PASS

COST DELTA
-84.3%

STATUS
VERIFIED
```

This should become a recognizable LeanCTX visual object.

---

# 25. Receipt design

The Receipt is a core trust artifact.

It should feel closer to an engineering certificate than a SaaS report.

Visual principles:

- Paper/Bone background,
- strict grid,
- mono metadata,
- clear verification area,
- high legibility,
- no marketing decoration.

Sections:

```text
Identity
Workload
Performance Profile
Provider
Usage
Cost
Quality
Verification
```

---

# 26. Performance Profile design

Canonical card:

```text
PERFORMANCE PROFILE

payments-review
v1.4.2

CONTEXT BUDGET
64k

READ STRATEGY
outline-first

REUSE
enabled

COMPRESSION
balanced

KIT
payments-security@2.1

QUALITY FLOOR
0.92

STATUS
approved
```

Profiles should feel version-controlled, not like consumer presets.

---

# 27. Icons

Icon style:

- geometric,
- monoline,
- system-like,
- grid constructed.

Use icons for:

- select,
- compress,
- reuse,
- recover,
- measure,
- verify,
- deploy.

Avoid:

- sparkles,
- magic wands,
- brains,
- robot heads,
- generic lightning bolts.

---

# 28. Photography

Photography is optional and should be rare.

Preferred:

- industrial environments,
- hardware,
- infrastructure,
- engineering desks,
- manufacturing detail,
- server environments,
- Swiss industrial context.

Treatment:

- neutral,
- high contrast,
- restrained.

Avoid:

- stock photos of people staring at dashboards,
- glowing AI brains,
- humanoid robots,
- blue holograms.

---

# 29. 3D and rendered imagery

3D may be used when it communicates architecture.

Good:

- exploded systems,
- stack layers,
- module assembly,
- context paths.

Bad:

- floating glass cubes,
- generic AI spheres,
- metallic chips used only to look futuristic.

The supplied hardware-style LeanCTX render is suitable as campaign/brand imagery, not as the core identity.

---

# 30. Exploded diagrams

Exploded diagrams are highly compatible with the brand.

They should show:

- system boundaries,
- layers,
- inputs/outputs,
- modularity,
- context path.

Thinkery:
- more architectural.

LeanCTX:
- more signal / execution / context-flow oriented.

---

# 31. Motion

Motion should communicate system behavior.

Preferred:

- context enters,
- irrelevant segments disappear,
- signal converges,
- selected state locks,
- metrics update,
- receipt verifies.

Motion style:

- controlled,
- precise,
- fast,
- restrained.

Avoid:

- bounce,
- liquid morphing,
- playful spring motion,
- glowing particle effects.

---

# 32. Hero motion concept

1. Multiple context inputs enter.
2. Streams pass through the LeanCTX boundary.
3. Unnecessary branches reduce.
4. Selected context exits.
5. Performance metrics update.
6. `VERIFIED` appears.

This tells the product story visually without metaphor.

---

# 33. Website system

## Hero

- Carbon background.
- Large clean headline.
- One meaningful performance visualization.
- Minimal CTA set.

No decorative collage.

## Product sections

Use:

- modular grid,
- real diagrams,
- real product screenshots,
- benchmark data.

## Benchmark section

Switch to Paper/Bone.

Make it feel like an engineering report.

## Enterprise section

Use more Thinkery-like architectural grids.

Show:

- agents,
- Profiles,
- evidence,
- policy.

Avoid abstract platform clouds.

---

# 34. Product UI

The UI should feel like engineering software.

Primary nouns:

- Benchmarks
- Runs
- Profiles
- Receipts
- Context
- Integrations

Avoid generic page names such as:

- Intelligence
- Insights
- Command Center

unless the content truly requires them.

---

# 35. Dashboard hierarchy

Primary metric:

> **Cost / successful task**

Secondary:

- input tokens,
- quality,
- latency,
- context reuse.

Do not lead with vanity counters such as total tokens saved if they are not tied to workload outcomes.

---

# 36. UI states

Canonical states:

```text
BASELINE
TUNED
VERIFIED
REGRESSED
FAILED
PENDING
```

Each state needs:

- text,
- icon,
- color,
- explicit meaning.

Never rely on color alone.

---

# 37. Thinkery applications

Thinkery can use:

- Paper/Bone surfaces,
- physical materials,
- architectural grids,
- industrial signage,
- emboss/deboss,
- black anodized / brushed-metal contexts.

Thinkery should look **built to endure**.

---

# 38. LeanCTX applications

LeanCTX can use:

- dark technical surfaces,
- benchmark panels,
- routing systems,
- CLI/terminal,
- Receipts,
- Profile cards,
- diagrams.

LeanCTX should look **built to execute**.

---

# 39. Social system

Use repeated formats rather than bespoke art every time.

## Benchmark card

```text
LEANCTX / PERFORMANCE RUN

BASELINE
139,115

LEANCTX
14,016

QUALITY
PASS / PASS

CALCULATED COST
-84.3%
```

## Thesis card

> Give every agent a context system.

with one small supporting system diagram.

## Product update card

```text
LEANCTX SDK / RELEASE

Context recovery
Available in vX.Y
```

Keep it factual.

---

# 40. Documentation

Docs should use:

- Paper/Bone reading surface,
- dark code blocks,
- precise diagrams,
- limited accent,
- strong information hierarchy.

Docs should feel like infrastructure documentation, not a marketing microsite.

---

# 41. GitHub

README header:

```text
LeanCTX
The Context SDK for AI Agents.

Give every agent a context system.
```

Then:

1. Install
2. First benchmark
3. Coding-agent integrations
4. SDK
5. Methodology

Do not lead with a wall of badges or vanity metrics.

---

# 42. Clear space

Use at least one core modular unit around either mark.

For LeanCTX, the central signal width can act as a practical reference unit.

No competing copy, border or icon should enter the clear-space zone.

---

# 43. Minimum size

Digital:

- compact mark: approximately 20–24px minimum,
- full lockup: test for legibility, generally >100px width.

Print:

- central signal and negative-space geometry must remain distinct.

Always test actual reproduction.

---

# 44. Logo misuse

Do not:

- stretch,
- rotate,
- add glow,
- add gradients,
- place inside arbitrary shapes,
- alter bracket angles,
- recolor individual pieces decoratively,
- apply chrome/3D treatment to the canonical logo.

Campaign art may interpret the mark but may never replace the core identity.

---

# 45. Background rules

Primary combinations:

### Carbon background
Paper/white logo.

### Paper/Bone background
Carbon logo.

### Photography
Use only monochrome logo with strong contrast.

Avoid noisy backgrounds.

---

# 46. Accessibility

All product and web use must meet accessible contrast standards.

Signal Orange should not be used for small body text on dark backgrounds without contrast testing.

Charts must not rely only on orange vs green.

Use:

- labels,
- patterns,
- line styles,
- text state names.

---

# 47. The performance-aesthetic guardrail

The biggest visual risk is turning performance into visual cosplay.

For every technical visual, ask:

> **Does this communicate real system behavior, or does it merely look technical?**

If it only looks technical, simplify it.

As the product matures, replace mock telemetry with real telemetry.

Technical authority comes from evidence.

---

# 48. Do / Don't

## DO

- use real metrics,
- use real Receipts,
- show baseline vs treatment,
- expose methodology,
- use restrained accents,
- use meaningful grids,
- use meaningful routing diagrams,
- use industrial materiality for Thinkery,
- use technical execution language for LeanCTX.

## DON'T

- use fake metrics,
- use glowing gradients,
- use racing imagery,
- use cars/turbos,
- use AI brains,
- use robot illustrations,
- use random circuit patterns,
- use decorative technical noise,
- overuse orange,
- create unnecessary subbrands.

---

# 49. Canonical visual system

## Thinkery

**Essence:** architectural control.

**Primary mode:** Paper / Carbon.

**Visual primitives:**

- mass,
- grid,
- negative space,
- structure,
- module,
- passage.

**Line:**

> **Systems for the context agents need to work.**

---

## LeanCTX

**Essence:** a context system for AI agents.

**Primary mode:** Carbon / Paper.

**Visual primitives:**

- brackets,
- signal,
- routing,
- compression,
- selection,
- benchmark,
- Receipt.

**Line:**

> **Give every agent a context system.**

---

# 50. Final design principle

The brand should not tell people LeanCTX is high-performance by looking aggressive.

It should make performance visible through:

- controlled geometry,
- precise data,
- real comparisons,
- verifiable evidence,
- disciplined typography,
- engineered restraint.

The visual authority comes from **measurement, not decoration**.
