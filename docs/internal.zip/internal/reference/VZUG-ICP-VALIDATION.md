# 12 — V-ZUG ICP Feedback: Strategic Impact on LeanCTX

**Status:** Canonical strategy update  
**Date:** 2026-08-20  
**Company:** Thinkery AG  
**Product:** LeanCTX  
**Primary thesis:** **The Context SDK for AI Agents.**  
**Primary promise:** **Tune any agent. Prove every gain.**

---

# 1. Executive conclusion

The V-ZUG feedback does **not** invalidate the LeanCTX strategy.

It sharpens it.

The important signal is not:

> “V-ZUG does not need LeanCTX.”

The important signal is:

> **A technically advanced enterprise AI team has already built its own internal context-efficiency harness because the problem is important enough to justify dedicated infrastructure.**

Fabian described an internal setup that already includes:

- dynamic context routing,
- evals and turn-outcome evaluation,
- TTL/cache measurement,
- LLMOps,
- optimization of internally operated MCP servers,
- context reduction at agent/client level,
- stripping context to the required minimum before it reaches the model,
- context reduction for both cost efficiency and context-poisoning risk.

This means the problem LeanCTX targets is not hypothetical.

A sophisticated enterprise is already solving it internally.

The strategic question is therefore no longer:

> **Can context optimization be valuable?**

V-ZUG has already answered that.

The new question is:

> **Should every company and every agent team have to build and maintain this context-performance infrastructure independently?**

LeanCTX should make the answer increasingly:

> **No.**

---

# 2. What V-ZUG has effectively built

Fabian's description can be reduced to:

```text
V-Assist / internal agents
        │
        ▼
V-ZUG INTERNAL HARNESS
        │
        ├── context routing
        ├── context reduction
        ├── cache / TTL logic
        ├── eval signals
        ├── tool optimization
        ├── MCP optimization
        └── cost / quality controls
        │
        ▼
Models / tools / infrastructure
```

The team did not merely optimize one prompt.

It created an **infrastructure layer around agent execution**.

That is close to the product category LeanCTX is now trying to standardize.

---

# 3. What LeanCTX becomes

```text
Any AI Agent
        │
        ├── Claude Code
        ├── Codex
        ├── Cursor
        ├── OpenAI Agents
        ├── Claude Agent SDK
        ├── LangGraph
        └── Custom Agent
        │
        ▼
LEANCTX — CONTEXT SDK
        │
        ├── context planning
        ├── selection
        ├── compression
        ├── reuse
        ├── recovery
        ├── measurement
        ├── Tuning Profiles
        ├── Context Kits
        └── evidence
        │
        ▼
Models / tools / data
```

The critical difference is:

> **LeanCTX should turn application-specific context engineering into a reusable system capability.**

That is stronger than “LeanCTX reduces tokens.”

---

# 4. Strategic reframing

The old sales story was often:

> LeanCTX can reduce unnecessary context and AI cost.

For less mature teams, that remains useful.

But an advanced team hears:

> “We already do that.”

The stronger story is:

> **You already optimize individual agents and tools. LeanCTX turns that work into a shared, reusable and measurable context-performance layer.**

Without LeanCTX:

```text
Agent A
 ├── custom routing
 ├── custom cache logic
 └── custom context rules

Agent B
 ├── custom routing
 ├── custom cache logic
 └── custom context rules

Agent C
 ├── custom routing
 ├── custom cache logic
 └── custom context rules
```

With LeanCTX:

```text
Agent A ─┐
Agent B ─┼── LeanCTX Context SDK
Agent C ─┘
             │
             ├── Profiles
             ├── Kits
             ├── Evidence
             ├── Dyno
             └── shared Runtime
```

This is the enterprise opportunity.

---

# 5. Category validation

The strongest interpretation of the feedback is:

> **A mature enterprise has already built a precursor to the product category internally.**

This is how infrastructure categories often emerge.

Sophisticated teams can build:
- auth,
- payments,
- observability,
- feature flags,
- search,
- data pipelines,
- experimentation systems.

Products still become valuable because teams should not need to keep building and maintaining the same infrastructure independently.

Core principle:

# **We do not win because customers cannot build LeanCTX.**
# **We win because they should not have to.**

---

# 6. New ICP model

“Companies using AI agents” is too broad.

LeanCTX should distinguish at least three maturity levels.

## ICP 1 — Agent teams without dedicated context infrastructure

They have:
- custom AI agents,
- coding agents,
- agentic workflows,
- real provider usage,
- growing cost,

but little dedicated context-performance infrastructure.

### Pain
- context grows unpredictably,
- repeated reads/tool output,
- expensive histories,
- opaque spend,
- no controlled baseline.

### Best offer
**Agent Tuning Sprint**

### Message
> We benchmark one agent, integrate LeanCTX, tune the context strategy and prove the result.

### Near-term attractiveness
**Highest.**

This is the best first-sales ICP.

---

## ICP 2 — Teams with fragmented optimization

They already have some:
- caching,
- evals,
- routing,
- context trimming,
- MCP optimization,

but logic is spread across applications.

### Pain
Optimizations are:
- application-specific,
- hard to compare,
- hard to version,
- hard to reuse,
- framework-coupled.

### Best offer
**LeanCTX SDK + Dyno + Tuning Profiles**

### Message
> Standardize context performance instead of rebuilding optimization logic inside every agent.

### Attractiveness
**Very high.**

This may become the strongest repeatable mid-market / enterprise motion.

---

## ICP 3 — Advanced internal-harness teams

V-ZUG is the clearest current example.

They already have:
- dedicated context harness,
- sophisticated evals,
- routing,
- cache policy,
- custom MCP optimization,
- context-minimization logic.

### Immediate pain is not
“we need token optimization.”

### Strategic pain may become
- internal maintenance,
- portability,
- provider/model changes,
- duplicated infrastructure across teams,
- benchmarking,
- versioning,
- organization-wide standards,
- evidence,
- continuous retuning.

### Best future offer
- SDK standardization,
- Dyno benchmark against internal harness,
- Tuning Profile infrastructure,
- Continuous AutoTune,
- enterprise context-performance control.

### Commercial attractiveness
Near-term: **lower**  
Long-term: **potentially extremely high**

These are build-vs-buy customers.

---

# 7. Two B2B sales motions

## Motion A — Tune my agent

### Target
ICP 1 and parts of ICP 2.

### Entry offer
**Agent Tuning Sprint**

### Customer question
> Can LeanCTX make this agent more efficient without degrading the accepted result?

### Proof
```text
stock
 ↓
baseline
 ↓
LeanCTX
 ↓
treatment
 ↓
quality gate
 ↓
receipt
```

### Economic story
> **Lower verified cost per successful agent task.**

### Role
Fastest cash.

---

## Motion B — Stop rebuilding context infrastructure

### Target
Advanced ICP 2 and ICP 3.

### Customer question
> Why are we maintaining context optimization separately inside every agent/application?

### Entry motion
- technical discovery,
- architecture comparison,
- Dyno benchmark,
- SDK evaluation.

### Economic story
Not only inference savings:

- less internal platform engineering,
- lower maintenance,
- portability,
- reusable Profiles,
- common methodology,
- continuous tuning,
- shared evidence.

### Role
Longer sales cycle, potentially much higher ACV.

---

# 8. Advanced teams are not disqualified

Under a compression-centric framing:

> “We already optimize context ourselves.”

sounds like a disqualifier.

Under the Context SDK strategy it is a **qualification signal**.

It means:

1. real agent workloads exist,
2. context is recognized as infrastructure,
3. the problem matters enough to build tooling,
4. build-vs-buy economics may eventually matter.

The correct response is not:

> “You still need our compressor.”

It is:

> **“You have already validated the problem. The question is whether this infrastructure should remain bespoke.”**


# 9. The “Fabian Test”

V-ZUG should become an internal product-quality test.

For any feature intended for advanced enterprises, ask:

> **Would Fabian simply say: “We already built this”?**

If yes, LeanCTX needs a second question:

### Is the LeanCTX version:

- easier to integrate?
- portable across agent frameworks?
- portable across providers?
- versioned?
- reproducible?
- independently benchmarked?
- easier to maintain?
- continuously tunable?
- evidence-linked?
- reusable across teams?

If the answer is no to all of these:

> **The feature is not differentiated enough.**

---

# 10. What LeanCTX must eventually provide beyond a bespoke harness

A strong internal harness can be excellent.

LeanCTX must win by becoming a **specialized reusable product**, not merely by replicating it.

## 10.1 Portability

The same conceptual tuning system should work across:

```text
Claude Code
Codex
Cursor
Custom Agents
OpenAI Agents
Claude Agent SDK
LangGraph
```

Not identically, but through the same:
- Runtime,
- Profile model,
- evidence model,
- benchmark model.

---

## 10.2 Versioned performance

Context behavior should be deployable as:

```text
payments-agent
Tuning Profile v4.2
```

instead of undocumented conditionals spread across agent code.

Versioning creates:
- review,
- rollback,
- reproducibility,
- comparison,
- auditability.

---

## 10.3 Dyno

Advanced teams should be able to compare:

```text
Stock
vs
Internal Harness
vs
LeanCTX Profile A
vs
LeanCTX Profile B
```

using:
- the same workload,
- the same model/provider,
- the same quality gates.

This converts architecture opinion into evidence.

---

## 10.4 Evidence

Every tuning decision can be tied to:

- task,
- profile,
- provider,
- model,
- provider usage,
- calculated cost,
- quality,
- outcome,
- receipt.

This is stronger than informal “our harness is optimized.”

---

## 10.5 Continuous tuning

Models, pricing, caching and agent behavior change.

An internal harness may need manual retuning.

LeanCTX’s long-term answer:

```text
workload
 ↓
Dyno
 ↓
AutoTune
 ↓
new Profile
 ↓
quality validation
 ↓
deploy
```

If executed well, this is a major product advantage.

---

## 10.6 Maintenance economics

The enterprise question becomes:

> **Should context-performance engineering remain an internal infrastructure product forever?**

That is the long-term build-vs-buy case.

---

# 11. Why the SDK framing becomes stronger

Fabian’s feedback strengthens the SDK framing.

An SDK is exactly how a specialized infrastructure capability becomes reusable across agents.

The value proposition becomes:

> **Instead of embedding a custom context harness in every application, integrate the LeanCTX Context SDK.**

This is much easier to understand than:
- Context OS,
- Context Control Plane,
- AI infrastructure fabric.

And it is closer to something companies can evaluate today.

---

# 12. LeanCTX must still not become a generic Agent SDK

The V-ZUG feedback does **not** justify broadening scope.

LeanCTX owns:

```text
context planning
selection
compression
reuse
recovery
Profiles
Kits
measurement
evidence
```

LeanCTX does not need to own:

```text
generic agent loops
business workflows
CRM
voice
browser automation
generic tool orchestration
```

The more mature the buyer, the more important this specialization becomes.

---

# 13. Internal harnesses can become capabilities later

A powerful future architecture is:

```text
LeanCTX Tuning Layer
       │
       ├── LeanCTX native optimizer
       ├── customer internal optimizer
       ├── provider-native optimizer
       └── third-party optimizer
```

Then LeanCTX owns:

- benchmarking,
- Profiles,
- quality evaluation,
- evidence,
- selection,
- lifecycle.

A customer’s existing harness becomes one capability.

Strategically, this changes the competitive game.

LeanCTX no longer has to beat every specialized optimizer in every workload.

It needs to answer:

> **Which strategy produces the best accepted outcome for this workload?**

---

# 14. Do not build the optimizer-provider interface yet

This is future architecture.

It is **not** a current roadmap priority.

The V-ZUG conversation must not create another side quest.

Current focus remains:

1. Real Dyno
2. Quality gate
3. Canonical receipt/evidence
4. Reference custom agent
5. Attach vs Embed benchmark
6. Tuning Profile
7. Paid customer

Only after those are real should external/customer optimizer interfaces become active work.

---

# 15. V-ZUG as a future benchmark partner

V-ZUG is currently a weak basic pilot target.

But it could become an unusually valuable future benchmark partner.

Conceptual experiment:

```text
REAL V-ZUG WORKLOAD

ARM A
Stock

ARM B
V-ZUG internal harness

ARM C
LeanCTX Attach

ARM D
LeanCTX Embed
```

Measure:

- provider usage,
- cost,
- quality,
- latency,
- context volume,
- tool calls,
- integration effort,
- portability,
- maintenance requirements.

Every result is useful.

### If V-ZUG wins
LeanCTX learns from a strong internal reference.

### If LeanCTX wins
That becomes powerful enterprise evidence.

### If both are similar
LeanCTX must win on:
- standardization,
- maintenance,
- portability,
- evidence,
- continuous tuning.

---

# 16. V-ZUG’s role in the ICP portfolio

| Dimension | V-ZUG fit |
|---|---|
| Immediate free savings pilot | Low |
| Immediate paid Tuning Sprint | Low–medium |
| Product discovery | Extremely high |
| SDK design reference | Very high |
| Advanced enterprise ICP | Very high |
| Build-vs-buy case | Potentially very high |
| Technical design partner | Very high |
| Short-term revenue | Low |
| Future lighthouse potential | High |

Decision:

> **Do not chase V-ZUG for immediate revenue. Learn from them and revisit when LeanCTX can challenge an internal harness on its own terms.**

---

# 17. Outreach impact

The existing outreach message:

> LeanCTX reduces unnecessary processing and context cost.

remains suitable for ICP 1.

It is too weak for advanced teams.

## Message for less mature teams

> Give us one existing AI agent. We measure its current cost, integrate LeanCTX and verify whether the same workload can be completed with less context and equivalent quality.

## Message for advanced teams

> **LeanCTX is turning context optimization from application-specific engineering into a reusable SDK layer for AI agents.**

Supporting explanation:

> Instead of implementing routing, compression, reuse and measurement separately in every agent, LeanCTX provides a common Context Runtime with benchmarkable, versioned Tuning Profiles.

That is the correct level for a team that already understands context infrastructure.

---

# 18. Website impact

The primary website remains:

# **The Context SDK for AI Agents.**

and:

# **Don’t replace your agent. Tune it.**

V-ZUG adds a future advanced-team section.

## Proposed section

### **Already built your own context layer? Good.**

> LeanCTX is designed for teams that have moved beyond one-off prompt optimization.

> Bring your existing context strategy, routing logic or internal harness to the Dyno. Benchmark it against versioned LeanCTX Profiles and keep the winning approach.

Conceptual visual:

```text
YOUR HARNESS ─────┐
                  │
LEANCTX PROFILE ──┼── DYNO ── COST / QUALITY / EVIDENCE
                  │
NATIVE STRATEGY ──┘
```

CTA:

> **Benchmark my context layer**

This should only become public when the Dyno genuinely supports the comparison.

---

# 19. Product strategy impact

The feedback strengthens:

- Context SDK positioning,
- Dyno as central product,
- Tuning Profiles,
- quality + economics together,
- provider/framework neutrality,
- Attach / Wrap / Embed,
- AutoTune as future paid intelligence.

It makes these more important:

- build-vs-buy economics,
- standardization,
- maintenance,
- portability,
- reproducibility.

It makes this less strategically central:

- winning a raw compression-percentage race.

---

# 20. Monetization impact

The feedback reveals two distinct willingness-to-pay drivers.

## Lower-maturity customer pays for

> **better agent economics**

Metric:
> cost per successful task

Entry:
> Agent Tuning Sprint

## Advanced customer eventually pays for

> **replacing internal context-platform maintenance with standardized infrastructure**

Value drivers:

- fewer internal platform-engineering hours,
- faster new-agent integration,
- common Profiles,
- consistent measurement,
- less duplicated tooling,
- continuous tuning,
- cross-framework portability,
- enterprise support.

This can support larger recurring contracts than pure token-savings economics.

---

# 21. Enterprise pricing implication

Do not price advanced enterprise only on tokens saved.

Potential value equation:

```text
Inference savings
+
engineering time avoided
+
faster agent rollout
+
lower maintenance
+
fewer performance regressions
+
standardized evidence/governance
```

That supports a stronger recurring platform model.

---

# 22. Competitive impact

The future positioning should not be:

> “LeanCTX has the best compressor.”

It should be:

> **LeanCTX is the system for measuring, tuning, versioning and operating context strategies across agents.**

Then:
- internal harnesses,
- provider compaction,
- third-party optimizers,
- LeanCTX native optimizers,

can all become inputs into the same performance system.

That is a stronger abstraction layer.

---

# 23. Strategic moat after V-ZUG

The moat becomes:

```text
SDK distribution
+
integration depth
+
Dyno methodology
+
Tuning Profiles
+
quality-aware evidence
+
AutoTune
+
cross-agent portability
+
organization performance history
```

Not:

```text
one compression algorithm
```

---

# 24. What V-ZUG does NOT change

The feedback does **not** justify:

- building a generic Control Plane immediately,
- implementing every LLMOps feature Fabian mentioned,
- copying V-ZUG’s cache strategy,
- building a full agent scheduler,
- finishing the entire Enterprise dashboard,
- building a marketplace,
- adding twenty integrations,
- changing the brand again.

The immediate plan remains focused.

---

# 25. Updated priority order

```text
P0  Real Dyno
P0  Quality gate
P0  Canonical receipt / evidence
P0  Reference custom agent
P0  Integration Depth Benchmark

P1  TuningProfileV1
P1  Claude Code / Codex / Cursor first-class integration
P1  Paid Agent Tuning Sprint

P2  ContextKitV1
P2  Playground
P2  Pro / Team

P3  AutoTune
P3  Advanced build-vs-buy enterprise motion

P4  External/customer optimizer capability interface
```

V-ZUG does not move P4 into P0.

---

# 26. The new advanced-enterprise discovery question

Do not lead with:

> Do you have AI-agent cost problems?

Ask:

> **Where does your context-performance logic live today?**

Follow-ups:

- inside each agent?
- inside MCP servers?
- inside a shared harness?
- in a model gateway?
- who owns it?
- how is it benchmarked?
- how is it versioned?
- how is quality validated?
- how much maintenance does it create?
- what happens when the model/provider changes?
- can another agent team reuse the same strategy?

These questions reveal the actual architecture and buying opportunity.

---

# 27. Product discovery questions for V-ZUG-like teams

1. How many agents use the harness?
2. Is context logic centralized or duplicated?
3. How does a new agent integrate it?
4. How many engineers maintain it?
5. How often does it change?
6. How do they evaluate a new optimization?
7. Do they replay the same workload?
8. Is context strategy versioned?
9. Can they roll back?
10. How do they compare model/provider changes?
11. How do they attribute savings?
12. How do they prevent quality regressions?
13. Can one team’s optimization be reused elsewhere?
14. What parts would they never buy externally?
15. What would make them replace or augment the harness?

The objective is to learn, not to convince them they have a problem.

---

# 28. Updated category thesis

V-ZUG strengthens this thesis:

> **Every serious agent system eventually develops a context strategy.**

At low maturity it is implicit.

At medium maturity it becomes a collection of application-level optimizations.

At high maturity it becomes an internal harness.

LeanCTX’s opportunity is to standardize that evolution:

```text
Implicit context behavior
        ↓
manual optimization
        ↓
internal harness
        ↓
standardized Context SDK
        ↓
continuous tuning infrastructure
```

---

# 29. Updated long-term vision

> **LeanCTX should become the performance layer companies use instead of rebuilding context infrastructure inside every AI agent.**

The developer connects or embeds LeanCTX.

LeanCTX provides:

- context planning,
- selection,
- compression,
- reuse,
- recovery,
- Profiles,
- Kits,
- measurement,
- evidence.

Thinkery provides:

- continuous AutoTune,
- private Profiles/Kits,
- shared evidence,
- organization economics,
- policy,
- enterprise operation.

The result:

> **Context performance becomes infrastructure, not application-specific craftsmanship.**

---

# 30. Final strategic conclusion

The V-ZUG conversation is a positive strategic signal.

It tells us three things.

## First

The problem is real enough that an advanced enterprise built dedicated infrastructure for it.

## Second

“Token savings” is too weak as the whole company story.

Sophisticated teams can already build local optimizations.

## Third

The strongest LeanCTX opportunity is standardization:

> **A reusable Context SDK, benchmarked through Dyno, deployed through versioned Profiles and continuously improved through evidence.**

The goal is not to convince V-ZUG today that its harness is bad.

The goal is to build LeanCTX until a team like V-ZUG eventually asks:

> **Why are we still maintaining this ourselves?**

That is the advanced-enterprise endgame.

---

# 31. Frozen strategic update

V-ZUG changes **interpretation**, not immediate focus.

### Strategy strengthened
**The Context SDK for AI Agents.**

### Commercial model expanded
Two motions:
1. **Tune my agent.**
2. **Stop rebuilding context infrastructure.**

### Advanced ICP added
Internal-harness teams.

### Moat clarified
Dyno + Profiles + Evidence + AutoTune + portability.

### Roadmap unchanged
Build the next proof before the next layer.

### Immediate objective unchanged

> **Get a real external customer to pay for a verified tuning outcome.**

Everything else remains subordinate to that.
