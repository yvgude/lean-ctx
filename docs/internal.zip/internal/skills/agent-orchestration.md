---
name: agent-orchestration
description: Mandatory multi-agent delivery for substantive lean-ctx tasks; orchestrate parallel Codex CLI and Claude Code CLI sub-agents, and improve the local lean-ctx agent bus when coordination quality or context efficiency requires it. Default Codex agents use GPT-5.6 Luna with max reasoning.
---

# Agent Orchestration Skill

Orchestrate parallel CLI sub-agents (Codex and/or Claude Code) for research,
refactoring, analysis, and design review.

## Mandatory activation

`AGENTS.md` makes this skill mandatory for every substantive task in this
repository. Load it before planning or acting, including when the user does not
explicitly mention agents.

The orchestration lead owns this activation. A concrete delegated subtask makes
the receiving agent a swarm worker: it registers with lean-ctx, follows its
assigned role, and MUST NOT recursively spawn another swarm unless the lead
explicitly asks it to do so.

Use the smallest effective swarm of **2 to 15** independent roles; 15 is a hard
concurrent maximum. The default topology is one implementer plus mapper, tester,
and reviewer roles. For changes that cannot safely be parallelized, reviewers
validate the completed change instead of editing concurrently. Only one agent
owns a file or shared worktree at a time; use separate worktrees when concurrent
implementation is justified.

Every agent registers on the lean-ctx agent bus, checks directives, and uses
lean-ctx context tools. The lead gathers agent evidence through lean-ctx,
reconciles conflicts, records the integrated decision and progress, then runs
the relevant quality gate before declaring completion.

## Premium agent-bus collaboration

Improving the local lean-ctx agent bus is explicitly allowed when it materially
improves agent-to-agent communication, shared context, ownership safety, or
delivery efficiency. Such work is first-class vision implementation, not an
out-of-scope detour. Keep the bus Research/local-only unless a separate product
gate promotes a public contract; do not turn it into a scheduler, hosted
coordination service, or generic agent platform.

Optimize for the **minimum total context needed to deliver accepted work**,
not merely the shortest individual message. Preserve correctness, provenance,
security, and recovery while making coordination maximally token-efficient:

- share distilled decisions, findings, blockers, evidence, task state and
  source references instead of transcripts or repeated raw output;
- prefer content-addressed references, stable IDs, deltas and targeted pull
  over rebroadcasting unchanged context;
- scope every message by project, task, recipient, privacy and freshness;
- use leases/claims before edits, explicit acknowledgements for critical
  directives, and idempotent handoffs with delivery versus acceptance state;
- deduplicate shared facts and let agents recover exact source through lean-ctx
  references when detail is needed;
- keep outputs deterministic and bounded; avoid timestamps, counters or random
  text in cacheable tool bodies;
- measure end-to-end context traffic, rediscovery, conflicts, blocked time and
  accepted outcomes before calling a bus change better.

Dogfood bus improvements in the active swarm. Add the smallest versioned
contract that removes an observed coordination bottleneck, cover failure,
privacy, replay and stale-state paths, preserve compatibility, then record the
decision and evidence through lean-ctx. The lead remains responsible for
integration and for preventing the bus from becoming a second source of truth.

Direct answers, status updates, and clarification questions are exempt. A user
may explicitly request a different runtime or a single-agent exception.

## When to use

- Large multi-agent research rounds
- Parallel codebase analysis
- Multi-file refactoring with isolated agents
- Visual / copy / a11y design review of a live site
- User says "agents starten", "codex agents", "claude agents", "fable",
  "Runde", "nächste Phase"
- Any substantive task in this repository (mandatory by `AGENTS.md`)

## Runtime selection

| User asks for | Runtime | Binary |
|---|---|---|
| (default) / "codex" / "agents starten" | Codex CLI — GPT-5.6 Luna, reasoning `max` | `codex` |
| "claude" / "claude agents" | Claude Code CLI | `claude` |
| "fable" / design review / architecture review | Claude Code CLI + Fable 5 | `claude --model claude-fable-5` |

Mix runtimes in one round when useful (e.g. Codex implementers + Claude Fable reviewer).

## Shared spawn rules (BOTH runtimes)

Each agent gets its **own** Cursor Shell call with `block_until_ms: 0`.

In this repo, native Shell is denied (lean-ctx replace mode). Use
`ctx_shell` with `run_in_background: true` and `timeout_ms: 600000` instead.
Same command string either way.

1. **Never `LEAN_CTX_DISABLED=1`** — compression + savings ledger must stay on
2. **Codex: always `</dev/null 2>&1`**. Claude: `< prompt.md 2>&1` **or** a non-empty argument plus `</dev/null 2>&1`. Never both empty.
3. **NEVER use `&` in the command** — Cursor/`ctx_shell` backgrounds the process
4. **One Shell call per agent** — no `for i in ...` loops
5. **Reports to `/tmp/<project>/`** — never rely on the agent printing only
6. **Wait 2–5 minutes** — real work is not 5 seconds
7. **Do not use `--bare`** (Claude) — it strips lean-ctx hooks

### CRITICAL: No `&` in Command

`&` inside the command backgrounds the CLI as a subprocess. When the parent
shell exits (after echo), it kills the job in ~5s.

Use Cursor `block_until_ms: 0` or `ctx_shell(run_in_background=true)`.

### CRITICAL: stdin

**Codex** waits on stdin unless closed → always `</dev/null`.

**Claude `-p`** takes the prompt from stdin **or** a positional argument:
- Preferred: `< /tmp/<project>/prompt-N.md 2>&1` (do not add `</dev/null`)
- Inline: `"prompt" </dev/null 2>&1`
- Broken: empty argument + `</dev/null` → `Input must be provided… --print`

### Verifying Agent Success

- Terminal/`ctx_shell` header `elapsed_ms` must be **>30s** for real work
- `elapsed_ms < 10000` → silent failure (sandbox, stdin, `&`, missing model)
- Confirm the report file exists and is non-empty

### Common Failure Modes

| Symptom | Cause | Fix |
|---|---|---|
| Exit ~5s, code 0 | `&` in command | Remove `&`, background via Cursor/`ctx_shell` |
| Exit ~5s, code 0 | stdin not closed | Add `</dev/null` |
| Empty report | could not write | Use `/tmp/<project>/` |
| "Reading additional input from stdin..." | stdin not redirected | **Always** `</dev/null` |
| `LEAN_CTX_DISABLED=1` | disables compression | Remove it |
| Claude exits immediately, no tools | `--bare` used | Remove `--bare` |
| Claude asks for permission and hangs | missing skip flag | Add `--dangerously-skip-permissions` |
| `Input must be provided… --print` | empty prompt + `</dev/null` | Feed `< prompt.md` **or** a non-empty argument |
| `monthly spend limit` / switch model | Fable (or current model) capped | Retry **without** `--model` (settings default) |
| `session limit · resets …` | Claude Code session quota | Wait for reset window; do not respawn the same model |
| Path jail / extra repo | cwd outside project | `cd` into the target repo; Claude: `--add-dir` |

## Codex CLI

lean-ctx is already wired (`~/.codex/hooks.json`, `lean-ctx init --agent codex`).

```bash
cd /path/to/project && codex exec --approve-for-me \
  --model gpt-5.6-luna \
  -c 'model_reasoning_effort="max"' "
<prompt here>
" </dev/null 2>&1
```

Codex-only rules:

1. **Always `--approve-for-me`**
2. **Always `--model gpt-5.6-luna -c 'model_reasoning_effort="max"'`** — do not
   rely on a configured default or substitute a different model/effort
3. Never `codex exec ... &`

## Claude Code CLI

lean-ctx is already wired (`~/.claude/settings.json` hooks,
`lean-ctx init --agent claude`). Binary: `~/.local/bin/claude`.

**Preferred (avoids quoting):** write the prompt to a file, feed it on stdin.
Do **not** also use `</dev/null` — that empties the prompt and Claude exits with
`Input must be provided either through stdin or as a prompt argument`.

```bash
cd /path/to/project && claude -p --dangerously-skip-permissions \
  --output-format text \
  --model claude-fable-5 \
  < /tmp/<project>/prompt-N.md 2>&1
```

Fallback (inline prompt). Then stdin MUST be closed:

```bash
cd /path/to/project && claude -p --dangerously-skip-permissions \
  --output-format text \
  --model claude-fable-5 \
  "You are Agent N. … Write report to /tmp/<project>/agent-N.md" \
  </dev/null 2>&1
```

Never combine an empty/missing prompt argument with `</dev/null`.
Never use `"$(cat prompt.md)" </dev/null` — if `cat` is jailed/empty, Claude
exits immediately with no work done.

Claude-only rules:

1. **Always `-p` / `--print`** — non-interactive, like `codex exec`
2. **Always `--dangerously-skip-permissions`** — Claude equivalent of `--approve-for-me`
3. **Default: omit `--model`** — uses `~/.claude/settings.json`
4. **Fable when asked** (or design / architecture review):
   `--model claude-fable-5`. If Claude reports a monthly spend limit, retry
   the same command **without** `--model` (uses `~/.claude/settings.json`)
   and tell the user Fable was capped.
5. Extra repo or docs outside cwd: `--add-dir /abs/path`
6. **Never `--bare`** — skips hooks, LSP, lean-ctx
7. Do **not** combine `claude --bg` with Cursor backgrounding. Prefer `-p`
   so the shell stays the primary process and elapsed_ms is meaningful
8. Do **not** pass `--chrome` unless the user asked for a live browser pass
   and Chrome is already running — it can hang headless shells
9. **Prompt on stdin `< file` XOR `</dev/null` with a non-empty argument — never both empty**

Optional: `--output-format text` keeps terminal files readable.

### Claude extra-root example

Website in a sibling repo:

```bash
cd /path/to/leanctx-website && \
claude -p --dangerously-skip-permissions --output-format text \
  --model claude-fable-5 \
  --add-dir /path/to/lean-ctx/docs/internal \
  --add-dir /tmp/leanctx-website \
  < /tmp/leanctx-website/design-review/prompt-01-visual.md 2>&1
```

## Agent Naming Convention

- `Agent N: <short description>` for research / review
- `R<round>-Agent-<N>: <task>` for refactoring rounds
- Prefix `Claude-` / `Fable-` / `Codex-` when mixing runtimes

## Monitoring Pattern

```bash
# Cursor terminals
for id in $SHELL_IDS; do
  f="$TERMINALS_DIR/${id}.txt"
  elapsed=$(head -10 "$f" | grep elapsed_ms | awk '{print $2}')
  status=$(head -10 "$f" | grep status | awk '{print $2}')
  echo "Agent $id: $status (${elapsed}ms)"
done

# lean-ctx background jobs
# ctx_shell background_action=status job_id=<id>
```

Confirm each `/tmp/<project>/…md` report exists before synthesizing.

## Example: 5 Codex research agents

5 parallel Shell calls (`block_until_ms: 0` or `ctx_shell` background):

```bash
cd /path/to/project && codex exec --approve-for-me \
  --model gpt-5.6-luna \
  -c 'model_reasoning_effort="max"' "
You are Agent N. Research topic: <topic>
Write your report to /tmp/research/agent-N.md
" </dev/null 2>&1
```

## Example: 4 Claude Fable design-review agents

```bash
mkdir -p /tmp/leanctx-website/design-review
```

Then 4 parallel Claude calls (one per agent), cwd = website repo, Fable model,
each `< /tmp/leanctx-website/design-review/prompt-0N-….md`, reports beside the
prompts. Do NOT loop.
