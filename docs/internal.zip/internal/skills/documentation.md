---
name: documentation
description: >-
  Place documentation in the correct location within the lean-ctx docs structure.
  Use when creating, moving, or organizing any .md or .json documentation file,
  when asking "where does this doc go?", or when the user mentions docs, documentation,
  writing specs, contracts, guides, ADRs, runbooks, or vision documents.
---

# Documentation Placement

## Directory Map

```
docs/
├── reference/         → User-facing OSS documentation (how to USE lean-ctx)
├── guides/            → Integration guides per tool/IDE
├── contracts/         → Wire protocol specs (.md) + JSON schemas (.json)
├── adrs/              → Architecture Decision Records
├── runbooks/          → Operational procedures (deploy, incident, upgrade)
├── internal/          → CONFIDENTIAL (gitignored, never on GitHub)
│   └── vision/        → Strategy, roadmap, business model, vision
└── archive/           → Deprecated docs (gitignored, read-only reference)
```

## Decision Tree: Where Does It Go?

```
Is it about HOW TO USE lean-ctx?
├── Yes → Is it specific to one IDE/tool?
│   ├── Yes → docs/guides/{tool}.md
│   └── No → docs/reference/{topic}.md
└── No → Is it a technical interface contract?
    ├── Yes → docs/contracts/{name}-v{N}.md (+ .schema.json if machine-readable)
    └── No → Is it an architecture decision?
        ├── Yes → docs/adrs/ADR-{NNN}-{slug}.md
        └── No → Is it an operational procedure?
            ├── Yes → docs/runbooks/{name}.md
            └── No → Is it internal strategy/vision/business?
                ├── Yes → docs/internal/vision/{NN}-{NAME}.md
                └── No → Does it belong to an old feature we paused?
                    ├── Yes → docs/archive/{category}/
                    └── No → ASK before creating. Probably doesn't need a doc.
```

## Rules Per Directory

### `docs/reference/` — User Documentation

- **Audience:** OSS users, developers integrating lean-ctx
- **Language:** English
- **Naming:** `{NN}-{topic}.md` (numbered for reading order) or `appendix-{topic}.md`
- **Content:** CLI commands, config keys, MCP tool reference, troubleshooting
- **Goes on GitHub:** YES (public)

### `docs/guides/` — Integration Guides

- **Audience:** Developers using lean-ctx with specific tools
- **Language:** English
- **Naming:** `{tool-name}.md` (e.g. `cursor.md`, `claude-code.md`, `codex-cli.md`)
- **Content:** Setup steps, configuration, tips for that specific tool
- **Goes on GitHub:** YES (public)

### `docs/contracts/` — Wire Protocol Specs

- **Audience:** Developers building on lean-ctx APIs/protocols
- **Language:** English
- **Naming:** `{name}-v{N}.md` + optional `{name}-v{N}.schema.json`
- **Content:** Request/response formats, versioning rules, compatibility guarantees
- **Rule:** Only keep contracts that are ACTIVELY referenced in Rust code
- **Rule:** Aspirational/future contracts → `docs/archive/contracts/`
- **Goes on GitHub:** YES (public, part of the open protocol)

### `docs/adrs/` — Architecture Decision Records

- **Audience:** Contributors, future self
- **Language:** English
- **Naming:** `ADR-{NNN}-{slug}.md` (e.g. `ADR-014-open-runtime-invariant.md`)
- **Content:** Context, Decision, Consequences (standard ADR format)
- **Goes on GitHub:** YES (public)

### `docs/runbooks/` — Operational Docs

- **Audience:** Operators, maintainers
- **Language:** English
- **Naming:** `{procedure}.md`
- **Content:** Step-by-step procedures for deploy, incident response, upgrades
- **Goes on GitHub:** YES (public)

### `docs/internal/vision/` — Strategy & Vision

- **Audience:** Founders, advisors (CONFIDENTIAL)
- **Language:** Deutsch (explanations), English (technical terms)
- **Naming:** `{NN}-{NAME}.md` (numbered, ALL-CAPS name)
- **Content:** Market analysis, roadmap, business model, competitive strategy
- **Goes on GitHub:** NEVER (gitignored via `docs/internal/`)
- **Rule:** Max 19 documents. Replace, don't accumulate.

### `docs/archive/` — Deprecated

- **Content:** Everything that was once relevant but is now superseded
- **Goes on GitHub:** NEVER (gitignored)
- **Rule:** Never delete old docs — move them here
- **Rule:** Never reference archived docs from active docs

## Anti-Patterns (NEVER do)

1. **Never create new top-level folders** in `docs/` without updating this skill
2. **Never put confidential/business docs** outside `docs/internal/`
3. **Never accumulate** — if a doc is superseded, move the old one to archive FIRST
4. **Never create a doc without checking** if one already exists on that topic
5. **Never put generated content** (auto-docs) outside `docs/reference/generated/`
6. **Never exceed 19 vision docs** — consolidate or replace existing ones

## Naming Conventions

| Directory | Pattern | Example |
|-----------|---------|---------|
| reference | `{NN}-{topic}.md` | `08-multi-agent.md` |
| guides | `{tool}.md` | `cursor.md` |
| contracts | `{name}-v{N}.md` | `a2a-contract-v1.md` |
| adrs | `ADR-{NNN}-{slug}.md` | `ADR-012-task-identity.md` |
| runbooks | `{procedure}.md` | `shadow-pilot-runbook.md` |
| vision | `{NN}-{NAME}.md` | `04-PRODUCT-ROADMAP.md` |

## Git Visibility

| Directory | On GitHub | On GitLab | Reason |
|-----------|-----------|-----------|--------|
| reference | Yes | Yes | Public OSS docs |
| guides | Yes | Yes | Public OSS docs |
| contracts | Yes | Yes | Open protocol |
| adrs | Yes | Yes | Transparency |
| runbooks | Yes | Yes | Community ops |
| internal/ | No | No | Confidential strategy |
| archive/ | No | No | Noise reduction |
