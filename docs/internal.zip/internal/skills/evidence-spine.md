---
name: evidence-spine
description: "Implement or evolve ExecutionReceiptV1, execution receipts, task evidence, evidence linkage, ETPAO calculation, savings ledger, decision ledger, baseline/counterfactual rules, holdouts, signing, and verification. Use for execution receipt, evidence, ETPAO calculation, savings ledger, decision ledger, cost per accepted outcome, baseline, counterfactual, or signed receipt work."
---

# Evidence spine implementation

Make each task economically and operationally reconstructable. Preserve facts and label estimates; do not turn local estimates into verified commercial claims.

## Gather

1. Read `docs/internal/vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md` P2,
   then `docs/internal/execution/PROOF-DOCTRINE.md` and
   `docs/internal/reference/RECEIPT-EVIDENCE.md`.
2. Inspect current evidence substrate:
   - `rust/src/core/context_kernel/types.rs`, `mcp_receipt.rs`, and `receipt_chain.rs`.
   - `rust/src/core/etpao.rs` and `rust/src/core/context_kernel/etpao.rs`.
   - `rust/src/core/evidence_ledger.rs` and `rust/src/core/savings_ledger/`.
   - `rust/src/core/ocla/unified_ledger.rs` and `rust/src/core/ocla/tracing.rs`.
   - `rust/src/proxy/counterfactual.rs`, `holdout.rs`, `usage_accounting.rs`, and `cost.rs`.
   - `rust/src/core/context_kernel/outcome_signal.rs`.
3. Run `ctx_compose` and `ctx_impact`. Identify the authoritative source for each field; never double-count projections of one event.

## Act

### Define ExecutionReceiptV1

Use:

- `docs/contracts/execution-receipt-v1.schema.json` as normative schema.
- `docs/contracts/execution-receipt-v1.md` for baseline, authority, and verification semantics.
- `rust/src/core/execution_receipt.rs` for Rust projection, canonicalization, and validation.
- `rust/src/core/contracts.rs` and `CONTRACTS.md` for registration.

Include bounded, payload-free fields for receipt/task/plan/trace IDs; parent receipt; decision/policy/capability refs; model/provider; token balances; fresh/cached/output/reasoning usage; actual billed cost and source; baseline ref/method/version; latency/retries; outcome ref/status; evidence refs; chain predecessor; signer/key/signature. Represent money as integer micro-units plus ISO currency.

### Link the spine

Maintain this invariant:

```text
TaskEnvelopeV1 -> ExecutionPlanV1 -> ExecutionReceiptV1 -> AcceptedOutcomeV1
       |                 |                    |
       +---------- decision/evidence refs ----+
```

- Every receipt has exactly one `task_id` and executed `plan_id`.
- Every decision/policy/capability invocation emits an immutable ref used by the receipt.
- Outcome may arrive later; append/link it without rewriting signed historical facts.
- Use idempotency keys so retries cannot create duplicate economic events.

### Calculate ETPAO

Follow `rust/src/core/etpao.rs`:

```text
weighted_tokens = fresh
  + cached * cached_rate/fresh_rate
  + output * output_rate/fresh_rate
  + reasoning * reasoning_rate/fresh_rate
ETPAO = sum(weighted_tokens) / accepted_outcomes
delta_pct = (leanctx_ETPAO - baseline_ETPAO) / baseline_ETPAO * 100
```

Return infinity/undefined when accepted outcomes are zero. Store raw components, pricing source/version, and formula version so results can be recomputed. Do not present raw compression ratio as ETPAO.

### Enforce baseline and signing rules

- Prefer an actual requested/control execution under equivalent task, policy, and quality constraints.
- Use deterministic assignment from `proxy/holdout.rs`; prevent treatment contamination.
- A counterfactual is eligible only when method, inputs, model/provider assumptions, prices, and uncertainty are preserved. Label estimates explicitly.
- Reject imaginary or post-hoc cherry-picked baselines and comparisons with material accepted-outcome degradation.
- Reuse Ed25519 identity and canonical signing patterns from `core/agent_identity.rs` and `core/savings_ledger/signed_batch.rs`.
- Verify schema, canonical bytes, signature, signer, hash chain, referenced evidence, and recomputed totals.
- Preserve ADR-010: signed local observations remain observed/estimated, never `VerifiedSavingsV1` or billable results.

## Verify

- Add golden receipts and tamper vectors under `rust/tests/fixtures/`.
- Test task-plan-receipt-outcome joins, late outcomes, retries/idempotency, actual cost ingestion, baseline eligibility, zero accepted outcomes, and recomputation.
- Test signature/key/hash-chain failure and missing evidence refs.
- Extend `rust/tests/savings_verification.rs`, `evidence_bundle_e2e.rs`, `outcome_pricing_e2e.rs`, and `suite/etpao_benchmark_suite.rs`.
- Prove one repeatable workflow yields actual versus defensible baseline ETPAO/cost with no material accepted-outcome degradation.
- Run impacted tests and the Rust quality gate.
