---
name: focus-contract
description: Enforces Thinkery / LeanCTX product focus, canonical messaging, product-honesty labels, competitive discipline, and verification-first claims in agent work and conversations.
---

# Focus Contract — Thinkery / LeanCTX

## Purpose

Keep every agent conversation, artifact, proposal, and implementation aligned
to the approved Thinkery / LeanCTX narrative. This contract governs external
language and the decisions that produce it.

## Canonical message stack

Use the hierarchy in this order. Do not substitute near-synonyms or reorder it
when presenting the company or product.

1. **Thinkery:** Systems for the context agents need to work.
2. **LeanCTX:** The Context SDK for AI Agents.
3. **Hero:** Give every agent a context system.
4. **Thesis:** The context path determines what an agent sees next.
6. **Proof:** Measure. Compare. Verify.
7. **Developer campaign only:** Tune any agent.

Rules:

- “Tune any agent” is allowed only in developer-campaign copy; never use it as
  the company category, product description, enterprise promise, or investor
  thesis.
- Describe LeanCTX as the context system inside or alongside existing agents
  and custom systems; do not imply it replaces the model, agent, application,
  or human engineering judgment.
- Lead with the hierarchy, then explain the specific capability or workflow.
  Never lead with a feature, a generic platform claim, or a savings percentage.
- Treat `docs/internal/reference/BRAND-NARRATIVE.md` as the source of truth;
  resolve an ambiguity in favor of the canonical message stack above.
- Treat composable architecture as an internal strategic direction, not a
  public claim yet. Do not present it as a current capability, ecosystem, or
  customer promise; the present public wedge remains evidence-led context
  performance.
- Do not promise a marketplace, universal orchestration, or ten-partner
  integrations **NOW**. These are explicitly out of scope.
- Treat any RTK partnership as exploratory, pending mutual interest and a
  bounded joint benchmark. Never describe it as committed, announced, or
  already integrated.

## Vision execution authorization

The product owner may authorize engineering across the internal roadmap without
a paid run as a prerequisite. That authorization changes implementation
priority; it does **not** change public availability, product honesty, or the
open-core boundary.

- Phase B–D work may proceed as internal **Research** when it has a declared
  workload, an OSS/commercial classification, a narrow exit criterion, and no
  unsupported public claim.
- Phase E work is commercial by default. Build its decision logic, customer
  data, rankings, organization controls, and deployment authority only in the
  private Thinkery boundary (Class D/E), behind an explicit rollback and
  governance design.
- A paid customer, verified receipt, and revenue remain promotion gates for a
  public offer or an Available claim; they are not engineering prerequisites.
- Marketplace, universal orchestration, broad partner ecosystems, hosted-agent
  replacement, and consumer/social surfaces remain outside the authorized
  vision unless a later product decision explicitly changes that strategy.

## Terminology enforcement — apply in every conversation

The following legacy labels are forbidden in external copy, customer-facing
chat, sales scripts, presentations, and product descriptions:

- Dyno
- AutoTune
- Chiptuner

Do not introduce, explain, endorse, translate, or revive a forbidden label in
an external response. If a user uses one, acknowledge their intent without
repeating it, then reframe with approved language:

- controlled benchmark or comparison — a declared baseline and treatment on
  the same workload
- context-performance tuning — measured changes to the context path
- performance engineer — the person or team improving the system

In internal governance text, mention a forbidden label only when necessary to
enforce this prohibition. Do not let an internal analogy leak into public copy.

## Product Honesty

Attach one product-status label to every material capability claim:

| Status | Meaning | Conversation rule |
| --- | --- | --- |
| **Available** | Customers can use it now under stated conditions. | It may be demonstrated, documented, and verified. |
| **Preview** | It is usable with explicit limits. | State the limits; do not present it as a default production promise or broad proof point. |
| **Research** | It is exploratory work. | Do not sell it, promise it, or describe it as a committed product capability. |

Never infer **Available** from a roadmap, prototype, benchmark, or research
result. If the status is unknown, say so, avoid the capability claim, and seek
the product owner’s classification before publishing.

## Verification Doctrine

Every performance claim follows **Measure. Compare. Verify.**

1. **Measure** — declare workload, inputs, model, configuration, quality
   gates, metric method, and constraints.
2. **Compare** — evaluate a named baseline and treatment on the same declared
   workload; preserve no-gain and trade-off results.
3. **Verify** — provide reproducible evidence, quality results, permitted
   source inputs, and an offline-verifiable receipt or equivalent artifact.

Reject or qualify any claim based only on an isolated metric, uncontrolled
before/after, anecdote, or undisclosed methodology. Never promise a percentage
improvement; report only verified outcomes with their stated scope.

## Competitive differentiation

Speak respectfully and only from approved, current, public evidence. Do not
claim competitor feature parity, benchmark superiority, private architecture,
or future plans.

| Alternative | Approved distinction |
| --- | --- |
| Caveman | An agent harness/workflow choice; LeanCTX adds a context-performance layer that evaluates the context path around existing agents. |
| Headroom | An observability and optimization workflow; LeanCTX centers versioned context configurations and verification-grade comparisons, not only visibility into runs. |
| RTK | Retrieval and runtime building blocks; LeanCTX evaluates the complete context path as a performance system across declared workloads. |

Use this concise position when useful: **LeanCTX gives an existing agent a
context system: it selects, shapes, reuses, and recovers task-fit context
instead of treating every model call as a raw payload.**

## Decision gate — apply to every task

Before drafting, implementing, reviewing, or approving work, answer:

1. Does it strengthen the Context SDK for AI Agents?
2. Does it preserve the canonical message hierarchy?
3. Is each capability claim classified Available, Preview, or Research?
4. Can every performance claim satisfy Measure. Compare. Verify.?
5. Does it preserve the customer’s existing-agent choice?
6. Is competitive language specific, respectful, and evidence-bounded?
7. Does it avoid turning the internal composable strategy into a public
   marketplace, universal-orchestration, or multi-integration promise?

If any answer is no or unknown, narrow, reframe, park, or escalate the work.

## Agent response protocol

1. Identify the audience: developer, technical leader, buyer, partner, or
   investor.
2. Start from the canonical stack at the appropriate depth.
3. State product-status labels for material capability claims.
4. Use the Verification Doctrine for any performance claim or comparison.
5. Reframe forbidden terminology immediately and silently in external copy.
6. Mark uncertain, unverified, or research-only statements clearly; do not
   manufacture evidence, availability, or differentiation.

## Claim-quality checklist

- Company/product/category language exactly matches the canonical stack.
- Developer-only campaign language is confined to developer-campaign context.
- No forbidden legacy labels appear in external text.
- Every material capability has an honesty status.
- Every performance claim declares its measurement, comparison, and verification path.
- Competitor statements are bounded to the approved distinction and current public evidence.
