---
name: master-execution
description: Execute the LeanCTX Master Plan with premium quality. Covers all 5 workstreams (Codebase Cleanup, SDK v1, Website Rebuild, OCLA Composable, Partnership). Use when implementing any part of the master plan, starting a workstream, cleaning up code, building the website, creating SDK features, or working on OCLA capabilities. Enforces quality gates, tracks progress, and ensures every deliverable meets production standards.
---

# Master Execution — LeanCTX Premium Delivery

## North Star

Every action serves ONE outcome: **a paying customer holds a verified Receipt
proving LeanCTX improved their agent's context performance.**

Everything else is scaffolding toward that proof.

## Source of Truth (read before acting)

| Document | Purpose | Read when |
|----------|---------|-----------|
| `docs/internal/execution/MASTER-EXECUTION-PLAN.md` | Task tracker, status | Starting any task |
| `docs/internal/execution/WEBSITE-IMPLEMENTATION-PLAN.md` | Website spec | WS-3 work |
| `docs/internal/execution/WEBSITE-REDESIGN.md` | Exact copy | WS-3 work |
| `docs/internal/execution/GITLAB-ISSUES.md` | Issue manifest | Creating/closing issues |
| `docs/internal/execution/CLEANUP-PLAN.md` | Codebase trim waves | WS-1 work |
| `docs/internal/execution/SDK-V1-SPEC.md` | SDK specification | WS-2 work |
| `docs/internal/reference/VISUAL-BRAND-GUIDELINES.md` | Design system | WS-3 work |
| `docs/internal/reference/BRAND-NARRATIVE.md` | Messaging | Any public-facing work |
| `docs/internal/reference/OCLA-CAPABILITY-ARCHITECTURE.md` | OCLA spec | WS-4 work |
| `docs/internal/reference/OCLA-CURRENT-STATE.md` | Current OCLA audit | WS-4 work |
| `docs/internal/vision/00-NORTH-STAR.md` | Strategic direction | Scope decisions |

## Execution Protocol

### Before ANY task

1. Read `MASTER-EXECUTION-PLAN.md` — find current status
2. Identify which workstream and task number you're executing
3. Read the relevant spec document for that workstream
4. Confirm exit criteria BEFORE writing code

### During execution

1. ONE task at a time — mark `in-progress` before starting
2. Smallest possible diff that achieves the exit criterion
3. No placeholders, no mocks, no stubs, no demo data
4. Update `MASTER-EXECUTION-PLAN.md` status after each task completes

### After completion

1. Run quality gates (see below)
2. Update task status to `done` with commit hash
3. If on a branch: PR description references the Issue number
4. Clean up: no temp files, no debug prints, no commented-out code

## Quality Gates (mandatory)

### Rust changes

```bash
cargo check                                    # compiles
cargo test --lib                               # tests pass
cargo clippy --all-features -- -D warnings     # zero warnings
cargo fmt --check                              # formatted
```

### Website changes (deploy branch)

```bash
cd website && npm run build                    # builds without error
npm run validate                               # positioning validation
npm run validate:i18n                          # i18n check
```

### Python changes

```bash
cd packages/python-lean-ctx
pip install -e ".[dev]"
pytest
ruff check .
```

### Universal

- No `[lean-ctx: omitted` markers in committed files
- No hardcoded secrets, tokens, or credentials
- No TODO/FIXME without a linked issue number
- Commit message follows: `type(scope): description`

## Workstream Execution Details

### WS-1: Codebase Cleanup

**Principle:** Archive, don't delete. History matters.

**Wave execution pattern:**
1. `git checkout -b cleanup/wave-N-<slug>` from `main`
2. `mkdir -p _archive && git mv <dir> _archive/<dir>`
3. Check CI references: `grep -r '<dir>' .github/`
4. Run Rust quality gates
5. Commit with `--no-verify` ONLY if changes are non-Rust
6. PR → merge → delete branch

**Wave 2 targets:** `marketing/`, `email-templates/`, `demo/`, `lab/`, `blog/`, `lean/`
**Wave 3 targets:** Consolidate `bench/` + `benchmark/` → `benchmarks/`

**Pre-existing Rust errors:** The codebase has duplicate `.rs`/`mod.rs` files.
These are NOT caused by cleanup. Do not block cleanup PRs on pre-existing issues.

### WS-2: SDK v1 + Evidence

**Principle:** Real code, real API calls, real Receipts.

**Implementation order:**
1. `packages/python-lean-ctx/` — consolidated types from archived SDKs
2. `ctx.wrap()` — OpenAI Agents SDK adapter through proxy
3. `ContextSession` — correlated task identity
4. Receipt generation — every wrap() emits evidence
5. Performance Benchmark — baseline vs treatment, same task
6. Quality Gate — automated + human verification
7. Offline Receipt verification — cryptographic proof
8. Quickstart docs — developer can run in 5 minutes
9. PyPI publish — v1.0.0
10. First pilot — CHF 7,500 Tuning Sprint

**SDK API surface (target):**
```python
from leanctx import LeanCTX

ctx = LeanCTX(project=".")
agent = ctx.wrap(my_agent)
result = agent.run(task)
receipt = ctx.receipt()
```

### WS-3: Website Rebuild

**Branch:** `deploy` (GitLab only, NEVER push to GitHub)  
**Worktree:** sibling private deploy worktree (local path is environment-specific)

**Principle:** Copy from WEBSITE-REDESIGN.md VERBATIM. Do not invent claims.

**V2 Strategy:** Build ALL new pages in `page-templates/v2/` and `components/v2/`.
Old pages remain live until v2 is complete. Switch happens atomically by
updating route imports. NEVER delete old pages until v2 is verified and deployed.

**Design system tokens:**
- `--color-carbon: #0A0A0A` (background)
- `--color-bone: #F2F0E9` (light surface)
- `--color-signal-orange: #FF4B00` (intervention/CTA)
- `--color-verified: #2D8A4E` (pass state)

**Typography (Geist + IBM Plex Mono):**

| Usage | Font | Weight | Why |
|-------|------|--------|-----|
| Headlines (Thinkery + LeanCTX) | Geist | Medium (500) | monumental, clean, corporate |
| Body text | Geist | Regular (400) | neutral, hochwertig |
| LeanCTX UI elements | Geist | Regular/Medium | technical, very readable |
| Metrics / Run IDs / Receipts | IBM Plex Mono | Regular | engineering/measurement layer |
| CLI / Code blocks | IBM Plex Mono | Regular | matches the product |
| Micro Labels | IBM Plex Mono | Medium, uppercase | laboratory/metrology feel |

**Grid:** 12-column, engineering-precise (4-col mobile)

**Page priority (all in `page-templates/v2/`):**
1. `HomepageV2.astro` — Hero + 6 sections
2. `SdkPageV2.astro` — developer-focused, code examples
3. `EnterprisePageV2.astro` — performance-first narrative
4. `BenchmarkPageV2.astro` — replaces any "Dyno" language
5. Docs restructure (in existing DocsLayout)

**Components to build (in `components/v2/`):**
- `Hero.astro` — eyebrow + headline + body + CTAs + proof line
- `Section.astro` — reusable editorial block
- `EvidencePanel.astro` — real data visualization
- `ReceiptCard.astro` — receipt artifact display
- `CodeBlock.astro` — syntax-highlighted with copy
- `BenchmarkComparison.astro` — baseline vs treatment table

**Switch protocol (when v2 is complete):**
1. Update route files to import from `v2/` templates
2. Verify `npm run build` passes
3. Run `npm run validate` + `validate:i18n`
4. Deploy to production
5. Only then: delete old templates from `page-templates/`

**Font loading (add to BaseLayout or global CSS):**
```css
/* Geist — from Vercel's CDN or self-hosted */
@import url('https://cdn.jsdelivr.net/npm/geist@1/dist/fonts/geist-sans/style.css');
/* IBM Plex Mono — from Google Fonts */
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&display=swap');
```

**Forbidden:**
- No fake metrics or placeholder numbers
- No "Dyno", "Chiptuner", "AutoTune" in public copy
- No `Maximize intelligence` or generic AI marketing
- No claims about features that are `Research` status
- No deleting old pages until v2 is complete and verified
- No mixing v1 and v2 components in the same template

### WS-4: OCLA + Composable

**Principle:** Dogfood before ecosystem.

**Sequence:**
1. Audit existing OCLA traits → already done (OCLA-CURRENT-STATE.md)
2. Define `CapabilityManifest v0` in Rust
3. Wrap ONE native feature (CompressionProvider) as v0 capability
4. Link capability ID to Performance Profile format
5. Link capability ID to Receipt schema
6. Run existing Benchmark through capability path
7. Write conformance test
8. Build one trivial external capability (local process)

**CapabilityManifest v0 minimum fields:**
```rust
struct CapabilityManifest {
    id: String,           // e.g. "leanctx.compression.structural"
    version: SemVer,
    capability_type: CapabilityType, // Compression | Retrieval | ...
    execution_mode: ExecutionMode,   // InProcess | LocalBinary | Remote
    input_contract: Schema,
    output_contract: Schema,
    properties: CapabilityProperties, // lossy, recoverable, cache_safe
    permissions: Vec<Permission>,
}
```

### WS-5: Partnership

**Principle:** Prove composition works before promising it.

**Only after WS-4 is complete.**

Joint benchmark design:
- Same workload, same model, same quality gate
- ARM A: Stock / ARM B: RTK / ARM C: LeanCTX / ARM D: RTK+LeanCTX
- Measure: input tokens, cached tokens, output tokens, cost, latency, quality

## Parallel Agent Orchestration

When spawning agents for this plan:

**Use `subagent_type: "generalPurpose"`** — never `"explore"` (no MCP).

**Include lean-ctx instructions** in every agent prompt (see workspace rule).

**Parallelization rules:**
- WS-1, WS-2, WS-3 can run in parallel (independent branches/dirs)
- WS-4 depends on WS-2 exit criterion
- WS-5 depends on WS-4
- Within WS-3: Step 1 (tokens) must complete before Steps 2-5

**Agent naming:** `E<N>-<task-slug>` (E4-wave2, E5-homepage, E6-sdk-page...)

## Progress Tracking

After completing any task, update the master plan:

```markdown
| N.N | Task description | `branch-name` | **done** (commit-hash) |
```

After completing a workstream, update the ASCII progress bar:

```text
WS-1: CODEBASE CLEANUP          ██████████  Done
```

## Anti-Patterns (NEVER do these)

- Push `deploy` branch to GitHub
- Create more than 1 branch per agent on GitHub remote
- Commit files with lean-ctx compression markers
- Add dependencies without explicit version pins
- Create documentation files without being asked
- Skip quality gates "because it's just a small change"
- Use mock data or placeholder content on the website
- Promise composable capabilities publicly (internal only)
- Build marketplace, dashboard, or control plane features
- Work on WS-4/WS-5 before WS-2 has a paid customer

## Completion Definition

The plan is DONE when:

```
✓ Repo is clean (no dead dirs, one Python SDK path)
✓ Website reflects brand narrative (deploy branch, GitLab)
✓ SDK v1 on PyPI with ctx.wrap() + Receipt
✓ One paid customer has a verified Receipt
✓ CompressionProvider runs through OCLA v0 contract
✓ One external capability benchmarked (optional stretch)
```

Only then does LeanCTX earn the right to publicly say
"The Context SDK for AI Agents."
