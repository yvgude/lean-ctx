---
name: ocla-capability
description: "Add or evolve an OCLA capability with CapabilityManifestV1, capability manifest schema, capability registry registration, measurement hooks, security and data-classification metadata, versioning, and OCLA conformance tests. Use for add OCLA capability, capability manifest, register capability, CapabilityManifest, new provider/optimizer capability, or OCLA conformance work."
---

# OCLA capability implementation

Make every capability discoverable, measurable, policy-filterable, and contract-conformant without publishing learned selection intelligence.

## Gather

1. Read `docs/internal/vision/06-ENGINE-SDK-CLOUD-PLAN.md` Phase 0/P1,
   `docs/internal/vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md` P1, and
   `docs/internal/reference/OCLA-CAPABILITY-ARCHITECTURE.md`.
2. Inspect:
   - `rust/src/core/ocla/types.rs`: capability kinds, status, request context, wire types.
   - `rust/src/core/ocla/traits.rs`: `OclaService` and capability interfaces.
   - `rust/src/core/ocla/registry.rs`: built-in registration and projection tests.
   - `rust/src/core/ocla/builtin/`: native implementations.
   - `rust/src/core/ocla/policy_bundle.rs`: classification and fail-mode patterns.
   - `docs/contracts/ocla-verifier-conformance-v1.md` and `rust/tests/suite/ocla_wire_contract_suite.rs`.
3. Run `ctx_compose`, then `ctx_impact` for each OCLA file to change.
4. Confirm whether the requested behavior executes a declared capability or introduces global ranking/selection logic. Keep the latter out of this repo.

## Act

### Define CapabilityManifestV1

Use:

- `docs/contracts/ocla-capability-manifest-v1.schema.json` as normative schema.
- `docs/contracts/ocla-capability-manifest-v1.md` for semantics and compatibility.
- `rust/src/core/ocla/capability_manifest.rs` for Rust types/validation.
- `rust/src/core/contracts.rs` and `CONTRACTS.md` for registration.

Require:

- Identity: schema version, stable capability ID, kind, implementation/provider, implementation version.
- Contracts: input schema ref, output schema ref, OCLA API range, conformance profile.
- Execution: local/remote locality, deterministic flag, side-effect policy, fail mode, limits.
- Observability: latency observable, token/cost/quality/outcome measurements, receipt support.
- Security: data movement, network requirement, supported data classifications, residency constraints, secret handling.

Use bounded enums and maps. Move/reuse shared classification types instead of duplicating `DataClassification`. Exclude workload rankings, learned weights, customer results, private benchmarks, and provider commercial rates.

### Register the capability

1. Implement the narrow trait in `ocla/traits.rs` and `OclaService` metadata.
2. Return `CapabilityManifestV1`; derive the legacy `OclaCapability` view for compatibility while V1 migrates.
3. Register the implementation in `OclaRegistry::with_builtins()` or the approved external registry path.
4. Reject duplicate IDs, unsupported versions, invalid schema refs, and manifest/trait kind mismatches.
5. Keep registry iteration and serialized discovery deterministic.

### Add measurement hooks

- Emit observation, usage, latency, status/error, and outcome-link events for every invocation.
- Propagate `task_id`, `trace_id`, `request_id`, capability ID/version, and receipt/evidence refs.
- Record token balances at original/materialized/delivered/provider-billed stages where applicable.
- Use `ObservationHook`, `UsageSink`, `MetricsExporter`, `SavingsLedger`, and `OutcomeTracker` projections as appropriate.
- Fail closed when policy/security metadata cannot be evaluated; never fabricate success or savings.

## Verify

- Unit-test manifest validation, stable serialization, classification compatibility, limits, and duplicate registration.
- Extend `rust/src/core/ocla/registry.rs` tests to call the capability through dynamic dispatch.
- Add golden manifest/schema fixtures under `rust/tests/fixtures/`.
- Extend `rust/tests/suite/ocla_wire_contract_suite.rs` and `rust/tests/ocla_integration_suite.rs` for discovery, invocation, measurements, and failure semantics.
- Run `scripts/verify-ocla-contract-suite.py` against the Rust verifier; add Python SDK projection coverage in `clients/python/leanctx/ocla.py` when the manifest is public wire surface.
- Run impacted tests and the Rust quality gate.

Acceptance requires two native strategies to be invoked and compared through the same contract and task evidence model; comparison data must not become public production ranking logic.
