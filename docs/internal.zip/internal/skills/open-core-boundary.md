---
name: open-core-boundary
description: "Classify and review features against the LeanCTX open-core, OSS boundary, commercial/proprietary Control Plane, open contracts, public reference freeze, and strategic data rules. Use for open-core, OSS boundary, commercial, proprietary, feature classification, A-E classification, code publication, public API/schema design, or deciding which repository owns a feature."
---

# Open-core boundary review

Classify every Epic, ADR, and material feature before coding. Deployment location does not determine ownership.

## Gather

Read the authoritative sources in this order:

1. `docs/internal/vision/06-ENGINE-SDK-CLOUD-PLAN.md`,
   `docs/internal/vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md`, and
   `docs/internal/execution/ANTI-ROADMAP.md`.
2. `docs/adrs/ADR-010-oss-and-proprietary-contribution-boundary.md`.
3. `docs/internal/reference/OSS-PROTECTION.md` and the relevant P0/P8/P9
   section of the Complete Implementation Roadmap.
4. `docs/contracts/local-free-invariant-v1.md`, `oss-plane-separation-v1.md`, and `pillar-boundaries-v1.md`.
5. `rust/src/core/server_capabilities.rs`, `rust/tests/local_free_invariant.rs`, and `rust/tests/suite/contracts_frozen.rs` for enforcement.

Gather the feature's inputs, outputs, decision authority, data sources, learning loop, deployment variants, current publication status, and proposed files before classifying it.

## Act

### Apply the decision tree

Ask in order:

1. Does it mainly execute a decision? Execution primitives may be OSS or an open contract when trust/distribution benefits.
2. Does it decide which context, capability, model, provider, knowledge, budget, or fallback to use? If yes, commercial by default.
3. Does the value compound with workloads, outcomes, organization state, economic history, or supplier relationships? If yes, Class D or E.
4. Does openness materially improve trust or ecosystem adoption? Expose the interface, format, verifier, and neutral SDK—not learned implementation.
5. Is on-prem/sovereign deployment required? Offer commercial deployment; do not infer OSS ownership.
6. Does it contain customer-derived performance, private benchmark data, commercial provider information, or learned rankings? If yes, Class E.
7. Is it already Apache-2.0 public? Grandfather the current surface; freeze future compounding intelligence as Class C.

Use the core test: **Execute vs Decide**. Then ask: **Does the value compound?**

### Assign exactly one class

- **A — OSS Runtime:** necessary local execution, optimization, instrumentation, enforcement, or already-public developer experience. Build publicly.
- **B — Open Contract:** schemas, protocols, neutral SDKs, and verifiers whose openness creates trust/interoperability. Publish contract, not methodology.
- **C — Public Reference / Intelligence Freeze:** existing public basic router/tracker/reference logic. Maintain safety and compatibility; add no production learning loop.
- **D — Proprietary Control Plane:** decisions, attribution, orchestration, organization governance, production scheduling, and commercial economics. Implement privately from inception.
- **E — Strategic Data:** task performance graphs, rankings, learned weights, customer/private benchmark corpora, and commercial provider rates. Never commit publicly.

Split cross-boundary features at a versioned wire contract: OSS emits neutral observations or executes/enforces signed instructions; private code decides, attributes, learns, governs, or settles.

### Record the classification

Add this block to the Epic/ADR/spec before implementation:

```markdown
## Open-core classification
- Class: A | B | C | D | E
- Owner/repository:
- Executes or decides:
- Compounding inputs/value:
- Public contract boundary:
- Runtime-observed vs platform-verified authority:
- Data classification/residency:
- Existing public surface and freeze line:
- Reviewer and decision date:
```

If one proposal spans classes, split it into separately owned deliverables. Do not mark the entire feature B merely because it includes a schema.

## Verify

Before making code public, confirm:

- Classification exists and matches actual behavior, not naming.
- Public code only observes, executes, verifies, or enforces neutral contracts.
- No attribution/baseline methodology, quality-gate methodology, experiment orchestration, policy authoring/distribution, settlement, pricing, or fleet decisions leaked.
- No customer-derived outcomes, learned weights, capability/model rankings, private corpora, provider rates, credentials, or tenant data appear in code, fixtures, logs, snapshots, or docs.
- `SavingsObservationV1` remains observed/estimated; it is never relabeled verified, attributable, billable, or settled.
- Public routers/trackers are explicitly basic/reference and do not train a production decision system.
- Local runtime behavior remains free and ungated; commercial capabilities are additive.
- Contract changes include versioning, compatibility, conformance, and public/private ownership tests.
- Run `rust/tests/local_free_invariant.rs`, `rust/tests/suite/contracts_frozen.rs`, secret/data scans, and the relevant quality gate.

Stop and move the implementation to the private repository when Class D/E behavior or data would otherwise enter this public workspace.
