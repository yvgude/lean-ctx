---
name: scheduler-phase
description: "Implement scheduler phases from shadow recommendations to controlled model=auto, including ExecutionPlanV1 generation, candidate plan enumeration, capability selection, model/provider routing decisions, policy and budget filtering, quality floors, fallback strategy, calibration, and shadow-versus-production behavior. Use for shadow scheduler, execution plan, model=auto, capability selection, routing decision, quality floor, or scheduler fallback work."
---

# Scheduler phase implementation

Start deterministic and explainable. Shadow recommendations must not modify production execution; controlled routing must fail safe.

## Gather

1. Read `docs/internal/vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md` P2,
   P4 and P9, plus `docs/internal/execution/PROOF-DOCTRINE.md`.
2. Read `docs/internal/vision/06-ENGINE-SDK-CLOUD-PLAN.md` and
   `docs/internal/skills/open-core-boundary.md` before choosing a repository:
   production scheduling and learned selection are Class D/E.
3. Inspect OSS substrate:
   - `rust/src/core/context_kernel/types.rs`, `policy.rs`, `degradation.rs`, and `shadow.rs`.
   - `rust/src/core/ocla/registry.rs`, `builtin/model_router.rs`, and `routing_quality.rs`.
   - `rust/src/proxy/model_router.rs`, `policy_gate.rs`, `routing_feedback.rs`, `holdout.rs`, and `cost.rs`.
   - TaskEnvelope, CapabilityManifest, receipt, and outcome contracts if present.
4. Run `ctx_compose` and `ctx_impact`. Mark each touched component Class B, C, D, or E before coding.

## Act

### Generate ExecutionPlanV1

Place the open wire schema in `docs/contracts/execution-plan-v1.schema.json`, semantics in `docs/contracts/execution-plan-v1.md`, and the neutral Rust projection in `rust/src/core/execution_plan.rs`. Register it in `rust/src/core/contracts.rs` and `CONTRACTS.md`.

Include `plan_id`, `task_id`, mode, requested/baseline plan, bounded candidates, selected candidate, fallback candidate, expected cost/latency/quality/confidence, policy evaluations, catalog/price/evidence versions, rationale, and decision ref. Derive `plan_id` deterministically from canonical payload-free inputs; exclude timestamps and mutable rankings from the hash.

### Enumerate and filter candidates

1. Enumerate a bounded Cartesian set of allowed context strategy, capability, model, provider, and reasoning effort.
2. Always include the requested/baseline execution as the fallback candidate.
3. Apply hard filters before scoring: capability availability, data classification, locality/residency, provider allow/deny policy, side effects, budgets, and contract/version compatibility.
4. Preserve a machine-readable rejection reason for every filtered candidate.
5. Enforce quality floor as a hard constraint. Missing or weak evidence cannot justify controlled selection; it may produce a low-confidence shadow recommendation.
6. Rank feasible candidates with deterministic, versioned rules using expected cost, latency, and quality evidence. Do not add ML before evidence quality exists.

### Choose mode and fallback

- `shadow`: generate and persist the recommendation, but execute the original requested path unchanged. Join recommendation to the actual receipt for calibration.
- `controlled`: enable only for known task classes with sufficient evidence, enforceable policy, measurable quality floor, and tested fallback.
- Fall back to requested/baseline execution when no candidate is feasible, confidence is low, policy evaluation fails, route quality degrades, or execution errors.
- Never silently reduce quality, weaken residency/security, or exceed budget during fallback.
- Keep existing `context_kernel/shadow.rs` semantics distinct: it logs context plans and is not the production compute scheduler.

### Preserve the open-core boundary

- Public repo: ExecutionPlan contract, deterministic local execution/enforcement, open manifest data, local observations, verifier, and clearly basic/reference router compatibility.
- Private Control Plane: global candidate ranking, learned performance models, cross-customer outcomes, production scheduler, promotion logic, provider economics, and fleet allocation.
- Strategic data stores must contain refs/aggregates only across the public boundary, never private weights or commercial rates in fixtures/logs.

## Verify

- Unit-test deterministic plan IDs/order, candidate bounds, each hard filter, quality-floor rejection, and fallback completeness.
- Test shadow mode cannot mutate the actual model/provider/capability and always records a counterfactual recommendation.
- Test controlled mode gates, degraded-quality fallback, policy equivalence, and receipt linkage.
- Use deterministic holdouts from `rust/src/proxy/holdout.rs`; calibrate recommendations against actual outcomes.
- Add contract golden/drift tests under `rust/tests/fixtures/` and `rust/tests/suite/`.
- Do not expand `model=auto` until evaluated tasks show meaningful ETPAO/cost improvement without material accepted-outcome degradation.
- Run impacted tests and the Rust quality gate.
