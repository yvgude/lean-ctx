---
name: task-envelope
description: "Implement and evolve TaskEnvelopeV1, canonical task identity, task_id creation, parent/child task identity, and trace propagation across Runtime, MCP calls, shell execution, proxy requests, OCLA, context events, plans, and receipts. Use for requests mentioning implement TaskEnvelope, task identity, trace propagation, task_id, parent_task_id, or end-to-end task correlation."
---

# TaskEnvelopeV1 implementation

Treat a task as the canonical unit. Extend existing request, session, agent, and trace lineage; do not create a parallel tracing stack.

## Gather

1. Read `docs/internal/vision/08-COMPLETE-IMPLEMENTATION-ROADMAP.md` P1-P4
   and `docs/internal/reference/TECHNICAL-CONVERGENCE.md`.
2. Read `docs/internal/vision/06-ENGINE-SDK-CLOUD-PLAN.md` and the
   open-core boundary skill. Task identity is an open contract only when its
   data classification and compatibility rules are explicit.
3. Run `ctx_compose` for the requested flow and `ctx_impact` before changing Rust.
4. Inspect the current lineage and interception points:
   - `rust/src/core/ocla/types.rs`: `OclaRequestContext`, surfaces, token envelope.
   - `rust/src/server/call_tool/guarded.rs`: MCP call boundary.
   - `rust/src/server/post_dispatch.rs`: MCP receipts and context events.
   - `rust/src/shell/pipeline.rs` and `rust/src/core/tool_lifecycle.rs`: shell lifecycle.
   - `rust/src/proxy/lineage.rs` and `rust/src/proxy/forward/trace_id.rs`: trusted proxy lineage.
   - `rust/src/core/context_kernel/mcp_bridge.rs` and `proxy_bridge.rs`: kernel attribution.
5. Map every existing ID to one role before editing: `task_id` identifies work; `parent_task_id` links child work; `trace_id` groups spans; `request_id` identifies one request; `session_id` and `agent_id` identify actors/scopes.

## Act

### Define the contract

Use these locations:

- Normative JSON Schema: `docs/contracts/task-envelope-v1.schema.json`.
- Semantics/versioning: `docs/contracts/task-envelope-v1.md`.
- Rust wire projection and validation: `rust/src/core/task_envelope.rs`.
- Registration: `rust/src/core/mod.rs`, `rust/src/core/contracts.rs`, and `CONTRACTS.md`.

Keep V1 payload-free. Require `schema_version`, `task_id`, `trace_id`, `request_id`, `session_id`, `agent_id`, `created_at`, and `source_surface`; allow `parent_task_id`, `tenant_id`, `objective_ref`, and immutable evidence-safe attributes. Use bounded strings, `deny_unknown_fields`, explicit validation, and no prompt/file contents.

### Create identity once

- Accept an incoming `task_id` only from a trusted/authenticated boundary and validate it.
- Otherwise create a cryptographically random root ID at the first boundary encountered.
- MCP: resolve from request `_meta` in `call_tool/guarded.rs`; create there when absent.
- Shell: inherit `LEAN_CTX_TASK_ID`; create in `shell/pipeline.rs` for a root shell operation when absent.
- Proxy: resolve trusted task headers beside `proxy/lineage.rs`; create before request rewriting when absent.
- Child/subagent work: allocate a new `task_id`, preserve `trace_id`, and set `parent_task_id` to the caller task.
- Never regenerate identity during retries, cache hits, provider translation, or response streaming.

### Propagate through all joins

- Add task fields to `OclaRequestContext`; preserve existing request/session/agent/content lineage.
- Carry the envelope through MCP `_meta`, shell environment, trusted proxy headers, OCLA calls, Context/OS events, routing decisions, ledgers, and outcome signals.
- Extend `ContextReceiptV1` only as a migration bridge; new task-level evidence must reference `ExecutionReceiptV1`.
- Link evidence as `task_id -> plan_id -> receipt_id -> outcome_ref`; include `decision_ref` and `policy_ref` when present.
- Centralize parsing/generation helpers in `task_envelope.rs`; adapters must not invent incompatible IDs.

## Verify

- Unit-test schema validation, bounded IDs, unknown fields, root creation, trusted preservation, retry stability, and child-parent linkage.
- Add boundary tests for MCP, shell, proxy, and OCLA; assert one root task survives a complete flow.
- Add a golden JSON fixture under `rust/tests/fixtures/` and a schema drift test under `rust/tests/suite/`.
- Extend trace-correlation coverage in `rust/tests/closure/trace_correlation.rs`.
- Prove receipts and outcome evidence join on `task_id` without payload leakage.
- Run impacted tests, then `cargo test --lib`, `cargo clippy --all-features -- -D warnings`, and `cargo fmt --check` from `rust/`.

Do not finish with IDs present only in structs. The exit condition is one real coding task traceable from first context read through execution, cost, receipt, and outcome.
