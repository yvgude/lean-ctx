# LeanCTX — Canonical SDK-First Product and Repository Architecture

> **Classification:** Canonical product authority
>
> **Versioning status:** LOCAL-ONLY / UNVERSIONED. This confidential file is
> locally authoritative, but no approved durable private source currently exists.
>
> **Decision status:** Product direction DECIDED. Only parameters explicitly
> listed as pending remain pending.

## 1. Product priority

LeanCTX is a premium Context SDK for AI agents and AI-native products, built on
a strong Apache-2.0 Engine.

```text
Apache-2.0 LeanCTX Engine
          ↓
BSL 1.1 LeanCTX Production SDK
          ↓
Customer-owned agent / AI-native product
          ↓
Optional LeanCTX Cloud / optimization later
```

Priority is strict:

1. **Engine** is the open, independently useful mechanism substrate.
2. **Production SDK** is Thinkery's primary product and near-term focus.
3. **Customer adoption** proves the product before expansion.
4. **Cloud** is optional later commercial expansion.

> **Engine is open. SDK is BSL 1.1. SDK is the product. Cloud comes later.**

LeanCTX is an SDK company built on a strong OSS Engine. It is not an agent
framework, benchmark consultancy, orchestration platform, model provider, RAG
service, memory database, or OSS runtime whose only monetization is Cloud.

## 2. Product responsibilities

### Customer host

The customer retains the agent, model, prompts, tools, business logic,
orchestration, retries, permissions, UX, deployment, and customer relationship.

### LeanCTX Engine

> **Engine executes context mechanisms.**

The Engine owns deterministic low-level mechanisms: secure source reads,
search, structural transforms, compression, cache and recovery primitives,
bounded capability execution, content-addressed artifacts, invocation and
observation facts, and low-level evidence.

It remains Apache-2.0, public, useful on its own, and deliberately uncrippled.

### LeanCTX Production SDK

> **The Engine provides mechanisms. The BSL 1.1 Production SDK turns those
> mechanisms into a production context system.**

The SDK owns the customer-facing context lifecycle, semantics, developer
experience, safe defaults, maintained integrations, compatibility, evidence
projection, upgrades, and embedded product contract.

The stable lifecycle is:

```text
Select → Shape → Reuse → Recover
```

Initial product primitives:

- `ContextSession`
- `ContextSource`
- `ContextView`
- `ContextPlan`
- `ContextReceipt`

These are product semantics, not thin serialization wrappers.

### LeanCTX Cloud

> **Cloud extends the SDK business. It is not required to justify the SDK
> business.**

Cloud is optional, private/commercial, and later. It may add organization-scale
history, governance, Continuous Optimization, and Selection Intelligence only
after SDK product-market fit. Local Engine and SDK operation never require it.

## 3. Production SDK license

The Production SDK license family is **Business Source License 1.1 (BSL 1.1)**.
This is DECIDED and must not be described as pending, proposed, Apache, or OSS.

Only these implementation/legal parameters remain pending until formally set:

- Change Date;
- Change License;
- Additional Use Grant;
- evaluation/development and any production/free-use boundary;
- OEM and redistribution terms;
- pricing and enterprise exceptions;
- repository visibility/access and package namespace;
- contributor, security, and release processes.

Existing Apache-2.0 rights in the Engine and already-published artifacts are
unchanged. The SDK repository must carry the approved BSL text and parameters
before its first production release.

## 4. Why the SDK exists

Engine mechanisms alone are not a complete production product experience.
Without the SDK, every customer must invent lifecycle rules, source/view
semantics, planning, reuse and freshness policy, recovery, budgets, evidence
projection, adapters, error behavior, observability, migrations, and version
support.

The SDK packages those responsibilities into one coherent maintained product.

> **The Engine makes it possible. The SDK makes it practical to depend on in
> production.**

## 5. Why buy the SDK instead of building on the Engine?

The Apache Engine makes self-building legally and technically possible. LeanCTX
does not claim otherwise and creates no artificial moat.

A self-build means owning a permanent internal context-infrastructure product:

- context-session, source, view, plan, and receipt semantics;
- budgets, freshness, reuse, recovery, trust, and degradation policy;
- framework lifecycle, streaming, retry, and error integration;
- evidence lineage, quality hooks, observability, and verification;
- Engine compatibility, migrations, security defaults, and release support;
- integration tests, documentation, and production operations.

LeanCTX wins when integrating the SDK is clearly better than carrying that
engineering and maintenance burden.

> **We do not stop customers from building. We make buying LeanCTX the better
> engineering decision.**

The strongest customer statement is:

> **“We could build this ourselves. We chose LeanCTX instead.”**

## 6. Engine versus SDK boundary

Product-level SDK semantics must not migrate into the Apache Engine merely for
convenience.

Engine may own a feature when it is useful as a deterministic local mechanism
without controlling the customer's context lifecycle. SDK owns a feature when
it decides or manages how an agent/product uses context across that lifecycle.

Normally Engine-owned:

- secure reads, search, structural transforms, compression;
- local cache and recovery primitives;
- bounded capability execution;
- low-level invocation, observation, artifacts, and evidence facts.

Normally SDK-owned:

- `ContextSession` and high-level `ContextPlan` lifecycle;
- host-facing Select → Shape → Reuse → Recover orchestration;
- reuse/freshness, policy, budget, and degradation semantics;
- framework adapter lifecycle and developer ergonomics;
- compatibility, migrations, and embedded/OEM APIs.

The Engine must stay strong. The SDK must remain a substantial product rather
than a licensing shell around Engine calls.

## 7. SDK quality bar

> **The SDK should make sophisticated context engineering feel boringly
> simple.**

It must be obvious, coherent, fast, safe, predictable, well documented,
framework-friendly, testable, observable, easy to upgrade, and difficult to
misuse. It must avoid a configuration maze or broad framework surface.

The normal customer path should take hours or days, not weeks or months. Exact
syntax stays contract-driven, but the intended experience is one simple entry
point, one coherent session lifecycle, a factual receipt, and explicit metrics.

## 8. Product value the SDK owns

- stable Select → Shape → Reuse → Recover lifecycle;
- bounded budgets, source identity, freshness, trust, and safe defaults;
- coherent reuse, recovery, lineage, and downstream representation semantics;
- factual `ContextReceipt` with measured/estimated/unavailable classification;
- quality-gated comparison hooks and Engine invocation linkage;
- maintained host/framework adapters with streaming and retry preservation;
- Engine×SDK compatibility matrix, migrations, deprecation windows, fixtures,
  provenance, and stable errors;
- production documentation, support, and embedded/OEM readiness.

## 9. Embedded product distribution — LeanCTX Inside

```text
AI-native product
      ↓
customer-owned agent/runtime
      ↓
LeanCTX Production SDK
      ↓
LeanCTX Engine
      ↓
customer tools / MCP / data / models
```

One integration can reach many downstream deployments while the customer keeps
its own product and relationship. This **LeanCTX Inside** motion is a core
distribution strategy, not a future Cloud dependency.

## 10. First Production SDK target

The first SDK release proves only:

- one coherent lifecycle;
- one supported host/framework path;
- one native Embed path;
- one versioned Engine Protocol;
- one canonical Receipt;
- clean installation and excellent documentation;
- real compatibility and migration policy;
- no mock runtime and no founder-only setup.

Commercial value comes from quality and responsibility removed from the
customer, not feature count.

The current Python package is Preview/migration input. The existing Rust
`lean-ctx-sdk` is an Engine embedding facade, not the BSL Production SDK.

## 11. Repository architecture

Dependency direction is one-way:

```text
optional private Cloud repository/service
          ↓ published SDK contracts
separate BSL 1.1 Production SDK repository
          ↓ public versioned Engine Protocol
public Apache-2.0 Engine repository
```

The Production SDK **must** become a separate repository. Repository creation,
visibility, namespace, BSL parameters, contribution rules, and release/security
controls follow the decision record. They do not reopen product priority,
license family, or the repository split.

## 12. SDK-first delivery order

```text
Engine contract and factual evidence
        ↓
Production SDK vertical slice
        ↓
real embedded/customer adoption
        ↓
SDK hardening and repeatability
        ↓
optional Cloud / Continuous Optimization / Selection Intelligence
```

Current accepted integration status remains evidence-driven: P0 and P1 are
complete, P2 is active, P3 follows P2, and Production SDK repository work starts
only at its explicit entry gate. Isolated worktrees never advance status.

## 13. SDK product-market-fit test

Success is not token savings or GitHub adoption alone. Measure:

- install-to-first-useful-Receipt and existing-agent integration time;
- integration code/configuration and founder assistance;
- quality-preserving context reduction, reuse, recovery, and evidence coverage;
- clean upgrade across supported Engine and SDK versions;
- an explicit buy-vs-build decision won by LeanCTX;
- retention after comparison, a second workflow/agent, and downstream embedding;
- a Production SDK license, paid production use, or OEM commitment.

PMF proof is a capable engineering team choosing LeanCTX instead of owning the
equivalent context system, then expanding it without bespoke founder work.

## 14. Design partners

Prioritize teams already building real agents or AI-native products, with
repeated context-heavy workflows and enough engineering capability to build
their own layer. Learn which semantics they value, which Engine details they do
not want to own, what earns dependency trust, and what maintenance they will pay
to avoid.

## 15. Long-term moat

The moat is excellent SDK product, maintained semantics, embedded distribution,
compatibility, evidence, reliability, production learning, and later Selection
Intelligence—not a weakened Engine or hidden protocol.

Workspace, `.ctxpkg`, Calibrator, AutoTune, Shared Project Context, Continuous
Optimization, and Selection Intelligence remain gated Research unless promoted
by their own evidence and product decisions. Agent Bus improvements remain
local coordination infrastructure, not a public scheduler or generic platform.

## 16. Final doctrine

> **Engine is open.**
>
> **SDK is BSL 1.1.**
>
> **SDK is the product and must be worth buying.**
>
> **Do not rebuild paid product semantics inside the Apache Engine.**
>
> **Cloud comes later. LeanCTX Inside distributes the product.**
>
> **Build less surface. Make the surface exceptional.**
