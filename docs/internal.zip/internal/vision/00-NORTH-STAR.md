# LeanCTX — North Star

> **Classification:** Active support. The canonical architecture controls
> product/repository boundaries and status.

> **Status:** Operating and proof direction. [Context SDK Positioning](05-CONTEXT-SDK-POSITIONING.md)
> controls the public product story; [Product Architecture](PRODUCT-ARCHITECTURE.md)
> controls availability and support boundaries.

## The north star

LeanCTX gives an existing AI agent a context system. For each next step, it
helps determine the relevant source, the right representation, what remains
valid, and how to return to exact material.

```text
Select → Shape → Reuse → Recover
```

The agent host remains responsible for the task, model, tools, prompts, retries,
sandbox, permissions, and scheduling. LeanCTX owns the context path routed
through it—not what the agent does next.

The primary Thinkery product is the separate BSL 1.1 Production SDK built on
the Apache-2.0 Engine. Cloud is optional later expansion.

## What success means

The near-term success condition is one real workload that can show a comparable
baseline and treatment, a declared quality threshold, an inspectable local
Receipt, and offline verification. The affected result must be named precisely:
context sent, repeated reads, latency, calculated cost, or accepted task outcome.

A cheaper failed task is not a win. A local Receipt is inspectable evidence, not
a universal performance claim. Product-market fit is a capable team choosing
the SDK over building and permanently maintaining an equivalent layer, then
expanding it to another workflow, agent, or downstream deployment.

## Product path

| Stage | Status | Purpose |
| --- | --- | --- |
| Local Runtime and coding-agent setup | Available | Immediate local adoption through CLI, MCP, hooks, and proxy paths. |
| Python SDK v1 and declared reference wrapper | Preview | Migration input for a bounded programmatic integration path. |
| Separate Production SDK | Decided target | Primary BSL 1.1 product; premium lifecycle, compatibility, integrations and support. |
| Native custom-agent reference | Preview direction | Demonstrate task-fit views, reuse, recovery, bounded handoff, and a Receipt. |
| Shared Project Context | Research | Reuse scoped project state across sessions or agents without making LeanCTX an orchestrator. |
| Benchmark, Profiles, Kits, AutoTune, cloud operation | Research | Earn contracts and evidence before product or commercial claims. |

## Non-negotiable rules

- Keep the local developer experience useful without an account or hosted
  dependency.
- Do not represent an internal tool, local substrate, target API, or research
  design as a public product promise.
- Do not frame LeanCTX as an agent platform, agent builder, workflow scheduler,
  generic memory product, or hosted cloud workspace.
- When a result matters, compare the same workload under stated conditions and
  preserve its limitations.
- The current coding-agent wedge and native SDK destination complement each
  other; neither is a deprecated path.

## Reading order

1. [Context SDK Positioning](05-CONTEXT-SDK-POSITIONING.md)
2. [Product Architecture](PRODUCT-ARCHITECTURE.md)
3. [Proof Doctrine](../execution/PROOF-DOCTRINE.md)
4. [Master Execution Plan](../execution/MASTER-EXECUTION-PLAN.md)
5. [Canonical SDK-First Architecture](00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md)
