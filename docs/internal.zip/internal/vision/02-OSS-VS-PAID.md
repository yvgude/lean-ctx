# LeanCTX OSS vs Paid Boundary

> **Classification:** Active commercial boundary
>
> **Authority:** The canonical SDK-first architecture controls. This document
> explains—not reopens—the decided product split.

## Fixed model

| Layer | License/posture | Purpose |
| --- | --- | --- |
| **LeanCTX Engine** | Apache-2.0, public OSS | Strong independently useful context mechanisms and public Engine Protocol. |
| **LeanCTX Production SDK** | BSL 1.1, separate repository | Primary Thinkery product: maintained production context lifecycle and developer experience. |
| **LeanCTX Cloud** | Private/commercial, optional later | Organization-scale history, governance, Continuous Optimization, and Selection Intelligence after SDK PMF. |

BSL 1.1 is decided. Only Change Date, Change License, Additional Use Grant,
evaluation/production thresholds, OEM terms, pricing, repository access,
namespace, contributor, security, and release parameters remain pending.

There is no permanent “single developer free, organization paid” product law.
Permitted SDK use will follow the approved BSL parameters and commercial terms.

## Why Engine stays open

The Engine is LeanCTX's trust and distribution substrate. It must remain useful
without SDK or Cloud and expose deterministic local mechanisms, portable
protocols, evidence facts, and verification paths.

The goal is not to make self-building impossible. Apache-2.0 users may construct
their own layer. LeanCTX does not hide basic protocols or sabotage OSS.

## Why the SDK is paid product

Production context is more than Engine calls. The SDK owns:

- Select → Shape → Reuse → Recover lifecycle;
- session, source, view, plan, and receipt semantics;
- freshness, reuse, recovery, budgets, trust, and degradation policy;
- maintained framework and custom-host integrations;
- compatibility, migrations, deprecation, fixtures, and release provenance;
- evidence projection, observability, documentation, support, and OEM APIs.

A customer choosing Engine-only becomes owner of that permanent internal
infrastructure. The SDK must make buying the better engineering decision.

> **The Engine makes it possible. The SDK makes it practical to depend on in
> production.**

## Boundary test

A capability belongs in Engine when it is a deterministic local mechanism
useful without owning the customer's context lifecycle.

A capability belongs in the BSL SDK when it manages how an agent or product
uses context across its lifecycle.

A capability belongs in Cloud only when it requires organization-scale shared
operation, and only after local SDK PMF.

Never move SDK semantics into Engine for convenience. Never weaken Engine to
manufacture SDK value.

## Commercial sequence

1. Prove the public Engine Protocol and factual evidence chain.
2. Ship the small premium BSL 1.1 SDK vertical slice.
3. Win real build-vs-buy decisions and embedded deployments.
4. Harden compatibility and repeatability.
5. Add optional Cloud only when production usage earns it.

Primary revenue is Production SDK licensing/support and embedded/OEM agreements.
Cloud may later expand revenue; it is not the first or only durable monetization
layer.

## Product-market-fit evidence

- explicit internal-build versus LeanCTX evaluation;
- LeanCTX selected and retained after comparison;
- clean integration and upgrade without founder-only work;
- second workflow or agent using the SDK;
- downstream embedded deployment;
- paid production license or OEM commitment.

> **Engine is open. SDK is BSL 1.1. SDK is the product. Cloud comes later.**
