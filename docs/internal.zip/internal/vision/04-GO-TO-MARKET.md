# LeanCTX SDK-First Go-to-Market

> **Classification:** Active GTM guidance
>
> **Authority:** Canonical architecture controls product, license, and status.
> Pricing and exact commercial terms remain hypotheses until approved.

## Objective

Win a real build-vs-buy decision for the BSL 1.1 Production SDK.

> **“We could build this ourselves. We chose LeanCTX instead.”**

The ideal early customer already builds serious agents or an AI-native product,
has repeated context-heavy workflows, and has engineers capable of building its
own context layer. This makes adoption meaningful evidence rather than a sale to
a team that had no alternative.

## Product offered

- Apache-2.0 Engine: public, useful mechanism and trust substrate.
- BSL 1.1 Production SDK: primary paid/licensed product.
- Embedded/OEM path: LeanCTX Inside beneath the customer's product.
- Cloud: optional later expansion, not part of the initial value proof.

The current Python package and OpenAI Agents wrapper are Preview/migration input,
not the Production SDK offer.

## Design-partner motion

1. **Qualify:** confirm a real agent, recurring context burden, owner, data
   boundary, quality criterion, and explicit internal-build alternative.
2. **Map:** identify the lifecycle semantics, Engine details, compatibility debt,
   and support burden the team does not want to own.
3. **Integrate:** use one supported framework path or native Embed path; no mock
   Runtime and no founder-only hidden setup.
4. **Compare:** evaluate the customer's baseline and LeanCTX treatment with
   factual Receipts, a quality gate, and visible limitations.
5. **Decide:** ask whether the team will license/integrate LeanCTX instead of
   maintaining an equivalent internal system.
6. **Expand:** prove a second workflow, second agent, upgrade, downstream
   deployment, paid production license, or OEM agreement.

The first engagement may optimize learning over maximal short-term revenue. Do
not turn bespoke founder engineering into the product.

## What to learn

- Which SDK API and lifecycle customers naturally want.
- Which Engine details they refuse to own.
- Which safe defaults create trust.
- Which adapters, migrations, and support guarantees matter.
- What makes dependency risk acceptable.
- What they will pay to avoid building and maintaining.
- Whether the same contract travels into another workflow or downstream product.

## Adoption wedge

The public Engine and current Attach integrations let developers experience
LeanCTX mechanisms with low risk. They are not a promise that the Production SDK
is free or OSS.

The paid product demonstration should make responsibility removal visible:

```text
before: customer owns context lifecycle, adapters, evidence and upgrades
after:  customer integrates LeanCTX SDK and owns only its agent/product
```

A customer should reach a useful `ContextReceipt` and a production-shaped
integration in hours or days, not weeks or months.

## Proof requirements

Every comparison declares:

- workload and attributable inputs;
- baseline and treatment;
- model/provider and usage accounting;
- quality criterion and accepted outcome;
- context operations and recovery behavior;
- measured, estimated, or unavailable fields;
- Receipt/evidence identity;
- limitations and reproducibility path.

Token reduction is diagnostic, not PMF. A Receipt proves declared facts, not
automatic quality or business value.

## Commercial signals

Strong:

- explicit build-vs-buy evaluation won;
- signed Production SDK/design-partner commitment;
- retained integration after benchmark;
- clean Engine/SDK upgrade;
- second workflow or agent;
- downstream embedded deployment;
- paid production or OEM agreement;
- expansion without bespoke founder work.

Weak:

- GitHub stars or downloads alone;
- benchmark interest without integration;
- a founder-operated demo;
- requests for many adapters before one supported path works;
- interest in future Cloud without SDK adoption.

## LeanCTX Inside

```text
customer AI-native product
      ↓
customer-owned agent/runtime
      ↓
LeanCTX Production SDK
      ↓
LeanCTX Engine
```

The customer keeps its UX, business logic, orchestration, and relationship.
LeanCTX becomes the maintained context system beneath it. One SDK integration
can distribute through many downstream deployments.

## Messaging

Lead with:

- Premium Context SDK for AI agents and AI-native products.
- Give every agent a production context system.
- Engine mechanisms; SDK production lifecycle.
- Select → Shape → Reuse → Recover.
- Build less context infrastructure; ship the agent product.
- The Engine is open; the SDK is BSL 1.1.
- LeanCTX Inside.

Do not lead with:

- free/open SDK;
- “single developer free, organization paid”;
- Cloud as the first monetization layer;
- benchmark consultancy;
- universal savings;
- agent platform or orchestration;
- unapproved pricing or BSL parameters.

## Expansion gate

Cloud, Continuous Optimization, and Selection Intelligence enter GTM only after
repeat SDK adoption, trusted evidence, designated owners, privacy/tenant rules,
and explicit product gates.

> **Sell the SDK value first. Earn the right to expand.**
