# LeanCTX — Context SDK Positioning

> **Status:** Active positioning reference.
>
> **Classification:** Canonical support. Repository and licensing boundaries
> come from the
> [canonical architecture](00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md).
>
> **Authority:** This document defines the strategic product story and the
> target public contract. [Internal README](../README.md) and
> [Product Architecture](PRODUCT-ARCHITECTURE.md) remain authoritative for
> current availability, support, safety boundaries, and claim discipline.
>
> **Rule:** A target API, an internal runtime capability, or an experimental
> integration is never a public promise without its explicit status label.

## 1. Decision

LeanCTX is **The Context SDK for AI Agents.**

> **Give every agent a context system.**

LeanCTX is built into, or runs alongside, an agent system the customer already
owns. It is not an agent framework, model provider, cloud workspace, generic
agent builder, scheduler, multi-agent communication product, memory database,
RAG service, or compression-only proxy.

The practical boundary is:

> **Your framework runs the agent. LeanCTX manages its context path.**

This is the **SDK** product story within the broader LeanCTX architecture:
the open-source **Engine** executes local deterministic context operations;
the SDK makes context decisions inside the host loop; future **Cloud** services
may observe, share and govern published context artifacts across an
organization. Cloud is Research and never required for local execution. See
[Engine, SDK & Cloud Plan](06-ENGINE-SDK-CLOUD-PLAN.md) for the binding
product boundary and implementation order.

The agent host owns the task, model, prompts, tools, retries, orchestration,
sandbox, permissions, business logic, and user experience. LeanCTX controls
the context work routed through it before inference.

The Production SDK is Thinkery's primary product: a separate BSL 1.1 repository
downstream of the public Engine Protocol. `packages/python-lean-ctx/` is
Preview/migration input, not that final repository. Cloud is optional later
expansion, not the reason the SDK business exists.

## 2. The problem

An agent does not reason over an entire repository, company, or history. It
reasons over the information assembled for its next model call: files, search
results, tool output, instructions, earlier turns, facts, decisions, external
responses, and prior work.

The product question is therefore:

> **From everything the agent could know, what should it see now?**

Long-running and tool-using agents make that question harder. Raw output
accumulates, unchanged material is rediscovered, summaries lose detail, a new
session loses working state, and a second agent receives either too little
context or an entire irrelevant transcript.

LeanCTX makes this lifecycle explicit and recoverable.

## 3. Core lifecycle

The stable mental model is:

```text
Select → Shape → Reuse → Recover
```

### Select

Identify the sources relevant to the current task: repository files, command
output, search results, task state, or project facts.

### Shape

Return the representation the task needs: a structural map, signatures,
relevant lines, a focused result set, a compact view, or full source.
Compression is one shaping operation; it is not the category.

### Reuse

Carry forward context that remains valid instead of rediscovering it. Reuse is
always scoped by project, freshness, and policy.

### Recover

Return from a compact or derived view to exact source material when the task
requires more detail. Compact context is an index into truth, not a replacement
for truth.

## 4. Two cross-cutting directions

### Prove

LeanCTX can record local Receipts and offline-verification artifacts. A receipt
makes a declared operation inspectable; it does not itself prove task quality,
savings, or a universal performance result. Those claims require a comparable
baseline and treatment, a declared quality threshold, and visible methodology.

### Share

The desired **Research** direction is shared, scoped project context: agents and later
sessions reuse decisions, findings, references, and task state without passing
around complete transcripts.

This is not a public claim that LeanCTX orchestrates agents. Current agent
presence, bus, task, message, handoff, and A2A-related paths are local
implementation substrate. A supported shared-context product requires a bounded
contract, scope and privacy rules, freshness/conflict semantics, observable
limits, support ownership, and an explicit status gate.

## 5. Context is broader than memory, RAG, and compression

Memory is persisted information that may later become a source of context.
RAG is one way to select documents. Compression is one way to shape a payload.

LeanCTX owns the broader decision:

> **What should this agent see next, in what form, and how can it reuse or
> recover it?**

```text
Agent framework / scheduler → what the agent does next
LeanCTX                    → what context reaches that next step
Model                      → inference over that context
Sandbox / cloud workspace  → where work may execute
```

This makes LeanCTX complementary to agent frameworks, memory stores, model
gateways, and cloud-agent platforms.

## 6. Integration model and status

| Integration depth | Current status | Meaning |
| --- | --- | --- |
| Attach | Available | Local CLI, MCP, hooks, or proxy path around supported coding agents. |
| Wrap | Preview | The declared Python SDK v1 and OpenAI Agents SDK reference-wrapper path. |
| Embed | Preview | Native use inside a custom host; the host still owns the agent loop. |
| Shared Project Context | Research / target | Local substrate exists; no supported public coordination contract yet. |
| Performance Benchmark, Profiles, Kits, AutoTune | Research | Direction and design work, not general product promises. |

The strategic destination is native custom-agent integration. The available
coding-agent path remains the immediate distribution wedge and must never be
presented as inferior or deprecated.

### Embedded product distribution

Embed includes AI-native products that place LeanCTX below their own
product-owned agent/runtime and distribute that integration into downstream
customer deployments. LeanCTX still does not own the agent.

The product-market-fit test is demanding: a capable product company could build
its own context layer but chooses LeanCTX instead. Expansion into a second
workflow, second agent or downstream production deployment using the same
contracts is stronger evidence than founder-specific integration. No named
prospect defines the architecture.

### Why buy instead of build?

Engine users can legally and technically build their own layer. Their
alternative is to own a permanent internal product covering lifecycle,
freshness, recovery, budgets, evidence, adapters, security, migrations,
compatibility, testing, documentation, and production support.

The Production SDK packages that burden into one maintained product. Its value
is not access to hidden Engine mechanisms; it is excellent semantics, safe
defaults, integration quality, upgrade responsibility, and embedded/OEM
readiness.

> **The Engine makes it possible. The SDK makes it practical to depend on in
> production.**

> **We could build this ourselves. We chose LeanCTX instead.**

### Premium SDK quality bar

The SDK must feel obvious, coherent, fast, stable, safe, predictable,
well-documented, framework-friendly, testable, observable, and easy to upgrade.
It must turn sophisticated context engineering into a boringly simple normal
path, not expose a configuration maze or a thin collection of Engine wrappers.

## 7. Target public SDK contract

The Runtime has a broad tool surface. The public SDK should converge on a small,
stable contract rather than asking developers to understand every internal
command.

The v1 design target is deliberately limited to five primitives. They are
candidates for a stable public contract only after schemas, fixtures,
compatibility policy and runtime proof exist:

| v1 primitive | Responsibility |
| --- | --- |
| `ContextSession` | Scoped lifecycle for one task or agent run. |
| `ContextSource` | Retrievable truth or evidence with scope and recovery metadata. |
| `ContextView` | Task-fit representation linked back to its source material. |
| `ContextPlan` | Deterministic, bounded selection and shaping decision. |
| `ContextReceipt` | Factual record of a relevant context operation and its evidence. |

The following are post-v1 Research targets, each requiring its own versioned
contract and promotion gate:

| Deferred target | Promotion order and responsibility |
| --- | --- |
| `ContextWorkspace` | W1 local-first parent for bounded durable state and sessions. |
| Checkpoint and `ContextPackage` / `.ctxpkg` | W2 recoverable local artifacts and integrity-aware transfer. |
| `ProjectContext`, `ContextHandoff`, `ContextDelta` | W3 scoped reuse, structured handoff and parallel local work. |
| `ContextPolicy` | Enforced policy contract only after the core local lifecycle is proven. |

`ContextWorkspace` must not turn LeanCTX into an agent platform. The host still
owns execution; Engine owns local operations; Cloud stays optional. See
[Context Workspace & `.ctxpkg` Plan](07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md).

The contract must earn these invariants before promotion:

- derived views preserve source lineage;
- recovery is explicit where the source remains available;
- project and role scopes remain isolated;
- mutable source-derived state carries freshness or stale semantics;
- handoffs are structured and bounded;
- budgets and trust classifications are observable;
- receipts distinguish measured values from estimates and outcomes.

## 8. Multi-agent positioning

Use this public language only after a public surface earns an explicit
**Preview** status:

> **Agents can have different jobs. They should not have to rediscover the same
> project.**

> **LeanCTX gives the agents you orchestrate a shared, scoped project context.**

The correct responsibility split is:

```text
Host scheduler / framework
  → assigns work, invokes agents, retries, and controls execution

LeanCTX
  → prepares task-fit project context, preserves source references,
    reuses valid state, and creates bounded handoff artifacts
```

Do not market:

- multi-agent platform;
- agent swarm infrastructure;
- agent-to-agent communication product;
- shared enterprise brain;
- workflow scheduler;
- general agent orchestration.

The customer value is not that LeanCTX chooses who works next. It is that a
planner, implementer, and reviewer can start from the appropriate decisions,
findings, tests, and source references instead of rebuilding or receiving a
full transcript.

## 9. Language system

### Use

- The Context SDK for AI Agents
- Give every agent a context system
- Select, shape, reuse, and recover context
- Return a task-fit source view
- Reuse unchanged project context
- Recover the exact source on demand
- Hand off decisions and evidence, not a whole transcript
- Keep context explicit inside the agent loop
- Reduce unnecessary context before inference

### Do not lead with

- performance, innovation, intelligence, or other undefined abstractions;
- agent platform, agent OS, agent swarm, or generic orchestration;
- agent memory as the category;
- universal savings, quality, or hallucination claims;
- tool count or implementation names such as Agent Bus.

Context performance remains a useful technical and enterprise framing only when
the affected dimension is named: context sent, repeated reads, source recovery,
latency, calculated cost, or accepted task outcome.

## 10. Public narrative

### Category

> **The Context SDK for AI Agents.**

### Hero

> **Give every agent a context system.**

### Explanation

> **LeanCTX selects, shapes, reuses, and recovers the project context your
> agent needs—inside the agent loop you already own.**

### Architecture line

> **Your framework runs the agent. LeanCTX manages its context path.**

### Shared-context line

> **Agents can have different jobs. They should not have to rediscover the same
> project.**

### Recovery line

> **Return a task-fit view now. Recover the exact source when you need it.**

### Handoff line

> **Hand off decisions and evidence, not a whole transcript.**

## 11. Website implications

The website should teach the category in this order:

1. **Problem:** An agent can access everything; it should not load everything.
2. **Lifecycle:** Select, Shape, Reuse, Recover.
3. **SDK:** Show a small, clearly labelled target integration path; do not
   imply that target API names are already stable.
4. **Two entry points:** `Install for your coding agent` (Available) and
   `Build with LeanCTX` (Preview).
5. **Shared project context:** planner → builder → reviewer, visibly labelled
Research until a public contract earns Preview status.
6. **Proof:** methodology, declared scope, quality gate, and Receipts—not a
   standalone percentage.
7. **Local-first:** customer-side context boundary, portability, and
   model/framework independence.

Do not modify the live leanctx.com site under this strategy work. The dedicated
V2 repository is the only website implementation scope after copy approval.

## 12. Proof and product decisions

The strongest demonstration is an agent that behaves differently because
LeanCTX controls context production:

1. select a source neighbourhood for the task;
2. return focused views before full source;
3. reuse valid decisions and project facts;
4. recover exact lines or raw output only when needed;
5. record findings and verification state;
6. create a bounded handoff for the next agent or session;
7. inspect the declared context path in a Receipt.

The earlier controlled five-turn coding-agent result remains scoped evidence:
it showed lower calculated API cost under its declared methodology. It is not a
universal claim and cannot substitute for the current quality-gated proof path.

## 13. Delivery priorities

1. Keep this positioning aligned across active internal references, public docs,
   package READMEs, and the dedicated V2 copy plan.
2. Define and version the small SDK contract before promoting target primitive
   names as stable APIs.
3. Build one canonical custom-agent reference demo with task-fit views, reuse,
   recovery, bounded handoff, and a Receipt.
4. Treat `ContextWorkspace`, ContextCheckpointV2 and `.ctxpkg` composition
   as post-v1 target architecture until their individual contracts and
   migration fixtures exist.
5. Publish one capability/status map for every marketed integration and
   advanced capability.
6. Productize shared project context only after its contracts, safety boundary,
   and evidence are explicit.

## 14. One-line decision rule

> **LeanCTX should own what the agent knows for the next step—not what the
> agent does next.**
