# LeanCTX Engine, SDK & Cloud — Canonical Product Plan

> **Status:** Active internal strategy and implementation authority.
>
> **Classification:** Canonical support. The
> [canonical architecture](00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md)
> has higher authority for product and repository boundaries.
>
> **Precedence:** This document defines the three-product boundary and
> delivery order. The [internal README](../README.md) defines claim discipline;
> [Product Architecture](PRODUCT-ARCHITECTURE.md) defines current availability.
> The [Complete Implementation Roadmap](08-COMPLETE-IMPLEMENTATION-ROADMAP.md)
> supplies the binding cross-product gates, RFC backlog and milestone exits.
> Source-level truth still wins over plans.
>
> **Source synthesis:** `LEANCTX_ENGINE_SDK_CLOUD_MASTER_CONCEPT.md` was
> reviewed against the current codebase and internal authority. This concise
> plan, not an untracked input file, is the maintained decision record.

## 1. Decision

LeanCTX is **context infrastructure for AI agents**. It has three products with
one-way dependencies:

```text
Apache-2.0 LeanCTX Engine
      ↓ public Engine Protocol
BSL 1.1 LeanCTX Production SDK — primary product
      ↓ customer-owned agent / AI-native product
optional LeanCTX Cloud later
```

The umbrella promise remains:

> **Give every agent a context system.**

The host framework decides what an agent does next. LeanCTX determines and
executes the context work that makes the next inference useful.

```text
Framework → task, tools, retries, scheduling, permissions and UX
SDK       → what the agent should know next, in what form and within which rules
Engine    → local reads, search, shaping, cache, recovery and safety operations
Cloud     → shared state, observation and governance across an organization
```

This is a product split, not a reason to relicense or destabilize the existing
open-source runtime.

### Engineering discipline

> **Build less surface. Make the surface exceptional.**

Lean means fewer concepts, states, contracts and places where truth can
diverge—not minimum LOC. Test in proportion to risk; test count is not a KPI.
Prefer one real vertical slice over unintegrated infrastructure. No feature or
architecture theatre.

## 2. Product boundaries

| Product | Job | Current truth | Strategic commercial posture |
| --- | --- | --- | --- |
| **Engine** | Execute deterministic local context mechanisms. | Existing Apache-2.0 Rust runtime, CLI, MCP, hooks, proxy and stores are the public distribution wedge. | Remains genuinely open source. |
| **SDK** | Own the maintained production context lifecycle inside customer-owned agent loops. | Python v1 and its OpenAI Agents reference wrapper are **Preview/migration input**; no stable Production SDK repository exists. | Primary Thinkery product; separate repository; BSL 1.1. Only named license/release parameters remain pending. |
| **Cloud** | Later observe, share and govern context across teams, agents and machines. | **Research**. Existing local receipts, knowledge, bus and provider substrate are not a Cloud product. | Optional private/commercial expansion only after SDK PMF. |

### Feature-placement test

1. A deterministic operation on local input without task semantics belongs in
   **Engine**.
2. A decision about the context an agent should receive, reuse, recover or
   carry forward belongs in **SDK**.
3. Shared state across users, machines or organizations; central policy; or
   aggregate observation belongs in **Cloud**.

The SDK defines portable objects such as a handoff. Cloud may deliver or
govern them. Cloud never becomes a prerequisite for local Engine or SDK work.

## 3. LeanCTX Engine

### Owns

- source access, search, parsing, structure and graph retrieval;
- task-fit source transformations, token utilities, cache/archive and recovery;
- local storage, redaction, PathJail, integrity and bounded execution;
- CLI, MCP, hooks, proxy and protocol-level local providers.

### Does not own

- an agent's task plan, scheduler, retries, permissions model or user
  experience;
- context strategy for a business task;
- customer identity, organization policy distribution, billing or fleet
  management;
- generic agents, workflows, vector databases or cloud workspaces.

### Engineering rule

Keep the Engine **boringly excellent infrastructure**: deterministic outputs,
source lineage, explicit recovery, secure local defaults, stable protocols and
small dependable primitives. Freeze or deprecate surfaces that mix mechanism
with unbounded agent orchestration; do not yank existing supported paths
without a replacement and migration window.

## 4. LeanCTX SDK

The SDK is the developer product for building agents. It turns Engine
mechanisms into a bounded context lifecycle:

```text
Select → Shape → Reuse → Recover
```

Evidence is cross-cutting: receipts record what happened; evaluation compares
declared strategies under a stated quality threshold.

### v1 contract: keep it small

The first stable contract must contain only what the reference demo needs:

| Primitive | v1 responsibility |
| --- | --- |
| `ContextSession` | Scope one unit of agent work, budget and provenance. |
| `ContextSource` | Addressable source with freshness and recovery metadata. |
| `ContextView` | Task-fit derived view linked to its source. |
| `ContextPlan` | Inspectable deterministic selection and shaping decision. |
| `ContextReceipt` | Factual record of the context operation and measured values. |

`LeanCTX` may be the ergonomic root only after these contracts are stable. The
following are deliberate later phases, not v1 marketing: `ProjectContext`,
`ContextPolicy`, `ContextHandoff`, `ContextDelta`, Context Kits, adaptive
planning and framework adapter breadth.

### ContextWorkspace target

`ContextWorkspace` is the future SDK resource that gives durable,
source-backed context state one parent. It is a **Research/post-v1 target**,
not a fourth product, a public v1 API, a filesystem, a sandbox, or an agent
runtime. It may coordinate sessions, source references, policy, checkpoints,
package pins, handoffs and receipts while the Engine continues to own local
mechanisms and the host continues to own execution.

The narrow session/source/view/plan/receipt path earns its local proof first.
Only then may a versioned Workspace lifecycle unify existing stores without
creating a second session, receipt or cache stack. The binding state model,
`.ctxpkg` boundary and phased gates are in
[Context Workspace & `.ctxpkg` Plan](07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md).

### v1 invariants

- every derived view retains source lineage and an explicit recovery route;
- a reuse decision has scope and freshness evidence;
- `prepare()` is deterministic for the same inputs, policy and Engine version;
- budget, trust class, source limitations and measured-versus-estimated fields
  are observable;
- the SDK degrades locally when Cloud is absent;
- the host retains control of the agent loop.

### Repository and licensing gate

Before a new SDK repository is created, publish a versioned Engine interface,
compatibility policy, package names, integration demo and migration stance for
the existing in-process/Python surfaces.

> **The Engine remains Apache-2.0. The Production SDK is the primary product,
> will live in a separate repository, and uses BSL 1.1. Only the exact BSL,
> repository, release, contributor, security, OEM, and pricing parameters listed
> in the Production SDK Decision Record remain pending.**

Record BSL 1.1 as decided. Do not invent its Change Date, Change License,
Additional Use Grant, use boundary, OEM terms, pricing, or release/security
parameters before the responsible owners approve them.

## 5. LeanCTX Cloud

Cloud is an optional organization-scale layer for observing, sharing and
governing context across production agents. It is **Research** until an
individual surface earns a contract, privacy boundary, support owner and status
decision; local Engine and SDK operation never requires it.

### Smallest credible Cloud v1

Start with an opt-in **Receipt Board**:

- ingest signed or integrity-aware receipts and declared evaluation artifacts;
- show context sent, reuse, latency and calculated cost only with methodology;
- separate measured values, estimates and accepted outcomes;
- support metadata-only operation by default;
- retain tenant, project, policy and provenance boundaries from day one.

Do not start with raw repository synchronization, shared memory, agent
presence or a generic multi-agent platform.

### Data modes, in order

1. **Metadata only:** receipt and evaluation metadata, with no raw source.
2. **Derived context:** explicitly permitted views and bounded artifacts.
3. **Synchronized Project Context:** source references, decisions and facts
   with conflict, freshness and access semantics.
4. **Managed context:** only for a separately designed deployment and data
   control model.

Cloud must never silently upload raw source. Every mode requires explicit
policy, retention, tenant isolation, auditability and a local degradation path.

## 6. Dependency, protocol and release rules

```text
Engine: local mechanisms and versioned protocol contracts; never imports SDK or Cloud.
SDK:    consumes Engine contracts; exposes semantic contracts; never requires Cloud.
Cloud:  consumes published SDK/receipt contracts; never reaches into local Engine state.
```

- Promote a protocol only with schema/versioning, fixtures, compatibility
  tests, ownership and a deprecation policy.
- Maintain a compatibility matrix across released Engine and SDK versions.
- Release Engine, SDK and Cloud independently; no private Cloud module may be
  imported by the public runtime.
- Existing internal `Engine` types, Agent Bus, OCLA paths and provider
  machinery are implementation substrate unless a named public contract earns
  promotion.

## 7. Delivery sequence

The canonical sequence is P0 → P1 → P2 → P3 → P4 → P5–P7 → P8 → P9.
The older Phase labels below are a design crosswalk only and cannot reorder or
rename those gates:

- Phase 0 material supports P0–P2 and prepares—but does not approve—P4 decisions.
- Phase 1 is the P3 real SDK Preview vertical slice.
- Phase 2 is P4 contract hardening and separate-repository work after approvals.
- Phase 3 maps to P5–P7 Workspace/package/handoff Research.
- Phase 4 quality/adapters belong inside P2–P4 exits, before P5 begins.
- Phase 5 maps to P8 Receipt Board; governed optimization is P9.

### Phase 0 — boundaries before features

1. Freeze the product map and feature-placement test in all active docs.
2. Inventory present Engine, protocol, Python and in-process interfaces by
   support level; mark unsupported surfaces as internal or legacy.
3. Choose the Engine interface boundary and publish a compatibility policy.
4. Implement the decided separate-repository and BSL 1.1 strategy; approve its
   remaining namespace, license-parameter, contributor and release details.
5. Define the canonical reference workload and evidence gate.
6. Keep the current low-level `Engine` type internal; converge versioned
   invocation, observation and failure records in the protocol layer before
   exposing a new façade.
7. Prove one native Engine capability end-to-end: policy admission, resolved
   identity, deterministic invocation, structured observation and receipt
   lineage. Preserve legacy dispatch until parity is measured.
8. For any governed, shared or Cloud path, define an explicit admission result:
   enforced/degraded sandbox posture, resolved identity and scope, monotonic
   policy floor, declared data mode, external signer trust, licensing/
   repository approval, and named jurisdiction/export review ownership.
   A missing admission input blocks governed promotion; it never silently
   becomes a local or Cloud permission.

**Exit:** one written contract boundary, one package naming decision and no
unlabelled SDK/Cloud claims; governed paths have no fail-open identity, policy,
trust or data-mode claim.

### Phase 1 — deterministic SDK session

Build the smallest local reference integration: `ContextSession`, sources,
views, a budget, deterministic `prepare()`, recovery and a receipt. A developer
must build a useful custom agent without calling internal `ctx_*` tools.

**Exit:** reproducible demo, source-lineage tests, budget tests and a clear
Engine/SDK compatibility fixture.

### Phase 2 — planner, reuse and recovery

Add candidate discovery, deterministic view choice, inspectable plans,
version-aware reuse, invalidation and recovery references. Do not add adaptive
planning until deterministic strategies produce comparable evaluation evidence.

**Exit:** long-running reference workload avoids repeated discovery while
remaining able to recover exact source.

### Phase 3 — durable local Workspace and project context

After the deterministic session path is proven, specify a local
`ContextWorkspace` identity, source catalog, policy boundary and session
attachment. Add only source-backed facts, decisions, constraints and unresolved
questions; then policy and a bounded local handoff. A handoff carries task
state, evidence and source references—not a transcript.

**Exit:** a new local session can continue a task from bounded Workspace state
under an explicit policy. A public checkpoint/fork/delta/merge contract still
requires its own additive versioning and migration gates.

### Phase 4 cross-cut — P2–P4 evaluation and adapters (not a later phase)

Ship baseline/strategy comparisons with named measures and quality thresholds;
add adapters only where a validated customer workflow needs them.

**Exit:** one public-quality proof path and one or two maintained integration
paths, not an adapter catalogue.

### Phase 5 crosswalk — P8 Cloud Receipt Board; P9 remains later

Implement opt-in receipt/evaluation ingestion, tenant/project identity,
retention, audit and a metadata-first board. Shared Project Context, handoff
delivery, policy distribution and fleet management wait for explicit contracts
and customer evidence.

**Exit:** a team can inspect declared context behavior across runs without raw
source upload or dependence on Cloud for local execution; tenancy, retention,
audit, external signer trust, data mode and local-degradation admission are
tested before the surface is promoted.

## 8. Explicit non-goals

Do not build a generic agent builder, scheduler, workflow system, vector
database, observability replacement, knowledge base or generic multi-agent
communication product. LeanCTX owns what an agent knows for the next step—not
what the agent does next.

## 9. Status and communication discipline

| Surface | Status now | Promotion requirement |
| --- | --- | --- |
| Local Engine and coding-agent Attach | Available | Existing supported path and release evidence. |
| Python SDK v1 / OpenAI Agents reference wrapper | Preview | Explicit compatibility, limits and evidence. |
| General SDK object model and custom-host Embed | Preview target | Stable contract, fixtures, docs and reference demo. |
| Project Context, policy and handoff as product | Research | Scope, freshness, privacy, conflict and support rules. |
| Cloud Receipt Board | Research | Tenant, data-mode, retention, audit and evidence contract. |
| Shared context, governance and fleet control | Research | Cloud prerequisites plus customer-validated operation. |

Never turn an internal module, benchmark, prototype, plan or package into a
public claim. Name the mechanism and measure; avoid undefined promises such as
"performance" or "intelligence" without the affected dimension.

## 10. Immediate work queue

1. Publish the Engine interface and compatibility decision.
2. Create the deterministic custom-agent reference demo and its test fixture.
3. Define the five v1 SDK primitives and receipt schema as versioned contracts.
4. Audit current surfaces against Engine / SDK / Cloud; freeze ambiguous new
   work until classified.
5. Validate SDK buy-vs-build, repeat adoption, compatibility, and embedded
   distribution before scheduling Cloud implementation.
6. Resolve the remaining BSL parameters, repository ownership, namespace,
   contributor, security and release policy before production publication.
7. Write Workspace, SourceAnchor and checkpoint RFCs only after the current
   session/receipt path has a passing local reference fixture; keep
   `ContextKit` and `.ctxpkg` separate until their mapping is versioned.

## 11. Decision rule

> **Engine executes context operations. SDK decides context. Cloud coordinates
> context. The agent framework remains responsible for the agent.**
