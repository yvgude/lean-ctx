# LeanCTX Context Workspace & `.ctxpkg` Plan

> **Status:** Active internal target architecture. The current implementation
> and availability labels in [Product Architecture](PRODUCT-ARCHITECTURE.md)
> remain authoritative.
>
> **Classification:** Canonical support for post-v1 Research. It cannot make
> Workspace, sync, collaboration or Cloud prerequisites for Production SDK v1.
>
> **Source synthesis:** This plan reconciles
> [archived source concept](../_archive/sdk-first-convergence-2026-08-24/vision/CONTEXT-WORKSPACE-CTXPKG-MASTER-CONCEPT.md)
> with the codebase and the Engine/SDK/Cloud plan. The long source document is
> preserved verbatim for background; this concise plan records decisions.
> The [Complete Implementation Roadmap](08-COMPLETE-IMPLEMENTATION-ROADMAP.md)
> supplies the binding cross-product gates, RFC backlog and milestone exits.

## 1. Decision

`ContextWorkspace` is a post-v1 Research SDK resource for the durable context state of
one body of agent work. It is **not** a fourth LeanCTX product, a filesystem,
a VM, a scheduler, an agent, a memory database, or an execution sandbox.

```text
Host / framework  → task, model, tools, retries, scheduling, permissions, execution
LeanCTX SDK       → ContextWorkspace semantics and context decisions
LeanCTX Engine    → local context operations and portable protocol mechanisms
.ctxpkg           → portable, sealed context artifact or dependency
LeanCTX Cloud     → optional remote coordination and governance
```

The Workspace gives one clear parent to state that is currently represented by
sessions, source references, project facts, policies, snapshots, packages,
handoffs and receipts. It must **unify existing mechanisms**; it must not
rebuild them in parallel or promote them by renaming.

Current status remains unchanged:

| Surface | Status now |
| --- | --- |
| Local Engine, CLI, MCP, proxy and local context mechanisms | Available |
| Python SDK v1 and named OpenAI Agents wrapper | Preview |
| General cross-language SDK contract | Preview target |
| `ContextWorkspace` public lifecycle | Research / post-v1 target |
| Cloud, shared remote context and registry | Research |

`.ctxpkg` remains an open portable context-artifact/package concept. The
Production SDK license is BSL 1.1; an open interchange format does not transfer
SDK lifecycle semantics into the Engine or reopen that decision.

## 2. Canonical resource model

```text
ContextWorkspace
  ├── source catalog and recovery references
  ├── scoped ProjectContext and policy state
  ├── package pins
  ├── derived views and reusable artifacts
  ├── immutable checkpoints and lineage
  └── ContextSession
        ├── task and ContextPlan
        ├── selected ContextViews
        ├── bounded findings and decisions
        └── ContextReceipt
```

The target vocabulary is deliberately constrained:

| Object | Target responsibility | Not a claim today |
| --- | --- | --- |
| `ContextWorkspace` | Live, local semantic parent for durable context state. | Stable public SDK object. |
| `ContextSession` | One unit of task-scoped context work. | A replacement for existing session stores. |
| `ContextCheckpoint` | Immutable, restorable Workspace state reference. | Current SnapshotV1 renamed or widened. |
| `ContextDelta` | Source-backed semantic difference between states. | A generic transcript diff. |
| `ContextHandoff` | Curated, bounded transfer for another session or agent. | Implicit merge or agent orchestration. |
| `.ctxpkg` | Open, signed, versioned portable artifact/dependency. | A live Workspace, Cloud account or marketplace. |

Credentials, provider tokens, raw prompts and opaque provider responses remain
outside the portable state model. State and authorization are separate.

## 3. Ownership and dependency rules

| Layer | Owns | Does not own |
| --- | --- | --- |
| **Engine** | Local read/search/shape/recover/hash, revision and source operations, package parse/verify/materialize, local snapshot primitives, storage and safety. | Workspace lifecycle semantics, agent execution, organization policy or Cloud state. |
| **SDK** | Context decisions; later Workspace lifecycle, session attachment, package materialization, checkpoint/fork/delta/handoff semantics and receipt assembly. | Model inference, task execution, retries, scheduler, VM/sandbox or host permissions. |
| **Cloud** | Optional remote metadata, governed sharing/sync, observation, registry and tenancy after local proof. | A required dependency for local Engine/SDK work or default source ingestion. |
| **Host** | Agent loop, task, prompts, tools, retries, execution environment and UX. | LeanCTX context semantics and evidence. |

The one-way dependency is unchanged:

```text
Cloud → SDK → Engine protocol → Engine
```

Every feature still passes the placement test: deterministic local mechanics
belong in Engine; semantic context decisions and lifecycle in SDK; shared
organization state or control in Cloud.

## 4. `.ctxpkg` and ContextKit discipline

`.ctxpkg` stays an open artifact format. Current local package code, signing,
lockfiles and snapshot/export paths are useful substrate, but they do **not**
yet establish one public Workspace format, a hosted registry, or a complete
Kit-to-package mapping.

Until a versioned contract says otherwise:

- `ContextKit` and `.ctxpkg` are distinct concepts and implementations;
- a package can pin or seed future Workspace state, but it is never the live
  mutable Workspace;
- current Git-anchored SnapshotV1 is foundation only, not
  `ContextCheckpointV2`;
- existing readers/importers keep compatibility; new state semantics require
  additive versioned contracts and migration fixtures;
- package integrity proves artifact integrity, not accepted task quality,
  universal savings or customer outcome.

No registry, marketplace, remote discovery, raw-source synchronization or
Cloud account is implied by this plan.

## 5. Non-negotiable invariants

1. **Local first:** Workspace operations degrade locally when Cloud is absent.
2. **Source fidelity:** a view preserves lineage and an explicit recovery path.
3. **Explicit freshness:** reuse, stale state, source revision and conflict are
   represented—not silently assumed.
4. **Bounded state:** no hidden transcript becomes the durable source of truth.
5. **Policy inheritance:** sharing, fork and package materialization are
   bounded by explicit policy and scope.
6. **Immutable checkpoints:** checkpoint identity cannot change after creation.
7. **Explicit conflict:** a merge never silently turns caches or conflicting
   facts into truth.
8. **Provenance:** package, source, plan, transition and receipt links remain
   inspectable.
9. **No raw upload by default:** Cloud data modes require explicit consent,
   tenancy, retention and audit boundaries.
10. **Execution separation:** a Workspace fork copies what an agent knows, not
    the repository branch, VM, container or scheduler state.

## 6. Delivery order

This Research subplan cannot reorder the canonical P0–P9 roadmap. W0 occurs
only after integrated P2 and maps to P3/P4; W1 maps to P5, W2 to P6, W3 to P7,
and W4 to P8. P9 governed optimization is outside Workspace scope.

### W0 — boundary and current-path proof

Finish the existing deterministic
`ContextSession → ContextSource/View → ContextPlan → ContextReceipt` reference
path through versioned Engine contracts. Inventory Kit, package, snapshot and
session boundaries; resolve SDK repository/licensing gates before a production
SDK exists.

**Exit:** reproducible local custom-agent demo, source lineage and recovery
tests, compatibility fixture, and no unlabelled Workspace/Cloud claim.

### W1 — Workspace contract

Specify `ContextWorkspace` identity, local open/create/status, source catalog,
policy boundary and session attachment. Reuse existing state stores behind one
contract; do not create a competing session, receipt or cache stack.

**Exit:** versioned SDK/Engine contract, explicit local storage boundary and
fixture-backed state transitions.

### W2 — Checkpoint and package integration

Define `ContextCheckpointV2` additively: immutable state references, source
anchors, recovery, digest rules and migration from SnapshotV1. Define
package pin/install/seed/seal semantics only after the Kit↔`.ctxpkg` relation
is explicit.

**Exit:** deterministic restore and package fixtures; no silent format rewrite.

### W3 — Parallel local context

Add copy-on-write fork lineage, bounded `ContextDelta`, policy inheritance and
handoff first. Treat semantic merge as advanced work with narrow modes and
explicit conflict reports; never merge a cache as truth.

**Exit:** two local sessions can continue bounded verified work without
transcript transfer or hidden cross-project state.

### W4 — optional Cloud remote

Start with metadata-only workspace/checkpoint lineage and receipt observation.
Cloud promotion requires tenant/project identity, retention, audit,
data-mode consent, local degradation and customer evidence. Shared context,
package registry and governance are later independent decisions.

**Exit:** a team can inspect declared context behavior without raw source
upload or Cloud dependence for local execution.

## 7. Explicit non-goals

Do not build a generic agent builder, workflow/scheduler, VM or sandbox,
filesystem, vector database, generic memory service, multi-agent messaging
platform, Cloud-first workspace, or marketplace as part of this plan.

## 8. Decision rule

> **Does this make the ContextWorkspace lifecycle more explicit, recoverable
> and local-first? If not, it is not Workspace-priority work.**
