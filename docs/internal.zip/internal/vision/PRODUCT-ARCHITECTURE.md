# LeanCTX Product Architecture

**Status:** Current product architecture; the [internal README](../README.md)
owns availability.  
**Classification:** Canonical support. The
[canonical architecture](00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md)
owns product and repository boundaries.  
**Descriptor:** LeanCTX is **The Context SDK for AI Agents**.  
**Broader category:** Context Infrastructure for AI Agents.  
**Product concept:** Give every agent a context system.

[Context SDK Positioning](05-CONTEXT-SDK-POSITIONING.md) defines the public
narrative. [Engine, SDK & Cloud Plan](06-ENGINE-SDK-CLOUD-PLAN.md) and
[Context Workspace & `.ctxpkg` Plan](07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md)
define product order and promotion gates. This document explains the product
without turning implementation substrate into a shipped contract; its status
labels distinguish available local capability, Preview convergence, and
Research.

The dependency and target repository direction is always:

```text
Apache-2.0 Engine
      ↓ public Engine Protocol
BSL 1.1 Production SDK — primary product, separate repository
      ↓ customer-owned agent / AI-native product
optional private Cloud later
```

The current monorepo is transitional. `packages/python-lean-ctx/` is
Preview/migration input. The Engine remains Apache-2.0; the Production SDK is a
separate BSL 1.1 product. Only the exact legal/release parameters enumerated in
the Production SDK Decision Record remain pending.

## The product model

```text
                                  LEANCTX
                             Context SDK
                                      │
              ┌───────────────────────┼───────────────────────┐
              │                       │                       │
              ▼                       ▼                       ▼
         INTEGRATE                 OPTIMIZE                 VERIFY
              │                       │                       │
       Coding agents            Context plans             Benchmark
       Custom agents             Reuse                     Quality
       Frameworks                Compression               Receipts
                                 Recovery

                                      │
                                      ▼
                            ENTERPRISE: OPERATE
           Performance Profiles · Private context assets · Shared evidence
                    Policy · Organization economics · Private deployment
```

LeanCTX sits inside or alongside an existing agent loop. It controls how
context is selected, shaped, reused, recovered, and measured before it reaches
the model. It does not replace the customer's agent, task logic, model choice,
tools, or application retry policy.

The intended public v1 contract stays deliberately small:

```text
ContextSession → scope one task or agent run
ContextSource  → identify recoverable truth or evidence
ContextView    → provide a task-fit, source-linked representation
ContextPlan    → record a bounded deterministic context decision
ContextReceipt → record factual operation evidence
```

These five records are design candidates, not a current release. The historic
Python Preview convenience shape (`LeanCTX()`, `session()`, `wrap()`,
`load_kit()`, `receipt()`) is not a second v1 contract; it remains unsupported
where its proxy routes lack runtime parity.

`ContextWorkspace` is a post-v1 Research target: durable, source-backed context
state from which task sessions may derive what they need. It is not a shipped
facade and does not make LeanCTX an execution environment, agent scheduler or
Cloud workspace. The host owns execution; Engine owns local mechanism; Cloud
remains optional. See [Context Workspace & `.ctxpkg` Plan](07-CONTEXT-WORKSPACE-CTXPKG-PLAN.md).

## Status language

| Status | Meaning |
| --- | --- |
| **Available** | A shipped capability has a supported real user path. Implementation substrate alone does not qualify. |
| **Preview** | The public contract is being converged from existing substrate; use it only with an explicit compatibility and evidence scope. |
| **Research** | A product direction or private-commercial intent, not a generally available LeanCTX promise. |

An implementation directory is not, by itself, a public API. In particular,
the planned v1 facade, session semantics, typed adapters, and evidence flow
must pass their contract and quality gates before they are described as a
stable release.

## Integrate: three depths into one runtime

All three depths target one Context Engine, session identity, profile and Kit
identity, event order, and Receipt schema. Integration depth changes what
LeanCTX can observe and control; it must never cause an integration to invent
facts it cannot observe.

| Depth | Customer shape | LeanCTX visibility and control | Evidence rule | Status |
| --- | --- | --- | --- | --- |
| **Attach** | Install around an existing coding agent through CLI setup, MCP, or a proxy/sidecar. | Transit-visible tool and provider traffic; allowed context transformation at the gateway. | A Receipt may declare limited observability; it cannot claim host-only prompts, retries, or decisions. | **Available** locally; common V1 identity/Receipt semantics are **Preview**. |
| **Wrap** | Use a named adapter around a supported provider client or framework. | Adapter lifecycle events, prepared context, calls, streams, errors, and cancellation within the declared adapter contract. | Preserves the caller's values, errors, ordering, and backpressure while recording observable events. | **Preview**. Existing CLI `wrap` configures Attach; Python SDK v1 also provides `LeanCTX.wrap(agent)` for its declared reference-wrapper scope. It is not a general framework adapter or a GA contract. |
| **Embed** | Integrate LeanCTX natively inside a custom agent or application. | The host owns the full context lifecycle: plan, retrieval, reuse, recovery, and explicit provider calls. | Full host-owned facts can be recorded, but LeanCTX never silently sends traffic or retries the application. | **Preview**. The existing SDK Engine is substrate, not yet the public `LeanCTX()`/`session()` facade. |

The adoption rule is simple: Attach minimizes change, Wrap adds a declared
lifecycle, and Embed gives maximum control. Deeper integration is not a
license to claim better results without the same workload, quality gate, and
methodology.

Embed explicitly includes AI-native products that integrate LeanCTX beneath
their own agent/runtime and distribute it to downstream customer deployments.
The host remains owner of the agent. A capable product company choosing LeanCTX
instead of building its own context layer is a core product-market-fit test.

## Feature status map

| Public feature | What a user gets | Status | Honest boundary |
| --- | --- | --- | --- |
| **LeanCTX Runtime** | Local context tooling for selection, structural views, compression, reuse, recovery, and context-aware workflows. | **Available** | The stable product facade is still converging; module-level capabilities do not imply one finished v1 SDK contract. |
| **Attach integrations** | Keep using supported coding agents while LeanCTX operates through CLI, MCP, hooks, or proxy paths. | **Available** | Gateway evidence covers only traffic and facts the integration can see. |
| **ContextWorkspace / Checkpoint / Delta** | Target SDK resource for durable local context state, state lineage and bounded task continuation. | **Research** | Existing sessions, snapshots and diffs are substrate; no public Workspace lifecycle, checkpoint-v2 or semantic-delta contract exists yet. |
| **Shared project context and handoffs** | Local session, knowledge, handoff, and agent-presence substrate that can carry bounded work state. | **Research** | LeanCTX does not yet offer a supported cross-agent coordination, cache, privacy, freshness, or orchestration contract. |
| **Context plans** | Make selection, representation, budgets, reuse, and recovery decisions explicit for a task. | **Preview** | The planner exists; the portable `ContextSessionV1` and plan-reference contract are convergence work. |
| **Compression and reuse** | Remove avoidable context overhead while preserving recovery to exact source when needed. | **Available** | Optimization remains inspectable and bounded by the selected local configuration. |
| **Performance Profiles** | Versioned, deployable operating constraints for context behavior. | **Research** | TOML profile substrate exists locally; immutable, digest-addressed `TuningProfileV1` is not a released public contract. |
| **Context Kits** | Reusable context assets; `.ctxpkg` is separate portable local package substrate. | **Research** | Kit TOML and package/snapshot building blocks are separate; `ContextKitV1`, public package composition, pinning and signer semantics remain Research. |
| **Receipts and offline verification** | Inspectable execution/evidence artifacts and verifier foundations. | **Available** | A universal verified-savings claim requires the planned common session, quality, comparison, and bundle path. |
| **Performance Benchmark** | A declared baseline-versus-treatment test with quality and evidence gates. | **Research** | Benchmark, evaluation, and quality substrate exist; a supported local scenario and full V1 receipt flow remain release gates. |
| **Named SDK `wrap()` adapters** | Python SDK v1 provides `LeanCTX.wrap(agent)` and a declared OpenAI Agents reference-wrapper path. | **Preview** | There is no general `ctx.wrap(target, adapter=...)` adapter framework: supported agent/version, observability, degradation, and evidence remain explicit. |
| **AutoTune / autonomous promotion** | Search for and promote a winning profile automatically. | **Research** | Heuristics are not AutoTune. It needs an objective, search space, scheduler, quality constraints, promotion governance, registry, and evidence gate. |
| **LeanCTX Cloud and organization control plane** | Shared organization operation around public LeanCTX contracts. | **Research** | It is private-commercial scope, not a dependency or implicit capability of OSS. Public operational inventory is intentionally not invented. |

## Existing code → public product

These paths are the current implementation substrate. The map prevents the
public architecture from creating a parallel engine or a second definition of
profiles, Kits, sessions, or receipts.

| Public area | Existing code that owns or enables it | Product convergence |
| --- | --- | --- |
| Local Runtime and CLI | `rust/src/main.rs`, `rust/src/cli/`, `rust/crates/lean-ctx-sdk/src/lib.rs`, `rust/crates/lean-ctx-sdk/src/engine.rs` | Keep the current `Engine` as a low-level substrate; add the one public `LeanCTX` facade rather than renaming every engine. |
| Attach | `rust/src/hooks/`, `rust/src/server/`, `rust/src/tools/registered/`, `rust/src/proxy/`, `rust/src/cli/wrap_cmd.rs`, `rust/src/wrap/` | Retain as coding-agent/proxy integration. Make it emit the common integration descriptor and session correlation. |
| Context planning, compression, reuse, recovery | `rust/src/core/context_kernel/`, `rust/src/core/compressor*`, `rust/src/core/repomap*`, search and cache modules | Keep these as internal Context Engine components behind `ContextSession`; do not expose every core struct. |
| Session lifecycle | `rust/src/core/session/`, `rust/src/core/execution_ledger/` | Preserve work-session storage and the append-only ledger; compose them in the planned `SessionCoordinator` instead of renaming `SessionState`. |
| Profiles | `rust/src/core/profiles/`, profile loading/builtins, `profile_suggest` | Resolve existing local profile configuration into immutable `TuningProfileV1`; do not market suggestions as AutoTune. |
| Context Kits | `rust/src/kits/`, `rust/src/core/context_package/`, `kits/code-review/` | Evolve legacy TOML and package substrate into verified, version-pinned `ContextKitV1` assets. |
| Receipts and evidence | `rust/src/core/evidence_*`, `rust/src/core/evidence_flow.rs`, `rust/src/core/evidence_bundle.rs`, `rust/crates/lean-ctx-protocol/`, `packages/leanctx-verify/` | Assemble one canonical receipt and bundle path, then require independent verification for evidence claims. |
| Benchmark and quality | `rust/src/core/benchmark*`, evaluation and quality modules | Reuse for local baseline/treatment Dyno scenarios; do not create a parallel measurement stack. |
| SDKs and adapters | `packages/python-lean-ctx/`, `rust/crates/lean-ctx-sdk/`, `rust/crates/lean-ctx-ocla/`, `packages/node-lean-ctx/` | Canonicalize the Python distribution and add named, versioned adapters. Legacy Python trees are migration sources, not parallel product surfaces. |

The canonical V1 contracts belong in `rust/crates/lean-ctx-protocol/`. The
Rust runtime remains the reference implementation beneath CLI, MCP, proxy, and
SDK bindings. Bindings may be idiomatic, but cannot diverge on identifiers,
event ordering, errors, digests, or Receipt semantics.

## LeanCTX Cloud

LeanCTX Cloud is the intended private commercial owner of organization-facing
services. It consumes released public protocols and artifacts downstream; it
does not own or replace the local Context Engine.

It contains, as product scope rather than a public availability claim:

- account lifecycle, organizations, and workspaces;
- commercial entitlements and the Stripe-backed billing lifecycle;
- hosted private registries for approved assets and Pro/Team services;
- organization dashboards and shared operational views;
- the service boundary needed to distribute organization controls without
  importing private source into the OSS runtime.

Its repository location, deployment topology, database migration owner,
secrets, and production operations are private inventory matters and are not
asserted here. Cloud failure must not break local CLI, MCP, proxy, SDK, Kit,
Profile, or Receipt use.

## OSS and Enterprise boundary

| Capability | OSS: local and open | Enterprise / private addition | Boundary rule |
| --- | --- | --- | --- |
| Runtime and contracts | Context Engine, CLI, MCP, proxy, SDK bindings, and public protocol schemas. | Consumes released versions; does not fork the engine or schema. | The public runtime remains useful offline and without an account. |
| Integrations | Local Attach paths and the shared integration contract. | Approved organization rollout and compatibility governance. | Customer agent task logic and model choice remain customer-owned. |
| Profiles and Kits | Local configuration, local assets, verification substrate, and first-party fixtures. | Private context assets, approved registries, organization-scoped profile distribution. | Assets must retain explicit version, digest, provenance, and access boundaries. |
| Evidence | Local Receipts, evidence-bundle primitives, and offline verification. | Shared evidence history, audit views, retention and organization workflows. | A signature proves artifact integrity, not an unqualified business claim. |
| Policy | Local safety, PathJail, redaction, budget, and runtime configuration. | Organization policy, rollout controls, and governance. | Enterprise policy may constrain use but may not silently degrade local semantics. |
| Economics | Local observed usage and declared calculated-cost facts. | Organization budgets, allocation/showback, and economics views. | Distinguish provider usage, calculated cost, and invoice-reconciled cost. |
| Deployment | Local-first operation and public artifacts. | Private deployment, VPC/on-prem operation, and commercial support where offered. | No private credential, customer configuration, Cloud source, or billing dependency enters OSS. |
| Accounts and billing | None required. | Accounts, entitlements, and billing lifecycle. | An entitlement gate must be explicit; unavailable features must not be represented by a fake OSS implementation. |

## What Thinkery adds

Thinkery is the company and commercial operator, not a competing developer
product. LeanCTX is the product engineers integrate; Thinkery makes the
performance loop operable across an organization.

```text
LeanCTX: integrate → optimize → verify for one agent and workload
Thinkery: standardize → govern → compare → operate across the organization
```

On top of LeanCTX, Thinkery can provide the enterprise operating layer:

- private deployment and organization controls;
- shared evidence, policy, and performance-profile workflows;
- organization-level economics and commercial account operation;
- support for adopting the measured loop across teams, frameworks, and
  providers.

Thinkery does not turn LeanCTX into a hosted-agent platform, own customer task
logic, fabricate provider facts, or promise autonomous tuning before the
required search, quality, governance, and evidence system exists.

## Product guardrails

- **Local-first:** every useful local path remains available without Cloud.
- **Model-agnostic:** LeanCTX controls context, not default model routing.
- **Inspectable and recoverable:** compression never removes the ability to
  obtain exact source when the task needs it.
- **Evidence-led:** savings require a comparable baseline, declared quality
  gate, cost basis, methodology, and verifiable bundle.
- **One contract:** Attach, Wrap, and Embed share identities and Receipt
  semantics while honestly declaring coverage.
- **No premature platform:** Cloud, marketplace, managed execution, and
  autonomous tuning do not enter the OSS critical path ahead of proof.

## Canonical language

> **LeanCTX is the Context SDK for AI Agents.** It controls how existing
> agents select, shape, reuse, recover, and measure context before inference.
> **Measure. Compare. Verify.**

> **Thinkery builds systems for agent performance.**

## Composable target architecture

The current product architecture remains the product architecture described in
this document. Its long-term direction is a **composable Context Performance
Layer**, introduced incrementally behind the existing Context Performance
Infrastructure / Context SDK positioning. It is not a new customer promise or
a replacement runtime.

### Capability Plane and Selection Intelligence

The target separates execution from choice:

```text
workload + policy + permitted providers + performance evidence
                         |
                         v
     Performance Planner / Selection Intelligence (should use)
                         |
                         v
 Capability Plane (can perform) -> selected, ordered capability pipeline
```

The **Capability Plane** contains LeanCTX-native, customer, and third-party
providers. A provider can expose Compression, Planning, Shell, Retrieval,
Memory, KnowledgeGraph, Router, Evaluation, Policy, or Evidence capabilities.
It states what it can do and the relevant fidelity, cost, latency, privacy,
trust, compatibility, and recovery constraints.

The **Performance Planner** is not an agent orchestrator. It uses the task,
policy, quality gates, observed outcomes, and Receipts to decide what should
run, in which order, with which fallback. This Selection Intelligence is the
commercial differentiator: knowing which allowed combination delivers the
best result for a workload.

### OCLA, Profiles, and evidence

OCLA is the open **Capability Contract** for the target plane. Existing OCLA
traits already provide the codebase foundation. The next architectural work is
to make capability manifests, identity, constraints, and Receipt/Profile links
explicit; it does not require replacing the runtime or removing native
LeanCTX capabilities.

A Performance Profile may consequently name a multi-provider, policy-bounded
pipeline rather than only a LeanCTX setting. The planner remains responsible
for selecting a safe subset and proving what happened through the existing
quality-gated Receipt model.

### Capability Laboratory

The Benchmark grows into a **Performance Laboratory**. It evaluates Stock vs
LeanCTX under the same workload, quality gate, cost/latency measures, and
evidence model — producing comparable, verifiable evidence without a universal
performance claim. External capabilities exist as an Enterprise fallback, not
as a partner integration strategy.
### Delivery boundary

This is target architecture, not a reprioritization. Immediate priorities
remain Benchmark, Quality Gate, Receipt, Reference Agent, SDK, Profile, and a
paid customer. Attach, Wrap, Embed, current integrations, and public status
language remain authoritative until each composable capability is proven and
shipped.

## Source decisions

This architecture consolidates the brand narrative, technical convergence
contract, and convergence plan. For the North Star and product principles, see
[00-NORTH-STAR.md](00-NORTH-STAR.md). For the detailed runtime/API blueprint,
see the [canonical SDK-first architecture](00-CANONICAL-PRODUCT-AND-REPOSITORY-ARCHITECTURE.md).
